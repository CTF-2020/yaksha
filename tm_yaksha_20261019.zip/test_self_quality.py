"""Tests for correlator/self_quality.py -- the correlator's own reversal rate
(precision-over-time proxy).

Isolated onto a temp verdict_tracking store, same pattern as
test_verdict_tracking.py -- writing through the real one would pollute
~/.tm_verdict_history.db.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import verdict_tracking
from correlator import self_quality


def _cat(cid="A", family="sql-injection", verdict="blind_spot", loci=None):
    return {"id": cid, "name": cid, "family": family, "risk": "High",
            "verdict": verdict, "affected_components": loci or [f"{cid}.py:1"]}


def _report(rid, cats, title="R"):
    return {"id": rid, "title": title, "categories": cats}


class SelfQualityTests(unittest.TestCase):
    def setUp(self):
        self._orig = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        verdict_tracking.DB_PATH = self._orig

    def test_no_escalations_yet_rate_is_none(self):
        r = self_quality.reversal_rate()
        self.assertEqual(r["escalations"], 0)
        self.assertIsNone(r["rate"])

    def test_escalation_that_holds_is_not_reversed(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        verdict_tracking.record_transitions(_report("r2", [_cat(verdict="confirmed_exploitable")]))
        r = self_quality.reversal_rate()
        self.assertEqual(r["escalations"], 1)
        self.assertEqual(r["reversed"], 0)
        self.assertEqual(r["rate"], 0.0)

    def test_escalation_later_walked_back_is_reversed(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        verdict_tracking.record_transitions(_report("r2", [_cat(verdict="confirmed_exploitable")]))
        # De-escalation: silent in verdict_alerts, but updates verdict_history.
        verdict_tracking.record_transitions(_report("r3", [_cat(verdict="design_gap")]))
        r = self_quality.reversal_rate()
        self.assertEqual(r["escalations"], 1)
        self.assertEqual(r["reversed"], 1)
        self.assertEqual(r["rate"], 1.0)

    def test_re_escalation_back_to_original_is_not_reversed(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        verdict_tracking.record_transitions(_report("r2", [_cat(verdict="confirmed_exploitable")]))
        verdict_tracking.record_transitions(_report("r3", [_cat(verdict="design_gap")]))
        # Escalates again -- this is now the LATEST alert for this fingerprint,
        # and the current verdict matches it, so it should read as held.
        verdict_tracking.record_transitions(_report("r4", [_cat(verdict="confirmed_exploitable")]))
        r = self_quality.reversal_rate()
        self.assertEqual(r["escalations"], 1)   # one fingerprint, latest alert only
        self.assertEqual(r["reversed"], 0)

    def test_by_verdict_breakdown(self):
        verdict_tracking.record_transitions(_report("r1", [_cat("A", verdict="blind_spot")]))
        verdict_tracking.record_transitions(_report("r2", [_cat("A", verdict="confirmed_exploitable")]))
        verdict_tracking.record_transitions(_report("r3", [_cat("B", verdict="design_gap")]))
        verdict_tracking.record_transitions(_report("r4", [_cat("B", verdict="corroborated")]))
        r = self_quality.reversal_rate()
        self.assertEqual(r["escalations"], 2)
        self.assertIn("confirmed_exploitable", r["by_verdict"])
        self.assertIn("corroborated", r["by_verdict"])
        self.assertEqual(r["by_verdict"]["confirmed_exploitable"]["escalations"], 1)

    def test_precision_trend_buckets_by_escalation_time(self):
        now = 10_000_000.0
        day = 86400.0
        old_at = now - 40 * day    # bucket 0 of a 30-day-bucket window
        recent_at = now - 5 * day  # bucket 1

        verdict_tracking.record_transitions(
            _report("r1", [_cat("A", verdict="blind_spot")]), now=old_at - day)
        verdict_tracking.record_transitions(
            _report("r2", [_cat("A", verdict="confirmed_exploitable")]), now=old_at)

        verdict_tracking.record_transitions(
            _report("r3", [_cat("B", verdict="blind_spot")]), now=recent_at - day)
        verdict_tracking.record_transitions(
            _report("r4", [_cat("B", verdict="confirmed_exploitable")]), now=recent_at)

        trend = self_quality.precision_trend(buckets=2, bucket_days=30, now=now)
        self.assertEqual(len(trend), 2)
        self.assertEqual(trend[0]["escalations"], 1)
        self.assertEqual(trend[1]["escalations"], 1)

    def test_summary_worst_families_excludes_single_escalation_families(self):
        # Family "lonely" only ever escalates once -- excluded from the
        # worst-offenders ranking (too little signal to be meaningful).
        verdict_tracking.record_transitions(
            _report("r1", [_cat("A", family="lonely", verdict="blind_spot")]))
        verdict_tracking.record_transitions(
            _report("r2", [_cat("A", family="lonely", verdict="confirmed_exploitable")]))

        for i in range(2):
            cid = f"C{i}"
            verdict_tracking.record_transitions(
                _report(f"r{10+i}", [_cat(cid, family="chatty", verdict="blind_spot")]))
            verdict_tracking.record_transitions(
                _report(f"r{20+i}", [_cat(cid, family="chatty", verdict="confirmed_exploitable")]))
        # Walk one of the two "chatty" escalations back.
        verdict_tracking.record_transitions(
            _report("r30", [_cat("C0", family="chatty", verdict="design_gap")]))

        s = self_quality.summary()
        families = {w["family"] for w in s["worst_families"]}
        self.assertNotIn("lonely", families)
        self.assertIn("chatty", families)
        chatty = next(w for w in s["worst_families"] if w["family"] == "chatty")
        self.assertEqual(chatty["escalations"], 2)
        self.assertEqual(chatty["reversed"], 1)
        self.assertEqual(chatty["rate"], 0.5)


class PrecisionApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orig = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        verdict_tracking.DB_PATH = self._orig

    def test_precision_endpoint_empty_store(self):
        resp = self.client.get("/api/v1/correlate/precision")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["overall"]["escalations"], 0)
        self.assertIsNone(d["overall"]["rate"])

    def test_precision_endpoint_with_data(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        verdict_tracking.record_transitions(_report("r2", [_cat(verdict="confirmed_exploitable")]))
        resp = self.client.get("/api/v1/correlate/precision")
        d = resp.get_json()
        self.assertEqual(d["overall"]["escalations"], 1)
        self.assertEqual(d["overall"]["rate"], 0.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
