"""Tests for the correlator's public share route (GET /api/v1/correlate/<id>).

Same token-gate contract as api/reports.py's report_shared (see
test_reports_api.py's TestReportsApiRoutes for that precedent) but scoped to
methodology="correlation" reports only, and exempted from the global auth
gate by view identity (request.endpoint) rather than a path pattern -- see
app._auth_and_csrf.

report_db is isolated onto a temp DB; verdict_tracking/regression are also
isolated since _save_report best-effort syncs both for a verdict-carrying
category (see project convention on real ~/.tm_* store pollution from
unisolated tests).
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import regression
import report_db
import verdict_tracking


def _correlation_report(cats=None):
    return {
        "title": "Correlation run", "methodology": "correlation", "overall_risk": "Critical",
        "categories": cats if cats is not None else [
            {"id": "A", "name": "SQLi", "risk": "Critical", "verdict": "confirmed_exploitable",
             "family": "sql-injection", "affected_components": ["a.py:1"]}],
    }


def _sast_report():
    return {"title": "SAST scan", "methodology": "sast", "overall_risk": "High", "categories": []}


class PublicCorrelateRouteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orp = report_db.DB_PATH
        self._orpd = self.tm.REPORTS_DIR
        self._ovp = verdict_tracking.DB_PATH
        self._orgp = regression.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        root = Path(self._td.name)
        report_db.DB_PATH = root / "reports.db"
        report_db.init()
        self.tm.REPORTS_DIR = root / "reports_json"
        self.tm.REPORTS_DIR.mkdir(exist_ok=True)
        verdict_tracking.DB_PATH = root / "verdicts.db"
        verdict_tracking.init()
        regression.DB_PATH = root / "regression.db"
        regression.init()

        self.rid = self.tm._save_report(_correlation_report(), "Correlation run")
        self.token = report_db.get_report(self.rid)["share_token"]

    def _restore(self):
        report_db.DB_PATH = self._orp
        self.tm.REPORTS_DIR = self._orpd
        verdict_tracking.DB_PATH = self._ovp
        regression.DB_PATH = self._orgp

    def test_valid_token_returns_report(self):
        r = self.client.get(f"/api/v1/correlate/{self.rid}?token={self.token}")
        self.assertEqual(r.status_code, 200)
        body = r.get_json()
        self.assertTrue(body["success"])
        self.assertEqual(body["report"]["methodology"], "correlation")
        self.assertNotIn("share_token", body["report"])

    def test_wrong_token_403(self):
        r = self.client.get(f"/api/v1/correlate/{self.rid}?token=wrong")
        self.assertEqual(r.status_code, 403)

    def test_missing_token_403(self):
        r = self.client.get(f"/api/v1/correlate/{self.rid}")
        self.assertEqual(r.status_code, 403)

    def test_bad_id_rejected(self):
        r = self.client.get("/api/v1/correlate/..%2fetc?token=x")
        self.assertIn(r.status_code, (400, 404))

    def test_missing_report_404(self):
        r = self.client.get("/api/v1/correlate/9999_deadbeef?token=x")
        self.assertEqual(r.status_code, 404)

    def test_non_correlation_report_404s_even_with_valid_token(self):
        rid = self.tm._save_report(_sast_report(), "sast run")
        token = report_db.get_report(rid)["share_token"]
        r = self.client.get(f"/api/v1/correlate/{rid}?token={token}")
        self.assertEqual(r.status_code, 404)

    def test_bypasses_global_api_key(self):
        self.tm._TM_API_KEY = "master-secret"
        try:
            r = self.client.get(f"/api/v1/correlate/{self.rid}?token={self.token}")
            self.assertEqual(r.status_code, 200)
            # same route family, no token at all -> still gated normally
            r2 = self.client.get("/api/v1/correlate/sources")
            self.assertEqual(r2.status_code, 401)
        finally:
            self.tm._TM_API_KEY = ""

    def test_sibling_static_routes_are_not_exempted_from_auth(self):
        # The exemption matches this ONE view by endpoint identity -- it must
        # never accidentally cover a sibling /api/v1/correlate/* route.
        self.tm._TM_API_KEY = "master-secret"
        try:
            for path in ("/api/v1/correlate", "/api/v1/correlate/sources",
                        "/api/v1/correlate/trend", "/api/v1/correlate/sla"):
                r = self.client.get(path)
                self.assertEqual(r.status_code, 401, path)
        finally:
            self.tm._TM_API_KEY = ""


if __name__ == "__main__":
    unittest.main(verbosity=2)
