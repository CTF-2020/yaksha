"""confidence_decay.py — a correlated finding's confidence score decays the
longer it goes without being re-confirmed by a fresh correlation run, and
forces a "needs re-verification" flag once it has decayed past its verdict's
half-life.

Why: correlator/engine.py's ``confidence`` (0..1, how much the agreement
between sources corroborates the weakness) is computed once, at the moment a
correlation ran. Nothing since then has re-checked that the code the SAST
finding pointed at hasn't been rewritten, that the DAST endpoint hasn't been
retired, or that the production incident isn't long since remediated -- a
finding correlated six months ago still displays the SAME confidence today
as it did the day it was proven, even though the evidence backing it has had
no fresh eyes on it since. This module makes that staleness visible instead
of silent.

Age reuses verdict_tracking.py's ``verdict_since`` -- the timestamp the
finding's CURRENT verdict was last (re)confirmed by a correlation run,
already tracked for SLA aging (verdict_tracking.sla_status) -- rather than
inventing a second clock. Decay is deliberately orthogonal to the verdict
itself (same relationship engine.py's exploitability/business_impact scores
already have to verdict): a stale actively_exploited finding is still
actively_exploited until a human or a fresh correlation run says otherwise.
This module only says "the evidence for this is old enough that someone
should look again," it never changes the verdict on its own.

Half-lives are shorter for the verdicts that most need fresh eyes: a proven
incident or exploit is exactly the kind of finding whose environment changes
fastest (a patch ships, an endpoint gets pulled), so its confidence should
erode faster without reconfirmation than an already-uncertain design gap's.
"""
from __future__ import annotations

import time

import report_db
import suppressions
import verdict_tracking

_DAY = 86400.0
_EXCLUDED_METHODS = ("sast", "dast")

# Days for decayed_confidence to halve, by verdict. Shorter for the verdicts
# that most need fresh eyes -- see module docstring.
_HALF_LIFE_DAYS = {
    "actively_exploited": 14,
    "confirmed_exploitable": 30,
    "corroborated": 45,
    "design_gap": 90,
    "blind_spot": 90,
}
_DEFAULT_HALF_LIFE = 90


def decayed_confidence(confidence: float, verdict: str, age_days: float) -> float:
    """Exponential decay: halves every ``_HALF_LIFE_DAYS[verdict]`` days
    without a fresh correlation run touching this finding. Never negative
    age; never re-inflates confidence beyond its original value."""
    if age_days <= 0:
        return max(0.0, min(1.0, confidence))
    half_life = _HALF_LIFE_DAYS.get(verdict, _DEFAULT_HALF_LIFE)
    return max(0.0, min(1.0, confidence)) * (0.5 ** (age_days / half_life))


def needs_reverification(verdict: str, age_days: float) -> bool:
    """True once a finding has sat at its current verdict for a full half-life
    without being re-confirmed -- the "force periodic re-verification" trigger."""
    half_life = _HALF_LIFE_DAYS.get(verdict, _DEFAULT_HALF_LIFE)
    return age_days >= half_life


def annotate_rows(rows: list[dict], now: float | None = None) -> list[dict]:
    """Tag each row (needs ``fingerprint``/``verdict``/``confidence``) with
    ``age_days``/``decayed_confidence``/``needs_reverification`` in place.
    One bulk verdict_tracking query regardless of row count. A fingerprint
    verdict_tracking has never seen (not yet correlated even once) gets
    age_days=0 -- there's nothing stale about a finding with no history yet.
    """
    at = now if now is not None else time.time()
    since = verdict_tracking.since_map([r.get("fingerprint") or "" for r in rows])
    for row in rows:
        verdict = row.get("verdict") or ""
        confidence = float(row.get("confidence") or 0.0)
        vsince = since.get(row.get("fingerprint") or "")
        age_days = max(0.0, (at - vsince) / _DAY) if vsince else 0.0
        row["age_days"] = round(age_days, 1)
        row["decayed_confidence"] = round(decayed_confidence(confidence, verdict, age_days), 3)
        row["needs_reverification"] = needs_reverification(verdict, age_days)
    return rows


def _correlated_rows() -> list[dict]:
    """Every actionable (verdict-carrying, non-suppressed) finding across
    viewer-visible reports, deduplicated by fingerprint -- same source loop
    dashboard/service.py's _governance()/_verdicts() already use, extended
    to also carry ``confidence`` and a pointer back to its report."""
    from suppressions.engine import finding_fingerprint

    supps = suppressions.load_suppressions()
    seen: set[str] = set()
    rows: list[dict] = []
    for r in report_db.all_reports(limit=2000):
        if str(r.get("methodology", "")).lower() in _EXCLUDED_METHODS:
            continue
        annotated = suppressions.annotate_report(r, supps)
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            verdict = cat.get("verdict")
            if not verdict:
                continue
            fp = finding_fingerprint(cat)
            if fp in seen:
                continue
            seen.add(fp)
            rows.append({
                "fingerprint": fp, "verdict": verdict,
                "confidence": cat.get("confidence") or 0.0,
                "title": cat.get("name") or cat.get("title") or cat.get("id") or "Finding",
                "report_id": r.get("id"), "report_title": r.get("title") or r.get("id"),
            })
    return rows


def worklist(limit: int = 50) -> list[dict]:
    """Findings needing re-verification, oldest/most-decayed first -- the
    actionable "go look at these again" queue."""
    rows = annotate_rows(_correlated_rows())
    stale = [r for r in rows if r["needs_reverification"]]
    stale.sort(key=lambda r: (r["decayed_confidence"], -r["age_days"]))
    return stale[:max(1, min(limit, 500))]


def summary() -> dict:
    """Fleet-wide decay posture: how many correlated findings are being
    tracked, how many have decayed past their re-verification threshold, and
    the average confidence erosion across everything tracked."""
    rows = annotate_rows(_correlated_rows())
    tracked = [r for r in rows if r["age_days"] > 0]
    stale = [r for r in rows if r["needs_reverification"]]
    avg_erosion = 0.0
    if tracked:
        deltas = [max(0.0, r["confidence"] - r["decayed_confidence"]) for r in tracked]
        avg_erosion = round(sum(deltas) / len(deltas), 3)
    return {
        "total": len(rows),
        "tracked": len(tracked),
        "needs_reverification": len(stale),
        "avg_confidence_erosion": avg_erosion,
        "worklist": sorted(stale, key=lambda r: (r["decayed_confidence"], -r["age_days"]))[:10],
    }
