"""The Suppression record and its controlled vocabularies.

A Suppression is one operator decision to mute a finding. It is deliberately
report-independent: it matches findings by a stable *fingerprint* (or a broader
family/rule scope), so re-scanning a repo — which mints a new report id — does
not resurrect a risk someone already accepted.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field

# How broadly a suppression applies. Narrow -> wide:
#   finding — one specific finding fingerprint (a rule at a file-level locus)
#   family  — every finding of a weakness family (e.g. all "sql-injection")
#   rule    — every finding carrying a rule/category id (e.g. "WEB-A03-01")
SCOPES = ("finding", "family", "rule")

# The disposition recorded. All three mute the finding from the active posture;
# they differ in what they *mean*, which matters for audit and metrics.
#   accepted       — a real risk the business chose to accept (should expire)
#   false_positive — the tool is wrong; not a real risk here
#   wont_fix       — real but will not be remediated (deprecated component, etc.)
STATES = ("accepted", "false_positive", "wont_fix")

# The correlator's Verdict vocabulary (correlator/model.py), ordered most- to
# least-actionable. Duplicated here rather than imported so this package stays
# independent of the correlator — the string values are the actual contract.
# "actively_exploited" (a real production incident confirmed the weakness,
# not just lab-proven reachability) outranks every other verdict.
VERDICTS = ("actively_exploited", "confirmed_exploitable", "corroborated",
           "design_gap", "blind_spot")
VERDICT_RANK = {v: i for i, v in enumerate(VERDICTS)}

# Maximum lifetime (days) an "accepted" risk-acceptance may run before it must
# be re-justified, tightest for the verdicts that most need periodic review.
# Distinct from verdict_tracking.py's SLA windows (which answer "how fast
# must this be FIXED"): this answers "how long may fixing it be DEFERRED by
# an accepted-risk decision before someone has to look again" -- a longer,
# separate horizon, but the same shorter-for-more-actionable shape.
MAX_EXPIRY_DAYS = {
    "actively_exploited": 7,
    "confirmed_exploitable": 30,
    "corroborated": 90,
    "design_gap": 180,
    "blind_spot": 180,
}

_MAX_REASON = 2000
_MAX_FIELD = 400
_DAY = 86400.0


def cap_expiry_for_verdict(expires_at: float, verdict: str, created_at: float) -> float:
    """Force a maximum suppression lifetime for a verdict that needs periodic
    re-justification (see MAX_EXPIRY_DAYS). ``0`` (never expires) or a
    caller-requested date beyond the cap are both pulled in to the cap; a
    caller-requested expiry already inside the cap is left alone. A verdict
    with no configured cap (unverdicted / not yet correlated) is untouched.
    """
    max_days = MAX_EXPIRY_DAYS.get(verdict)
    if not max_days:
        return expires_at
    cap = created_at + max_days * _DAY
    if not expires_at or expires_at > cap:
        return cap
    return expires_at


def _clip(value, limit: int) -> str:
    return str(value or "").strip()[:limit]


@dataclass
class Suppression:
    """One risk-acceptance / suppression decision."""

    scope: str                     # one of SCOPES
    match: str                     # fingerprint | family slug | rule id (per scope)
    reason: str                    # required justification (audit trail)
    author: str                    # who made the decision (required)
    state: str = "accepted"        # one of STATES
    report_id: str = ""            # "" = applies across all reports; else scoped to one
    created_at: float = field(default_factory=lambda: time.time())
    expires_at: float = 0.0        # 0 = never expires; else epoch seconds
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    # A human-readable label captured at creation so the UI can show what was
    # suppressed even after the originating report is gone.
    label: str = ""
    # Optional guardrail for family/rule-scoped suppressions: "" (default)
    # applies unconditionally, same as before this field existed. Set to one
    # of VERDICTS to cap how actionable a correlated finding may be and still
    # get muted — e.g. max_verdict="design_gap" lets a broad "sql-injection"
    # family suppression mute design-gap/blind-spot findings but never a
    # confirmed_exploitable or corroborated one, even if a future scan
    # correlates a new instance of that family up to that verdict. Findings
    # without a verdict at all (plain SAST/manual reports) are unaffected.
    max_verdict: str = ""
    # The verdict the target finding actually carried at the moment this
    # suppression was created ("" when unknown -- a plain SAST/manual finding
    # never touched the correlator, or a broad family/rule suppression made
    # before any matching finding had been correlated). Captured for audit
    # ("this was accepted while confirmed_exploitable") and, together with
    # max_verdict, to enforce MAX_EXPIRY_DAYS in from_dict below -- a
    # suppression against a proven-exploitable finding cannot be granted
    # indefinitely, or longer than policy allows, even if the caller asks
    # for 0/no-expiry or a later date.
    verdict: str = ""

    def is_expired(self, now: float | None = None) -> bool:
        if not self.expires_at:
            return False
        return (now if now is not None else time.time()) >= self.expires_at

    def to_dict(self) -> dict:
        return asdict(self)

    def public_dict(self, now: float | None = None) -> dict:
        d = self.to_dict()
        d["expired"] = self.is_expired(now)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "Suppression":
        """Build from stored/user JSON, coercing and validating fields.

        Raises ValueError on a malformed record so the API returns a 400 and the
        store never persists garbage. Unknown keys are ignored.
        """
        scope = _clip(data.get("scope"), 32)
        if scope not in SCOPES:
            raise ValueError(f"scope must be one of {SCOPES}")
        match = _clip(data.get("match"), _MAX_FIELD)
        if not match:
            raise ValueError("match is required")
        reason = _clip(data.get("reason"), _MAX_REASON)
        if len(reason) < 3:
            raise ValueError("reason (justification) is required")
        author = _clip(data.get("author"), _MAX_FIELD)
        if not author:
            raise ValueError("author is required")
        state = _clip(data.get("state"), 32) or "accepted"
        if state not in STATES:
            raise ValueError(f"state must be one of {STATES}")

        max_verdict = _clip(data.get("max_verdict"), 32)
        if max_verdict and max_verdict not in VERDICTS:
            raise ValueError(f"max_verdict must be one of {VERDICTS}")

        verdict = _clip(data.get("verdict"), 32)
        if verdict and verdict not in VERDICTS:
            raise ValueError(f"verdict must be one of {VERDICTS}")

        expires_at = data.get("expires_at") or 0
        try:
            expires_at = float(expires_at)
        except (TypeError, ValueError):
            raise ValueError("expires_at must be epoch seconds")
        if expires_at < 0:
            raise ValueError("expires_at must not be negative")

        created_at = data.get("created_at")
        try:
            created_at = float(created_at) if created_at else time.time()
        except (TypeError, ValueError):
            created_at = time.time()

        # A suppression's own recorded verdict is the precise signal (the
        # exact finding it targeted); max_verdict is a fallback for
        # family/rule-scoped suppressions that declared a ceiling without a
        # single target finding to read a verdict off of. Only "accepted"
        # risk decisions get capped -- false_positive/wont_fix are
        # deliberately not time-bounded dispositions (see STATES above).
        if state == "accepted":
            expires_at = cap_expiry_for_verdict(
                expires_at, verdict or max_verdict, created_at)

        supp = cls(
            scope=scope, match=match, reason=reason, author=author, state=state,
            report_id=_clip(data.get("report_id"), _MAX_FIELD),
            created_at=created_at, expires_at=expires_at,
            label=_clip(data.get("label"), _MAX_FIELD),
            max_verdict=max_verdict, verdict=verdict,
        )
        if data.get("id"):
            supp.id = _clip(data.get("id"), 64)
        return supp
