"""Security posture dashboard: aggregate the whole tool into one overview."""
