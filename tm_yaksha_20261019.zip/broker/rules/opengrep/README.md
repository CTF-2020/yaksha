# Offline Opengrep ruleset

Drop `.yml`/`.yaml` Opengrep/Semgrep rule files in this directory to run the
multi-language SAST engines **fully offline** — no registry call, nothing about
a private repo leaves the network.

## How it is selected

`broker/config.resolve_opengrep_config()` picks the `--config` value with this
precedence:

1. `TM_BROKER_OPENGREP_RULES` — an explicit path or registry ref, if set.
2. **This directory** — used automatically as soon as it contains any rule file.
3. `"auto"` — the community ruleset from the registry (network).

So while this directory holds only this README, the default is unchanged
(`auto`) and online coverage is not reduced. The moment you add rule files here,
scans go offline against them. To point at a ruleset elsewhere instead:

```
export TM_BROKER_OPENGREP_RULES=/opt/rules/opengrep
```

The broker status API and `/broker` dashboard show which mode is active
(`rules_offline: true/false`) so the posture is always visible.

## Getting a local ruleset

- Vendor the [opengrep-rules](https://github.com/opengrep/opengrep-rules) repo
  (or the semgrep community rules) into this directory, or
- Author your own — the engines run whatever Opengrep-compatible YAML you place
  here. Keep licenses in mind: rules are read at runtime, not redistributed by
  this project, but if you commit third-party rule files their license applies
  to that copy.
```
