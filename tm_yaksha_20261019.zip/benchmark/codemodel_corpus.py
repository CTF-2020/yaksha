"""Labelled accuracy corpus for the code-derived threat-model engine.

Where :mod:`benchmark.corpus` scores the free-text offline reviewer, this scores
the *structural* engine (``codemodel.extractor.build_model``): given real source
files, does it recover the right attack surface (entry points), the right
dangerous operations reachable from it (sink families), which entry points are
authenticated, and which secrets are hardcoded?

Each case is a small but realistic multi-file app in one language, labelled with
ground truth an engineer would agree on by reading it. Cases deliberately embed
*distractors* — sinks inside strings/comments, query-param getters that look
like SQL calls, secrets read from the environment — so precision is measured,
not just recall. Language coverage spans the four the polyglot extractor added
(JS/TS, Go, Java) plus Python, so a regression in any one surfaces here.

Ground-truth schema per case::

    dict(
      name, lang,
      files = {rel_path: source},
      entry_points = {(METHOD, path), ...},         # expected attack surface
      authed = {(METHOD, path), ...},               # subset that must read authed
      sink_families = {(METHOD, path): {family,..}},# reachable weakness families
      hardcoded_secrets = int,                      # count that must read unmanaged
      managed_secrets = int,                        # count that must read managed
    )

`authed`, `sink_families`, `hardcoded_secrets` and `managed_secrets` are optional
per case; omit what a case does not exercise.
"""

# ── Python (Flask) ────────────────────────────────────────────────────────────
PY_FLASK = dict(
    name="flask-api", lang="python",
    files={
        "app.py": (
            "from flask import Flask, request, redirect\n"
            "import sqlite3, subprocess\n"
            "from auth import login_required\n"
            "app = Flask(__name__)\n"
            "API_KEY = 'sk-hardcoded-123'\n"
            "DB_PASSWORD = __import__('os').environ['DB_PASSWORD']\n"
            "\n"
            "@app.route('/search')\n"
            "def search():\n"
            "    q = request.args.get('q')\n"
            "    cur = sqlite3.connect('x').cursor()\n"
            "    cur.execute('SELECT * FROM t WHERE n = ' + q)\n"
            "    return 'ok'\n"
            "\n"
            "@app.route('/admin/exec', methods=['POST'])\n"
            "@login_required\n"
            "def run():\n"
            "    return do_run()\n"
            "\n"
            "def do_run():\n"
            "    subprocess.run(request.form['cmd'], shell=True)\n"
            "    return 'ran'\n"
        ),
        "auth.py": (
            "def login_required(f):\n"
            "    return f\n"
        ),
    },
    entry_points={("GET", "/search"), ("POST", "/admin/exec")},
    authed={("POST", "/admin/exec")},
    sink_families={
        ("GET", "/search"): {"sql-injection"},
        ("POST", "/admin/exec"): {"command-injection"},   # via do_run() call hop
    },
    hardcoded_secrets=1,
    managed_secrets=1,
)

# ── JavaScript (Express) ──────────────────────────────────────────────────────
JS_EXPRESS = dict(
    name="express-api", lang="javascript",
    files={
        "server.js": (
            "const express = require('express');\n"
            "const { execSync } = require('child_process');\n"
            "const { Pool } = require('pg');\n"
            "const helmet = require('helmet');\n"
            "const app = express();\n"
            "app.use(helmet());\n"
            "\n"
            "// app.get('/decoy', h) — a comment, must NOT be an entry point\n"
            "const s = \"app.post('/string-decoy', h)\";\n"
            "\n"
            "app.get('/products/:id', (req, res) => {\n"
            "  pool.query(`SELECT * FROM p WHERE id = ${req.params.id}`);\n"
            "  res.send('ok');\n"
            "});\n"
            "\n"
            "app.post('/jobs', requireAuth, createJob);\n"
        ),
        "jobs.js": (
            "const { execSync } = require('child_process');\n"
            "function createJob(req, res) {\n"
            "  execSync('run ' + req.body.name);\n"
            "  res.send('queued');\n"
            "}\n"
            "const token = 'ghp_hardcoded_value_here';\n"
        ),
    },
    entry_points={("GET", "/products/:id"), ("POST", "/jobs")},
    authed={("POST", "/jobs")},
    sink_families={
        ("GET", "/products/:id"): {"sql-injection"},
        ("POST", "/jobs"): {"command-injection"},
    },
    hardcoded_secrets=1,
)

# ── TypeScript (NestJS) ───────────────────────────────────────────────────────
TS_NEST = dict(
    name="nest-api", lang="typescript",
    files={
        "cats.controller.ts": (
            "import { Controller, Get, Post, UseGuards } from '@nestjs/common';\n"
            "\n"
            "@Controller('cats')\n"
            "export class CatsController {\n"
            "  @UseGuards(AuthGuard)\n"
            "  @Get(':id')\n"
            "  findOne(id: string): string {\n"
            "    return this.svc.findOne(id);\n"
            "  }\n"
            "\n"
            "  @Post()\n"
            "  create(body: any): string {\n"
            "    return 'created';\n"
            "  }\n"
            "}\n"
        ),
    },
    entry_points={("GET", "/cats/:id"), ("POST", "/cats")},
    authed={("GET", "/cats/:id")},
)

# ── Go (Gin) ──────────────────────────────────────────────────────────────────
GO_GIN = dict(
    name="gin-api", lang="go",
    files={
        "main.go": (
            "package main\n"
            "\n"
            "import (\n"
            '    "database/sql"\n'
            '    "os/exec"\n'
            '    "github.com/gin-gonic/gin"\n'
            '    _ "github.com/lib/pq"\n'
            ")\n"
            "\n"
            "func main() {\n"
            "    r := gin.Default()\n"
            "    r.Use(AuthMiddleware())\n"
            '    r.GET("/items/:id", getItem)\n'
            '    r.POST("/run", func(c *gin.Context) {\n'
            '        exec.Command("sh", "-c", c.PostForm("cmd"))\n'
            "    })\n"
            "}\n"
            "\n"
            "func getItem(c *gin.Context) {\n"
            '    id := c.Query("id")\n'
            '    db.Query("SELECT * FROM items WHERE id = " + id)\n'
            "}\n"
        ),
    },
    entry_points={("GET", "/items/:id"), ("POST", "/run")},
    # r.Use(AuthMiddleware()) is a global auth control for this batch
    authed={("GET", "/items/:id"), ("POST", "/run")},
    sink_families={
        ("GET", "/items/:id"): {"sql-injection"},
        ("POST", "/run"): {"command-injection"},
    },
)

# ── Java (Spring) ─────────────────────────────────────────────────────────────
JAVA_SPRING = dict(
    name="spring-api", lang="java",
    files={
        "OrderController.java": (
            "package com.example;\n"
            "import java.sql.Statement;\n"
            "import org.springframework.web.bind.annotation.*;\n"
            "import org.springframework.security.access.prepost.PreAuthorize;\n"
            "\n"
            "@RestController\n"
            '@RequestMapping("/api/orders")\n'
            "public class OrderController {\n"
            '    private String apiSecret = "hardcoded-secret-xyz";\n'
            "\n"
            '    @GetMapping("/{id}")\n'
            "    public String getOrder(@PathVariable String id) throws Exception {\n"
            "        Statement st = conn.createStatement();\n"
            '        return st.executeQuery("SELECT * FROM o WHERE id = " + id).toString();\n'
            "    }\n"
            "\n"
            '    @PreAuthorize("hasRole(\'ADMIN\')")\n'
            '    @PostMapping("/run")\n'
            "    public String run(@RequestParam String cmd) throws Exception {\n"
            "        Runtime.getRuntime().exec(cmd);\n"
            '        return "ok";\n'
            "    }\n"
            "}\n"
        ),
    },
    entry_points={("GET", "/api/orders/{id}"), ("POST", "/api/orders/run")},
    authed={("POST", "/api/orders/run")},
    sink_families={
        ("GET", "/api/orders/{id}"): {"sql-injection"},
        ("POST", "/api/orders/run"): {"command-injection"},
    },
    hardcoded_secrets=1,
)

# ── A deliberately clean design (precision guard) ─────────────────────────────
# A well-built handler: parameterized query, auth, env-sourced secret. The engine
# should find the entry point and NO injection sinks (query is a client call with
# a bound param, not string-concatenated), and read the entry point as authed.
GO_CLEAN = dict(
    name="gin-clean", lang="go",
    files={
        "main.go": (
            "package main\n"
            'import "github.com/gin-gonic/gin"\n'
            "\n"
            "func main() {\n"
            "    r := gin.Default()\n"
            "    r.Use(RequireAuth())\n"
            '    r.GET("/me", profile)\n'
            "}\n"
            "\n"
            "func profile(c *gin.Context) {\n"
            '    id := c.GetString("uid")\n'
            '    row := db.QueryRow("SELECT name FROM u WHERE id = $1", id)\n'
            "    c.JSON(200, row)\n"
            "}\n"
        ),
    },
    entry_points={("GET", "/me")},
    authed={("GET", "/me")},
    # QueryRow is a real sink call; it fires but is NOT tainted (bound param $1).
    # The corpus scores families reachable, so sql-injection IS present as a
    # family — but the tainted flag must be False. Checked separately below.
    sink_families={("GET", "/me"): {"sql-injection"}},
    clean_untainted=True,   # every reachable sink must have tainted == False
)


CASES = [PY_FLASK, JS_EXPRESS, TS_NEST, GO_GIN, JAVA_SPRING, GO_CLEAN]
