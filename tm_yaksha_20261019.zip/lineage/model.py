"""lineage/model.py — data model for design-to-code threat lineage.

A :class:`ThreatLineage` is one underlying risk, tracked by stable identity
across every report that ever touched it, regardless of methodology or
report id. Its ``status`` is a small state machine over which *kinds* of
evidence have observed it:

    predicted    -- seen only in a design/threat-model report so far
    realized     -- was predicted, and code or runtime evidence later matched it
    confirmed    -- has BOTH code and runtime evidence (the correlator's own bar
                    for "confirmed exploitable")
    blind_spot   -- code/runtime evidence exists with no prior design prediction
                    (found in code first — never modeled)

"realized" is the literal answer to "this design threat became this code
finding": it is the transition a lineage makes the first time a code/runtime
observation matches a threat that started life as a design prediction.
"""
from __future__ import annotations

from dataclasses import dataclass, field

STATUSES = ("predicted", "realized", "confirmed", "blind_spot")


@dataclass
class LineageEvent:
    """One observation of a threat, in one saved report, at one point in time."""

    at: str                 # ISO8601
    report_id: str
    report_title: str
    kind: str                # "design" | "code" | "runtime"
    methodology: str
    severity: str
    title: str
    locus_label: str


@dataclass
class ThreatLineage:
    """One underlying risk, tracked across every report that has touched it."""

    id: str                  # stable fingerprint: sha1(family + founding locus)[:16]
    family: str
    family_title: str
    status: str
    founding_locus: list = field(default_factory=list)   # frozen at creation
    kinds_seen: list = field(default_factory=list)        # sorted unique: design/code/runtime
    first_seen_at: str = ""
    first_seen_report_id: str = ""
    first_seen_report_title: str = ""
    first_seen_kind: str = ""
    updated_at: str = ""
    event_count: int = 0
    events: list = field(default_factory=list)   # list[LineageEvent], populated on demand
