"""Token usage / cost ledger for every Claude API call TM makes.

Every TM feature that calls Claude (threat-model analysis, diagram
generation, codemodel chain reasoning) goes through claude_client.py's
call_claude/call_claude_cached. Until now that usage object was read once
and discarded -- there was no record anywhere of how many tokens TM itself
spends, by which feature, or at what cost. claude_client.py logs one row
here per successful call (best-effort -- a logging failure must never break
an already-successful analysis); this module aggregates it for the Overview
dashboard and anything else that wants spend-by-caller.

Stdlib sqlite3 only, same connection-per-call + WAL pattern as
report_db.py / ownership.py / verdict_tracking.py.
"""
from __future__ import annotations

import csv
import io
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

DB_PATH = Path.home() / ".tm_llm_usage.db"

_init_lock = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS llm_calls (
    id                           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts                           REAL NOT NULL,
    caller                       TEXT NOT NULL DEFAULT '',
    model                        TEXT NOT NULL DEFAULT '',
    input_tokens                 INTEGER NOT NULL DEFAULT 0,
    output_tokens                INTEGER NOT NULL DEFAULT 0,
    cache_creation_input_tokens  INTEGER NOT NULL DEFAULT 0,
    cache_read_input_tokens      INTEGER NOT NULL DEFAULT 0,
    cost_usd                     REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_llm_calls_ts     ON llm_calls(ts);
CREATE INDEX IF NOT EXISTS ix_llm_calls_caller ON llm_calls(caller);
CREATE INDEX IF NOT EXISTS ix_llm_calls_model  ON llm_calls(model);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)


# ── Write path ──────────────────────────────────────────────────────────────
def record_call(*, model: str, caller: str, input_tokens: int, output_tokens: int,
                 cache_creation_input_tokens: int = 0, cache_read_input_tokens: int = 0,
                 cost_usd: float = 0.0, ts: float | None = None) -> None:
    """Log one successful Claude API call. Caller is a short dotted tag
    identifying the feature that made the call (e.g. "analyzer.owasp",
    "diagram.dfd", "codemodel.chain_reasoning") -- free text, not a foreign
    key, so a new call site never needs a schema change to be attributable."""
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT INTO llm_calls (ts, caller, model, input_tokens, output_tokens, "
            "cache_creation_input_tokens, cache_read_input_tokens, cost_usd) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (ts if ts is not None else time.time(), caller or "", model or "",
             int(input_tokens or 0), int(output_tokens or 0),
             int(cache_creation_input_tokens or 0), int(cache_read_input_tokens or 0),
             float(cost_usd or 0.0)),
        )


# ── Read path ───────────────────────────────────────────────────────────────
def call_count() -> int:
    with closing(_connect()) as conn:
        return int(conn.execute("SELECT COUNT(*) FROM llm_calls").fetchone()[0])


def recent(limit: int = 20) -> list[dict]:
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT * FROM llm_calls ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(r) for r in rows]


def summary(since: float | None = None) -> dict:
    """Aggregate spend/tokens, overall and broken down by caller and model.

    cache_hit_rate is cache_read_input_tokens / (cache_read_input_tokens +
    input_tokens) -- the share of *cacheable* prompt tokens that were
    actually served from cache rather than billed at full input price.
    """
    where = "WHERE ts >= ?" if since is not None else ""
    params = (since,) if since is not None else ()
    with closing(_connect()) as conn:
        row = conn.execute(f"""
            SELECT COUNT(*) AS calls, COALESCE(SUM(cost_usd),0) AS cost_usd,
                   COALESCE(SUM(input_tokens),0) AS input_tokens,
                   COALESCE(SUM(output_tokens),0) AS output_tokens,
                   COALESCE(SUM(cache_creation_input_tokens),0) AS cache_creation_tokens,
                   COALESCE(SUM(cache_read_input_tokens),0) AS cache_read_tokens
            FROM llm_calls {where}
        """, params).fetchone()
        by_caller = [dict(r) for r in conn.execute(f"""
            SELECT caller, COUNT(*) AS calls, COALESCE(SUM(cost_usd),0) AS cost_usd,
                   COALESCE(SUM(input_tokens),0) AS input_tokens,
                   COALESCE(SUM(output_tokens),0) AS output_tokens
            FROM llm_calls {where}
            GROUP BY caller ORDER BY cost_usd DESC
        """, params).fetchall()]
        by_model = [dict(r) for r in conn.execute(f"""
            SELECT model, COUNT(*) AS calls, COALESCE(SUM(cost_usd),0) AS cost_usd
            FROM llm_calls {where}
            GROUP BY model ORDER BY cost_usd DESC
        """, params).fetchall()]

    cache_read = int(row["cache_read_tokens"] or 0)
    base_input = int(row["input_tokens"] or 0)
    denom = cache_read + base_input
    cache_hit_rate = (cache_read / denom) if denom else 0.0

    return {
        "calls": int(row["calls"] or 0),
        "cost_usd": round(float(row["cost_usd"] or 0.0), 4),
        "input_tokens": base_input,
        "output_tokens": int(row["output_tokens"] or 0),
        "cache_creation_tokens": int(row["cache_creation_tokens"] or 0),
        "cache_read_tokens": cache_read,
        "cache_hit_rate": round(cache_hit_rate, 4),
        "by_caller": by_caller,
        "by_model": by_model,
    }


_CSV_COLUMNS = ("ts", "caller", "model", "input_tokens", "output_tokens",
                "cache_creation_input_tokens", "cache_read_input_tokens", "cost_usd")


def to_csv(rows: list[dict]) -> str:
    """Render call-log rows (recent()'s shape) as CSV text."""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=_CSV_COLUMNS, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return buf.getvalue()


if __name__ == "__main__":
    import sys

    def _main(argv: list[str]) -> int:
        init()
        if not argv or argv[0] == "summary":
            s = summary()
            print(f"calls={s['calls']} cost_usd={s['cost_usd']:.4f} "
                  f"input_tokens={s['input_tokens']} output_tokens={s['output_tokens']} "
                  f"cache_hit_rate={s['cache_hit_rate']:.2%}")
            for r in s["by_caller"]:
                print(f"  {r['caller'] or '(untagged)':30s} calls={r['calls']:<5d} "
                      f"cost_usd={r['cost_usd']:.4f}")
            return 0
        if argv[0] == "recent":
            limit = int(argv[1]) if len(argv) > 1 else 20
            for r in recent(limit=limit):
                print(f"{r['ts']:.0f}  {r['caller'] or '(untagged)':30s} {r['model']:24s} "
                      f"in={r['input_tokens']:<7d} out={r['output_tokens']:<7d} "
                      f"${r['cost_usd']:.4f}")
            return 0
        print(__doc__)
        return 1

    raise SystemExit(_main(sys.argv[1:]))
