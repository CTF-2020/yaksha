"""Tests for guard.diff — unified-diff parsing into per-file added-line sets."""
from __future__ import annotations

import unittest

from guard import diff as guard_diff

_SINGLE_HUNK = """\
diff --git a/app.py b/app.py
index 1111111..2222222 100644
--- a/app.py
+++ b/app.py
@@ -10,3 +10,5 @@ def handler():
 def handler():
     x = 1
-    return x
+    y = os.system("sh " + x)
+    return y
+    # trailing comment
"""

_TWO_FILES = """\
diff --git a/a.py b/a.py
index 1111111..2222222 100644
--- a/a.py
+++ b/a.py
@@ -1,1 +1,2 @@
 import os
+os.system("new")
diff --git a/b.py b/b.py
index 1111111..2222222 100644
--- a/b.py
+++ b/b.py
@@ -5,1 +5,2 @@
 x = 1
+y = 2
"""

_NEW_FILE = """\
diff --git a/new.py b/new.py
new file mode 100644
index 0000000..1111111
--- /dev/null
+++ b/new.py
@@ -0,0 +1,3 @@
+import os
+os.system("hi")
+print("done")
"""

_DELETED_FILE = """\
diff --git a/gone.py b/gone.py
deleted file mode 100644
index 1111111..0000000
--- a/gone.py
+++ /dev/null
@@ -1,2 +0,0 @@
-import os
-os.system("bye")
"""

_MULTIPLE_HUNKS = """\
diff --git a/m.py b/m.py
index 1111111..2222222 100644
--- a/m.py
+++ b/m.py
@@ -1,2 +1,3 @@
 line1
+added_early
 line2
@@ -20,2 +21,3 @@
 line20
+added_late
 line21
"""

_NO_NEWLINE_MARKER = """\
diff --git a/n.py b/n.py
index 1111111..2222222 100644
--- a/n.py
+++ b/n.py
@@ -1,1 +1,1 @@
-old
\\ No newline at end of file
+new
\\ No newline at end of file
"""


class TestParseAddedLines(unittest.TestCase):
    def test_added_lines_are_captured_with_correct_numbers(self):
        added = guard_diff.parse_added_lines(_SINGLE_HUNK)
        # hunk starts new-side at line 10: 10=context(def), 11=context(x=1),
        # 12=+y=os.system(...), 13=+return y, 14=+# trailing comment
        self.assertEqual(added["app.py"], {12, 13, 14})

    def test_removal_only_diff_yields_no_added_lines(self):
        removal_only = (
            "diff --git a/r.py b/r.py\n"
            "index 1111111..2222222 100644\n"
            "--- a/r.py\n"
            "+++ b/r.py\n"
            "@@ -1,2 +1,1 @@\n"
            " keep\n"
            "-drop\n"
        )
        added = guard_diff.parse_added_lines(removal_only)
        self.assertEqual(added["r.py"], set())

    def test_multiple_files_are_tracked_independently(self):
        added = guard_diff.parse_added_lines(_TWO_FILES)
        self.assertEqual(added["a.py"], {2})
        self.assertEqual(added["b.py"], {6})

    def test_new_file_all_lines_added(self):
        added = guard_diff.parse_added_lines(_NEW_FILE)
        self.assertEqual(added["new.py"], {1, 2, 3})

    def test_deleted_file_has_no_added_lines(self):
        added = guard_diff.parse_added_lines(_DELETED_FILE)
        # /dev/null on the +++ side means no "+++ b/..." match -> no entry at all
        self.assertEqual(added, {})

    def test_multiple_hunks_in_same_file_both_captured(self):
        added = guard_diff.parse_added_lines(_MULTIPLE_HUNKS)
        self.assertEqual(added["m.py"], {2, 22})

    def test_no_newline_marker_does_not_desync_line_numbers(self):
        added = guard_diff.parse_added_lines(_NO_NEWLINE_MARKER)
        self.assertEqual(added["n.py"], {1})

    def test_empty_diff_yields_empty_map(self):
        self.assertEqual(guard_diff.parse_added_lines(""), {})


if __name__ == "__main__":
    unittest.main()
