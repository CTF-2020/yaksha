"""Tests for the Claude API token-usage/cost ledger (llm_usage_db.py).

Isolated onto a temp SQLite store, same pattern as test_ownership.py /
test_settings_db.py -- writing through the real one would pollute
~/.tm_llm_usage.db.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import llm_usage_db


class LlmUsageDbTests(unittest.TestCase):
    def setUp(self):
        self._orig_path = llm_usage_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        llm_usage_db.DB_PATH = Path(self._td.name) / "usage.db"
        llm_usage_db.init()

    def _restore(self):
        llm_usage_db.DB_PATH = self._orig_path

    def test_empty_summary(self):
        s = llm_usage_db.summary()
        self.assertEqual(s["calls"], 0)
        self.assertEqual(s["cost_usd"], 0.0)
        self.assertEqual(s["cache_hit_rate"], 0.0)
        self.assertEqual(s["by_caller"], [])
        self.assertEqual(s["by_model"], [])

    def test_record_call_roundtrip(self):
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="analyzer.owasp",
            input_tokens=1000, output_tokens=500,
            cache_creation_input_tokens=0, cache_read_input_tokens=0,
            cost_usd=0.0105,
        )
        self.assertEqual(llm_usage_db.call_count(), 1)
        s = llm_usage_db.summary()
        self.assertEqual(s["calls"], 1)
        self.assertAlmostEqual(s["cost_usd"], 0.0105)
        self.assertEqual(s["input_tokens"], 1000)
        self.assertEqual(s["output_tokens"], 500)

    def test_summary_aggregates_across_callers_and_models(self):
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="analyzer.owasp",
            input_tokens=100, output_tokens=50, cost_usd=0.001,
        )
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="analyzer.owasp",
            input_tokens=200, output_tokens=100, cost_usd=0.002,
        )
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="diagram.dfd",
            input_tokens=50, output_tokens=25, cost_usd=0.0005,
        )
        s = llm_usage_db.summary()
        self.assertEqual(s["calls"], 3)
        self.assertAlmostEqual(s["cost_usd"], 0.0035)

        by_caller = {r["caller"]: r for r in s["by_caller"]}
        self.assertEqual(by_caller["analyzer.owasp"]["calls"], 2)
        self.assertEqual(by_caller["diagram.dfd"]["calls"], 1)

        by_model = {r["model"]: r for r in s["by_model"]}
        self.assertEqual(by_model["claude-sonnet-4-6"]["calls"], 3)

    def test_cache_hit_rate(self):
        # 300 tokens served from cache, 100 billed at full input price ->
        # 75% of cacheable input came from cache.
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="analyzer.owasp",
            input_tokens=100, output_tokens=10,
            cache_creation_input_tokens=0, cache_read_input_tokens=300,
            cost_usd=0.001,
        )
        s = llm_usage_db.summary()
        self.assertAlmostEqual(s["cache_hit_rate"], 0.75)

    def test_summary_since_filters_by_timestamp(self):
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="analyzer.owasp",
            input_tokens=100, output_tokens=10, cost_usd=0.001, ts=1000.0,
        )
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="analyzer.owasp",
            input_tokens=100, output_tokens=10, cost_usd=0.001, ts=2000.0,
        )
        self.assertEqual(llm_usage_db.summary()["calls"], 2)
        self.assertEqual(llm_usage_db.summary(since=1500.0)["calls"], 1)

    def test_recent_orders_newest_first(self):
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="a", input_tokens=1, output_tokens=1,
            cost_usd=0.0, ts=1.0,
        )
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="b", input_tokens=1, output_tokens=1,
            cost_usd=0.0, ts=2.0,
        )
        rows = llm_usage_db.recent(limit=10)
        self.assertEqual([r["caller"] for r in rows], ["b", "a"])

    def test_record_call_defaults_missing_cache_fields_to_zero(self):
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="analyzer.owasp",
            input_tokens=10, output_tokens=5, cost_usd=0.0,
        )
        row = llm_usage_db.recent(limit=1)[0]
        self.assertEqual(row["cache_creation_input_tokens"], 0)
        self.assertEqual(row["cache_read_input_tokens"], 0)

    def test_to_csv_header_and_row(self):
        llm_usage_db.record_call(
            model="claude-sonnet-4-6", caller="analyzer.owasp",
            input_tokens=10, output_tokens=5, cost_usd=0.001, ts=1000.0,
        )
        csv_text = llm_usage_db.to_csv(llm_usage_db.recent())
        lines = csv_text.strip().splitlines()
        self.assertEqual(lines[0], "ts,caller,model,input_tokens,output_tokens,"
                                    "cache_creation_input_tokens,cache_read_input_tokens,cost_usd")
        self.assertIn("analyzer.owasp", lines[1])
        self.assertIn("claude-sonnet-4-6", lines[1])

    def test_to_csv_empty_rows_is_header_only(self):
        csv_text = llm_usage_db.to_csv([])
        self.assertEqual(csv_text.strip().count("\n"), 0)


class LlmUsageApiTests(unittest.TestCase):
    """Read-only /api/v1/llm-usage routes. No CSRF needed -- GET requests
    bypass the app's CSRF gate entirely (app.py::_auth_and_csrf)."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orig_path = llm_usage_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        llm_usage_db.DB_PATH = Path(self._td.name) / "usage.db"
        llm_usage_db.init()

    def _restore(self):
        llm_usage_db.DB_PATH = self._orig_path

    def test_summary_endpoint_empty(self):
        resp = self.client.get("/api/v1/llm-usage")
        self.assertEqual(resp.status_code, 200)
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["calls"], 0)

    def test_summary_endpoint_reflects_recorded_calls(self):
        llm_usage_db.record_call(model="claude-sonnet-4-6", caller="analyzer.owasp",
                                  input_tokens=100, output_tokens=50, cost_usd=0.001)
        d = self.client.get("/api/v1/llm-usage").get_json()
        self.assertEqual(d["calls"], 1)
        self.assertEqual(d["by_caller"][0]["caller"], "analyzer.owasp")

    def test_summary_endpoint_since_filter(self):
        llm_usage_db.record_call(model="claude-sonnet-4-6", caller="a",
                                  input_tokens=1, output_tokens=1, cost_usd=0.0, ts=1000.0)
        llm_usage_db.record_call(model="claude-sonnet-4-6", caller="b",
                                  input_tokens=1, output_tokens=1, cost_usd=0.0, ts=2000.0)
        d = self.client.get("/api/v1/llm-usage?since=1500").get_json()
        self.assertEqual(d["calls"], 1)

    def test_summary_endpoint_ignores_malformed_since(self):
        llm_usage_db.record_call(model="claude-sonnet-4-6", caller="a",
                                  input_tokens=1, output_tokens=1, cost_usd=0.0)
        d = self.client.get("/api/v1/llm-usage?since=not-a-number").get_json()
        self.assertEqual(d["calls"], 1)

    def test_recent_endpoint(self):
        llm_usage_db.record_call(model="claude-sonnet-4-6", caller="a",
                                  input_tokens=1, output_tokens=1, cost_usd=0.0, ts=1.0)
        llm_usage_db.record_call(model="claude-sonnet-4-6", caller="b",
                                  input_tokens=1, output_tokens=1, cost_usd=0.0, ts=2.0)
        d = self.client.get("/api/v1/llm-usage/recent?limit=1").get_json()
        self.assertTrue(d["success"])
        self.assertEqual(len(d["calls"]), 1)
        self.assertEqual(d["calls"][0]["caller"], "b")

    def test_recent_endpoint_clamps_limit(self):
        d = self.client.get("/api/v1/llm-usage/recent?limit=99999").get_json()
        self.assertTrue(d["success"])  # clamped server-side, not rejected

    def test_export_csv_endpoint(self):
        llm_usage_db.record_call(model="claude-sonnet-4-6", caller="analyzer.owasp",
                                  input_tokens=10, output_tokens=5, cost_usd=0.001)
        resp = self.client.get("/api/v1/llm-usage/export.csv")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.mimetype, "text/csv")
        self.assertIn("analyzer.owasp", resp.get_data(as_text=True))

    def test_get_requires_no_csrf_token(self):
        # Sanity check documenting the GET-bypasses-CSRF behavior this
        # blueprint relies on instead of re-implementing a token check.
        resp = self.client.get("/api/v1/llm-usage")
        self.assertEqual(resp.status_code, 200)


if __name__ == "__main__":
    unittest.main()
