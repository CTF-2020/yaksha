"""Tests for the opt-in session-login page gate (app.py's _auth_and_csrf).

A login system that produces a session but nothing checks it is a false sense
of security (see api/login.py's own comment). This gate is OFF by default —
_REQUIRE_LOGIN — so a personal/local install is never locked out by an
upgrade; these tests flip it on for the duration of each test and restore it
afterward.

Run:  python -m unittest test_login_gate
"""
from __future__ import annotations

import unittest


def _malicious_report() -> dict:
    return {"id": "rpt_login_gate", "title": "R", "methodology": "owasp",
            "overall_risk": "Low", "analyzed_at": "2026-07-31T00:00:00Z",
            "categories": []}


class LoginGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orig_require_login = self.tm._REQUIRE_LOGIN

    def tearDown(self):
        self.tm._REQUIRE_LOGIN = self._orig_require_login

    def _enable_gate(self):
        self.tm._REQUIRE_LOGIN = True

    # ── off by default ──────────────────────────────────────────────────────
    def test_gate_off_by_default_page_accessible_without_session(self):
        self.assertFalse(self._orig_require_login)
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)

    def test_gate_off_by_default_api_accessible_without_session(self):
        self.assertFalse(self._orig_require_login)
        r = self.client.get("/api/v1/dashboard")
        self.assertEqual(r.status_code, 200)

    # ── gate on: unauthenticated ─────────────────────────────────────────────
    def test_page_request_redirects_to_login_when_gate_on(self):
        self._enable_gate()
        r = self.client.get("/", follow_redirects=False)
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].startswith("/login"))

    def test_next_param_preserves_original_path(self):
        self._enable_gate()
        r = self.client.get("/broker", follow_redirects=False)
        self.assertEqual(r.status_code, 302)
        self.assertIn("next=%2Fbroker", r.headers["Location"])

    def test_api_request_returns_401_json_when_gate_on(self):
        self._enable_gate()
        r = self.client.get("/api/v1/dashboard")
        self.assertEqual(r.status_code, 401)
        self.assertFalse(r.get_json()["success"])

    # ── exemptions that must survive the gate ───────────────────────────────
    def test_login_page_itself_always_reachable(self):
        self._enable_gate()
        r = self.client.get("/login")
        self.assertEqual(r.status_code, 200)

    def test_logout_always_reachable(self):
        self._enable_gate()
        r = self.client.get("/logout", follow_redirects=False)
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/login"))

    def test_health_check_exempt(self):
        self._enable_gate()
        r = self.client.get("/health")
        self.assertEqual(r.status_code, 200)

    def test_csrf_token_endpoint_exempt(self):
        self._enable_gate()
        r = self.client.get("/api/csrf-token")
        self.assertEqual(r.status_code, 200)

    def test_shared_report_link_exempt(self):
        rid = self.tm._save_report(_malicious_report(), "Gate test report")
        try:
            token = self.tm.report_db.get_report(rid)["share_token"]
            self._enable_gate()
            r = self.client.get(f"/api/v1/reports/{rid}/shared?token={token}")
            self.assertEqual(r.status_code, 200)
        finally:
            self.tm._REQUIRE_LOGIN = False
            self.client.delete(f"/api/v1/reports/{rid}",
                               headers={"X-CSRF-Token": self.tm._CSRF_TOKEN})

    def test_valid_api_key_bypasses_login_gate(self):
        self._enable_gate()
        self.tm._TM_API_KEY = "master-secret"
        try:
            r = self.client.get("/api/v1/dashboard",
                                headers={"X-API-Key": "master-secret"})
            self.assertEqual(r.status_code, 200)
        finally:
            self.tm._TM_API_KEY = ""

    # ── gate on: authenticated ───────────────────────────────────────────────
    def test_authenticated_session_passes_through(self):
        self._enable_gate()
        with self.client.session_transaction() as sess:
            sess["user_email"] = "carol@example.com"
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        api = self.client.get("/api/v1/dashboard")
        self.assertEqual(api.status_code, 200)


if __name__ == "__main__":
    unittest.main(verbosity=2)
