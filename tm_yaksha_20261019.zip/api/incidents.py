"""Production-incident ingestion API.

  POST /api/v1/incidents   record one or more production incidents as a
                            report (methodology="incident"); the correlator
                            treats each as SourceKind.INCIDENT and assigns
                            Verdict.ACTIVELY_EXPLOITED — the strongest verdict
                            it can reach — see incidents.py and
                            correlator/engine.py.
                            body: {title?, entries: [{weakness, locus,
                            source?, severity?, description?, detected_at?,
                            cwe?}, ...]}
  GET  /api/v1/incidents   list saved incident reports, newest first.

Writes go through the same CSRF/auth gate as the rest of the app (enforced in
the app's before_request), and through the normal ``_save_report`` pipeline
(secret scrubbing, rule enrichment, verdict-transition tracking) — an
incident report is not a special case anywhere downstream of this endpoint.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

import incidents
import report_db

bp = Blueprint("incidents_api", __name__, url_prefix="/api/v1/incidents")


@bp.get("")
def list_all():
    reports = report_db.list_reports(limit=100, methodology="incident")
    return jsonify({"success": True, "count": len(reports), "incidents": reports})


@bp.post("")
def create():
    body = request.get_json(silent=True) or {}
    entries = body.get("entries")
    title = str(body.get("title", "")).strip()
    try:
        report = incidents.build_incident_report(entries, title)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400

    import app as tm_app  # lazy import to avoid a circular import at module load
    report_id = tm_app._save_report(report, report["title"])
    return jsonify({
        "success": True,
        "report_id": report_id,
        "title": report["title"],
        "overall_risk": report.get("overall_risk"),
        "incident_count": len(report["categories"]),
    }), 201
