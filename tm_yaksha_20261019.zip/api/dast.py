"""DAST scanner API + dashboard page.

Routes (CSRF + optional TM_API_KEY apply via the app's global before_request):
  GET    /api/v1/dast                       scanner status / engine info
  GET    /api/v1/dast/targets              list registered targets
  POST   /api/v1/dast/targets              register a target {name,url,scope?,auth_header?}
  DELETE /api/v1/dast/targets/<id>         remove a target
  POST   /api/v1/dast/targets/<id>/scan    trigger a scan {severity?} -> {job_id}
  GET    /api/v1/dast/jobs                 list scan jobs
  GET    /api/v1/dast/jobs/<id>            poll one job
  GET    /api/v1/dast/jobs/<id>/events     SSE progress stream
  POST   /api/v1/dast/import               push a finished report (X-Dast-Token)

  GET    /dast-scanner                      dashboard UI (separate, un-prefixed bp)

Scans only ever run against *registered* targets picked by id, so a dashboard
user can never coerce the server into probing an arbitrary URL. Targets are the
authorization boundary: registering one asserts you are allowed to scan it.
"""
from __future__ import annotations

import json
import secrets
import time

from flask import Blueprint, Response, jsonify, render_template, request

import app as tm_app
from dast import config, get_service, github

bp = Blueprint("dast_api", __name__, url_prefix="/api/v1/dast")
page_bp = Blueprint("dast_page", __name__)


@bp.get("")
def status():
    return jsonify({
        "success": True,
        "engine": "builtin",
        "engine_available": True,
        "active_checks": config.ACTIVE_CHECKS,
        "severities": list(config.SEVERITIES),
        "targets": len(config.load_targets()),
        "remote_import_enabled": bool(config.IMPORT_TOKEN),
        "budget": {
            "max_pages": config.MAX_PAGES,
            "max_requests": config.MAX_REQUESTS,
            "rate_delay": config.RATE_DELAY,
            "request_timeout": config.REQUEST_TIMEOUT,
            "scan_timeout": config.SCAN_TIMEOUT,
            "max_seeds": config.MAX_SEEDS,
            "cors_probe_cap": config.CORS_PROBE_CAP,
        },
        "github": {
            "webhook_url": request.host_url.rstrip("/") + "/api/v1/dast/webhook",
            "global_secret_set": bool(config.GITHUB_WEBHOOK_SECRET),
            "global_token_set": bool(config.GITHUB_TOKEN),
            "fail_on": config.GITHUB_FAIL_ON,
            "scan_severity": config.GITHUB_SCAN_SEVERITY,
            "checks_mode": config.checks_mode(),
        },
    })


# ── Target registry ───────────────────────────────────────────────────────────
@bp.get("/targets")
def list_targets():
    targets = [config.redact_target(t) for t in config.load_targets()]
    return jsonify({"success": True, "targets": targets})


@bp.post("/targets")
def add_target():
    body = request.get_json(silent=True) or {}
    name = str(body.get("name", "")).strip()
    url = config.normalize_target_url(str(body.get("url", "")))
    if not name or not url:
        return jsonify({"success": False,
                        "error": "name and a valid http(s) url are required"}), 400
    if len(name) > 120 or len(str(body.get("url", ""))) > 500:
        return jsonify({"success": False, "error": "name or url too long"}), 400

    scope = str(body.get("scope", "")).strip()
    auth_header = str(body.get("auth_header", "")).strip()

    # Optional CI release-gate wiring (all optional; the target works without it).
    github_token = str(body.get("github_token", "")).strip()
    webhook_secret = str(body.get("webhook_secret", "")).strip()
    repo_url = str(body.get("repo_url", "")).strip()
    deploy_branch = str(body.get("deploy_branch", "")).strip()
    fail_on = str(body.get("fail_on", "")).strip()
    if fail_on and fail_on not in config.SEVERITY_ORDER:
        return jsonify({"success": False, "error": "invalid fail_on severity"}), 400
    github_full_name = (str(body.get("github_full_name", "")).strip().lower()
                        or config.github_full_name_from_url(repo_url) or "")

    target_id = config.slugify(name)
    if not config.is_valid_slug(target_id):
        return jsonify({"success": False,
                        "error": "could not derive a valid target id"}), 400

    # Re-registering without re-supplying a secret keeps the stored one.
    existing = config.get_target(target_id) or {}
    auth_header = auth_header or existing.get("auth_header", "")
    github_token = github_token or existing.get("github_token", "")
    webhook_secret = webhook_secret or existing.get("webhook_secret", "")

    entry = {
        "id": target_id,
        "name": name,
        "url": url,
        "scope": scope,
        "host": config.target_host(url),
        "enabled": True,
        "added_at": config.now_iso(),
        "last_scan": None,
        # CI gate (non-secret).
        "github_full_name": github_full_name,
        "repo_url": repo_url,
        "deploy_branch": deploy_branch,
        "fail_on": fail_on,
        # Secret-bearing — redacted on every read-back via config.redact_target.
        "auth_header": auth_header,
        "github_token": github_token,
        "webhook_secret": webhook_secret,
    }
    config.upsert_target(entry)
    return jsonify({"success": True, "target": config.redact_target(entry)}), 201


@bp.delete("/targets/<target_id>")
def delete_target(target_id: str):
    if not config.is_valid_slug(target_id):
        return jsonify({"success": False, "error": "invalid target id"}), 400
    return (jsonify({"success": True}) if config.remove_target(target_id)
            else (jsonify({"success": False, "error": "target not found"}), 404))


# ── Scans / jobs ──────────────────────────────────────────────────────────────
@bp.post("/targets/<target_id>/scan")
@tm_app.limiter.limit("10 per minute")
def scan_target(target_id: str):
    if not config.is_valid_slug(target_id):
        return jsonify({"success": False, "error": "invalid target id"}), 400
    target = config.get_target(target_id)
    if not target:
        return jsonify({"success": False, "error": "target not found"}), 404
    body = request.get_json(silent=True) or {}
    severity = str(body.get("severity", "Info"))
    job_id = get_service().submit_scan(target, severity)
    return jsonify({"success": True, "job_id": job_id}), 202


@bp.get("/jobs")
def list_jobs():
    return jsonify({"success": True, "jobs": get_service().list_jobs()})


@bp.get("/jobs/<job_id>")
def get_job(job_id: str):
    job = get_service().get_job(job_id)
    if not job:
        return jsonify({"success": False, "error": "job not found"}), 404
    return jsonify({"success": True, "job": job})


@bp.get("/jobs/<job_id>/events")
def job_events(job_id: str):
    service = get_service()
    if not service.get_job(job_id):
        return jsonify({"success": False, "error": "job not found"}), 404

    def stream():
        deadline = time.time() + config.SCAN_TIMEOUT + 30
        last = None
        while time.time() < deadline:
            job = service.get_job(job_id)
            if not job:
                break
            snapshot = json.dumps({"status": job["status"], "progress": job.get("progress"),
                                   "report_id": job.get("report_id"), "stats": job.get("stats"),
                                   "error": job.get("error"), "log": job.get("log", [])})
            if snapshot != last:
                yield f"data: {snapshot}\n\n"
                last = snapshot
            if job["status"] in ("done", "error"):
                break
            time.sleep(1)
        yield "event: end\ndata: {}\n\n"

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ── Remote push from a standalone scanner ─────────────────────────────────────
@bp.post("/import")
def import_report():
    if not config.IMPORT_TOKEN:
        return jsonify({"success": False, "error": "remote import disabled "
                        "(set TM_DAST_TOKEN)"}), 403
    provided = request.headers.get("X-Dast-Token", "")
    if not secrets.compare_digest(provided, config.IMPORT_TOKEN):
        return jsonify({"success": False, "error": "invalid dast token"}), 401
    report = request.get_json(silent=True) or {}
    try:
        report_id = get_service().import_report(report)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify({"success": True, "id": report_id}), 201


# ── GitHub webhook (CI release gate) ──────────────────────────────────────────
@bp.post("/webhook")
def github_webhook():
    """Receive a GitHub deployment_status / push event and trigger a scan.

    Auth is the HMAC in `X-Hub-Signature-256` (this route is exempt from the
    app's CSRF + API-key guard). We resolve the event to a *registered* target,
    verify the signature against that target's secret (falling back to the global
    secret), and scan the target's registered URL — never a URL from the payload.
    The result is posted back onto the deployment/commit as a gate signal.
    """
    body = request.get_data() or b""          # raw bytes, for the HMAC
    event = request.headers.get("X-GitHub-Event", "")
    sig = request.headers.get("X-Hub-Signature-256", "")

    try:
        payload = json.loads(body.decode("utf-8") or "{}")
    except ValueError:
        return jsonify({"success": False, "error": "invalid JSON payload"}), 400

    parsed = github.parse_webhook(event, payload)

    # Resolve the target first so a per-target secret can verify the signature.
    secret = config.GITHUB_WEBHOOK_SECRET
    target = config.find_target_for_github(parsed.get("full_name", ""))
    if target and target.get("webhook_secret"):
        secret = target["webhook_secret"]
    if not secret:
        return jsonify({"success": False, "error": "no webhook secret configured"}), 403
    if not github.verify_signature(secret, body, sig):
        return jsonify({"success": False, "error": "invalid signature"}), 401

    if parsed["kind"] == "ping":
        return jsonify({"success": True, "pong": True})
    if parsed["kind"] == "ignored":
        return jsonify({"success": True, "ignored": True, "reason": parsed.get("reason")})
    if not target:
        return jsonify({"success": False,
                        "error": f"no registered target for {parsed.get('full_name')}"}), 404

    # A push only gates when it matches the target's configured deploy branch;
    # otherwise the app may not be deployed yet, so we ignore it.
    if parsed["kind"] == "push":
        deploy_branch = (target.get("deploy_branch") or "").strip()
        if not deploy_branch or parsed.get("branch") != deploy_branch:
            return jsonify({"success": True, "ignored": True,
                            "reason": f"push branch {parsed.get('branch')!r} is not the "
                                      "target's deploy_branch"})

    gh_ctx = {
        "kind": parsed["kind"],
        "full_name": parsed["full_name"],
        "sha": parsed["sha"],
        "environment": parsed.get("environment"),
        "deployment_id": parsed.get("deployment_id"),
        "public_url": config.PUBLIC_URL or request.host_url.rstrip("/"),
    }
    job_id = get_service().submit_scan(
        target, config.GITHUB_SCAN_SEVERITY, gh_ctx=gh_ctx)
    return jsonify({"success": True, "job_id": job_id, "kind": parsed["kind"],
                    "target_id": target["id"], "sha": parsed["sha"]}), 202


# ── Dashboard page ────────────────────────────────────────────────────────────
@page_bp.get("/dast-scanner")
def dast_page():
    from app import _CSRF_TOKEN
    return render_template("dast.html", csrf_token=_CSRF_TOKEN)
