"""tests/test_sast_visibility.py — SAST reports live under /api/v1/sast alone.

Broker scan reports must never surface through the general report API: not in
the /api/reports listing, not fetchable/deletable/exportable by id there. Their
only serving surface is /api/v1/sast/reports*.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import app as tm_app
import report_db


def _isolate(tmp_path, monkeypatch):
    monkeypatch.setattr(tm_app, "REPORTS_DIR", tmp_path)
    monkeypatch.setattr(report_db, "DB_PATH", tmp_path / "reports.db")


def _save_pair():
    sast_id = tm_app._save_report(
        {"methodology": "sast", "overall_risk": "Critical", "categories": [],
         "analyzed_at": "2026-07-17"}, "SAST — scan1")
    tm_id = tm_app._save_report(
        {"methodology": "owasp", "overall_risk": "Low", "categories": [],
         "analyzed_at": "2026-07-17"}, "Threat model")
    return sast_id, tm_id


def _csrf(client):
    return client.get("/api/csrf-token").get_json()["token"]


def test_general_list_hides_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    ids = [r["id"] for r in client.get("/api/reports").get_json()["reports"]]
    assert tm_id in ids
    assert sast_id not in ids


def test_general_get_404s_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    assert client.get(f"/api/reports/{sast_id}").status_code == 404
    assert client.get(f"/api/reports/{tm_id}").status_code == 200


def test_general_delete_404s_sast_and_keeps_file(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, _ = _save_pair()
    client = tm_app.app.test_client()
    resp = client.delete(f"/api/reports/{sast_id}",
                         headers={"X-CSRF-Token": _csrf(client)})
    assert resp.status_code == 404
    assert (tmp_path / f"{sast_id}.json").exists()


def test_general_exports_404_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, _ = _save_pair()
    client = tm_app.app.test_client()
    assert client.get(f"/api/export/{sast_id}").status_code == 404
    assert client.get(f"/api/reports/{sast_id}/export/sarif").status_code == 404


def test_sast_api_lists_only_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    data = client.get("/api/v1/sast/reports").get_json()
    ids = [r["id"] for r in data["reports"]]
    assert sast_id in ids
    assert tm_id not in ids


def test_sast_api_serves_and_exports_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    resp = client.get(f"/api/v1/sast/reports/{sast_id}")
    assert resp.status_code == 200
    assert resp.get_json()["report"]["methodology"] == "sast"
    # Non-SAST reports are not served here.
    assert client.get(f"/api/v1/sast/reports/{tm_id}").status_code == 404
    sarif_resp = client.get(f"/api/v1/sast/reports/{sast_id}/export/sarif")
    assert sarif_resp.status_code == 200
    assert b'"version"' in sarif_resp.data


def test_sast_api_delete(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, _ = _save_pair()
    client = tm_app.app.test_client()
    resp = client.delete(f"/api/v1/sast/reports/{sast_id}",
                         headers={"X-CSRF-Token": _csrf(client)})
    assert resp.status_code == 200
    assert not (tmp_path / f"{sast_id}.json").exists()


# ── Regression: the boundary above must hold for every report-derived
# endpoint, not just get/delete/export. These 7 previously had no gate at all,
# letting a SAST report id reach enrichment/ticketing/control-register/PQC
# through the general API despite the "never the general report API" contract
# documented on _is_sast_methodology.
def test_enrich_endpoints_404_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    assert client.get(f"/api/reports/{sast_id}/enrich/attack").status_code == 404
    assert client.get(f"/api/reports/{tm_id}/enrich/attack").status_code == 200
    assert client.get(f"/api/reports/{sast_id}/enrich/compliance").status_code == 404
    assert client.get(f"/api/reports/{tm_id}/enrich/compliance").status_code == 200


def test_control_register_404s_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    assert client.get(f"/api/reports/{sast_id}/control-register").status_code == 404
    assert client.get(f"/api/reports/{tm_id}/control-register").status_code == 200
    assert client.get(f"/api/reports/{sast_id}/control-register/export").status_code == 404
    assert client.get(f"/api/reports/{tm_id}/control-register/export").status_code == 200


def test_pqc_404s_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    assert client.get(f"/api/reports/{sast_id}/pqc").status_code == 404
    assert client.get(f"/api/reports/{tm_id}/pqc").status_code == 200


def test_ticket_creation_404s_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    csrf = _csrf(client)
    body = {"provider": "jira", "dry_run": True, "jira_url": "https://x.atlassian.net",
            "jira_email": "a@b.com", "jira_token": "t", "jira_project": "P"}
    resp = client.post(f"/api/reports/{sast_id}/tickets", json=body,
                       headers={"X-CSRF-Token": csrf})
    assert resp.status_code == 404
    resp = client.post(f"/api/reports/{tm_id}/tickets", json=body,
                       headers={"X-CSRF-Token": csrf})
    assert resp.status_code == 200


def test_confluence_publish_404s_sast(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    sast_id, tm_id = _save_pair()
    client = tm_app.app.test_client()
    csrf = _csrf(client)
    body = {"dry_run": True, "confluence_base_url": "https://x.atlassian.net",
            "confluence_email": "a@b.com", "confluence_api_token": "t",
            "confluence_space_key": "S"}
    resp = client.post(f"/api/reports/{sast_id}/confluence-page", json=body,
                       headers={"X-CSRF-Token": csrf})
    assert resp.status_code == 404
    resp = client.post(f"/api/reports/{tm_id}/confluence-page", json=body,
                       headers={"X-CSRF-Token": csrf})
    assert resp.status_code == 200
