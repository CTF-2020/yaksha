"""SQLite store for operational/integration settings — scan timeouts, worker
counts, GitHub/Jira/Azure integration knobs and tokens, security-header
toggles. Complements the deployment-time env vars these used to be sourced
from exclusively; env vars still win when set, so an env-var-only deployment
sees zero behavior change.

Deliberately excluded (bootstrap-order — needed before any DB connection can
exist, or deployment topology, not app data): TM_SECRET_KEY, TM_HOST/TM_PORT,
the TM_*_DIR state-directory paths (including this module's own
TM_SETTINGS_DIR), TM_BROKER_SCANNER/TM_BROKER_PYTHON.

Resolution precedence for every setting: **env var (if set) > stored DB value
> hardcoded default** — the same precedence already established by
app.py's _load_or_create_secret_key() and _bootstrap_admin_user(). Callers
pass the already-fetched env value (not an env-var name), so call sites stay
almost identical to the `os.environ.get(...)` line they replace, and this
module doesn't need to know each setting's env-var name(s) — e.g.
GITHUB_TOKEN's existing two-env-var fallback (TM_GITHUB_TOKEN or bare
GITHUB_TOKEN) is resolved by the caller exactly as it is today, before being
handed to resolve_str() as `env_value`.

Settings resolved on every HTTP request (frame-options, CSP) are read once at
process start into a module constant by their caller, NOT re-queried per
request — see app.py's usage. Everything else may resolve live per call;
none of these are hot-path enough for a SQLite read to matter.

Stdlib ``sqlite3`` only, mirroring report_db.py's pattern: connection-per-
call with WAL + a busy timeout, and an idempotent :func:`init` so ``DB_PATH``
can be repointed by tests without any "already initialized" staleness.

Run as a script for admin editing without touching env vars:
    python settings_db.py set <key> <value>
    python settings_db.py get <key>
    python settings_db.py unset <key>
    python settings_db.py list [--reveal-secrets]
"""
from __future__ import annotations

import os
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

STATE_DIR = Path(os.environ.get("TM_SETTINGS_DIR", str(Path.home() / ".tm_settings")))
DB_PATH = STATE_DIR / "settings.db"

_init_lock = threading.Lock()

# Keys that must never come back over list_settings() in plaintext unless
# explicitly asked for. Centralized here so a caller storing a token can't
# forget to flag it.
SECRET_KEYS = frozenset({
    "broker.import_token", "broker.github_token", "broker.github_webhook_secret",
    "app.api_key", "app.anthropic_api_key",
    "jira.token", "azure.pat", "linear.api_key", "confluence.api_token",
})

_TRUE = ("1", "true", "yes", "on")
_FALSE = ("0", "false", "no", "off")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    key         TEXT PRIMARY KEY,
    value       TEXT,
    is_secret   INTEGER NOT NULL DEFAULT 0,
    updated_at  REAL
);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)


# ── Storage ───────────────────────────────────────────────────────────────────
def set_value(key: str, value: str) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT OR REPLACE INTO settings(key,value,is_secret,updated_at) VALUES (?,?,?,?)",
            (key, str(value), int(key in SECRET_KEYS), time.time()))


def get_value(key: str) -> str | None:
    init()
    with closing(_connect()) as conn:
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else None


def unset(key: str) -> bool:
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute("DELETE FROM settings WHERE key = ?", (key,))
        return cur.rowcount > 0


def clear_all(preserve: "set[str] | None" = None) -> int:
    """Wipe every stored setting except the given keys. Used by the admin
    flush action — `preserve` exists so a flush can't silently turn off a
    security setting the operator explicitly enabled (e.g. app.require_login)
    by wiping the row that stores it. Returns the number of rows removed."""
    keep = preserve or set()
    init()
    with closing(_connect()) as conn, conn:
        rows = conn.execute("SELECT key FROM settings").fetchall()
        to_delete = [r["key"] for r in rows if r["key"] not in keep]
        conn.executemany("DELETE FROM settings WHERE key = ?", [(k,) for k in to_delete])
    return len(to_delete)


def list_settings(reveal_secrets: bool = False) -> list[dict]:
    """Every stored setting. Secret values come back as None (with
    is_secret=True) unless reveal_secrets is explicitly requested."""
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT key,value,is_secret,updated_at FROM settings ORDER BY key").fetchall()
    out = []
    for r in rows:
        is_secret = bool(r["is_secret"])
        out.append({
            "key": r["key"],
            "value": r["value"] if (reveal_secrets or not is_secret) else None,
            "is_secret": is_secret,
            "updated_at": r["updated_at"],
        })
    return out


# ── Resolution (env > DB > default) ─────────────────────────────────────────────
def _parse_bool(s: str, default: bool) -> bool:
    v = s.strip().lower()
    if v in _TRUE:
        return True
    if v in _FALSE:
        return False
    return default


def resolve_str(key: str, env_value: str | None, default: str) -> str:
    if env_value:
        return env_value
    stored = get_value(key)
    return stored if stored is not None else default


def resolve_int(key: str, env_value: str | None, default: int) -> int:
    if env_value:
        try:
            return int(env_value)
        except ValueError:
            pass
    stored = get_value(key)
    if stored is not None:
        try:
            return int(stored)
        except ValueError:
            pass
    return default


def resolve_bool(key: str, env_value: str | None, default: bool) -> bool:
    if env_value:
        return _parse_bool(env_value, default)
    stored = get_value(key)
    if stored is not None:
        return _parse_bool(stored, default)
    return default


def resolve_set(key: str, env_value: str | None, default: frozenset = frozenset()) -> set:
    """Comma-separated list -> a set of non-empty, stripped, lowercased items."""
    raw = env_value if env_value else get_value(key)
    if not raw:
        return set(default)
    return {item.strip().lower() for item in raw.split(",") if item.strip()}


if __name__ == "__main__":
    import sys

    def _main(argv: list[str]) -> int:
        if not argv:
            print(__doc__)
            return 1
        cmd = argv[0]
        if cmd == "set" and len(argv) == 3:
            set_value(argv[1], argv[2])
            print(f"set {argv[1]}")
            return 0
        if cmd == "get" and len(argv) == 2:
            v = get_value(argv[1])
            print(v if v is not None else "(unset)")
            return 0 if v is not None else 1
        if cmd == "unset" and len(argv) == 2:
            ok = unset(argv[1])
            print("unset" if ok else "no such key")
            return 0 if ok else 1
        if cmd == "list":
            reveal = "--reveal-secrets" in argv
            for s in list_settings(reveal_secrets=reveal):
                shown = s["value"] if s["value"] is not None else (
                    "(secret, hidden)" if s["is_secret"] else "(unset)")
                print(f"{s['key']} = {shown}")
            return 0
        print(__doc__)
        return 1

    raise SystemExit(_main(sys.argv[1:]))
