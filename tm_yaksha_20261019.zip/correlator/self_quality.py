"""correlator/self_quality.py — the correlator's own precision over time.

Every other verdict feature in this codebase measures the STATE of a finding
(its current verdict, age, SLA, whether reports agree about it). This module
measures the correlator itself: of the times it raised a finding's confidence
(an escalation -- verdict_tracking.verdict_alerts, e.g. blind_spot ->
corroborated), how many of those escalations held up against later evidence
versus got walked back? A high reversal rate, especially on
confirmed_exploitable/actively_exploited specifically, would mean the
correlator's strongest claims aren't durable -- the closest thing to a
precision signal this system can produce without an external ground truth
(there is no labeled "was this actually exploitable" oracle to grade
verdicts against, so this measures self-consistency over time instead).

Reversal is computed by diffing verdict_alerts (the from/to verdict recorded
at the time of each past escalation) against verdict_history.verdict (the
CURRENT verdict for that same fingerprint) -- no new storage: de-escalations
already update verdict_history silently (verdict_tracking.py's own
docstring), so "the current verdict is less actionable than what this alert
escalated to" is sufficient proof the escalation didn't stick. A fingerprint
escalated more than once within the window being measured only contributes
its LATEST escalation in that window to the reversal check -- only the
finding's live state matters; counting every historical escalation
separately would double-count the same underlying reversal.
"""
from __future__ import annotations

import time

import verdict_tracking
from suppressions.model import VERDICT_RANK

_DAY = 86400.0


def _latest_per_fingerprint(alerts: list[dict]) -> dict[str, dict]:
    """alerts must be ordered oldest-first (verdict_tracking.all_alerts'
    contract) so the last write per fingerprint is genuinely the latest."""
    latest: dict[str, dict] = {}
    for a in alerts:
        latest[a["fingerprint"]] = a
    return latest


def _tag_reversals(alerts: list[dict]) -> list[dict]:
    """One row per fingerprint (its latest escalation in ``alerts``), tagged
    with whether the CURRENT verdict is still at-or-above what it escalated
    to at the time."""
    latest = _latest_per_fingerprint(alerts)
    if not latest:
        return []
    current = verdict_tracking.current_verdict_map(list(latest.keys()))
    out = []
    for fp, a in latest.items():
        now_v = current.get(fp)
        reversed_ = bool(
            now_v and now_v in VERDICT_RANK
            and VERDICT_RANK[now_v] > VERDICT_RANK[a["to_verdict"]])
        out.append({**a, "current_verdict": now_v, "reversed": reversed_})
    return out


def reversal_rate(now: float | None = None) -> dict:
    """Overall + per-to-verdict reversal rate across every escalation ever
    recorded. ``rate`` is None (not 0.0) until at least one escalation has
    happened -- there is nothing to claim precision about yet."""
    alerts = verdict_tracking.all_alerts()
    rows = _tag_reversals(alerts)
    total = len(rows)
    reversed_n = sum(1 for r in rows if r["reversed"])

    by_verdict: dict[str, dict] = {}
    for r in rows:
        b = by_verdict.setdefault(r["to_verdict"], {"escalations": 0, "reversed": 0})
        b["escalations"] += 1
        if r["reversed"]:
            b["reversed"] += 1
    for b in by_verdict.values():
        b["rate"] = round(b["reversed"] / b["escalations"], 3) if b["escalations"] else None

    return {
        "escalations": total,
        "reversed": reversed_n,
        "rate": round(reversed_n / total, 3) if total else None,
        "by_verdict": by_verdict,
    }


def precision_trend(buckets: int = 12, bucket_days: float = 30.0,
                     now: float | None = None) -> list[dict]:
    """Reversal rate bucketed by each escalation's own timestamp, oldest
    bucket first -- charts whether the correlator's confidence increases have
    been holding up better or worse over time.

    Recent buckets are inherently biased toward LOWER reversal rates than
    they will eventually settle at: a reversal can only be observed after it
    happens, and an escalation from last week has had far less time to be
    walked back than one from six months ago. Treat the last 1-2 buckets as
    provisional, not as a real trend, until they've aged.
    """
    at = now if now is not None else time.time()
    bucket_days = max(1.0, bucket_days)
    buckets = max(1, buckets)
    start = at - buckets * bucket_days * _DAY

    alerts = verdict_tracking.all_alerts(since=start)
    out = []
    for i in range(buckets):
        b_start = start + i * bucket_days * _DAY
        b_end = b_start + bucket_days * _DAY
        bucket_alerts = [a for a in alerts if b_start <= a["at"] < b_end]
        rows = _tag_reversals(bucket_alerts)
        total = len(rows)
        reversed_n = sum(1 for r in rows if r["reversed"])
        out.append({
            "bucket_start": b_start, "bucket_end": b_end,
            "escalations": total, "reversed": reversed_n,
            "rate": round(reversed_n / total, 3) if total else None,
        })
    return out


def summary(now: float | None = None) -> dict:
    """Top-level self-quality card: overall reversal rate, recent trend, and
    the worst-offending weakness families -- what a correlator maintainer
    would check before trusting the tool's own claims."""
    at = now if now is not None else time.time()
    overall = reversal_rate(at)
    trend = precision_trend(now=at)

    alerts = verdict_tracking.all_alerts()
    rows = _tag_reversals(alerts)
    by_family: dict[str, dict] = {}
    for r in rows:
        fam = r.get("family") or "?"
        b = by_family.setdefault(fam, {"escalations": 0, "reversed": 0})
        b["escalations"] += 1
        if r["reversed"]:
            b["reversed"] += 1
    worst = sorted(
        ({"family": fam, **b,
          "rate": round(b["reversed"] / b["escalations"], 3) if b["escalations"] else None}
         for fam, b in by_family.items() if b["escalations"] >= 2),
        key=lambda r: (-(r["rate"] or 0.0), -r["escalations"]),
    )[:8]

    return {"overall": overall, "trend": trend, "worst_families": worst}
