"""api/design_review.py — Jira-ticket-triggered proactive design review.

Closes the "before code" gap: today TM only reviews architecture when someone
pastes text, uploads a diagram, or points it at a repo URL. This listens for a
Jira ticket being written and runs the same analysis automatically, the
moment the ticket exists — mirroring the SAST broker's GitHub webhook
(api/sast.py) but for Jira instead of GitHub.

Auth: Jira (Cloud or Server) has no native request-signing like GitHub's
X-Hub-Signature-256 — a raw System Webhook can only template the URL (so a
secret goes in a query param), while a Jira Automation "Send web request"
action can attach a custom header instead. Both are accepted, checked with a
constant-time compare against one configured secret, same posture as the
app's own optional TM_API_KEY bearer guard in app.py's before_request.

On issue_created / issue_updated the ticket's summary + description (plain
text on Server, Atlassian Document Format on Cloud — both handled) is run
through the existing analyzer.analyze() LLM-enrichment path, saved as a normal
TM report (methodology="design-review"), and a summary comment is posted back
on the originating ticket via jira_client.add_comment — best-effort, never
fails the request.

The saved report is also synced into the persistent threat-lineage graph
(lineage.service), registering each of its findings as a "predicted" threat
under that fingerprint. This is what makes a ticket-level trigger more than
a one-off review: the moment a matching code or runtime finding shows up from
any later codemodel/SAST/DAST scan and gets synced too, lineage recognizes it
as the SAME threat and flips it to "realized" — closing the loop from
"flagged at planning time" to "found in the code," automatically, the same
loop DAST validation closes on the runtime side.

If the ticket names a component or lives under a project key that matches a
broker-registered repo's display name, the webhook also queues a fresh
SAST+code-model+correlation pipeline run (broker.pipeline) for that repo in
the background — so a ticket marking a design change doesn't just get its own
one-off review, it re-scans the actual code the change is landing in. This is
best-effort matching (no Jira custom field or TM-side mapping UI exists yet),
so most tickets simply won't match anything, which is the expected common
case, not a failure.
"""
from __future__ import annotations

import hmac
import logging
import os
import threading

from flask import Blueprint, jsonify, request

import app as tm_app
import analyzer
import jira_client
import settings_db

log = logging.getLogger(__name__)

bp = Blueprint("design_review_api", __name__, url_prefix="/api/v1/design-review")

_HANDLED_EVENTS = {"jira:issue_created", "jira:issue_updated"}
_MAX_ARCH_LEN = 60_000

# Caps how many ticket-triggered pipeline runs (git fetch + SAST + code-model)
# can be in flight at once, regardless of how many distinct repos a burst of
# webhook calls names — the same proportionate concern broker.service's
# bounded worker pool addresses for GitHub-triggered scans, sized down here
# since this path is expected to fire far less often than a push webhook.
_RESCAN_CONCURRENCY = threading.Semaphore(2)


def _webhook_secret() -> str:
    return settings_db.resolve_str(
        "design_review.webhook_secret", os.environ.get("TM_DESIGN_REVIEW_SECRET"), "")


def _verify(req) -> bool:
    """Constant-time check against a header or query-param secret.

    Never raises — a malformed/missing secret is just "not verified", the
    same contract as broker.github.verify_signature.
    """
    secret = _webhook_secret()
    if not secret:
        return False
    provided = req.headers.get("X-TM-Webhook-Secret", "") or req.args.get("secret", "")
    if not provided:
        return False
    return hmac.compare_digest(provided, secret)


def _ticket_text(issue: dict) -> tuple[str, str]:
    fields = issue.get("fields") or {}
    summary = str(fields.get("summary") or "").strip()
    description = jira_client.adf_to_text(fields.get("description")).strip()
    return summary, description


_COMMENT_FIELD_LEN = 300  # per-category text caps: long enough to be useful, short
                          # enough that 3 categories don't turn into a wall of text


def _clip(text: str, limit: int = _COMMENT_FIELD_LEN) -> str:
    text = str(text or "").strip()
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def _post_comment_best_effort(issue_key: str, report: dict, report_id: str) -> None:
    """Comment the review summary back on the ticket. Never raises — a Jira
    outage or missing ticket-comment credentials must never fail the webhook
    response; the report is already saved by the time this runs."""
    cfg = jira_client.config_from_env()
    if not cfg or cfg.provider != "jira":
        return
    try:
        from broker import config as bconfig
        base = bconfig.PUBLIC_URL or ""
        link = f"{base}/#report={report_id}" if base else f"report {report_id}"
        lines = [
            f"Yaksha Guard design review complete — overall risk: {report.get('overall_risk', 'Unknown')}",
            report.get("summary", ""),
            "",
        ]
        for cat in report.get("categories", [])[:3]:
            lines.append(f"- [{cat.get('risk', '?')}] {cat.get('name', cat.get('id', ''))}")
            # The technical explanation of *why* this is a finding (analyzer.py's
            # "description" — a concrete explanation referencing this system's
            # components, not just the STRIDE/OWASP category label) plus the top
            # recommended fix, so the ticket carries the actual issue, not only
            # a risk-level label a reader would otherwise have to open the full
            # report to understand.
            description = _clip(cat.get("description", ""))
            if description:
                lines.append(f"  {description}")
            mitigations = cat.get("mitigations") or []
            action = str((mitigations[0] or {}).get("action", "")).strip() if mitigations else ""
            if action:
                lines.append(f"  Fix: {_clip(action)}")
        lines.append("")
        lines.append(f"Full report: {link}")
        jira_client.add_comment(cfg, issue_key, "\n".join(l for l in lines if l is not None))
    except Exception as exc:  # noqa: BLE001 — best-effort, must never fail the webhook
        log.warning("could not post design-review comment on %s: %s", issue_key, exc)


def _sync_lineage_best_effort(report_id: str) -> None:
    """Register this design-time review in the persistent threat-lineage graph.

    Best-effort, same posture as the comment-back above: a lineage bug must
    never fail the webhook response, and the report itself is already saved
    by the time this runs, so there is nothing to roll back on failure.
    """
    try:
        from lineage import service as lineage_service
        lineage_service.sync(report_id)
    except Exception as exc:  # noqa: BLE001 — best-effort, must never fail the webhook
        log.warning("could not sync design-review report %s into lineage: %s",
                   report_id, exc)


def _find_target_repo(issue: dict) -> dict | None:
    """Best-effort match from the ticket to a broker-registered repo.

    Matched by Jira component name(s) or project key against a registered
    repo's display name (case-insensitive exact match) — the only identifiers
    a raw Jira webhook payload carries that plausibly name a codebase, absent
    a dedicated Jira custom field or a TM-side ticket-to-repo mapping UI
    (neither exists yet). Returning None is the normal, common outcome for a
    ticket that isn't scoped to one registered repo — not an error.
    """
    fields = issue.get("fields") or {}
    candidates = [str(c.get("name", "")).strip()
                  for c in (fields.get("components") or [])
                  if isinstance(c, dict) and c.get("name")]
    project_key = str((fields.get("project") or {}).get("key", "")).strip()
    if project_key:
        candidates.append(project_key)
    wanted = {c.lower() for c in candidates if c}
    if not wanted:
        return None
    try:
        from broker import config as bconfig
        repos = bconfig.load_repos()
    except Exception:
        return None
    for repo in repos:
        if str(repo.get("name", "")).strip().lower() in wanted:
            return repo
    return None


def _post_rescan_comment_best_effort(issue_key: str, repo: dict, result: dict) -> None:
    """Comment the rescan's correlation verdict back on the ticket that
    triggered it — the other half of the ticket-to-rescan loop. Without this,
    the design-review comment posts immediately but the rescan it queues runs
    in the background and its outcome (still present / fixed / newly
    corroborated) previously only ever reached a log line, never the ticket.

    Best-effort, same posture as _post_comment_best_effort: this runs inside
    the background rescan thread, so nothing here may raise back into it.
    """
    cfg = jira_client.config_from_env()
    if not cfg or cfg.provider != "jira":
        return
    corr_id = result.get("correlation_report_id")
    if not corr_id:
        return
    try:
        import report_db
        report = report_db.get_report(corr_id)
        if not report:
            return
        from broker import config as bconfig
        base = bconfig.PUBLIC_URL or ""
        link = f"{base}/#report={corr_id}" if base else f"report {corr_id}"
        lines = [
            f"Rescan complete for {repo.get('name', repo.get('id', 'repo'))} — "
            f"overall risk: {report.get('overall_risk', 'Unknown')}",
            report.get("summary", ""),
            "",
            f"Correlation report: {link}",
        ]
        jira_client.add_comment(cfg, issue_key, "\n".join(l for l in lines if l is not None))
    except Exception as exc:  # noqa: BLE001 — best-effort, must never break the background thread
        log.warning("could not post rescan-result comment on %s: %s", issue_key, exc)


def _rescan_affected_repo_background(repo: dict, issue_key: str) -> None:
    """Queue a fresh SAST+code-model+correlation pipeline run for ``repo`` in
    a background thread.

    A full pipeline run clones/fetches and scans a repo — far longer than a
    webhook response should block for — so this mirrors the GitHub webhook's
    async posture (broker.service.submit_scan) rather than running inline.
    Best-effort: a failure here is logged only; the webhook has already
    responded with the design-review report it definitely produced by the
    time this runs.
    """
    def _run():
        if not _RESCAN_CONCURRENCY.acquire(blocking=False):
            log.info("design-review re-scan for repo %s (issue %s) skipped: "
                     "too many re-scans already in flight", repo.get("id"), issue_key)
            return
        try:
            from broker import pipeline
            result = pipeline.run(repo)
            log.info("design-review triggered re-scan for repo %s (issue %s): "
                     "correlation report %s", repo.get("id"), issue_key,
                     result.get("correlation_report_id"))
            _post_rescan_comment_best_effort(issue_key, repo, result)
        except Exception as exc:  # noqa: BLE001 — background thread, nothing to return to
            log.warning("design-review triggered re-scan failed for repo %s (issue %s): %s",
                       repo.get("id"), issue_key, exc)
        finally:
            _RESCAN_CONCURRENCY.release()

    threading.Thread(target=_run, daemon=True,
                     name=f"design-review-rescan-{repo.get('id', '?')}").start()


@bp.post("/webhook")
@tm_app.limiter.limit("20 per minute")
def jira_webhook():
    """Receive a Jira issue_created/issue_updated event and run a design review."""
    if not _verify(request):
        return jsonify({"success": False, "error": "invalid or missing webhook secret"}), 401

    body = request.get_json(silent=True) or {}
    event = body.get("webhookEvent", "")
    if event not in _HANDLED_EVENTS:
        return jsonify({"success": True, "ignored": True, "event": event})

    issue = body.get("issue") or {}
    issue_key = str(issue.get("key") or "")
    summary, description = _ticket_text(issue)
    if not issue_key or not (summary or description):
        return jsonify({"success": False, "error": "missing issue key or content"}), 400

    arch_text = f"{summary}\n\n{description}".strip()[:_MAX_ARCH_LEN]

    import app as tm_app  # lazy import to avoid a circular import at load

    api_key = tm_app._env_api_key_if_omitted("", False)
    methodology = analyzer.normalize_methodologies(None)
    if not api_key:
        methodology = tm_app._fallback_without_api_key(methodology)

    try:
        report = analyzer.analyze(
            api_key, arch_text, title=f"Design Review · {issue_key}", methodology=methodology)
    except Exception as exc:
        log.error("design-review analysis failed for %s: %s", issue_key, exc)
        return jsonify({"success": False, "error": "analysis failed"}), 500

    report["methodology"] = "design-review"
    report["methodology_label"] = "Proactive Design Review (Jira)"
    report_id = tm_app._save_report(report, report["title"], arch_text)

    _post_comment_best_effort(issue_key, report, report_id)
    _sync_lineage_best_effort(report_id)

    target_repo = _find_target_repo(issue)
    if target_repo:
        _rescan_affected_repo_background(target_repo, issue_key)

    return jsonify({
        "success": True, "report_id": report_id, "issue_key": issue_key,
        "rescan": "queued" if target_repo else "skipped",
        "rescan_repo_id": target_repo.get("id") if target_repo else None,
    }), 202
