"""verdict_reconciliation.py — cross-REPORT verdict reconciliation: when the
same underlying finding (same fingerprint) currently carries different
verdicts across two or more LIVE reports at once, decide one effective
verdict and surface the disagreement.

Distinct from verdict_tracking.py's cross-SCAN tracking, which watches one
finding's verdict change SEQUENTIALLY over successive correlation runs ("did
it get worse since last time?") and only remembers the last verdict seen.
This module instead looks SIDEWAYS, at every report that exists right now: a
repo correlated under two different configurations (say a SAST+DAST run and
a SAST+design-review run), a monorepo correlated per-service into separate
reports that both touch a shared library, or simply an old correlation
report nobody re-ran that still says something a newer, more complete one
has since disproven — any of these can leave the SAME finding sitting at two
different verdicts simultaneously. Nothing else in this codebase ever
compares them side by side: every existing cross-report rollup (dashboard's
_verdicts()/_governance(), fleet.py, triage.py) dedupes by fingerprint by
silently keeping whichever report it encounters first (report_db.all_reports
returns newest-first), which in practice means "whichever was scanned most
recently wins" — with no record that a disagreement ever existed.

Reconciliation policy: the EFFECTIVE verdict for a fingerprint is the MOST
ACTIONABLE verdict among every live report that currently carries it — not
the most recent one. This is the same "err toward more risk visible, not
less" bias verdict_tracking.py already applies to its own SLA backfill (see
its module docstring): letting a stale or narrower-scoped correlation run
silently win over a more damning one, purely because of store-iteration
order, is exactly the kind of quiet risk-hiding this module exists to
surface instead of perpetuate.

Read-time and non-destructive, same posture as suppressions/ownership/
confidence_decay: this never rewrites a stored report or verdict, it only
computes a reconciled view and a conflict worklist for a human (or another
read-time consumer) to act on.
"""
from __future__ import annotations

import report_db
import suppressions
from suppressions.model import VERDICT_RANK

_EXCLUDED_METHODS = ("sast", "dast")


def _live_verdict_rows() -> dict[str, list[dict]]:
    """fingerprint -> every currently-live instance of it, one entry per
    (non-suppressed, verdict-carrying) category across every viewer-visible
    report — ALL of them, not just the newest per fingerprint. That
    "keep everything, not just the latest" collection is the whole
    difference from every other cross-report rollup in this codebase.
    """
    from suppressions.engine import finding_fingerprint

    supps = suppressions.load_suppressions()
    by_fp: dict[str, list[dict]] = {}
    for r in report_db.all_reports(limit=2000):
        if str(r.get("methodology", "")).lower() in _EXCLUDED_METHODS:
            continue
        annotated = suppressions.annotate_report(r, supps)
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            verdict = cat.get("verdict")
            if verdict not in VERDICT_RANK:
                continue
            fp = finding_fingerprint(cat)
            by_fp.setdefault(fp, []).append({
                "verdict": verdict, "report_id": r.get("id"),
                "report_title": r.get("title") or r.get("id"),
                "title": cat.get("name") or cat.get("title") or cat.get("id") or "Finding",
                "family": cat.get("family") or "",
            })
    return by_fp


def reconcile(instances: list[dict]) -> dict:
    """One fingerprint's live instances -> the reconciled view: the most
    actionable verdict among them, whether they actually disagree, and the
    full sorted set of distinct verdicts present."""
    verdicts = [row["verdict"] for row in instances]
    distinct = sorted(set(verdicts), key=lambda v: VERDICT_RANK[v])
    return {
        "effective_verdict": distinct[0],
        "conflict": len(distinct) > 1,
        "distinct_verdicts": distinct,
        "instances": instances,
    }


def _all_reconciled() -> list[dict]:
    """Every currently-tracked fingerprint's reconciliation record, whether
    or not it actually conflicts."""
    out = []
    for fp, rows in _live_verdict_rows().items():
        rec = reconcile(rows)
        first = rows[0]
        out.append({"fingerprint": fp, "title": first["title"], "family": first["family"], **rec})
    return out


def _sort_worst_first(items: list[dict]) -> list[dict]:
    return sorted(items, key=lambda c: (VERDICT_RANK[c["effective_verdict"]], -len(c["instances"])))


def conflicts(limit: int = 100) -> list[dict]:
    """Every finding currently carrying more than one distinct verdict across
    live reports, most-actionable-effective-verdict first."""
    items = _sort_worst_first([r for r in _all_reconciled() if r["conflict"]])
    return items[:max(1, min(limit, 500))]


def summary() -> dict:
    """Fleet-wide reconciliation posture: how many tracked findings have a
    live cross-report disagreement, and the worst of them."""
    all_items = _all_reconciled()
    conflict_items = _sort_worst_first([r for r in all_items if r["conflict"]])
    total = len(all_items)
    return {
        "total_findings": total,
        "conflicts": len(conflict_items),
        "conflict_pct": round(100.0 * len(conflict_items) / total, 1) if total else 0.0,
        "worst_conflicts": conflict_items[:10],
    }


def effective_verdict(fingerprint: str) -> str | None:
    """The reconciled (most-actionable-across-live-reports) verdict for one
    fingerprint, or None if it has no live verdict-carrying instance at all
    right now."""
    rows = _live_verdict_rows().get(fingerprint)
    if not rows:
        return None
    return reconcile(rows)["effective_verdict"]
