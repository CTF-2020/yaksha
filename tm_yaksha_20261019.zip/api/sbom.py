"""SBOM API routes."""
from __future__ import annotations

from flask import Blueprint

import app as tm_app


bp = Blueprint("sbom_api", __name__, url_prefix="/api/v1/sbom")


@bp.post("/analyze")
@tm_app.limiter.limit("20 per minute")
def analyze_sbom():
    """Analyze a CycloneDX or SPDX SBOM."""
    return tm_app._analyze_sbom_impl()
