"""System model extracted from code for the threat-modeling side.

Where a SAST engine emits vulnerabilities, this engine emits *design facts*: the
attack surface (entry points), the trust boundaries the code actually crosses
(data stores, external calls), the security controls it can see (auth, validation,
TLS…) and the secrets it handles. Those facts are what a threat model reasons
over, so lifting them out of code lets us (a) render a code-derived threat model
and (b) reconcile it against a human one via the correlation engine.

Everything here is a plain dataclass so the extractor stays pure and testable.
"""
from __future__ import annotations

from dataclasses import dataclass, field


# Confidence a fact was correctly inferred from static structure alone.
HIGH, MEDIUM, LOW = "high", "medium", "low"


@dataclass
class Sink:
    """A security-sensitive operation reachable in the code."""

    kind: str            # sql | command | code-eval | deserialize | path | ssrf | template | redirect
    family: str          # correlator weakness-family slug, e.g. "sql-injection"
    cwe: str             # e.g. "CWE-89"
    name: str            # the call expression, e.g. "cursor.execute"
    file: str
    line: int
    hops: int = 0        # 0 = in the handler body, 1 = one call away, …
    tainted: bool = False  # an argument traces to request/user input
    confidence: str = MEDIUM


@dataclass
class DependencyUse:
    """A call into a third-party import, reachable in the code.

    Sink only covers the handful of hardcoded dangerous call patterns
    (sql/command/eval/…); most vulnerable-dependency CVEs (an SSRF header leak,
    a bad default, …) don't match any of those. This tracks *any* call whose
    root resolves to a tracked import, independent of whether it also matches
    a Sink pattern, so a vulnerable-component finding can be checked for real
    reachability regardless of which kind of flaw the CVE actually is.
    """

    root: str             # resolved import root, e.g. "yaml", "requests"
    name: str             # the call expression, e.g. "yaml.load"
    file: str
    line: int
    hops: int = 0
    tainted: bool = False


@dataclass
class Control:
    """A security control observed in the code."""

    kind: str            # auth | validation | encoding | tls | csrf | rate-limit | logging | headers
    mechanism: str       # e.g. "@login_required", "pydantic model", "Talisman"
    scope: str           # global | entrypoint
    file: str = ""
    line: int = 0


@dataclass
class EntryPoint:
    """An externally reachable point of the system — the attack surface."""

    method: str          # GET/POST/… or "*" | "consume" | "cli"
    path: str            # route path or handler identity
    handler: str         # function/view name
    file: str
    line: int
    framework: str = ""
    kind: str = "http"   # http | graphql | queue | cli | webhook | rpc
    authenticated: bool = False
    controls: list = field(default_factory=list)        # list[Control]
    reachable_sinks: list = field(default_factory=list)  # list[Sink]
    reachable_deps: list = field(default_factory=list)   # list[DependencyUse]
    # Business-impact signal from walking the call graph out from this entry
    # point: {"tier", "score", "reason", "hops"} for the nearest reachable
    # function (this handler, or anything it transitively calls) whose
    # route/name/file matches a business_impact keyword tier, or None if
    # nothing in the reachable subgraph matched. See
    # codemodel/extractor.py:_reachable_impact and
    # codemodel/business_impact.py:nearest_match.
    reachable_impact: dict | None = None

    @property
    def locus(self) -> str:
        return f"{self.method} {self.path}".strip()


@dataclass
class ExternalCall:
    """A call that leaves the process / crosses a trust boundary."""

    kind: str            # http | db | cache | queue | storage | rpc
    target: str          # driver / host / service name
    file: str
    line: int
    encrypted: bool = True   # False for cleartext (http://) endpoints we can see


@dataclass
class DataStore:
    """A persistence or state boundary the code connects to."""

    kind: str            # sql | nosql | cache | object-storage | filesystem
    engine: str          # postgres | mysql | sqlite | mongo | redis | s3 | …
    file: str
    line: int


@dataclass
class Secret:
    """A credential/secret the code references."""

    name: str
    file: str
    line: int
    managed: bool        # True when read from env/secret manager, False when hardcoded


@dataclass
class TrustBoundary:
    """An inferred boundary between differently-trusted zones."""

    name: str
    kind: str            # network | process | privilege | persistence | external-service
    description: str = ""


@dataclass
class SystemModel:
    """The whole code-derived view of a system."""

    root: str = ""
    languages: set = field(default_factory=set)
    frameworks: set = field(default_factory=set)
    entry_points: list = field(default_factory=list)     # list[EntryPoint]
    external_calls: list = field(default_factory=list)    # list[ExternalCall]
    data_stores: list = field(default_factory=list)       # list[DataStore]
    controls: list = field(default_factory=list)          # list[Control] (global)
    secrets: list = field(default_factory=list)           # list[Secret]
    trust_boundaries: list = field(default_factory=list)  # list[TrustBoundary]
    files_scanned: int = 0
    parse_errors: list = field(default_factory=list)      # list[str]

    def stats(self) -> dict:
        authed = sum(1 for e in self.entry_points if e.authenticated)
        agent_tools = sum(1 for e in self.entry_points if e.kind == "agent-tool")
        return {
            "entry_points": len(self.entry_points),
            "authenticated_entry_points": authed,
            "unauthenticated_entry_points": len(self.entry_points) - authed,
            "agent_tool_entry_points": agent_tools,
            "external_calls": len(self.external_calls),
            "data_stores": len(self.data_stores),
            "global_controls": len(self.controls),
            "secrets": len(self.secrets),
            "hardcoded_secrets": sum(1 for s in self.secrets if not s.managed),
            "trust_boundaries": len(self.trust_boundaries),
            "files_scanned": self.files_scanned,
        }
