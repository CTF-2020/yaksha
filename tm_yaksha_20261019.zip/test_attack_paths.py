"""Tests for attack-path synthesis (attack_paths) + the /correlate/attack-paths API.

Unit tests drive precise synthetic attack surfaces; the integration test runs
the real codemodel extractor on a vulnerable Flask fixture, so the entry->sink
reachability, taint, and severity all come from the actual engine.
"""
from __future__ import annotations

import os
import tempfile
import unittest

import attack_paths
from codemodel import extractor, mapper, threats


# Reuse the codemodel test fixture: /hook is an unauthenticated, tainted
# command-injection; /public/search an unauth SQLi; /admin/delete an authed SSRF.
FLASK_APP = '''
import os, sqlite3, requests
from flask import Flask, request
from flask_login import login_required
app = Flask(__name__)

@app.route("/public/search")
def search():
    q = request.args.get("q")
    sqlite3.connect("a.db").execute("SELECT * FROM u WHERE n='%s'" % q)
    return "ok"

@app.route("/hook", methods=["POST"])
def hook():
    os.system("sh " + request.form["c"])
    return "ok"
'''


def _cm_report_from_source(src=FLASK_APP):
    d = tempfile.mkdtemp(prefix="ap_test_")
    with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
        fh.write(src)
    model = extractor.build_model(d)
    return mapper.build_report(model, threats.derive(model),
                               {"id": "r", "name": "fixture"}, {})


def _surface(entry_over=None, sink_over=None):
    """A synthetic codemodel report carrying one entry->sink surface."""
    entry = {"method": "POST", "path": "/upload", "handler": "upload",
             "file": "h.py", "line": 3, "authenticated": False, "controls": [],
             "sinks": [{"kind": "command", "family": "command-injection",
                        "cwe": "CWE-78", "name": "os.system", "file": "h.py",
                        "line": 5, "hops": 0, "tainted": True}]}
    if entry_over:
        entry.update(entry_over)
    if sink_over:
        entry["sinks"][0].update(sink_over)
    return {"id": "cm", "methodology": "codemodel",
            "scan_metadata": {"attack_surface": [entry]}}


def _dast(family_cwe="CWE-78", name="Command Injection", locus="/upload"):
    return {"id": "dyn", "methodology": "dast", "categories": [{
        "id": "D1", "name": name, "risk": "High", "_source": "DAST",
        "cwe": family_cwe, "affected_components": [locus],
        "threats": [{"name": locus}]}]}


class TestSynthesisUnit(unittest.TestCase):
    def test_tainted_unauth_sink_becomes_high_confidence_path(self):
        paths = attack_paths.synthesize(_surface())
        self.assertEqual(len(paths), 1)
        p = paths[0]
        self.assertEqual(p.family, "command-injection")
        self.assertEqual(p.severity, "Critical")
        self.assertTrue(p.tainted)
        self.assertFalse(p.authenticated)
        self.assertEqual(p.verdict, "high-confidence")
        self.assertFalse(p.runtime_confirmed)
        # Steps run entry -> boundary -> sink.
        roles = [s.role for s in p.steps]
        self.assertEqual(roles[0], "entry")
        self.assertEqual(roles[-1], "sink")
        self.assertIn("boundary", roles)

    def test_non_tainted_no_evidence_is_dropped(self):
        paths = attack_paths.synthesize(_surface(sink_over={"tainted": False}))
        self.assertEqual(paths, [])

    def test_non_tainted_but_runtime_evidence_is_kept_and_confirmed(self):
        paths = attack_paths.synthesize(
            _surface(sink_over={"tainted": False}), [_dast()])
        self.assertEqual(len(paths), 1)
        p = paths[0]
        self.assertTrue(p.runtime_confirmed)
        self.assertEqual(p.verdict, "confirmed")
        self.assertIn("dyn", p.evidence_reports)

    def test_runtime_confirmed_escalates_and_boosts_confidence(self):
        base = attack_paths.synthesize(_surface())[0]
        confirmed = attack_paths.synthesize(_surface(), [_dast()])[0]
        self.assertGreater(confirmed.confidence, base.confidence)
        self.assertEqual(confirmed.verdict, "confirmed")
        self.assertTrue(confirmed.runtime_confirmed)

    def test_authenticated_entry_is_candidate_not_high_confidence(self):
        paths = attack_paths.synthesize(
            _surface(entry_over={"authenticated": True}))
        self.assertEqual(paths[0].verdict, "candidate")
        # Auth entry has lower confidence than the unauth equivalent.
        self.assertLess(paths[0].confidence,
                        attack_paths.synthesize(_surface())[0].confidence)

    def test_dast_at_different_feature_does_not_confirm(self):
        paths = attack_paths.synthesize(
            _surface(sink_over={"tainted": False}),
            [_dast(locus="/unrelated-endpoint")])
        # No tainted signal and no matching runtime evidence -> dropped.
        self.assertEqual(paths, [])

    def test_priority_orders_confirmed_first(self):
        # Two surfaces: one confirmed critical, one candidate medium.
        report = {"id": "cm", "methodology": "codemodel", "scan_metadata": {
            "attack_surface": [
                {"method": "GET", "path": "/x", "handler": "x", "file": "a.py",
                 "line": 1, "authenticated": True, "controls": [],
                 "sinks": [{"kind": "redirect", "family": "open-redirect",
                            "cwe": "CWE-601", "name": "redirect", "file": "a.py",
                            "line": 2, "hops": 0, "tainted": True}]},
                {"method": "POST", "path": "/y", "handler": "y", "file": "b.py",
                 "line": 1, "authenticated": False, "controls": [],
                 "sinks": [{"kind": "command", "family": "command-injection",
                            "cwe": "CWE-78", "name": "os.system", "file": "b.py",
                            "line": 2, "hops": 0, "tainted": True}]}]}}
        paths = attack_paths.synthesize(report, [_dast(locus="/y")])
        self.assertEqual(paths[0].family, "command-injection")  # confirmed critical first


class TestToReport(unittest.TestCase):
    def test_report_shape(self):
        paths = attack_paths.synthesize(_surface(), [_dast()])
        report = attack_paths.to_report(
            paths, [{"id": "cm", "role": "codemodel"}, {"id": "dyn", "role": "evidence"}],
            {"report_title": "AP test"})
        self.assertEqual(report["methodology"], "attackpath")
        self.assertEqual(report["overall_risk"], "Critical")
        self.assertEqual(report["scan_metadata"]["confirmed"], 1)
        self.assertEqual(report["categories"][0]["_source"], "ATTACKPATH")

    def test_empty_paths_report_is_valid(self):
        report = attack_paths.to_report([], [{"id": "cm"}], {})
        self.assertEqual(report["categories"], [])
        self.assertEqual(report["overall_risk"], "Info")
        self.assertIn("No exploitable attack paths", report["summary"])

    def test_category_id_is_stable_across_processes_not_builtin_hash(self):
        # Regression: the id used Python's builtin hash(), which is
        # randomized per-process (PYTHONHASHSEED) — the same finding got a
        # different id every run, breaking suppression fingerprints and
        # cross-scan diffing. Spawn a fresh interpreter (its own random hash
        # seed) and confirm the id it computes matches this process's.
        import subprocess
        import sys
        paths = attack_paths.synthesize(_surface(), [_dast()])
        report = attack_paths.to_report(paths, [{"id": "cm"}], {})
        this_process_id = report["categories"][0]["id"]

        script = (
            "import sys; sys.path.insert(0, %r)\n"
            "import attack_paths\n"
            "from test_attack_paths import _surface, _dast\n"
            "paths = attack_paths.synthesize(_surface(), [_dast()])\n"
            "report = attack_paths.to_report(paths, [{'id': 'cm'}], {})\n"
            "print(report['categories'][0]['id'])\n"
        ) % os.path.dirname(os.path.abspath(__file__))
        out = subprocess.run(
            [sys.executable, "-c", script],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            capture_output=True, text=True, timeout=30,
            env={**os.environ, "PYTHONHASHSEED": "random"},
        )
        self.assertEqual(out.returncode, 0, out.stderr)
        other_process_id = out.stdout.strip()
        self.assertEqual(this_process_id, other_process_id)


class TestEndToEndFromExtractor(unittest.TestCase):
    def test_real_codemodel_yields_tainted_command_injection_path(self):
        cm = _cm_report_from_source()
        surface = cm["scan_metadata"]["attack_surface"]
        self.assertTrue(surface, "codemodel report must carry attack_surface")

        paths = attack_paths.synthesize(cm)
        families = {p.family for p in paths}
        # /hook is tainted -> path. /public/search's SQL sink is reachable but the
        # extractor does not confirm taint through "%s" % q, so with no scan
        # evidence it is intentionally dropped (a path always carries a concrete
        # exploitability signal, not mere reachability).
        self.assertIn("command-injection", families)
        self.assertNotIn("sql-injection", families)
        cmd = next(p for p in paths if p.family == "command-injection")
        self.assertEqual(cmd.severity, "Critical")
        self.assertFalse(cmd.authenticated)   # /hook is unauthenticated
        self.assertTrue(cmd.tainted)

    def test_reachable_sqli_surfaces_once_runtime_evidence_exists(self):
        # The same reachable-but-untainted SQL sink becomes a path when a DAST
        # scan confirms injection at that endpoint.
        cm = _cm_report_from_source()
        dast = _dast(family_cwe="CWE-89", name="SQL Injection", locus="/public/search")
        paths = attack_paths.synthesize(cm, [dast])
        sqli = [p for p in paths if p.family == "sql-injection"]
        self.assertTrue(sqli)
        self.assertTrue(sqli[0].runtime_confirmed)

    def test_runtime_evidence_confirms_the_chain(self):
        cm = _cm_report_from_source()
        dast = _dast(locus="/hook")
        paths = attack_paths.synthesize(cm, [dast])
        cmd = next(p for p in paths if p.family == "command-injection")
        self.assertTrue(cmd.runtime_confirmed)
        self.assertEqual(cmd.verdict, "confirmed")


class TestAttackPathApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        cls._saved = []
        cls.cm_id = tm_app._save_report(_cm_report_from_source(), "AP CM fixture")
        cls._saved.append(cls.cm_id)
        cls.dast_id = tm_app._save_report(_dast(locus="/hook"), "AP DAST fixture")
        cls._saved.append(cls.dast_id)

    @classmethod
    def tearDownClass(cls):
        for rid in cls._saved:
            cls.client.delete(f"/api/v1/reports/{rid}",
                              headers={"X-CSRF-Token": cls.csrf})

    def _post(self, body):
        return self.client.post("/api/v1/correlate/attack-paths", json=body,
                                headers={"X-CSRF-Token": self.csrf})

    def test_synthesize_with_evidence(self):
        r = self._post({"codemodel_report_id": self.cm_id,
                        "evidence_report_ids": [self.dast_id]})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        j = r.get_json()
        self.assertGreaterEqual(j["paths_total"], 1)
        self.assertGreaterEqual(j["confirmed"], 1)   # /hook confirmed by DAST
        self._saved.append(j["report_id"])

    def test_missing_codemodel_id_rejected(self):
        self.assertEqual(self._post({}).status_code, 400)

    def test_wrong_methodology_rejected(self):
        r = self._post({"codemodel_report_id": self.dast_id})   # a DAST report
        self.assertEqual(r.status_code, 400)
        self.assertIn("not a code-derived model", r.get_json()["error"])

    def test_unknown_codemodel_id_404(self):
        r = self._post({"codemodel_report_id": "nonexistent_1_00"})
        self.assertEqual(r.status_code, 404)


if __name__ == "__main__":
    unittest.main()
