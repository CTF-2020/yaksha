"""Static + functional guards for report-viewer output encoding.

The report viewer renders findings client-side with innerHTML, and finding
content now originates from untrusted sources (repo file contents via SAST, and
arbitrary reports via the token-gated /import endpoint). These tests lock in the
escaping fixes so a regression re-opens neither the stored-XSS holes nor the
U+2028/U+2029 syntax error that a naive escaper introduced.

Run:  python -m unittest test_viewer_security
"""
from __future__ import annotations

import io
import os
import re
import shutil
import subprocess
import unittest

_TEMPLATE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "templates", "index.html")


def _html() -> str:
    with io.open(_TEMPLATE, encoding="utf-8") as fh:
        return fh.read()


class TestEscaperStatic(unittest.TestCase):
    def setUp(self):
        self.html = _html()

    def test_single_esc_definition(self):
        # A duplicate definition previously shadowed the hardened one.
        self.assertEqual(self.html.count("function esc(s)"), 1)

    def test_esc_escapes_quote_and_angles(self):
        body = self.html[self.html.index("function esc(s)"):][:400]
        for needle in ("&amp;", "&lt;", "&gt;", "&quot;", "&#39;"):
            self.assertIn(needle, body, f"esc() must produce {needle}")

    def test_escattrjs_defined(self):
        self.assertIn("function escAttrJs(s)", self.html)

    def test_no_raw_line_separators(self):
        # Raw U+2028/U+2029 inside a regex/JS literal is a parse error that would
        # break the entire page script; they must be written as \u escapes.
        self.assertNotIn(chr(0x2028), self.html)
        self.assertNotIn(chr(0x2029), self.html)

    def test_known_sinks_are_escaped(self):
        # None of these untrusted fields may be interpolated raw into innerHTML.
        forbidden = [
            r">${risk}<",
            r">${t.risk}<",
            r">${overall} Risk<",
            r"${report.analyzed_at || ''}</div>",   # must be esc()'d
        ]
        for frag in forbidden:
            self.assertNotIn(frag, self.html, f"unescaped sink present: {frag}")

    def test_onclick_uses_js_attr_escaper(self):
        # The STRIDE detail toggle passes an untrusted component into a JS string
        # inside an attribute — it must go through escAttrJs, not plain esc.
        m = re.search(r"toggleStrideDetail\(this,'\$\{(\w+)\(row\.component\)", self.html)
        self.assertIsNotNone(m, "toggleStrideDetail onclick not found")
        self.assertEqual(m.group(1), "escAttrJs")


@unittest.skipUnless(shutil.which("node"), "node not available for functional check")
class TestEscaperFunctional(unittest.TestCase):
    """Execute the real esc/escAttrJs against breakout payloads via node."""

    def _grab(self, html: str, name: str) -> str:
        i = html.index(f"function {name}(")
        return html[i:html.index("\n}", i) + 2]

    def test_no_js_string_breakout(self):
        html = _html()
        harness = self._grab(html, "esc") + "\n" + self._grab(html, "escAttrJs") + r'''
function htmlDecode(s){return s.replace(/&#39;/g,"'").replace(/&quot;/g,'"').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');}
globalThis.pwn=()=>{globalThis.__break=true;};
const payloads=["a'/**/;pwn();//","a\");pwn();(\"","x\\","a'-pwn()-'b","</span><img src=x onerror=pwn()>"];
let any=false;
for(const p of payloads){
  globalThis.__break=false;
  const src=htmlDecode("f(this,'"+escAttrJs(p)+"_S')").replace(/\bthis\b/g,"null").replace(/\bf\(/g,"(function(){})(");
  try{ new Function(src)(); }catch(e){}
  any = any || globalThis.__break;
}
process.stdout.write(any ? "BREAKOUT" : "SAFE");
'''
        f = os.path.join(os.path.dirname(_TEMPLATE), "..", "_viewer_xss_check.js")
        with io.open(f, "w", encoding="utf-8", newline="") as fh:
            fh.write(harness)
        try:
            r = subprocess.run(["node", f], capture_output=True, text=True, timeout=30)
        finally:
            os.remove(f)
        self.assertEqual(r.returncode, 0, f"script failed to parse/run: {r.stderr[:300]}")
        self.assertEqual(r.stdout.strip(), "SAFE", "a payload broke out of the JS string")


if __name__ == "__main__":
    unittest.main(verbosity=2)
