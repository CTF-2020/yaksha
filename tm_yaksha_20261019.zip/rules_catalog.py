"""In-process query layer over the semgrep rule reference catalog.

The catalog itself (data/semgrep_rules.json) holds rule *metadata only* — see the
`_notice` block in that file. This module loads it once and offers search, faceted
filtering, pagination, and single-rule lookup for the /rules dashboard and its API.

Stdlib only; no import-time side effects beyond a lazy cached read.
"""
from __future__ import annotations

import functools
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

_DATA = Path(__file__).resolve().parent / "data" / "semgrep_rules.json"

# semgrep severities -> the Critical/High/Medium/Low/Info scale the TM UI badges use.
_SEV_LABEL = {
    "ERROR": "High",
    "WARNING": "Medium",
    "MEDIUM": "Medium",
    "INFO": "Info",
}
_SEV_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}


def sev_label(raw: str) -> str:
    return _SEV_LABEL.get(str(raw or "").upper(), "Info")


@functools.lru_cache(maxsize=1)
def _payload() -> Dict[str, Any]:
    if not _DATA.exists():
        return {"_notice": {"rule_count": 0, "note": "catalog file missing"}, "rules": []}
    data = json.loads(_DATA.read_text(encoding="utf-8"))
    for r in data.get("rules", []):
        r["sev_label"] = sev_label(r.get("severity"))
        # a single lowercased haystack for fast substring search
        r["_hay"] = " ".join([
            r.get("id", ""), r.get("name", ""), r.get("message", ""),
            " ".join(r.get("cwe", [])), " ".join(r.get("owasp", [])),
            " ".join(r.get("technology", [])), r.get("language", ""), r.get("category", ""),
        ]).lower()
    return data


def reload() -> None:
    """Drop the cache (used by tests that swap the data file)."""
    _payload.cache_clear()
    _cwe_index.cache_clear()


@functools.lru_cache(maxsize=1)
def _cwe_index() -> Dict[str, List[Dict[str, Any]]]:
    idx: Dict[str, List[Dict[str, Any]]] = {}
    for r in all_rules():
        for c in r.get("cwe", []):
            idx.setdefault(str(c).strip().upper(), []).append(r)
    return idx


def related(cwes: Optional[List[str]], limit: int = 3) -> List[Dict[str, Any]]:
    """Catalog entries sharing a CWE with a generated finding.

    Lets a SAST/Codemodel finding cite prior art instead of standing as an
    isolated claim — "this pattern is also flagged by N rules across
    semgrep-community/gitlab-sast-rules" — without vendoring any detection
    logic (the catalog is metadata-only; see the `_notice` block). Matches on
    CWE only (unambiguous numeric ids); OWASP category strings differ in
    shape per ruleset and per methodology, too fuzzy to cross-reference
    safely. Returns `[]` — never fabricated — when there's no CWE or no match.
    """
    wanted = {str(c).strip().upper() for c in (cwes or []) if c}
    if not wanted:
        return []
    idx = _cwe_index()
    out: List[Dict[str, Any]] = []
    seen_names = set()
    for cwe in sorted(wanted):
        for r in idx.get(cwe, []):
            name = r.get("name", "")
            if not name or name in seen_names:
                continue
            seen_names.add(name)
            out.append({
                "id": r.get("id", ""), "key": r.get("key", ""), "name": name,
                "ruleset": r.get("ruleset", ""), "language": r.get("language", ""),
                "cwe": list(r.get("cwe", [])),
                # OWASP-style risk-rating metadata carried by ~70% of the
                # catalog (gitlab-sast-rules mainly) -- "" when the source
                # ruleset didn't tag it, never fabricated. See
                # app.py:_enrich_with_rule_references (aggregates this into
                # a category-level rule_risk_rating fact) and
                # correlator/engine.py (folds it into confidence scoring).
                "confidence": str(r.get("confidence") or ""),
                "likelihood": str(r.get("likelihood") or ""),
                "impact": str(r.get("impact") or ""),
            })
            if len(out) >= limit:
                return out
    return out


def notice() -> Dict[str, Any]:
    return dict(_payload().get("_notice", {}))


def all_rules() -> List[Dict[str, Any]]:
    return _payload().get("rules", [])


def _public(r: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in r.items() if not k.startswith("_")}


def facets() -> Dict[str, List[Dict[str, Any]]]:
    """Value -> count for the filterable dimensions, most common first."""
    dims = {"language": {}, "category": {}, "sev_label": {}, "ruleset": {}}
    for r in all_rules():
        for dim in dims:
            key = r.get(dim) or "other"
            dims[dim][key] = dims[dim].get(key, 0) + 1
    out: Dict[str, List[Dict[str, Any]]] = {}
    for dim, counts in dims.items():
        items = [{"value": k, "count": v} for k, v in counts.items()]
        if dim == "sev_label":
            items.sort(key=lambda i: _SEV_ORDER.get(i["value"], 9))
        else:
            items.sort(key=lambda i: (-i["count"], i["value"]))
        out[dim] = items
    return out


def query(
    q: Optional[str] = None,
    language: Optional[str] = None,
    category: Optional[str] = None,
    severity: Optional[str] = None,
    ruleset: Optional[str] = None,
    cwe: Optional[str] = None,
    owasp: Optional[str] = None,
    page: int = 1,
    per_page: int = 50,
) -> Dict[str, Any]:
    """Filter + paginate. All filters combine with AND; `q` is a substring match."""
    rules = all_rules()
    ql = (q or "").strip().lower()
    cwl = (cwe or "").strip().lower()
    owl = (owasp or "").strip().lower()

    def keep(r: Dict[str, Any]) -> bool:
        if ql and ql not in r["_hay"]:
            return False
        if language and r.get("language") != language:
            return False
        if category and r.get("category") != category:
            return False
        if severity and r.get("sev_label") != severity:
            return False
        if ruleset and r.get("ruleset") != ruleset:
            return False
        if cwl and not any(cwl in c.lower() for c in r.get("cwe", [])):
            return False
        if owl and not any(owl in o.lower() for o in r.get("owasp", [])):
            return False
        return True

    matched = [r for r in rules if keep(r)]
    total = len(matched)
    per_page = max(1, min(int(per_page or 50), 200))
    page = max(1, int(page or 1))
    start = (page - 1) * per_page
    window = matched[start:start + per_page]

    by_sev: Dict[str, int] = {}
    for r in matched:
        key = r.get("sev_label") or "Info"
        by_sev[key] = by_sev.get(key, 0) + 1
    by_severity = sorted(
        ({"value": k, "count": v} for k, v in by_sev.items()),
        key=lambda i: _SEV_ORDER.get(i["value"], 9))

    return {
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": (total + per_page - 1) // per_page,
        "rules": [_public(r) for r in window],
        "by_severity": by_severity,
    }


def get(key: str) -> Optional[Dict[str, Any]]:
    if not key:
        return None
    for r in all_rules():
        if r.get("key") == key or r.get("id") == key:
            return _public(r)
    return None


def stats() -> Dict[str, Any]:
    rules = all_rules()
    by_ruleset: Dict[str, int] = {}
    for r in rules:
        rs = r.get("ruleset") or "unknown"
        by_ruleset[rs] = by_ruleset.get(rs, 0) + 1
    return {
        "total": len(rules),
        "with_cwe": sum(1 for r in rules if r.get("cwe")),
        "with_owasp": sum(1 for r in rules if r.get("owasp")),
        "security": sum(1 for r in rules if r.get("category") == "security"),
        "languages": len({r.get("language") for r in rules}),
        "by_ruleset": by_ruleset,
        "notice": notice(),
    }
