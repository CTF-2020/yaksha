"""Tests for the risk-acceptance / suppression workflow.

Covers the fingerprint's stability guarantees (survives re-scan + line edits,
distinguishes genuinely different findings), the store's durability/validation,
the engine's scoped matching + expiry + report scoping, and the read-time
report annotation (severity recompute). API tests exercise the blueprint end to
end through the Flask test client with CSRF, against an isolated store path."""
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

import regression
import suppressions
import verdict_tracking
from suppressions import db, engine, model, store


def _cat(cid="WEB-A03-01", family="sql-injection", cwe="CWE-89",
         components=None, name="Injection", risk="High", threats=None,
         verdict=None):
    cat = {
        "id": cid, "name": name, "family": family, "cwe": cwe, "risk": risk,
        "affected_components": components if components is not None
        else ["GET /x → execute (app.py:7)"],
        "threats": threats or [],
    }
    if verdict:
        cat["verdict"] = verdict
    return cat


class TestFingerprint(unittest.TestCase):
    def test_stable_across_line_number_changes(self):
        a = _cat(components=["GET /x → execute (app.py:7)"])
        b = _cat(components=["GET /x → execute (app.py:42)"])
        self.assertEqual(engine.finding_fingerprint(a),
                         engine.finding_fingerprint(b))

    def test_stable_across_component_order(self):
        a = _cat(components=["a.py:1", "b.py:2"])
        b = _cat(components=["b.py:99", "a.py:5"])
        self.assertEqual(engine.finding_fingerprint(a),
                         engine.finding_fingerprint(b))

    def test_different_file_is_different_finding(self):
        a = _cat(components=["app.py:7"])
        b = _cat(components=["other.py:7"])
        self.assertNotEqual(engine.finding_fingerprint(a),
                            engine.finding_fingerprint(b))

    def test_different_rule_is_different_finding(self):
        a = _cat(cid="WEB-A03-01")
        b = _cat(cid="WEB-A01-01")
        self.assertNotEqual(engine.finding_fingerprint(a),
                            engine.finding_fingerprint(b))

    def test_threat_loci_participate(self):
        a = _cat(components=[], threats=[{"name": "GET /x (app.py:5)"}])
        b = _cat(components=[], threats=[{"name": "GET /x (app.py:9)"}])
        self.assertEqual(engine.finding_fingerprint(a),
                         engine.finding_fingerprint(b))


class TestModelValidation(unittest.TestCase):
    def test_requires_reason_author_scope(self):
        with self.assertRaises(ValueError):
            model.Suppression.from_dict({"scope": "finding", "match": "x",
                                         "author": "me"})  # no reason
        with self.assertRaises(ValueError):
            model.Suppression.from_dict({"scope": "finding", "match": "x",
                                         "reason": "ok because", "author": ""})
        with self.assertRaises(ValueError):
            model.Suppression.from_dict({"scope": "bogus", "match": "x",
                                         "reason": "ok because", "author": "me"})

    def test_valid_record_roundtrips(self):
        s = model.Suppression.from_dict({
            "scope": "family", "match": "sql-injection",
            "reason": "compensating WAF control in place",
            "author": "alice", "state": "accepted", "expires_at": 0})
        d = s.to_dict()
        self.assertEqual(model.Suppression.from_dict(d).match, "sql-injection")

    def test_expiry(self):
        past = model.Suppression.from_dict({
            "scope": "rule", "match": "WEB-A03-01", "reason": "temporary",
            "author": "bob", "expires_at": 1000})
        self.assertTrue(past.is_expired(2000))
        self.assertFalse(past.is_expired(500))

    def test_max_verdict_defaults_empty_and_is_optional(self):
        s = model.Suppression.from_dict({
            "scope": "rule", "match": "WEB-A03-01",
            "reason": "ok because", "author": "me"})
        self.assertEqual(s.max_verdict, "")

    def test_max_verdict_rejects_unknown_value(self):
        with self.assertRaises(ValueError):
            model.Suppression.from_dict({
                "scope": "rule", "match": "WEB-A03-01", "reason": "ok because",
                "author": "me", "max_verdict": "very_bad"})

    def test_max_verdict_valid_value_roundtrips(self):
        s = model.Suppression.from_dict({
            "scope": "family", "match": "sql-injection", "reason": "ok because",
            "author": "me", "max_verdict": "design_gap"})
        d = s.to_dict()
        self.assertEqual(model.Suppression.from_dict(d).max_verdict, "design_gap")

    def test_verdict_defaults_empty_and_is_optional(self):
        s = model.Suppression.from_dict({
            "scope": "finding", "match": "fp1", "reason": "ok because", "author": "me"})
        self.assertEqual(s.verdict, "")

    def test_verdict_rejects_unknown_value(self):
        with self.assertRaises(ValueError):
            model.Suppression.from_dict({
                "scope": "finding", "match": "fp1", "reason": "ok because",
                "author": "me", "verdict": "very_bad"})


class TestVerdictAwareExpiry(unittest.TestCase):
    def test_cap_expiry_leaves_unverdicted_untouched(self):
        self.assertEqual(model.cap_expiry_for_verdict(0, "", 1000.0), 0)

    def test_cap_expiry_forces_never_expires_down_to_the_cap(self):
        out = model.cap_expiry_for_verdict(0, "confirmed_exploitable", 1000.0)
        self.assertEqual(out, 1000.0 + model.MAX_EXPIRY_DAYS["confirmed_exploitable"] * 86400)

    def test_cap_expiry_pulls_in_a_later_requested_date(self):
        far_future = 1000.0 + 9999 * 86400
        out = model.cap_expiry_for_verdict(far_future, "actively_exploited", 1000.0)
        self.assertEqual(out, 1000.0 + model.MAX_EXPIRY_DAYS["actively_exploited"] * 86400)

    def test_cap_expiry_leaves_a_shorter_requested_date_alone(self):
        soon = 1000.0 + 2 * 86400
        out = model.cap_expiry_for_verdict(soon, "confirmed_exploitable", 1000.0)
        self.assertEqual(out, soon)

    def test_actively_exploited_gets_the_shortest_cap(self):
        self.assertLess(model.MAX_EXPIRY_DAYS["actively_exploited"],
                        model.MAX_EXPIRY_DAYS["confirmed_exploitable"])
        self.assertLess(model.MAX_EXPIRY_DAYS["confirmed_exploitable"],
                        model.MAX_EXPIRY_DAYS["design_gap"])

    def test_from_dict_applies_cap_via_verdict_field(self):
        s = model.Suppression.from_dict({
            "scope": "finding", "match": "fp1", "reason": "ok because",
            "author": "me", "verdict": "confirmed_exploitable",
            "created_at": 1000.0, "expires_at": 0})
        self.assertEqual(s.expires_at, 1000.0 + model.MAX_EXPIRY_DAYS["confirmed_exploitable"] * 86400)

    def test_from_dict_falls_back_to_max_verdict_when_verdict_absent(self):
        s = model.Suppression.from_dict({
            "scope": "family", "match": "sql-injection", "reason": "ok because",
            "author": "me", "max_verdict": "actively_exploited",
            "created_at": 1000.0, "expires_at": 0})
        self.assertEqual(s.expires_at, 1000.0 + model.MAX_EXPIRY_DAYS["actively_exploited"] * 86400)

    def test_false_positive_state_is_not_capped(self):
        s = model.Suppression.from_dict({
            "scope": "finding", "match": "fp1", "reason": "not real",
            "author": "me", "state": "false_positive", "verdict": "actively_exploited",
            "created_at": 1000.0, "expires_at": 0})
        self.assertEqual(s.expires_at, 0)

    def test_wont_fix_state_is_not_capped(self):
        s = model.Suppression.from_dict({
            "scope": "finding", "match": "fp1", "reason": "deprecated component",
            "author": "me", "state": "wont_fix", "verdict": "confirmed_exploitable",
            "created_at": 1000.0, "expires_at": 0})
        self.assertEqual(s.expires_at, 0)

    def test_uncorrelated_finding_is_not_capped(self):
        # No verdict and no max_verdict -- a plain SAST/manual finding never
        # touched the correlator, so there's no verdict-based policy to apply.
        s = model.Suppression.from_dict({
            "scope": "finding", "match": "fp1", "reason": "ok because",
            "author": "me", "created_at": 1000.0, "expires_at": 0})
        self.assertEqual(s.expires_at, 0)


class TestStore(unittest.TestCase):
    """Isolates onto a temp DB, like test_report_db.py's TestReportDbModule."""

    def setUp(self):
        self._orig_db_path = db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        db.DB_PATH = Path(self._td.name) / "suppressions.db"
        db.init()

    def _restore(self):
        db.DB_PATH = self._orig_db_path

    def test_add_list_delete(self):
        s = store.add_suppression({
            "scope": "finding", "match": "abc123", "reason": "false positive here",
            "author": "carol", "state": "false_positive"})
        listed = store.list_suppressions()
        self.assertEqual(len(listed), 1)
        self.assertFalse(listed[0]["expired"])
        self.assertTrue(store.delete_suppression(s.id))
        self.assertEqual(store.list_suppressions(), [])

    def test_dedup_replaces_same_scope_match_report(self):
        store.add_suppression({"scope": "rule", "match": "WEB-A03-01",
                               "reason": "first reason", "author": "a"})
        store.add_suppression({"scope": "rule", "match": "WEB-A03-01",
                               "reason": "second reason", "author": "b"})
        items = store.list_suppressions()
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["reason"], "second reason")

    def test_max_verdict_persists_through_sqlite_roundtrip(self):
        s = store.add_suppression({
            "scope": "family", "match": "sql-injection", "reason": "compensating control",
            "author": "dana", "max_verdict": "corroborated"})
        listed = store.list_suppressions()
        self.assertEqual(listed[0]["max_verdict"], "corroborated")
        self.assertEqual(store.load_suppressions()[0].max_verdict, "corroborated")

    def test_verdict_persists_through_sqlite_roundtrip(self):
        store.add_suppression({
            "scope": "finding", "match": "fp1", "reason": "risk accepted",
            "author": "dana", "verdict": "confirmed_exploitable"})
        listed = store.list_suppressions()
        self.assertEqual(listed[0]["verdict"], "confirmed_exploitable")
        self.assertEqual(store.load_suppressions()[0].verdict, "confirmed_exploitable")
        # expires_at was capped on the way in (0 -> forced by the verdict).
        self.assertNotEqual(listed[0]["expires_at"], 0)

    def test_prune_expired(self):
        store.add_suppression({"scope": "rule", "match": "R1", "reason": "temp",
                               "author": "a", "expires_at": 1000})
        store.add_suppression({"scope": "rule", "match": "R2", "reason": "keep",
                               "author": "a"})
        self.assertEqual(store.prune_expired(now=5000), 1)
        self.assertEqual(len(store.load_suppressions()), 1)


class TestEngineMatching(unittest.TestCase):
    def _supp(self, **kw):
        base = {"reason": "accepted risk here", "author": "me"}
        base.update(kw)
        return model.Suppression.from_dict(base)

    def test_finding_scope_matches_only_that_fingerprint(self):
        cat = _cat()
        fp = engine.finding_fingerprint(cat)
        s = self._supp(scope="finding", match=fp)
        self.assertTrue(engine.matches(s, cat))
        self.assertFalse(engine.matches(s, _cat(cid="WEB-A01-01")))

    def test_family_scope_matches_all_of_family(self):
        s = self._supp(scope="family", match="sql-injection")
        self.assertTrue(engine.matches(s, _cat(cid="WEB-A03-01")))
        self.assertTrue(engine.matches(s, _cat(cid="CM-002")))
        self.assertFalse(engine.matches(s, _cat(family="xss")))

    def test_rule_scope_matches_rule_id(self):
        s = self._supp(scope="rule", match="WEB-A03-01")
        self.assertTrue(engine.matches(s, _cat(cid="WEB-A03-01")))
        self.assertFalse(engine.matches(s, _cat(cid="WEB-A03-02")))

    def test_expired_suppression_does_not_match(self):
        cat = _cat()
        s = self._supp(scope="family", match="sql-injection", expires_at=1000)
        self.assertFalse(engine.matches(s, cat, now=2000))
        self.assertTrue(engine.matches(s, cat, now=500))

    def test_report_scoped_suppression(self):
        cat = _cat()
        s = self._supp(scope="family", match="sql-injection", report_id="R1")
        self.assertTrue(engine.matches(s, cat, report_id="R1"))
        self.assertFalse(engine.matches(s, cat, report_id="R2"))

    def test_max_verdict_blocks_more_actionable_finding(self):
        # a family-wide suppression capped at "design_gap" must not silently
        # swallow a confirmed_exploitable instance of that same family.
        s = self._supp(scope="family", match="sql-injection", max_verdict="design_gap")
        blocked = _cat(verdict="confirmed_exploitable")
        allowed = _cat(verdict="design_gap")
        self.assertFalse(engine.matches(s, blocked))
        self.assertTrue(engine.matches(s, allowed))

    def test_max_verdict_allows_equally_or_less_actionable_finding(self):
        s = self._supp(scope="family", match="sql-injection", max_verdict="corroborated")
        self.assertTrue(engine.matches(s, _cat(verdict="corroborated")))
        self.assertTrue(engine.matches(s, _cat(verdict="blind_spot")))
        self.assertFalse(engine.matches(s, _cat(verdict="confirmed_exploitable")))

    def test_max_verdict_ignored_for_findings_without_a_verdict(self):
        # plain SAST/manual findings never went through the correlator and so
        # carry no "verdict" key at all — max_verdict must not block those.
        s = self._supp(scope="family", match="sql-injection", max_verdict="confirmed_exploitable")
        self.assertTrue(engine.matches(s, _cat()))  # no verdict param passed


class TestEngineMatchesRow(unittest.TestCase):
    """matches_row() is the triage worklist's row-shaped twin of matches() --
    it must agree with matches() on every case, since it's meant to be an exact
    identity check against report_db's SQL findings table, not an approximation."""

    def _supp(self, **kw):
        base = {"reason": "accepted risk here", "author": "me"}
        base.update(kw)
        return model.Suppression.from_dict(base)

    def _row(self, cat, report_id=""):
        return {"rule": cat.get("id", ""), "family": cat.get("family", ""),
                "fingerprint": engine.finding_fingerprint(cat),
                "verdict": cat.get("verdict") or "", "report_id": report_id}

    def test_finding_scope_matches_only_that_fingerprint(self):
        cat = _cat()
        fp = engine.finding_fingerprint(cat)
        s = self._supp(scope="finding", match=fp)
        self.assertTrue(engine.matches_row(s, self._row(cat)))
        self.assertFalse(engine.matches_row(s, self._row(_cat(cid="WEB-A01-01"))))

    def test_family_scope_matches_all_of_family(self):
        s = self._supp(scope="family", match="sql-injection")
        self.assertTrue(engine.matches_row(s, self._row(_cat(cid="WEB-A03-01"))))
        self.assertFalse(engine.matches_row(s, self._row(_cat(family="xss"))))

    def test_rule_scope_matches_rule_id(self):
        s = self._supp(scope="rule", match="WEB-A03-01")
        self.assertTrue(engine.matches_row(s, self._row(_cat(cid="WEB-A03-01"))))
        self.assertFalse(engine.matches_row(s, self._row(_cat(cid="WEB-A03-02"))))

    def test_report_scoped_suppression(self):
        cat = _cat()
        s = self._supp(scope="family", match="sql-injection", report_id="R1")
        self.assertTrue(engine.matches_row(s, self._row(cat, report_id="R1")))
        self.assertFalse(engine.matches_row(s, self._row(cat, report_id="R2")))

    def test_max_verdict_blocks_more_actionable_finding(self):
        s = self._supp(scope="family", match="sql-injection", max_verdict="design_gap")
        blocked = _cat(verdict="confirmed_exploitable")
        allowed = _cat(verdict="design_gap")
        self.assertFalse(engine.matches_row(s, self._row(blocked)))
        self.assertTrue(engine.matches_row(s, self._row(allowed)))

    def test_agrees_with_matches_across_cases(self):
        cats = [_cat(), _cat(cid="WEB-A01-01"), _cat(family="xss"),
               _cat(verdict="confirmed_exploitable"), _cat(verdict="design_gap")]
        supps = [self._supp(scope="finding", match=engine.finding_fingerprint(_cat())),
                self._supp(scope="family", match="sql-injection"),
                self._supp(scope="rule", match="WEB-A03-01"),
                self._supp(scope="family", match="sql-injection", max_verdict="design_gap")]
        for s in supps:
            for cat in cats:
                self.assertEqual(engine.matches(s, cat), engine.matches_row(s, self._row(cat)),
                                 f"disagreement for scope={s.scope} cat_id={cat.get('id')}")


class TestAnnotateReport(unittest.TestCase):
    def _report(self):
        return {
            "id": "R1",
            "categories": [
                _cat(cid="WEB-A03-01", family="sql-injection", risk="Critical"),
                _cat(cid="WEB-A07-01", family="auth", cwe="CWE-287",
                     name="Auth", risk="High",
                     components=["POST /login (login.py:3)"]),
            ],
        }

    def test_suppressed_finding_drops_from_active_posture(self):
        rep = self._report()
        s = model.Suppression.from_dict({
            "scope": "family", "match": "sql-injection",
            "reason": "compensating control", "author": "me"})
        out = engine.annotate_report(rep, [s])
        cats = {c["id"]: c for c in out["categories"]}
        self.assertTrue(cats["WEB-A03-01"]["suppressed"])
        self.assertFalse(cats["WEB-A07-01"]["suppressed"])
        self.assertEqual(out["active_severity_counts"]["Critical"], 0)
        self.assertEqual(out["active_severity_counts"]["High"], 1)
        self.assertEqual(out["suppressed_severity_counts"]["Critical"], 1)
        self.assertEqual(out["suppression_summary"]["suppressed"], 1)
        self.assertEqual(out["suppression_summary"]["active"], 1)

    def test_does_not_mutate_input(self):
        rep = self._report()
        engine.annotate_report(rep, [])
        self.assertNotIn("suppressed", rep["categories"][0])

    def test_carries_fingerprint_for_ui(self):
        out = engine.annotate_report(self._report(), [])
        self.assertTrue(all(c.get("fingerprint") for c in out["categories"]))

    def test_max_verdict_guardrail_applies_during_annotation(self):
        rep = self._report()
        rep["categories"][0]["verdict"] = "confirmed_exploitable"
        s = model.Suppression.from_dict({
            "scope": "family", "match": "sql-injection", "max_verdict": "design_gap",
            "reason": "compensating control for the design-gap case only",
            "author": "me"})
        out = engine.annotate_report(rep, [s])
        cats = {c["id"]: c for c in out["categories"]}
        self.assertFalse(cats["WEB-A03-01"]["suppressed"])
        self.assertEqual(out["active_severity_counts"]["Critical"], 1)


class TestSuppressionAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.tm_app = tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        # point every store entrypoint at an isolated DB + JSON backup file
        self._patchers = [
            mock.patch.object(db, "DB_PATH", Path(self.tmp) / "suppressions.db"),
            mock.patch.object(store, "_BACKUP_PATH", Path(self.tmp) / "supp.json"),
        ]
        for p in self._patchers:
            p.start()

    def tearDown(self):
        for p in self._patchers:
            p.stop()

    def _token(self):
        return self.client.get("/api/csrf-token").get_json()["token"]

    def test_create_list_delete_cycle(self):
        token = self._token()
        r = self.client.post("/api/v1/suppressions",
                             json={"scope": "rule", "match": "WEB-A03-01",
                                   "reason": "accepted for legacy module",
                                   "author": "alice"},
                             headers={"X-CSRF-Token": token})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        supp_id = r.get_json()["suppression"]["id"]

        listed = self.client.get("/api/v1/suppressions").get_json()
        self.assertEqual(listed["count"], 1)

        d = self.client.delete(f"/api/v1/suppressions/{supp_id}",
                               headers={"X-CSRF-Token": token})
        self.assertEqual(d.status_code, 200)
        self.assertEqual(self.client.get("/api/v1/suppressions")
                         .get_json()["count"], 0)

    def test_create_accepts_max_verdict(self):
        token = self._token()
        r = self.client.post("/api/v1/suppressions",
                             json={"scope": "family", "match": "sql-injection",
                                   "reason": "accepted for legacy module",
                                   "author": "alice", "max_verdict": "design_gap"},
                             headers={"X-CSRF-Token": token})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        self.assertEqual(r.get_json()["suppression"]["max_verdict"], "design_gap")

    def test_create_rejects_bad_max_verdict(self):
        token = self._token()
        r = self.client.post("/api/v1/suppressions",
                             json={"scope": "rule", "match": "X", "author": "a",
                                   "reason": "because", "max_verdict": "nope"},
                             headers={"X-CSRF-Token": token})
        self.assertEqual(r.status_code, 400)

    def test_create_rejects_missing_reason(self):
        token = self._token()
        r = self.client.post("/api/v1/suppressions",
                             json={"scope": "rule", "match": "X", "author": "a"},
                             headers={"X-CSRF-Token": token})
        self.assertEqual(r.status_code, 400)

    def test_create_requires_csrf(self):
        r = self.client.post("/api/v1/suppressions",
                             json={"scope": "rule", "match": "X",
                                   "reason": "because", "author": "a"})
        self.assertEqual(r.status_code, 403)

    def test_suppress_finding_captures_verdict_and_caps_expiry(self):
        # A verdict-carrying category also drives app.py's best-effort
        # verdict_tracking/regression sync on save -- isolate both onto this
        # test's temp dir too, not just the suppression store (see project
        # memory on real ~/.tm_* store pollution from unisolated tests).
        with mock.patch.object(verdict_tracking, "DB_PATH", Path(self.tmp) / "verdicts.db"), \
             mock.patch.object(regression, "DB_PATH", Path(self.tmp) / "regression.db"):
            token = self._token()
            report = {"title": "t", "methodology": "correlation", "categories": [
                _cat(cid="CORR-001", family="sql-injection", risk="Critical",
                    verdict="confirmed_exploitable")]}
            rid = self.tm_app._save_report(report, "t")
            try:
                r = self.client.post(f"/api/v1/reports/{rid}/suppress",
                                     json={"index": 0, "reason": "risk accepted by AppSec",
                                           "author": "carol", "expires_at": 0},
                                     headers={"X-CSRF-Token": token})
                self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
                supp = r.get_json()["suppression"]
                self.assertEqual(supp["verdict"], "confirmed_exploitable")
                self.assertNotEqual(supp["expires_at"], 0)   # never-expires was forced down
                max_days = model.MAX_EXPIRY_DAYS["confirmed_exploitable"]
                self.assertLessEqual(supp["expires_at"], supp["created_at"] + max_days * 86400 + 1)
            finally:
                self.tm_app.report_db.delete_report(rid)
                try:
                    os.unlink(self.tm_app.REPORTS_DIR / f"{rid}.json")
                except OSError:
                    pass

    def test_suppress_finding_by_index_then_reflected(self):
        # save a real codemodel-style report through the app store
        token = self._token()
        report = {"title": "t", "methodology": "codemodel", "categories": [
            _cat(cid="CM-001", family="sql-injection", risk="Critical")]}
        rid = self.tm_app._save_report(report, "t")
        try:
            r = self.client.post(f"/api/v1/reports/{rid}/suppress",
                                 json={"index": 0, "reason": "risk accepted by AppSec",
                                       "author": "carol"},
                                 headers={"X-CSRF-Token": token})
            self.assertEqual(r.status_code, 201, r.get_data(as_text=True))

            view = self.client.get(f"/api/v1/reports/{rid}/suppressed").get_json()
            self.assertEqual(view["summary"]["suppressed"], 1)
            self.assertEqual(view["active_severity_counts"]["Critical"], 0)
            self.assertTrue(view["findings"][0]["suppressed"])
        finally:
            self.tm_app.report_db.delete_report(rid)
            try:
                os.unlink(self.tm_app.REPORTS_DIR / f"{rid}.json")
            except OSError:
                pass


if __name__ == "__main__":
    unittest.main()
