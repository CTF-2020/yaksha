"""Assemble the security-posture overview from the stores that already exist.

Read-only and defensive: each section is computed independently and wrapped so
a missing/broken store (no broker, no AIBOM inventory, empty DB) degrades that
one section to empty rather than failing the whole dashboard. Nothing here
starts a scan or reaches a network — it only summarizes saved state.

SAST broker and DAST scanner findings are deliberately EXCLUDED from the
cross-report severity totals/trend/families (they live under their own tabs;
see report_db's methodology exclusion) and surfaced instead as separate
"sast"/"dast" sections, so the dashboard mirrors the product's information
architecture.
"""
from __future__ import annotations

from datetime import datetime, timezone

import report_db
import suppressions
import verdict_tracking

_SEVS = ("Critical", "High", "Medium", "Low", "Info")
_EXCLUDED_METHODS = ("sast", "dast")


def _empty_sev() -> dict:
    return {s: 0 for s in _SEVS}


def _cat_severity(cat: dict) -> str:
    sev = str(cat.get("risk") or cat.get("severity") or "Info").capitalize()
    return sev if sev in _SEVS else "Info"


def _active_severity_totals() -> tuple[dict, int]:
    """Severity totals across viewer-visible reports, with suppressed
    findings excluded — the same accepted-risk/false-positive decisions the
    single-report viewer already applies (suppressions.annotate_report), just
    extended to the aggregate posture instead of stopping at one report.

    Counts one unit per affected-component *locus* within a non-suppressed
    category, matching report_db's own findings-table derivation exactly
    (reusing its locus splitter) — so these totals equal the pre-suppression
    numbers whenever nothing is actually suppressed, and only ever change
    because a finding was explicitly muted, not because the counting unit
    quietly changed underneath.
    """
    supps = suppressions.load_suppressions()
    sev = _empty_sev()
    total = 0
    for r in report_db.all_reports(limit=2000):
        if str(r.get("methodology", "")).lower() in _EXCLUDED_METHODS:
            continue
        annotated = suppressions.annotate_report(r, supps)
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            n = len(report_db._category_loci(cat))
            sev[_cat_severity(cat)] += n
            total += n
    return sev, total


def _threat_model_posture() -> dict:
    """Severity totals, methodology mix, trend and recent list across the
    viewer-visible (non-SAST) reports."""
    rows = report_db.trends(limit=1000)          # already excludes methodology='sast'
    by_meth: dict[str, int] = {}
    for r in rows:
        m = r.get("methodology") or "other"
        by_meth[m] = by_meth.get(m, 0) + 1

    sev, findings = _active_severity_totals()

    # Trend: oldest -> newest, capped, each point a severity breakdown.
    trend = []
    for r in reversed(rows[:24]):
        point = {"at": r.get("analyzed_at") or r.get("created_at"),
                 "total": int(r.get("total", 0) or 0),
                 "risk": r.get("overall_risk") or "Info"}
        point.update({s: int(r["severity_counts"].get(s, 0) or 0) for s in _SEVS})
        trend.append(point)

    recent = [{"id": r["id"], "title": r.get("title") or r["id"],
               "methodology": r.get("methodology") or "?",
               "overall_risk": r.get("overall_risk") or "Info",
               "analyzed_at": r.get("analyzed_at") or ""}
              for r in rows[:8]]

    return {
        "reports": len(rows),
        "findings": findings,
        "severity": sev,
        "critical_high": sev["Critical"] + sev["High"],
        "by_methodology": by_meth,
        "trend": trend,
        "recent": recent,
    }


def _families() -> list[dict]:
    """Weakness-family rollup across viewer-visible reports, suppressed
    categories excluded (see _active_severity_totals). Grouped with the
    correlator's own family taxonomy so the labels here line up with the
    Analyse/Correlate tabs instead of drifting into a second vocabulary."""
    from correlator import taxonomy   # pure; lazy to keep import graph light

    supps = suppressions.load_suppressions()
    agg: dict[str, dict] = {}
    for r in report_db.all_reports(limit=2000):
        if str(r.get("methodology", "")).lower() in _EXCLUDED_METHODS:
            continue
        annotated = suppressions.annotate_report(r, supps)
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            title = str(cat.get("title") or cat.get("name") or cat.get("id") or "Finding")
            cwes = taxonomy.extract_cwes(str(cat.get("cwe", "")), str(cat.get("notes", "")),
                                        str(cat.get("description", "")))
            owasp = taxonomy.extract_owasp(str(cat.get("id", "")), str(cat.get("owasp", "")),
                                           f"{title} {cat.get('notes', '')}")
            family, _ = taxonomy.resolve_family(title, cwes, owasp,
                                                notes=str(cat.get("notes", "")))
            n = len(report_db._category_loci(cat))
            bucket = agg.setdefault(family, {"family": family, "total": 0,
                                             "high_plus": 0, "reports": set()})
            bucket["total"] += n
            if _cat_severity(cat) in ("Critical", "High"):
                bucket["high_plus"] += n
            bucket["reports"].add(r.get("id"))

    out = [{"family": v["family"], "total": v["total"], "high_plus": v["high_plus"],
            "reports": len(v["reports"])} for v in agg.values()]
    out.sort(key=lambda f: (-f["high_plus"], -f["total"]))
    return out[:12]


def _verdicts() -> dict:
    """Correlator verdict rollup across viewer-visible reports, suppressed
    categories excluded (see _active_severity_totals).

    Only correlation-derived findings carry a ``verdict`` at all -- a plain
    SAST/manual/design-only finding never touched the correlator. Those are
    tallied separately as "unverdicted" rather than silently dropped, so a
    report with no correlation coverage reads as "not yet correlated" instead
    of masquerading as a clean confirmed_exploitable=0 bill of health.
    """
    from correlator.model import Verdict   # pure; lazy to keep import graph light

    order = [v.value for v in Verdict]     # most- to least-actionable
    supps = suppressions.load_suppressions()
    counts = {v: 0 for v in order}
    unverdicted = 0
    top_confirmed = []
    top_active = []
    for r in report_db.all_reports(limit=2000):
        if str(r.get("methodology", "")).lower() in _EXCLUDED_METHODS:
            continue
        annotated = suppressions.annotate_report(r, supps)
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            verdict = cat.get("verdict")
            n = len(report_db._category_loci(cat))
            if verdict not in counts:
                unverdicted += n
                continue
            counts[verdict] += n
            entry = {
                "report_id": r.get("id"), "report_title": r.get("title") or r.get("id"),
                "id": cat.get("id"), "name": cat.get("name") or cat.get("title") or cat.get("id"),
                "risk": _cat_severity(cat),
            }
            if verdict == Verdict.CONFIRMED_EXPLOITABLE.value:
                top_confirmed.append(entry)
            elif verdict == Verdict.ACTIVELY_EXPLOITED.value:
                top_active.append(entry)

    top_confirmed.sort(key=lambda f: _SEVS.index(f["risk"]) if f["risk"] in _SEVS else 99)
    top_active.sort(key=lambda f: _SEVS.index(f["risk"]) if f["risk"] in _SEVS else 99)
    return {
        "order": order,
        "counts": counts,
        "unverdicted": unverdicted,
        "total_correlated": sum(counts.values()),
        "top_confirmed": top_confirmed[:8],
        "top_active_incidents": top_active[:8],
    }


def _verdict_alerts() -> dict:
    """Recent verdict escalations (a finding got strictly more actionable
    since it was last seen -- see verdict_tracking.py) not yet acknowledged."""
    items = verdict_tracking.list_alerts(limit=8, unacknowledged_only=True)
    return {"unacknowledged": verdict_tracking.unacknowledged_count(), "recent": items}


def _verdict_sla() -> dict:
    """How long tracked findings have sat at their current verdict vs. that
    verdict's remediation window (verdict_tracking.sla_summary)."""
    return verdict_tracking.sla_summary()


def _verdict_trend() -> list[dict]:
    """Verdict-count time series across successive correlation runs, oldest
    first (chart-ready) -- same shape/ordering as threat_model.trend."""
    rows = report_db.verdict_trends(limit=24)
    return list(reversed(rows))


def _design_debt() -> dict:
    """Design-debt burn-down: is the design_gap backlog (modeled but
    unproven) shrinking or growing? See verdict_tracking.design_debt_summary."""
    summary = verdict_tracking.design_debt_summary()
    trend_rows = report_db.verdict_trends(limit=24)
    burndown = [{"id": r["id"], "title": r["title"], "analyzed_at": r["analyzed_at"],
                 "design_gap": r["verdict_counts"]["design_gap"]}
                for r in reversed(trend_rows)]
    return {**summary, "burndown": burndown}


def _governance() -> dict:
    """Ownership + risk-acceptance coverage across every actionable (i.e.
    verdict-carrying, non-suppressed) finding.

    Only correlated findings get a bucket-default owner (see ownership.py),
    so an uncorrelated finding is excluded from the denominator rather than
    counted as unowned -- same "correlated vs. not yet correlated" split
    _verdicts() already makes. Deduplicated by fingerprint across reports:
    the same underlying finding re-appearing in a later correlation run is
    one accountability line, not several.
    """
    import ownership
    from suppressions.engine import finding_fingerprint

    supps = suppressions.load_suppressions()
    seen: set[str] = set()
    rows = []
    for r in report_db.all_reports(limit=2000):
        if str(r.get("methodology", "")).lower() in _EXCLUDED_METHODS:
            continue
        annotated = suppressions.annotate_report(r, supps)
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            verdict = cat.get("verdict")
            if not verdict:
                continue
            fp = finding_fingerprint(cat)
            if fp in seen:
                continue
            seen.add(fp)
            rows.append({"fingerprint": fp, "verdict": verdict})

    ownership.annotate_rows(rows)
    total = len(rows)
    owned = sum(1 for row in rows if row.get("owner"))
    unowned_urgent = sum(1 for row in rows if not row.get("owner")
                        and row["verdict"] in ("actively_exploited", "confirmed_exploitable"))

    now = datetime.now(timezone.utc).timestamp()
    accepted = [s for s in supps if not s.is_expired(now)]
    by_state: dict[str, int] = {}
    for s in accepted:
        by_state[s.state] = by_state.get(s.state, 0) + 1

    return {
        "owned": owned,
        "unowned": total - owned,
        "total_actionable": total,
        "coverage_pct": round(100.0 * owned / total, 1) if total else 0.0,
        "unowned_urgent": unowned_urgent,
        "risk_accepted": len(accepted),
        "risk_accepted_by_state": by_state,
    }


def _reachable_dependencies() -> dict:
    """Vulnerable-dependency (SBOM) findings with a code-model-proven reachable
    call path (correlator.service.list_reachable_dependencies)."""
    from correlator import service as correlator_service   # lazy: keeps import graph light
    return correlator_service.list_reachable_dependencies()


def _verdict_reconciliation() -> dict:
    """Findings currently carrying different verdicts across two or more
    LIVE reports at once (not sequential drift over time -- see
    verdict_reconciliation.py for how this differs from verdict_tracking.py)."""
    import verdict_reconciliation
    return verdict_reconciliation.summary()


def _design_gap_agenda() -> dict:
    """Per-finding worklist for the open design_gap backlog -- which findings
    make up design_debt's aggregate count, and what to do about each (see
    design_gap_agenda.py). Dashboard only needs the summary + a short
    preview; the full worklist is the dedicated API endpoint."""
    import design_gap_agenda
    full = design_gap_agenda.agenda(limit=1000)
    return {"total": full["total"], "overdue": full["overdue"],
            "by_next_step": full["by_next_step"], "items": full["items"][:8]}


def _correlator_precision() -> dict:
    """The correlator's own reversal rate -- of the times it raised a
    finding's confidence, how many of those escalations later got walked
    back (see correlator/self_quality.py)."""
    from correlator import self_quality
    return self_quality.summary()


def _confidence_decay() -> dict:
    """How much correlated-finding confidence has eroded from staleness, and
    how many findings are overdue for re-verification (see confidence_decay.py)."""
    import confidence_decay
    return confidence_decay.summary()


def _fleet() -> dict:
    """Fleet-wide correlation posture across every registered SAST repo/DAST
    target (see fleet.py for how a correlation report gets attributed back
    to the repo it covers)."""
    import fleet
    return fleet.summary()


def _sast() -> dict:
    """Broker posture: repo count + the latest scan risk per repo."""
    try:
        from broker import config as bconfig
    except Exception:
        return {"available": False, "repos": 0, "scans": []}
    try:
        repos = bconfig.load_repos()
    except Exception:
        repos = []
    scans = []
    worst = _empty_sev()
    for r in repos:
        ls = r.get("last_scan") or {}
        risk = ls.get("risk")
        if risk in worst:
            worst[risk] += 1
        scans.append({"name": r.get("name") or r.get("id"),
                      "risk": risk or "—",
                      "findings": int(ls.get("findings", 0) or 0),
                      "report_id": ls.get("report_id") or "",
                      "at": ls.get("at") or ""})
    scans.sort(key=lambda s: _SEVS.index(s["risk"]) if s["risk"] in _SEVS else 99)
    return {"available": True, "repos": len(repos),
            "risk_counts": worst, "scans": scans[:8]}


def _dast() -> dict:
    """DAST is soft-disabled: its blueprint isn't registered (api/__init__.py),
    so there is no live scanner to report posture for or link a card to,
    even though the dast/ package and any past scan data still exist on disk."""
    return {"available": False, "targets": 0, "scans": []}


def _aibom() -> dict:
    """AI posture: how much of the estate uses AI, and how riskily."""
    try:
        from aibom import config as aconfig
    except Exception:
        return {"available": False}
    try:
        inv = aconfig.load_inventory()
    except Exception:
        inv = []
    providers: set[str] = set()
    models: set[str] = set()
    agents = mcp = with_ai = 0
    risk = _empty_sev()
    for e in inv:
        provs = e.get("providers") or []
        if provs:
            with_ai += 1
        providers.update(provs)
        models.update(e.get("models") or [])
        flags = e.get("flags") or {}
        if flags.get("agents"):
            agents += 1
        if flags.get("mcp"):
            mcp += 1
        rr = e.get("overall_risk")
        if rr in risk:
            risk[rr] += 1
    return {"available": True, "repos_scanned": len(inv), "repos_with_ai": with_ai,
            "providers": sorted(providers), "distinct_models": len(models),
            "agents": agents, "mcp": mcp, "risk_counts": risk}


def _llm_usage() -> dict:
    """Claude API spend across every TM feature that calls Claude (threat-model
    analysis, diagram generation, codemodel chain reasoning) — aggregated from
    llm_usage_db, the ledger claude_client.py writes one row to per successful
    call. This is TM's own spend running its features, not a report about the
    user's scanned repos."""
    import llm_usage_db
    llm_usage_db.init()
    return llm_usage_db.summary()


def build() -> dict:
    """The whole overview payload. Each section is independently defensive."""
    errors: dict[str, str] = {}

    def safe(name, fn, fallback):
        try:
            return fn()
        except Exception as exc:   # pragma: no cover - defensive
            errors[name] = str(exc)
            return {"error": str(exc), **fallback} if isinstance(fallback, dict) else fallback

    tm = safe("threat_model", _threat_model_posture, {"reports": 0, "findings": 0,
              "severity": _empty_sev(), "critical_high": 0,
              "by_methodology": {}, "trend": [], "recent": []})
    families = safe("families", _families, [])
    verdicts = safe("verdicts", _verdicts, {
        "order": ["actively_exploited", "confirmed_exploitable", "corroborated",
                 "design_gap", "blind_spot"],
        "counts": {"actively_exploited": 0, "confirmed_exploitable": 0, "corroborated": 0,
                  "design_gap": 0, "blind_spot": 0},
        "unverdicted": 0, "total_correlated": 0, "top_confirmed": [], "top_active_incidents": [],
    })
    verdict_alerts = safe("verdict_alerts", _verdict_alerts, {"unacknowledged": 0, "recent": []})
    verdict_sla = safe("verdict_sla", _verdict_sla, {
        "tracked": 0, "counts": {"breached": 0, "at_risk": 0, "ok": 0},
        "by_verdict": {}, "worst": [],
    })
    verdict_trend = safe("verdict_trend", _verdict_trend, [])
    design_debt = safe("design_debt", _design_debt, {
        "open": 0, "oldest_days": 0.0, "opened_recent": 0, "resolved_recent": 0,
        "net_recent": 0, "window_days": 30, "burndown": [],
    })
    reachable_deps = safe("reachable_dependencies", _reachable_dependencies,
                          {"count": 0, "items": []})
    governance = safe("governance", _governance, {
        "owned": 0, "unowned": 0, "total_actionable": 0, "coverage_pct": 0.0,
        "unowned_urgent": 0, "risk_accepted": 0, "risk_accepted_by_state": {},
    })
    verdict_reconciliation = safe("verdict_reconciliation", _verdict_reconciliation, {
        "total_findings": 0, "conflicts": 0, "conflict_pct": 0.0, "worst_conflicts": [],
    })
    design_gap_agenda = safe("design_gap_agenda", _design_gap_agenda, {
        "total": 0, "overdue": 0, "by_next_step": {"rule_exists": 0, "no_rule": 0}, "items": [],
    })
    correlator_precision = safe("correlator_precision", _correlator_precision, {
        "overall": {"escalations": 0, "reversed": 0, "rate": None, "by_verdict": {}},
        "trend": [], "worst_families": [],
    })
    confidence_decay = safe("confidence_decay", _confidence_decay, {
        "total": 0, "tracked": 0, "needs_reverification": 0,
        "avg_confidence_erosion": 0.0, "worklist": [],
    })
    fleet = safe("fleet", _fleet, {
        "repos": 0, "correlated": 0, "uncorrelated": 0, "coverage_pct": 0.0,
        "totals": {v: 0 for v in ("actively_exploited", "confirmed_exploitable",
                                  "corroborated", "design_gap", "blind_spot")},
        "worst_repos": [], "repos_detail": [],
    })
    sast = safe("sast", _sast, {"available": False, "repos": 0, "scans": []})
    dast = safe("dast", _dast, {"available": False, "targets": 0, "scans": []})
    aibom = safe("aibom", _aibom, {"available": False})
    llm_usage = safe("llm_usage", _llm_usage, {
        "calls": 0, "cost_usd": 0.0, "input_tokens": 0, "output_tokens": 0,
        "cache_creation_tokens": 0, "cache_read_tokens": 0, "cache_hit_rate": 0.0,
        "by_caller": [], "by_model": [],
    })

    return {
        # False whenever any section above actually raised — a section that
        # legitimately has no data yet still reports success=True, so the UI
        # can tell "empty" apart from "broken" instead of rendering silent zeros.
        "success": not errors,
        "errors": errors,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "threat_model": tm,
        "families": families,
        "verdicts": verdicts,
        "verdict_alerts": verdict_alerts,
        "verdict_sla": verdict_sla,
        "verdict_trend": verdict_trend,
        "design_debt": design_debt,
        "reachable_dependencies": reachable_deps,
        "governance": governance,
        "verdict_reconciliation": verdict_reconciliation,
        "design_gap_agenda": design_gap_agenda,
        "correlator_precision": correlator_precision,
        "confidence_decay": confidence_decay,
        "fleet": fleet,
        "sast": sast,
        "dast": dast,
        "aibom": aibom,
        "llm_usage": llm_usage,
    }
