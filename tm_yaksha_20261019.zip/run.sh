#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

# Copy .env.example if no .env exists yet
if [ ! -f .env ] && [ -f .env.example ]; then
  cp .env.example .env
  echo "Created .env from .env.example"
fi

# Load .env if it exists
if [ -f .env ]; then
  set -a
  source .env
  set +a
fi

# Set up venv and install deps
python3 -m venv .venv 2>/dev/null || true
export TM_PORT=8080

source .venv/bin/activate
pip install --upgrade pip -q
pip install -q -r requirements.txt

# Warn if no key (user can still enter it in the UI)
if [ -z "$ANTHROPIC_API_KEY" ]; then
  echo ""
  echo "  ⚠  ANTHROPIC_API_KEY not set — paste your key in the UI or add it to .env"
  echo ""
fi

python app.py
