"""tests/test_new_modules.py — pytest suite for production modules added in v2.0."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import mitre_attack
import compliance_mappings
import pqc_assessment
import control_register
import sbom_parser
import diagram_generator
import system_design_advisor
from _rules_architecture import ARCHITECTURE_RULES
from _rules_devsecops import DEVSECOPS_RULES
from offline_rules import detect_applicable_rulesets, run_offline_review


def test_offline_architecture_diagram_detects_key_components():
    diagram = diagram_generator.generate_architecture_diagram_offline(
        "React frontend calls API gateway, auth service, PostgreSQL database, Redis cache, and OpenAI LLM."
    )
    assert diagram.startswith("flowchart LR")
    assert "Client" in diagram
    assert "API" in diagram
    assert "DB" in diagram
    assert "LLM" in diagram


def test_system_design_context_uses_moved_bundle():
    report = {
        "summary": "API gateway, cache, database, and SSO design review.",
        "categories": [
            {
                "id": "A07",
                "name": "Identification and Authentication Failures",
                "risk": "High",
                "affected_components": ["API Gateway", "SSO"],
                "threats": [{"name": "JWT validation gap", "description": "Token validation must be explicit."}],
                "mitigations": [{"action": "Validate issuer, audience, signature, and expiry on every request."}],
            }
        ],
        "recommendations": ["Centralize authorization at the API gateway."],
    }

    context = system_design_advisor.build_system_design_context(
        report,
        "React SPA calls an API Gateway backed by microservices, Redis cache, PostgreSQL, and SSO.",
    )

    assert context["bundle"]["topics"] > 0
    assert context["domains"]
    assert any(domain["topics"] for domain in context["domains"])
    assert context["decision_queue"]


# ── mitre_attack ──────────────────────────────────────────────────────────────

def test_attack_a01_returns_techniques():
    techs = mitre_attack.get_techniques("A01")
    assert len(techs) > 0
    assert all(k in techs[0] for k in ("id", "name", "tactic", "url"))


def test_attack_llm01_returns_techniques():
    techs = mitre_attack.get_techniques("LLM01", "llm")
    assert len(techs) > 0
    assert any(t["id"] == "T1059" for t in techs)


def test_attack_csa02_detected():
    techs = mitre_attack.get_techniques("CSA02", "cloud")
    assert any(t["id"] == "T1078" for t in techs)


def test_attack_enrich_categories_in_place():
    cats = [{"id": "A07", "name": "Auth Failures", "risk": "High"}]
    mitre_attack.enrich_categories(cats)
    assert "attack_techniques" in cats[0]
    assert len(cats[0]["attack_techniques"]) > 0


def test_attack_unknown_category_empty():
    assert mitre_attack.get_techniques("UNKNOWN99") == []


def test_attack_stride_s_mapped():
    techs = mitre_attack.get_techniques("S", "stride")
    assert any(t["id"] == "T1078" for t in techs)


def test_attack_stride_prefixed_id_mapped():
    techs = mitre_attack.get_techniques("STRIDE-S")
    assert any(t["id"] == "T1078" for t in techs)


def test_attack_enriches_stride_llm_contextual_mapping():
    cats = [{
        "id": "STRIDE-T",
        "name": "Prompt Injection and Context Tampering",
        "source_method": "stride",
        "threats": [{
            "name": "Prompt Injection and Context Tampering",
            "description": "Retrieved content can carry prompt injection into model context.",
            "attack_vector": "LLM service context tampering",
        }],
    }]

    mitre_attack.enrich_categories(cats)

    ids = {t["id"] for t in cats[0]["attack_techniques"]}
    assert "T1059" in ids
    assert "T1565" in ids


# ── compliance_mappings ───────────────────────────────────────────────────────

def test_compliance_a07_covers_pci_and_nist():
    controls = compliance_mappings.get_controls("A07")
    frameworks = {c["framework"] for c in controls}
    assert "PCI DSS 4.0" in frameworks
    assert "NIST 800-53" in frameworks


def test_compliance_controls_have_required_keys():
    controls = compliance_mappings.get_controls("A01")
    assert controls
    for key in ("framework", "control_id", "control_name", "requirement"):
        assert key in controls[0], f"Missing key: {key}"


def test_compliance_llm01_has_ai_frameworks():
    controls = compliance_mappings.get_controls("LLM01", "llm")
    frameworks = {c["framework"] for c in controls}
    assert "NIST AI RMF" in frameworks


def test_compliance_gap_summary():
    cats = [{"id": "A02", "risk": "Critical", "compliance_controls": [
        {"framework": "PCI DSS 4.0", "control_id": "3.5", "control_name": "x", "requirement": "y"},
    ]}]
    gaps = compliance_mappings.compliance_summary(cats)
    assert "PCI DSS 4.0" in gaps
    assert "3.5" in gaps["PCI DSS 4.0"]


def test_compliance_enrich_adds_controls_and_frameworks():
    cats = [{"id": "A09", "name": "Logging Failures", "risk": "High"}]
    compliance_mappings.enrich_categories(cats)
    assert "compliance_controls" in cats[0]
    assert "compliance_frameworks" in cats[0]
    assert len(cats[0]["compliance_controls"]) > 0


# ── pqc_assessment ────────────────────────────────────────────────────────────

def test_pqc_detects_rsa():
    r = pqc_assessment.assess_text("We use RSA-2048 for JWT signing and TLS certificates")
    assert r["findings_count"] >= 1
    assert any(f["algorithm"] == "RSA" for f in r["findings"])


def test_pqc_detects_3des():
    r = pqc_assessment.assess_text("Legacy 3DES encryption for payment data")
    assert any("3DES" in f["algorithm"] for f in r["findings"])
    assert r["overall_risk"] == "Critical"


def test_pqc_detects_ecdsa():
    r = pqc_assessment.assess_text("ECDSA P-256 code signing certificates")
    assert any("ECDSA" in f["algorithm"] or "ECC" in f["algorithm"] for f in r["findings"])


def test_pqc_clean_for_aes256():
    r = pqc_assessment.assess_text("AES-256-GCM symmetric encryption with TLS 1.3")
    assert r["findings_count"] == 0
    assert r["overall_risk"] == "None"


def test_pqc_to_category_structure():
    assessment = pqc_assessment.assess_text("RSA-2048 certificate pinning and 3DES legacy")
    cat = pqc_assessment.pqc_to_category(assessment)
    assert cat is not None
    assert cat["id"] == "PQC"
    assert cat["risk"] in ("Critical", "High", "Medium", "Low")
    assert len(cat["threats"]) > 0
    assert len(cat["mitigations"]) > 0


def test_pqc_none_when_clean():
    assessment = pqc_assessment.assess_text("AES-256 and SHA-256 only")
    cat = pqc_assessment.pqc_to_category(assessment)
    assert cat is None


def test_pqc_standards_present():
    r = pqc_assessment.assess_text("RSA key exchange")
    assert len(r["pqc_standards"]) == 3
    ids = [s["fips"] for s in r["pqc_standards"]]
    assert "FIPS 203" in ids and "FIPS 204" in ids and "FIPS 205" in ids


# ── control_register ─────────────────────────────────────────────────────────

SAMPLE_REPORT = {
    "title": "Test System",
    "categories": [
        {
            "id": "A01", "name": "Broken Access Control", "risk": "Critical",
            "affected_components": ["API gateway", "Orders API", "PostgreSQL"],
            "threats": [
                {
                    "name": "Cross-tenant object access",
                    "attack_vector": "Attacker changes object identifiers to read or modify another tenant's records.",
                }
            ],
            "mitigations": [
                {"action": "Enforce RBAC on every API endpoint", "priority": "Immediate"},
                {"action": "Log and alert on all authorization failures", "priority": "Short-term"},
            ],
            "compliance_controls": [
                {"framework": "PCI DSS 4.0", "control_id": "7.2", "control_name": "x", "requirement": "y"}
            ],
            "attack_techniques": [{"id": "T1078", "name": "Valid Accounts", "tactic": "Initial Access", "url": ""}],
        },
        {
            "id": "A07", "name": "Auth Failures", "risk": "High",
            "mitigations": [
                {"action": "Enforce MFA via FIDO2 hardware tokens", "priority": "Immediate"},
            ],
            "compliance_controls": [],
            "attack_techniques": [],
        },
    ],
}


def test_ctrl_reg_correct_count():
    controls = control_register.generate_control_register(SAMPLE_REPORT)
    assert len(controls) == 3


def test_ctrl_reg_required_fields():
    controls = control_register.generate_control_register(SAMPLE_REPORT)
    required = ["control_id", "control_type", "risk_severity", "control_description",
                "control_summary", "control_domain", "source_finding", "threat_context",
                "affected_components", "why_it_matters", "verification_guidance",
                "implementation_evidence", "priority", "testing_frequency", "sabsa_layer"]
    for key in required:
        assert key in controls[0], f"Missing key: {key}"


def test_ctrl_reg_type_classification():
    controls = control_register.generate_control_register(SAMPLE_REPORT)
    types = {c["control_type"] for c in controls}
    assert "Preventive" in types
    assert "Detective" in types


def test_ctrl_reg_critical_gets_p1():
    controls = control_register.generate_control_register(SAMPLE_REPORT)
    crit = [c for c in controls if c["risk_severity"] == "Critical"]
    assert all("P1" in c["priority"] for c in crit)


def test_ctrl_reg_to_csv_valid():
    controls = control_register.generate_control_register(SAMPLE_REPORT)
    csv_str = control_register.to_csv(controls)
    assert "control_id" in csv_str
    assert "CTRL-" in csv_str
    assert len(csv_str.splitlines()) == len(controls) + 1  # header + rows


def test_ctrl_reg_sabsa_view():
    controls = control_register.generate_control_register(SAMPLE_REPORT)
    sabsa = control_register.sabsa_view(controls)
    assert isinstance(sabsa, dict)
    assert all(len(v) > 0 for v in sabsa.values())


def test_ctrl_reg_compliance_mapping():
    controls = control_register.generate_control_register(SAMPLE_REPORT)
    first = controls[0]
    assert "7.2" in first.get("compliance_mapping", "")


def test_ctrl_reg_entries_explain_context_and_validation():
    controls = control_register.generate_control_register(SAMPLE_REPORT)
    first = controls[0]
    assert "Broken Access Control" in first["source_finding"]
    assert "object identifiers" in first["threat_context"]
    assert "API gateway" in first["affected_components"]
    assert "why_it_matters" in first
    assert "authorization tests" in first["verification_guidance"]
    assert first["owner"] != "TBD"


def test_ctrl_reg_confirmed_exploitable_escalates_priority():
    # High severity normally maps to P2; a correlator verdict of
    # confirmed_exploitable (proven, not just modeled) should escalate it.
    report = {
        "categories": [{
            "id": "A07", "name": "Auth Failures", "risk": "High",
            "verdict": "confirmed_exploitable",
            "mitigations": [{"action": "Enforce MFA via FIDO2 hardware tokens",
                             "priority": "Immediate"}],
        }],
    }
    controls = control_register.generate_control_register(report)
    assert controls[0]["priority"] == "P1 — Immediate (≤72hrs)"
    assert controls[0]["priority_escalated"] is True
    assert controls[0]["verdict"] == "confirmed_exploitable"
    assert "confirmed_exploitable" in controls[0]["why_it_matters"]


def test_ctrl_reg_confirmed_exploitable_critical_stays_capped_at_p1():
    report = {
        "categories": [{
            "id": "A01", "name": "Broken Access Control", "risk": "Critical",
            "verdict": "confirmed_exploitable",
            "mitigations": [{"action": "Enforce RBAC on every API endpoint",
                             "priority": "Immediate"}],
        }],
    }
    controls = control_register.generate_control_register(report)
    assert controls[0]["priority"] == "P1 — Immediate (≤72hrs)"
    # already at the ceiling -- nothing to escalate to, so no false claim of escalation
    assert controls[0]["priority_escalated"] is False


def test_ctrl_reg_actively_exploited_escalates_priority_with_incident_rationale():
    # actively_exploited (a real production incident, not lab proof) must
    # escalate at least as hard as confirmed_exploitable, and its
    # why_it_matters text must name the incident, not the correlation engine.
    report = {
        "categories": [{
            "id": "A07", "name": "Auth Failures", "risk": "Medium",
            "verdict": "actively_exploited",
            "mitigations": [{"action": "Enforce MFA via FIDO2 hardware tokens",
                             "priority": "Immediate"}],
        }],
    }
    controls = control_register.generate_control_register(report)
    assert controls[0]["priority"] == "P1 — Immediate (≤72hrs)"
    assert controls[0]["priority_escalated"] is True
    assert controls[0]["verdict"] == "actively_exploited"
    assert "production incident" in controls[0]["why_it_matters"]
    assert "confirmed_exploitable" not in controls[0]["why_it_matters"]


def test_ctrl_reg_other_verdicts_and_missing_verdict_leave_priority_unchanged():
    for verdict in (None, "corroborated", "design_gap", "blind_spot"):
        cat = {
            "id": "A07", "name": "Auth Failures", "risk": "High",
            "mitigations": [{"action": "Enforce MFA via FIDO2 hardware tokens",
                             "priority": "Immediate"}],
        }
        if verdict:
            cat["verdict"] = verdict
        controls = control_register.generate_control_register({"categories": [cat]})
        assert controls[0]["priority"] == "P2 — Short-term (≤7 days)", verdict
        assert controls[0]["priority_escalated"] is False, verdict
        assert controls[0]["verdict"] == (verdict or "")


# ── sbom_parser ───────────────────────────────────────────────────────────────

CDX_JSON = json.dumps({
    "bomFormat": "CycloneDX", "specVersion": "1.4",
    "components": [
        {"name": "log4j-core", "version": "2.14.1", "type": "library"},
        {"name": "safe-lib",   "version": "3.0.0",  "type": "library"},
        {"name": "minimist",   "version": "0.2.1",  "type": "library"},
        {"name": "unpinned",   "version": "",        "type": "library"},
    ]
})

SPDX_JSON = json.dumps({
    "spdxVersion": "SPDX-2.3",
    "packages": [
        {"name": "log4j-core", "versionInfo": "2.14.1"},
        {"name": "express", "versionInfo": "4.17.0"},
    ]
})


def test_sbom_parse_cyclonedx_json():
    r = sbom_parser.parse_sbom(CDX_JSON, "bom.json")
    assert r.format == "CycloneDX JSON"
    assert len(r.components) == 4


def test_sbom_detects_log4shell():
    r = sbom_parser.parse_sbom(CDX_JSON, "bom.json")
    assert any(v.cve == "CVE-2021-44228" for v in r.vulnerabilities)


def test_sbom_detects_minimist():
    r = sbom_parser.parse_sbom(CDX_JSON, "bom.json")
    assert any(v.cve == "CVE-2021-44906" for v in r.vulnerabilities)


def test_sbom_no_duplicate_findings():
    r = sbom_parser.parse_sbom(CDX_JSON, "bom.json")
    keys = [(v.component, v.version, v.cve) for v in r.vulnerabilities]
    assert len(keys) == len(set(keys))


def test_sbom_overall_risk_critical():
    r = sbom_parser.parse_sbom(CDX_JSON, "bom.json")
    assert r.overall_risk == "Critical"


def test_sbom_detects_unpinned():
    r = sbom_parser.parse_sbom(CDX_JSON, "bom.json")
    assert "unpinned" in r.unpinned_components


def test_sbom_to_categories():
    r = sbom_parser.parse_sbom(CDX_JSON, "bom.json")
    cats = sbom_parser.sbom_to_categories(r)
    assert len(cats) >= 1
    assert cats[0]["risk"] == "Critical"
    assert len(cats[0]["threats"]) >= 1


def test_sbom_categories_are_tagged_for_correlation():
    """_source="SBOM" is how the correlator classifies these as code-level
    evidence (SourceKind.CODE) instead of an undifferentiated design finding."""
    r = sbom_parser.parse_sbom(CDX_JSON, "bom.json")
    cats = sbom_parser.sbom_to_categories(r)
    assert all(c["_source"] == "SBOM" for c in cats)


def test_sbom_parse_spdx_json():
    r = sbom_parser.parse_sbom(SPDX_JSON, "sbom.json")
    assert r.format == "SPDX JSON"
    assert len(r.components) == 2


def test_sbom_invalid_json_raises():
    import pytest
    with pytest.raises(ValueError):
        sbom_parser.parse_sbom("{}", "test.json")


# ── architecture rules ────────────────────────────────────────────────────────

def test_architecture_rules_minimum_count():
    assert len(ARCHITECTURE_RULES) >= 15


def test_architecture_rules_required_fields():
    for rule in ARCHITECTURE_RULES:
        for key in ("id", "category", "question", "severity", "patterns_to_check", "mitigations"):
            assert key in rule, f"Rule {rule.get('id','?')} missing: {key}"


def test_architecture_rules_ids_unique():
    ids = [r["id"] for r in ARCHITECTURE_RULES]
    assert len(ids) == len(set(ids))


def test_architecture_covers_zero_trust():
    cats = {r["category"] for r in ARCHITECTURE_RULES}
    assert "ZERO_TRUST" in cats


def test_architecture_covers_polp():
    cats = {r["category"] for r in ARCHITECTURE_RULES}
    assert "LEAST_PRIVILEGE" in cats


# ── devsecops rules ───────────────────────────────────────────────────────────

def test_devsecops_rules_minimum_count():
    assert len(DEVSECOPS_RULES) >= 12


def test_devsecops_rules_required_fields():
    for rule in DEVSECOPS_RULES:
        for key in ("id", "category", "question", "severity", "patterns_to_check", "mitigations"):
            assert key in rule, f"Rule {rule.get('id','?')} missing: {key}"


def test_devsecops_covers_sast():
    cats = {r["category"] for r in DEVSECOPS_RULES}
    assert "SAST" in cats


def test_devsecops_covers_pqc():
    cats = {r["category"] for r in DEVSECOPS_RULES}
    assert "POST_QUANTUM_CRYPTO" in cats


# ── integration: new rulesets ─────────────────────────────────────────────────

def test_detect_architecture_always_included():
    rulesets = detect_applicable_rulesets("REST API web application with database")
    assert "architecture" in rulesets


def test_detect_devsecops_from_pipeline_keywords():
    rulesets = detect_applicable_rulesets("GitHub Actions CI/CD pipeline deploys to production")
    assert "devsecops" in rulesets


def test_offline_review_architecture_only():
    result = run_offline_review(
        "zero trust admin privileged access RBAC no MFA VPN trusted network",
        rulesets=["architecture"]
    )
    assert result["rulesets_applied"] == ["architecture"]
    assert result["overall_risk"] in ("Critical", "High", "Medium", "Low")
    assert len(result["findings"]) > 0


def test_offline_review_devsecops_only():
    result = run_offline_review(
        "github actions pipeline developer code repository no sast",
        rulesets=["devsecops"]
    )
    assert result["rulesets_applied"] == ["devsecops"]
    assert len(result["findings"]) > 0


def test_offline_full_ruleset_count():
    result = run_offline_review(
        "web application api database authentication mobile ios android aws lambda kubernetes",
        rulesets=["web", "api", "ai", "mobile", "cloud", "architecture", "devsecops"]
    )
    assert result["summary_counts"]["total"] >= 150
