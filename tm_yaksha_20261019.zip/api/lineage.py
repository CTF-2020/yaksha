"""Design-to-code threat lineage API.

Routes (CSRF + optional TM_API_KEY apply via the app's global before_request):
  GET  /api/v1/lineage                  engine status + counts by status
  GET  /api/v1/lineage/threats           list tracked threats {status?, family?}
  GET  /api/v1/lineage/threats/<id>      one threat's full event timeline
  POST /api/v1/lineage/sync              sync a saved report {report_id}
                                          -> persists/updates lineage, returns a summary

The engine only ever reads/writes through report_db (a saved report) and its
own lineage.db store — it never touches the filesystem or an arbitrary path,
same authorization posture as the correlator.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

from lineage import service

bp = Blueprint("lineage_api", __name__, url_prefix="/api/v1/lineage")


@bp.get("")
def status():
    return jsonify({"success": True, **service.status()})


@bp.get("/threats")
def list_threats():
    status_filter = request.args.get("status") or None
    family_filter = request.args.get("family") or None
    if status_filter and status_filter not in ("predicted", "realized", "confirmed", "blind_spot"):
        return jsonify({"success": False, "error": "invalid status filter"}), 400
    return jsonify({"success": True,
                    "threats": service.list_threats(status=status_filter, family=family_filter)})


@bp.get("/threats/<threat_id>")
def get_threat(threat_id: str):
    threat = service.get_threat(threat_id)
    if threat is None:
        return jsonify({"success": False, "error": f"threat not found: {threat_id}"}), 404
    return jsonify({"success": True, "threat": threat})


@bp.post("/sync")
def sync():
    body = request.get_json(silent=True) or {}
    report_id = str(body.get("report_id", "")).strip()
    if not report_id:
        return jsonify({"success": False, "error": "report_id is required"}), 400
    try:
        summary = service.sync(report_id)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 404
    return jsonify({"success": True, **summary}), 200
