"""Target validation and DAST engine invocation.

A thin, safety-focused boundary between the service/CLI and the scanning engine:
it validates that the target is a well-formed http(s) URL, resolves the host
scope allowlist, and runs the in-process engine. Unlike the SAST scanner it does
not shell out — the DAST engine is pure-stdlib Python and ships with TM — but the
same `{"findings": [...]}`-style result is returned so the report mapper is shared.
"""
from __future__ import annotations

from . import config, engine


class ScanError(RuntimeError):
    """Raised when a target is invalid or the engine cannot run."""


def prepare_target(target: dict) -> tuple[str, list[str]]:
    """Return (normalized_url, scope_hosts) for a registered target.

    Raises ScanError for anything that is not a scannable http(s) URL — the
    engine is never handed a scheme it cannot safely drive.
    """
    url = config.normalize_target_url(target.get("url", ""))
    if not url:
        raise ScanError(f"not a scannable http(s) target: {target.get('url')!r}")
    scope = config.parse_scope(target.get("scope", ""), config.target_host(url))
    if not scope:
        raise ScanError("could not determine a host scope for the target")
    return url, scope


def run_scan(target: dict, severity: str = "Info", progress=None) -> tuple[list[dict], dict]:
    """Scan a target and return (findings, meta).

    `meta` carries crawl statistics that the mapper folds into the report's
    scan_metadata (pages crawled, requests made).
    """
    if severity not in config.SEVERITY_ORDER:
        severity = "Info"
    url, scope = prepare_target(target)
    result = engine.scan(
        url, scope, severity_threshold=severity,
        auth_header=target.get("auth_header", ""), progress=progress)
    meta = {
        "source": "dast",
        "url": url,
        "scope": scope,
        "pages_crawled": result.pages_crawled,
        "requests_made": result.requests_made,
        "active": config.ACTIVE_CHECKS,
        "truncated": result.truncated,
    }
    return result.findings, meta
