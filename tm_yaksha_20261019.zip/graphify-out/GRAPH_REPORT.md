# Graph Report - .  (2026-08-06)

## Corpus Check
- 297 files · ~596,837 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 5786 nodes · 11066 edges · 327 communities (220 shown, 107 thin omitted)
- Extraction: 97% EXTRACTED · 3% INFERRED · 0% AMBIGUOUS · INFERRED: 326 edges (avg confidence: 0.64)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Offline Rules
- Agentic Threats
- API: AIBOM
- AIBOM: Config (aibom/config.py)
- AIBOM: Mapper
- AIBOM: DB
- AIBOM: Engine
- AIBOM: Service
- Analyzer
- App (top-level) - is_offline_capable_methodology
- Analyzer Tests
- Engine (top-level)
- API: Confidence
- API: Dashboard
- API: Admin
- Auth
- Broker: Config (list_repos)
- API: Analysis
- API: Assetgraph
- API: Codemodel
- API: Controls (controls.py)
- API: Core
- API: Correlate
- Verdict Tracking (alerts)
- Attack Paths
- Report View
- Exec Summary
- DAST: Config
- API: Design Review
- JIRA Client
- Fleet
- Incidents
- API: Lineage (lineage.py)
- API: Login
- API: Lookups (lookups.py)
- API: Ownership (api/ownership.py)
- Offline Pattern Enrichment (patterns.py)
- API: PQC (pqc.py)
- Regression
- API: Reports
- API: Rules
- API: SAST
- App (top-level) - sbom.py
- API: Suppressions
- API: Tickets (tickets.py)
- API: Triage
- App (top-level) - app.py
- Report Store
- Wsgi
- Report DB
- Suppressions: Store
- DAST Validate Tests
- GITHUB Arch Tests
- Readme
- Arch Drift (arch_drift.py)
- Assetgraph: Service
- Assetgraph: DB
- Assetgraph DB Tests
- Benchmark: Codemodel Harness
- Benchmark: Codemodel Corpus
- Benchmark: Harness (benchmark/harness.py)
- Broker: Mapper
- Broker: Engines
- Broker: Delta
- Broker: GITHUB
- DAST: GITHUB
- Broker: Scanner
- Broker: Reviewer (threat_from_finding)
- Settings DB Tests
- Broker: Remediation (remediation.py)
- Broker: Remediation (RemediationError)
- Broker Tests (ScanError)
- Broker: Service
- Broker Tests (due_repos)
- Diagram Generator
- Codemodel Tests (codemodel/__init__.py)
- Codemodel: Extractor
- Codemodel: Chain Reasoning (chain_reasoning.py)
- Codemodel: Terraform Extractor
- Codemodel: Polyglot Extractor (Sink)
- Codemodel: Python Extractor (DependencyUse)
- Compliance Mappings
- Confidence Decay
- Control Register
- New Modules Tests
- Correlator: Model
- Correlator: Engine
- Correlator: Taxonomy
- Correlator: Self Quality
- Dashboard: Service
- Dashboard Package
- DAST: Mapper
- Benchmark Package
- Benchmark: Harness (dast/benchmark/harness.py)
- DAST: Engine (dast/engine.py)
- DAST: Engine (NoRedirect)
- Regression Tests (Resp)
- DAST: Engine (Fetcher)
- DAST: Engine (init)
- DAST: Engine (LinkParser)
- DAST: Engine (body_ratio)
- DAST: Service
- DAST: Validate
- Suppressions: Engine
- EPSS KEV
- Guard Package (guard/__init__.py)
- Guard Diff Tests
- Guard: Scan
- Lineage: DB
- Lineage: Engine
- LLM Attack Vector Atlas
- Mitre Attack
- Offline Patterns (offline_patterns.py)
- Offline Patterns (dedupe_text)
- Offline Rules Tests
- Owasp API 2023
- Owasp Mobile (owasp_mobile.py)
- Owasp Web 2025
- Ownership
- Nav API Tests
- Redos Audit (redos_audit.py)
- Rules Catalog (rules_catalog.py)
- Rules Catalog (reload)
- Run.sh (run.sh script)
- SARIF
- SARIF Import
- SBOM Parser
- SSVC
- Static: Tm Fallback (tm_fallback.js)
- Triage Tests (finding_fingerprint)
- System Design Package (system_design/__init__.py)
- System Design: System Design Full (basic_usage.py)
- System Design: Pyproject.toml (system-design-skill)
- System Design: System Design Full (system_design_full.py)
- System Design: System Design Full (SkillError)
- System Design: System Design Full (to_payload)
- System Design: System Design Full (Flashcard)
- System Design: System Design Skill
- System Design: System Design Full Tests
- System Design Advisor
- AIBOM Tests (test_aibom.py)
- AIBOM Tests (TestApi)
- AIBOM DB Tests
- Arch Drift Tests (cm_report)
- Arch Drift Tests (TestDeclaredParsing)
- Assetgraph Engine Tests
- Assetgraph Service Tests (test_assetgraph_service.py)
- Assetgraph Service Tests (TestAssetGraphApi)
- Attack Paths Tests
- Benchmark Tests (test_benchmark.py)
- Benchmark Tests (TestAccuracyFloors)
- Broker Tests (make_vuln_repo)
- Broker Tests (TestMapper)
- Broker Tests (TestCodeContext)
- Broker Tests (TestGitHubModule)
- Broker Tests (TestBrokerApi)
- Broker Tests (TestCodeModelAutoTrigger)
- Canary Tests
- Chain Reasoning Tests (test_chain_reasoning.py)
- Codemodel Tests (TestExtractorUnit)
- Codemodel Tests (TestModelJoin)
- Codemodel Tests (TestThreatDerivation)
- Codemodel Benchmark Tests
- Codemodel Polyglot Tests (test_codemodel_polyglot.py)
- Codemodel Polyglot Tests (TestGo)
- Codemodel Polyglot Tests (TestJavaSpring)
- Codemodel Terraform Tests
- Compliance Mappings Tests
- Confidence Decay Tests
- Correlator Tests
- Correlator Service Tests
- DAST Tests (test_dast.py)
- DAST Tests (VulnHandler)
- DAST Tests (VulnServer)
- DAST Tests (enter)
- DAST Tests (ids)
- DAST Tests (TestMapper)
- DAST Tests (TestWebhookParsing)
- DAST Tests (TestFindTargetForGithub)
- DAST Tests (TestReportBack)
- DAST Tests (TestXssContextAwareness)
- DAST Tests (TestScanDedup)
- DAST Tests (TestBoundedConcurrency)
- DAST Refinements Tests
- DAST Service Validate Tests
- Design Gap Agenda Tests
- Engines Tests (test_engines.py)
- EPSS KEV Tests
- Fleet Tests
- Guard Scan Tests
- Incidents Tests
- JIRA Webhook Tests (test_jira_webhook.py)
- JIRA Webhook Tests (reset_limiter)
- JIRA Webhook Tests (TestFindTargetRepo)
- Lineage DB Tests
- Lineage Engine Tests (test_lineage_engine.py)
- Lineage Service Tests
- Login Gate Tests
- Mitre Attack Tests
- Ownership Tests (test_ownership.py)
- Ownership Tests (OwnershipModuleTests)
- PR Tm Tests (ChangedFilesInjectionGuardTests)
- Redos Audit Tests
- Regression Tests (test_regression.py)
- Regression Tests (get)
- Remediation Tests
- Report DB Tests
- Report Store Tests
- Reports API Tests
- Reviewer Tests (test_reviewer.py)
- Reviewer Tests (TestTaintVerdicts)
- Reviewer Tests (TestSuggestions)
- Rules Tests (test_rules.py)
- Rules Tests (CatalogTests)
- Rules Tests (ApiTests)
- Rules Tests (FindingEnrichmentTests)
- SARIF Tests (test_sarif.py)
- SARIF Tests (report)
- SARIF Import Tests
- Secret Key Tests
- Self Quality Tests
- SSVC Tests
- Suppressions Tests (test_suppressions.py)
- Suppressions Tests (cat)
- Suppressions Tests (TestVerdictAwareExpiry)
- Suppressions Tests (TestStore)
- Suppressions Tests (TestEngineMatchesRow)
- Suppressions Tests (TestAnnotateReport)
- Suppressions Tests (TestSuppressionAPI)
- Suppressions DB Tests
- Tm Guard CLI Tests
- Triage Tests (TriageAPITests)
- Users DB Tests
- Verdict Reconciliation Tests (test_verdict_reconciliation.py)
- Verdict Reconciliation Tests (ReconcileTests)
- Verdict Tracking Tests
- Viewer Security Tests (test_viewer_security.py)
- Admin Tests
- API V1 Contract Tests
- Dashboard Tests (tests/test_dashboard.py)
- Dashboard Tests (TestDashboardService)
- Exec Summary Tests
- Export Filters Tests
- Frontend Upload Tests (test_frontend_upload.py)
- PR Tm Tests (tests/test_pr_tm.py)
- SAST Visibility Tests
- Tm Gate
- Tm Guard
- Triage
- Users DB
- Verdict Reconciliation
- Rules Architecture
- AIBOM: Config (aibom.config (public persistence surface)
- Verdict Tracking (Verdict reconciliation API blueprint)
- API: Controls (Control Register API blueprint)
- API: DAST (DAST Scanner API (status/targets/jobs)
- API: DAST (DAST Target Registration Endpoint)
- API: DAST (DAST Remote Import Endpoint)
- API: Diagrams
- API: Lineage (Threat Lineage API)
- API: Lineage (Lineage Sync Endpoint (POST /sync)
- Templates: AIBOM
- API: Lookups (Lookup/Compliance Metadata API)
- API: Nav
- API: Ownership (Suppressions API blueprint)
- API: PQC (Post-Quantum Crypto Assessment API)
- API: SBOM
- API: Tickets (Ticket Creation API)
- API: Tickets (Confluence Page Publish Endpoint)
- Arch Drift (Architecture Drift Detection module)
- Benchmark: Harness (tm/benchmark/harness.py)
- Broker: Config (sast)
- Broker: Remediation #1
- Broker: Reviewer (review_finding)
- Codemodel: Chain Reasoning (call_claude)
- Codemodel: Config Extractor (extract config-file dispatcher)
- Chain Reasoning Tests (tm/correlator/taxonomy.py)
- Codemodel: Model
- Codemodel: Polyglot Extractor (js_agent_tools MCP/agent tool detection)
- Codemodel: Python Extractor #1
- Codemodel: Signatures (SINKS signature table)
- Codemodel: Signatures (AUTH_DECORATORS / AUTH_DEPENDENCIES tables)
- Lineage Engine Tests (tm/correlator/engine.py)
- Correlator: Mapper
- DAST Package
- DAST: Scanner
- Data: Semgrep Rules #1
- Data: Semgrep Rules #2
- Guard Package #1
- Lineage Package
- Offline Pattern Enrichment (RULESET_PROFILES)
- Owasp Mobile (OWASP_CLOUD_TOP10 knowledge base)
- Redos Audit (audit_pattern ReDoS heuristic detector)
- Redos Audit #1
- Redos Audit (bounded_search input-length cap mitigation)
- Risk Signals
- Run.sh (run.sh venv bootstrap + launcher)
- Static: Tm Fallback #1
- Stride Pasta
- System Design Package (system_design package init)
- Examples: Basic Usage
- System Design: Pyproject.toml (system-design-skill package config)
- System Design: System Design Full (TopicSection dataclass)
- System Design: System Design Full (SearchHit dataclass)
- System Design: System Design Full (SkillMetadata dataclass)
- System Design: System Design Full (StudyPlanDay dataclass)
- System Design: System Design Full (Flashcard dataclass (full)
- System Design: System Design Full (QuizQuestion dataclass (full)
- System Design: System Design Full (SkillError exception hierarchy)
- AIBOM Tests #1
- Arch Drift Tests #1
- Engines Tests #1
- Viewer Security Tests #1
- Frontend Upload Tests #1
- Prd #1
- Prd (dast/engine.py — DAST producer)
- Prd #2
- Prd #3
- Requirements
- Rule.yaml
- System Design: Readme
- Templates: Code Subnav
- Templates: Portal Head
- Templates: Admin

## God Nodes (most connected - your core abstractions)
1. `finding_fingerprint()` - 51 edges
2. `ScanError` - 45 edges
3. `TestEngine` - 45 edges
4. `register_api_blueprints()` - 44 edges
5. `Masked` - 42 edges
6. `analyze()` - 39 edges
7. `BrokerService` - 39 edges
8. `_check_rule()` - 38 edges
9. `Resp` - 34 edges
10. `SystemDesignKnowledgeBase` - 33 edges

## Surprising Connections (you probably didn't know these)
- `Rationale: non-loopback bind without TM_API_KEY warns of unauthenticated GitHub-token exposure` --semantically_similar_to--> `README.md — TM / Yaksha Guard project overview`  [INFERRED] [semantically similar]
  wsgi.py → README.md
- `test_api_v1_contract.py — /api/v1 blueprint contract tests` --semantically_similar_to--> `docker-compose.yml — TM container deployment config`  [INFERRED] [semantically similar]
  tests/test_api_v1_contract.py → docker-compose.yml
- `status()` --conceptually_related_to--> `GET /api/export/<id> (report export)`  [AMBIGUOUS]
  api/sast.py → templates/index.html
- `finding_fingerprint()` --semantically_similar_to--> `tm/broker/delta.py`  [INFERRED] [semantically similar]
  suppressions/engine.py → broker/delta.py
- `run()` --conceptually_related_to--> `POST /api/v1/sast/repos/<id>/pipeline (SAST+code-model+correlation)`  [INFERRED]
  api/correlate.py → templates/broker.html

## Import Cycles
- 3-file cycle: `correlator/__init__.py -> correlator/service.py -> correlator/engine.py -> correlator/__init__.py`
- 3-file cycle: `codemodel/__init__.py -> codemodel/service.py -> codemodel/extractor.py -> codemodel/__init__.py`
- 4-file cycle: `codemodel/__init__.py -> codemodel/service.py -> codemodel/extractor.py -> codemodel/python_extractor.py -> codemodel/__init__.py`
- 5-file cycle: `codemodel/__init__.py -> codemodel/service.py -> codemodel/extractor.py -> codemodel/polyglot_extractor.py -> codemodel/python_extractor.py -> codemodel/__init__.py`

## Hyperedges (group relationships)
- **AI/API architecture detection feeding OWASP rule catalogs** — agentic_threats_get_agentic_attack_surface, rules_ai_ai_rules, rules_api_api_rules [INFERRED 0.75]
- **AI-BOM layered persistence: config (public surface) / db (SQLite plumbing) / service (orchestration)** — aibom_config_module, aibom_db_module, aibom_service_module [EXTRACTED 0.90]
- **Admin flush-everything data reset touching per-subsystem stores** — api_admin_flush_everything, aibom_service_module, api_ownership_module, api_regression_module [INFERRED 0.75]
- **Codemodel scan fans out to lineage/assetgraph, mirroring DAST + design_review sync patterns** — api_codemodel, api_assetgraph, lineage_service_ext, dast_service, api_design_review [EXTRACTED 0.90]
- **Living asset-graph reconciliation: codemodel report -> extracted assets/edges -> SQLite upsert/stale** — assetgraph_service_sync, assetgraph_engine_extract, assetgraph_db, assetgraph_model [EXTRACTED 0.90]
- **SQLite-system-of-record with best-effort JSON backup mirroring, and the service layer built atop it** — broker_config_module, broker_db_module, broker_service_module [EXTRACTED 0.90]
- **PR-diff-scoped code model built from changed files then posted back to the PR as its own GitHub comment** — broker_pr_tm_run, codemodel_service_analyze_path, broker_github_report_tm_to_pr [EXTRACTED 0.85]
- **Independently reimplemented source-to-sink taint analysis across subsystems** — reviewer_taintMap, polyglot_collectSinks [INFERRED 0.75]
- **Verdict-asymmetric treatment of proven exploits (actively_exploited/confirmed_exploitable) across canary, compliance, decay, and remediation** — canary_proven_verdicts, compliance_mappings_weighted_summary, confidence_decay_worklist, broker_remediation_queue [EXTRACTED 0.85]
- **Code-derived threat modeling pipeline: extract -> derive -> report** — codemodel_model_systemmodel, codemodel_threats_derive, polyglot_analyzeSource [EXTRACTED 0.90]
- **Pipeline: extractor.build_model -> threats.derive -> mapper.build_report, triggered by broker/service.py manual scans and app.py's ad-hoc GitHub URL threat modeling** — codemodel_extractor_build_model, codemodel_threats_derive, codemodel_mapper_build_report, broker_service_run, app_github_system_model [INFERRED 0.80]
- **Correlator priority-score signal fusion (confidence + exploitability + business impact + EPSS/KEV)** — correlator_engine_adjudicate, correlator_engine_confidence, correlator_engine_exploitability, correlator_engine_business_impact, correlator_engine_epss_kev [EXTRACTED 0.90]
- **Correlator verdict consumed by independent downstream artifact generators** — correlator_model_verdict, control_register_module, jira_client_module, exec_summary_module [INFERRED 0.75]
- **Dashboard defensive per-section aggregation pattern** — dashboard_service_build, dashboard_service_fleet_section, dashboard_service_design_gap_agenda_section, dashboard_service_correlator_precision_section, dashboard_service_sast_section, dashboard_service_dast_section [EXTRACTED 0.90]
- **Cross-source evidence reconciliation: DAST-tagged runtime findings feed both the correlator's verdict engine and the codemodel attack-path validator** — dast_mapper_category_from_group, correlator_engine_source_kind, dast_validate_validate, attack_paths_module [INFERRED 0.80]
- **OWASP category ID taxonomy (A01-A10/API1-API10/LLM01-10) independently modeled in multiple modules** — owasp_owasp_top10, owasp_api_owasp_api_top10, owasp_api_2023_owasp_api_2023, offline_pattern_enrichment_category_profiles, mitre_attack_normalize_category [INFERRED 0.70]
- **Connection-per-call SQLite + WAL system-of-record pattern** — ownership_module, regression_module, report_db_module, settings_db_module, suppressions_db_module [INFERRED 0.90]
- **Independently duplicated correlator Verdict vocabulary to avoid coupling** — report_db_module, suppressions_model_module, control_register_module, jira_client_module [INFERRED 0.85]
- **Triage queue -> owner/SSVC-annotated finding -> SARIF export flow** — report_db_module, sarif_module, ownership_module, ssvc_module [INFERRED 0.75]
- **Client-side fallback renderer duplicates server-side OWASP/STRIDE/PQC taxonomies for classification and labeling** — tm_fallback_finding_titles, tm_fallback_issue_families, owasp_llm_top10, owasp_web_2025, stride_dict [INFERRED 0.75]
- **Duplicate system-design knowledge-base implementations (skill.py superseded by full.py)** — system_design_full_knowledgebase, system_design_skill_systemdesignskill, basic_usage_example [INFERRED 0.70]
- **Codemodel report (scan_metadata) as shared substrate for downstream security analyses** — test_arch_drift_tests, test_attack_paths_tests, test_assetgraph_engine_tests [INFERRED 0.80]
- **SQLite store isolation test pattern (temp DB_PATH swap, upsert/backfill contract)** — test_assetgraph_db_tests [INFERRED 0.80]
- **Codemodel multi-source design-fact extraction feeding one SystemModel/threats pipeline** — codemodel_extractor_module, codemodel_polyglot_extractor_module, codemodel_terraform_extractor_module, codemodel_config_extractor_module [INFERRED 0.80]
- **Verdict-driven prioritization consumers of correlator verdicts** — correlator_engine, verdict_tracking, confidence_decay, design_gap_agenda_module, ownership_module, broker_pkg, fleet_module [INFERRED 0.75]
- **Suppression-aware exclusion gating across worklists/queues** — suppressions_pkg, confidence_decay, design_gap_agenda_module, fleet_module, correlator_service, broker_pkg [INFERRED 0.75]
- **Automatic post-scan attack-path validation wiring DAST findings against codemodel-confirmed reachable sinks** — dast_service_module, dast_validate_module, correlator_taxonomy_module [INFERRED 0.75]
- **Jira ticket -> design review -> background rescan -> comment-back loop** — api_design_review, analyzer_module, jira_client_module, lineage_pkg, broker_pkg [EXTRACTED 0.90]
- **Design-to-code-to-runtime threat lineage tracking (predicted/realized/confirmed) built atop correlator observations** — correlator_engine_module, lineage_engine_module, lineage_service_module, lineage_db_module [INFERRED 0.80]
- **Shared git-argument-injection guard (untrusted branch/ref must pass through -- separator before reaching git subprocess)** — test_pr_tm_tests, broker_pr_tm_changed_files, broker_remediation_open_pr, broker_scanner_run_git [EXTRACTED 0.90]
- **Persistent SECRET_KEY (multi-worker safe) underpins CSRF-token-gated write endpoints across reports/suppressions/sarif-import APIs** — test_secret_key_tests, app_load_or_create_secret_key, test_sarif_import_tests [INFERRED 0.75]
- **Shared temp-DB store-isolation pattern to avoid polluting real ~/.tm_* stores** — test_admin_file, test_triage_file, test_dashboard_file, test_exec_summary_file [INFERRED 0.75]
- **Verdict-gated escalation of remediation priority/ticketing/action** — jira_client_module, control_register_module, ssvc_module [INFERRED 0.70]
- **Three test suites jointly enforce the contract that SAST-methodology reports never surface through the general report API** — test_sast_visibility_py, test_pr_tm_py, test_api_v1_contract_py [INFERRED 0.75]
- **Verdict-driven prioritization across SSVC, tracking, reconciliation, and triage** — ssvc_module, verdict_tracking_module, verdict_reconciliation_module, triage_module [INFERRED 0.80]
- **Verdict escalation/SLA/design-debt lifecycle surfaced on the dashboard** — verdict_tracking_record_transitions, verdict_tracking_sla_summary, verdict_tracking_design_debt_summary, dashboard_page, api_dashboard [INFERRED 0.80]
- **tm_gate.py + tm_guard.py jointly implement PRD's CI-gate SDLC-integration requirement** — tm_gate_py, tm_guard_py, prd_ci_gate_fr [INFERRED 0.80]
- **Design/Code/Runtime producers feed the correlator to form PRD's unified security assurance pipeline** — prd_analyzer_component, prd_broker_component, prd_dast_component, prd_codemodel_component, prd_correlator_component [EXTRACTED 0.90]
- **OWASP Triple-Top 10 ruleset (API 2023 + Web 2021 + LLM 2025) in rule.yaml** — ruleyaml_owasp_triple_top10, ruleyaml_owasp_api_top10, ruleyaml_owasp_web_top10, ruleyaml_owasp_llm_top10 [EXTRACTED 1.00]
- **Code tab pipeline: Scan (broker) -> Model (codemodel) -> Correlation (correlate) -> Dynamic (dast)** — tpl_code_subnav [EXTRACTED 0.90]
- **SAST + Code Model + Correlation single-repo pipeline** — broker_page, api_sast_repos_pipeline, codemodel_page, correlate_page, api_correlate_run [EXTRACTED 0.90]
- **Triage queue drives suppression + ownership assignment across findings** — triage_page, api_reports_suppress, api_suppressions_delete, api_owners, suppressions_finding_fingerprint [INFERRED 0.75]
- **Dual API-plus-UI Blueprint Split Pattern** — api_sast_bp, broker_page_bp, api_dast_bp, api_dast_page_bp, api_aibom_bp, api_aibom_page_bp, api_rules_bp, api_rules_page_bp, api_codemodel_bp [INFERRED 0.75]
- **EPSS/KEV Vulnerability Prioritization Inputs** — data_epss_kev_cache_epss, data_epss_kev_cache_kev, api_correlate_bp [INFERRED 0.50]

## Communities (327 total, 107 thin omitted)

### Community 41 - "Offline Rules"
Cohesion: 0.08
Nodes (26): _rules_ai.py — OWASP LLM Top 10 2025 offline rules., _rules_api.py — OWASP API Security Top 10 2023 offline rules., _rules_architecture.py — Security Architecture Principles offline rules.…, _rules_cloud.py — CSA Cloud Top Threats 2024 + provider-specific offline rules., _rules_devsecops.py — DevSecOps and Secure SDLC offline rules. Sources: - Green…, _rules_mobile.py — OWASP Mobile Top 10 (2024) + Kubernetes Top 10 offline rules., _rules_web.py — OWASP Top 10 2021 offline rules., _effective_risk() (+18 more)

### Community 66 - "Agentic Threats"
Cohesion: 0.11
Nodes (26): AiDetectionResult, TypedDict, ApiDetectionResult, _keyword_matches(), detect_ai_architecture(), is_ai_analysis_applicable(), get_agentic_attack_surface(), detect_api_architecture() (+18 more)

### Community 125 - "API: AIBOM"
Cohesion: 0.20
Nodes (15): AI-BOM: AI bill of materials + LLM usage inventory scanner for Yaksha Guard., get_service(), AI-BOM orchestration: job queue, background worker, report + BOM persistence.…, get, status(), post, limit, scan_repo() (+7 more)

### Community 120 - "AIBOM: Config (aibom/config.py)"
Cohesion: 0.17
Nodes (17): is_safe_job_id(), _read_json(), Path, _write_json(), _backup(), save_jobs(), save_bom(), load_bom() (+9 more)

### Community 148 - "AIBOM: Mapper"
Cohesion: 0.24
Nodes (13): now_iso(), _severity_counts(), _highest_severity(), _inventory_category(), _finding_category(), result_to_report(), _purl(), _cdx_component() (+5 more)

### Community 103 - "AIBOM: DB"
Cohesion: 0.21
Nodes (20): _connect(), Connection, init(), load_jobs(), save_jobs(), save_bom(), load_bom(), save_latest() (+12 more)

### Community 61 - "AIBOM: Engine"
Cohesion: 0.17
Nodes (23): _Inventory, Path, _rel(), _read_text(), _find_line(), _redact_secret(), Match, _scan_requirements() (+15 more)

### Community 156 - "AIBOM: Service"
Cohesion: 0.21
Nodes (3): AibomService, Admin flush: drop every job, BOM document, and inventory rollup from memory and…, Persist via the host app so the report joins the existing UI list.

### Community 67 - "Analyzer"
Cohesion: 0.12
Nodes (23): _raw_methodology_keys(), normalize_methodologies(), methodology_label(), offline_fallback_methodologies(), _risk_score(), _category_display_name(), _category_key(), _normalize_category() (+15 more)

### Community 35 - "App (top-level) - is_offline_capable_methodology"
Cohesion: 0.07
Nodes (38): is_offline_capable_methodology(), post, limit, architecture_diagram(), Generate an architecture Mermaid diagram., _methodology_from_form(), _methodology_from_json(), _fallback_without_api_key() (+30 more)

### Community 4 - "Analyzer Tests"
Cohesion: 0.06
Nodes (65): _extract_json(), _wrap_input(), _harden_system(), _coerce_risk(), _coerce_score(), _validate_analysis_result(), analyze_owasp(), analyze_stride() (+57 more)

### Community 131 - "Engine (top-level)"
Cohesion: 0.18
Nodes (6): analyze_yaml_rules(), _keywords(), ThreatModelingEngine, engine.py — YAML-based threat modeling engine. Provides two modes:…, Evaluate all YAML vectors against architecture_text without user input. Returns…, Shared explicit-insecurity-phrase list used to escalate review findings. Single…

### Community 141 - "API: Confidence"
Cohesion: 0.14
Nodes (12): Versioned API blueprint registration., get, summary(), worklist(), Confidence-decay API -- surfaces correlated findings whose evidence has gone…, get, get_nav(), Portal navigation API. Read-only JSON mirror of portal_nav.py — the same data… (+4 more)

### Community 23 - "API: Dashboard"
Cohesion: 0.05
Nodes (45): register_api_blueprints(), Register the clearer v1 API surface while preserving legacy routes., Core Blueprint, Analysis Blueprint, Controls Blueprint, Diagrams Blueprint, Lookups Blueprint, Patterns Blueprint (+37 more)

### Community 157 - "API: Admin"
Cohesion: 0.24
Nodes (13): get, admin_page(), list_users(), post, create_user(), set_role(), _flush_everything(), epss_kev_status() (+5 more)

### Community 140 - "Auth"
Cohesion: 0.16
Nodes (15): before_request, _gate(), delete, delete_user(), context_processor, _inject_portal_nav(), Every template renders its navbar from portal_nav.py (also served at…, current_user_email() (+7 more)

### Community 50 - "Broker: Config (list_repos)"
Cohesion: 0.11
Nodes (30): list_repos(), list_repos(), add_repo(), _dir_has_rules(), Path, slugify(), now_iso(), redact_repo() (+22 more)

### Community 201 - "API: Analysis"
Cohesion: 0.24
Nodes (9): post, limit, create_review(), create_review_job(), get, review_job_events(), Run a review and return the finished report., Start a streaming review job. (+1 more)

### Community 206 - "API: Assetgraph"
Cohesion: 0.36
Nodes (8): get, status(), list_assets(), get_asset(), asset_repos(), post, sync(), Persistent asset graph API. Routes (CSRF + optional TM_API_KEY apply via the…

### Community 47 - "API: Codemodel"
Cohesion: 0.08
Nodes (34): _sync_downstream_best_effort(), get, status(), list_repos(), post, limit, analyze(), drift() (+26 more)

### Community 231 - "API: Controls (controls.py)"
Cohesion: 0.33
Nodes (6): get, get_controls(), export_controls(), Control register API routes., Get the control register for a report., Export the control register for a report.

### Community 158 - "API: Core"
Cohesion: 0.15
Nodes (13): get, api_manifest(), Core API discovery endpoints., Describe the stable v1 API groups for clients and integrations., confidence-decay API blueprint, correlate API blueprint (mediator engine), dashboard API blueprint (posture overview), fleet API blueprint (repo/target posture rollup) (+5 more)

### Community 78 - "API: Correlate"
Cohesion: 0.13
Nodes (24): get, status(), sources(), trend(), reachable_dependencies(), design_debt(), design_debt_agenda(), precision() (+16 more)

### Community 49 - "Verdict Tracking (alerts)"
Cohesion: 0.10
Nodes (32): alerts(), sla(), Verdict escalations detected across every correlation run so far -- a finding…, How long every tracked finding has sat at its current verdict vs. that…, _connect(), Connection, init(), record_transitions() (+24 more)

### Community 121 - "Attack Paths"
Cohesion: 0.19
Nodes (17): attack_paths_run(), Synthesize attack paths from a codemodel report + optional evidence. Body:…, Step, AttackPath, _worse(), _family_severity(), _index_evidence(), _match() (+9 more)

### Community 93 - "Report View"
Cohesion: 0.13
Nodes (22): limit, public_correlate(), Token-gated public view of one correlation report — no TM_API_KEY, no session.…, _attack_vector_html(), html_escape(), _num(), _split_path_line(), _category_loci() (+14 more)

### Community 133 - "Exec Summary"
Cohesion: 0.23
Nodes (15): get, overview(), exec_summary_view(), dashboard_page(), Security posture dashboard API + page. Routes: GET /api/v1/dashboard aggregated…, _s(), _headline(), _posture_paragraph() (+7 more)

### Community 27 - "DAST: Config"
Cohesion: 0.09
Nodes (40): get, status(), list_targets(), post, add_target(), delete, delete_target(), limit (+32 more)

### Community 111 - "API: Design Review"
Cohesion: 0.14
Nodes (19): _webhook_secret(), _verify(), _adf_to_text(), _ticket_text(), _sync_lineage_best_effort(), _find_target_repo(), _rescan_affected_repo_background(), post (+11 more)

### Community 2 - "JIRA Client"
Cohesion: 0.06
Nodes (42): _clip(), _post_comment_best_effort(), _post_rescan_comment_best_effort(), Comment the review summary back on the ticket. Never raises — a Jira outage or…, Comment the rescan's correlation verdict back on the ticket that triggered it —…, UnsafeURLError, RuntimeError, _assert_safe_url() (+34 more)

### Community 122 - "Fleet"
Cohesion: 0.15
Nodes (16): get, summary(), repos(), Fleet-wide correlation posture across every registered SAST repo / DAST target…, _registered_repos(), _source_repo_index(), _latest_correlation_by_repo(), _verdict_counts() (+8 more)

### Community 159 - "Incidents"
Cohesion: 0.22
Nodes (12): get, list_all(), post, create(), Production-incident ingestion API. POST /api/v1/incidents record one or more…, _now_iso(), _normalize_entry(), _category() (+4 more)

### Community 221 - "API: Lineage (lineage.py)"
Cohesion: 0.36
Nodes (7): get, status(), list_threats(), get_threat(), post, sync(), Design-to-code threat lineage API. Routes (CSRF + optional TM_API_KEY apply via…

### Community 207 - "API: Login"
Cohesion: 0.33
Nodes (8): _safe_next(), get, login_page(), post, login_submit(), logout(), Sign-in page, backed by a real credential store (users_db.py, SQLite). Nothing…, Only ever redirect to a same-site path — never a scheme or a protocol-relative…

### Community 208 - "API: Lookups (lookups.py)"
Cohesion: 0.28
Nodes (8): get, list_compliance_frameworks(), lookup_attack(), lookup_compliance(), Lookup and compliance metadata API routes., List compliance frameworks known to the local mapper., Look up MITRE ATT&CK techniques for a category., Look up compliance controls for a category.

### Community 192 - "API: Ownership (api/ownership.py)"
Cohesion: 0.33
Nodes (10): get, list_owners(), get_defaults(), post, set_default(), list_assignments(), assign(), delete (+2 more)

### Community 104 - "Offline Pattern Enrichment (patterns.py)"
Cohesion: 0.17
Nodes (19): get, list_patterns(), list_patterns_for_ruleset(), get_pattern(), Offline pattern catalog API routes., List every offline pattern with full analyst context., List enriched offline patterns for one ruleset., Fetch one enriched offline pattern. (+11 more)

### Community 209 - "API: PQC (pqc.py)"
Cohesion: 0.22
Nodes (8): post, limit, assess_pqc(), get, report_pqc(), Post-quantum cryptography API routes., Assess architecture text or uploaded files for PQC migration risk., Assess and persist PQC findings for an existing report.

### Community 5 - "Regression"
Cohesion: 0.05
Nodes (49): get, list_cases(), get_case(), post, run_case(), run_all(), list_alerts(), ack_alert() (+41 more)

### Community 18 - "API: Reports"
Cohesion: 0.07
Nodes (45): _load(), get, list_reports(), get_report(), report_structure(), report_findings(), report_paths(), report_safe() (+37 more)

### Community 193 - "API: Rules"
Cohesion: 0.27
Nodes (10): get, list_rules(), facets(), stats(), get_rule(), dashboard(), Rule catalog API + dashboard page. Serves the semgrep rule *reference* catalog…, rules.html (Rule Catalog page) (+2 more)

### Community 39 - "API: SAST"
Cohesion: 0.12
Nodes (35): get, post, delete, delete_repo(), limit, scan_repo(), list_jobs(), metrics() (+27 more)

### Community 17 - "App (top-level) - sbom.py"
Cohesion: 0.06
Nodes (44): post, limit, analyze_sbom(), Analyze a CycloneDX or SPDX SBOM., _scrub_secrets(), _prune_reports_to_limit(), _aggregate_rule_risk_rating(), _enrich_with_rule_references() (+36 more)

### Community 105 - "API: Suppressions"
Cohesion: 0.13
Nodes (20): _load_report(), get, list_all(), post, create(), delete, delete(), report_suppressed() (+12 more)

### Community 222 - "API: Tickets (tickets.py)"
Cohesion: 0.32
Nodes (7): post, limit, create_tickets(), publish_confluence_page(), Ticket creation API routes., Create Jira, Azure DevOps, or Linear tickets for report findings., Publish a Confluence page summarizing report findings.

### Community 134 - "API: Triage"
Cohesion: 0.22
Nodes (16): _sort_order_from_request(), _filters_from_request(), get, methodologies(), list_queue(), export_csv(), export_sarif(), triage_page() (+8 more)

### Community 1 - "App (top-level) - app.py"
Cohesion: 0.06
Nodes (66): _prune_stale_jobs(), _login_exempt(), after_request, _prod_headers(), before_request, _auth_and_csrf(), errorhandler, _not_found() (+58 more)

### Community 85 - "Report Store"
Cohesion: 0.15
Nodes (23): _load_or_create_secret_key(), Path, Resolve the Flask SECRET_KEY: TM_SECRET_KEY env var wins, else a key persisted…, atomic_replace(), atomic_write_text(), atomic_write_json(), read_json(), _backup_paths() (+15 more)

### Community 235 - "Wsgi"
Cohesion: 0.27
Nodes (4): template_filter, _format_epoch(), Render a Unix-epoch (seconds) timestamp as a readable UTC date/time., wsgi.py — Production WSGI entry point. Linux/Mac: gunicorn --bind 0.0.0.0:5001…

### Community 95 - "Report DB"
Cohesion: 0.13
Nodes (22): _backfill_report_db(), One-time migration of a pre-2026-07-23 JSON-only install into the database.…, _connect(), Connection, init(), delete_report(), delete_all(), prune_to_limit() (+14 more)

### Community 11 - "Suppressions: Store"
Cohesion: 0.07
Nodes (44): _backfill_suppressions_db(), One-time migration of a pre-2026-07-25 ~/.tm_suppressions.json install into…, Risk-acceptance / finding-suppression workflow. A security tool that cannot…, _connect(), Connection, init(), _row_to_suppression(), Row (+36 more)

### Community 3 - "DAST Validate Tests"
Cohesion: 0.05
Nodes (35): _backfill_broker_db(), One-time migration of a pre-2026-07-25 ~/.tm_broker JSON install into SQLite.…, _connect(), Connection, init(), load_repos(), save_repos(), upsert_repo() (+27 more)

### Community 30 - "GITHUB Arch Tests"
Cohesion: 0.08
Nodes (39): _architecture_from_github(), Derive a threat-model architecture description from a repo's code., _fmt_entry(), describe_model(), Render a SystemModel as a plain-text architecture description. The threat-model…, Return a threat-model-ready textual description of the code model., _slug(), _lbl() (+31 more)

### Community 183 - "Readme"
Cohesion: 0.20
Nodes (12): analyze_route(), test_api_v1_contract.py — /api/v1 blueprint contract tests, wsgi.py (Production WSGI entry point), Rationale: non-loopback bind without TM_API_KEY warns of unauthenticated GitHub-token exposure, API_V1.md — Yaksha Guard API v1 surface documentation, Rationale: legacy /api/... routes frozen, new endpoints only under /api/v1, PRD.md — Yaksha Guard Unified Security Assurance Platform, Rationale: mediator/correlation layer is the product's core differentiator, not another scanner (+4 more)

### Community 106 - "Arch Drift (arch_drift.py)"
Cohesion: 0.17
Nodes (18): _infer_kind(), DeclaredModel, _build_declared(), declared_from_drawio(), declared_from_report(), DriftFinding, _cm_meta(), diff() (+10 more)

### Community 160 - "Assetgraph: Service"
Cohesion: 0.23
Nodes (12): assetgraph — a persistent, accumulating graph of assets across every codemodel…, now_iso(), _load_report(), sync(), _edge_dict(), _asset_dict(), list_assets(), get_asset() (+4 more)

### Community 112 - "Assetgraph: DB"
Cohesion: 0.24
Nodes (19): _connect(), Connection, init(), _row_to_asset(), Row, _row_to_edge(), get_asset(), upsert_asset() (+11 more)

### Community 79 - "Assetgraph DB Tests"
Cohesion: 0.13
Nodes (10): _id(), extract(), assetgraph/engine.py — pure extraction: a codemodel report -> assets + edges.…, Extract this codemodel report's current asset snapshot for its repo. The result…, Asset, assetgraph/model.py — data model for the persistent, accumulating asset graph.…, _asset(), _edge() (+2 more)

### Community 210 - "Benchmark: Codemodel Harness"
Cohesion: 0.33
Nodes (7): Measured-accuracy benchmark for the offline analysis engine., _build(), _pr(), evaluate(), format_report(), main(), Measured-accuracy harness for the code-derived threat-model engine. Scores…

### Community 211 - "Benchmark: Harness (benchmark/harness.py)"
Cohesion: 0.33
Nodes (8): _status_of(), _meets_expect(), evaluate(), format_report(), main(), Measured-accuracy harness for the OFFLINE deterministic analysis engine. TM's…, The targeted rule's status in a review, or PASS if it did not fire/apply., Run the full corpus and return structured metrics (no printing).

### Community 107 - "Broker: Mapper"
Cohesion: 0.15
Nodes (16): SAST broker service. Scans internal repositories with a static analysis engine…, _push_remote(), main(), Standalone broker entry point. Lets the broker run as a separate process next…, _sev(), _highest_severity(), _severity_counts(), _category_from_group() (+8 more)

### Community 53 - "Broker: Engines"
Cohesion: 0.10
Nodes (31): resolve_opengrep_config(), opengrep_rules_are_local(), The `--config` value for opengrep/semgrep. Resolution order (first wins): an…, True when opengrep will read rules from disk (no registry/network call)., detect_languages(), Path, _find_binary(), available_engines() (+23 more)

### Community 184 - "Broker: Delta"
Cohesion: 0.23
Nodes (11): _norm_path(), _norm_snippet(), finding_fingerprint(), fingerprints(), partition_new(), Finding fingerprints, baselines, and PR delta gating. A *fingerprint* is a…, Repo-relative, forward-slash path with any leading ./ or / removed., Collapse all whitespace so formatting-only changes keep one identity. (+3 more)

### Community 24 - "Broker: GITHUB"
Cohesion: 0.08
Nodes (35): parse_webhook(), _as_pr_number(), _ignored(), GitHubError, RuntimeError, GitHubClient, gate_passes_findings(), _status_line() (+27 more)

### Community 96 - "DAST: GITHUB"
Cohesion: 0.14
Nodes (21): verify_signature(), gate_passes(), Validate a GitHub `X-Hub-Signature-256: sha256=<hex>` header. Returns False…, True when nothing in the report is at or worse than the fail_on severity., parse_webhook(), _ignored(), _md(), _status_line() (+13 more)

### Community 20 - "Broker: Scanner"
Cohesion: 0.07
Nodes (43): is_valid_ref(), authed_clone_url(), A git ref/refspec safe to hand to `git fetch` (no leading dash, no spaces)., Embed a token into an https GitHub URL for cloning a private repo. Only…, _diff_names(), changed_files(), Path, run() (+35 more)

### Community 71 - "Broker: Reviewer (threat_from_finding)"
Cohesion: 0.12
Nodes (23): _threat_from_finding(), _lang_of(), _source_re(), Pattern, _py_function(), _brace_function(), _enclosing_scope(), _taint_map() (+15 more)

### Community 25 - "Settings DB Tests"
Cohesion: 0.07
Nodes (23): enabled(), _connect(), Connection, init(), set_value(), get_value(), unset(), clear_all() (+15 more)

### Community 185 - "Broker: Remediation (remediation.py)"
Cohesion: 0.23
Nodes (11): find_threat(), propose_fix(), _clean_locus(), _verdict_index(), queue(), broker/remediation.py — human-gated fix-PR proposals for SAST findings. TM has…, Locate the one file:line hit a propose/open-pr call is addressing. TM has no…, Read-only: return a reviewable patch for one finding, or why not. ``against``… (+3 more)

### Community 257 - "Broker: Remediation (RemediationError)"
Cohesion: 0.67
Nodes (3): RemediationError, RuntimeError, Raised for any propose/open-pr failure the API layer should surface cleanly.

### Community 36 - "Broker Tests (ScanError)"
Cohesion: 0.06
Nodes (23): ScanError, RuntimeError, looks_like_git_url(), Raised when workspace prep or the scan engine fails., True for git URLs (https/ssh/git/file or scp-like git@host:path)., TestUrlClassification, TestConcurrencySerialization, TestDelta (+15 more)

### Community 21 - "Broker: Service"
Cohesion: 0.08
Nodes (16): BrokerService, Lock, _branch_from_ref(), Return the (lazily created) workspace lock for one repo id., Admin flush: drop every job from memory and persistence (baselines, sha cache)…, Return the id of an already queued/running scan for the same event. GitHub…, Reuse a prior report for an already-scanned SHA. Returns True on hit., Capture/consult the base-branch baseline for PR delta gating. On a push, record… (+8 more)

### Community 237 - "Broker Tests (due_repos)"
Cohesion: 0.33
Nodes (3): Repos whose `scan_interval_hours` has elapsed since their last scan., TestWorkerPoolAndScheduler, Bounded pool (#4) and scheduler selection (#9).

### Community 97 - "Diagram Generator"
Cohesion: 0.19
Nodes (20): _with_backoff(), call_claude(), claude_client.py — Shared Anthropic SDK client with prompt caching and retry., Call fn(), retrying on rate-limit/server errors with exponential backoff., Call Claude with ephemeral cache on the system prompt., _extract_mermaid(), _node(), generate_architecture_diagram_offline() (+12 more)

### Community 9 - "Codemodel Tests (codemodel/__init__.py)"
Cohesion: 0.05
Nodes (35): Code-derived threat modeling engine for Yaksha Guard. Reads a codebase and…, classify(), Business-impact classification for code-derived findings. Technical…, Infer a business-impact tier from free text. Pass route paths, handler names,…, now_iso(), _architecture_category(), _attack_surface(), build_report() (+27 more)

### Community 31 - "Codemodel: Extractor"
Cohesion: 0.09
Nodes (37): nearest_match(), Graph-proximity variant of :func:`classify`. ``candidates`` is ``[(text, hops),…, _iter_files(), _rel(), build_model(), _safe_read(), _assemble_python(), _assemble_poly() (+29 more)

### Community 72 - "Codemodel: Chain Reasoning (chain_reasoning.py)"
Cohesion: 0.13
Nodes (23): ChainStep, Chain, _coerce_severity(), _coerce_confidence(), _select_entry_points(), _known_loci(), _extract_bounded(), _fact_locus_index() (+15 more)

### Community 57 - "Codemodel: Terraform Extractor"
Cohesion: 0.11
Nodes (22): is_config_file(), extract(), _extract_env(), _extract_dockerfile(), _extract_generic(), Lightweight, regex-based extraction from configuration files. Half of a…, Secret, TrustBoundary (+14 more)

### Community 8 - "Codemodel: Polyglot Extractor (Sink)"
Cohesion: 0.10
Nodes (48): Sink, Control, ExternalCall, DataStore, A security-sensitive operation reachable in the code., A security control observed in the code., A call that leaves the process / crosses a trust boundary., A persistence or state boundary the code connects to. (+40 more)

### Community 26 - "Codemodel: Python Extractor (DependencyUse)"
Cohesion: 0.09
Nodes (26): DependencyUse, A call into a third-party import, reachable in the code. Sink only covers the…, _attr_chain(), _last_attr(), _root_name(), _str_arg(), _names_in(), _attr_roots_in() (+18 more)

### Community 123 - "Compliance Mappings"
Cohesion: 0.13
Nodes (18): get_controls(), get_frameworks_for_finding(), enrich_categories(), compliance_summary(), _verdict_adjusted_impact(), weighted_compliance_summary(), compliance_mappings.py — Control cross-reference: OWASP → PCI DSS 4.0, HIPAA,…, Return compliance controls for an OWASP category ID. (+10 more)

### Community 19 - "Confidence Decay"
Cohesion: 0.08
Nodes (43): decayed_confidence(), needs_reverification(), annotate_rows(), _correlated_rows(), summary(), confidence_decay.py — a correlated finding's confidence score decays the longer…, Exponential decay: halves every ``_HALF_LIFE_DAYS[verdict]`` days without a…, True once a finding has sat at its current verdict for a full half-life without… (+35 more)

### Community 113 - "Control Register"
Cohesion: 0.17
Nodes (19): _verdict_adjusted_priority(), _classify_control_type(), _make_control_id(), _as_text(), _first_text(), _join_limited(), _control_summary(), _control_domain() (+11 more)

### Community 38 - "New Modules Tests"
Cohesion: 0.08
Nodes (27): generate_control_register(), Generate a control register from a threat model report. Returns a list of…, assess_text(), pqc_to_category(), pqc_assessment.py — Post-Quantum Cryptography assessment module. Evaluates…, Scan architecture text for quantum-vulnerable cryptographic algorithms. Returns…, Convert PQC assessment to analyzer 'category' format for UI rendering., test_pqc_detects_rsa() (+19 more)

### Community 73 - "Correlator: Model"
Cohesion: 0.12
Nodes (21): Correlation (mediator) engine for Yaksha Guard. Sits between the threat-model…, correlate(), Correlate a set of saved reports into ranked cross-source findings., now_iso(), _threat_from_observation(), _category_from_finding(), _verdict_counts(), findings_to_report() (+13 more)

### Community 40 - "Correlator: Engine"
Cohesion: 0.09
Nodes (36): _import_roots(), _component_names(), _merge_reachability(), _dependency_hits(), annotate_dependency_reachability(), _union_find(), _cluster_family(), _expand_owasp_designs() (+28 more)

### Community 48 - "Correlator: Taxonomy"
Cohesion: 0.07
Nodes (34): _source_kind(), _category_text(), _category_locations(), _first_remediation(), observe_report(), Decide the evidence class of one category. A per-category ``_source`` tag (set…, A blob of every free-text field, for CWE/keyword scraping., Turn one saved report into a list of normalized observations. (+26 more)

### Community 161 - "Correlator: Self Quality"
Cohesion: 0.21
Nodes (12): _latest_per_fingerprint(), _tag_reversals(), reversal_rate(), precision_trend(), summary(), correlator/self_quality.py — the correlator's own precision over time. Every…, alerts must be ordered oldest-first (verdict_tracking.all_alerts' contract) so…, One row per fingerprint (its latest escalation in ``alerts``), tagged with… (+4 more)

### Community 15 - "Dashboard: Service"
Cohesion: 0.07
Nodes (49): list_reachable_dependencies(), Vulnerable-dependency (SBOM) findings with a code-model-proven reachable call…, _empty_sev(), _cat_severity(), _active_severity_totals(), _threat_model_posture(), _families(), _verdicts() (+41 more)

### Community 62 - "DAST: Mapper"
Cohesion: 0.11
Nodes (23): Dynamic Application Security Testing (DAST) package. A running-application…, _push_remote(), main(), Standalone DAST scanner entry point. Lets the dynamic scanner run as a separate…, parse_scope(), Comma/space separated host allowlist; falls back to the target's own host. The…, _highest_severity(), _severity_counts() (+15 more)

### Community 32 - "Benchmark: Harness (dast/benchmark/harness.py)"
Cohesion: 0.11
Nodes (34): _page(), _enc(), _sc_xss_body(), _sc_xss_attr(), _sc_xss_comment(), _sc_xss_textarea(), _sc_xss_encoded(), _sc_redirect() (+26 more)

### Community 37 - "DAST: Engine (dast/engine.py)"
Cohesion: 0.13
Nodes (35): _same_scope(), _strip_fragment(), _looks_binary(), _consider(), ScanResult, scan(), _param_signature(), _path_signature() (+27 more)

### Community 108 - "Regression Tests (Resp)"
Cohesion: 0.20
Nodes (6): Resp, _decode(), _mk_resp(), _FakeFetcher, RegressionRunTests, Duck-types dast.engine.Fetcher's .get(url) -> Resp, without any network I/O.

### Community 74 - "DAST: Engine (Fetcher)"
Cohesion: 0.20
Nodes (24): Fetcher, _seed_from_site(), _active_checks(), _mutate(), _probe_reflected_xss(), _probe_open_redirect(), _inject(), _req_line() (+16 more)

### Community 170 - "DAST: Engine (LinkParser)"
Cohesion: 0.17
Nodes (5): _LinkParser, HTMLParser, _BreakoutDetector, Collect crawlable link targets and GET-form endpoints from an HTML page.…, Detect whether an injected, uniquely-named tag actually parsed as markup. The…

### Community 94 - "DAST: Service"
Cohesion: 0.16
Nodes (5): DastService, Admin flush: drop every job from memory and persistence so the dashboard…, Return the id of an already queued/running scan for this work, if any. GitHub…, Post the deployment gate signal back to GitHub for webhook scans., Re-synthesize attack paths for this target's linked repo using the scan that…

### Community 202 - "DAST: Validate"
Cohesion: 0.24
Nodes (9): repo_id_for_target(), latest_codemodel_report(), validate(), dast/validate.py — attack-path validation from a completed DAST scan.…, The SAST-broker repo id this DAST target's application was built from, resolved…, Most recent saved codemodel report for this repo, or None if it has never been…, Synthesize attack paths for this target's repo, using ``dast_report`` as…, attack_paths.synthesize()/to_report() (external) (+1 more)

### Community 80 - "Suppressions: Engine"
Cohesion: 0.11
Nodes (22): _next_step(), _rows(), agenda(), design_gap_agenda.py — per-finding worklist for the open design-gap backlog.…, Open design-gap findings, oldest (most overdue) first, each carrying a concrete…, _norm_locus_token(), _loci(), _rule_id() (+14 more)

### Community 114 - "EPSS KEV"
Cohesion: 0.16
Nodes (19): _empty_cache(), _load(), _save(), lookup(), combined_lookup(), cache_status(), refresh_kev(), refresh_epss() (+11 more)

### Community 172 - "Guard Diff Tests"
Cohesion: 0.15
Nodes (3): guard/diff.py — turn a unified diff into per-file added-line sets. A pre-merge…, TestParseAddedLines, Tests for guard.diff — unified-diff parsing into per-file added-line sets.

### Community 212 - "Guard: Scan"
Cohesion: 0.31
Nodes (8): parse_added_lines(), Map each file touched by a unified diff to the new-side lines it adds. Only…, GuardFinding, _sink_severity(), _title(), scan_diff(), guard/scan.py — diff-scoped code security scan for the pre-merge gate. Reuses…, Findings from ``repo_root`` whose file:line was added by this diff.

### Community 63 - "Lineage: DB"
Cohesion: 0.15
Nodes (25): lineage — persistent design-to-code threat traceability. Tracks one underlying…, _connect(), Connection, init(), _row_to_threat(), Row, get(), all_threats() (+17 more)

### Community 126 - "Lineage: Engine"
Cohesion: 0.20
Nodes (15): now_iso(), _threat_id(), _status_from_kinds(), _find_match(), sync_observations(), sync_report(), lineage/engine.py — pure matching logic: observations -> lineage updates.…, Match observations against ``existing`` (mutated in place) and return (threats… (+7 more)

### Community 149 - "LLM Attack Vector Atlas"
Cohesion: 0.21
Nodes (14): _normalise_cell(), _slug_phrases(), _domain_key(), _row_domain_from_id(), _severity(), _patterns(), _make_rule(), _parse_checklist() (+6 more)

### Community 115 - "Mitre Attack"
Cohesion: 0.14
Nodes (19): _normalize_ruleset(), _normalize_category(), _dedupe_techniques(), get_techniques(), enrich_findings(), enrich_categories(), mitre_attack.py — MITRE ATT&CK Enterprise technique mappings for threat…, Return list of ATT&CK technique dicts for a given category ID. category: e.g.… (+11 more)

### Community 7 - "Offline Patterns (offline_patterns.py)"
Cohesion: 0.08
Nodes (60): _now_ms(), _contains_any(), _ai_surface_applicable(), _matched(), _risk_score(), _effective_finding_risk(), _worst_risk(), _overall_from_categories() (+52 more)

### Community 56 - "Offline Patterns (dedupe_text)"
Cohesion: 0.09
Nodes (31): _dedupe_text(), _component_terms(), _sentences(), _component_evidence(), _local_text(), _boundary_for_component(), _matched_controls(), _matched_negative_signals() (+23 more)

### Community 13 - "Offline Rules Tests"
Cohesion: 0.08
Nodes (50): _check_rule(), detect_applicable_rulesets(), run_offline_review(), Evaluate one rule against architecture text. Returns result dict., Auto-detect applicable rulesets using keyword matching (no API key required)., Run deterministic offline review against architecture text. Args:…, test_detect_architecture_always_included(), test_detect_devsecops_from_pipeline_keywords() (+42 more)

### Community 246 - "Owasp Web 2025"
Cohesion: 0.40
Nodes (4): owasp_web_2025.py — OWASP Web Application Top 10 (2025) checklist data., OWASP_LLM_TOP10 knowledge base, findingTitles id-to-name lookup (JS), attackVectorDetails narrative descriptions (JS)

### Community 98 - "Ownership"
Cohesion: 0.18
Nodes (21): _connect(), Connection, init(), set_default(), get_defaults(), assign(), clear_assignment(), list_assignments() (+13 more)

### Community 173 - "Nav API Tests"
Cohesion: 0.15
Nodes (4): Single source of truth for the portal navigation. Every page's navbar…, NavApiTests, Portal navigation: portal_nav.py is the single source of truth. GET /api/v1/nav…, Each tab's advertised API base must answer (GET base or a probe under it), so…

### Community 116 - "Redos Audit (redos_audit.py)"
Cohesion: 0.15
Nodes (19): _quant_at(), _group_bodies(), _has_unbounded_inner_quant(), _alternation_overlaps(), _adjacent_unbounded(), audit_pattern(), audit_patterns(), audit_source_file() (+11 more)

### Community 132 - "Rules Catalog (rules_catalog.py)"
Cohesion: 0.33
Nodes (16): sev_label(), _payload(), Any, _cwe_index(), related(), notice(), all_rules(), _public() (+8 more)

### Community 127 - "SARIF"
Cohesion: 0.22
Nodes (17): _norm_severity(), _rule_id(), _cwes(), _tags(), _location(), _fingerprint(), _threat_loci(), _clean_locus() (+9 more)

### Community 51 - "SARIF Import"
Cohesion: 0.12
Nodes (32): SarifError, _band_from_security_severity(), _severity_for(), _worst(), _rule_tags(), _cwes(), _owasp(), _text() (+24 more)

### Community 64 - "SBOM Parser"
Cohesion: 0.12
Nodes (27): SBOMComponent, SBOMVulnFinding, SBOMReport, _parse_cyclonedx_json(), _extract_cdx_license(), _parse_cyclonedx_xml(), _parse_spdx_json(), _parse_spdx_text() (+19 more)

### Community 194 - "SSVC"
Cohesion: 0.29
Nodes (9): SSVCResult, _exploitation(), _exposure(), _automatable(), _human_impact(), _action(), decide(), ssvc.py — Stakeholder-Specific Vulnerability Categorization triage action for a… (+1 more)

### Community 68 - "Static: Tm Fallback (tm_fallback.js)"
Cohesion: 0.21
Nodes (26): qs(), qsa(), text(), esc(), toast(), setStatus(), fetchCsrf(), apiFetch() (+18 more)

### Community 42 - "Triage Tests (finding_fingerprint)"
Cohesion: 0.12
Nodes (6): finding_fingerprint(), A report-independent, line-insensitive identity for one finding., _report(), _cat(), TriageQueueTests, Tests for the flat, sortable, cross-report triage worklist (triage.py).…

### Community 164 - "System Design: System Design Full (basic_usage.py)"
Cohesion: 0.19
Nodes (12): main(), Small example for using system_design_skill.py as a library., SkillLoadError, Path, read_required(), read_optional(), default_output_path(), build_parser() (+4 more)

### Community 81 - "System Design: System Design Full (system_design_full.py)"
Cohesion: 0.17
Nodes (20): SkillMetadata, SearchHit, parse_skill_metadata(), parse_frontmatter(), find_markdown_link(), parse_markdown_sections(), clean_heading(), markdown_to_text() (+12 more)

### Community 162 - "System Design: System Design Full (SkillError)"
Cohesion: 0.18
Nodes (9): SkillError, Exception, TopicNotFoundError, TopicSection, StudyPlanDay, chunk_evenly(), print_section_meta(), Base exception for user-facing skill tool errors. (+1 more)

### Community 175 - "System Design: System Design Full (to_payload)"
Cohesion: 0.35
Nodes (4): IssueRecord, SystemDesignKnowledgeBase, replace_issue(), In-memory knowledge base built from the generated skill markdown files.

### Community 135 - "System Design: System Design Full (Flashcard)"
Cohesion: 0.21
Nodes (10): Flashcard, QuizQuestion, sentence_split(), first_sentences(), json_print(), print_wrapped(), run_command(), Namespace (+2 more)

### Community 10 - "System Design: System Design Skill"
Cohesion: 0.07
Nodes (29): MarkdownSection, SearchResult, StudyDay, Flashcard, QuizQuestion, SystemDesignSkill, Path, read_text() (+21 more)

### Community 174 - "System Design Advisor"
Cohesion: 0.29
Nodes (12): _knowledge_base(), _category_text(), _report_text(), _topic_payload(), _unique_topics(), _domain_guidance(), build_system_design_context(), _decision_from_category() (+4 more)

### Community 44 - "AIBOM Tests (test_aibom.py)"
Cohesion: 0.09
Nodes (14): _write(), Path, _build_ai_repo(), _ids(), _component(), TestEngineAiRepo, TestEngineCleanAndGating, TestMapper (+6 more)

### Community 176 - "Arch Drift Tests (cm_report)"
Cohesion: 0.24
Nodes (3): _cm_report(), TestDiff, TestToReport

### Community 136 - "Arch Drift Tests (TestDeclaredParsing)"
Cohesion: 0.12
Nodes (4): TestDeclaredParsing, TestDriftApi, TestAnalyzeApiErrorHandling, POST /api/v1/code-model/analyze must only convert *expected* failures…

### Community 137 - "Assetgraph Engine Tests"
Cohesion: 0.19
Nodes (4): _codemodel_report(), TestExtract, Tests for assetgraph.engine — pure extraction of assets/edges from a codemodel…, The whole point of a graph: the same external target called by two different…

### Community 150 - "Assetgraph Service Tests (test_assetgraph_service.py)"
Cohesion: 0.19
Nodes (3): _codemodel_report(), TestAssetGraphServiceDirect, Tests for assetgraph.service (direct) and the /api/v1/assetgraph API (Flask).…

### Community 58 - "Attack Paths Tests"
Cohesion: 0.12
Nodes (9): _cm_report_from_source(), _surface(), _dast(), TestSynthesisUnit, TestToReport, TestEndToEndFromExtractor, TestAttackPathApi, Tests for attack-path synthesis (attack_paths) + the /correlate/attack-paths… (+1 more)

### Community 213 - "Benchmark Tests (test_benchmark.py)"
Cohesion: 0.22
Nodes (4): TestNegationRobustness, TestHarnessReport, Regression floors for the offline analysis engine's measured accuracy. The…, Directly guards the negation-aware control suppression: a design that describes…

### Community 151 - "Broker Tests (make_vuln_repo)"
Cohesion: 0.16
Nodes (7): _make_vuln_repo(), skipUnless, TestRealScan, TestPipeline, TestPipelineApiErrorHandling, One-button SAST + code-model + correlation (#10)., POST /repos/<id>/pipeline must only convert *expected* failures (ScanError: bad…

### Community 117 - "Broker Tests (TestMapper)"
Cohesion: 0.14
Nodes (5): TestMapper, TestChecksApi, TestDeltaGatingAndSarif, Check Run annotations + the auto-fallback to commit status., New-only gate + comment (#1) and SARIF code-scanning upload (#2).

### Community 75 - "Broker Tests (TestGitHubModule)"
Cohesion: 0.09
Nodes (4): TestGitHubModule, TestWebhookFlow, config_json(), Webhook auth + dispatch with the GitHub network calls mocked out.

### Community 100 - "Broker Tests (TestBrokerApi)"
Cohesion: 0.10
Nodes (5): TestBrokerApi, TestDashboardApi, TestRegistrationValidation, API surface the dashboard relies on: interval field + status fields., Registration-time pre-flight (validate_remote / POST repos validate:true).…

### Community 22 - "Canary Tests"
Cohesion: 0.07
Nodes (12): _threat(), _cat(), _report(), ParseLocusTests, QualifyingThreatsTests, GenerateCaseTests, GenerateForReportTests, ToBashScriptTests (+4 more)

### Community 28 - "Chain Reasoning Tests (test_chain_reasoning.py)"
Cohesion: 0.08
Nodes (11): _cm_report(), _bounded(), TestFactsText, TestGrounding, TestReasonUnit, TestToReport, TestIntegrationRealExtractor, TestChainReasoningApi (+3 more)

### Community 45 - "Codemodel Polyglot Tests (test_codemodel_polyglot.py)"
Cohesion: 0.07
Nodes (10): _eps(), TestExpress, TestExpressRouteWithLeadingObjectArg, TestMcpAgentTool, TestNest, TestBuildModelJoin, Tests for codemodel.polyglot_extractor — JS/TS/Go/Java design-fact extraction.…, A route handler preceded by a non-function argument (a schema/options object,… (+2 more)

### Community 69 - "Codemodel Terraform Tests"
Cohesion: 0.12
Nodes (8): _misconfigs(), S3BucketTests, SecurityGroupTests, IamPolicyTests, PublicDatabaseTests, NonResourceFileTests, ThreatDerivationIntegrationTests, Tests for codemodel/terraform_extractor.py. Run: python -m unittest…

### Community 70 - "Compliance Mappings Tests"
Cohesion: 0.10
Nodes (7): GetControlsColonSuffixTests, EnrichCategoriesColonSuffixTests, _cat(), WeightedComplianceSummaryTests, EnrichComplianceEndpointTests, Regression tests for compliance_mappings.py's category-id -> control lookup.…, The /enrich/compliance route must persist both the legacy flat gap summary and…

### Community 46 - "Confidence Decay Tests"
Cohesion: 0.07
Nodes (8): _cat(), _report(), DecayMathTests, AnnotateRowsTests, WorklistAndSummaryTests, VerdictTrackingSinceMapTests, ConfidenceApiTests, Tests for confidence_decay.py -- confidence erosion + forced re-verification…

### Community 0 - "Correlator Tests"
Cohesion: 0.06
Nodes (13): _sast_report(), _dast_report(), _codemodel_report(), _sbom_report(), _codemodel_sink_report(), _threat_model_report(), _incident_report(), TestTaxonomy (+5 more)

### Community 59 - "Correlator Service Tests"
Cohesion: 0.09
Nodes (11): _sast_dast_reports(), SuppressedFindingsTests, ListCorrelatableTests, _correlation_report_with_reachable_dep(), ListReachableDependenciesTests, ReportIdValidationTests, Tests for correlator/service.py's report loading. Run: python -m unittest…, An accepted-risk/false-positive decision must not inflate correlation output —… (+3 more)

### Community 76 - "DAST Tests (test_dast.py)"
Cohesion: 0.08
Nodes (8): TestEvidenceSnippet, TestConfig, TestScanner, _FakeClient, _FakeClientNoChecks, TestWebhookE2E, TestBenchmark, DAST module tests (stdlib unittest). Run from the tm project root: python -m…

### Community 152 - "DAST Tests (VulnHandler)"
Cohesion: 0.16
Nodes (4): _VulnHandler, BaseHTTPRequestHandler, _CorsHandler, _SeedHandler

### Community 143 - "DAST Tests (VulnServer)"
Cohesion: 0.19
Nodes (4): _VulnServer, TestEngineEndToEnd, TestEngineSafety, TestBudgetAndTruncation

### Community 229 - "DAST Tests (enter)"
Cohesion: 0.29
Nodes (3): TestReflectedOriginCors, TestCrawlSeeding, ThreadingHTTPServer

### Community 128 - "DAST Tests (ids)"
Cohesion: 0.26
Nodes (3): _ids(), TestNewPassiveChecks, TestInjectionChecks

### Community 87 - "DAST Refinements Tests"
Cohesion: 0.12
Nodes (10): _Handler, BaseHTTPRequestHandler, _simulate_sql(), _serve(), _fast_scan(), TestBooleanSqli, TestSri, TestBodyRatio (+2 more)

### Community 88 - "Design Gap Agenda Tests"
Cohesion: 0.16
Nodes (5): _cat(), _report(), AgendaTests, DesignGapAgendaApiTests, Tests for the per-finding design-gap worklist (design_gap_agenda.py). Isolated…

### Community 12 - "Engines Tests (test_engines.py)"
Cohesion: 0.08
Nodes (19): _sarif(), _result(), TestToFindings, TestDetectLanguages, TestSelection, TestNormalizeFinding, _stub_engine(), Path (+11 more)

### Community 29 - "EPSS KEV Tests"
Cohesion: 0.07
Nodes (12): _kev_response(), _epss_response(), _StubResponse, EpssKevTestCase, ExtractCvesTests, CacheLoadSaveTests, LookupTests, RefreshKevTests (+4 more)

### Community 82 - "Fleet Tests"
Cohesion: 0.19
Nodes (7): _sast_report(), _dast_report(), _cat(), _correlation_report(), FleetTests, FleetApiTests, Tests for fleet.py -- fleet-wide correlation posture across registered SAST…

### Community 153 - "Guard Scan Tests"
Cohesion: 0.15
Nodes (5): _write_fixture(), TestScanDiff, Tests for guard.scan — diff-scoped codemodel findings. The key property under…, Regression: an earlier design used the entry point's def line as the finding's…, Regression: the auth-gap fallback used to gate on `not ep.reachable_sinks`, so…

### Community 83 - "Incidents Tests"
Cohesion: 0.10
Nodes (4): TestBuildIncidentReport, TestIncidentsApi, Tests for incidents.py (pure report-building logic) and the api/incidents.py…, Live against the real app/report_db — cleans up every report it creates via the…

### Community 60 - "JIRA Webhook Tests (test_jira_webhook.py)"
Cohesion: 0.07
Nodes (9): TestAdfExtraction, TestRescanResultCommentDirect, TestRescanConcurrencyCap, TestAddCommentJiraOnly, TextToAdfTests, Tests for the Jira-triggered proactive design-review webhook…, Direct unit tests for _post_rescan_comment_best_effort's edge cases — the…, Bounds how many pipeline runs a burst of webhook calls can trigger at once,… (+1 more)

### Community 43 - "JIRA Webhook Tests (reset_limiter)"
Cohesion: 0.09
Nodes (7): _reset_limiter(), _body(), TestWebhookAuth, TestWebhookDispatch, TestRescanTrigger, End-to-end (no mocked lineage.sync): a ticket whose description matches an…, A ticket that names a registered repo (by component or project key) must queue…

### Community 178 - "Lineage DB Tests"
Cohesion: 0.24
Nodes (3): _threat(), _event(), TestLineageDb

### Community 154 - "Lineage Engine Tests (test_lineage_engine.py)"
Cohesion: 0.25
Nodes (5): _design_report(), _code_report(), _runtime_report(), TestSyncObservations, Tests for lineage.engine — pure observation-to-lineage matching. Design and…

### Community 109 - "Lineage Service Tests"
Cohesion: 0.10
Nodes (3): TestLineageServiceDirect, TestLineageApi, Tests for lineage.service (direct) and the /api/v1/lineage API (Flask).…

### Community 118 - "Login Gate Tests"
Cohesion: 0.16
Nodes (3): _malicious_report(), LoginGateTests, Tests for the opt-in session-login page gate (app.py's _auth_and_csrf). A login…

### Community 179 - "Mitre Attack Tests"
Cohesion: 0.15
Nodes (4): MobilePrefixRoutingTests, ColonSuffixCategoryIdTests, Regression tests for mitre_attack.py's category-id -> ruleset routing.…, owasp.py / offline_patterns.py's _framework_report stamp category ids with a…

### Community 180 - "Redos Audit Tests"
Cohesion: 0.15
Nodes (5): TestDangerous, TestSafe, TestSourceScan, TestBoundedSearch, Tests for the ReDoS static auditor. Run: python -m unittest test_redos_audit…

### Community 145 - "Regression Tests (test_regression.py)"
Cohesion: 0.29
Nodes (5): _threat(), _cat(), _report(), RegressionStoreTests, Tests for regression.py -- persisted canary/regression cases + re-runs.…

### Community 14 - "Remediation Tests"
Cohesion: 0.07
Nodes (10): _report_with_threat(), FindThreatTests, ProposeFixTests, OpenPrTests, _sast_report(), _correlation_report(), QueueTests, RemediationQueueApiTests (+2 more)

### Community 33 - "Report DB Tests"
Cohesion: 0.11
Nodes (5): _report(), _cat(), TestReportDbModule, TestReportDbApi, Tests for the SQLite report read-model (report_db) + its query endpoints. The…

### Community 110 - "Report Store Tests"
Cohesion: 0.10
Nodes (4): TestAtomicWrite, TestReadJson, TestIndexDurability, Tests for the crash-safe report store — the data-loss regression guard. Run:…

### Community 89 - "Reports API Tests"
Cohesion: 0.10
Nodes (4): _malicious_report(), TestReportView, TestReportsApiRoutes, Tests for the structured, HTML-safe reports API (/api/v1/reports/*). Covers the…

### Community 181 - "Reviewer Tests (test_reviewer.py)"
Cohesion: 0.19
Nodes (5): _ws(), Path, TestSafetyAndPlumbing, Tests for broker/reviewer.py — per-finding PR-reviewer analysis. Everything…, Write {relpath: source} into a fresh temp dir and return its Path.

### Community 129 - "Reviewer Tests (TestTaintVerdicts)"
Cohesion: 0.20
Nodes (3): _review(), TestTaintVerdicts, TestScopeExtraction

### Community 217 - "Rules Tests (test_rules.py)"
Cohesion: 0.22
Nodes (3): AggregateRuleRiskRatingTests, Rule catalog tests (stdlib unittest). Run from the tm project root: python -m…, Pure unit tests for app._aggregate_rule_risk_rating against synthetic refs,…

### Community 165 - "SARIF Tests (test_sarif.py)"
Cohesion: 0.15
Nodes (4): _rows(), TestSarifRows, Tests for the SARIF 2.1.0 exporter. Run: python -m unittest test_sarif Asserts…, Same SARIF 2.1.0 contract as TestSarif, but built from flat triage rows…

### Community 54 - "SARIF Import Tests"
Cohesion: 0.09
Nodes (8): _doc(), TestSarifImportParsing, TestSarifImportErrors, TestSarifRoundTrip, TestSarifImportApi, TestImportedReportCorrelates, Tests for SARIF 2.1.0 import (sarif_import) + the /reports/import/sarif API.…, The payoff: an imported scanner finding + a DAST finding at the same feature…

### Community 187 - "Secret Key Tests"
Cohesion: 0.17
Nodes (3): TestSecretKeyResolution, skipIf, Tests for persistent SECRET_KEY resolution (_load_or_create_secret_key). The…

### Community 119 - "Self Quality Tests"
Cohesion: 0.17
Nodes (5): _cat(), _report(), SelfQualityTests, PrecisionApiTests, Tests for correlator/self_quality.py -- the correlator's own reversal rate…

### Community 34 - "SSVC Tests"
Cohesion: 0.05
Nodes (4): DecisionPointTests, ActionTableTests, DecideEndToEndTests, Tests for ssvc.py — the SSVC-inspired decision-point derivation and action.…

### Community 130 - "Suppressions Tests (cat)"
Cohesion: 0.23
Nodes (3): _cat(), TestFingerprint, TestEngineMatching

### Community 167 - "Suppressions DB Tests"
Cohesion: 0.23
Nodes (3): _supp(), TestSuppressionsDb, Tests for the SQLite suppressions store (suppressions/db.py). Isolates onto a…

### Community 146 - "Tm Guard CLI Tests"
Cohesion: 0.26
Nodes (5): _git(), _ns(), Namespace, TestTmGuardCli, End-to-end tests for tm_guard.py against a real temporary git repository.…

### Community 90 - "Users DB Tests"
Cohesion: 0.08
Nodes (3): TestUsersDb, Tests for the user credential store (users_db.py). Isolates onto a temp DB,…, A DB created before the role column existed must migrate in place, not lose its…

### Community 91 - "Verdict Reconciliation Tests (test_verdict_reconciliation.py)"
Cohesion: 0.16
Nodes (5): _cat(), _report(), StoreBackedTests, ReconciliationApiTests, Tests for verdict_reconciliation.py -- cross-REPORT verdict reconciliation…

### Community 16 - "Verdict Tracking Tests"
Cohesion: 0.09
Nodes (7): _cat(), _report(), TestVerdictTracking, TestVerdictSla, TestDesignDebt, TestVerdictTrackingApi, Tests for verdict_tracking.py — escalation detection across re-correlations.…

### Community 147 - "Viewer Security Tests (test_viewer_security.py)"
Cohesion: 0.15
Nodes (6): _html(), TestEscaperStatic, skipUnless, TestEscaperFunctional, Static + functional guards for report-viewer output encoding. The report viewer…, Execute the real esc/escAttrJs against breakout payloads via node.

### Community 52 - "Admin Tests"
Cohesion: 0.11
Nodes (6): _IsolatedStoresMixin, TestAuthGate, TestUserManagement, TestFlush, Repoints every store the flush action can touch onto one temp dir., auth.is_admin() reads users_db fresh every request, not a cached session value…

### Community 199 - "API V1 Contract Tests"
Cohesion: 0.22
Nodes (4): _isolate_report_store(), test_api_v1_analysis_review_alias_persists_report(), test_api_v1_controls_alias_returns_register(), Contract tests for the versioned API surface.

### Community 55 - "Dashboard Tests (tests/test_dashboard.py)"
Cohesion: 0.07
Nodes (6): _cat(), _report(), TestDashboardVerdicts, TestDashboardApi, Security posture dashboard: aggregation service + API. The service summarizes…, Isolated from TestDashboardService's fixed-count fixtures since these tests…

### Community 65 - "Exec Summary Tests"
Cohesion: 0.15
Nodes (4): _cat(), _report(), ExecSummaryTests, ExecSummaryApiTests

### Community 77 - "Export Filters Tests"
Cohesion: 0.11
Nodes (6): _cat(), _IsolatedStoresMixin, SarifVerdictFilterTests, TriageExportRowsTests, TriageCsvEndpointTests, Verdict-filtered SARIF export (app.py::_export_report_sarif_impl) and the…

### Community 84 - "PR Tm Tests (tests/test_pr_tm.py)"
Cohesion: 0.08
Nodes (6): TestEnabled, TestRun, TestChangedFiles, TestReportDbSastExclusion, PR-scoped threat modeling (broker/pr_tm.py) + SAST exclusion in report_db.…, Viewer-facing queries hide methodology='sast' unless opted in.

### Community 139 - "SAST Visibility Tests"
Cohesion: 0.32
Nodes (16): _isolate(), _save_pair(), _csrf(), test_general_list_hides_sast(), test_general_get_404s_sast(), test_general_delete_404s_sast_and_keeps_file(), test_general_exports_404_sast(), test_sast_api_lists_only_sast() (+8 more)

### Community 163 - "Tm Gate"
Cohesion: 0.22
Nodes (13): _parse_args(), Namespace, _run_gate(), _format_text(), _format_github(), main(), _print_summary(), GitHub Actions annotation format. (+5 more)

### Community 168 - "Tm Guard"
Cohesion: 0.29
Nodes (13): GitError, RuntimeError, _git(), _repo_root(), _parse_args(), Namespace, _diff_text(), _report() (+5 more)

### Community 200 - "Triage"
Cohesion: 0.24
Nodes (10): _filtered_sorted(), queue(), export_rows(), to_csv(), _tally(), Flat, sortable, cross-report triage worklist. The PRD's AppSec persona wants…, Every matching row (suppression-aware, owner-annotated, sorted), not yet…, The flat worklist: filtered, suppression-aware, sorted, paginated.… (+2 more)

### Community 102 - "Users DB"
Cohesion: 0.23
Nodes (21): _connect(), Connection, init(), _normalize_email(), create_user(), verify_user(), get_user(), list_users() (+13 more)

### Community 155 - "Verdict Reconciliation"
Cohesion: 0.21
Nodes (14): _live_verdict_rows(), reconcile(), _all_reconciled(), _sort_worst_first(), conflicts(), summary(), effective_verdict(), verdict_reconciliation.py — cross-REPORT verdict reconciliation: when the same… (+6 more)

### Community 186 - "Rules Architecture"
Cohesion: 0.17
Nodes (12): _rules_architecture.py (ARCHITECTURE_RULES), _rules_devsecops.py (DEVSECOPS_RULES), compliance_mappings.py — OWASP to PCI/HIPAA/GDPR/SOC2/NIST cross-reference, diagram_generator.py (offline architecture diagrams), tm/epss_kev.py, mitre_attack.py (ATT&CK technique enrichment), tm/offline_rules.py, pqc_assessment.py (post-quantum crypto assessment) (+4 more)

### Community 244 - "AIBOM: Config (aibom.config (public persistence surface)"
Cohesion: 0.40
Nodes (5): aibom.config (public persistence surface), aibom.db (SQLite system of record), AibomService (job queue + worker orchestration), NAV_ITEMS / USE_CASES, tm/test_aibom_db.py

### Community 6 - "Verdict Tracking (Verdict reconciliation API blueprint)"
Cohesion: 0.05
Nodes (61): admin API blueprint (users + flush), Verdict reconciliation API blueprint, app.py Flask backend entrypoint, auth.py session/role helpers, tm/broker/delta.py, tm/broker/github.py, tm/broker/pipeline.py, broker/scanner.py — repo access + scan-engine invocation (+53 more)

### Community 92 - "Templates: AIBOM"
Cohesion: 0.09
Nodes (23): Sign-in Page blueprint, Rationale: restrict `next` redirect to same-site paths to prevent open redirect, Portal Navigation Config, tm/tests/test_nav_api.py, _portal_nav.html (shared top navigation), GET /api/v1/nav, ygToggleTheme() (light/dark/techno cycle), /logout route (+15 more)

### Community 255 - "API: Ownership (Suppressions API blueprint)"
Cohesion: 0.67
Nodes (3): api/ownership.py — owner-assignment CRUD (external to this chunk), Suppressions API blueprint, Triage worklist API blueprint

### Community 256 - "Benchmark: Harness (tm/benchmark/harness.py)"
Cohesion: 0.67
Nodes (3): tm/benchmark/harness.py, Risk Signal Phrase List Module, tm/test_benchmark.py

### Community 223 - "Broker: Config (sast)"
Cohesion: 0.36
Nodes (8): broker/config.py — broker configuration + registry persistence facade, sha_cache_get/sha_cache_put (repo+sha -> report_id, delegate to broker.db), broker/db.py — SQLite system of record for broker state, _sast(), _dast(), tm/dast/config.py, tm/fleet.py, tm/test_broker_db.py

### Community 253 - "Broker: Remediation #1"
Cohesion: 0.50
Nodes (4): broker/remediation.py — human-gated fix-PR proposals, PROVEN_VERDICTS (actively_exploited, confirmed_exploitable gate), weighted_compliance_summary / _verdict_adjusted_impact, control_register.py — internal control register (external to this chunk)

### Community 203 - "Broker: Reviewer (review_finding)"
Cohesion: 0.20
Nodes (9): review_finding(), _taint_map() local taint pass, _enclosing_scope() function extraction, _FIX_TABLE mechanical fix rules, _SOURCE_RES taint-source regex table, Rationale: _MAX_SIG_LINE_LEN caps ReDoS on signature regex, analyze_source() JS/TS/Go/Java extraction, Masked class (comment/string masker) (+1 more)

### Community 232 - "Codemodel: Chain Reasoning (call_claude)"
Cohesion: 0.29
Nodes (6): call_claude_cached(), _with_backoff() retry wrapper, reason() LLM attack-chain reasoning, Chain / ChainStep dataclasses, _parse_chains() grounding verification, Rationale: no offline fallback for generative chain reasoning

### Community 86 - "Chain Reasoning Tests (tm/correlator/taxonomy.py)"
Cohesion: 0.10
Nodes (24): codemodel/extractor.py — directory-level model orchestration, codemodel/threats.py — derive threat-model findings from SystemModel, tm/correlator/taxonomy.py, tm/dast/service.py, Chain Reasoning Test Suite, codemodel.chain_reasoning (LLM attack-chain reasoning + grounding verification), Codemodel Benchmark Regression Test Suite, benchmark.codemodel_harness (measured-accuracy CI gate) (+16 more)

### Community 245 - "Lineage Engine Tests (tm/correlator/engine.py)"
Cohesion: 0.40
Nodes (5): tm/correlator/engine.py, Lineage Engine Test Suite, lineage.engine (observation-to-lineage status matching: predicted/realized/confirmed/blind_spot), Lineage Service + API Test Suite, lineage.service (sync orchestration + /api/v1/lineage endpoints)

### Community 238 - "Owasp Mobile (OWASP_CLOUD_TOP10 knowledge base)"
Cohesion: 0.33
Nodes (6): OWASP_CLOUD_TOP10 knowledge base, OWASP_MOBILE_2024 checklist, OWASP_KUBERNETES_TOP10 checklist, sbom_to_categories(), issueFamilies classification taxonomy (JS), STRIDE knowledge base

### Community 236 - "Examples: Basic Usage"
Cohesion: 0.33
Nodes (6): basic_usage.py example script, system-design_github_data.json (raw scraped repo data), SystemDesignKnowledgeBase class, SystemDesignSkill class (older parallel implementation), SystemDesignFullScriptTests suite, SystemDesignSkillTests suite

### Community 247 - "Arch Drift Tests #1"
Cohesion: 0.60
Nodes (5): Architecture drift detection test suite (arch_drift + codemodel), TestAssetGraphDb suite (SQLite assetgraph store contract), TestExtract suite (assetgraph.engine.extract contract), assetgraph.service sync/list_assets + API test suite, Attack-path synthesis test suite (attack_paths + codemodel)

### Community 171 - "Requirements"
Cohesion: 0.15
Nodes (12): tm_app (Yaksha Guard Flask application), anthropic (Python SDK, >=0.97.0), flask (>=3.1.0), flask-limiter (>=4.1.0), flask-compress (>=1.15), python-dotenv (>=1.0.0), itsdangerous (>=2.2.0), werkzeug (>=3.1.0) (+4 more)

### Community 204 - "Rule.yaml"
Cohesion: 0.22
Nodes (10): Master Threat Modeling & Architecture Review Framework (rule.yaml doc 1), Threat actor / adversary model (Nation State, Organized Crime, Hacktivist, Insider, Opportunistic), Defense-in-depth layered controls (physical/IoT, network, application, data), Comprehensive attack vector ontology (app/API, cloud/infra, data, identity/OT, emerging), STRIDE mapping & mitigation catalog, Threat-model execution checklist (pre/during/post review), OWASP Triple-Top 10 Security Review Ruleset (doc 2), OWASP API Security Top 10 (2023) (+2 more)

### Community 99 - "System Design: Readme"
Cohesion: 0.11
Nodes (22): System Design knowledge base (vendored karanpratapsingh/system-design), Caching (cache hit/miss, invalidation, eviction, distributed/global cache), Load Balancing (layers, types, routing algorithms), Content Delivery Network (push/pull CDNs), Databases & DBMS (SQL vs NoSQL), CAP Theorem / PACELC, Sharding & Consistent Hashing, Message Brokers / Queues / Pub-Sub / ESB (+14 more)

### Community 261 - "Templates: Portal Head"
Cohesion: 0.67
Nodes (3): _portal_head.html (Yaksha Guard design system: light/dark/techno themes), _theme_boot.html (pre-paint theme resolver + ygToggleTheme), integrations.html (GitHub integrations page)

### Community 251 - "Templates: Admin"
Cohesion: 0.50
Nodes (4): admin.html (Admin page: users + danger zone), POST/DELETE /api/v1/admin/users, POST /api/v1/admin/users/<email>/role, POST /api/v1/admin/flush

## Ambiguous Edges - Review These
- `status()` → `GET /api/export/<id> (report export)`  [AMBIGUOUS]
  templates/index.html · relation: conceptually_related_to
- `BrokerService._run (worker job body: scan, review, PR-TM, codemodel)` → `correlator/engine.py::_exploitability/_confidence/_business_impact (external to this chunk)`  [AMBIGUOUS]
  broker/service.py · relation: conceptually_related_to
- `Lookups Blueprint` → `EPSS Score Cache`  [AMBIGUOUS]
  data/epss_kev_cache.json · relation: shares_data_with
- `Correlate Blueprint` → `EPSS Score Cache`  [AMBIGUOUS]
  data/epss_kev_cache.json · relation: shares_data_with
- `Correlate Blueprint` → `KEV Catalog Cache`  [AMBIGUOUS]
  data/epss_kev_cache.json · relation: shares_data_with

## Knowledge Gaps
- **280 isolated node(s):** `run.sh script`, `TM_PORT`, `system-design-skill`, `_rules_architecture.py (ARCHITECTURE_RULES)`, `_rules_devsecops.py (DEVSECOPS_RULES)` (+275 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **107 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `status()` and `GET /api/export/<id> (report export)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `BrokerService._run (worker job body: scan, review, PR-TM, codemodel)` and `correlator/engine.py::_exploitability/_confidence/_business_impact (external to this chunk)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `Lookups Blueprint` and `EPSS Score Cache`?**
  _Edge tagged AMBIGUOUS (relation: shares_data_with) - confidence is low._
- **What is the exact relationship between `Correlate Blueprint` and `EPSS Score Cache`?**
  _Edge tagged AMBIGUOUS (relation: shares_data_with) - confidence is low._
- **What is the exact relationship between `Correlate Blueprint` and `KEV Catalog Cache`?**
  _Edge tagged AMBIGUOUS (relation: shares_data_with) - confidence is low._
- **Why does `register_api_blueprints()` connect `API: Dashboard` to `App (top-level) - app.py`, `API: Confidence`?**
  _High betweenness centrality (0.036) - this node is a cross-community bridge._
- **Why does `ScanError` connect `Broker Tests (ScanError)` to `Broker Tests (TestBrokerApi)`, `API: SAST`, `Arch Drift Tests (TestDeclaredParsing)`, `Codemodel Tests (codemodel/__init__.py)`, `Broker Tests (TestGitHubModule)`, `Broker Tests (due_repos)`, `API: Codemodel`, `Arch Drift Tests (cm_report)`, `Broker Tests (TestCodeModelAutoTrigger)`, `Broker: Scanner`, `Broker Tests (TestMapper)`, `Broker: Service`, `Broker Tests (make_vuln_repo)`, `Broker Tests (TestCodeContext)`?**
  _High betweenness centrality (0.028) - this node is a cross-community bridge._