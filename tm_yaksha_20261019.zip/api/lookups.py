"""Lookup and compliance metadata API routes."""
from __future__ import annotations

from flask import Blueprint

import app as tm_app


bp = Blueprint("lookups_api", __name__, url_prefix="/api/v1")


@bp.get("/compliance/frameworks")
def list_compliance_frameworks():
    """List compliance frameworks known to the local mapper."""
    return tm_app._list_compliance_frameworks_impl()


@bp.get("/lookups/attack/<category>")
def lookup_attack(category: str):
    """Look up MITRE ATT&CK techniques for a category."""
    return tm_app._lookup_attack_impl(category)


@bp.get("/lookups/compliance/<category>")
def lookup_compliance(category: str):
    """Look up compliance controls for a category."""
    return tm_app._lookup_compliance_impl(category)
