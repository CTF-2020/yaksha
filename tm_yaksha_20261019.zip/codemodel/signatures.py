"""Signature tables the extractors match against.

Kept as data (not code) so adding coverage for a framework, sink or store is a
one-line edit and so the same tables can be reused by the AST walker and the
regex/config extractors. Everything is lower-cased at match time.
"""
from __future__ import annotations

# ── HTTP verbs a route decorator/method can carry ─────────────────────────────
HTTP_VERBS = {"get", "post", "put", "patch", "delete", "head", "options", "trace"}

# Attribute names that register a route when called as `@x.<attr>(...)`.
ROUTE_ATTRS = HTTP_VERBS | {"route", "add_url_rule", "websocket", "api_route"}

# ── Auth controls: decorator / mixin / dependency names that gate access ──────
AUTH_DECORATORS = {
    "login_required", "jwt_required", "requires_auth", "require_auth", "auth_required",
    "authenticated", "permission_required", "roles_required", "role_required",
    "admin_required", "token_required", "requires_scopes", "requires_permission",
    "has_permission", "protected", "require_login", "require_permission",
    "requires_authentication", "verify_jwt_in_request", "requires_role",
}
AUTH_MIXINS = {
    "loginrequiredmixin", "permissionrequiredmixin", "userpassestestmixin",
    "accessmixin",
}
# Callables that resolve the current principal (FastAPI Depends / DRF).
AUTH_DEPENDENCIES = {
    "get_current_user", "get_current_active_user", "require_user", "authenticate",
    "verify_token", "current_user", "get_user", "oauth2_scheme",
}
# DRF / framework class attributes that carry auth policy.
AUTH_CLASS_ATTRS = {"permission_classes", "authentication_classes"}

# ── Validation controls ───────────────────────────────────────────────────────
VALIDATION_CALLS = {
    "is_valid", "validate", "full_clean", "clean", "load", "parse_obj",
    "model_validate", "check", "validate_python",
}
VALIDATION_BASES = {"basemodel", "schema", "form", "modelform", "serializer",
                    "modelserializer"}

# ── Global security middleware / wrappers ─────────────────────────────────────
# name -> control kind
GLOBAL_CONTROLS = {
    "csrfprotect": "csrf", "csrf": "csrf", "csrfmiddleware": "csrf",
    "talisman": "headers", "securitymiddleware": "headers", "securityheaders": "headers",
    "limiter": "rate-limit", "ratelimiter": "rate-limit", "throttle": "rate-limit",
    "cors": "headers", "corsmiddleware": "headers",
    "httpsredirect": "tls", "httpsredirectmiddleware": "tls", "sslify": "tls",
}

# ── Sensitive sinks: call signature -> (kind, family, cwe) ────────────────────
# Matched on the attribute/function name (last component of the call).
SINKS = {
    # injection-class
    "execute": ("sql", "sql-injection", "CWE-89"),
    "executemany": ("sql", "sql-injection", "CWE-89"),
    "executescript": ("sql", "sql-injection", "CWE-89"),
    "raw": ("sql", "sql-injection", "CWE-89"),
    "extra": ("sql", "sql-injection", "CWE-89"),
    "system": ("command", "command-injection", "CWE-78"),
    "popen": ("command", "command-injection", "CWE-78"),
    "call": ("command", "command-injection", "CWE-78"),
    "run": ("command", "command-injection", "CWE-78"),
    "check_output": ("command", "command-injection", "CWE-78"),
    "eval": ("code-eval", "code-injection", "CWE-94"),
    "exec": ("code-eval", "code-injection", "CWE-94"),
    "compile": ("code-eval", "code-injection", "CWE-94"),
    "loads": ("deserialize", "deserialization", "CWE-502"),
    "load": ("deserialize", "deserialization", "CWE-502"),
    "render_template_string": ("template", "template-injection", "CWE-1336"),
    "from_string": ("template", "template-injection", "CWE-1336"),
    # request-forgery / redirect (only elevated when the argument is tainted)
    "urlopen": ("ssrf", "ssrf", "CWE-918"),
    "redirect": ("redirect", "open-redirect", "CWE-601"),
    # path
    "open": ("path", "path-traversal", "CWE-22"),
    "send_file": ("path", "path-traversal", "CWE-22"),
    "send_from_directory": ("path", "path-traversal", "CWE-22"),
}

# Sinks that are only interesting when an argument is attacker-controlled.
TAINT_GATED_SINKS = {"path", "ssrf", "redirect"}

# "call" and "run" are too generic to trust as command-execution sinks on their
# own — agent.run(), chain.run(), thread.run(), Flask's app.run(), a mock's
# call()… all share the name with subprocess.run/Popen.call. Gate them to a
# real process-spawning root so agentic code (LangChain .run(), CrewAI
# .kickoff(), AutoGen .initiate_chat()) doesn't get misreported as OS command
# injection. "system"/"popen"/"check_output" stay ungated — those names are
# specific enough in practice.
COMMAND_GATED_ATTRS = {"call", "run"}
COMMAND_SINK_ROOTS = {"subprocess", "os", "sh", "commands", "popen2"}

# HTTP client callables whose *tainted* first arg is SSRF; otherwise an external call.
HTTP_CLIENT_ATTRS = {"get", "post", "put", "patch", "delete", "request",
                     "head", "options", "urlopen", "send"}
HTTP_CLIENT_ROOTS = {"requests", "httpx", "urllib", "urllib3", "aiohttp", "session"}

# ── Data stores / external services: root module or call -> (kind, engine) ────
DATA_STORES = {
    "psycopg2": ("sql", "postgres"), "psycopg": ("sql", "postgres"),
    "asyncpg": ("sql", "postgres"), "pymysql": ("sql", "mysql"),
    "mysqldb": ("sql", "mysql"), "mysql": ("sql", "mysql"),
    "sqlite3": ("sql", "sqlite"), "cx_oracle": ("sql", "oracle"),
    "pyodbc": ("sql", "sqlserver"), "sqlalchemy": ("sql", "sql"),
    "pymongo": ("nosql", "mongo"), "motor": ("nosql", "mongo"),
    "redis": ("cache", "redis"), "memcache": ("cache", "memcached"),
    "boto3": ("object-storage", "aws"), "botocore": ("object-storage", "aws"),
    "google.cloud": ("object-storage", "gcp"), "azure": ("object-storage", "azure"),
    "elasticsearch": ("nosql", "elasticsearch"), "cassandra": ("nosql", "cassandra"),
}
QUEUE_ROOTS = {"kafka": "kafka", "pika": "rabbitmq", "celery": "celery",
               "kombu": "amqp", "confluent_kafka": "kafka", "nats": "nats"}

# ── Secret-bearing identifier hints ───────────────────────────────────────────
SECRET_NAME_HINTS = ("password", "passwd", "secret", "token", "api_key", "apikey",
                     "access_key", "private_key", "client_secret", "credential",
                     "auth_token", "session_key")

# ── Agentic AI: orchestration frameworks, LLM SDKs, tool registration ─────────
# Import roots for agent-orchestration frameworks (multi-agent, tool-use loops,
# MCP servers). Presence alone is a trust-boundary signal even without a
# detected tool function.
AGENT_FRAMEWORK_ROOTS = {
    "langchain", "langchain_core", "langchain_community", "langgraph",
    "crewai", "autogen", "pyautogen", "llama_index", "llama_agents",
    "semantic_kernel", "haystack", "dspy", "mcp", "openai_agents",
    "agents", "smolagents", "griptape", "guidance", "langchain4j",
}
# Import roots for a bare LLM provider SDK (no orchestration framework on top).
LLM_PROVIDER_ROOTS = {"openai", "anthropic", "cohere", "mistralai",
                      "google-generativeai", "vercel-ai"}

# Decorators that register a function as an LLM/agent-invokable tool. Matched
# on the decorator's last attribute name alone (same permissive style as
# AUTH_DECORATORS), so `@tool`, `@mcp.tool()`, `@server.tool()`, `@app.tool()`
# and OpenAI's `@function_tool` are all recognised regardless of the
# framework's own import alias or object name.
AGENT_TOOL_DECORATORS = {"tool", "function_tool", "agent_tool", "structuredtool"}

# Dotted call-chain substrings that identify a direct LLM invocation (chat
# completion / generation call). Matched against the full attribute chain
# rather than root+attr — much more precise than name-only matching, since the
# provider's client variable can be named anything (`client`, `llm`, `model`).
LLM_CALL_CHAIN_SIGNATURES = (
    "chat.completions.create", "chat.completions.acreate", "completions.create",
    "messages.create", "messages.acreate", "generate_content",
)
