"""Tests for claude_client.py's token-usage/cost tracking -- cost calculation
and that a successful call logs one row to llm_usage_db under the right
caller tag. The retry/backoff behavior predates this change and isn't
re-tested here.

Isolated onto a temp llm_usage_db store (same pattern as test_ownership.py)
and a mocked anthropic.Anthropic client -- no real network call.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import claude_client
import llm_usage_db


def _fake_message(text="ok", input_tokens=100, output_tokens=50,
                   cache_creation_input_tokens=0, cache_read_input_tokens=0):
    return SimpleNamespace(
        content=[SimpleNamespace(text=text)],
        usage=SimpleNamespace(
            input_tokens=input_tokens, output_tokens=output_tokens,
            cache_creation_input_tokens=cache_creation_input_tokens,
            cache_read_input_tokens=cache_read_input_tokens,
        ),
    )


class CostCalculationTests(unittest.TestCase):
    def test_known_model_computes_cost(self):
        usage = SimpleNamespace(input_tokens=1_000_000, output_tokens=1_000_000,
                                 cache_creation_input_tokens=0, cache_read_input_tokens=0)
        cost = claude_client._cost_usd("claude-sonnet-4-6", usage)
        self.assertAlmostEqual(cost, 3.00 + 15.00)

    def test_cache_tokens_priced_separately(self):
        usage = SimpleNamespace(input_tokens=0, output_tokens=0,
                                 cache_creation_input_tokens=1_000_000,
                                 cache_read_input_tokens=1_000_000)
        cost = claude_client._cost_usd("claude-sonnet-4-6", usage)
        self.assertAlmostEqual(cost, 3.75 + 0.30)

    def test_unpriced_model_returns_zero(self):
        usage = SimpleNamespace(input_tokens=1_000_000, output_tokens=1_000_000,
                                 cache_creation_input_tokens=0, cache_read_input_tokens=0)
        self.assertEqual(claude_client._cost_usd("some-future-model", usage), 0.0)

    def test_none_usage_returns_zero(self):
        self.assertEqual(claude_client._cost_usd("claude-sonnet-4-6", None), 0.0)


class UsageLoggingTests(unittest.TestCase):
    def setUp(self):
        self._orig_path = llm_usage_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        llm_usage_db.DB_PATH = Path(self._td.name) / "usage.db"
        llm_usage_db.init()

    def _restore(self):
        llm_usage_db.DB_PATH = self._orig_path

    @patch("claude_client.anthropic.Anthropic")
    def test_call_claude_logs_usage_with_caller_tag(self, mock_anthropic_cls):
        mock_client = mock_anthropic_cls.return_value
        mock_client.messages.create.return_value = _fake_message()

        result = claude_client.call_claude("key", "system", "user", caller="diagram.dfd")

        self.assertEqual(result, "ok")
        rows = llm_usage_db.recent(limit=1)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["caller"], "diagram.dfd")
        self.assertEqual(rows[0]["model"], claude_client.MODEL)
        self.assertEqual(rows[0]["input_tokens"], 100)
        self.assertEqual(rows[0]["output_tokens"], 50)
        self.assertGreater(rows[0]["cost_usd"], 0.0)

    @patch("claude_client.anthropic.Anthropic")
    def test_call_claude_cached_logs_usage_with_caller_tag(self, mock_anthropic_cls):
        mock_client = mock_anthropic_cls.return_value
        mock_client.messages.create.return_value = _fake_message(
            cache_creation_input_tokens=200, cache_read_input_tokens=0)

        claude_client.call_claude_cached(
            "key", "system", "static", "dynamic", caller="analyzer.owasp")

        rows = llm_usage_db.recent(limit=1)
        self.assertEqual(rows[0]["caller"], "analyzer.owasp")
        self.assertEqual(rows[0]["cache_creation_input_tokens"], 200)

    @patch("claude_client.anthropic.Anthropic")
    def test_no_caller_tag_logs_empty_string(self, mock_anthropic_cls):
        mock_client = mock_anthropic_cls.return_value
        mock_client.messages.create.return_value = _fake_message()

        claude_client.call_claude("key", "system", "user")

        rows = llm_usage_db.recent(limit=1)
        self.assertEqual(rows[0]["caller"], "")

    @patch("claude_client.anthropic.Anthropic")
    def test_usage_logging_failure_does_not_break_the_call(self, mock_anthropic_cls):
        """A broken usage ledger must never take down an already-successful
        LLM call -- _record_usage swallows its own exceptions."""
        mock_client = mock_anthropic_cls.return_value
        mock_client.messages.create.return_value = _fake_message(text="still works")

        with patch("llm_usage_db.record_call", side_effect=RuntimeError("db down")):
            result = claude_client.call_claude("key", "system", "user", caller="diagram.dfd")

        self.assertEqual(result, "still works")


if __name__ == "__main__":
    unittest.main()
