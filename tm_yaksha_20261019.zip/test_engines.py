"""Tests for the external multi-language SAST engine layer.

Run:  python -m pytest test_engines.py

External engines are exercised through *stub* engines — a Python script that
emits canned SARIF — so the suite proves the full adapter path (selection,
invocation, SARIF normalization, severity threshold, path canonicalization,
code-context attachment, failure isolation) without requiring Opengrep, Gosec,
njsscan or Bandit to be installed on the host.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import sarif_import
from broker import config, engines, mapper


def _sarif(results, rules=None, tool="StubTool"):
    return {
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {"name": tool, "rules": rules or []}},
            "results": results,
        }],
    }


def _result(rule_id, uri, line, level="error", snippet="", message="hit",
            props=None):
    r = {
        "ruleId": rule_id,
        "level": level,
        "message": {"text": message},
        "locations": [{"physicalLocation": {
            "artifactLocation": {"uri": uri},
            "region": {"startLine": line,
                       **({"snippet": {"text": snippet}} if snippet else {})},
        }}],
    }
    if props:
        r["properties"] = props
    return r


class TestToFindings(unittest.TestCase):
    def test_maps_core_fields(self):
        doc = _sarif(
            [_result("js.eval", "src/app.js", 3, level="error",
                     snippet="eval(userInput)")],
            rules=[{"id": "js.eval",
                    "shortDescription": {"text": "Eval of user input"},
                    "properties": {"tags": ["external/cwe/cwe-95"]},
                    "help": {"text": "Do not eval untrusted data."}}])
        (f,) = sarif_import.to_findings(doc, engine="Opengrep")
        self.assertEqual(f["id"], "js.eval")
        self.assertEqual(f["title"], "Eval of user input")
        self.assertEqual(f["severity"], "High")          # level=error
        self.assertEqual(f["file"], "src/app.js")
        self.assertEqual(f["line"], 3)
        self.assertEqual(f["snippet"], "eval(userInput)")
        self.assertEqual(f["cwe"], "CWE-95")
        self.assertEqual(f["remediation"], "Do not eval untrusted data.")
        self.assertEqual(f["engine"], "Opengrep")
        self.assertEqual(f["domain"], "Opengrep")

    def test_security_severity_beats_level(self):
        doc = _sarif([_result("r1", "a.go", 1, level="note",
                              props={"security-severity": "9.5"})])
        (f,) = sarif_import.to_findings(doc)
        self.assertEqual(f["severity"], "Critical")

    def test_message_falls_back_as_snippet(self):
        doc = _sarif([_result("r1", "a.go", 1, message="G101 hardcoded credential")])
        (f,) = sarif_import.to_findings(doc)
        self.assertEqual(f["snippet"], "G101 hardcoded credential")

    def test_engine_defaults_to_tool_name(self):
        doc = _sarif([_result("r1", "a.go", 1)], tool="gosec")
        (f,) = sarif_import.to_findings(doc)
        self.assertEqual(f["engine"], "gosec")

    def test_rejects_non_sarif(self):
        with self.assertRaises(sarif_import.SarifError):
            sarif_import.to_findings({"not": "sarif"})
        with self.assertRaises(sarif_import.SarifError):
            sarif_import.to_findings([])


class TestDetectLanguages(unittest.TestCase):
    def test_detects_and_skips_dependency_dirs(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "src").mkdir()
            (root / "src" / "app.js").write_text("x", encoding="utf-8")
            (root / "main.go").write_text("package main", encoding="utf-8")
            (root / "tool.py").write_text("pass", encoding="utf-8")
            (root / "node_modules" / "lib").mkdir(parents=True)
            (root / "node_modules" / "lib" / "index.ts").write_text("x", encoding="utf-8")
            langs = engines.detect_languages(root)
        self.assertEqual(langs, {"js", "go", "py"})   # no "ts": vendored only

    def test_all_four_target_languages(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            for name, body in (("a.js", "x"), ("b.ts", "y"),
                               ("svc/main.go", "package main"),
                               ("Api.java", "class Api {}")):
                p = root / name
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(body, encoding="utf-8")
            self.assertEqual(engines.detect_languages(root),
                             {"js", "ts", "go", "java"})

    def test_empty_repo_no_languages(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "README.md").write_text("hi", encoding="utf-8")
            self.assertEqual(engines.detect_languages(Path(d)), set())


class TestSelection(unittest.TestCase):
    def test_off_auto_and_csv(self):
        with mock.patch.object(config, "EXTERNAL_ENGINES", "off"):
            self.assertEqual(engines._selected_ids(), set())
        with mock.patch.object(config, "EXTERNAL_ENGINES", "auto"):
            # "auto" runs the default_auto engines only — njsscan is opt-in
            # (it duplicates Opengrep's js/ts coverage).
            auto = {eid for eid, s in engines.ENGINES.items()
                    if s.get("default_auto", True)}
            self.assertEqual(engines._selected_ids(), auto)
            self.assertNotIn("njsscan", engines._selected_ids())
        with mock.patch.object(config, "EXTERNAL_ENGINES", "gosec,bogus"):
            self.assertEqual(engines._selected_ids(), {"gosec"})

    def test_optin_engine_selectable_by_name(self):
        with mock.patch.object(config, "EXTERNAL_ENGINES", "njsscan"):
            self.assertEqual(engines._selected_ids(), {"njsscan"})


class TestNormalizeFinding(unittest.TestCase):
    def test_absolute_and_file_uri_become_repo_relative(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            absolute = str((root / "pkg" / "db.go").resolve())
            for raw in (absolute, "file:///" + absolute.replace("\\", "/")):
                f = {"file": raw}
                engines._normalize_finding(root, f)
                self.assertEqual(f["file"], "pkg/db.go", raw)

    def test_relative_path_gets_forward_slashes(self):
        f = {"file": "src\\app.js"}
        engines._normalize_finding(Path("."), f)
        self.assertEqual(f["file"], "src/app.js")


def _stub_engine(script: Path, languages={"js"}):
    """An ENGINES spec that runs `script` with the current Python."""
    return {
        "name": "StubEngine",
        "binaries": (sys.executable,),
        "languages": set(languages),
        "license": "MIT",
        "args": lambda binpath, root, langs: [binpath, str(script), str(root)],
        "cwd": False,
    }


def _write_stub(dirpath: Path, sarif_doc: dict, exit_code=1) -> Path:
    script = dirpath / "stub_engine.py"
    script.write_text(
        "import sys\n"
        f"sys.stdout.write({json.dumps(json.dumps(sarif_doc))})\n"
        f"sys.exit({exit_code})\n", encoding="utf-8")
    return script


def _js_repo(root: Path) -> None:
    (root / "src").mkdir(parents=True, exist_ok=True)
    (root / "src" / "app.js").write_text(
        "const cp = require('child_process');\n"
        "function run(input) {\n"
        "  cp.exec('ls ' + input);\n"
        "}\n", encoding="utf-8")


class TestRunEngines(unittest.TestCase):
    def _run(self, sarif_doc=None, severity="Low", spec=None, exit_code=1,
             repo_setup=_js_repo):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "repo"
            root.mkdir()
            repo_setup(root)
            script = _write_stub(Path(d), sarif_doc or {}, exit_code=exit_code)
            stub = spec or _stub_engine(script)
            stub["args"] = lambda binpath, r, langs, s=script: [binpath, str(s), str(r)]
            with mock.patch.dict(engines.ENGINES, {"stub": stub}, clear=True), \
                 mock.patch.object(config, "EXTERNAL_ENGINES", "stub"):
                return engines.run_engines(root, severity)

    def test_end_to_end_stub_scan(self):
        doc = _sarif([_result("js.exec", "src/app.js", 3, level="error",
                              snippet="cp.exec('ls ' + input);")])
        findings, meta = self._run(doc)
        self.assertEqual(len(findings), 1)
        f = findings[0]
        self.assertEqual(f["engine"], "StubEngine")
        self.assertEqual(f["file"], "src/app.js")
        # Code context was attached from the real file on disk.
        self.assertIn("cp.exec", f.get("code_context", ""))
        (m,) = meta
        self.assertEqual(m["status"], "ok")
        self.assertEqual(m["findings"], 1)

    def test_severity_threshold_filters(self):
        doc = _sarif([
            _result("hi", "src/app.js", 1, level="error"),      # High
            _result("med", "src/app.js", 2, level="warning"),   # Medium
            _result("low", "src/app.js", 3, level="note"),      # Low
        ])
        findings, _ = self._run(doc, severity="Medium")
        self.assertEqual({f["id"] for f in findings}, {"hi", "med"})

    def test_engine_failure_is_isolated(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "repo"
            root.mkdir()
            _js_repo(root)
            script = Path(d) / "boom.py"
            script.write_text("import sys\nsys.stderr.write('kaboom')\n"
                              "sys.stdout.write('not json')\nsys.exit(3)\n",
                              encoding="utf-8")
            stub = _stub_engine(script)
            with mock.patch.dict(engines.ENGINES, {"stub": stub}, clear=True), \
                 mock.patch.object(config, "EXTERNAL_ENGINES", "stub"):
                findings, meta = engines.run_engines(root, "Low")
        self.assertEqual(findings, [])
        (m,) = meta
        self.assertEqual(m["status"], "error")
        self.assertIn("kaboom", m["error"])

    def test_unavailable_binary_reported_not_fatal(self):
        stub = {"name": "Ghost", "binaries": ("definitely-not-a-real-binary-xyz",),
                "languages": {"js"}, "license": "MIT",
                "args": lambda b, r: [b], "cwd": False}
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            _js_repo(root)
            with mock.patch.dict(engines.ENGINES, {"ghost": stub}, clear=True), \
                 mock.patch.object(config, "EXTERNAL_ENGINES", "ghost"):
                findings, meta = engines.run_engines(root, "Low")
        self.assertEqual(findings, [])
        self.assertEqual(meta[0]["status"], "unavailable")

    def test_language_mismatch_skips_engine(self):
        doc = _sarif([_result("r", "x.go", 1)])
        def py_only(root):
            (root / "only.py").write_text("pass", encoding="utf-8")
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "repo"
            root.mkdir()
            py_only(root)
            script = _write_stub(Path(d), doc)
            stub = _stub_engine(script, languages={"go"})
            with mock.patch.dict(engines.ENGINES, {"stub": stub}, clear=True), \
                 mock.patch.object(config, "EXTERNAL_ENGINES", "stub"):
                findings, meta = engines.run_engines(root, "Low")
        self.assertEqual(findings, [])
        self.assertTrue(meta[0]["status"].startswith("skipped"))

    def test_off_runs_nothing(self):
        with mock.patch.object(config, "EXTERNAL_ENGINES", "off"):
            findings, meta = engines.run_engines(Path("."), "Low")
        self.assertEqual((findings, meta), ([], []))


class TestAvailabilityRoster(unittest.TestCase):
    def test_roster_shape(self):
        with mock.patch.object(config, "EXTERNAL_ENGINES", "auto"):
            roster = engines.available_engines()
        self.assertEqual({e["id"] for e in roster},
                         {"opengrep", "gosec", "njsscan", "bandit"})
        by_id = {e["id"]: e for e in roster}
        for e in roster:
            self.assertIn("available", e)
            self.assertIn("license", e)
            self.assertIsInstance(e["languages"], list)
        # default_auto engines are enabled under "auto"; njsscan is opt-in.
        self.assertTrue(by_id["opengrep"]["enabled"])
        self.assertTrue(by_id["gosec"]["enabled"])
        self.assertTrue(by_id["bandit"]["enabled"])
        self.assertFalse(by_id["njsscan"]["enabled"])
        # Opengrep row surfaces its ruleset source / offline posture.
        self.assertIn("rules", by_id["opengrep"])
        self.assertIn("rules_offline", by_id["opengrep"])

    def test_roster_reflects_path(self):
        def fake_find(spec):
            return "/usr/bin/gosec" if spec["binaries"][0] == "gosec" else None
        with mock.patch.object(engines, "_find_binary", side_effect=fake_find), \
             mock.patch.object(config, "EXTERNAL_ENGINES", "auto"):
            roster = {e["id"]: e for e in engines.available_engines()}
        self.assertTrue(roster["gosec"]["available"])
        self.assertEqual(roster["gosec"]["binary"], "/usr/bin/gosec")
        self.assertFalse(roster["opengrep"]["available"])


class TestFindingsCap(unittest.TestCase):
    def test_findings_cap_enforced(self):
        big = _sarif([_result(f"R{i}", "src/app.js", i + 1, level="error")
                      for i in range(10)])
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "repo"
            root.mkdir()
            _js_repo(root)
            script = _write_stub(Path(d), big)
            stub = _stub_engine(script)
            with mock.patch.dict(engines.ENGINES, {"stub": stub}, clear=True), \
                 mock.patch.object(config, "EXTERNAL_ENGINES", "stub"), \
                 mock.patch.object(config, "MAX_FINDINGS", 3):
                findings, meta = engines.run_engines(root, "Low")
        self.assertEqual(len(findings), 3)


class TestMapperProvenance(unittest.TestCase):
    def test_engine_finding_carries_provenance_in_report(self):
        finding = {
            "id": "G101", "title": "Hardcoded credential", "severity": "High",
            "file": "pkg/db.go", "line": 7, "snippet": 'pass := "hunter2"',
            "cwe": "CWE-798", "owasp": "", "remediation": "Move to a secret store.",
            "engine": "Gosec", "domain": "Gosec",
        }
        report = mapper.findings_to_report(
            [finding], {"id": "r", "name": "repo"}, {}, "Low")
        (cat,) = report["categories"]
        self.assertIn("engine: Gosec", cat["notes"])
        self.assertEqual(cat["category"], "Gosec")
        self.assertIn("engine: Gosec", cat["threats"][0]["control_objective"])


class TestCrossEngineDedup(unittest.TestCase):
    def _f(self, engine, file="app.js", line=3, cwe="CWE-95", sev="High",
           snippet="eval(x)", rid="r", rem=""):
        return {"id": rid, "engine": engine, "file": file, "line": line,
                "cwe": cwe, "severity": sev, "snippet": snippet, "remediation": rem}

    def test_same_weakness_two_engines_collapses(self):
        a = self._f("Opengrep", rid="og.eval", sev="Medium")
        b = self._f("njsscan", rid="njs.eval", sev="High")   # graded higher
        unique, removed = engines._dedup_across_engines([a, b])
        self.assertEqual(removed, 1)
        self.assertEqual(len(unique), 1)
        surv = unique[0]
        self.assertEqual(surv["engine"], "Opengrep")          # first-seen owns it
        self.assertEqual(surv["severity"], "High")            # but severity lifts
        self.assertIn("njsscan", surv["corroborated_by"])

    def test_different_cwe_same_line_kept_separate(self):
        a = self._f("Opengrep", cwe="CWE-95", rid="eval")
        b = self._f("Opengrep", cwe="CWE-89", rid="sqli")     # same line, other bug
        unique, removed = engines._dedup_across_engines([a, b])
        self.assertEqual(removed, 0)
        self.assertEqual(len(unique), 2)

    def test_cweless_findings_keyed_on_snippet(self):
        a = self._f("A", cwe="", snippet="dangerous(x)")
        b = self._f("B", cwe="", snippet="dangerous(x)")      # identical locus+code
        c = self._f("C", cwe="", snippet="other(y)")
        unique, removed = engines._dedup_across_engines([a, b, c])
        self.assertEqual(removed, 1)
        self.assertEqual(len(unique), 2)

    def test_survivor_inherits_missing_snippet_and_remediation(self):
        a = self._f("A", snippet="", rem="")
        b = self._f("B", snippet="eval(x)", rem="Do not eval.")
        (surv,), _ = engines._dedup_across_engines([a, b])
        self.assertEqual(surv["snippet"], "eval(x)")
        self.assertEqual(surv["remediation"], "Do not eval.")

    def test_end_to_end_two_engines_dedup_and_meta(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "repo"
            root.mkdir()
            _js_repo(root)
            # two engines, same weakness at the same locus, distinct rule ids
            script1 = Path(d) / "s1.py"
            script2 = Path(d) / "s2.py"
            for script, rid in ((script1, "og.exec"), (script2, "njs.exec")):
                doc = _sarif([_result(rid, "src/app.js", 3, level="error",
                                      snippet="cp.exec('ls '+input)")],
                             rules=[{"id": rid,
                                     "properties": {"tags": ["external/cwe/cwe-78"]}}])
                script.write_text(
                    "import sys\n"
                    f"sys.stdout.write({json.dumps(json.dumps(doc))})\n",
                    encoding="utf-8")
            e1 = _stub_engine(script1); e1["name"] = "EngineOne"
            e1["args"] = lambda b, r, langs: [b, str(script1), str(r)]
            e2 = _stub_engine(script2); e2["name"] = "EngineTwo"
            e2["args"] = lambda b, r, langs: [b, str(script2), str(r)]
            with mock.patch.dict(engines.ENGINES,
                                 {"e1": e1, "e2": e2}, clear=True), \
                 mock.patch.object(config, "EXTERNAL_ENGINES", "e1,e2"):
                findings, meta = engines.run_engines(root, "Low")
        self.assertEqual(len(findings), 1)                    # collapsed to one
        self.assertEqual(findings[0]["engine"], "EngineOne")  # registry-order wins
        self.assertIn("EngineTwo", findings[0]["corroborated_by"])
        dedup_meta = [m for m in meta if m["engine"] == "(dedup)"]
        self.assertEqual(len(dedup_meta), 1)
        self.assertEqual(dedup_meta[0]["duplicates_removed"], 1)

    def test_cwe95_and_cwe94_on_same_eval_collapse(self):
        # The exact NodeGoat case: built-in scanner tags eval() CWE-94, Opengrep
        # tags the identical line CWE-95. Same weakness, must not double-report.
        a = self._f("builtin", cwe="CWE-94", snippet="const x = eval(req.body.x);")
        b = self._f("Opengrep", cwe="CWE-95", snippet="        const x = eval(req.body.x);")
        unique, removed = engines._dedup_across_engines([a, b])
        self.assertEqual(removed, 1)
        self.assertEqual(len(unique), 1)

    def test_backslash_and_forward_slash_paths_key_the_same(self):
        # Built-in scanner emits OS-native separators (os.path.relpath on
        # Windows -> backslashes); SARIF-importing engines normalize to
        # forward slashes. Same file, same line, same CWE must still collapse.
        a = self._f("builtin", file=r"app\routes\contributions.js")
        b = self._f("Opengrep", file="app/routes/contributions.js")
        unique, removed = engines._dedup_across_engines([a, b])
        self.assertEqual(removed, 1)
        self.assertEqual(len(unique), 1)


class TestMergeWithBuiltin(unittest.TestCase):
    def _f(self, engine, file="app.js", line=3, cwe="CWE-95", sev="High",
           snippet="eval(x)", rid="r"):
        d = {"id": rid, "file": file, "line": line, "cwe": cwe,
             "severity": sev, "snippet": snippet}
        if engine is not None:
            d["engine"] = engine
        return d

    def test_builtin_and_external_duplicate_collapses(self):
        # The built-in scanner's findings carry no "engine" key at all (unlike
        # external-engine findings) — this is the actual shape service.py and
        # pipeline.py combine, previously via a bare `.extend()` with no dedup.
        builtin = [self._f(None, rid="SAR-APPSEC-XXX")]
        ext = [self._f("Opengrep", rid="javascript.eval-detected")]
        merged, removed = engines.merge_with_builtin(builtin, ext)
        self.assertEqual(removed, 1)
        self.assertEqual(len(merged), 1)
        self.assertEqual(merged[0]["id"], "SAR-APPSEC-XXX")  # built-in wins precedence

    def test_no_overlap_keeps_both(self):
        builtin = [self._f(None, file="a.js", rid="A")]
        ext = [self._f("Opengrep", file="b.js", rid="B")]
        merged, removed = engines.merge_with_builtin(builtin, ext)
        self.assertEqual(removed, 0)
        self.assertEqual(len(merged), 2)

    def test_emits_progress_message_only_when_something_merged(self):
        messages = []
        builtin = [self._f(None, rid="A")]
        ext = [self._f("Opengrep", rid="B")]
        engines.merge_with_builtin(builtin, ext, emit=messages.append)
        self.assertTrue(messages)
        messages.clear()
        engines.merge_with_builtin([self._f(None, file="a.js")],
                                   [self._f("Opengrep", file="b.js")], emit=messages.append)
        self.assertFalse(messages)


class TestVersionProvenance(unittest.TestCase):
    def test_driver_version_captured_in_meta(self):
        doc = _sarif([_result("r", "src/app.js", 3, level="error")])
        doc["runs"][0]["tool"]["driver"]["version"] = "1.25.0"
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "repo"
            root.mkdir()
            _js_repo(root)
            script = _write_stub(Path(d), doc)
            stub = _stub_engine(script)
            with mock.patch.dict(engines.ENGINES, {"stub": stub}, clear=True), \
                 mock.patch.object(config, "EXTERNAL_ENGINES", "stub"):
                _, meta = engines.run_engines(root, "Low")
        self.assertEqual(meta[0]["version"], "1.25.0")


class TestCoverageGaps(unittest.TestCase):
    def test_missing_default_engine_flagged_when_no_fallback(self):
        # Go is present, gosec (the only default_auto engine covering it) is
        # unavailable, and no other default engine covers Go at all.
        run_ids = ["gosec"]
        meta = [{"engine": "gosec", "status": "unavailable"}]
        gaps = engines._coverage_gaps({"go"}, run_ids, meta)
        self.assertEqual(len(gaps), 1)
        self.assertEqual(gaps[0]["language"], "go")
        self.assertEqual(gaps[0]["missing_engines"], ["Gosec"])
        self.assertEqual(gaps[0]["still_covered_by"], [])

    def test_missing_engine_with_fallback_still_flagged_but_notes_coverage(self):
        run_ids = ["opengrep", "gosec"]
        meta = [{"engine": "opengrep", "status": "ok"},
                {"engine": "gosec", "status": "unavailable"}]
        gaps = engines._coverage_gaps({"go"}, run_ids, meta)
        self.assertEqual(len(gaps), 1)
        self.assertEqual(gaps[0]["missing_engines"], ["Gosec"])
        self.assertEqual(gaps[0]["still_covered_by"], ["Opengrep"])

    def test_no_gap_when_all_default_engines_available(self):
        run_ids = ["opengrep", "gosec"]
        meta = [{"engine": "opengrep", "status": "ok"},
                {"engine": "gosec", "status": "ok"}]
        self.assertEqual(engines._coverage_gaps({"go"}, run_ids, meta), [])

    def test_opt_in_engine_absence_is_not_a_gap(self):
        # njsscan is default_auto=False (opt-in, overlaps Opengrep); its absence
        # from run_ids is normal, not a coverage gap.
        run_ids = ["opengrep"]
        meta = [{"engine": "opengrep", "status": "ok"}]
        self.assertEqual(engines._coverage_gaps({"js"}, run_ids, meta), [])

    def test_end_to_end_gap_surfaces_in_run_engines_meta(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "repo"
            root.mkdir()
            (root / "main.go").write_text("package main\n", encoding="utf-8")
            fake_gosec = dict(engines.ENGINES["gosec"])
            fake_gosec["binaries"] = ("definitely-not-a-real-binary-xyz",)
            with mock.patch.dict(engines.ENGINES, {"gosec": fake_gosec}, clear=True), \
                 mock.patch.object(config, "EXTERNAL_ENGINES", "auto"):
                _, meta = engines.run_engines(root, "Low")
        cov = [m for m in meta if m["engine"] == "(coverage)"]
        self.assertEqual(len(cov), 1)
        self.assertEqual(cov[0]["gaps"][0]["language"], "go")


class TestMapperCoverageWarning(unittest.TestCase):
    def test_coverage_gap_appended_to_summary(self):
        meta = {"engines": [{"engine": "(coverage)", "name": "Coverage gaps",
                             "status": "warn", "gaps": [
                                 {"language": "go", "missing_engines": ["Gosec"],
                                  "still_covered_by": []}]}]}
        report = mapper.findings_to_report([], {"id": "r", "name": "repo"}, meta, "Low")
        self.assertIn("Coverage gap", report["summary"])
        self.assertIn("Gosec", report["summary"])
        self.assertIn("go", report["summary"])

    def test_no_coverage_note_leaves_summary_unchanged(self):
        meta = {"engines": [{"engine": "opengrep", "status": "ok"}]}
        report = mapper.findings_to_report([], {"id": "r", "name": "repo"}, meta, "Low")
        self.assertNotIn("Coverage gap", report["summary"])


class TestOfflineResolver(unittest.TestCase):
    def test_env_override_wins(self):
        with mock.patch.object(config, "OPENGREP_RULES", "/etc/rules"):
            self.assertEqual(config.resolve_opengrep_config(), ["/etc/rules"])
            self.assertTrue(config.opengrep_rules_are_local())

    def test_env_override_wins_even_with_langs(self):
        with mock.patch.object(config, "OPENGREP_RULES", "/etc/rules"):
            self.assertEqual(config.resolve_opengrep_config({"py"}), ["/etc/rules"])

    def test_registry_ref_is_not_local(self):
        with mock.patch.object(config, "OPENGREP_RULES", "p/ci"):
            self.assertFalse(config.opengrep_rules_are_local())

    def test_defaults_to_auto_when_no_local_rules_and_no_langs(self):
        # An empty/absent bundled dir must not silently break online scans.
        with mock.patch.object(config, "OPENGREP_RULES", ""), \
             mock.patch.object(config, "BUNDLED_OPENGREP_RULES",
                               Path(tempfile.mkdtemp())):
            self.assertEqual(config.resolve_opengrep_config(), ["auto"])
            self.assertFalse(config.opengrep_rules_are_local())

    def test_prefers_bundled_dir_with_rules(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "r.yaml").write_text("rules: []", encoding="utf-8")
            with mock.patch.object(config, "OPENGREP_RULES", ""), \
                 mock.patch.object(config, "BUNDLED_OPENGREP_RULES", Path(d)):
                self.assertEqual(config.resolve_opengrep_config(), [d])
                self.assertTrue(config.opengrep_rules_are_local())

    def test_scopes_registry_packs_to_detected_languages(self):
        # A JS-only repo must never pull in Python/Django/etc. rule packs: that's
        # exactly how python.django.security.django-no-csrf-token ended up firing
        # on a Swig template in a Node app with zero Python anywhere in it.
        with mock.patch.object(config, "OPENGREP_RULES", ""), \
             mock.patch.object(config, "BUNDLED_OPENGREP_RULES",
                               Path(tempfile.mkdtemp())):
            cfgs = config.resolve_opengrep_config({"js", "ts"})
            self.assertEqual(set(cfgs), {"p/javascript", "p/typescript"})
            self.assertNotIn("p/python", cfgs)
            # Registry packs (even language-scoped ones) still hit the network —
            # only an explicit override or a bundled on-disk ruleset is "local".
            self.assertFalse(config.opengrep_rules_are_local({"js", "ts"}))

    def test_unrecognized_langs_fall_back_to_auto(self):
        with mock.patch.object(config, "OPENGREP_RULES", ""), \
             mock.patch.object(config, "BUNDLED_OPENGREP_RULES",
                               Path(tempfile.mkdtemp())):
            self.assertEqual(config.resolve_opengrep_config({"ruby-unknown-dialect"}), ["auto"])


if __name__ == "__main__":
    unittest.main()
