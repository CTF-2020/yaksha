"""diagram_generator.py — Generates Mermaid diagrams from architecture text via Claude API."""
from __future__ import annotations
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

from claude_client import call_claude


def _extract_mermaid(text: str) -> str:
    """Extract mermaid code block. Falls back to raw text if no fence found."""
    match = re.search(
        r'```(?:mermaid)?\s*((?:graph|flowchart|C4|sequenceDiagram|stateDiagram|erDiagram).*?)```',
        text, re.DOTALL | re.IGNORECASE,
    )
    if match:
        return match.group(1).strip()
    match2 = re.search(r'```\s*(.*?)```', text, re.DOTALL)
    if match2:
        return match2.group(1).strip()
    return text.strip()


def _node(label: str, shape: str = "box") -> str:
    safe = re.sub(r"[^A-Za-z0-9 ]+", " ", label).strip() or "Component"
    safe = re.sub(r"\s+", " ", safe)[:36]
    if shape == "database":
        return f'[("{safe}")]'
    if shape == "queue":
        return f'[["{safe}"]]'
    return f'["{safe}"]'


def generate_architecture_diagram_offline(architecture_text: str, title: str = "System") -> str:
    """Build a conservative Mermaid architecture diagram without an LLM call."""
    text = architecture_text.lower()
    catalog = [
        ("User", "User", "box", ["user", "customer", "employee", "admin", "client"]),
        ("Client", "Client App", "box", ["frontend", "spa", "react", "next.js", "browser", "mobile", "ios", "android"]),
        ("Gateway", "API Gateway", "box", ["api gateway", "gateway", "load balancer", "alb", "nginx", "cloudfront"]),
        ("API", "Application API", "box", ["api", "rest", "graphql", "fastapi", "express", "backend"]),
        ("Auth", "Auth Service", "box", ["auth", "oauth", "oidc", "jwt", "sso", "identity"]),
        ("Service", "Business Service", "box", ["service", "microservice", "worker", "container", "ecs", "kubernetes"]),
        ("Queue", "Message Queue", "queue", ["queue", "kafka", "rabbitmq", "sqs", "pubsub", "event bus"]),
        ("LLM", "LLM Service", "box", ["llm", "gpt", "claude", "openai", "model", "agent", "rag"]),
        ("VectorDB", "Vector DB", "database", ["vector", "pinecone", "embedding", "chromadb", "weaviate"]),
        ("Cache", "Cache", "database", ["redis", "cache", "memcached"]),
        ("DB", "Database", "database", ["database", "postgres", "postgresql", "mysql", "mongodb", "aurora", "rds"]),
        ("Storage", "Object Storage", "database", ["s3", "blob", "bucket", "object storage", "file upload"]),
        ("ThirdParty", "Third Party API", "box", ["third-party", "third party", "payment", "stripe", "sendgrid", "external"]),
        ("Monitor", "Monitoring", "box", ["logging", "monitoring", "cloudtrail", "siem", "alert"]),
    ]
    found: dict[str, tuple[str, str]] = {
        node_id: (label, shape)
        for node_id, label, shape, patterns in catalog
        if any(pattern in text for pattern in patterns)
    }
    if not found:
        found = {
            "User": ("User", "box"),
            "App": ("Application", "box"),
            "DB": ("Database", "database"),
        }
    if "User" not in found:
        found = {"User": ("User", "box"), **found}

    lines = ["flowchart LR"]
    for node_id, (label, shape) in found.items():
        lines.append(f"  {node_id}{_node(label, shape)}")

    order = [n for n in ("User", "Client", "Gateway", "API", "Service") if n in found]
    if len(order) < 2 and "App" in found:
        order = ["User", "App"]
    for left, right in zip(order, order[1:]):
        lines.append(f"  {left} --> {right}")

    primary = "Service" if "Service" in found else ("API" if "API" in found else order[-1])
    if "Auth" in found and primary != "Auth":
        lines.append(f"  {primary} --> Auth")
    for target in ("LLM", "VectorDB", "Queue", "Cache", "DB", "Storage", "ThirdParty", "Monitor"):
        if target in found and target != primary:
            lines.append(f"  {primary} --> {target}")
    if "LLM" in found and "VectorDB" in found:
        lines.append("  LLM --> VectorDB")

    styled = [n for n in ("User", "Client", "Gateway", "API", "Service", "Auth", "LLM") if n in found]
    if styled:
        lines.append("  classDef boundary fill:#0f1e35,stroke:#00c4a7,color:#e2e8f0")
        lines.append(f"  class {','.join(styled)} boundary")
    return "\n".join(lines)


def generate_architecture_diagram(api_key: str, architecture_text: str, title: str = "System") -> str:
    if not api_key:
        return generate_architecture_diagram_offline(architecture_text, title)

    system = (
        "You are an expert software architect. Generate ONLY valid Mermaid flowchart syntax "
        "for a high-level architecture diagram. Use conservative syntax with simple node IDs, "
        "quoted labels, and --> arrows."
    )
    user = f"""Create a high-level architecture diagram for this system.

TITLE:
{title}

ARCHITECTURE:
{architecture_text[:3000]}

Rules:
1. Start with `flowchart LR`
2. Show user/client, gateways, services, data stores, external systems, and AI components if present
3. Use short labels and simple node IDs with letters/numbers/underscores only
4. Use database cylinder syntax for data stores: `DB[("Database")]`
5. Return ONLY Mermaid code, no prose and no markdown fence."""

    try:
        return _extract_mermaid(call_claude(api_key, system, user, max_tokens=2048,
                                             caller="diagram.mermaid"))
    except Exception:
        return generate_architecture_diagram_offline(architecture_text, title)


def generate_dfd(api_key: str, architecture_text: str) -> str:
    system = (
        "You are an expert software architect specializing in data flow diagrams. "
        "Generate ONLY valid Mermaid diagram syntax inside a fenced code block. "
        "Use conservative Mermaid syntax: simple quoted node labels, --> arrows only, "
        "no special characters in labels except alphanumeric and spaces."
    )
    user = f"""Create a Level 1 Data Flow Diagram for this architecture using Mermaid flowchart syntax.

ARCHITECTURE:
{architecture_text[:3000]}

Rules for the Mermaid DFD:
1. Use `flowchart LR` (left-to-right) as the opening line
2. Show all major components, services, and data stores
3. Label every arrow with the data type/operation (e.g., `-->|"HTTP Request"|`)
4. Use subgraphs for trust boundaries: `subgraph "Trust Boundary Name"` ... `end`
5. Use cylinder shape for databases: `DB[("Database Name")]`
6. Use rectangles for external entities: `Ext["External System"]`
7. Keep node IDs simple: letters/numbers/underscores only (no spaces)
8. Keep all labels SHORT — max 4 words per node label

Return ONLY a fenced ```mermaid code block with the complete diagram."""

    raw = call_claude(api_key, system, user, max_tokens=4096, caller="diagram.dfd")
    return _extract_mermaid(raw)


def generate_c4_context(api_key: str, architecture_text: str, title: str = "System") -> str:
    system = (
        "You are a C4 model expert. Generate ONLY valid Mermaid C4Context syntax "
        "inside a fenced code block. Use exact C4Context element types as shown."
    )
    user = f"""Create a C4 Context (Level 1) diagram for this architecture.

ARCHITECTURE:
{architecture_text[:3000]}

Use EXACTLY this Mermaid C4Context syntax template — no deviations:

```C4Context
  title System Context for {title}
  Person(personAlias, "Role Name", "Brief description of who this person is")
  System(sysAlias, "System Name", "What this system does in one sentence")
  System_Ext(extAlias, "External System", "What role it plays")
  Rel(personAlias, sysAlias, "How they interact")
  Rel(sysAlias, extAlias, "Integration relationship")
```

Rules:
- Include ALL user personas as Person() elements
- Include the main system as System()
- Include ALL external services as System_Ext()
- Use descriptive Rel() labels that explain the interaction
- Limit to 10 elements maximum for clarity

Return ONLY the fenced ```mermaid (or ```C4Context) code block."""

    raw = call_claude(api_key, system, user, max_tokens=4096, caller="diagram.c4_context")
    result = _extract_mermaid(raw)
    if not result.startswith("C4Context") and "C4Context" not in result[:20]:
        result = "C4Context\n" + result
    return result


def generate_attack_tree(api_key: str, architecture_text: str, threat_model: dict) -> str:
    top_threats = []
    for cat in threat_model.get("categories", []):
        if cat.get("risk") in ("Critical", "High"):
            for t in cat.get("threats", [])[:2]:
                top_threats.append(f"{cat.get('id','')}: {t.get('name','Unknown threat')}")

    system_title = threat_model.get("title", "Target System")
    system = (
        "You are a security architect specializing in attack tree modeling. "
        "Generate ONLY valid Mermaid flowchart syntax for an attack tree inside a fenced code block. "
        "Use conservative syntax: simple node IDs, quoted labels, --> arrows only."
    )
    user = f"""Create an attack tree diagram showing how the top threats would be exploited.

ARCHITECTURE (summary):
{architecture_text[:1500]}

TOP IDENTIFIED THREATS:
{chr(10).join(f"- {t}" for t in (top_threats[:8] or ["General system compromise"]))}

Generate a Mermaid graph TD attack tree where:
- Root node: the primary attack goal (compromising {system_title})
- Level 2: major attack categories (Authentication Bypass, Data Exfiltration, etc.)
- Level 3: specific attack techniques
- Apply color styling to critical nodes:
  - Critical: `style NodeId fill:#ef4444,color:#fff,stroke:#dc2626`
  - High risk: `style NodeId fill:#f97316,color:#fff,stroke:#ea580c`
  - Medium: `style NodeId fill:#eab308,color:#000,stroke:#ca8a04`
- Use simple node IDs (R, A, B, A1, A2, etc. — no spaces)

Return ONLY the fenced ```mermaid code block."""

    raw = call_claude(api_key, system, user, max_tokens=4096, caller="diagram.attack_tree")
    return _extract_mermaid(raw)


def generate_stride_diagram(api_key: str, architecture_text: str, stride_results: list) -> str:
    stride_summary = "\n".join(
        f"- {item.get('component','?')} → {item.get('threat_type','?')}: {item.get('threat','?')}"
        for item in (stride_results or [])[:10]
    )
    system = (
        "Generate ONLY valid Mermaid flowchart syntax for a STRIDE threat map. "
        "Use conservative syntax with simple node IDs and quoted labels."
    )
    user = f"""Create a STRIDE threat map diagram for this architecture.

ARCHITECTURE:
{architecture_text[:2000]}

IDENTIFIED STRIDE THREATS:
{stride_summary or "Apply STRIDE analysis based on the architecture components"}

Create a Mermaid flowchart LR showing:
- All architecture components as nodes
- Arrows between components showing data flows
- Threat annotations on relevant nodes using subgraphs or node labels
- Color-code nodes with identified threats:
  - Critical threat: style with fill:#ef4444,color:#fff
  - Multiple threats: style with fill:#f97316,color:#fff
  - Low threats: style with fill:#22c55e,color:#000

Return ONLY the fenced ```mermaid code block."""

    raw = call_claude(api_key, system, user, max_tokens=4096, caller="diagram.stride_diagram")
    return _extract_mermaid(raw)


def generate_api_flow(api_key: str, architecture_text: str, api_findings: list | None = None) -> str:
    findings_text = ""
    if api_findings:
        top = sorted(api_findings, key=lambda c: c.get("risk_score", 0), reverse=True)[:5]
        findings_text = "\nTop API Security Findings:\n" + "\n".join(
            f"- {c.get('id','')}: {c.get('name','')} (risk: {c.get('risk','?')})"
            for c in top
        )
    system = (
        "You are a security architect. Generate concise Mermaid diagrams for API trust boundaries. "
        "Return only the Mermaid code — no prose."
    )
    user = f"""Create a Mermaid flowchart showing the API security boundary diagram for this architecture.
Show: API clients, API gateway/load balancer, backend services, auth service, data stores.
Mark high-risk flows with annotations. Use subgraphs for trust zones.
{findings_text}

Architecture:
---
{architecture_text}
---

Return ONLY the Mermaid diagram code starting with 'flowchart LR'."""

    raw = call_claude(api_key, system, user, max_tokens=4096, caller="diagram.api_flow")
    return _extract_mermaid(raw)


def generate_all(
    api_key: str,
    architecture_text: str,
    title: str,
    threat_model: dict,
    include_stride: bool = False,
    stride_results: list | None = None,
    include_api_flow: bool = False,
) -> dict:
    """Generate all diagram types in parallel. Returns dict keyed by diagram type."""
    tasks: dict[str, callable] = {
        "architecture": lambda: generate_architecture_diagram(api_key, architecture_text, title),
    }
    if api_key:
        tasks.update({
            "dfd": lambda: generate_dfd(api_key, architecture_text),
            "c4": lambda: generate_c4_context(api_key, architecture_text, title),
            "attack_tree": lambda: generate_attack_tree(api_key, architecture_text, threat_model),
        })
    if include_stride and api_key:
        tasks["stride"] = lambda: generate_stride_diagram(api_key, architecture_text, stride_results or [])
    if include_api_flow and api_key:
        api_findings = threat_model.get("categories", [])
        tasks["api_flow"] = lambda: generate_api_flow(api_key, architecture_text, api_findings)

    results: dict[str, str] = {}
    _fallbacks = {
        "architecture": 'flowchart LR\n  Error["Architecture diagram generation failed"]',
        "dfd":        'flowchart LR\n  Error["DFD generation failed"]',
        "c4":         'C4Context\n  title Error\n  System(err, "Generation Failed", "")',
        "attack_tree": 'flowchart TD\n  Root["Attack tree generation failed"]',
        "stride":     'flowchart LR\n  Error["STRIDE diagram failed"]',
        "api_flow":   'flowchart LR\n  Error["API flow diagram failed"]',
    }

    with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        for future in as_completed(futures):
            name = futures[future]
            try:
                results[name] = future.result()
            except Exception as e:
                results[name] = _fallbacks.get(name, f'flowchart LR\n  Error["{name} failed: {str(e)[:60]}"]')

    return results
