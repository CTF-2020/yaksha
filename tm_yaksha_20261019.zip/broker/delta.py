"""Finding fingerprints, baselines, and PR delta gating.

A *fingerprint* is a stable identity for a finding across scans: rule id + a
repo-relative path + a whitespace-normalized snippet, hashed. It is deliberately
line-number independent, so reindentation or an unrelated insertion above a
finding does not change its identity.

Fingerprints let the broker tell a brand-new finding on a PR apart from one that
already existed on the base branch, so the PR gate can fail only on *new*
problems instead of the whole backlog — the single biggest driver of whether a
security gate survives contact with a real team.
"""
from __future__ import annotations

import hashlib
import re

_WS_RE = re.compile(r"\s+")


def _norm_path(path: str) -> str:
    """Repo-relative, forward-slash path with any leading ./ or / removed."""
    p = str(path or "").replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    return p.lstrip("/")


def _norm_snippet(snippet: str) -> str:
    """Collapse all whitespace so formatting-only changes keep one identity."""
    return _WS_RE.sub(" ", str(snippet or "").strip())


def finding_fingerprint(finding: dict) -> str:
    """Stable 16-hex content hash for a finding (line-number independent)."""
    rule = str(finding.get("id") or finding.get("rule") or "")
    path = _norm_path(finding.get("file", ""))
    snippet = _norm_snippet(finding.get("snippet", ""))
    basis = f"{rule}\0{path}\0{snippet}"
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()[:16]


def fingerprints(findings) -> set[str]:
    """The fingerprint set for a list of findings."""
    return {finding_fingerprint(f) for f in findings or []}


def partition_new(findings, baseline: set[str]) -> tuple[list, list]:
    """Split findings into (new, known) relative to a baseline fingerprint set.

    A finding is *known* when its fingerprint is already in the baseline (it
    existed on the base branch); everything else is *new* and is what a delta
    gate should act on.
    """
    new: list = []
    known: list = []
    for f in findings or []:
        (known if finding_fingerprint(f) in (baseline or set()) else new).append(f)
    return new, known
