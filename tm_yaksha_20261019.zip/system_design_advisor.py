"""Bridge the local system-design bundle into threat-model reports."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Iterable

from system_design.system_design_full import SkillError, SystemDesignKnowledgeBase


SYSTEM_DESIGN_ROOT = Path(__file__).resolve().parent / "system_design"

DOMAIN_QUERIES: list[dict[str, object]] = [
    {
        "name": "Trust Boundaries and Identity",
        "query": "OAuth OpenID Connect SSO API Gateway mTLS service discovery proxy security",
        "match": ["auth", "identity", "oauth", "jwt", "sso", "iam", "trust", "gateway", "spoof"],
    },
    {
        "name": "Data Protection and State",
        "query": "databases SQL NoSQL replication sharding transactions caching consistency storage",
        "match": ["database", "storage", "data", "s3", "postgres", "cache", "transaction", "replication"],
    },
    {
        "name": "API and Interaction Surfaces",
        "query": "API Gateway REST GraphQL gRPC rate limiting load balancing proxy CDN",
        "match": ["api", "endpoint", "rate", "cors", "ssrf", "gateway", "load", "cdn", "proxy"],
    },
    {
        "name": "Resilience and Operations",
        "query": "SLA SLO SLI disaster recovery circuit breaker availability scalability monitoring",
        "match": ["dos", "availability", "logging", "monitoring", "backup", "resilience", "failover"],
    },
    {
        "name": "Distributed Architecture",
        "query": "microservices event driven architecture message queues pub sub CQRS event sourcing",
        "match": ["microservice", "queue", "event", "pub", "sub", "cqrs", "pipeline", "service"],
    },
    {
        "name": "AI and Retrieval Architecture",
        "query": "search indexes caching data stores API gateway message queues microservices",
        "match": ["llm", "rag", "vector", "embedding", "model", "agent", "tool", "retrieval"],
    },
]

_CATEGORY_DOMAIN_HINTS: list[tuple[list[str], str]] = [
    (["a01", "a07", "api1", "api2", "api5", "spoof", "elevation", "identity", "authentication", "authorization", "access control"], "Trust Boundaries and Identity"),
    (["a02", "a06", "a08", "llm03", "llm05", "cryptographic", "data", "secret", "component", "integrity", "storage"], "Data Protection and State"),
    (["a03", "a04", "a10", "api3", "api4", "api6", "api7", "api8", "api9", "api10", "injection", "ssrf", "resource", "endpoint"], "API and Interaction Surfaces"),
    (["a09", "stride-d", "repudiation", "denial", "logging", "monitoring", "availability", "incident"], "Resilience and Operations"),
    (["cloud", "c0", "cis", "pipeline", "microservice", "queue", "event", "supply chain"], "Distributed Architecture"),
    (["llm", "prompt", "agent", "rag", "model", "vector", "tool"], "AI and Retrieval Architecture"),
]


@lru_cache(maxsize=1)
def _knowledge_base() -> SystemDesignKnowledgeBase:
    return SystemDesignKnowledgeBase.load(SYSTEM_DESIGN_ROOT)


def _category_text(category: dict) -> str:
    threats = " ".join(
        " ".join(str(threat.get(key, "")) for key in ("name", "description", "attack_vector", "impact"))
        for threat in category.get("threats", [])
        if isinstance(threat, dict)
    )
    mitigations = " ".join(
        str(item.get("action", item) if isinstance(item, dict) else item)
        for item in category.get("mitigations", [])
    )
    return " ".join(
        str(part)
        for part in [
            category.get("id", ""),
            category.get("name", ""),
            category.get("risk", ""),
            category.get("notes", ""),
            category.get("source_method", ""),
            " ".join(category.get("affected_components", [])),
            threats,
            mitigations,
        ]
    ).lower()


def _report_text(report: dict, architecture_text: str) -> str:
    category_text = " ".join(_category_text(category) for category in report.get("categories", []))
    recommendations = " ".join(str(item) for item in report.get("recommendations", []))
    return f"{architecture_text} {report.get('summary', '')} {category_text} {recommendations}".lower()


def _topic_payload(kb: SystemDesignKnowledgeBase, hit) -> dict:
    section = hit.section
    try:
        summary = kb.summarize(section.slug, sentences=2)
    except SkillError:
        summary = hit.snippet
    return {
        "title": section.title,
        "slug": section.slug,
        "score": round(float(hit.score), 2),
        "read_minutes": section.read_minutes,
        "line_start": section.line_start,
        "summary": summary[:420],
        "reasons": list(hit.reasons)[:4],
    }


def _unique_topics(topics: Iterable[dict], limit: int) -> list[dict]:
    unique: list[dict] = []
    seen: set[str] = set()
    for topic in topics:
        slug = str(topic.get("slug", ""))
        if not slug or slug in seen:
            continue
        seen.add(slug)
        unique.append(topic)
        if len(unique) >= limit:
            break
    return unique


def _domain_guidance(kb: SystemDesignKnowledgeBase, report_text: str) -> list[dict]:
    domains: list[dict] = []
    for domain in DOMAIN_QUERIES:
        matches = [term for term in domain["match"] if str(term).lower() in report_text]
        query = f"{domain['query']} {' '.join(matches)}".strip()
        hits = kb.search(query, limit=4)
        topics = _unique_topics((_topic_payload(kb, hit) for hit in hits), 3)
        domains.append({
            "name": domain["name"],
            "matched_terms": matches[:8],
            "query": query,
            "topics": topics,
        })
    return domains


def build_system_design_context(report: dict, architecture_text: str) -> dict:
    """Return system-design guidance derived from a completed threat report."""
    kb = _knowledge_base()
    text = _report_text(report, architecture_text)
    domains = _domain_guidance(kb, text)

    report_hits = kb.search(text[:2500], limit=10)
    domain_topics = [
        topic
        for domain in domains
        for topic in domain.get("topics", [])
    ]
    top_topics = _unique_topics(
        [*domain_topics, *(_topic_payload(kb, hit) for hit in report_hits)],
        8,
    )
    if not top_topics:
        top_topics = _unique_topics(
            (
                {
                    "title": topic.title,
                    "slug": topic.slug,
                    "score": 0,
                    "read_minutes": topic.read_minutes,
                    "line_start": topic.line_start,
                    "summary": kb.summarize(topic.slug, sentences=1)[:420],
                    "reasons": ["baseline"],
                }
                for topic in kb.top_level_topics()[:8]
            ),
            8,
        )

    decision_queue = []
    for category in report.get("categories", [])[:10]:
        topic = _topic_for_category(category, domains)
        if not topic:
            break
        decision_queue.append({
            "area": category.get("name") or category.get("id") or "Architecture decision",
            "priority": category.get("risk", "Medium"),
            "topic": topic["title"],
            "decision": _decision_from_category(category, topic),
        })

    return {
        "bundle": {
            "name": kb.metadata.name,
            "description": kb.metadata.description,
            "root": str(SYSTEM_DESIGN_ROOT),
            "topics": len(kb.sections),
            "top_level_topics": len(kb.top_level_topics()),
        },
        "domains": domains,
        "top_topics": top_topics,
        "decision_queue": decision_queue[:8],
    }


def _decision_from_category(category: dict, topic: dict) -> str:
    mitigation = None
    for item in category.get("mitigations", []):
        mitigation = item.get("action") if isinstance(item, dict) else str(item)
        if mitigation:
            break
    if mitigation:
        return f"Apply '{topic['title']}' design guidance while implementing: {mitigation}"
    return f"Review '{topic['title']}' design guidance before finalizing this architecture area."


def _topic_for_category(category: dict, domains: list[dict]) -> dict | None:
    category_text = _category_text(category)
    category_base = " ".join(
        str(category.get(key, ""))
        for key in ("id", "name", "source_method", "source_label")
    ).lower()
    domain_by_name = {domain.get("name"): domain for domain in domains}
    for terms, domain_name in _CATEGORY_DOMAIN_HINTS:
        if any(term in category_base for term in terms):
            domain = domain_by_name.get(domain_name)
            if domain and domain.get("topics"):
                return domain["topics"][0]
    for domain_config in DOMAIN_QUERIES:
        if any(str(term).lower() in category_text for term in domain_config["match"]):
            domain = domain_by_name.get(domain_config["name"])
            if domain and domain.get("topics"):
                return domain["topics"][0]
    return next(
        (
            candidate
            for domain in domains
            for candidate in domain.get("topics", [])
            if candidate.get("slug")
        ),
        None,
    )
