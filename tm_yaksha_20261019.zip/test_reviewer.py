"""Tests for broker/reviewer.py — per-finding PR-reviewer analysis.

Everything runs against throwaway temp workspaces; nothing touches the real
report or broker stores.
"""
import tempfile
import unittest
from pathlib import Path

from broker import mapper, reviewer


def _ws(files: dict) -> Path:
    """Write {relpath: source} into a fresh temp dir and return its Path."""
    root = Path(tempfile.mkdtemp(prefix="revtest_"))
    for rel, src in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(src, encoding="utf-8")
    return root


def _review(files, file, line, **finding):
    root = _ws(files)
    f = {"file": file, "line": line, **finding}
    reviewer.review_findings(root, [f])
    return f.get("review")


PY_SQLI = '''\
import sqlite3
from flask import request

def search():
    q = request.args.get("q")
    sql = "SELECT * FROM items WHERE name = '" + q + "'"
    cur.execute(sql)
'''


class TestTaintVerdicts(unittest.TestCase):
    def test_python_taint_chain_is_likely_exploitable(self):
        rv = _review({"app.py": PY_SQLI}, "app.py", 7,
                     id="SQLI-1", title="SQL Injection", cwe="CWE-89")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_EXPLOITABLE)
        self.assertEqual(rv["function"]["name"], "search")
        # evidence names the derived identifier and cites the source line
        self.assertTrue(any("`sql`" in e for e in rv["evidence"]))
        self.assertTrue(any("request.args" in s for s in rv["flow"]))

    def test_direct_source_on_flagged_line_high_confidence(self):
        src = ('from flask import request\n'
               'def go():\n'
               '    os.system("ping " + request.args.get("host"))\n')
        rv = _review({"app.py": src}, "app.py", 3,
                     id="CMD-1", title="Command Injection", cwe="CWE-78")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_EXPLOITABLE)
        self.assertEqual(rv["confidence"], "high")

    def test_sanitizer_on_path_downgrades_to_needs_validation(self):
        src = ('import shlex\nfrom flask import request\n'
               'def go():\n'
               '    host = shlex.quote(request.args.get("host"))\n'
               '    os.system("ping " + host)\n')
        rv = _review({"app.py": src}, "app.py", 5,
                     id="CMD-1", title="Command Injection", cwe="CWE-78")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_VALIDATE)

    def test_constant_args_likely_false_positive(self):
        src = 'def go():\n    subprocess.run("ls", shell=True)\n'
        rv = _review({"app.py": src}, "app.py", 2,
                     id="SUBP-1", title="subprocess with shell", cwe="CWE-78")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_FALSE_POSITIVE)

    def test_constant_downgrade_never_applies_to_secret_rules(self):
        src = 'def cfg():\n    connect(password="hunter2")\n'
        rv = _review({"app.py": src}, "app.py", 2,
                     id="SEC-1", title="Hardcoded password", cwe="CWE-798")
        self.assertNotEqual(rv["verdict"], reviewer.VERDICT_FALSE_POSITIVE)
        # advice must never echo the secret back into the report
        self.assertNotIn("hunter2", str(rv.get("suggestion", "")))

    def test_test_path_is_likely_false_positive(self):
        rv = _review({"tests/test_x.py": PY_SQLI}, "tests/test_x.py", 7,
                     id="SQLI-1", title="SQL Injection", cwe="CWE-89")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_FALSE_POSITIVE)
        self.assertTrue(any("test" in e.lower() for e in rv["evidence"]))

    def test_source_in_scope_without_chain_needs_validation(self):
        src = ('from flask import request\n'
               'def go(path):\n'
               '    _ = request.args.get("unrelated")\n'
               '    open(path).read()\n')
        rv = _review({"app.py": src}, "app.py", 4,
                     id="PATH-1", title="Path traversal", cwe="CWE-22")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_VALIDATE)

    def test_no_source_at_all_low_confidence_validation(self):
        src = 'def go(path):\n    open(path).read()\n'
        rv = _review({"app.py": src}, "app.py", 2,
                     id="PATH-1", title="Path traversal", cwe="CWE-22")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_VALIDATE)
        self.assertEqual(rv["confidence"], "low")


class TestScopeExtraction(unittest.TestCase):
    def test_python_innermost_function_wins(self):
        src = ('def outer():\n'
               '    def inner():\n'
               '        eval(x)\n'
               '    inner()\n')
        rv = _review({"a.py": src}, "a.py", 3, id="EVAL-1", title="eval", cwe="CWE-95")
        self.assertEqual(rv["function"]["name"], "inner")

    def test_js_function_extraction_and_req_query_source(self):
        src = ('function handler(req, res) {\n'
               '  const q = req.query.name;\n'
               '  db.run("SELECT " + q);\n'
               '}\n')
        rv = _review({"srv.js": src}, "srv.js", 3,
                     id="SQLI-2", title="SQL Injection", cwe="CWE-89")
        self.assertEqual(rv["function"]["name"], "handler")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_EXPLOITABLE)

    def test_go_function_extraction(self):
        src = ('package main\n'
               'func Handle(w http.ResponseWriter, r *http.Request) {\n'
               '\tname := r.URL.Query().Get("name")\n'
               '\texec.Command("sh", "-c", name)\n'
               '}\n')
        rv = _review({"main.go": src}, "main.go", 4,
                     id="CMD-2", title="Command Injection", cwe="CWE-78")
        self.assertEqual(rv["function"]["name"], "Handle")
        self.assertEqual(rv["verdict"], reviewer.VERDICT_EXPLOITABLE)

    def test_js_control_keyword_not_captured_as_function(self):
        # `if (cond) {` looks like `name(args) {` to the signature scan — the
        # walk-back must skip it and report the real enclosing function.
        src = ('function realHandler(req, res) {\n'
               '  if (req.query.admin) {\n'
               '    db.run("SELECT " + req.query.id);\n'
               '  }\n'
               '}\n')
        rv = _review({'s.js': src}, 's.js', 3,
                     id='SQLI', title='SQL Injection', cwe='CWE-89')
        self.assertEqual(rv['function']['name'], 'realHandler')

    def test_java_while_not_captured_as_method(self):
        src = ('class C {\n'
               '  void handle(HttpServletRequest req) {\n'
               '    while (true) {\n'
               '      exec(req.getParameter("x"));\n'
               '    }\n'
               '  }\n'
               '}\n')
        rv = _review({'C.java': src}, 'C.java', 4,
                     id='CMD', title='Command Injection', cwe='CWE-78')
        self.assertEqual(rv['function']['name'], 'handle')

    def test_second_call_on_line_does_not_force_false_positive(self):
        # A real non-literal call plus a trailing literal call must NOT be
        # dismissed as constant-only.
        src = 'def go(user_input):\n    dangerous(user_input) or note("ok")\n'
        rv = _review({'a.py': src}, 'a.py', 2,
                     id='X', title='Code Injection', cwe='CWE-94')
        self.assertNotEqual(rv['verdict'], reviewer.VERDICT_FALSE_POSITIVE)

    def test_window_fallback_when_no_function(self):
        src = "x = 1\n" * 10 + 'eval(open("f").read())\n'
        rv = _review({"top.py": src}, "top.py", 11, id="EVAL-1", title="eval", cwe="CWE-95")
        self.assertIsNone(rv["function"]["name"])
        self.assertEqual(rv["function"]["kind"], "window")


class TestSuggestions(unittest.TestCase):
    def _sug(self, src, line, **finding):
        return _review({"a.py": src}, "a.py", line, **finding)["suggestion"]

    def test_yaml_load_mechanical_rewrite(self):
        sug = self._sug("def go(f):\n    data = yaml.load(f)\n", 2,
                        id="YAML-1", title="Unsafe YAML load", cwe="CWE-502")
        self.assertEqual(sug["kind"], "mechanical")
        self.assertIn("yaml.safe_load(", sug["diff"][1][1])

    def test_verify_false_mechanical_rewrite(self):
        sug = self._sug('def go(u):\n    requests.get(u, verify=False)\n', 2,
                        id="TLS-1", title="TLS verification disabled", cwe="CWE-295")
        self.assertIn("verify=True", sug["diff"][1][1])

    def test_shell_true_sketch(self):
        sug = self._sug("def go(c):\n    subprocess.run(c, shell=True)\n", 2,
                        id="SUBP-1", title="subprocess shell", cwe="CWE-78")
        self.assertEqual(sug["kind"], "sketch")
        self.assertNotIn("shell=True", sug["diff"][1][1])

    def test_md5_sketch_mentions_usedforsecurity(self):
        sug = self._sug("def go(d):\n    h = hashlib.md5(d)\n", 2,
                        id="HASH-1", title="Weak hash", cwe="CWE-327")
        self.assertIn("sha256", sug["diff"][1][1])
        self.assertIn("usedforsecurity", sug["note"])

    def test_fstring_sql_parameterization(self):
        src = ('from flask import request\n'
               'def go():\n'
               '    q = request.args.get("q")\n'
               '    cur.execute(f"SELECT * FROM t WHERE n = {q}")\n')
        sug = self._sug(src, 4, id="SQLI-1", title="SQL Injection", cwe="CWE-89")
        self.assertIn("%s", sug["diff"][1][1])
        self.assertIn("(q,)", sug["diff"][1][1])

    def test_percent_format_sql_still_gets_advice(self):
        # non-f-string SQLi (`%`, .format, concat) can't be mechanically rewritten
        # from one line, but must still carry parameterization advice — not nothing.
        src = ('from flask import request\n'
               'def go():\n'
               '    a = request.args.get("a")\n'
               '    cur.execute("SELECT * FROM t WHERE a=%s" % a)\n')
        sug = self._sug(src, 4, id="SQLI-1", title="SQL Injection", cwe="CWE-89")
        self.assertIsNotNone(sug)
        self.assertIsNone(sug["diff"])
        self.assertIn("parameter", sug["note"].lower())

    def test_concat_sql_gets_advice(self):
        src = ('from flask import request\n'
               'def go():\n'
               '    a = request.args.get("a")\n'
               '    cur.execute("SELECT * FROM t WHERE a=\'" + a + "\'")\n')
        sug = self._sug(src, 4, id="SQLI-1", title="SQL Injection", cwe="CWE-89")
        self.assertIsNotNone(sug)
        self.assertIn("parameter", sug["note"].lower())

    def test_os_system_gives_advice_not_broken_diff(self):
        sug = self._sug('def go(name):\n    os.system("tar -xf " + name)\n', 2,
                        id="CMD-1", title="Command Injection", cwe="CWE-78")
        self.assertIsNone(sug["diff"])          # no misleading single-element argv
        self.assertIn("argv", sug["note"].lower())

    def test_secret_rule_gets_advice_without_diff(self):
        sug = self._sug('def cfg():\n    api_key = "sk-XYZ"\n', 2,
                        id="SEC-2", title="Hardcoded API key", cwe="CWE-798")
        self.assertIsNone(sug["diff"])
        self.assertIn("rotate", sug["note"])

    def test_eval_rewrite_only_for_python(self):
        rv = _review({"a.js": "function go(x) {\n  eval(x);\n}\n"}, "a.js", 2,
                     id="EVAL-2", title="eval", cwe="CWE-95")
        sug = rv.get("suggestion")
        if sug is not None:
            self.assertNotIn("literal_eval", str(sug))


class TestSafetyAndPlumbing(unittest.TestCase):
    def test_path_escape_gets_no_review(self):
        root = _ws({"a.py": "x = 1\n"})
        f = {"file": "../../outside.py", "line": 1, "id": "X", "title": "x"}
        reviewer.review_findings(root, [f])
        self.assertNotIn("review", f)

    def test_missing_file_and_bad_line_are_skipped(self):
        root = _ws({"a.py": "x = 1\n"})
        fs = [{"file": "gone.py", "line": 1}, {"file": "a.py", "line": 0},
              {"file": "a.py", "line": "NaN"}, {"line": 3}]
        self.assertEqual(reviewer.review_findings(root, fs), 0)

    def test_review_cap(self):
        root = _ws({"a.py": "def go():\n    eval(x)\n"})
        fs = [{"file": "a.py", "line": 2, "id": "E", "title": "eval"}
              for _ in range(reviewer._MAX_REVIEWED + 20)]
        self.assertEqual(reviewer.review_findings(root, fs), reviewer._MAX_REVIEWED)

    def test_mapper_carries_review_and_supersedes_fp_boilerplate(self):
        f = {"id": "SQLI-1", "title": "SQL Injection", "file": "app.py", "line": 7,
             "severity": "High",
             "review": {"verdict": "likely-exploitable", "confidence": "high",
                        "summary": "User input reaches the sink.",
                        "evidence": ["e1"], "function": {"name": "search"}}}
        threat = mapper._threat_from_finding(f)
        self.assertEqual(threat["review"]["verdict"], "likely-exploitable")
        self.assertEqual(threat["false_positive_guidance"],
                         "User input reaches the sink.")

    def test_assign_regex_ignores_comparisons(self):
        for line in ("if x == 3:", "while a != b:", "return x <= y", "a === b"):
            self.assertIsNone(reviewer._ASSIGN_RE.match(line),
                              f"comparison misparsed as assignment: {line}")

    def test_reviewed_findings_still_json_serializable(self):
        import json
        rv = _review({"app.py": PY_SQLI}, "app.py", 7,
                     id="SQLI-1", title="SQL Injection", cwe="CWE-89")
        json.dumps(rv)   # raises on any non-serializable leak

    def test_brace_function_does_not_redos_on_long_ambiguous_line(self):
        # A crafted long line of repeated modifier keywords with no completing
        # "(" makes the java/csharp _SIG_RES patterns backtrack catastrophically
        # (exponential in line length) if matched in full — _MAX_SIG_LINE_LEN
        # truncation must keep this bounded regardless of input size.
        import time
        for lang in ("java", "csharp"):
            line = ("public " * 4000) + "X"
            t0 = time.time()
            reviewer._brace_function([line], 1, lang)
            elapsed = time.time() - t0
            self.assertLess(elapsed, 1.0,
                            f"{lang} signature regex took {elapsed:.2f}s — ReDoS regression")


if __name__ == "__main__":
    unittest.main()
