"""SQLite store for AI-BOM — the system of record for scan job history,
generated CycloneDX BOM documents, and the per-repo "latest" rollup that
feeds the org-wide inventory view.

:mod:`aibom.config` remains the public surface every caller uses; this module
is purely the persistence plumbing behind it, and also mirrors every write to
the legacy JSON files as a best-effort backup.

Stdlib ``sqlite3`` only, mirroring :mod:`report_db`'s pattern: connection-per-
call with WAL + a busy timeout, and an idempotent :func:`init` so ``DB_PATH``
can be repointed by tests without any "already initialized" staleness.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import closing
from pathlib import Path

from . import config

DB_PATH = config.STATE_DIR / "aibom.db"

_init_lock = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id          TEXT PRIMARY KEY,
    repo_id     TEXT,
    started_at  TEXT,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_aibom_jobs_repo ON jobs(repo_id);
CREATE TABLE IF NOT EXISTS boms (
    job_id      TEXT PRIMARY KEY,
    data        TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS latest (
    repo_id     TEXT PRIMARY KEY,
    scanned_at  TEXT,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_aibom_latest_scanned ON latest(scanned_at);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)


# ── Job history ───────────────────────────────────────────────────────────────
def load_jobs() -> list[dict]:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT data FROM jobs ORDER BY started_at DESC, rowid DESC").fetchall()
    return [json.loads(r["data"]) for r in rows]


def save_jobs(jobs: list[dict]) -> None:
    """Replace the full job history (the service always passes its complete,
    already-trimmed, in-memory set)."""
    init()
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM jobs")
        conn.executemany(
            "INSERT INTO jobs(id,repo_id,started_at,data) VALUES (?,?,?,?)",
            [(j.get("id"), j.get("repo_id"), str(j.get("started_at") or ""),
              json.dumps(j, ensure_ascii=False))
             for j in jobs if j.get("id")])


# ── BOM documents ─────────────────────────────────────────────────────────────
def save_bom(job_id: str, bom: dict) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT OR REPLACE INTO boms(job_id,data) VALUES (?,?)",
            (job_id, json.dumps(bom, ensure_ascii=False)))


def load_bom(job_id: str) -> dict | None:
    init()
    with closing(_connect()) as conn:
        row = conn.execute("SELECT data FROM boms WHERE job_id = ?", (job_id,)).fetchone()
    return json.loads(row["data"]) if row else None


# ── Per-repo latest rollup (feeds the org-wide inventory view) ────────────────
def save_latest(repo_id: str, summary: dict) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT OR REPLACE INTO latest(repo_id,scanned_at,data) VALUES (?,?,?)",
            (repo_id, str(summary.get("scanned_at") or ""),
             json.dumps(summary, ensure_ascii=False)))


def load_inventory() -> list[dict]:
    """All per-repo rollups, newest scan first."""
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT data FROM latest ORDER BY scanned_at DESC, rowid DESC").fetchall()
    return [json.loads(r["data"]) for r in rows]


def remove_latest(repo_id: str) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM latest WHERE repo_id = ?", (repo_id,))


def clear_all() -> int:
    """Wipe job history, generated BOM documents, and the per-repo latest
    rollup. Returns the number of jobs removed."""
    init()
    with closing(_connect()) as conn, conn:
        n = conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
        conn.execute("DELETE FROM jobs")
        conn.execute("DELETE FROM boms")
        conn.execute("DELETE FROM latest")
    return n


# ── Backfill ──────────────────────────────────────────────────────────────────
def backfill(jobs: list[dict], boms: dict[str, dict], latest: list[dict]) -> int:
    """Import a pre-existing JSON-only install's state once, on first boot
    after upgrading. Never touches the JSON files. Returns a rough count of
    records imported, for logging."""
    n = 0
    if jobs:
        save_jobs(jobs)
        n += len(jobs)
    for job_id, bom in (boms or {}).items():
        save_bom(job_id, bom)
        n += 1
    for entry in latest:
        repo_id = entry.get("repo_id") or entry.get("id")
        if repo_id:
            save_latest(repo_id, entry)
            n += 1
    return n


def job_count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
