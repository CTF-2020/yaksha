"""Single source of truth for the portal navigation.

Every page's navbar (templates/_portal_nav.html and the index.html topbar)
renders from NAV_ITEMS via the app-level context processor, and the same data
is served as JSON at GET /api/v1/nav (api/nav.py) so external consumers and
the UI agree on what tabs exist. Add/rename/remove a tab HERE, nowhere else.
"""
from __future__ import annotations

# key   — the `active` marker templates compare against
# label — visible tab text
# path  — href of the HTML page
# api   — the v1 API base(s) backing that page (full route lists at GET /api/v1)
NAV_ITEMS = [
    {"key": "dashboard", "label": "Overview",    "path": "/",
     "api": ["/api/v1/dashboard"]},
    {"key": "reports",   "label": "Analyse",     "path": "/reports",
     "api": ["/api/v1/reports", "/api/v1/analysis"]},
    {"key": "triage",    "label": "Triage",      "path": "/triage",
     "api": ["/api/v1/triage"]},
    # All code-analysis surfaces live under one "Code" tab, switched via the
    # shared _code_subnav.html secondary bar: Scan (SAST broker), Model
    # (code-derived threat model), Correlation (cross-source reconciliation).
    # DAST is soft-disabled (its blueprint isn't registered, see api/__init__.py)
    # so its API base is deliberately absent here too.
    {"key": "code",      "label": "Code",        "path": "/broker",
     "api": ["/api/v1/sast", "/api/v1/code-model", "/api/v1/correlate"]},
    {"key": "integrations", "label": "Integrations", "path": "/integrations",
     "api": ["/api/v1/sast"]},
    {"key": "rules",     "label": "Rules",       "path": "/rules",
     "api": ["/api/v1/rules"]},
    {"key": "aibom",     "label": "AIBOM",       "path": "/aibom",
     "api": ["/api/v1/aibom"]},
    # Only ever shown to admins — filtered out in app.py's context processor
    # and api/nav.py for everyone else, since the page itself 403s for them.
    {"key": "admin",     "label": "Admin",       "path": "/admin",
     "api": ["/api/v1/admin/users"], "admin_only": True},
]

# The "Use Cases ▾" dropdown on the report viewer. `key` feeds the page's
# fillUseCase(key) prefill; icon/name/desc are presentation.
USE_CASES = [
    {"key": "api",    "icon": "🔌", "name": "API & Microservices",
     "desc": "REST/GraphQL APIs, service mesh, auth flows"},
    {"key": "cloud",  "icon": "☁️", "name": "Cloud Infrastructure",
     "desc": "AWS/GCP/Azure deployments, IAM, storage"},
    {"key": "llm",    "icon": "🤖", "name": "AI / LLM Applications",
     "desc": "RAG pipelines, agents, prompt injection risks"},
    {"key": "mobile", "icon": "📱", "name": "Mobile & Client Apps",
     "desc": "iOS/Android, local storage, deep-links"},
    {"key": "web",    "icon": "🌐", "name": "Web Application",
     "desc": "SPA/SSR, auth, sessions, CSRF, XSS"},
]
