"""Confidence-decay API -- surfaces correlated findings whose evidence has
gone stale (see confidence_decay.py for the decay model).

Routes:
  GET /api/v1/confidence/summary    fleet-wide decay posture + a short worklist
  GET /api/v1/confidence/worklist   the full "needs re-verification" queue
                                     (?limit=)
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

import confidence_decay

bp = Blueprint("confidence_api", __name__, url_prefix="/api/v1/confidence")


@bp.get("/summary")
def summary():
    return jsonify({"success": True, **confidence_decay.summary()})


@bp.get("/worklist")
def worklist():
    try:
        limit = int(request.args.get("limit", 50))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "limit must be an integer"}), 400
    items = confidence_decay.worklist(limit=limit)
    return jsonify({"success": True, "count": len(items), "worklist": items})
