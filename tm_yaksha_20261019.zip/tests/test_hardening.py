"""tests/test_hardening.py — security-hardening regressions for app.py.

Covers HTML export escaping, secret scrubbing on persist, and retention pruning
of the report store so it cannot grow without bound.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest

import app as tm_app
import report_db


@pytest.fixture
def isolated_report_db(tmp_path, monkeypatch):
    """Point report_db at a scratch database so retention/count assertions are
    exact, not polluted by whatever real reports already exist in ~/.tm_reports."""
    monkeypatch.setattr(report_db, "DB_PATH", tmp_path / "reports.db")
    monkeypatch.setattr(tm_app, "REPORTS_DIR", tmp_path)


# ── Export escaping (#4) ────────────────────────────────────────────────────────

def test_export_html_escapes_malicious_risk_score():
    report = {
        "title": "XSS",
        "overall_risk": "High",
        "categories": [
            {"id": "A01", "name": "Broken Access Control", "risk": "High",
             "risk_score": "<script>alert(1)</script>"},
        ],
        "recommendations": ["<img src=x onerror=alert(1)>"],
    }
    html = tm_app._build_export_html(report)
    assert "<script>alert(1)</script>" not in html
    assert "&lt;script&gt;" in html
    assert "<img src=x onerror=alert(1)>" not in html


def test_export_html_escapes_malicious_title_and_name():
    report = {
        "title": "</title><script>bad()</script>",
        "overall_risk": "High",
        "categories": [{"id": "<b>id</b>", "name": "<svg/onload=x>", "risk": "High"}],
    }
    html = tm_app._build_export_html(report)
    assert "<script>bad()</script>" not in html
    assert "<svg/onload=x>" not in html


def test_export_html_only_uses_safe_risk_colors():
    # An attacker-controlled risk string must not break out of the style attribute.
    report = {
        "title": "Color",
        "overall_risk": "red;}</style><script>x</script>",
        "categories": [{"id": "A01", "name": "X", "risk": "red;}</style><script>y</script>"}],
    }
    html = tm_app._build_export_html(report)
    assert "<script>" not in html


# ── Secret scrubbing (#3) ────────────────────────────────────────────────────────

def test_save_report_strips_secrets(isolated_report_db):
    report = {
        "overall_risk": "Low",
        "categories": [],
        "api_key": "sk-secret",
        "jira_token": "jira-secret",
        "summary": "ok",
    }
    report_id = tm_app._save_report(report, "Secret Test")
    saved = report_db.get_report(report_id)
    assert "api_key" not in saved
    assert "jira_token" not in saved
    assert "sk-secret" not in report_db._connect().execute(
        "SELECT data FROM reports WHERE id = ?", (report_id,)).fetchone()[0]
    assert saved["summary"] == "ok"


# ── Retention / size caps (#5) ───────────────────────────────────────────────────

def test_retention_prunes_oldest_reports(isolated_report_db, monkeypatch):
    monkeypatch.setattr(tm_app, "_RETENTION_LIMIT", 3)

    # Save more reports than the retention limit.
    ids = [tm_app._save_report({"overall_risk": "Low", "categories": []}, f"R{i}") for i in range(5)]

    remaining = {r["id"] for r in report_db.list_reports(limit=100, include_sast=True)}

    assert len(remaining) <= 3
    assert ids[-1] in remaining          # newest retained
    assert ids[0] not in remaining       # oldest pruned


def test_prune_to_limit_is_safe_with_no_reports(isolated_report_db):
    # Must not error, and must not touch a report that's within the limit.
    report_id = tm_app._save_report({"overall_risk": "Low", "categories": []}, "Solo")
    tm_app._prune_reports_to_limit()
    assert report_db.get_report(report_id) is not None


def test_sast_reports_pruned_independently_of_other_reports(isolated_report_db):
    # A burst of one report type must not evict the other's history — SAST
    # scans are typically far more frequent than manual reviews, and broker
    # keeps its own job history independently (JOB_RETENTION), so an evicted
    # SAST report leaves a dangling job -> report link ("open" 404s) even
    # though the job is still listed.
    sast_ids = [report_db.upsert_report(
        {"id": f"s{i}", "methodology": "sast", "overall_risk": "Low", "categories": []})
        or f"s{i}" for i in range(5)]
    other_ids = [tm_app._save_report({"overall_risk": "Low", "categories": []}, f"R{i}")
                 for i in range(5)]

    deleted = report_db.prune_to_limit_by_bucket(sast_limit=3, other_limit=2)

    remaining = {r["id"] for r in report_db.list_reports(limit=100, include_sast=True)}
    assert set(deleted) & set(sast_ids)  # oldest SAST reports were pruned
    assert set(deleted) & set(other_ids)  # oldest other reports were pruned too
    assert len(remaining & set(sast_ids)) == 3   # newest 3 SAST kept
    assert len(remaining & set(other_ids)) == 2  # newest 2 other kept
    # newest of each bucket always survives
    assert sast_ids[-1] in remaining
    assert other_ids[-1] in remaining
