"""DAST module tests (stdlib unittest).

Run from the tm project root:
    python -m unittest test_dast

The engine tests stand up a deliberately-vulnerable HTTP app in-process (loopback,
ephemeral port) and scan it, so the active/passive checks are exercised against
real responses rather than mocks.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from dast import config, engine, github, mapper, scanner

# Every target in this suite is an in-process loopback fixture, so the polite
# inter-request delay (0.3s production default) is pure dead time here — it was
# ~80% of the suite's wall clock (e.g. the benchmark corpus test: 106s → ~15s).
# Fetcher reads config.RATE_DELAY at construction, so patching the module
# attribute covers every scan the service spawns, not just explicit Fetchers.
config.RATE_DELAY = 0.0


# ── A tiny intentionally-insecure app to scan ─────────────────────────────────
class _VulnHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):            # keep the test output clean
        pass

    def do_GET(self):                     # noqa: N802 (stdlib signature)
        parsed = urlparse(self.path)
        path, qs = parsed.path, parse_qs(parsed.query)

        if path == "/redir" and "url" in qs:
            # Open redirect: reflect the attacker-controlled destination.
            self.send_response(302)
            self.send_header("Location", qs["url"][0])
            self.end_headers()
            return

        if path == "/page2":
            # Reflected XSS: echo q unencoded into an HTML body.
            q = qs.get("q", [""])[0]
            body = f"<html><body>you searched for {q}</body></html>"
            self._send_html(body)
            return

        if path == "/error":
            self._send_html("<html><body>Traceback (most recent call last):\n"
                            "  File x</body></html>")
            return

        # Landing page: no security headers, insecure cookie, links to the rest.
        body = ("<html><head><title>Vuln App</title></head><body>"
                "<a href='/page2?q=1'>search</a> "
                "<a href='/redir?url=1'>go</a> "
                "<a href='/error'>err</a> "
                "<a href='http://evil.example.com/x?p=1'>offsite</a>"
                "</body></html>")
        self._send_html(body, cookie="sid=abc123")

    def _send_html(self, body: str, cookie: str = ""):
        raw = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("X-Powered-By", "PHP/8.1.0")
        if cookie:
            self.send_header("Set-Cookie", cookie)   # no Secure/HttpOnly/SameSite
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


class _VulnServer:
    def __enter__(self):
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), _VulnHandler)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.port}/"
        return self

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.httpd.server_close()


def _ids(findings):
    return {f["id"] for f in findings}


# ── Engine end-to-end ─────────────────────────────────────────────────────────
class TestEngineEndToEnd(unittest.TestCase):
    def test_full_scan_finds_expected_classes(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope, severity_threshold="Info")
        ids = _ids(result.findings)
        # Passive
        self.assertIn("DAST-HDR-CSP", ids)
        self.assertIn("DAST-HDR-XCTO", ids)
        self.assertIn("DAST-HDR-XFO", ids)
        self.assertIn("DAST-COOKIE-FLAGS", ids)
        self.assertIn("DAST-INFO-BANNER", ids)     # X-Powered-By: PHP/8.1.0
        self.assertIn("DAST-TLS-PLAINTEXT", ids)   # served over http
        self.assertIn("DAST-INFO-ERROR", ids)      # /error stack trace
        # Active
        self.assertIn("DAST-XSS-REFLECTED", ids)
        self.assertIn("DAST-OPEN-REDIRECT", ids)

    def test_reflected_xss_is_high_and_located_to_param(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope, severity_threshold="Info")
        xss = [f for f in result.findings if f["id"] == "DAST-XSS-REFLECTED"]
        self.assertTrue(xss)
        self.assertEqual(xss[0]["severity"], "High")
        self.assertEqual(xss[0]["param"], "q")
        self.assertEqual(xss[0]["cwe"], "CWE-79")

    def test_active_finding_captures_request_and_response_evidence(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope, severity_threshold="Info")
        xss = [f for f in result.findings if f["id"] == "DAST-XSS-REFLECTED"][0]
        # The exact request that triggered it is kept for reproduction.
        self.assertTrue(xss["request"].startswith("GET http"))
        self.assertIn("page2", xss["request"])
        # The response evidence contains the reflected marker in context — the
        # "vulnerable code" a dynamic scan can show.
        self.assertIn(engine._XSS_MARKER, xss["evidence_snippet"])
        self.assertIn("you searched for", xss["evidence_snippet"])

    def test_scope_confinement_never_leaves_authorized_host(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope, severity_threshold="Info")
        for f in result.findings:
            host = (urlparse(f["url"]).hostname or "").lower()
            self.assertIn(host, scope, f"finding escaped scope: {f['url']}")

    def test_passive_only_mode_skips_active_checks(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope, severity_threshold="Info",
                                 active=False)
        ids = _ids(result.findings)
        self.assertIn("DAST-HDR-CSP", ids)          # passive still runs
        self.assertNotIn("DAST-XSS-REFLECTED", ids)  # active suppressed
        self.assertNotIn("DAST-OPEN-REDIRECT", ids)

    def test_severity_threshold_filters_low_and_info(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope, severity_threshold="High")
        for f in result.findings:
            self.assertIn(f["severity"], ("Critical", "High"))


# ── Engine safety invariants ──────────────────────────────────────────────────
class TestEvidenceSnippet(unittest.TestCase):
    def test_snippet_excerpts_around_match_with_ellipses(self):
        body = "A" * 300 + "SECRET_TOKEN" + "B" * 300
        snip = engine._snippet(body, "secret_token")   # case-insensitive
        self.assertIn("SECRET_TOKEN", snip)
        self.assertTrue(snip.startswith("…") and snip.endswith("…"))
        self.assertLessEqual(len(snip), engine._SNIPPET_MAX + 4)

    def test_snippet_collapses_whitespace(self):
        body = "line1\n\n   line2  MATCH  line3"
        snip = engine._snippet(body, "MATCH")
        self.assertNotIn("\n", snip)
        self.assertIn("MATCH", snip)

    def test_snippet_returns_empty_when_absent(self):
        self.assertEqual(engine._snippet("hello world", "nope"), "")
        self.assertEqual(engine._snippet("", "x"), "")


class TestEngineSafety(unittest.TestCase):
    def test_request_budget_is_enforced(self):
        with _VulnServer() as srv:
            f = engine.Fetcher(budget=3, delay=0)
            for _ in range(3):
                self.assertTrue(f.get(srv.base).ok)
            self.assertTrue(f.exhausted())
            self.assertFalse(f.get(srv.base).ok)  # 4th refused, not sent

    def test_redirects_are_not_followed(self):
        with _VulnServer() as srv:
            f = engine.Fetcher(delay=0)
            resp = f.get(srv.base + "redir?url=https://dast-canary.example.net/")
        self.assertEqual(resp.status, 302)
        self.assertEqual(resp.header("location"),
                         "https://dast-canary.example.net/")


# ── Config ────────────────────────────────────────────────────────────────────
class TestConfig(unittest.TestCase):
    def test_normalize_target_url(self):
        self.assertEqual(config.normalize_target_url("example.com"),
                         "http://example.com")
        self.assertEqual(config.normalize_target_url("https://x/y"), "https://x/y")
        self.assertEqual(config.normalize_target_url("ftp://x"), "")
        self.assertEqual(config.normalize_target_url("javascript:alert(1)"), "")
        self.assertEqual(config.normalize_target_url(""), "")

    def test_parse_scope_defaults_to_target_host(self):
        self.assertEqual(config.parse_scope("", "app.local"), ["app.local"])
        self.assertCountEqual(config.parse_scope("a.local, b.local", "app.local"),
                              ["a.local", "b.local", "app.local"])

    def test_redact_target_hides_secret(self):
        t = {"id": "x", "name": "X", "auth_header": "Authorization: Bearer s3cr3t"}
        red = config.redact_target(t)
        self.assertNotIn("auth_header", red)
        self.assertTrue(red["auth_header_set"])
        self.assertFalse(config.redact_target({"id": "y"})["auth_header_set"])

    def test_target_registry_crud(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            orig = config.TARGETS_PATH
            config.TARGETS_PATH = Path(tmp) / "targets.json"
            try:
                self.assertEqual(config.load_targets(), [])
                config.upsert_target({"id": "app", "name": "App", "url": "https://a/"})
                self.assertEqual(len(config.load_targets()), 1)
                self.assertEqual(config.get_target("app")["name"], "App")
                config.upsert_target({"id": "app", "name": "App2", "url": "https://a/"})
                self.assertEqual(config.get_target("app")["name"], "App2")  # replace
                self.assertTrue(config.remove_target("app"))
                self.assertFalse(config.remove_target("app"))
            finally:
                config.TARGETS_PATH = orig


# ── Scanner boundary ──────────────────────────────────────────────────────────
class TestScanner(unittest.TestCase):
    def test_prepare_target_rejects_non_http(self):
        with self.assertRaises(scanner.ScanError):
            scanner.prepare_target({"url": "ftp://x/"})
        with self.assertRaises(scanner.ScanError):
            scanner.prepare_target({"url": ""})

    def test_prepare_target_returns_scope(self):
        url, scope = scanner.prepare_target({"url": "https://app.local/x"})
        self.assertEqual(url, "https://app.local/x")
        self.assertIn("app.local", scope)


# ── Mapper ────────────────────────────────────────────────────────────────────
class TestMapper(unittest.TestCase):
    def _findings(self):
        return [
            {"id": "DAST-XSS-REFLECTED", "title": "Reflected Cross-Site Scripting",
             "severity": "High", "url": "https://a/p", "param": "q",
             "evidence": "reflects payload", "owasp": "A03:2021 Injection",
             "cwe": "CWE-79", "remediation": "encode output", "method": "GET"},
            {"id": "DAST-HDR-CSP", "title": "Missing Content-Security-Policy header",
             "severity": "Medium", "url": "https://a/", "param": "",
             "evidence": "no CSP", "owasp": "A05", "cwe": "CWE-693",
             "remediation": "set CSP", "method": "GET"},
        ]

    def test_report_shape(self):
        target = {"id": "app", "name": "App", "url": "https://a/"}
        meta = {"pages_crawled": 3, "requests_made": 12}
        report = mapper.findings_to_report(self._findings(), target, meta, "Info")
        self.assertEqual(report["methodology"], "dast")
        self.assertEqual(report["overall_risk"], "High")       # worst wins
        self.assertEqual(report["categories"][0]["id"], "DAST-XSS-REFLECTED")  # sorted worst-first
        self.assertEqual(report["scan_metadata"]["findings_total"], 2)
        self.assertEqual(report["scan_metadata"]["rules_triggered"], 2)
        self.assertIn("encode output", report["recommendations"])
        # each finding becomes a threat ticket inside its rule card
        self.assertEqual(report["categories"][0]["threats"][0]["name"], "https://a/p [q]")

    def test_threat_carries_request_and_response_evidence(self):
        findings = [{
            "id": "DAST-SQLI", "title": "SQL injection (error-based)",
            "severity": "High", "url": "https://a/p", "param": "id",
            "evidence": "quote triggers DB error", "owasp": "A03:2021 Injection",
            "cwe": "CWE-89", "remediation": "parameterize", "method": "GET",
            "request": "GET https://a/p?id=1'",
            "evidence_snippet": "…you have an error in your SQL syntax…",
        }]
        report = mapper.findings_to_report(
            findings, {"id": "a", "name": "A", "url": "https://a/"},
            {"pages_crawled": 1, "requests_made": 3}, "Info")
        threat = report["categories"][0]["threats"][0]
        self.assertEqual(threat["request"], "GET https://a/p?id=1'")
        self.assertIn("error in your SQL syntax", threat["evidence_snippet"])

    def test_passive_finding_omits_reproduction_fields(self):
        # A header finding has no request/snippet — the mapper must not invent them.
        findings = [{
            "id": "DAST-HDR-CSP", "title": "Missing CSP", "severity": "Medium",
            "url": "https://a/", "param": "", "evidence": "no CSP", "owasp": "A05",
            "cwe": "CWE-693", "remediation": "set CSP", "method": "GET"}]
        report = mapper.findings_to_report(
            findings, {"id": "a", "name": "A", "url": "https://a/"},
            {"pages_crawled": 1, "requests_made": 1}, "Info")
        threat = report["categories"][0]["threats"][0]
        self.assertNotIn("request", threat)
        self.assertNotIn("evidence_snippet", threat)

    def test_empty_findings_report(self):
        report = mapper.findings_to_report([], {"id": "a", "name": "A", "url": "https://a/"},
                                           {"pages_crawled": 1, "requests_made": 1}, "Info")
        self.assertEqual(report["overall_risk"], "Info")
        self.assertEqual(report["categories"], [])


# ── GitHub CI release-gate: webhook parsing ───────────────────────────────────
class TestWebhookParsing(unittest.TestCase):
    def _repo(self):
        return {"repository": {"full_name": "me/app"}}

    def test_ping(self):
        p = github.parse_webhook("ping", self._repo())
        self.assertEqual(p["kind"], "ping")
        self.assertEqual(p["full_name"], "me/app")

    def test_deployment_status_success(self):
        payload = {**self._repo(),
                   "deployment": {"sha": "abc123", "environment": "staging", "id": 42},
                   "deployment_status": {"state": "success", "environment": "staging"}}
        p = github.parse_webhook("deployment_status", payload)
        self.assertEqual(p["kind"], "deployment")
        self.assertEqual(p["sha"], "abc123")
        self.assertEqual(p["environment"], "staging")
        self.assertEqual(p["deployment_id"], 42)

    def test_deployment_status_non_success_ignored(self):
        payload = {**self._repo(), "deployment": {"sha": "abc"},
                   "deployment_status": {"state": "pending"}}
        self.assertEqual(github.parse_webhook("deployment_status", payload)["kind"],
                         "ignored")

    def test_push_parsed_with_branch(self):
        payload = {**self._repo(), "ref": "refs/heads/main", "after": "d34db33f"}
        p = github.parse_webhook("push", payload)
        self.assertEqual(p["kind"], "push")
        self.assertEqual(p["branch"], "main")
        self.assertEqual(p["sha"], "d34db33f")

    def test_push_branch_deletion_ignored(self):
        payload = {**self._repo(), "ref": "refs/heads/x", "after": "0" * 40,
                   "deleted": True}
        self.assertEqual(github.parse_webhook("push", payload)["kind"], "ignored")

    def test_unhandled_event_ignored(self):
        self.assertEqual(github.parse_webhook("issues", self._repo())["kind"], "ignored")

    def test_signature_roundtrip(self):
        secret, body = "s3cr3t", b'{"hello":"world"}'
        sig = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        self.assertTrue(github.verify_signature(secret, body, sig))
        self.assertFalse(github.verify_signature(secret, body, sig + "0"))
        self.assertFalse(github.verify_signature("", body, sig))


# ── Target matching for a webhook ─────────────────────────────────────────────
class TestFindTargetForGithub(unittest.TestCase):
    def setUp(self):
        self._orig = config.TARGETS_PATH
        self._tmp = tempfile.TemporaryDirectory()
        config.TARGETS_PATH = Path(self._tmp.name) / "targets.json"

    def tearDown(self):
        config.TARGETS_PATH = self._orig
        self._tmp.cleanup()

    def test_matches_explicit_full_name(self):
        config.upsert_target({"id": "app", "name": "App", "url": "https://a/",
                              "github_full_name": "me/app"})
        self.assertEqual(config.find_target_for_github("Me/App")["id"], "app")  # case-insensitive
        self.assertIsNone(config.find_target_for_github("me/other"))

    def test_matches_repo_url_derivation(self):
        config.upsert_target({"id": "app", "name": "App", "url": "https://a/",
                              "repo_url": "https://github.com/me/app.git"})
        self.assertEqual(config.find_target_for_github("me/app")["id"], "app")


# ── Report-back to GitHub (fake client, no network) ───────────────────────────
_GH_CALLS: list = []


class _FakeClient:
    def __init__(self, *a, **k):
        pass

    def create_check_run(self, full, sha, **k):
        _GH_CALLS.append(("check", k.get("conclusion")))
        return {"id": 1}

    def set_commit_status(self, full, sha, state, desc, url=""):
        _GH_CALLS.append(("status", state))

    def _request(self, method, path, body=None):
        _GH_CALLS.append(("deploy", (body or {}).get("state")))
        return {}


class _FakeClientNoChecks(_FakeClient):
    def create_check_run(self, full, sha, **k):
        raise github.GitHubError("403: checks:write required")


class TestReportBack(unittest.TestCase):
    def setUp(self):
        _GH_CALLS.clear()
        self._orig = github.GitHubClient

    def tearDown(self):
        github.GitHubClient = self._orig

    def _report(self, sev):
        f = [{"id": "DAST-X", "title": "X", "severity": sev, "url": "https://a/",
              "param": "", "evidence": "e", "owasp": "o", "cwe": "c",
              "remediation": "r", "method": "GET"}]
        return mapper.findings_to_report(f, {"id": "a", "name": "A", "url": "https://a/"},
                                         {"pages_crawled": 1, "requests_made": 1}, "Info")

    def _ctx(self):
        return {"kind": "deployment", "full_name": "me/app", "sha": "abc",
                "environment": "staging", "deployment_id": 42, "public_url": "http://tm"}

    def test_check_run_and_deployment_status_on_gate_fail(self):
        github.GitHubClient = _FakeClient
        target = {"id": "a", "github_token": "tok", "fail_on": "High"}
        github.report_to_github(target, self._ctx(), self._report("High"), "rid", None)
        self.assertIn(("check", "failure"), _GH_CALLS)     # High >= gate High -> fail
        self.assertIn(("deploy", "failure"), _GH_CALLS)     # deployment status posted

    def test_check_run_success_when_gate_passes(self):
        github.GitHubClient = _FakeClient
        target = {"id": "a", "github_token": "tok", "fail_on": "High"}
        github.report_to_github(target, self._ctx(), self._report("Low"), "rid", None)
        self.assertIn(("check", "success"), _GH_CALLS)      # Low < gate High -> pass
        self.assertIn(("deploy", "success"), _GH_CALLS)

    def test_falls_back_to_commit_status_without_checks_permission(self):
        github.GitHubClient = _FakeClientNoChecks
        target = {"id": "a", "github_token": "tok", "fail_on": "High"}
        github.report_to_github(target, self._ctx(), self._report("High"), "rid", None)
        self.assertIn(("status", "failure"), _GH_CALLS)     # fell back to commit status

    def test_skipped_without_token(self):
        github.GitHubClient = _FakeClient
        target = {"id": "a", "github_token": ""}
        orig = config.GITHUB_TOKEN
        config.GITHUB_TOKEN = ""
        try:
            github.report_to_github(target, self._ctx(), self._report("High"), "rid", None)
        finally:
            config.GITHUB_TOKEN = orig
        self.assertEqual(_GH_CALLS, [])                      # no calls at all


# ── Full webhook -> scan -> report-back path through the Flask app ─────────────
@unittest.skip("DAST is soft-disabled: its blueprint isn't registered "
               "(api/__init__.py), so /api/v1/dast* routes 404")
class TestWebhookE2E(unittest.TestCase):
    def test_deployment_webhook_scans_registered_target(self):
        import app as tm_app
        orig_client = github.GitHubClient
        github.GitHubClient = _FakeClient
        _GH_CALLS.clear()
        c = tm_app.app.test_client()
        csrf = json.loads(c.get("/api/csrf-token").data)["token"]
        hdr = {"X-CSRF-Token": csrf, "Content-Type": "application/json"}
        report_id = None
        try:
            with _VulnServer() as srv:
                c.post("/api/v1/dast/targets", headers=hdr, json={
                    "name": "wh-e2e", "url": srv.base,
                    "github_full_name": "me/whapp", "github_token": "tok",
                    "webhook_secret": "s3cr3t", "fail_on": "High"})

                payload = json.dumps({
                    "repository": {"full_name": "me/whapp"},
                    "deployment": {"sha": "abc123", "environment": "staging", "id": 7},
                    "deployment_status": {"state": "success", "environment": "staging"},
                }).encode()
                sig = "sha256=" + hmac.new(b"s3cr3t", payload, hashlib.sha256).hexdigest()
                r = c.post("/api/v1/dast/webhook", data=payload, headers={
                    "X-GitHub-Event": "deployment_status",
                    "X-Hub-Signature-256": sig, "Content-Type": "application/json"})
                self.assertEqual(r.status_code, 202)
                job_id = json.loads(r.data)["job_id"]

                import time
                for _ in range(80):
                    job = json.loads(c.get(f"/api/v1/dast/jobs/{job_id}").data)["job"]
                    if job["status"] in ("done", "error"):
                        break
                    time.sleep(0.25)
            self.assertEqual(job["status"], "done")
            self.assertEqual(job["trigger"], "deployment")
            self.assertEqual(job["environment"], "staging")
            self.assertGreater(job["stats"]["findings_total"], 0)
            report_id = job["report_id"]
            # report-back to GitHub happened (check run + deployment status)
            self.assertTrue(any(k == "check" for k, _ in _GH_CALLS))
            self.assertTrue(any(k == "deploy" for k, _ in _GH_CALLS))
        finally:
            github.GitHubClient = orig_client
            c.delete("/api/v1/dast/targets/wh-e2e", headers=hdr)
            if report_id:
                c.delete(f"/api/v1/reports/{report_id}", headers=hdr)

    def test_invalid_signature_rejected(self):
        import app as tm_app
        c = tm_app.app.test_client()
        csrf = json.loads(c.get("/api/csrf-token").data)["token"]
        hdr = {"X-CSRF-Token": csrf, "Content-Type": "application/json"}
        try:
            c.post("/api/v1/dast/targets", headers=hdr, json={
                "name": "wh-sig", "url": "https://x.local/",
                "github_full_name": "me/sig", "webhook_secret": "right"})
            payload = json.dumps({"repository": {"full_name": "me/sig"},
                                  "deployment": {"sha": "x", "id": 1},
                                  "deployment_status": {"state": "success"}}).encode()
            bad = "sha256=" + hmac.new(b"wrong", payload, hashlib.sha256).hexdigest()
            r = c.post("/api/v1/dast/webhook", data=payload, headers={
                "X-GitHub-Event": "deployment_status",
                "X-Hub-Signature-256": bad, "Content-Type": "application/json"})
            self.assertEqual(r.status_code, 401)
        finally:
            c.delete("/api/v1/dast/targets/wh-sig", headers=hdr)


# ── XSS context-awareness (false-positive control) ────────────────────────────
class TestXssContextAwareness(unittest.TestCase):
    """The reflected-XSS check must only cry High when a real markup breakout
    parses — reflections into a comment/textarea, or properly encoded, must not."""

    def _det(self, body: str) -> bool:
        d = engine._BreakoutDetector(engine._XSS_TOKEN)
        d.feed(body)
        return d.injected

    def test_breakout_in_body_is_detected(self):
        self.assertTrue(self._det(f"<div>x {engine._XSS_MARKER} y</div>"))

    def test_breakout_from_attribute_is_detected(self):
        self.assertTrue(self._det(f'<input value="{engine._XSS_MARKER}">'))

    def test_reflection_in_comment_is_inert(self):
        self.assertFalse(self._det(f"<!-- {engine._XSS_MARKER} -->"))

    def test_reflection_in_textarea_is_inert(self):
        self.assertFalse(self._det(f"<textarea>{engine._XSS_MARKER}</textarea>"))

    def test_reflection_in_title_is_inert(self):
        self.assertFalse(self._det(f"<title>{engine._XSS_MARKER}</title>"))

    def test_reflection_in_script_is_inert(self):
        self.assertFalse(self._det(f"<script>var x='{engine._XSS_MARKER}'</script>"))


# ── New passive checks: CSP quality, mixed content, secrets, cache ────────────
class TestNewPassiveChecks(unittest.TestCase):
    def _rep(self):
        return engine._Reporter(threshold=99)

    def test_weak_csp_flagged(self):
        rep = self._rep()
        resp = engine.Resp("https://a/", 200,
                           {"content-type": "text/html",
                            "content-security-policy":
                                "script-src 'self' 'unsafe-inline' *"},
                           None, "<html></html>")
        engine._check_csp_quality(resp, rep)
        self.assertIn("DAST-HDR-CSP-WEAK", _ids(rep.findings))

    def test_strong_csp_not_flagged(self):
        rep = self._rep()
        resp = engine.Resp("https://a/", 200,
                           {"content-type": "text/html",
                            "content-security-policy":
                                "default-src 'self'; object-src 'none'; "
                                "base-uri 'self'"},
                           None, "<html></html>")
        engine._check_csp_quality(resp, rep)
        self.assertNotIn("DAST-HDR-CSP-WEAK", _ids(rep.findings))

    def test_mixed_content_flagged_only_on_https(self):
        rep = self._rep()
        engine._check_mixed_content("https://a/", ["http://cdn/x.js",
                                                   "https://ok/y.js"], rep)
        self.assertIn("DAST-MIXED-CONTENT", _ids(rep.findings))
        rep2 = self._rep()
        engine._check_mixed_content("http://a/", ["http://cdn/x.js"], rep2)
        self.assertEqual(rep2.findings, [])

    def test_secret_in_url_flagged(self):
        rep = self._rep()
        engine._check_url_secrets("https://a/cb?api_key=AKIA123&state=x", rep)
        ids = _ids(rep.findings)
        self.assertIn("DAST-INFO-SECRET-URL", ids)
        # a benign param name must not fire
        rep2 = self._rep()
        engine._check_url_secrets("https://a/cb?page=2&state=x", rep2)
        self.assertEqual(rep2.findings, [])

    def test_cacheable_authenticated_response_flagged(self):
        rep = self._rep()
        import email.message
        msg = email.message.Message()
        msg["Set-Cookie"] = "sid=1"
        resp = engine.Resp("https://a/", 200, {"content-type": "text/html"},
                           msg, "<html></html>")
        engine._check_cache(resp, rep, authenticated=False)
        self.assertIn("DAST-HDR-CACHE", _ids(rep.findings))


# ── Reflected-Origin CORS (active) ────────────────────────────────────────────
class _CorsHandler(BaseHTTPRequestHandler):
    reflect_creds = True

    def log_message(self, *a):
        pass

    def version_string(self):
        return "t"

    def do_GET(self):                          # noqa: N802
        origin = self.headers.get("Origin", "")
        body = b"<html><body>api</body></html>"
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            if type(self).reflect_creds:
                self.send_header("Access-Control-Allow-Credentials", "true")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class TestReflectedOriginCors(unittest.TestCase):
    def _scan(self, handler_cls):
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
        port = httpd.server_address[1]
        t = threading.Thread(target=httpd.serve_forever, daemon=True)
        t.start()
        try:
            base = f"http://127.0.0.1:{port}/"
            scope = config.parse_scope("", "127.0.0.1")
            return engine.scan(base, scope, severity_threshold="Info")
        finally:
            httpd.shutdown()
            httpd.server_close()

    def test_reflect_with_credentials_is_high(self):
        class H(_CorsHandler):
            reflect_creds = True
        r = self._scan(H)
        hit = [f for f in r.findings if f["id"] == "DAST-CORS-REFLECT-CREDS"]
        self.assertTrue(hit)
        self.assertEqual(hit[0]["severity"], "High")

    def test_reflect_without_credentials_is_low(self):
        class H(_CorsHandler):
            reflect_creds = False
        r = self._scan(H)
        ids = _ids(r.findings)
        self.assertIn("DAST-CORS-REFLECT", ids)
        self.assertNotIn("DAST-CORS-REFLECT-CREDS", ids)


# ── Safety: wall-clock budget + coverage truncation ───────────────────────────
class TestBudgetAndTruncation(unittest.TestCase):
    def test_zero_time_budget_truncates(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope, time_budget=0)
        self.assertTrue(result.truncated)
        self.assertIn("DAST-COVERAGE-TRUNCATED", _ids(result.findings))

    def test_page_cap_truncates_with_queue_remaining(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope, max_pages=1)
        # landing links to more in-scope pages than one -> truncated
        self.assertTrue(result.truncated)
        self.assertIn("DAST-COVERAGE-TRUNCATED", _ids(result.findings))

    def test_full_scan_is_not_truncated(self):
        with _VulnServer() as srv:
            scope = config.parse_scope("", config.target_host(srv.base))
            result = engine.scan(srv.base, scope)
        self.assertFalse(result.truncated)
        self.assertNotIn("DAST-COVERAGE-TRUNCATED", _ids(result.findings))


# ── Service: duplicate-scan dedup ─────────────────────────────────────────────
class TestScanDedup(unittest.TestCase):
    def setUp(self):
        from dast import service
        self._orig = config.JOBS_PATH
        self._tmp = tempfile.TemporaryDirectory()
        config.JOBS_PATH = Path(self._tmp.name) / "jobs.json"
        self.svc = service.DastService()

    def tearDown(self):
        config.JOBS_PATH = self._orig
        self._tmp.cleanup()

    def test_redelivery_collapses_onto_inflight_job(self):
        # Seed a running job for target 'app' at sha 'abc'.
        self.svc._jobs["dast_1"] = {"id": "dast_1", "target_id": "app",
                                    "status": "running", "commit": "abc"}
        got = self.svc.submit_scan({"id": "app", "url": "https://a/"},
                                   gh_ctx={"kind": "deployment", "sha": "abc"})
        self.assertEqual(got, "dast_1")           # no new job spawned

    def test_different_sha_starts_new_job(self):
        self.svc._jobs["dast_1"] = {"id": "dast_1", "target_id": "app",
                                    "status": "running", "commit": "abc"}
        # A different sha is distinct work; _find_inflight must not match it.
        self.assertIsNone(self.svc._find_inflight("app", "def"))

    def test_finished_job_does_not_block(self):
        self.svc._jobs["dast_1"] = {"id": "dast_1", "target_id": "app",
                                    "status": "done", "commit": "abc"}
        self.assertIsNone(self.svc._find_inflight("app", "abc"))


class TestBoundedConcurrency(unittest.TestCase):
    """A burst of scans across many DIFFERENT targets must not spawn one
    thread per request — it must respect config.DAST_WORKERS, the same
    bounded-pool guarantee broker.service already gives SAST scans."""

    def setUp(self):
        from dast import service
        self._orig_jobs_path = config.JOBS_PATH
        self._orig_workers = config.DAST_WORKERS
        self._tmp = tempfile.TemporaryDirectory()
        config.JOBS_PATH = Path(self._tmp.name) / "jobs.json"
        config.DAST_WORKERS = 2
        self.svc = service.DastService()

    def tearDown(self):
        config.JOBS_PATH = self._orig_jobs_path
        config.DAST_WORKERS = self._orig_workers
        self._tmp.cleanup()

    def test_concurrent_scans_never_exceed_dast_workers(self):
        import time
        from dast import scanner as dscanner

        state = {"cur": 0, "max": 0}
        guard = threading.Lock()

        def fake_run_scan(target, severity, progress=None):
            with guard:
                state["cur"] += 1
                state["max"] = max(state["max"], state["cur"])
            time.sleep(0.15)
            with guard:
                state["cur"] -= 1
            return [], {"findings_total": 0, "rules_triggered": 0,
                       "severity_counts": {}, "pages_crawled": 0}

        orig_run_scan = dscanner.run_scan
        dscanner.run_scan = fake_run_scan
        self.svc._save_report = lambda report: "rid"
        self.svc._validate_attack_paths = lambda *a, **k: None
        try:
            job_ids = [
                self.svc.submit_scan({"id": f"t{i}", "url": f"https://t{i}.example/"},
                                     gh_ctx={"sha": f"sha-{i}"})
                for i in range(6)
            ]
            deadline = time.time() + 10
            while time.time() < deadline:
                jobs = {j["id"]: j for j in self.svc.list_jobs()}
                if all(jobs.get(j, {}).get("status") in ("done", "error")
                       for j in job_ids):
                    break
                time.sleep(0.05)
        finally:
            dscanner.run_scan = orig_run_scan
        self.assertLessEqual(state["max"], 2,
                             "more concurrent scans ran than DAST_WORKERS allows")
        self.assertGreater(state["max"], 0, "no scan ever ran")


# ── Crawl seeding from robots.txt / sitemap.xml ───────────────────────────────
class _SeedHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def version_string(self):
        return "t"

    def do_GET(self):                          # noqa: N802
        path = urlparse(self.path).path
        if path == "/robots.txt":
            self._send("Disallow: /hidden/\nSitemap: %s/sitemap.xml\n"
                       % self._origin(), ctype="text/plain")
        elif path == "/sitemap.xml":
            self._send('<?xml version="1.0"?><urlset><url><loc>%s/deep</loc>'
                       "</url></urlset>" % self._origin(), ctype="application/xml")
        elif path in ("/", "/hidden/", "/deep"):
            self._send("<html><body>page</body></html>")
        else:
            self.send_response(404)
            self.end_headers()

    def _origin(self):
        return f"http://127.0.0.1:{self.server.server_address[1]}"

    def _send(self, body, ctype="text/html; charset=utf-8"):
        raw = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


class TestCrawlSeeding(unittest.TestCase):
    def test_seeds_from_robots_and_sitemap(self):
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), _SeedHandler)
        port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        try:
            base = f"http://127.0.0.1:{port}/"
            scope = config.parse_scope("", "127.0.0.1")
            fetcher = engine.Fetcher(delay=0)
            seen = {base}
            queue = []
            engine._seed_from_site(base, scope, fetcher, seen, queue)
            joined = " ".join(queue)
            self.assertIn("/hidden/", joined)     # from robots Disallow
            self.assertIn("/deep", joined)         # from sitemap <loc>
        finally:
            httpd.shutdown()
            httpd.server_close()

    def test_out_of_scope_sitemap_url_in_robots_is_never_fetched(self):
        # A `Sitemap:` line in the TARGET's own robots.txt is untrusted input —
        # it must not be fetched unless it's in the scan's own scope, or a
        # scanned app could point it at an internal/metadata address and have
        # the scanner fetch it (SSRF via crawl seeding).
        class _OutOfScopeSitemapHandler(_SeedHandler):
            def do_GET(self):                      # noqa: N802
                path = urlparse(self.path).path
                if path == "/robots.txt":
                    self._send("Sitemap: http://internal.example.invalid/sitemap.xml\n",
                              ctype="text/plain")
                elif path in ("/",):
                    self._send("<html><body>page</body></html>")
                else:
                    self.send_response(404)
                    self.end_headers()

        httpd = ThreadingHTTPServer(("127.0.0.1", 0), _OutOfScopeSitemapHandler)
        port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        try:
            base = f"http://127.0.0.1:{port}/"
            scope = config.parse_scope("", "127.0.0.1")
            fetcher = engine.Fetcher(delay=0)
            seen = {base}
            queue = []
            fetched = []
            real_get = fetcher.get
            def _tracking_get(url):
                fetched.append(url)
                return real_get(url)
            fetcher.get = _tracking_get
            engine._seed_from_site(base, scope, fetcher, seen, queue)
            self.assertFalse(
                any("internal.example.invalid" in u for u in fetched),
                f"out-of-scope sitemap URL was fetched: {fetched}")
        finally:
            httpd.shutdown()
            httpd.server_close()


# ── Injection probes (SQLi / traversal / SSTI / command injection) ────────────
class TestInjectionChecks(unittest.TestCase):
    def _scan(self, name):
        from dast.benchmark import harness
        with harness._Server() as srv:
            scope = config.parse_scope("", "127.0.0.1")
            return engine.scan(f"{srv.base}{name}/", scope,
                               severity_threshold="Info")

    def test_error_based_sqli(self):
        ids = _ids(self._scan("sqli").findings)
        self.assertIn("DAST-SQLI", ids)

    def test_path_traversal(self):
        ids = _ids(self._scan("traversal").findings)
        self.assertIn("DAST-PATH-TRAVERSAL", ids)

    def test_ssti(self):
        ids = _ids(self._scan("ssti").findings)
        self.assertIn("DAST-SSTI", ids)

    def test_command_injection(self):
        ids = _ids(self._scan("cmdi").findings)
        self.assertIn("DAST-CMD-INJECTION", ids)

    def test_client_side_open_redirect(self):
        ids = _ids(self._scan("redirect_meta").findings)
        self.assertIn("DAST-OPEN-REDIRECT", ids)

    def test_injection_safe_app_has_no_false_positives(self):
        ids = _ids(self._scan("inj_safe").findings)
        for rule in ("DAST-SQLI", "DAST-PATH-TRAVERSAL", "DAST-SSTI",
                     "DAST-CMD-INJECTION", "DAST-XSS-REFLECTED"):
            self.assertNotIn(rule, ids, f"false positive: {rule}")

    def test_injection_checks_can_be_disabled(self):
        orig = config.INJECTION_CHECKS
        config.INJECTION_CHECKS = False
        try:
            ids = _ids(self._scan("sqli").findings)
            self.assertNotIn("DAST-SQLI", ids)
        finally:
            config.INJECTION_CHECKS = orig


# ── Measured-accuracy benchmark as a regression guard ─────────────────────────
class TestBenchmark(unittest.TestCase):
    def test_corpus_is_100pct_recall_zero_false_positives(self):
        from dast.benchmark import harness
        r = harness.run()
        self.assertEqual(r["fn"], 0, f"missed findings: {r['cases']}")
        self.assertEqual(r["fp"], 0, f"false positives: {r['cases']}")
        self.assertEqual(r["recall"], 1.0)
        self.assertEqual(r["precision"], 1.0)


if __name__ == "__main__":
    unittest.main()
