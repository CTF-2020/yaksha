"""Signature catalog for the AI-BOM engine.

Everything the engine detects is declared here so coverage can be reviewed and
extended without touching scan logic: known AI packages (PyPI / npm / Go), model
identifier grammars, provider API endpoints, credential env-var names, hardcoded
key formats, model artifact extensions, and the risk-rule metadata used to turn
raw signals into report findings (mapped to OWASP LLM Top 10 2025 + CWE).
"""
from __future__ import annotations

import re

# ── Package catalogs ──────────────────────────────────────────────────────────
# name (as it appears in the manifest, lowercase) -> (provider/display, category)
# Categories: provider-sdk, framework, agent-framework, vector-db,
#             local-inference, ml-runtime, tokenizer, mcp, guardrails, evaluation
PY_PACKAGES: dict[str, tuple[str, str]] = {
    # Provider SDKs
    "anthropic": ("Anthropic", "provider-sdk"),
    "openai": ("OpenAI", "provider-sdk"),
    "google-generativeai": ("Google Gemini", "provider-sdk"),
    "google-genai": ("Google Gemini", "provider-sdk"),
    "google-cloud-aiplatform": ("Google Vertex AI", "provider-sdk"),
    "cohere": ("Cohere", "provider-sdk"),
    "mistralai": ("Mistral AI", "provider-sdk"),
    "groq": ("Groq", "provider-sdk"),
    "together": ("Together AI", "provider-sdk"),
    "replicate": ("Replicate", "provider-sdk"),
    "huggingface-hub": ("Hugging Face", "provider-sdk"),
    "litellm": ("LiteLLM (multi-provider router)", "provider-sdk"),
    "boto3-bedrock": ("AWS Bedrock", "provider-sdk"),   # synthetic; detected via code
    # Orchestration frameworks
    "langchain": ("LangChain", "framework"),
    "langchain-core": ("LangChain", "framework"),
    "langchain-community": ("LangChain", "framework"),
    "langchain-openai": ("LangChain", "framework"),
    "langchain-anthropic": ("LangChain", "framework"),
    "langgraph": ("LangGraph", "agent-framework"),
    "llama-index": ("LlamaIndex", "framework"),
    "llama-index-core": ("LlamaIndex", "framework"),
    "haystack-ai": ("Haystack", "framework"),
    "farm-haystack": ("Haystack", "framework"),
    "semantic-kernel": ("Semantic Kernel", "framework"),
    "dspy": ("DSPy", "framework"),
    "dspy-ai": ("DSPy", "framework"),
    "guidance": ("Guidance", "framework"),
    "instructor": ("Instructor", "framework"),
    "haystack": ("Haystack", "framework"),
    # Agent frameworks
    "pydantic-ai": ("Pydantic AI", "agent-framework"),
    "smolagents": ("smolagents", "agent-framework"),
    "autogen": ("AutoGen", "agent-framework"),
    "pyautogen": ("AutoGen", "agent-framework"),
    "ag2": ("AG2 (AutoGen)", "agent-framework"),
    "crewai": ("CrewAI", "agent-framework"),
    "openai-agents": ("OpenAI Agents SDK", "agent-framework"),
    # Vector stores / RAG
    "chromadb": ("Chroma", "vector-db"),
    "pinecone": ("Pinecone", "vector-db"),
    "pinecone-client": ("Pinecone", "vector-db"),
    "qdrant-client": ("Qdrant", "vector-db"),
    "weaviate-client": ("Weaviate", "vector-db"),
    "faiss-cpu": ("FAISS", "vector-db"),
    "faiss-gpu": ("FAISS", "vector-db"),
    "pymilvus": ("Milvus", "vector-db"),
    "lancedb": ("LanceDB", "vector-db"),
    "pgvector": ("pgvector", "vector-db"),
    # Local inference / ML runtimes
    "ollama": ("Ollama", "local-inference"),
    "llama-cpp-python": ("llama.cpp", "local-inference"),
    "vllm": ("vLLM", "local-inference"),
    "transformers": ("Hugging Face Transformers", "local-inference"),
    "sentence-transformers": ("Sentence Transformers", "local-inference"),
    "diffusers": ("Hugging Face Diffusers", "local-inference"),
    "onnxruntime": ("ONNX Runtime", "ml-runtime"),
    "torch": ("PyTorch", "ml-runtime"),
    "tensorflow": ("TensorFlow", "ml-runtime"),
    "keras": ("Keras", "ml-runtime"),
    # Tokenizers
    "tiktoken": ("OpenAI tiktoken", "tokenizer"),
    "tokenizers": ("Hugging Face Tokenizers", "tokenizer"),
    # MCP
    "mcp": ("Model Context Protocol", "mcp"),
    "fastmcp": ("FastMCP", "mcp"),
    # Guardrails / evaluation
    "guardrails-ai": ("Guardrails AI", "guardrails"),
    "nemoguardrails": ("NVIDIA NeMo Guardrails", "guardrails"),
    "llm-guard": ("LLM Guard", "guardrails"),
    "rebuff": ("Rebuff", "guardrails"),
    "ragas": ("Ragas", "evaluation"),
    "deepeval": ("DeepEval", "evaluation"),
}

# Dotted / renamed python import prefixes that don't normalize to a package name
# by simply swapping underscores for hyphens.
PY_IMPORT_ALIASES: dict[str, str] = {
    "google.generativeai": "google-generativeai",
    "google.genai": "google-genai",
    "vertexai": "google-cloud-aiplatform",
    "llama_index": "llama-index",
    "llama_cpp": "llama-cpp-python",
    "guardrails": "guardrails-ai",
    "qdrant_client": "qdrant-client",
    "weaviate": "weaviate-client",
    "faiss": "faiss-cpu",
    "haystack": "haystack-ai",
    "agents": "openai-agents",
}

NPM_PACKAGES: dict[str, tuple[str, str]] = {
    "@anthropic-ai/sdk": ("Anthropic", "provider-sdk"),
    "openai": ("OpenAI", "provider-sdk"),
    "@google/generative-ai": ("Google Gemini", "provider-sdk"),
    "@google/genai": ("Google Gemini", "provider-sdk"),
    "cohere-ai": ("Cohere", "provider-sdk"),
    "@mistralai/mistralai": ("Mistral AI", "provider-sdk"),
    "groq-sdk": ("Groq", "provider-sdk"),
    "together-ai": ("Together AI", "provider-sdk"),
    "replicate": ("Replicate", "provider-sdk"),
    "@huggingface/inference": ("Hugging Face", "provider-sdk"),
    "ai": ("Vercel AI SDK", "framework"),
    "langchain": ("LangChain", "framework"),
    "llamaindex": ("LlamaIndex", "framework"),
    "ollama": ("Ollama", "local-inference"),
    "@modelcontextprotocol/sdk": ("Model Context Protocol", "mcp"),
    "chromadb": ("Chroma", "vector-db"),
    "@pinecone-database/pinecone": ("Pinecone", "vector-db"),
    "@qdrant/js-client-rest": ("Qdrant", "vector-db"),
    "weaviate-ts-client": ("Weaviate", "vector-db"),
    "@xenova/transformers": ("Transformers.js", "local-inference"),
    "onnxruntime-node": ("ONNX Runtime", "ml-runtime"),
    "@tensorflow/tfjs": ("TensorFlow.js", "ml-runtime"),
}
# npm scope prefixes matched when the exact name isn't in the catalog.
NPM_PREFIXES: dict[str, tuple[str, str]] = {
    "@langchain/": ("LangChain", "framework"),
    "@ai-sdk/": ("Vercel AI SDK", "framework"),
    "@llamaindex/": ("LlamaIndex", "framework"),
}

GO_MODULES: dict[str, tuple[str, str]] = {
    "github.com/anthropics/anthropic-sdk-go": ("Anthropic", "provider-sdk"),
    "github.com/openai/openai-go": ("OpenAI", "provider-sdk"),
    "github.com/sashabaranov/go-openai": ("OpenAI", "provider-sdk"),
    "github.com/google/generative-ai-go": ("Google Gemini", "provider-sdk"),
    "github.com/tmc/langchaingo": ("LangChainGo", "framework"),
    "github.com/ollama/ollama": ("Ollama", "local-inference"),
    "github.com/mark3labs/mcp-go": ("Model Context Protocol", "mcp"),
}

# ── Model identifiers ─────────────────────────────────────────────────────────
# Only fires on quoted string literals to keep prose/docs from matching.
MODEL_RE = re.compile(
    r"""["'`](?P<model>
        (?:anthropic\.|us\.anthropic\.)?claude-[a-z0-9][\w.:-]*
        | gpt-[0-9o][\w.-]* | chatgpt-[\w.-]+ | o[134](?:-mini|-preview|-pro)[\w.-]*
        | text-embedding-[\w.-]+ | text-davinci-[\w.-]+ | dall-e-[23] | whisper-1
        | gemini-[\w.-]+ | (?:meta\.)?llama-?[234][\w.:-]* | mistral-(?:large|medium|small|tiny|nemo|embed)[\w.-]*
        | mixtral-[\w.-]+ | command-r[\w.-]* | amazon\.titan-[\w.:-]+
        | deepseek-(?:chat|coder|reasoner|r1|v[23])[\w.-]* | qwen[23][\w.:-]* | phi-[34][\w.-]*
        | grok-[\w.-]+ | sonar(?:-pro|-reasoning)?[\w.-]*
        | nomic-embed-text[\w.-]* | all-minilm[\w.-]* | bge-(?:small|base|large|m3)[\w.-]* | e5-(?:small|base|large)[\w.-]*
    )["'`]""",
    re.IGNORECASE | re.VERBOSE,
)

# prefix (lowercase) -> provider, first match wins.
MODEL_PROVIDER_PREFIXES: list[tuple[str, str]] = [
    ("anthropic.claude", "AWS Bedrock (Anthropic)"),
    ("us.anthropic.claude", "AWS Bedrock (Anthropic)"),
    ("claude", "Anthropic"),
    ("gpt", "OpenAI"), ("chatgpt", "OpenAI"), ("o1", "OpenAI"), ("o3", "OpenAI"),
    ("o4", "OpenAI"), ("text-embedding", "OpenAI"), ("text-davinci", "OpenAI"),
    ("dall-e", "OpenAI"), ("whisper", "OpenAI"),
    ("gemini", "Google"),
    ("meta.llama", "AWS Bedrock (Meta)"), ("llama", "Meta"),
    ("mistral", "Mistral AI"), ("mixtral", "Mistral AI"),
    ("command", "Cohere"),
    ("amazon.titan", "AWS Bedrock (Amazon)"),
    ("deepseek", "DeepSeek"), ("qwen", "Alibaba"), ("phi-", "Microsoft"),
    ("grok", "xAI"), ("sonar", "Perplexity"),
    ("nomic-embed", "Nomic"), ("all-minilm", "Sentence Transformers"),
    ("bge-", "BAAI"), ("e5-", "Microsoft"),
]

# ── Provider API endpoints ────────────────────────────────────────────────────
ENDPOINTS: dict[str, str] = {
    "api.openai.com": "OpenAI",
    "api.anthropic.com": "Anthropic",
    "generativelanguage.googleapis.com": "Google Gemini",
    "aiplatform.googleapis.com": "Google Vertex AI",
    "bedrock-runtime": "AWS Bedrock",
    "openai.azure.com": "Azure OpenAI",
    "api.cohere.com": "Cohere",
    "api.cohere.ai": "Cohere",
    "api.mistral.ai": "Mistral AI",
    "api.groq.com": "Groq",
    "openrouter.ai": "OpenRouter",
    "api.together.xyz": "Together AI",
    "api.replicate.com": "Replicate",
    "api-inference.huggingface.co": "Hugging Face",
    "api.deepseek.com": "DeepSeek",
    "api.perplexity.ai": "Perplexity",
    "api.x.ai": "xAI",
    "localhost:11434": "Ollama (local)",
    "127.0.0.1:11434": "Ollama (local)",
}
ENDPOINT_RE = re.compile("|".join(re.escape(h) for h in ENDPOINTS), re.IGNORECASE)

# ── Credential environment variables (references are inventory, not findings) ─
ENV_KEYS: dict[str, str] = {
    "OPENAI_API_KEY": "OpenAI", "AZURE_OPENAI_API_KEY": "Azure OpenAI",
    "AZURE_OPENAI_ENDPOINT": "Azure OpenAI", "ANTHROPIC_API_KEY": "Anthropic",
    "GOOGLE_API_KEY": "Google", "GEMINI_API_KEY": "Google Gemini",
    "COHERE_API_KEY": "Cohere", "MISTRAL_API_KEY": "Mistral AI",
    "GROQ_API_KEY": "Groq", "HF_TOKEN": "Hugging Face",
    "HUGGINGFACEHUB_API_TOKEN": "Hugging Face", "HUGGING_FACE_HUB_TOKEN": "Hugging Face",
    "TOGETHER_API_KEY": "Together AI", "OPENROUTER_API_KEY": "OpenRouter",
    "REPLICATE_API_TOKEN": "Replicate", "PERPLEXITY_API_KEY": "Perplexity",
    "XAI_API_KEY": "xAI", "DEEPSEEK_API_KEY": "DeepSeek",
}
ENV_KEY_RE = re.compile(r"\b(" + "|".join(ENV_KEYS) + r")\b")

# ── Hardcoded credential formats (findings; evaluated in order, first wins) ───
KEY_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("Anthropic", re.compile(r"sk-ant-[A-Za-z0-9_-]{24,}")),
    ("OpenRouter", re.compile(r"sk-or-[A-Za-z0-9_-]{24,}")),
    ("OpenAI", re.compile(r"sk-(?:proj|svcacct)-[A-Za-z0-9_-]{24,}")),
    ("OpenAI", re.compile(r"sk-[A-Za-z0-9]{40,}")),
    ("Google", re.compile(r"AIza[0-9A-Za-z_-]{35}")),
    ("Hugging Face", re.compile(r"hf_[A-Za-z0-9]{30,}")),
    ("Groq", re.compile(r"gsk_[A-Za-z0-9]{40,}")),
    ("Replicate", re.compile(r"r8_[A-Za-z0-9]{30,}")),
]

# ── Model artifact files ──────────────────────────────────────────────────────
ARTIFACT_EXTS: dict[str, str] = {
    ".gguf": "GGUF", ".ggml": "GGML", ".safetensors": "SafeTensors",
    ".onnx": "ONNX", ".pt": "PyTorch", ".pth": "PyTorch", ".tflite": "TFLite",
    ".h5": "Keras H5", ".mlmodel": "Core ML",
}
PICKLE_EXTS = {".pkl", ".pickle", ".joblib"}

# ── Behavioral signal regexes ────────────────────────────────────────────────
LLM_CALL_RE = re.compile(
    r"(?:\.chat\.completions\.create|\.messages\.create|\.responses\.create"
    r"|generate_content|ChatCompletion|\.beta\.threads|ollama\.chat"
    r"|invoke_model|converse\s*\(|streamText\s*\(|generateText\s*\()")
EXEC_SINK_RE = re.compile(
    r"(?:\beval\s*\(|\bexec\s*\(|os\.system\s*\(|subprocess\.(?:run|Popen|call|check_output)"
    r"|child_process|execSync\s*\(|\bspawnSync\s*\()")
TOOL_DEF_RE = re.compile(
    r"(?:@tool\b|@mcp\.tool|tools\s*=\s*\[|[\"']type[\"']\s*:\s*[\"']function[\"']"
    r"|tool_choice|function_call(?:ing)?|StructuredTool|input_schema\s*[=:])")
MCP_RE = re.compile(
    r"(?:modelcontextprotocol|FastMCP\s*\(|mcp\.server|from\s+mcp\b|@mcp\.tool)")
RAG_RE = re.compile(
    r"(?:as_retriever|similarity_search|vector_?store|VectorStoreIndex"
    r"|RetrievalQA|\.embed_documents|create_retrieval_chain)", re.IGNORECASE)
FROM_PRETRAINED_RE = re.compile(r"\bfrom_pretrained\s*\(")
LATEST_MODEL_RE = re.compile(r"""["'`][\w.]*[\w-]+-latest["'`]""")
# Untrusted request/CLI data flowing into something named prompt/message-ish.
PROMPT_TAINT_RES = [
    re.compile(r"(?i)(?:prompt|message|instruction|query)\w*\s*(?:\+?=)\s*.*"
               r"(?:request\.(?:args|form|json|values|get_json)|req\.(?:body|query|params)"
               r"|input\s*\(|sys\.argv|params\[)"),
    re.compile(r"(?i)(?:prompt|messages?)\w*\s*=\s*f[\"'].*\{[^}]*"
               r"(?:request\.|req\.|user_input|argv)"),
]

# ── Risk-rule metadata ────────────────────────────────────────────────────────
RULES: dict[str, dict] = {
    "AIBOM-KEY-001": {
        "title": "Hardcoded AI provider API key in source",
        "severity": "Critical", "owasp": "A07:2021 Identification & Auth Failures",
        "cwe": "CWE-798",
        "remediation": "Revoke and rotate the key immediately, then load it from a "
                       "secrets manager or environment variable. Purge it from git "
                       "history (filter-repo/BFG) — deleting the line is not enough.",
    },
    "AIBOM-KEY-002": {
        "title": "AI provider API key committed in a dotenv/config file",
        "severity": "High", "owasp": "A07:2021 Identification & Auth Failures",
        "cwe": "CWE-798",
        "remediation": "Rotate the key and remove the file from version control "
                       "(.gitignore the .env, commit a .env.example with blank values).",
    },
    "AIBOM-INJ-001": {
        "title": "Untrusted input flows into an LLM prompt",
        "severity": "Medium", "owasp": "LLM01:2025 Prompt Injection", "cwe": "CWE-1427",
        "remediation": "Treat user/request data placed in prompts as untrusted: "
                       "separate system vs user roles, constrain output format, and "
                       "validate/limit what downstream actions the response can drive.",
    },
    "AIBOM-OUT-001": {
        "title": "LLM output may reach a code/command execution sink",
        "severity": "High", "owasp": "LLM05:2025 Improper Output Handling", "cwe": "CWE-94",
        "remediation": "Never eval/exec model output or pass it to a shell. Parse it "
                       "as data (JSON schema validation) and allow-list the operations "
                       "it can trigger.",
    },
    "AIBOM-AGY-001": {
        "title": "Agent tool exposes shell/system execution",
        "severity": "High", "owasp": "LLM06:2025 Excessive Agency", "cwe": "CWE-78",
        "remediation": "Scope agent tools to the minimum operations required; replace "
                       "generic shell tools with parameterized, allow-listed actions "
                       "and require human approval for destructive ones.",
    },
    "AIBOM-SUP-001": {
        "title": "Pickle-format model artifact committed to the repo",
        "severity": "Medium", "owasp": "LLM03:2025 Supply Chain", "cwe": "CWE-502",
        "remediation": "Pickle files execute arbitrary code on load. Convert model "
                       "weights to SafeTensors/ONNX, or verify provenance and load "
                       "with a restricted unpickler.",
    },
    "AIBOM-SUP-002": {
        "title": "AI dependency declared without a version pin",
        "severity": "Low", "owasp": "LLM03:2025 Supply Chain", "cwe": "CWE-1104",
        "remediation": "Pin AI SDKs and frameworks to exact versions (or use a lock "
                       "file) so a compromised or breaking upstream release cannot "
                       "flow into a build unreviewed.",
    },
    "AIBOM-SUP-003": {
        "title": "Hub model loaded without a pinned revision",
        "severity": "Medium", "owasp": "LLM03:2025 Supply Chain", "cwe": "CWE-494",
        "remediation": "Pass revision=<commit-sha> to from_pretrained so the exact "
                       "weights are pinned; hub repos are mutable and can be "
                       "backdoored after you first adopt them.",
    },
    "AIBOM-MOD-001": {
        "title": "Floating '-latest' model alias in use",
        "severity": "Low", "owasp": "LLM03:2025 Supply Chain", "cwe": "CWE-1104",
        "remediation": "Reference a dated/versioned model id so behavior, cost, and "
                       "safety characteristics don't change silently under you.",
    },
    "AIBOM-MCP-001": {
        "title": "Model Context Protocol integration present",
        "severity": "Info", "owasp": "LLM06:2025 Excessive Agency", "cwe": "",
        "remediation": "Inventory item: review each MCP server's tool surface, "
                       "authentication, and whether untrusted content can reach it.",
    },
    "AIBOM-RAG-001": {
        "title": "RAG / vector-retrieval surface present",
        "severity": "Info", "owasp": "LLM08:2025 Vector & Embedding Weaknesses", "cwe": "",
        "remediation": "Inventory item: retrieved documents are an indirect prompt-"
                       "injection channel — review what enters the index and how "
                       "retrieved text is framed in prompts.",
    },
    "AIBOM-AGN-001": {
        "title": "Agentic framework in use",
        "severity": "Info", "owasp": "LLM06:2025 Excessive Agency", "cwe": "",
        "remediation": "Inventory item: enumerate the agent's tools and privileges; "
                       "apply least-agency and human-in-the-loop for consequential "
                       "actions.",
    },
}

SEVERITIES = ("Critical", "High", "Medium", "Low", "Info")
