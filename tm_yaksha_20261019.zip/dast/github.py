"""GitHub CI release-gate integration for the DAST scanner.

Where the SAST broker scans code on a push/PR, DAST scans a *running* application
— so its natural CI trigger is a successful deployment. This module bridges
GitHub `deployment_status` (and, optionally, a push to a configured deploy
branch) to the DAST scan/report pipeline, then reports the verdict back onto the
deployment/commit so a pipeline can gate promotion to production on it.

A deliberate safety property: the webhook only ever *selects which registered
target to scan*. The URL that gets probed always comes from the trusted target
registry, never from the webhook payload (a `deployment_status.environment_url`
is attacker-influenceable and is intentionally ignored). This preserves the
"registered targets only — registering asserts authorization" invariant.

Dependency-free (urllib) like the rest of the app. Generic pieces — HMAC
verification, the REST client, the severity gate — are reused from broker.github
so the two scanners share one hardened implementation.
"""
from __future__ import annotations

import re

# Reuse the broker's hardened, scanner-agnostic GitHub primitives verbatim.
from broker.github import (  # noqa: F401
    GitHubClient,
    GitHubError,
    gate_passes,
    verify_signature,
)

from . import config

_COMMENT_MARKER = "<!-- yaksha-guard-dast -->"
_COMMIT_CONTEXT = "yaksha-guard/dast"
_CHECK_NAME = "Yaksha Guard DAST"
_DEPLOY_STATES_OK = {"success"}
_HTTP_TIMEOUT = 30


# ── Webhook parsing ───────────────────────────────────────────────────────────
def parse_webhook(event: str, payload: dict) -> dict:
    """Normalise a raw webhook into {kind, full_name, sha, environment, ...}.

    kind is one of: ping | deployment | push | ignored. Only a successful
    deployment (or a push to a configured deploy branch, handled by the caller)
    returns an actionable sha; everything else is "ignored" with a reason so the
    endpoint can 200 without doing work.
    """
    payload = payload or {}
    repo = payload.get("repository") or {}
    full_name = (repo.get("full_name") or "").strip()

    if event == "ping":
        return {"kind": "ping", "full_name": full_name, "reason": "pong",
                "sha": None, "environment": None, "deployment_id": None,
                "branch": None}

    if event == "deployment_status":
        status = payload.get("deployment_status") or {}
        deployment = payload.get("deployment") or {}
        state = (status.get("state") or "").lower()
        if state not in _DEPLOY_STATES_OK:
            return _ignored(full_name, f"deployment_status state {state!r}")
        sha = deployment.get("sha") or ""
        if not sha:
            return _ignored(full_name, "deployment missing sha")
        environment = (status.get("environment") or deployment.get("environment")
                       or "")
        return {"kind": "deployment", "full_name": full_name, "sha": sha,
                "environment": environment,
                "deployment_id": deployment.get("id"), "branch": None}

    if event == "push":
        ref = payload.get("ref") or ""
        sha = payload.get("after") or ""
        if payload.get("deleted") or set(sha) <= {"0"}:
            return _ignored(full_name, "branch deletion / no commit")
        if not ref.startswith("refs/heads/"):
            return _ignored(full_name, f"non-branch ref {ref!r}")
        branch = ref.split("/", 2)[-1]
        # The caller decides whether this branch matches the target's
        # deploy_branch; parsing just surfaces the branch + sha.
        return {"kind": "push", "full_name": full_name, "sha": sha,
                "environment": None, "deployment_id": None, "branch": branch}

    return _ignored(full_name, f"unhandled event {event!r}")


def _ignored(full_name: str, reason: str) -> dict:
    return {"kind": "ignored", "full_name": full_name, "reason": reason,
            "sha": None, "environment": None, "deployment_id": None,
            "branch": None}


# ── Rendering helpers ─────────────────────────────────────────────────────────
def _md(text) -> str:
    """Neutralise markdown/HTML control chars in untrusted strings."""
    return re.sub(r"[`<>|*_\[\]\r\n]", " ", str(text))


def _status_line(report: dict) -> str:
    meta = report.get("scan_metadata") or {}
    counts = meta.get("severity_counts", {})
    parts = [f"{counts[s]} {s}" for s in config.SEVERITIES if counts.get(s)]
    total = meta.get("findings_total", 0)
    return f"{total} finding(s): " + (", ".join(parts) if parts else "none")


def build_check_output(report: dict | None, error: str | None, passed: bool,
                       fail_on: str, environment: str, report_url: str) -> dict:
    """Build the check-run `output` block (title + markdown summary).

    DAST findings are URLs, not repo file:line locations, so — unlike the SAST
    check run — there are no inline diff annotations; the summary carries the
    findings breakdown and a link to the full report instead.
    """
    if error or report is None:
        return {"title": "Scan failed",
                "summary": f"The DAST scan could not complete: {_md(error or 'unknown error')}"}
    meta = report.get("scan_metadata") or {}
    counts = meta.get("severity_counts", {})
    verdict = ("✅ Passed" if passed else "❌ Failed") + f" — gate `{_md(fail_on)}`"
    rows = "\n".join(f"| {s} | {counts.get(s, 0)} |"
                     for s in config.SEVERITIES if counts.get(s)) or "| _none_ | 0 |"
    top = sorted(report.get("categories", []),
                 key=lambda c: config.SEVERITY_ORDER.get(c.get("risk", "Info"), 99))[:8]
    findings_md = "\n".join(
        f"- **{_md(c.get('risk', '?'))}** · {_md(c.get('title', c.get('id', '?')))}"
        f" ({len(c.get('threats', []))} location(s))" for c in top
    ) or "_No findings at the selected threshold._"
    env_line = f"\nEnvironment: `{_md(environment)}`." if environment else ""
    link = f"\n\n[View the full report →]({report_url})" if report_url else ""
    crawl = f"Crawled {meta.get('pages_crawled', 0)} page(s), {meta.get('requests_made', 0)} request(s)."
    return {
        "title": verdict,
        "summary": (f"{_md(_status_line(report))}{env_line}\n\n{crawl}\n\n"
                    f"| Severity | Count |\n|---|---|\n{rows}\n\n"
                    f"**Top findings**\n{findings_md}{link}"),
    }


def build_comment(report: dict, report_url: str, passed: bool, fail_on: str,
                  environment: str = "") -> str:
    """Render a findings comment (used if the deployment references a PR)."""
    meta = report.get("scan_metadata") or {}
    counts = meta.get("severity_counts", {})
    verdict = ("✅ **Passed** — no findings at or above "
               f"`{fail_on}`." if passed else
               f"❌ **Failed** — findings at or above `{fail_on}` present.")
    rows = "\n".join(f"| {s} | {counts.get(s, 0)} |"
                     for s in config.SEVERITIES if counts.get(s)) or "| _none_ | 0 |"
    env_line = f"\nEnvironment: `{_md(environment)}`" if environment else ""
    link = f"\n\n[View the full report →]({report_url})" if report_url else ""
    return (
        f"{_COMMENT_MARKER}\n## 🛡️ Yaksha Guard — DAST\n\n{verdict}\n"
        f"{_md(_status_line(report))}{env_line}\n\n"
        f"| Severity | Count |\n|---|---|\n{rows}{link}\n\n"
        f"<sub>Dynamic analysis by Yaksha Guard DAST · gate `{_md(fail_on)}`.</sub>"
    )


def _conclusion(report: dict | None, error: str | None, passed: bool) -> str:
    if error or report is None:
        return "failure"
    return "success" if passed else "failure"


# ── Deployment status post-back (DAST-specific GitHub call) ────────────────────
def _create_deployment_status(client: "GitHubClient", full_name: str,
                              deployment_id, state: str, description: str,
                              log_url: str = "", environment_url: str = "") -> dict:
    """POST a deployment status so the deploy itself shows the scan verdict.

    Not part of broker.github (SAST never touches deployments); implemented here
    against the same minimal client. GitHub deployment states include success /
    failure / error, which map cleanly onto a pass/fail gate.
    """
    body = {"state": state, "description": description[:140]}
    if log_url:
        body["log_url"] = log_url
    if environment_url:
        body["environment_url"] = environment_url
    return client._request(
        "POST", f"/repos/{full_name}/deployments/{deployment_id}/statuses", body)


# ── Orchestration: post a finished scan back to the deployment/commit ──────────
def report_to_github(target: dict, gh_ctx: dict, report: dict | None,
                     report_id: str | None, error: str | None,
                     log=lambda m: None) -> None:
    """Post a finished DAST scan back to GitHub as a deployment gate signal.

    Emits, best-effort: (1) a Check Run (auto mode) or commit Status (fallback,
    e.g. a classic PAT without checks:write) keyed by the deployment sha, and
    (2) a deployment status on the originating deployment when there is one. Any
    GitHub failure is logged and swallowed so reporting never fails the scan job.
    """
    token = target.get("github_token") or config.GITHUB_TOKEN
    if not token:
        log("GitHub reporting skipped: no token configured")
        return
    full_name = (gh_ctx.get("full_name")
                 or config.github_full_name_from_url(target.get("repo_url", "")))
    sha = gh_ctx.get("sha")
    if not full_name or not sha:
        log("GitHub reporting skipped: missing repo/sha context")
        return

    client = GitHubClient(token)
    public = (gh_ctx.get("public_url") or config.PUBLIC_URL or "").rstrip("/")
    report_url = f"{public}/#report={report_id}" if (public and report_id) else ""
    fail_on = target.get("fail_on") or config.GITHUB_FAIL_ON
    environment = gh_ctx.get("environment") or ""
    passed = bool(report is not None and not error and gate_passes(report, fail_on))
    conclusion = _conclusion(report, error, passed)

    # ── Commit-level signal: Check Run (preferred) or commit Status (fallback) ──
    mode = config.checks_mode()
    signalled = False
    if mode != "off":
        try:
            output = build_check_output(report, error, passed, fail_on,
                                        environment, report_url)
            client.create_check_run(
                full_name, sha, status="completed", conclusion=conclusion,
                output=output, details_url=report_url,
                completed_at=config.now_iso())
            log(f"GitHub check run created: {conclusion}")
            signalled = True
        except GitHubError as exc:
            if mode == "force":
                log(f"GitHub check run failed (forced, no fallback): {exc}")
                signalled = True
            else:
                log(f"Check run unavailable, using commit status: {_short(exc)}")
    if not signalled:
        try:
            state = "error" if (error or report is None) else (
                "success" if passed else "failure")
            desc = (f"Scan failed: {error or 'unknown error'}"
                    if state == "error" else _status_line(report))
            client.set_commit_status(full_name, sha, state, desc, report_url)
            log(f"GitHub commit status set: {state}")
        except GitHubError as exc:
            log(f"GitHub commit status error: {exc}")

    # ── Deployment status: let the deploy itself carry the gate verdict ─────────
    if gh_ctx.get("deployment_id") is not None:
        try:
            state = "success" if (report is not None and not error and passed) else "failure"
            desc = (_status_line(report) if report is not None
                    else f"Scan failed: {error or 'unknown error'}")
            _create_deployment_status(
                client, full_name, gh_ctx["deployment_id"], state, desc,
                log_url=report_url)
            log(f"GitHub deployment status set: {state}")
        except GitHubError as exc:
            log(f"GitHub deployment status error: {_short(exc)}")


def _short(exc) -> str:
    return str(exc).splitlines()[0][:160] if str(exc) else exc.__class__.__name__
