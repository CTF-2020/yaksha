"""AST-based extraction of security-relevant facts from a Python file.

This is the deep, framework-aware path. For each file we parse the AST once and
collect, per function: the sinks it contains, the local functions it calls, the
controls on it, and whether it is a route handler. The orchestrator
(:mod:`codemodel.extractor`) then joins these across files — resolving which
sinks are *reachable from* each entry point through the call graph, and linking
Django URL patterns to their view functions.

Framework coverage is intentionally decorator/signature driven so it degrades
gracefully: an unknown framework still yields sinks, stores and secrets even if
its routes are not recognised.
"""
from __future__ import annotations

import ast

from . import signatures as sig
from .model import (
    HIGH, LOW, MEDIUM, Control, DataStore, DependencyUse, ExternalCall, Secret, Sink,
)


class FunctionInfo:
    """What we learned about a single function definition."""

    def __init__(self, name: str, lineno: int):
        self.name = name
        self.lineno = lineno
        self.sinks: list[Sink] = []
        self.dep_calls: list[DependencyUse] = []
        self.calls: set[str] = set()        # names of locally-called functions
        self.controls: list[Control] = []   # from decorators / signature
        self.is_route = False
        self.route_method = "*"
        self.route_path = ""
        self.framework = ""
        self.params: set[str] = set()
        self.is_agent_tool = False
        self.tool_name = ""
        # Set by extractor.py when the cross-file call graph (fn_map) is
        # assembled — the file this function is defined in, for business-
        # impact call-graph proximity matching (see extractor.py:_impact_text).
        self.file = ""


class FileFacts:
    def __init__(self, rel_path: str):
        self.rel_path = rel_path
        self.functions: dict[str, FunctionInfo] = {}
        self.global_controls: list[Control] = []
        self.external_calls: list[ExternalCall] = []
        self.data_stores: list[DataStore] = []
        self.secrets: list[Secret] = []
        self.django_urls: list[dict] = []   # {method,path,view,line}
        self.cbv_controls: dict[str, list[Control]] = {}   # class view name -> controls
        self.frameworks: set[str] = set()
        # locally-bound identifier -> resolved top-level import root, e.g.
        # {"yaml": "yaml", "y": "yaml", "load": "yaml"} for `import yaml`,
        # `import yaml as y`, `from yaml import load` respectively.
        self.import_map: dict[str, str] = {}


# ── helpers ───────────────────────────────────────────────────────────────────
def _attr_chain(node) -> str:
    """Return a dotted name for Name/Attribute/Call nodes: ``a.b.c``."""
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    return ".".join(reversed(parts))


def _last_attr(node) -> str:
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Name):
        return node.id
    return ""


def _root_name(node) -> str:
    while isinstance(node, ast.Attribute):
        node = node.value
    return node.id if isinstance(node, ast.Name) else ""


def _str_arg(call, index=0):
    if len(call.args) > index and isinstance(call.args[index], ast.Constant) \
            and isinstance(call.args[index].value, str):
        return call.args[index].value
    return ""


def _names_in(node) -> set:
    return {n.id for n in ast.walk(node) if isinstance(n, ast.Name)}


def _attr_roots_in(node) -> set:
    return {_root_name(n) for n in ast.walk(node) if isinstance(n, ast.Attribute)}


# ── decorator / signature interpretation ──────────────────────────────────────
def _interpret_decorator(dec, fn: FunctionInfo):
    """Fill route metadata and auth controls from one decorator node."""
    target = dec.func if isinstance(dec, ast.Call) else dec
    attr = _last_attr(target).lower()
    root = _root_name(target).lower()

    # Route registration: @app.route / @app.get / @router.post / add_url_rule
    if isinstance(dec, ast.Call) and attr in sig.ROUTE_ATTRS:
        fn.is_route = True
        fn.route_path = _str_arg(dec) or fn.name
        if attr in sig.HTTP_VERBS:
            fn.route_method = attr.upper()
        else:
            fn.route_method = _methods_from_kwargs(dec)
        fn.framework = _framework_of(root, attr)
        return

    # Auth decorator (bare @login_required or called @jwt_required())
    if attr in sig.AUTH_DECORATORS or root in sig.AUTH_DECORATORS:
        fn.controls.append(Control("auth", f"@{attr or root}", "entrypoint", line=fn.lineno))
        return

    # Agent/LLM tool registration: bare @tool, @mcp.tool(), @server.tool(),
    # OpenAI's @function_tool. The function becomes reachable from the
    # LLM/agent runtime the same way a route is reachable from the network —
    # its arguments are attacker-influenceable via prompt injection.
    if attr in sig.AGENT_TOOL_DECORATORS or root in sig.AGENT_TOOL_DECORATORS:
        fn.is_agent_tool = True
        fn.tool_name = (_str_arg(dec) if isinstance(dec, ast.Call) else "") or fn.name


def _methods_from_kwargs(call) -> str:
    for kw in call.keywords:
        if kw.arg == "methods" and isinstance(kw.value, (ast.List, ast.Tuple)):
            verbs = [e.value.upper() for e in kw.value.elts
                     if isinstance(e, ast.Constant) and isinstance(e.value, str)]
            if verbs:
                return "/".join(verbs)
    return "GET"


def _framework_of(root: str, attr: str) -> str:
    if attr == "route" or attr == "add_url_rule":
        return "flask"
    if root in ("router", "app") and attr in sig.HTTP_VERBS:
        return "fastapi/flask"
    return "web"


def _signature_controls(fn_node, fn: FunctionInfo):
    """FastAPI ``Depends(...)`` params and validation-model params."""
    args = fn_node.args
    for arg in list(args.args) + list(getattr(args, "kwonlyargs", [])):
        fn.params.add(arg.arg)
    # defaults align to the tail of args
    defaults = list(args.defaults)
    tail = args.args[len(args.args) - len(defaults):] if defaults else []
    for arg, default in list(zip(tail, defaults)) + list(
            zip(getattr(args, "kwonlyargs", []), getattr(args, "kw_defaults", []))):
        if isinstance(default, ast.Call):
            callee = _last_attr(default.func).lower()
            inner = _root_name(default.func).lower()
            if callee == "depends":
                dep = _dependency_name(default)
                if dep and dep.lower() in sig.AUTH_DEPENDENCIES:
                    fn.controls.append(Control("auth", f"Depends({dep})", "entrypoint",
                                               line=fn.lineno))
            if inner in sig.AUTH_DEPENDENCIES or callee in sig.AUTH_DEPENDENCIES:
                fn.controls.append(Control("auth", f"{callee or inner}()", "entrypoint",
                                           line=fn.lineno))
        # a param annotated with a validation model = input validation present
        ann = arg.annotation if hasattr(arg, "annotation") else None
        if ann is not None and _last_attr(ann).lower() in sig.VALIDATION_BASES:
            fn.controls.append(Control("validation", "typed request model",
                                       "entrypoint", line=fn.lineno))


def _dependency_name(call) -> str:
    if call.args:
        return _last_attr(call.args[0])
    return ""


# ── the visitor ───────────────────────────────────────────────────────────────
class _Visitor(ast.NodeVisitor):
    def __init__(self, facts: FileFacts):
        self.facts = facts
        self._fn_stack: list[FunctionInfo] = []

    # functions -------------------------------------------------------------
    def visit_FunctionDef(self, node):
        self._enter_function(node)

    def visit_AsyncFunctionDef(self, node):
        self._enter_function(node)

    def _enter_function(self, node):
        fn = FunctionInfo(node.name, node.lineno)
        for dec in node.decorator_list:
            self._note_global_control(dec)
            _interpret_decorator(dec, fn)
        _signature_controls(node, fn)
        if fn.framework:
            self.facts.frameworks.add(fn.framework.split("/")[0])
        self.facts.functions[node.name] = fn
        self._fn_stack.append(fn)
        self.generic_visit(node)
        self._fn_stack.pop()

    # classes: DRF permission_classes + CBV auth mixins ---------------------
    def visit_ClassDef(self, node):
        controls: list[Control] = []
        base_names = {_last_attr(b).lower() for b in node.bases}
        if base_names & sig.AUTH_MIXINS:
            controls.append(Control("auth", "auth mixin", "entrypoint", line=node.lineno))
        for stmt in node.body:
            if isinstance(stmt, ast.Assign):
                targets = {t.id for t in stmt.targets if isinstance(t, ast.Name)}
                if targets & sig.AUTH_CLASS_ATTRS:
                    # permission_classes = [] means *no* auth; anything else is a control
                    if not _is_empty_collection(stmt.value):
                        controls.append(Control("auth", "permission_classes",
                                                "entrypoint", line=stmt.lineno))
        if controls:
            self.facts.cbv_controls[node.name] = controls
        self.generic_visit(node)

    # calls: sinks, stores, external calls, validation, global controls -----
    def visit_Call(self, node):
        self._classify_call(node)
        self.generic_visit(node)

    # assignments: hardcoded vs managed secrets -----------------------------
    def visit_Assign(self, node):
        self._classify_secret(node)
        self.generic_visit(node)

    # imports: framework + store detection ----------------------------------
    def visit_Import(self, node):
        for alias in node.names:
            root = alias.name.split(".")[0].lower()
            bound = alias.asname or alias.name.split(".")[0]
            self.facts.import_map[bound] = root
            self._note_import(alias.name.lower())
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if node.module:
            root = node.module.split(".")[0].lower()
            for alias in node.names:
                bound = alias.asname or alias.name
                self.facts.import_map[bound] = root
            self._note_import(node.module.lower())
        self.generic_visit(node)

    # ---- internals --------------------------------------------------------
    def _note_import(self, module: str):
        head = module.split(".")[0]
        if head in ("flask",):
            self.facts.frameworks.add("flask")
        elif head in ("fastapi", "starlette"):
            self.facts.frameworks.add("fastapi")
        elif head in ("django", "rest_framework"):
            self.facts.frameworks.add("django")
        elif head in sig.AGENT_FRAMEWORK_ROOTS:
            self.facts.frameworks.add(head)
        elif head in sig.LLM_PROVIDER_ROOTS:
            self.facts.frameworks.add(head)
        elif module.startswith("google.generativeai"):
            self.facts.frameworks.add("google-generativeai")

    def _note_global_control(self, dec):
        # @app.before_request auth gates, @app.after_request header setters
        target = dec.func if isinstance(dec, ast.Call) else dec
        attr = _last_attr(target).lower()
        if attr in ("before_request", "before_app_request"):
            self.facts.global_controls.append(
                Control("auth", "@before_request", "global"))

    def _classify_call(self, node):
        attr = _last_attr(node.func).lower()
        root = _root_name(node.func).lower()
        chain = _attr_chain(node.func).lower()

        # generic dependency-call tracking — any call whose root resolves to a
        # tracked import, independent of whether it also matches a Sink
        # pattern below. This is what lets an SBOM/dependency-CVE finding be
        # checked for reachability even when the vulnerable call isn't one of
        # the hardcoded dangerous-sink shapes (e.g. a header-leak in an HTTP
        # client, not a sql/eval/deserialize call).
        dep_root = self.facts.import_map.get(root)
        if dep_root:
            tainted, _ = self._arg_flags(node)
            self._add_dep_call(node, dep_root, chain or root, tainted)

        # global security middleware constructed as Talisman(app) / CSRFProtect(app)
        ctor = _last_attr(node.func).lower()
        if ctor in sig.GLOBAL_CONTROLS:
            self.facts.global_controls.append(
                Control(sig.GLOBAL_CONTROLS[ctor], _last_attr(node.func), "global",
                        line=node.lineno))

        # data stores / queues
        if root in sig.DATA_STORES or chain.split(".")[0] in sig.DATA_STORES:
            kind, engine = sig.DATA_STORES.get(root) or sig.DATA_STORES[chain.split(".")[0]]
            self.facts.data_stores.append(DataStore(kind, engine, self.facts.rel_path, node.lineno))
        if root in sig.QUEUE_ROOTS:
            self.facts.external_calls.append(
                ExternalCall("queue", sig.QUEUE_ROOTS[root], self.facts.rel_path, node.lineno))

        # http client call — external call, SSRF if tainted. Gated on a real
        # client root (requests/httpx/urllib/session…) so Flask's `request`
        # input object (request.args.get) is never mistaken for an outbound call.
        if attr in sig.HTTP_CLIENT_ATTRS and root in sig.HTTP_CLIENT_ROOTS:
            tainted, cleartext = self._arg_flags(node)
            if tainted and self._fn_stack:
                self._add_sink(node, "ssrf", "ssrf", "CWE-918", tainted=True)
            else:
                self.facts.external_calls.append(
                    ExternalCall("http", root or "http", self.facts.rel_path,
                                 node.lineno, encrypted=not cleartext))

        # direct LLM invocation (chat/completion/generate call) — an outbound
        # trust-boundary crossing to a third-party model provider, matched on
        # the dotted chain so any client variable name is recognised.
        if any(pat in chain for pat in sig.LLM_CALL_CHAIN_SIGNATURES):
            self.facts.external_calls.append(
                ExternalCall("llm", root or "llm-provider", self.facts.rel_path, node.lineno))

        # sensitive sinks
        if attr in sig.SINKS and not (attr in sig.COMMAND_GATED_ATTRS
                                       and root not in sig.COMMAND_SINK_ROOTS):
            kind, family, cwe = sig.SINKS[attr]
            if kind in sig.TAINT_GATED_SINKS:
                tainted, _ = self._arg_flags(node)
                if not tainted:
                    return
                self._add_sink(node, kind, family, cwe, tainted=True)
            else:
                # yaml.load is only unsafe without a safe loader; keep MEDIUM
                tainted, _ = self._arg_flags(node)
                self._add_sink(node, kind, family, cwe, tainted=tainted)

        # validation call inside a handler body
        if attr in sig.VALIDATION_CALLS and self._fn_stack:
            self._fn_stack[-1].controls.append(
                Control("validation", f"{attr}()", "entrypoint", line=node.lineno))

        # record local function calls for the call graph — bare names
        # (`helper()`) and same-object method calls (`self.foo()` /
        # `cls.foo()`). fn_map (extractor.py) resolves calls by bare name
        # with no class/type information, so `self.foo()` is recorded as a
        # call to `foo` — the same way it would resolve a bare `foo()` call —
        # letting the reachability BFS cross into the many handlers that
        # dispatch to sinks via `self._something()` instead of a module
        # function. Arbitrary attribute calls on other objects
        # (`response.json()`) are deliberately NOT recorded: without type
        # info they'd just as likely collide with an unrelated same-named
        # method elsewhere, adding false edges rather than real ones.
        if self._fn_stack:
            if isinstance(node.func, ast.Name):
                self._fn_stack[-1].calls.add(node.func.id)
            elif isinstance(node.func, ast.Attribute) and root in ("self", "cls"):
                self._fn_stack[-1].calls.add(node.func.attr)

    def _arg_flags(self, node):
        """(tainted, cleartext) for a call's arguments."""
        tainted = False
        cleartext = False
        params = self._fn_stack[-1].params if self._fn_stack else set()
        for a in list(node.args) + [k.value for k in node.keywords]:
            roots = _attr_roots_in(a) | _names_in(a)
            if "request" in roots or (params & roots):
                tainted = True
            if isinstance(a, ast.Constant) and isinstance(a.value, str) \
                    and a.value.startswith("http://"):
                cleartext = True
        return tainted, cleartext

    def _add_sink(self, node, kind, family, cwe, tainted=False):
        s = Sink(kind=kind, family=family, cwe=cwe, name=_attr_chain(node.func),
                 file=self.facts.rel_path, line=node.lineno, tainted=tainted,
                 confidence=HIGH if tainted else MEDIUM)
        if self._fn_stack:
            self._fn_stack[-1].sinks.append(s)
        else:
            # module-level sink: attach to a synthetic module function bucket
            self.facts.functions.setdefault(
                "<module>", FunctionInfo("<module>", node.lineno)).sinks.append(s)

    def _add_dep_call(self, node, dep_root, name, tainted):
        d = DependencyUse(root=dep_root, name=name, file=self.facts.rel_path,
                          line=node.lineno, tainted=tainted)
        if self._fn_stack:
            self._fn_stack[-1].dep_calls.append(d)
        else:
            self.facts.functions.setdefault(
                "<module>", FunctionInfo("<module>", node.lineno)).dep_calls.append(d)

    def _classify_secret(self, node):
        value = node.value
        for target in node.targets:
            name = target.id.lower() if isinstance(target, ast.Name) else \
                (_last_attr(target).lower() if isinstance(target, ast.Attribute) else "")
            if not name or not any(h in name for h in sig.SECRET_NAME_HINTS):
                continue
            managed = _reads_env(value)
            if isinstance(value, ast.Constant) and isinstance(value.value, str) \
                    and value.value and not managed:
                self.facts.secrets.append(
                    Secret(target.id if isinstance(target, ast.Name) else name,
                           self.facts.rel_path, node.lineno, managed=False))
            elif managed:
                self.facts.secrets.append(
                    Secret(target.id if isinstance(target, ast.Name) else name,
                           self.facts.rel_path, node.lineno, managed=True))


def _reads_env(node) -> bool:
    for n in ast.walk(node):
        if isinstance(n, ast.Attribute) and n.attr in ("getenv", "environ"):
            return True
        if isinstance(n, ast.Subscript) and isinstance(n.value, ast.Attribute) \
                and n.value.attr == "environ":
            return True
        if isinstance(n, ast.Call) and _last_attr(n.func) in ("getenv", "get_secret",
                                                              "get_parameter"):
            return True
    return False


def _is_empty_collection(node) -> bool:
    return isinstance(node, (ast.List, ast.Tuple, ast.Set)) and not node.elts


# ── public entry ──────────────────────────────────────────────────────────────
def analyze_python_source(source: str, rel_path: str) -> FileFacts:
    facts = FileFacts(rel_path)
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError) as exc:
        facts_error = f"{rel_path}: {exc.__class__.__name__}: {exc}"
        facts.parse_error = facts_error  # type: ignore[attr-defined]
        return facts
    _Visitor(facts).visit(tree)
    _extract_django_urls(tree, facts)
    return facts


def _extract_django_urls(tree, facts: FileFacts):
    """`urlpatterns = [path("x/", view), ...]` and re_path/url variants."""
    for node in ast.walk(tree):
        if not (isinstance(node, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == "urlpatterns"
                        for t in node.targets)):
            continue
        if not isinstance(node.value, (ast.List, ast.Tuple)):
            continue
        for elt in node.value.elts:
            if isinstance(elt, ast.Call) and _last_attr(elt.func) in ("path", "re_path", "url"):
                route = _str_arg(elt)
                view = ""
                if len(elt.args) > 1:
                    view = _view_name(elt.args[1])
                facts.django_urls.append(
                    {"method": "*", "path": route or "/", "view": view, "line": elt.lineno})
                facts.frameworks.add("django")


def _view_name(node) -> str:
    if isinstance(node, ast.Call):          # SomeView.as_view()
        return _root_name(node.func) or _last_attr(node.func)
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Name):
        return node.id
    return ""
