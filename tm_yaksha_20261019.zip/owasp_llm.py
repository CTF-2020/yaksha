"""owasp_llm.py — OWASP LLM Top 10 2025 knowledge base for AI/agentic threat modeling."""
from __future__ import annotations

OWASP_LLM_TOP10: dict = {
    "LLM01": {
        "id": "LLM01", "name": "Prompt Injection",
        "description": "Malicious inputs manipulate LLM behavior via direct user input or indirect injection from external sources (documents, web pages, tool outputs).",
        "agentic_risk": "Critical",
        "attack_scenarios": [
            "Direct: User input overrides system prompt via role-playing or instruction injection",
            "Indirect: Retrieved web content or RAG documents embed hidden instructions",
            "Agentic: Tool output from a compromised data source hijacks agent decision loop",
            "Multi-agent: Upstream agent poisons context passed to downstream agents",
        ],
        "mitigations": [
            {"action": "Privilege separation: never allow user-controlled input to override system-level instructions", "priority": "Immediate"},
            {"action": "Validate and sanitize all external content before injecting into LLM context", "priority": "Immediate"},
            {"action": "Use constrained tool output schemas — reject unstructured free-text from tools", "priority": "Short-term"},
            {"action": "Human-in-the-loop approval for all irreversible agent actions", "priority": "Short-term"},
        ],
    },
    "LLM02": {
        "id": "LLM02", "name": "Insecure Output Handling",
        "description": "LLM-generated output is consumed by downstream components (browsers, databases, shells) without validation, enabling XSS, SQLi, RCE.",
        "agentic_risk": "High",
        "attack_scenarios": [
            "LLM output passed to subprocess.run() or eval() without sanitization",
            "LLM-generated HTML rendered in browser without CSP — stored XSS",
            "SQL queries constructed from LLM output without parameterization",
            "Agent-generated shell commands executed directly on host",
        ],
        "mitigations": [
            {"action": "Treat all LLM output as untrusted user input — apply same sanitization rules", "priority": "Immediate"},
            {"action": "Use parameterized queries for any LLM-generated database operations", "priority": "Immediate"},
            {"action": "Content Security Policy headers for any LLM-generated HTML rendering", "priority": "Short-term"},
            {"action": "Whitelist allowed commands/operations before executing agent-generated actions", "priority": "Short-term"},
        ],
    },
    "LLM03": {
        "id": "LLM03", "name": "Training Data Poisoning",
        "description": "Adversarial manipulation of training data, fine-tuning datasets, or RAG knowledge bases to degrade model integrity or implant backdoors.",
        "agentic_risk": "High",
        "attack_scenarios": [
            "Backdoor triggers in fine-tuning data: specific phrase activates malicious behavior",
            "Poisoned vector DB entries skew RAG retrieval toward attacker-controlled content",
            "Supply chain compromise of public datasets (Common Crawl, HuggingFace)",
            "Embedding space poisoning causing semantic search to return adversarial docs",
        ],
        "mitigations": [
            {"action": "Data provenance verification and cryptographic signing for all training datasets", "priority": "Short-term"},
            {"action": "Anomaly detection on training data distributions — flag statistical outliers", "priority": "Short-term"},
            {"action": "Red-team fine-tuned models for backdoor triggers before deployment", "priority": "Short-term"},
            {"action": "Strict access controls and audit logging on vector database write operations", "priority": "Immediate"},
        ],
    },
    "LLM04": {
        "id": "LLM04", "name": "Model Denial of Service",
        "description": "Resource exhaustion via adversarial inputs, unbounded agent loops, or context window flooding causing degraded availability.",
        "agentic_risk": "Medium",
        "attack_scenarios": [
            "Unbounded agent recursion: agent calls tool → tool calls agent → infinite loop",
            "Context window exhaustion via injected large documents in RAG pipeline",
            "Token flooding via adversarial repetitive prompts consuming inference budget",
            "Algorithmic complexity via carefully crafted inputs that maximize compute time",
        ],
        "mitigations": [
            {"action": "Rate limiting per user/session on all LLM inference endpoints", "priority": "Immediate"},
            {"action": "Maximum token limits on all user-controlled inputs and tool outputs", "priority": "Immediate"},
            {"action": "Recursive call depth limits (max 10) in all agent orchestration frameworks", "priority": "Short-term"},
            {"action": "Cost budgets per request with circuit breakers for anomalous consumption", "priority": "Short-term"},
        ],
    },
    "LLM05": {
        "id": "LLM05", "name": "Supply Chain Vulnerabilities",
        "description": "Compromised models, datasets, plugins, or ML dependencies in the AI development and deployment pipeline.",
        "agentic_risk": "High",
        "attack_scenarios": [
            "Backdoored model weights distributed via HuggingFace or model registries",
            "Malicious PyPI packages mimicking popular ML libraries (typosquatting)",
            "Compromised MCP server or LangChain tool plugin with data exfiltration",
            "Third-party vector database with poisoned default embeddings",
        ],
        "mitigations": [
            {"action": "Model card verification and hash validation for all model weights", "priority": "Immediate"},
            {"action": "Dependency pinning with hash verification in requirements.txt/pyproject.toml", "priority": "Immediate"},
            {"action": "Third-party plugin sandboxing — isolated execution environments for external tools", "priority": "Short-term"},
            {"action": "Software Bill of Materials (SBOM) for all ML pipeline components", "priority": "Long-term"},
        ],
    },
    "LLM06": {
        "id": "LLM06", "name": "Sensitive Information Disclosure",
        "description": "LLM leaks training data, system prompts, user data, or secrets via memorization, context exposure, or adversarial extraction.",
        "agentic_risk": "High",
        "attack_scenarios": [
            "PII memorized from training data regurgitated via targeted prompting",
            "System prompt extraction via jailbreak or adversarial few-shot examples",
            "Cross-user data leakage in shared model instances via context contamination",
            "Agent conversation history exposed to downstream agents or logged to insecure stores",
        ],
        "mitigations": [
            {"action": "PII scrubbing and differential privacy techniques before training", "priority": "Short-term"},
            {"action": "System prompt protection via API-level controls — not accessible via user messages", "priority": "Immediate"},
            {"action": "Output filtering for PII patterns, secrets, and sensitive data before delivery", "priority": "Immediate"},
            {"action": "Session isolation: each user session gets independent context with no cross-contamination", "priority": "Short-term"},
        ],
    },
    "LLM07": {
        "id": "LLM07", "name": "Insecure Plugin Design",
        "description": "LLM plugins, tools, and function-calling integrations with excessive permissions, insufficient validation, or missing authorization.",
        "agentic_risk": "Critical",
        "attack_scenarios": [
            "Plugin executes arbitrary shell commands from LLM-generated parameters",
            "OAuth plugin with overly broad scope grants LLM access to entire Google Drive",
            "Tool bypasses authentication when called by LLM vs when called by human",
            "MCP server exposes admin endpoints callable by any connected agent",
        ],
        "mitigations": [
            {"action": "Principle of least privilege for all tools — minimum required permissions only", "priority": "Immediate"},
            {"action": "Separate authentication for tool invocations — LLM cannot bypass tool-level authZ", "priority": "Immediate"},
            {"action": "Input validation in every plugin: reject unexpected parameter types/ranges", "priority": "Immediate"},
            {"action": "Tool action audit log: every invocation logged with parameters and caller identity", "priority": "Short-term"},
        ],
    },
    "LLM08": {
        "id": "LLM08", "name": "Excessive Agency",
        "description": "Agent granted too many permissions, operates without sufficient oversight, or performs irreversible actions autonomously.",
        "agentic_risk": "Critical",
        "attack_scenarios": [
            "Agent with file system write + network + code execution autonomously deploys malicious code",
            "Multi-agent pipeline where no stage requires human confirmation for high-impact actions",
            "Agent permanently deletes data or sends emails based on LLM hallucination",
            "Prompt-injected agent chain that escalates privileges across downstream agents",
        ],
        "mitigations": [
            {"action": "Minimal permission scoping per task — explicitly deny all permissions not required", "priority": "Immediate"},
            {"action": "Human approval gates for all irreversible or high-impact actions", "priority": "Immediate"},
            {"action": "Immutable audit log for every agent action with full parameter capture", "priority": "Short-term"},
            {"action": "Sandbox agent execution environment with strict resource limits", "priority": "Short-term"},
        ],
    },
    "LLM09": {
        "id": "LLM09", "name": "Overreliance",
        "description": "Uncritical trust in LLM output for high-stakes decisions without human verification, leading to security, safety, or operational failures.",
        "agentic_risk": "Medium",
        "attack_scenarios": [
            "Security decisions (access grants, firewall rules) delegated entirely to LLM",
            "Agent-generated code deployed to production without human review",
            "Medical or legal advice acted upon without expert validation",
            "Threat model generated by AI accepted as ground truth without security review",
        ],
        "mitigations": [
            {"action": "Human-in-the-loop for all critical decisions involving safety, security, or compliance", "priority": "Immediate"},
            {"action": "Confidence thresholds: low-confidence outputs automatically escalate to human review", "priority": "Short-term"},
            {"action": "Explicit uncertainty communication in all LLM outputs — never false confidence", "priority": "Short-term"},
            {"action": "Red-team AI-assisted workflows to identify over-reliance failure modes", "priority": "Long-term"},
        ],
    },
    "LLM10": {
        "id": "LLM10", "name": "Model Theft",
        "description": "Unauthorized extraction of model weights, architecture, or behavior via API probing, distillation attacks, or side-channel analysis.",
        "agentic_risk": "Medium",
        "attack_scenarios": [
            "Model inversion via systematic API query logging and analysis",
            "Model distillation: using API responses as training data for a competing model",
            "Architecture reconstruction via gradient-based membership inference attacks",
            "Weight extraction via timing side-channels in inference endpoints",
        ],
        "mitigations": [
            {"action": "Aggressive rate limiting on inference endpoints with anomaly detection for systematic probing", "priority": "Immediate"},
            {"action": "Output perturbation: add minimal noise to resist distillation without degrading utility", "priority": "Short-term"},
            {"action": "Query logging and behavioral analysis to detect extraction patterns", "priority": "Short-term"},
            {"action": "Terms of service enforcement with automated detection of API abuse patterns", "priority": "Long-term"},
        ],
    },
}
