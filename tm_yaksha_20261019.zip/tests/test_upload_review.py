"""Upload review request regressions."""
from io import BytesIO
import json
import sys
from pathlib import Path

from werkzeug.datastructures import MultiDict

sys.path.insert(0, str(Path(__file__).parent.parent))

import app as tm_app
import report_db


def _isolate(tmp_path, monkeypatch):
    monkeypatch.setattr(tm_app, "REPORTS_DIR", tmp_path)
    monkeypatch.setattr(report_db, "DB_PATH", tmp_path / "reports.db")


def test_report_id_validation_accepts_saved_sbom_ids():
    assert tm_app._validate_report_id("sbom_1779016409_deadbeef")


def test_control_register_csv_route_uses_response_object(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    report_id = "1779016409_deadbeef"
    report_db.upsert_report({
        "id": report_id,
        "title": "Control Register Test",
        "methodology": "test",
        "categories": [
            {
                "id": "A01",
                "name": "Broken Access Control",
                "risk": "High",
                "mitigations": [{"action": "Enforce RBAC checks", "priority": "Immediate"}],
            }
        ],
    })

    client = tm_app.app.test_client()
    response = client.get(f"/api/reports/{report_id}/control-register?format=csv")

    assert response.status_code == 200
    assert response.mimetype == "text/csv"
    assert "Enforce RBAC checks" in response.get_data(as_text=True)


def test_analyze_route_persists_architecture_text_for_followup_routes(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)

    def fake_analyze(api_key, architecture_text, **kwargs):
        return {
            "title": kwargs.get("title", "Test"),
            "methodology": "test",
            "summary": "ok",
            "overall_risk": "Low",
            "categories": [],
            "recommendations": [],
            "analyzed_at": "2026-05-17T00:00:00",
        }

    monkeypatch.setattr(tm_app.analyzer, "analyze", fake_analyze)
    client = tm_app.app.test_client()
    token = client.get("/api/csrf-token").get_json()["token"]
    architecture = "React frontend to API gateway with RSA-2048 certificates."

    response = client.post(
        "/api/analyze",
        json={
            "api_key": "",
            "title": "Stored Architecture",
            "methodology": "owasp_api",
            "architecture": architecture,
        },
        headers={"X-CSRF-Token": token},
    )

    assert response.status_code == 200
    report_id = response.get_json()["id"]
    saved_report = (tmp_path / f"{report_id}.json").read_text(encoding="utf-8")
    assert architecture in saved_report


def test_report_pqc_route_persists_assessment_on_report(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    report_id = "1779016409_deadbeef"
    report_db.upsert_report({
        "id": report_id,
        "title": "PQC Persistence",
        "methodology": "test",
        "architecture_text": "TLS certificates use RSA-2048 and ECDSA P-256.",
        "categories": [],
    })

    client = tm_app.app.test_client()
    response = client.get(f"/api/reports/{report_id}/pqc")

    assert response.status_code == 200
    body = response.get_json()
    assert body["success"] is True
    assert body["findings_count"] >= 1
    saved_report = report_db.get_report(report_id)
    assert saved_report["pqc_assessment"]["findings_count"] == body["findings_count"]


def test_multipart_review_combines_typed_text_and_uploaded_file(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    captured = {}

    def fake_analyze(api_key, architecture_text, **kwargs):
        captured["architecture_text"] = architecture_text
        return {
            "title": kwargs.get("title", "Test"),
            "methodology": "test",
            "summary": "ok",
            "overall_risk": "Low",
            "categories": [],
            "recommendations": [],
            "analyzed_at": "2026-05-17T00:00:00",
        }

    monkeypatch.setattr(tm_app.analyzer, "analyze", fake_analyze)
    client = tm_app.app.test_client()
    token = client.get("/api/csrf-token").get_json()["token"]

    response = client.post(
        "/api/analyze",
        data={
            "title": "Upload Merge",
            "architecture": "Typed architecture context.",
            "methodology": "owasp_api",
            "file": (BytesIO(b"Uploaded file architecture context."), "arch.txt"),
        },
        headers={"X-CSRF-Token": token},
        content_type="multipart/form-data",
    )

    assert response.status_code == 200
    assert response.get_json()["success"] is True
    assert "Typed architecture context." in captured["architecture_text"]
    assert "Uploaded file architecture context." in captured["architecture_text"]


def test_multipart_review_triggers_with_file_only(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    captured = {}

    def fake_analyze(api_key, architecture_text, **kwargs):
        captured["architecture_text"] = architecture_text
        return {
            "title": kwargs.get("title", "Test"),
            "methodology": "test",
            "summary": "ok",
            "overall_risk": "Low",
            "categories": [],
            "recommendations": [],
            "analyzed_at": "2026-05-17T00:00:00",
        }

    monkeypatch.setattr(tm_app.analyzer, "analyze", fake_analyze)
    client = tm_app.app.test_client()
    token = client.get("/api/csrf-token").get_json()["token"]

    response = client.post(
        "/api/analyze",
        data={
            "title": "Upload Only",
            "methodology": "owasp_api",
            "file": (BytesIO(b"File-only architecture context."), "arch.txt"),
        },
        headers={"X-CSRF-Token": token},
        content_type="multipart/form-data",
    )

    assert response.status_code == 200
    assert response.get_json()["success"] is True
    assert "File-only architecture context." in captured["architecture_text"]


def test_multipart_review_combines_multiple_supporting_files_in_scope(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    captured = {}

    def fake_analyze(api_key, architecture_text, **kwargs):
        captured["architecture_text"] = architecture_text
        return {
            "title": kwargs.get("title", "Test"),
            "methodology": "test",
            "summary": "ok",
            "overall_risk": "Low",
            "categories": [],
            "recommendations": [],
            "analyzed_at": "2026-05-17T00:00:00",
        }

    monkeypatch.setattr(tm_app.analyzer, "analyze", fake_analyze)
    client = tm_app.app.test_client()
    token = client.get("/api/csrf-token").get_json()["token"]

    response = client.post(
        "/api/analyze",
        data=MultiDict([
            ("title", "Multiple Uploads"),
            ("architecture", "Primary system: React frontend to API."),
            ("methodology", "owasp_api"),
            ("file", (BytesIO(b"Data flow: API to PostgreSQL."), "data-flow.md")),
            ("file", (BytesIO(b"Trust boundary: Internet to gateway."), "trust-boundaries.txt")),
        ]),
        headers={"X-CSRF-Token": token},
        content_type="multipart/form-data",
    )

    assert response.status_code == 200
    assert response.get_json()["success"] is True
    assert "Primary architecture description (in scope for threat model)" in captured["architecture_text"]
    assert "Supporting document 1 (data-flow.md) - IN SCOPE FOR THREAT MODEL" in captured["architecture_text"]
    assert "Supporting document 2 (trust-boundaries.txt) - IN SCOPE FOR THREAT MODEL" in captured["architecture_text"]
    assert "Data flow: API to PostgreSQL." in captured["architecture_text"]
    assert "Trust boundary: Internet to gateway." in captured["architecture_text"]
