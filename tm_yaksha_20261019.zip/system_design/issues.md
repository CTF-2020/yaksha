# GitHub Issues

Recent issues from the repository (23 total).

## Open Issues (2)

### #1: Good job!
**Labels:** misc | **Created:** 2022-08-16
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/1)

### #63: Can you add a Github wiki, So we can access the TOC in the sidebar
**Labels:** improvement | **Created:** 2025-12-03
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/63)


## Recently Closed Issues (21)

### #55: I appreciate you sharing that, THANKS
**Labels:** No labels | **Closed:** 2025-05-26
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/55)

### #54: Potential Incorrect Diagram Label for Write-Through Caching
**Labels:** stale | **Closed:** 2025-05-18
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/54)

### #46: epub version request
**Labels:** No labels | **Closed:** 2024-11-15
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/46)

### #41: Description of Referential integrity
**Labels:** stale | **Closed:** 2024-04-09
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/41)

### #39: System dewign
**Labels:** stale | **Closed:** 2024-03-21
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/39)

### #38: Can I translate them to Chinese?
**Labels:** stale | **Closed:** 2024-03-13
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/38)

### #36: Mistake in the Sparse Indexing section
**Labels:** improvement | **Closed:** 2024-01-18
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/36)

### #35: Question about transrate and use it
**Labels:** stale | **Closed:** 2024-01-11
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/35)

### #34: System design
**Labels:** stale | **Closed:** 2024-01-09
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/34)

### #33: Simple Design
**Labels:** stale | **Closed:** 2024-01-08
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/33)

### #29: System design course
**Labels:** stale | **Closed:** 2023-08-23
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/29)

### #28: Additional content request [Load balancers]
**Labels:** stale | **Closed:** 2023-07-30
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/28)

### #26: Epub file is larger than 50mb which is not allow by the Send to Kindle desktop application
**Labels:** stale | **Closed:** 2023-07-22
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/26)

### #27: Plis help me
**Labels:** stale | **Closed:** 2023-07-22
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/27)

### #25: Question about tools used
**Labels:** stale | **Closed:** 2023-07-19
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/25)

### #20: Calculations on Whatsapp System Design - Storage
**Labels:** stale | **Closed:** 2023-01-20
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/20)

### #16: Add Etsy Tech Blog as Resource
**Labels:** stale | **Closed:** 2022-09-29
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/16)

### #14: WhatsApp, data model design
**Labels:** improvement | **Closed:** 2022-09-08
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/14)

### #7: Records and fields vs rows and columns in general DBMS discussions
**Labels:** improvement | **Closed:** 2022-08-22
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/7)

### #4: Make fornt in images more readable
**Labels:** No labels | **Closed:** 2022-08-22
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/4)

### #3: GitHub markdown rendering issue in URL Shortener -> High-level design -> URL Encoding section
**Labels:** No labels | **Closed:** 2022-08-17
[View on GitHub](https://github.com/karanpratapsingh/system-design/issues/3)

