"""Tests for lineage.engine — pure observation-to-lineage matching.

Design and code fixtures deliberately share vocabulary ("user search handler"
vs. "handlers/user_search.py") so relatedness is unambiguous — two or more
shared tokens, not a single fragile overlap — the same bar the correlator's
own ``locus_related`` uses.

Lineage matching is intentionally *stricter* than the correlator's own
corroboration rule: the correlator attaches a design finding to every piece of
evidence in its weakness family (a coarse "is this family modeled at all"
question); lineage requires locus relatedness even for a design->code match,
because "this specific prediction became this specific finding" is a stronger
claim than "some finding of this family exists somewhere."
"""
from __future__ import annotations

import unittest

from correlator.engine import observe_report
from lineage import engine as lineage_engine


def _design_report(rid="r_design", component="user search handler",
                   name="SQL Injection", risk="High"):
    return {
        "id": rid, "title": "Design Review", "methodology": "owasp",
        "categories": [{
            "id": "WEB-A03", "name": name, "risk": risk,
            "affected_components": [component],
            "mitigations": [{"action": "Parameterize queries."}],
        }],
    }


def _code_report(rid="r_code", locus="handlers/user_search.py:42",
                 name="SQL Injection", risk="Critical", source="CODEMODEL"):
    return {
        "id": rid, "title": "Code Model", "methodology": "codemodel",
        "categories": [{
            "id": "CM-001", "name": name, "risk": risk, "_source": source,
            "cwe": "CWE-89", "affected_components": [locus],
        }],
    }


def _runtime_report(rid="r_dast", locus="handlers/user_search.py:42",
                    name="SQL Injection", risk="High"):
    return {
        "id": rid, "title": "DAST", "methodology": "dast",
        "categories": [{
            "id": "DAST-SQLI", "name": name, "risk": risk, "_source": "DAST",
            "cwe": "CWE-89", "affected_components": [locus],
        }],
    }


class TestSyncObservations(unittest.TestCase):
    def test_new_design_observation_creates_predicted_threat(self):
        existing = []
        touched, events = lineage_engine.sync_report(_design_report(), existing)
        self.assertEqual(len(touched), 1)
        self.assertEqual(touched[0].status, "predicted")
        self.assertEqual(touched[0].kinds_seen, ["design"])
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0][1].kind, "design")

    def test_matching_code_observation_advances_predicted_to_realized(self):
        existing = []
        lineage_engine.sync_report(_design_report(), existing)
        self.assertEqual(existing[0].status, "predicted")

        touched, _ = lineage_engine.sync_report(_code_report(), existing)
        self.assertEqual(len(existing), 1)   # matched, not duplicated
        self.assertEqual(touched[0].status, "realized")
        self.assertEqual(sorted(touched[0].kinds_seen), ["code", "design"])

    def test_confirmed_requires_both_code_and_runtime(self):
        existing = []
        lineage_engine.sync_report(_design_report(), existing)
        lineage_engine.sync_report(_code_report(), existing)
        self.assertEqual(existing[0].status, "realized")

        touched, _ = lineage_engine.sync_report(_runtime_report(), existing)
        self.assertEqual(len(existing), 1)
        self.assertEqual(touched[0].status, "confirmed")
        self.assertEqual(sorted(touched[0].kinds_seen), ["code", "design", "runtime"])

    def test_code_only_finding_with_no_prior_design_is_a_blind_spot(self):
        existing = []
        touched, _ = lineage_engine.sync_report(_code_report(), existing)
        self.assertEqual(touched[0].status, "blind_spot")
        self.assertEqual(touched[0].kinds_seen, ["code"])

    def test_unrelated_locus_in_same_family_creates_a_separate_threat(self):
        existing = []
        lineage_engine.sync_report(_design_report(), existing)
        unrelated = _code_report(locus="billing/invoice_export.py:99")
        lineage_engine.sync_report(unrelated, existing)
        # Same family (sql-injection) but no shared vocabulary -> two threats,
        # the design prediction stays unrealized, the unrelated code finding
        # is its own blind spot.
        self.assertEqual(len(existing), 2)
        statuses = sorted(t.status for t in existing)
        self.assertEqual(statuses, ["blind_spot", "predicted"])

    def test_threat_id_is_deterministic_for_same_family_and_locus(self):
        obs1 = observe_report(_code_report(rid="a"))[0]
        obs2 = observe_report(_code_report(rid="b"))[0]   # same locus, different report
        id1 = lineage_engine._threat_id(obs1.family, obs1.locus_tokens)
        id2 = lineage_engine._threat_id(obs2.family, obs2.locus_tokens)
        self.assertEqual(id1, id2)

    def test_observation_with_no_locus_is_skipped(self):
        report = {
            "id": "r", "title": "T", "methodology": "owasp",
            "categories": [{"id": "A05", "name": "Security Misconfiguration",
                            "risk": "Medium", "affected_components": []}],
        }
        existing = []
        touched, events = lineage_engine.sync_report(report, existing)
        self.assertEqual(touched, [])
        self.assertEqual(events, [])
        self.assertEqual(existing, [])

    def test_founding_locus_is_frozen_at_creation(self):
        existing = []
        lineage_engine.sync_report(_design_report(), existing)
        original_locus = list(existing[0].founding_locus)

        # A related-but-not-identical code locus should still match (that's the
        # point of fuzzy relatedness) without mutating the founding signature.
        lineage_engine.sync_report(
            _code_report(locus="handlers/user_search_v2.py:10"), existing)
        self.assertEqual(existing[0].founding_locus, original_locus)

    def test_status_helper_matrix(self):
        f = lineage_engine._status_from_kinds
        self.assertEqual(f({"design"}), "predicted")
        self.assertEqual(f({"design", "code"}), "realized")
        self.assertEqual(f({"design", "runtime"}), "realized")
        self.assertEqual(f({"code", "runtime"}), "confirmed")
        self.assertEqual(f({"design", "code", "runtime"}), "confirmed")
        self.assertEqual(f({"code"}), "blind_spot")
        self.assertEqual(f({"runtime"}), "blind_spot")


if __name__ == "__main__":
    unittest.main()
