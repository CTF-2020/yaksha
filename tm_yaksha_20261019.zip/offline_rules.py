"""offline_rules.py — Deterministic offline review engine (no API key required).

Rules are organized in three sub-modules imported here:
  _rules_web  — OWASP Top 10 2021
  _rules_ai   — OWASP LLM Top 10 2025
  _rules_api  — OWASP API Security Top 10 2023

Each rule returns PASS (not applicable), WARN (review recommended),
or FAIL (critical review required) based on keyword/pattern matching.
"""
from __future__ import annotations
import re
from typing import Literal

from owasp import OWASP_TOP10
from owasp_llm import OWASP_LLM_TOP10
from owasp_api import OWASP_API_TOP10
from agentic_threats import detect_ai_architecture, detect_api_architecture, is_ai_analysis_applicable
from _rules_web import WEB_RULES
from _rules_ai import AI_RULES
from _rules_api import API_RULES
from _rules_mobile import MOBILE_RULES
from _rules_cloud import CLOUD_RULES
from _rules_architecture import ARCHITECTURE_RULES
from _rules_devsecops import DEVSECOPS_RULES
from offline_pattern_enrichment import enrich_rule, infer_ruleset
from risk_signals import RISK_SIGNALS as _RISK_SIGNALS

Status = Literal["PASS", "WARN", "FAIL"]

_SEV_RANK: dict[str, int] = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}

_BROAD_PATTERNS: set[str] = {
    "api", "app", "application", "auth", "body", "client", "code", "data",
    "db", "endpoint", "field", "file", "form", "id", "input", "key", "list",
    "log", "message", "model", "network", "object", "output", "page", "path",
    "post", "put", "query", "request", "resource", "response", "role",
    "server", "service", "system", "test", "token", "tool", "ui", "url",
    "user", "web",
}

_HIGH_SIGNAL_SHORT_PATTERNS: set[str] = {
    "2fa", "abac", "acr", "aes", "aks", "alb", "ami", "apk", "csp",
    "cve", "dast", "dmz", "dns", "ebs", "ec2", "ecr", "eks", "elb", "gcp",
    "gcr", "gdpr", "gke", "hsts", "iam", "imds", "ipa", "jwt", "kms", "mcp",
    "mfa", "nsg", "oidc", "pki", "rbac", "rds", "rag", "rsa", "s3", "saml",
    "sast", "sdk", "sdlc", "siem", "soc", "soar", "sql", "sqs", "ssrf",
    "ssl", "sso", "tls", "vpn", "waf",
}

_WEB_SIGNALS: list[str] = [
    "web app", "web application", "website", "browser", "frontend", "react",
    "angular", "vue", "spa", "single page", "login form", "session", "cookie",
]

_CONTROL_EVIDENCE: dict[str, list[str]] = {
    "WEB-A01-01": [
        "rbac authorization checks", "authorization checks", "object-level authorization",
        "row-level authorization", "ownership checks", "tenant scoped", "tenant resources",
        "per-tenant access control",
    ],
    "WEB-A01-02": [
        "rbac", "least privilege", "least-privilege", "privileged access controlled",
        "admin mfa", "separate admin", "deny by default",
    ],
    "WEB-A01-03": [
        "signed urls", "signed url", "time-limited urls", "private s3 bucket",
        "private bucket", "block public access", "directory listing disabled",
        "access-controlled uploads", "authenticated file access",
    ],
    "WEB-A01-04": [
        "strict cors allowlist", "cors allowlist", "trusted origins",
        "allowlist specific trusted origins", "restrict cross-origin",
    ],
    "WEB-A02-01": [
        "https enforced", "tls enforced", "tls 1.2", "tls 1.3", "hsts",
    ],
    "WEB-A02-03": [
        "encrypted at rest", "database encrypted", "sse-kms", "field-level encryption",
    ],
    "WEB-A02-04": [
        "secrets manager", "key rotation", "secret rotation", "token rotation",
        "refresh token rotation", "secret scanning",
    ],
    "WEB-A03-01": [
        "parameterized sql", "parameterized statements", "prepared statements",
        "sqlalchemy", "orm", "no string concatenation", "zero string concatenation",
    ],
    "WEB-A04-02": [
        "server-side input validation", "server side input validation", "server-side validation",
        "schema validation", "json schema", "pydantic", "zod",
    ],
    "WEB-A05-04": [
        "private s3 bucket", "private bucket", "block public access",
        "private by default", "private-by-default", "not publicly accessible",
        "signed urls", "sse-kms", "rds private", "private queue",
    ],
    "WEB-A07-03": [
        "short-lived jwt", "short lived jwt", "refresh token rotation",
        "token rotation", "token revocation", "immediate revocation",
        "server-side token revocation", "logout invalidation",
    ],
    "WEB-A09-01": [
        "centralized audit logging", "audit logging", "authentication success",
        "authentication failure", "logout", "ip address", "timestamp", "siem",
    ],
    "WEB-A09-02": [
        "centralized audit logging", "audit logging", "alerts", "alerting", "siem",
        "anomalous failure", "monitoring enabled",
    ],
    "WEB-A09-03": [
        "centralized logging", "centralized audit logging", "logs shipped",
        "siem", "alerts", "alerting",
    ],
    "API-API2-01": [
        "refresh token rotation", "token rotation", "key rotation",
        "immediate revocation", "token revocation", "rotatable", "revocable",
        "short-lived jwt",
    ],
    "API-API2-02": [
        "jwt validation", "validate jwt", "issuer audience", "algorithm and expiry",
        "iss", "aud", "exp", "nbf", "oidc", "openid connect", "open id connect",
    ],
    "API-API2-04": [
        "never stored in frontend", "api credentials are never", "no client-side api keys",
        "server-side proxy", "secret scanning", "keys never in frontend",
    ],
    "API-API4-02": [
        "rate limiting", "rate limit", "waf rate limiting", "quota", "throttling",
    ],
    "API-API5-04": [
        "rbac authorization checks", "authorization checks", "per-role", "rbac",
        "permission checks",
    ],
    "API-API7-04": [
        "allowlist", "url allowlist", "domain allowlist", "egress allowlist",
    ],
    "API-API8-01": [
        "strict cors allowlist", "cors allowlist", "hsts", "secure headers",
    ],
    "API-API8-04": [
        "tls 1.2", "tls 1.3", "hsts", "https enforced", "tls enforced",
    ],
    "AI-LLM01-01": [
        "schema validated", "content filtered", "input validation",
        "prompt validation", "kept separate from system instructions",
        "separate from system instructions", "privilege separation",
        "user prompts are schema validated",
    ],
    "AI-LLM01-02": [
        "prompt-injection scanned", "prompt injection scanned", "sanitize retrieved content",
        "sanitized before entering llm context", "provenance tracked",
    ],
    "AI-LLM02-01": [
        "html escaped", "html-escaped", "dompurify", "csp", "content-security-policy",
    ],
    "AI-LLM03-01": [
        "tenant scoped", "provenance tracked", "audit ingestion", "authenticated ingestion",
        "dedicated ingestion service",
    ],
    "AI-LLM03-03": [
        "provenance tracked", "allowlist permitted document sources", "approved origins",
        "prompt-injection scanned",
    ],
    "AI-LLM03-04": [
        "anomaly detection", "retrieval quality monitoring", "human-review retrieved context",
        "retrieval monitoring",
    ],
    "AI-LLM04-01": [
        "rate limits", "rate limiting", "token limits", "quota", "throttling",
    ],
    "AI-LLM06-03": [
        "tenant scoped", "session isolation", "context isolation", "isolated between sessions",
        "per-session memory", "per-user memory",
    ],
    "AI-LLM06-04": [
        "pii is redacted", "pii redacted", "redacted before model calls",
        "sensitive data redaction", "secret redaction", "output filtering",
        "filtered for pii",
    ],
    "AI-LLM07-01": [
        "tool calls are allowlisted", "allowlisted tools", "least privilege scoped",
        "least-privilege scoped", "human approval", "permission scopes",
    ],
    "AI-LLM08-01": [
        "human approval", "write actions require approval", "approval for write actions",
        "allowlisted tools", "least privilege scoped", "least-privilege scoped",
    ],
    "AI-LLM07-05": [
        "pinned by content hash", "content hash pinned", "re-approval required",
        "tool definitions pinned", "manifest diffed", "diff tool manifests",
        "re-reviewed before use",
    ],
    "API-API8-05": [
        "introspection disabled", "disables graphql introspection", "playground disabled",
        "playground is disabled", "graphiql disabled", "introspection gated behind authentication",
    ],
    "API-API2-05": [
        "algorithm pinned", "single expected algorithm", "explicit algorithm allowlist",
        "verification paths fully separate", "public key reused as an hmac secret",
        "rejects alg none",
    ],
    "AI-LLM10-01": [
        "rate limits", "rate limiting", "token rate limits", "quota", "quotas",
        "throttling", "protect inference endpoints",
    ],
    "AI-LLM10-02": [
        "anomaly detection", "query pattern monitoring", "api usage monitoring",
        "centralized logs", "model query monitoring",
    ],
    "CLD-CSA03-01": [
        "short expiry", "expires within minutes", "short-lived presigned url",
        "time-limited presigned url", "expires in minutes",
    ],
    "CLD-CSA08-01": [
        "alerts for unusual data volume", "bulk download alerts",
        "off-hours access alerting", "anomalous access alerting",
        "data access anomaly detection",
    ],
}

_RULE_REQUIRED_CONTEXT: dict[str, list[str]] = {
    "WEB-A01-01": [
        "record", "user_id", "account_id", "resource", "entity", "object id",
        "row", "tenant", "ownership", "object-level",
    ],
    "WEB-A01-03": [
        "static", "upload", "file server", "media", "assets", "directory listing",
        "public file", "public bucket", "anonymous read", "signed url",
    ],
    "API-API2-04": [
        "api key", "secret", "credential", "client-side", "javascript",
        "mobile app", "query parameter", "git", "version control",
    ],
    "API-API5-02": [
        "delete", "put", "patch", "http method", "method restriction",
    ],
    "API-API5-04": [
        "authorization", "access control", "permission", "role", "function",
        "privileged", "admin",
    ],
    "AI-LLM06-03": [
        "session", "conversation history", "memory", "user session",
        "chat history", "shared context",
    ],
    "AI-LLM09-03": [
        "confidence", "uncertainty", "hallucination", "accuracy",
        "validation", "threshold", "reliability",
    ],
    "AI-LLM10-01": [
        "inference", "api endpoint", "public api", "public endpoint",
        "external access", "rate limit", "quota",
    ],
    "AI-LLM10-02": [
        "query log", "monitoring", "analytics", "anomaly",
        "inference", "api usage", "model query",
    ],
    "AI-LLM10-03": [
        "model output", "api response", "inference output",
        "model response", "public endpoint",
    ],
}


def _effective_risk(severity: str, status: Status) -> str:
    if status == "PASS":
        return "Info"
    if status == "FAIL":
        return severity
    return {
        "Critical": "High",
        "High": "Medium",
        "Medium": "Low",
        "Low": "Low",
        "Info": "Info",
    }.get(severity, "Medium")


def _pattern_matches(text_lower: str, pattern: str) -> bool:
    pattern_lower = pattern.strip().lower()
    if not pattern_lower:
        return False
    if re.search(r"[^a-z0-9_\-\s]", pattern_lower):
        return pattern_lower in text_lower

    parts = [re.escape(part) for part in re.split(r"[\s_-]+", pattern_lower) if part]
    if not parts:
        return False
    expression = r"(?<![a-z0-9])" + r"[\s_-]+".join(parts) + r"(?![a-z0-9])"
    return bool(re.search(expression, text_lower))


def _matched_patterns(text_lower: str, patterns: list[str]) -> list[str]:
    return [pattern for pattern in patterns if _pattern_matches(text_lower, pattern)]


def _pattern_weight(pattern: str) -> int:
    pattern_lower = pattern.strip().lower()
    if not pattern_lower:
        return 0
    if pattern_lower in _BROAD_PATTERNS:
        return 1
    if (
        pattern_lower in _HIGH_SIGNAL_SHORT_PATTERNS
        or len(pattern_lower) >= 6
        or re.search(r"[\s_/\-():*.]", pattern_lower)
        or any(ch.isdigit() for ch in pattern_lower)
    ):
        return 3
    return 2


def _has_sufficient_evidence(triggered: list[str], text_lower: str, extra_risk: bool = False) -> bool:
    if not triggered:
        return False

    explicit_risk = extra_risk or any(_pattern_matches(text_lower, signal) for signal in _RISK_SIGNALS)
    score = sum(_pattern_weight(pattern) for pattern in triggered)
    strong_hits = sum(1 for pattern in triggered if _pattern_weight(pattern) >= 3)

    if explicit_risk and score >= 1:
        return True
    if strong_hits >= 1 and score >= 3:
        return True
    return score >= 3 and len(triggered) >= 2


# Negation cues that flip a control mention into evidence the control is ABSENT.
# "no SAST", "without MFA", "lacks encryption", "not enforced" must not be read as
# the control being present (which would suppress the very finding it describes).
_NEGATION_RE = re.compile(
    r"\b(no|not|without|lacks?|lacking|missing|absent|never|none|"
    r"zero|disabled|neither|nor)\b|n't")
_NEGATION_WINDOW = 40
# A negation cue must belong to the SAME clause as the phrase it negates. Without
# this, a cue word attached to an earlier, unrelated clause (e.g. "debug disabled;
# private by default" — "disabled" negates "debug", not "private by default")
# bleeds across the sentence boundary and produces a false negation.
_CLAUSE_BOUNDARY_RE = re.compile(r"[.;,\n]")


def _control_is_negated(text_lower: str, phrase: str) -> bool:
    """True when EVERY occurrence of a control phrase is preceded by a negation.

    Conservative: one un-negated mention (the control described as present) means
    the control counts as evidence and the phrase is kept. Only phrases whose
    every occurrence sits behind a negation cue are dropped.
    """
    plow = phrase.strip().lower()
    if not plow:
        return False
    # Locate occurrences with the same token-boundary semantics as matching.
    if re.search(r"[^a-z0-9_\-\s]", plow):
        spans = [(m.start(), m.end()) for m in re.finditer(re.escape(plow), text_lower)]
    else:
        parts = [re.escape(p) for p in re.split(r"[\s_-]+", plow) if p]
        if not parts:
            return False
        expr = r"(?<![a-z0-9])" + r"[\s_-]+".join(parts) + r"(?![a-z0-9])"
        spans = [(m.start(), m.end()) for m in re.finditer(expr, text_lower)]
    if not spans:
        return False
    for start, _ in spans:
        window_start = max(0, start - _NEGATION_WINDOW)
        boundary_matches = list(_CLAUSE_BOUNDARY_RE.finditer(text_lower, window_start, start))
        if boundary_matches:
            window_start = max(window_start, boundary_matches[-1].end())
        window = text_lower[window_start:start]
        if not _NEGATION_RE.search(window):
            return False   # a non-negated mention -> the control is real
    return True            # every mention was negated


def _control_signal_pool(rule_id: str, rule: dict | None, ruleset: str | None) -> list[str]:
    signals = list(_CONTROL_EVIDENCE.get(rule_id, []))
    if rule:
        signals.extend(enrich_rule(rule, ruleset=ruleset).get("positive_control_examples", []))
    return signals


def _control_evidence(rule_id: str, text_lower: str, rule: dict | None = None, ruleset: str | None = None) -> list[str]:
    signals = _control_signal_pool(rule_id, rule, ruleset)
    return _dedupe_matches([
        signal for signal in signals
        if _pattern_matches(text_lower, signal)
        and not _control_is_negated(text_lower, signal)])


def _negated_control_signals(rule_id: str, text_lower: str, rule: dict | None = None, ruleset: str | None = None) -> list[str]:
    """Control phrases mentioned but explicitly negated ("not redacted", "no MFA").

    A negated control mention is discarded from _control_evidence (it must not
    suppress the finding) but it is precise, rule-specific evidence that the risk
    IS present — often more targeted than the generic RISK_SIGNALS phrase list.
    """
    signals = _control_signal_pool(rule_id, rule, ruleset)
    return _dedupe_matches([
        signal for signal in signals
        if _pattern_matches(text_lower, signal)
        and _control_is_negated(text_lower, signal)])


def _dedupe_matches(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
    return result


def _rule_context_evidence(rule_id: str, text_lower: str) -> list[str]:
    return [signal for signal in _RULE_REQUIRED_CONTEXT.get(rule_id, []) if _pattern_matches(text_lower, signal)]


def _check_rule(architecture_text: str, rule: dict, ruleset: str | None = None) -> dict:
    """Evaluate one rule against architecture text. Returns result dict."""
    text_lower = architecture_text.lower()
    rule_id = rule["id"]
    resolved_ruleset = ruleset or infer_ruleset(rule)
    patterns = rule.get("patterns_to_check", [])
    triggered = _matched_patterns(text_lower, patterns)

    not_applicable = False
    if rule_id.startswith("AI-LLM"):
        ai_detection = detect_ai_architecture(architecture_text)
        not_applicable = not is_ai_analysis_applicable(ai_detection)

    negated_controls = _negated_control_signals(rule_id, text_lower, rule, resolved_ruleset)
    explicit_risk = bool(negated_controls) or any(_pattern_matches(text_lower, sig) for sig in _RISK_SIGNALS)
    control_evidence = _control_evidence(rule_id, text_lower, rule, resolved_ruleset)
    context_evidence = _rule_context_evidence(rule_id, text_lower)
    context_required = rule_id in _RULE_REQUIRED_CONTEXT
    sufficient_evidence = _has_sufficient_evidence(triggered, text_lower, extra_risk=bool(negated_controls)) and (
        explicit_risk or not context_required or bool(context_evidence)
    )

    if not_applicable:
        status: Status = "PASS"
        match_confidence = "not_applicable"
    elif sufficient_evidence and rule.get("severity") in ("Critical", "High") and explicit_risk:
        status = "FAIL"
        match_confidence = "high"
    elif control_evidence:
        status = "PASS"
        match_confidence = "positive_control"
    elif not sufficient_evidence:
        status = "PASS"
        match_confidence = "low"
    else:
        status = "WARN"
        match_confidence = "medium"
    effective_risk = _effective_risk(rule["severity"], status)

    owasp_ref: dict = {}
    category = rule.get("category", "")
    if category and category.startswith("API") and category in OWASP_API_TOP10:
        entry = OWASP_API_TOP10[category]
        owasp_ref = {"id": entry["id"], "name": entry["name"]}
    elif category and category.startswith("LLM") and category in OWASP_LLM_TOP10:
        entry = OWASP_LLM_TOP10[category]
        owasp_ref = {"id": entry["id"], "name": entry["name"]}
    elif category and category in OWASP_TOP10:
        entry = OWASP_TOP10[category]
        owasp_ref = {"id": entry["id"], "name": entry["name"]}

    enrichment = enrich_rule(
        rule,
        ruleset=resolved_ruleset,
        triggered_patterns=triggered,
        control_evidence=control_evidence,
        context_evidence=context_evidence,
        match_confidence=match_confidence,
    )

    result: dict = {
        "rule_id": rule_id,
        "question": rule["question"],
        "rationale": rule.get("rationale", ""),
        "severity": rule["severity"],
        "status": status,
        "effective_risk": effective_risk,
        "triggered_patterns": triggered,
        "control_evidence": control_evidence,
        "context_evidence": context_evidence,
        "match_confidence": match_confidence,
        "mitigations": rule.get("mitigations", []),
        "references": rule.get("references", []),
        **enrichment,
    }
    if owasp_ref:
        result["owasp_reference"] = owasp_ref
    return result


ALL_RULES: dict[str, list[dict]] = {
    "web":          WEB_RULES,
    "ai":           AI_RULES,
    "api":          API_RULES,
    "mobile":       MOBILE_RULES,
    "cloud":        CLOUD_RULES,
    "architecture": ARCHITECTURE_RULES,
    "devsecops":    DEVSECOPS_RULES,
}


_MOBILE_SIGNALS      = ["mobile", "ios", "android", "react native", "flutter", "swift", "kotlin", "apk", "ipa", "webview"]
_CLOUD_SIGNALS       = ["aws", "azure", "gcp", "cloud", "s3 ", "ec2", "lambda", "kubernetes", "k8s", "terraform", "vpc", "iam role"]
_DEVSECOPS_SIGNALS   = ["ci/cd", "pipeline", "github actions", "jenkins", "gitlab", "deploy", "build", "sast", "dast", "developer", "sdlc"]
_ARCHITECTURE_SIGNALS = ["architecture", "design", "system", "service", "component", "network", "infrastructure", "zero trust", "rbac", "access control"]


def detect_applicable_rulesets(architecture_text: str) -> list[str]:
    """Auto-detect applicable rulesets using keyword matching (no API key required)."""
    text_lower = architecture_text.lower()
    rulesets = []
    if any(_pattern_matches(text_lower, signal) for signal in _WEB_SIGNALS):
        rulesets.append("web")
    api = detect_api_architecture(architecture_text)
    if api.get("is_api") and api.get("confidence") in ("high", "medium"):
        rulesets.append("api")
    rulesets.append("architecture")
    ai = detect_ai_architecture(architecture_text)
    if is_ai_analysis_applicable(ai):
        rulesets.append("ai")
    if any(_pattern_matches(text_lower, sig) for sig in _MOBILE_SIGNALS):
        rulesets.append("mobile")
    if any(_pattern_matches(text_lower, sig) for sig in _CLOUD_SIGNALS):
        rulesets.append("cloud")
    if any(_pattern_matches(text_lower, sig) for sig in _DEVSECOPS_SIGNALS):
        rulesets.append("devsecops")
    return rulesets


def run_offline_review(
    architecture_text: str,
    rulesets: list[str] | None = None,
) -> dict:
    """
    Run deterministic offline review against architecture text.

    Args:
        architecture_text: Raw text description of the architecture.
        rulesets: List of ruleset names ("web", "ai", "api"). Auto-detected if None.

    Returns:
        Dict with findings (per-rule PASS/WARN/FAIL), summary counts,
        overall_risk, and top recommendations.
    """
    if rulesets is None:
        rulesets = detect_applicable_rulesets(architecture_text)

    findings: list[dict] = []
    for name in rulesets:
        rules = ALL_RULES.get(name, [])
        for rule in rules:
            result = _check_rule(architecture_text, rule, name)
            result["ruleset"] = name
            result["category"] = rule.get("category", "")
            findings.append(result)

    fail_f = [f for f in findings if f["status"] == "FAIL"]
    warn_f = [f for f in findings if f["status"] == "WARN"]
    pass_f = [f for f in findings if f["status"] == "PASS"]

    sev_counts: dict[str, int] = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
    risk_counts: dict[str, int] = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
    for f in fail_f + warn_f:
        sev_counts[f["severity"]] = sev_counts.get(f["severity"], 0) + 1
        risk = f.get("effective_risk", f["severity"])
        risk_counts[risk] = risk_counts.get(risk, 0) + 1

    if risk_counts["Critical"] > 0:
        overall_risk = "Critical"
    elif risk_counts["High"] >= 2:
        overall_risk = "High"
    elif risk_counts["High"] > 0 or risk_counts["Medium"] >= 3:
        overall_risk = "Medium"
    else:
        overall_risk = "Low"

    top_active = sorted(
        fail_f + warn_f,
        key=lambda r: (_SEV_RANK.get(r.get("effective_risk", r["severity"]), 5), r["rule_id"]),
    )
    recommendations = []
    for r in top_active[:5]:
        guidance = (r.get("implementation_guidance") or r.get("mitigations") or ["Review and remediate the control gap."])[0]
        recommendations.append(
            f"[{r.get('effective_risk', r['severity'])}] {r.get('pattern_name', r['rule_id'])}: {guidance}"
        )

    return {
        "methodology": "Offline Review",
        "rulesets_applied": rulesets,
        "total_rules": len(findings),
        "findings": findings,
        "summary_counts": {
            "total": len(findings),
            "fail": len(fail_f),
            "warn": len(warn_f),
            "pass": len(pass_f),
            "by_severity": sev_counts,
            "by_effective_risk": risk_counts,
        },
        "overall_risk": overall_risk,
        "recommendations": recommendations,
    }
