"""Tests for confidence_decay.py -- confidence erosion + forced
re-verification for correlated findings whose evidence has gone stale.

report_db/suppressions/verdict_tracking are isolated onto temp stores, same
pattern as test_dashboard.py/test_fleet.py. Age is seeded by calling
verdict_tracking.record_transitions with an explicit past ``now``, then
reading decay at a later ``now`` -- the same two-clock trick
test_verdict_tracking.py's SLA tests already use.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

import confidence_decay
import report_db
import suppressions
import verdict_tracking
from suppressions import db as supp_db
from suppressions import finding_fingerprint
from suppressions import store as supp_store

_DAY = 86400.0


def _cat(cid, verdict, confidence, family="sql-injection", loci=None):
    return {"id": cid, "name": cid, "title": cid, "risk": "High", "family": family,
            "verdict": verdict, "confidence": confidence,
            "threats": [{"name": l} for l in (loci or [f"{cid}.py:1"])],
            "affected_components": loci or [f"{cid}.py:1"]}


def _report(rid, cats, methodology="correlation", title="R"):
    return {"id": rid, "title": title, "methodology": methodology,
            "overall_risk": cats[0]["risk"] if cats else "Info", "categories": cats}


class DecayMathTests(unittest.TestCase):
    def test_zero_age_returns_original_confidence(self):
        self.assertEqual(confidence_decay.decayed_confidence(0.8, "confirmed_exploitable", 0), 0.8)

    def test_confidence_halves_at_one_half_life(self):
        half_life = confidence_decay._HALF_LIFE_DAYS["confirmed_exploitable"]
        out = confidence_decay.decayed_confidence(0.8, "confirmed_exploitable", half_life)
        self.assertAlmostEqual(out, 0.4, places=6)

    def test_confidence_quarters_at_two_half_lives(self):
        half_life = confidence_decay._HALF_LIFE_DAYS["confirmed_exploitable"]
        out = confidence_decay.decayed_confidence(0.8, "confirmed_exploitable", 2 * half_life)
        self.assertAlmostEqual(out, 0.2, places=6)

    def test_unknown_verdict_uses_default_half_life(self):
        out = confidence_decay.decayed_confidence(0.8, "not-a-real-verdict",
                                                   confidence_decay._DEFAULT_HALF_LIFE)
        self.assertAlmostEqual(out, 0.4, places=6)

    def test_confidence_is_clamped_to_0_1_before_decay(self):
        out = confidence_decay.decayed_confidence(1.5, "confirmed_exploitable", 0)
        self.assertEqual(out, 1.0)

    def test_needs_reverification_false_before_half_life(self):
        half_life = confidence_decay._HALF_LIFE_DAYS["actively_exploited"]
        self.assertFalse(confidence_decay.needs_reverification("actively_exploited", half_life - 1))

    def test_needs_reverification_true_at_half_life(self):
        half_life = confidence_decay._HALF_LIFE_DAYS["actively_exploited"]
        self.assertTrue(confidence_decay.needs_reverification("actively_exploited", half_life))

    def test_actively_exploited_decays_faster_than_design_gap(self):
        self.assertLess(confidence_decay._HALF_LIFE_DAYS["actively_exploited"],
                        confidence_decay._HALF_LIFE_DAYS["design_gap"])


class AnnotateRowsTests(unittest.TestCase):
    def setUp(self):
        self._op = verdict_tracking.DB_PATH
        self.addCleanup(lambda: setattr(verdict_tracking, "DB_PATH", self._op))
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def test_never_correlated_fingerprint_gets_zero_age_and_not_stale(self):
        rows = confidence_decay.annotate_rows([
            {"fingerprint": "never-seen", "verdict": "confirmed_exploitable", "confidence": 0.9}])
        self.assertEqual(rows[0]["age_days"], 0.0)
        self.assertEqual(rows[0]["decayed_confidence"], 0.9)
        self.assertFalse(rows[0]["needs_reverification"])

    def test_aged_fingerprint_decays_and_flags_stale(self):
        t0 = 1_000_000.0
        cat = {"id": "A", "name": "A", "family": "xss", "verdict": "confirmed_exploitable",
              "affected_components": ["a.py:1"]}
        verdict_tracking.record_transitions({"id": "r1", "categories": [cat]}, now=t0)
        half_life = confidence_decay._HALF_LIFE_DAYS["confirmed_exploitable"]
        later = t0 + half_life * _DAY

        rows = confidence_decay.annotate_rows([
            {"fingerprint": finding_fingerprint(cat),
             "verdict": "confirmed_exploitable", "confidence": 0.8}], now=later)
        self.assertAlmostEqual(rows[0]["age_days"], half_life, places=1)
        self.assertAlmostEqual(rows[0]["decayed_confidence"], 0.4, places=1)
        self.assertTrue(rows[0]["needs_reverification"])


class WorklistAndSummaryTests(unittest.TestCase):
    def setUp(self):
        self._orp = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self._ovp = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        supp_db.init()
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        report_db.DB_PATH = self._orp
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp
        verdict_tracking.DB_PATH = self._ovp

    def test_uncorrelated_report_finding_has_no_history_and_is_not_stale(self):
        report_db.upsert_report(_report("r1", [_cat("A", "confirmed_exploitable", 0.9)]))
        items = confidence_decay.worklist()
        self.assertEqual(items, [])
        s = confidence_decay.summary()
        self.assertEqual(s["total"], 1)
        self.assertEqual(s["tracked"], 0)
        self.assertEqual(s["needs_reverification"], 0)

    def test_stale_finding_appears_in_worklist_and_summary(self):
        cat = _cat("A", "confirmed_exploitable", 0.9)
        report = _report("r1", [cat])
        report_db.upsert_report(report)
        t0 = 2_000_000.0
        verdict_tracking.record_transitions(report, now=t0)

        half_life = confidence_decay._HALF_LIFE_DAYS["confirmed_exploitable"]
        later = t0 + (half_life + 1) * _DAY
        with mock.patch("time.time", return_value=later):
            items = confidence_decay.worklist()
            s = confidence_decay.summary()
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["report_id"], "r1")
        self.assertTrue(items[0]["needs_reverification"])
        self.assertEqual(s["needs_reverification"], 1)
        self.assertGreater(s["avg_confidence_erosion"], 0)

    def test_suppressed_finding_excluded_from_worklist(self):
        cat = _cat("A", "confirmed_exploitable", 0.9)
        report = _report("r1", [cat])
        report_db.upsert_report(report)
        t0 = 3_000_000.0
        verdict_tracking.record_transitions(report, now=t0)
        suppressions.add_suppression({
            "scope": "rule", "match": "A", "reason": "accepted", "author": "carol"})

        half_life = confidence_decay._HALF_LIFE_DAYS["confirmed_exploitable"]
        later = t0 + (half_life + 1) * _DAY
        with mock.patch("time.time", return_value=later):
            items = confidence_decay.worklist()
        self.assertEqual(items, [])

    def test_sast_dast_methodologies_excluded(self):
        report_db.upsert_report(_report("r1", [_cat("A", "confirmed_exploitable", 0.9)],
                                        methodology="sast"))
        s = confidence_decay.summary()
        self.assertEqual(s["total"], 0)


class VerdictTrackingSinceMapTests(unittest.TestCase):
    def setUp(self):
        self._op = verdict_tracking.DB_PATH
        self.addCleanup(lambda: setattr(verdict_tracking, "DB_PATH", self._op))
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def test_empty_input_returns_empty_map(self):
        self.assertEqual(verdict_tracking.since_map([]), {})

    def test_unknown_fingerprint_absent_from_result(self):
        self.assertEqual(verdict_tracking.since_map(["nope"]), {})

    def test_known_fingerprint_maps_to_verdict_since(self):
        cat = {"id": "A", "name": "A", "family": "xss", "verdict": "blind_spot",
              "affected_components": ["a.py:1"]}
        from suppressions import finding_fingerprint
        fp = finding_fingerprint(cat)
        verdict_tracking.record_transitions({"id": "r1", "categories": [cat]}, now=500.0)
        out = verdict_tracking.since_map([fp])
        self.assertEqual(out[fp], 500.0)


class ConfidenceApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orp = report_db.DB_PATH
        self._ovp = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        report_db.DB_PATH = self._orp
        verdict_tracking.DB_PATH = self._ovp

    def test_summary_endpoint(self):
        resp = self.client.get("/api/v1/confidence/summary")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["total"], 0)

    def test_worklist_endpoint(self):
        resp = self.client.get("/api/v1/confidence/worklist")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["worklist"], [])

    def test_worklist_rejects_bad_limit(self):
        resp = self.client.get("/api/v1/confidence/worklist?limit=notanumber")
        self.assertEqual(resp.status_code, 400)


if __name__ == "__main__":
    unittest.main()
