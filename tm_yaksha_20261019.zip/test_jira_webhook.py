"""Tests for the Jira-triggered proactive design-review webhook (api/design_review.py).

The analyzer call and the Jira comment-back are both mocked out — this suite
proves the adapter path (secret verification, event filtering, ADF/plain-text
extraction, report save, best-effort comment) without a real LLM call or a
real Jira instance, same spirit as test_broker.py's TestWebhookFlow.
"""
from __future__ import annotations

import json
import threading
import time
import unittest
from unittest import mock

import app as tm_app  # noqa: F401 — must import before api.design_review (see its
                       # `import app as tm_app` for the rate limiter: importing the
                       # submodule directly first would re-enter app.py's blueprint
                       # registration mid-way through api.design_review's own load.
from api import design_review
import jira_client


def _reset_limiter():
    # The webhook is rate-limited (20/minute, api/design_review.py) against
    # flask-limiter's in-memory storage, which persists for the life of the
    # process rather than being test-isolated. This file alone posts to it
    # more than 20 times, so each _post() resets the counter first — a single
    # upfront reset wouldn't be enough, since the file's total request count
    # exceeds the limit regardless of where in the run counting starts.
    tm_app.limiter.storage.reset()


def _body(payload: dict) -> bytes:
    return json.dumps(payload).encode()


_ISSUE_CREATED_PLAIN = {
    "webhookEvent": "jira:issue_created",
    "issue": {"key": "SEC-101", "fields": {
        "summary": "New payments microservice",
        "description": "A Flask service that takes a card token from the client "
                       "and calls the PSP API directly, no server-side validation yet.",
    }},
}

_ADF_DESCRIPTION = {
    "type": "doc", "version": 1,
    "content": [
        {"type": "paragraph", "content": [
            {"type": "text", "text": "Service reads "},
            {"type": "text", "text": "user-supplied redirect URLs"},
            {"type": "text", "text": " from a query param."},
        ]},
    ],
}

_ISSUE_UPDATED_ADF = {
    "webhookEvent": "jira:issue_updated",
    "issue": {"key": "SEC-102", "fields": {
        "summary": "Open redirect risk in login flow",
        "description": _ADF_DESCRIPTION,
    }},
}

_FAKE_REPORT = {
    "title": "Design Review · SEC-101",
    "overall_risk": "High",
    "summary": "Card data flows without server-side validation.",
    "categories": [
        {"id": "A02", "name": "Cryptographic Failures", "risk": "High"},
        {"id": "A04", "name": "Insecure Design", "risk": "Medium"},
    ],
}


class TestAdfExtraction(unittest.TestCase):
    """adf_to_text itself now lives in jira_client.py (promoted from this
    module's former private copy so get_issue/get_issue_comments can reuse
    it too) -- these tests exercise it through that import."""

    def test_plain_string_passthrough(self):
        self.assertEqual(jira_client.adf_to_text("plain text"), "plain text")

    def test_adf_doc_flattened(self):
        text = jira_client.adf_to_text(_ADF_DESCRIPTION)
        self.assertIn("user-supplied redirect URLs", text)
        self.assertIn("query param", text)

    def test_non_dict_non_str_is_empty(self):
        self.assertEqual(jira_client.adf_to_text(None), "")
        self.assertEqual(jira_client.adf_to_text(42), "")

    def test_ticket_text_prefers_adf_body(self):
        summary, desc = design_review._ticket_text(_ISSUE_UPDATED_ADF["issue"])
        self.assertEqual(summary, "Open redirect risk in login flow")
        self.assertIn("redirect URLs", desc)


class TestWebhookAuth(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.client = tm_app.app.test_client()

    def _post(self, payload, headers=None, qs=""):
        _reset_limiter()
        return self.client.post(
            "/api/v1/design-review/webhook" + qs,
            data=_body(payload),
            headers={"Content-Type": "application/json", **(headers or {})})

    def test_no_secret_configured_rejected(self):
        with mock.patch.object(design_review, "_webhook_secret", return_value=""):
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 401)

    def test_wrong_secret_rejected(self):
        with mock.patch.object(design_review, "_webhook_secret", return_value="right-secret"):
            r = self._post(_ISSUE_CREATED_PLAIN, headers={"X-TM-Webhook-Secret": "wrong"})
        self.assertEqual(r.status_code, 401)

    def test_missing_secret_header_rejected(self):
        with mock.patch.object(design_review, "_webhook_secret", return_value="right-secret"):
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 401)

    def test_correct_secret_via_header_accepted(self):
        with mock.patch.object(design_review, "_webhook_secret", return_value="right-secret"), \
             mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=None):
            r = self._post(_ISSUE_CREATED_PLAIN, headers={"X-TM-Webhook-Secret": "right-secret"})
        self.assertEqual(r.status_code, 202, r.get_data(as_text=True))

    def test_correct_secret_via_query_param_accepted(self):
        with mock.patch.object(design_review, "_webhook_secret", return_value="right-secret"), \
             mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=None):
            r = self._post(_ISSUE_CREATED_PLAIN, qs="?secret=right-secret")
        self.assertEqual(r.status_code, 202, r.get_data(as_text=True))


class TestWebhookDispatch(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.client = tm_app.app.test_client()
        cls.secret_patch = mock.patch.object(
            design_review, "_webhook_secret", return_value="s3cr3t")
        cls.secret_patch.start()

    @classmethod
    def tearDownClass(cls):
        cls.secret_patch.stop()

    def _post(self, payload):
        _reset_limiter()
        return self.client.post(
            "/api/v1/design-review/webhook", data=_body(payload),
            headers={"Content-Type": "application/json", "X-TM-Webhook-Secret": "s3cr3t"})

    def test_ignored_event_type(self):
        r = self._post({"webhookEvent": "jira:issue_deleted", "issue": {"key": "X-1"}})
        self.assertEqual(r.status_code, 200)
        d = r.get_json()
        self.assertTrue(d["ignored"])

    def test_missing_issue_content_400(self):
        r = self._post({"webhookEvent": "jira:issue_created",
                        "issue": {"key": "X-2", "fields": {"summary": "", "description": ""}}})
        self.assertEqual(r.status_code, 400)

    def test_issue_created_runs_analysis_and_saves_report(self):
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)) as m_analyze, \
             mock.patch.object(jira_client, "config_from_env", return_value=None):
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 202, r.get_data(as_text=True))
        d = r.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["issue_key"], "SEC-101")
        self.assertTrue(d["report_id"])

        # The architecture text handed to the analyzer combines summary + description.
        (api_key, arch_text), kwargs = m_analyze.call_args
        self.assertIn("payments microservice", arch_text)
        self.assertIn("card token", arch_text)
        self.assertEqual(kwargs["title"], "Design Review · SEC-101")

        import report_db
        saved = report_db.list_reports(limit=5, methodology="design-review")
        self.assertTrue(any(r["id"] == d["report_id"] for r in saved))

    def test_adf_description_is_flattened_before_analysis(self):
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)) as m_analyze, \
             mock.patch.object(jira_client, "config_from_env", return_value=None):
            r = self._post(_ISSUE_UPDATED_ADF)
        self.assertEqual(r.status_code, 202)
        (_api_key, arch_text), _kwargs = m_analyze.call_args
        self.assertIn("redirect URLs", arch_text)

    def test_comment_posted_back_on_success(self):
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net",
                                       jira_email="a@b.com", jira_token="tok")
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch.object(jira_client, "add_comment") as m_comment:
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 202)
        m_comment.assert_called_once()
        args, _ = m_comment.call_args
        self.assertEqual(args[0], cfg)
        self.assertEqual(args[1], "SEC-101")
        self.assertIn("High", args[2])

    def test_comment_includes_technical_description_and_fix(self):
        report = dict(_FAKE_REPORT)
        report["categories"] = [{
            "id": "A02", "name": "Cryptographic Failures", "risk": "High",
            "description": "Card PAN is transmitted to the payments service over plain HTTP.",
            "mitigations": [{"action": "Enforce TLS 1.2+ on the payments endpoint.",
                             "priority": "Short-term"}],
        }]
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net",
                                       jira_email="a@b.com", jira_token="tok")
        with mock.patch("analyzer.analyze", return_value=report), \
             mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch.object(jira_client, "add_comment") as m_comment:
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 202)
        body = m_comment.call_args[0][2]
        self.assertIn("Card PAN is transmitted", body)
        self.assertIn("Fix: Enforce TLS 1.2+", body)

    def test_comment_clips_long_description(self):
        report = dict(_FAKE_REPORT)
        report["categories"] = [{"id": "A02", "name": "Cryptographic Failures", "risk": "High",
                                 "description": "x" * 500}]
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net",
                                       jira_email="a@b.com", jira_token="tok")
        with mock.patch("analyzer.analyze", return_value=report), \
             mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch.object(jira_client, "add_comment") as m_comment:
            self._post(_ISSUE_CREATED_PLAIN)
        body = m_comment.call_args[0][2]
        self.assertIn("x" * 299 + "…", body)
        self.assertNotIn("x" * 300, body)

    def test_comment_without_description_or_mitigations_still_works(self):
        # _FAKE_REPORT's categories carry no description/mitigations at all -
        # the original, unenriched shape must not raise or break the comment.
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net",
                                       jira_email="a@b.com", jira_token="tok")
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch.object(jira_client, "add_comment") as m_comment:
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 202)
        m_comment.assert_called_once()

    def test_comment_failure_does_not_fail_webhook(self):
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net",
                                       jira_email="a@b.com", jira_token="tok")
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch.object(jira_client, "add_comment", side_effect=RuntimeError("jira down")):
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 202, r.get_data(as_text=True))

    def test_analysis_failure_returns_500(self):
        with mock.patch("analyzer.analyze", side_effect=RuntimeError("boom")):
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 500)

    def test_report_is_synced_into_lineage(self):
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=None), \
             mock.patch("lineage.service.sync") as m_sync:
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 202)
        m_sync.assert_called_once_with(r.get_json()["report_id"])

    def test_lineage_sync_failure_does_not_fail_webhook(self):
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=None), \
             mock.patch("lineage.service.sync", side_effect=RuntimeError("db locked")):
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 202, r.get_data(as_text=True))

    def test_predicted_threat_appears_in_lineage_after_a_real_sync(self):
        """End-to-end (no mocked lineage.sync): a ticket whose description
        matches an OWASP category the fake analyzer returns should land in the
        lineage store as a 'predicted' threat, keyed by that category's family."""
        import tempfile
        from pathlib import Path

        from lineage import db as lineage_db
        orig_path = lineage_db.DB_PATH
        td = tempfile.TemporaryDirectory()
        lineage_db.DB_PATH = Path(td.name) / "lineage.db"
        try:
            report_with_locus = dict(_FAKE_REPORT)
            report_with_locus["categories"] = [
                {"id": "A02", "name": "Cryptographic Failures", "risk": "High",
                 "affected_components": ["payments card token handler"]},
            ]
            with mock.patch("analyzer.analyze", return_value=report_with_locus), \
                 mock.patch.object(jira_client, "config_from_env", return_value=None):
                r = self._post(_ISSUE_CREATED_PLAIN)
            self.assertEqual(r.status_code, 202)

            from lineage import service as lineage_service
            threats = lineage_service.list_threats(status="predicted")
            self.assertEqual(len(threats), 1)
            self.assertEqual(threats[0]["family"], "crypto-failure")
        finally:
            lineage_db.DB_PATH = orig_path
            td.cleanup()


class TestFindTargetRepo(unittest.TestCase):
    """Best-effort ticket -> registered-repo matching (see design_review.
    _find_target_repo's docstring for why this is the only signal available)."""

    def test_matches_by_component_name_case_insensitive(self):
        issue = {"fields": {"components": [{"name": "Payments API"}]}}
        repos = [{"id": "r1", "name": "payments api"}, {"id": "r2", "name": "other"}]
        with mock.patch("broker.config.load_repos", return_value=repos):
            repo = design_review._find_target_repo(issue)
        self.assertEqual(repo["id"], "r1")

    def test_matches_by_project_key(self):
        issue = {"fields": {"project": {"key": "SEC"}}}
        repos = [{"id": "r1", "name": "SEC"}]
        with mock.patch("broker.config.load_repos", return_value=repos):
            repo = design_review._find_target_repo(issue)
        self.assertEqual(repo["id"], "r1")

    def test_no_match_returns_none(self):
        issue = {"fields": {"components": [{"name": "Nope"}]}}
        with mock.patch("broker.config.load_repos",
                        return_value=[{"id": "r1", "name": "other"}]):
            self.assertIsNone(design_review._find_target_repo(issue))

    def test_no_candidates_skips_loading_repos_entirely(self):
        with mock.patch("broker.config.load_repos") as m:
            self.assertIsNone(design_review._find_target_repo({"fields": {}}))
        m.assert_not_called()

    def test_broker_unavailable_returns_none(self):
        issue = {"fields": {"project": {"key": "SEC"}}}
        with mock.patch("broker.config.load_repos", side_effect=RuntimeError("no broker")):
            self.assertIsNone(design_review._find_target_repo(issue))


class TestRescanTrigger(unittest.TestCase):
    """A ticket that names a registered repo (by component or project key)
    must queue a background SAST+code-model+correlation pipeline run for it —
    see design_review._rescan_affected_repo_background."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.client = tm_app.app.test_client()
        cls.secret_patch = mock.patch.object(
            design_review, "_webhook_secret", return_value="s3cr3t")
        cls.secret_patch.start()

    @classmethod
    def tearDownClass(cls):
        cls.secret_patch.stop()

    def _post(self, payload):
        _reset_limiter()
        return self.client.post(
            "/api/v1/design-review/webhook", data=_body(payload),
            headers={"Content-Type": "application/json", "X-TM-Webhook-Secret": "s3cr3t"})

    def test_matching_component_queues_background_rescan(self):
        payload = {
            "webhookEvent": "jira:issue_created",
            "issue": {"key": "SEC-201", "fields": {
                "summary": "Payments redesign",
                "description": "New checkout flow.",
                "components": [{"name": "payments-api"}],
            }},
        }
        done = threading.Event()

        def fake_run(repo, **kw):
            done.set()
            return {"correlation_report_id": "corr_1"}

        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=None), \
             mock.patch("lineage.service.sync"), \
             mock.patch("broker.config.load_repos",
                        return_value=[{"id": "repo1", "name": "payments-api"}]), \
             mock.patch("broker.pipeline.run", side_effect=fake_run) as m_run:
            r = self._post(payload)
            self.assertEqual(r.status_code, 202, r.get_data(as_text=True))
            d = r.get_json()
            self.assertEqual(d["rescan"], "queued")
            self.assertEqual(d["rescan_repo_id"], "repo1")
            self.assertTrue(done.wait(timeout=2), "pipeline.run was not called in background")
            time.sleep(0.05)   # let the background thread's finally: release() land
        m_run.assert_called_once()
        self.assertEqual(m_run.call_args[0][0]["id"], "repo1")

    def test_no_matching_repo_skips_rescan(self):
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=None), \
             mock.patch("lineage.service.sync"), \
             mock.patch("broker.config.load_repos",
                        return_value=[{"id": "repo1", "name": "unrelated"}]), \
             mock.patch("broker.pipeline.run") as m_run:
            r = self._post(_ISSUE_CREATED_PLAIN)
        self.assertEqual(r.status_code, 202)
        d = r.get_json()
        self.assertEqual(d["rescan"], "skipped")
        self.assertIsNone(d["rescan_repo_id"])
        m_run.assert_not_called()

    def test_rescan_result_comment_posted_on_success(self):
        # The other half of the ticket-to-rescan loop: once pipeline.run()
        # succeeds, its correlation verdict must be posted back on the SAME
        # ticket as a follow-up comment — not just logged.
        payload = {
            "webhookEvent": "jira:issue_created",
            "issue": {"key": "SEC-203", "fields": {
                "summary": "Payments redesign",
                "description": "New checkout flow.",
                "components": [{"name": "payments-api"}],
            }},
        }
        corr_report = {
            "overall_risk": "High",
            "summary": "Correlated 4 finding(s) from 2 report(s) into 2 weakness cluster(s). "
                       "1 confirmed exploitable (static + runtime agree), 1 corroborated "
                       "(design + evidence), 0 blind spot(s), 0 design gap(s). Sources: x, y.",
        }
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net",
                                       jira_email="a@b.com", jira_token="tok")
        calls = []
        done = threading.Event()

        def fake_add_comment(_cfg, _issue_key, body):
            calls.append(body)
            if len(calls) >= 2:   # 1st = immediate design-review comment, 2nd = rescan result
                done.set()

        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch("lineage.service.sync"), \
             mock.patch("broker.config.load_repos",
                        return_value=[{"id": "repo1", "name": "payments-api"}]), \
             mock.patch("broker.pipeline.run",
                        return_value={"correlation_report_id": "corr_9"}), \
             mock.patch("report_db.get_report", return_value=corr_report), \
             mock.patch.object(jira_client, "add_comment", side_effect=fake_add_comment):
            r = self._post(payload)
            self.assertEqual(r.status_code, 202, r.get_data(as_text=True))
            self.assertTrue(done.wait(timeout=2), "rescan-result comment was not posted")
            time.sleep(0.05)

        self.assertEqual(len(calls), 2)
        rescan_body = calls[1]
        self.assertIn("Rescan complete", rescan_body)
        self.assertIn("confirmed exploitable", rescan_body)
        self.assertIn("corr_9", rescan_body)

    def test_rescan_failure_does_not_fail_webhook(self):
        payload = {
            "webhookEvent": "jira:issue_created",
            "issue": {"key": "SEC-202", "fields": {
                "summary": "Payments redesign",
                "description": "New checkout flow.",
                "components": [{"name": "payments-api"}],
            }},
        }
        with mock.patch("analyzer.analyze", return_value=dict(_FAKE_REPORT)), \
             mock.patch.object(jira_client, "config_from_env", return_value=None), \
             mock.patch("lineage.service.sync"), \
             mock.patch("broker.config.load_repos",
                        return_value=[{"id": "repo1", "name": "payments-api"}]), \
             mock.patch("broker.pipeline.run", side_effect=RuntimeError("git fetch failed")):
            r = self._post(payload)
        self.assertEqual(r.status_code, 202, r.get_data(as_text=True))


class TestRescanResultCommentDirect(unittest.TestCase):
    """Direct unit tests for _post_rescan_comment_best_effort's edge cases —
    the through-the-webhook test above only covers the happy path."""

    def test_no_jira_config_is_noop(self):
        with mock.patch.object(jira_client, "config_from_env", return_value=None), \
             mock.patch.object(jira_client, "add_comment") as m_comment:
            design_review._post_rescan_comment_best_effort(
                "SEC-1", {"id": "r1"}, {"correlation_report_id": "corr_1"})
        m_comment.assert_not_called()

    def test_missing_correlation_report_id_is_noop(self):
        cfg = jira_client.TicketConfig(provider="jira")
        with mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch.object(jira_client, "add_comment") as m_comment:
            design_review._post_rescan_comment_best_effort("SEC-1", {"id": "r1"}, {})
        m_comment.assert_not_called()

    def test_report_not_found_is_noop(self):
        cfg = jira_client.TicketConfig(provider="jira")
        with mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch("report_db.get_report", return_value=None), \
             mock.patch.object(jira_client, "add_comment") as m_comment:
            design_review._post_rescan_comment_best_effort(
                "SEC-1", {"id": "r1"}, {"correlation_report_id": "corr_missing"})
        m_comment.assert_not_called()

    def test_add_comment_failure_does_not_raise(self):
        cfg = jira_client.TicketConfig(provider="jira")
        with mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch("report_db.get_report",
                        return_value={"overall_risk": "Low", "summary": "s"}), \
             mock.patch.object(jira_client, "add_comment",
                               side_effect=RuntimeError("jira down")):
            design_review._post_rescan_comment_best_effort(  # must not raise
                "SEC-1", {"id": "r1"}, {"correlation_report_id": "corr_1"})

    def test_comment_includes_repo_name_summary_and_link(self):
        cfg = jira_client.TicketConfig(provider="jira")
        report = {"overall_risk": "Critical", "summary": "1 confirmed exploitable finding."}
        with mock.patch.object(jira_client, "config_from_env", return_value=cfg), \
             mock.patch("report_db.get_report", return_value=report), \
             mock.patch("broker.config.PUBLIC_URL", "https://tm.internal"), \
             mock.patch.object(jira_client, "add_comment") as m_comment:
            design_review._post_rescan_comment_best_effort(
                "SEC-1", {"id": "r1", "name": "payments-api"},
                {"correlation_report_id": "corr_42"})
        m_comment.assert_called_once()
        body = m_comment.call_args[0][2]
        self.assertIn("payments-api", body)
        self.assertIn("Critical", body)
        self.assertIn("1 confirmed exploitable finding.", body)
        self.assertIn("https://tm.internal/#report=corr_42", body)


class TestRescanConcurrencyCap(unittest.TestCase):
    """Bounds how many pipeline runs a burst of webhook calls can trigger at
    once, isolated onto its own semaphore so it can't be flaked by timing in
    other tests sharing the module-level default."""

    def setUp(self):
        self._orig_sem = design_review._RESCAN_CONCURRENCY
        design_review._RESCAN_CONCURRENCY = threading.Semaphore(2)

    def tearDown(self):
        design_review._RESCAN_CONCURRENCY = self._orig_sem

    def test_concurrency_cap_skips_extra_rescans(self):
        gate = threading.Event()
        started = []

        def blocking_run(repo, **kw):
            started.append(repo["id"])
            gate.wait(timeout=2)
            return {"correlation_report_id": "x"}

        with mock.patch("broker.pipeline.run", side_effect=blocking_run):
            design_review._rescan_affected_repo_background({"id": "r1"}, "T-1")
            design_review._rescan_affected_repo_background({"id": "r2"}, "T-2")
            design_review._rescan_affected_repo_background({"id": "r3"}, "T-3")
            time.sleep(0.3)
            self.assertEqual(len(started), 2)   # only 2 concurrent slots
            gate.set()
            time.sleep(0.3)


class TestAddCommentJiraOnly(unittest.TestCase):
    def test_non_jira_provider_raises(self):
        cfg = jira_client.TicketConfig(provider="azure")
        with self.assertRaises(ValueError):
            jira_client.add_comment(cfg, "X-1", "hi")

    def test_jira_provider_posts_to_comment_endpoint(self):
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net/",
                                       jira_email="a@b.com", jira_token="tok")
        with mock.patch.object(jira_client, "_http", return_value={}) as m_http:
            jira_client.add_comment(cfg, "SEC-1", "hello world")
        (method, url, headers, payload), _ = m_http.call_args
        self.assertEqual(method, "POST")
        self.assertEqual(url, "https://x.atlassian.net/rest/api/3/issue/SEC-1/comment")
        self.assertEqual(payload["body"]["content"][0]["content"][0]["text"], "hello world")

    def test_multiline_comment_uses_hardbreaks_not_a_single_text_node(self):
        # Regression: the design-review comment is multi-line (summary, then a
        # bullet + description + fix line per category) — it must not collapse
        # into a run-on line, which a single ADF text node containing raw '\n'
        # characters would do.
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net/",
                                       jira_email="a@b.com", jira_token="tok")
        with mock.patch.object(jira_client, "_http", return_value={}) as m_http:
            jira_client.add_comment(cfg, "SEC-1", "line one\nline two\nline three")
        payload = m_http.call_args[0][3]
        para = payload["body"]["content"][0]["content"]
        self.assertEqual(
            para,
            [
                {"type": "text", "text": "line one"},
                {"type": "hardBreak"},
                {"type": "text", "text": "line two"},
                {"type": "hardBreak"},
                {"type": "text", "text": "line three"},
            ],
        )

    def test_blank_line_becomes_double_hardbreak_with_no_empty_text_node(self):
        # ADF text nodes must be non-empty, so a blank line ("") can't become
        # {"type": "text", "text": ""} — it's just two adjacent hardBreaks.
        cfg = jira_client.TicketConfig(provider="jira", jira_url="https://x.atlassian.net/",
                                       jira_email="a@b.com", jira_token="tok")
        with mock.patch.object(jira_client, "_http", return_value={}) as m_http:
            jira_client.add_comment(cfg, "SEC-1", "para one\n\npara two")
        para = m_http.call_args[0][3]["body"]["content"][0]["content"]
        self.assertEqual(
            para,
            [
                {"type": "text", "text": "para one"},
                {"type": "hardBreak"},
                {"type": "hardBreak"},
                {"type": "text", "text": "para two"},
            ],
        )
        for node in para:
            if node["type"] == "text":
                self.assertTrue(node["text"])   # never an empty text node


class TextToAdfTests(unittest.TestCase):
    """Direct tests for jira_client._text_to_adf, the shared ADF line-break
    builder used by both add_comment and _jira_create."""

    def test_empty_string_is_an_empty_paragraph(self):
        doc = jira_client._text_to_adf("")
        self.assertEqual(doc["content"], [{"type": "paragraph", "content": []}])

    def test_single_line_has_no_hardbreak(self):
        doc = jira_client._text_to_adf("just one line")
        content = doc["content"][0]["content"]
        self.assertEqual(content, [{"type": "text", "text": "just one line"}])

    def test_doc_envelope_shape(self):
        doc = jira_client._text_to_adf("x")
        self.assertEqual(doc["type"], "doc")
        self.assertEqual(doc["version"], 1)
        self.assertEqual(len(doc["content"]), 1)
        self.assertEqual(doc["content"][0]["type"], "paragraph")


if __name__ == "__main__":
    unittest.main()
