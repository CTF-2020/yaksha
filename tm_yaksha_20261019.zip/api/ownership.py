"""Owner assignment API -- verdict-bucket defaults + per-finding overrides.

Routes:
  GET    /api/v1/owners             distinct owner names currently in use
                                    (bucket defaults + per-finding overrides),
                                    for populating a filter dropdown
  GET    /api/v1/owners/defaults    verdict bucket -> default owner map
  POST   /api/v1/owners/defaults    set one bucket's default owner
                                    {verdict, owner} -- owner="" clears it
  GET    /api/v1/owners/assignments every per-finding override, newest first
  POST   /api/v1/owners/assign      set a per-finding override
                                    {fingerprint, owner, assigned_by?, note?}
                                    -- owner="" clears it (falls back to the
                                    bucket default)
  DELETE /api/v1/owners/assign/<fingerprint>   clear a per-finding override

Writes go through the same CSRF/auth gate as the rest of the app (enforced in
the app's before_request) -- triage ownership is an operational call any
analyst working the queue can make, not an admin-only action like the
account/flush routes in api/admin.py.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

import ownership

bp = Blueprint("ownership_api", __name__, url_prefix="/api/v1/owners")


@bp.get("")
def list_owners():
    names = {o for o in ownership.get_defaults().values() if o}
    names |= {a["owner"] for a in ownership.list_assignments() if a.get("owner")}
    return jsonify({"success": True, "owners": sorted(names)})


@bp.get("/defaults")
def get_defaults():
    return jsonify({"success": True, "defaults": ownership.get_defaults()})


@bp.post("/defaults")
def set_default():
    body = request.get_json(silent=True) or {}
    verdict = str(body.get("verdict") or "")
    owner = str(body.get("owner") or "")
    try:
        ownership.set_default(verdict, owner)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify({"success": True, "defaults": ownership.get_defaults()})


@bp.get("/assignments")
def list_assignments():
    return jsonify({"success": True, "assignments": ownership.list_assignments()})


@bp.post("/assign")
def assign():
    body = request.get_json(silent=True) or {}
    fingerprint = str(body.get("fingerprint") or "").strip()
    if not fingerprint:
        return jsonify({"success": False, "error": "fingerprint is required"}), 400
    owner = str(body.get("owner") or "")
    record = ownership.assign(fingerprint, owner,
                              assigned_by=str(body.get("assigned_by") or ""),
                              note=str(body.get("note") or ""))
    return jsonify({"success": True, "assignment": record})


@bp.delete("/assign/<path:fingerprint>")
def clear_assignment(fingerprint: str):
    removed = ownership.clear_assignment(fingerprint)
    if not removed:
        return jsonify({"success": False, "error": "no assignment for that fingerprint"}), 404
    return jsonify({"success": True, "cleared": fingerprint})
