"""Security posture dashboard API + page.

Routes:
  GET  /api/v1/dashboard         aggregated posture across every tool (read-only)
  GET  /api/v1/exec-summary      plain-English narrative rollup of the same data --
                                  a top-level route (not nested under /dashboard)
                                  since it's consumed as its own resource by
                                  external integrations, not just the Overview page
  GET  /                         the overview page (separate un-prefixed page bp;
                                  the landing page for the whole app)
"""
from __future__ import annotations

from flask import Blueprint, jsonify, render_template

import exec_summary
from dashboard import service

bp = Blueprint("dashboard_api", __name__, url_prefix="/api/v1/dashboard")
exec_summary_bp = Blueprint("exec_summary_api", __name__, url_prefix="/api/v1")
page_bp = Blueprint("dashboard_page", __name__)


@bp.get("")
def overview():
    return jsonify(service.build())


@exec_summary_bp.get("/exec-summary")
def exec_summary_view():
    return jsonify(exec_summary.build())


@page_bp.get("/")
def dashboard_page():
    from app import _CSRF_TOKEN
    return render_template("dashboard.html", csrf_token=_CSRF_TOKEN)
