"""Full-fledged Python tool for the local system-design skill bundle.

This script is intentionally standalone and dependency-free. It turns the
generated markdown skill files in this directory into a searchable knowledge
base, CLI, study assistant, export tool, and small interactive shell.

Examples:
    python system_design_full.py info
    python system_design_full.py search "cache invalidation"
    python system_design_full.py show "Caching"
    python system_design_full.py plan --focus interview --days 5
    python system_design_full.py export --format html --output system-design.html
"""

from __future__ import annotations

import argparse
import csv
import html
import json
import math
import re
import sys
import textwrap
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Iterator, Sequence


VERSION = "2.0.0"
DEFAULT_WIDTH = 96
README_FILE = "README.md"
SKILL_FILE = "SKILL.md"
ISSUES_FILE = "issues.md"
STRUCTURE_FILE = "file_structure.md"

HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9+.-]*")
LINK_RE = re.compile(r"\[([^\]]+)]\(([^)]+)\)")
IMAGE_RE = re.compile(r"!\[[^\]]*]\([^)]*\)")
CODE_BLOCK_RE = re.compile(r"```.*?```", re.DOTALL)
FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*", re.DOTALL)

TOPIC_SKIP_TITLES = {"system design", "table of contents"}

STOP_WORDS = {
    "a",
    "about",
    "above",
    "after",
    "again",
    "all",
    "also",
    "an",
    "and",
    "any",
    "are",
    "as",
    "at",
    "be",
    "because",
    "been",
    "between",
    "but",
    "by",
    "can",
    "data",
    "do",
    "does",
    "each",
    "for",
    "from",
    "has",
    "have",
    "how",
    "if",
    "in",
    "into",
    "is",
    "it",
    "its",
    "more",
    "not",
    "of",
    "on",
    "one",
    "or",
    "our",
    "such",
    "system",
    "than",
    "that",
    "the",
    "their",
    "them",
    "there",
    "these",
    "this",
    "to",
    "use",
    "used",
    "using",
    "we",
    "when",
    "where",
    "which",
    "while",
    "with",
    "within",
    "would",
    "you",
}

FOCUS_GROUPS: dict[str, set[str]] = {
    "foundations": {
        "What is system design?",
        "IP",
        "OSI Model",
        "TCP and UDP",
        "Domain Name System (DNS)",
        "Load Balancing",
        "Clustering",
        "Caching",
        "Content Delivery Network (CDN)",
        "Proxy",
        "Availability",
        "Scalability",
        "Storage",
    },
    "database": {
        "Databases and DBMS",
        "SQL databases",
        "NoSQL databases",
        "SQL vs NoSQL databases",
        "Database Replication",
        "Indexes",
        "Normalization and Denormalization",
        "ACID and BASE consistency models",
        "CAP theorem",
        "PACELC Theorem",
        "Transactions",
        "Distributed Transactions",
        "Sharding",
        "Consistent Hashing",
        "Database Federation",
    },
    "architecture": {
        "N-tier architecture",
        "Message Brokers",
        "Message Queues",
        "Publish-Subscribe",
        "Enterprise Service Bus (ESB)",
        "Monoliths and Microservices",
        "Event-Driven Architecture (EDA)",
        "Event Sourcing",
        "Command and Query Responsibility Segregation (CQRS)",
        "API Gateway",
        "REST, GraphQL, gRPC",
        "Long polling, WebSockets, Server-Sent Events (SSE)",
    },
    "reliability": {
        "Geohashing and Quadtrees",
        "Circuit breaker",
        "Rate Limiting",
        "Service Discovery",
        "SLA, SLO, SLI",
        "Disaster recovery",
        "Virtual Machines (VMs) and Containers",
        "OAuth 2.0 and OpenID Connect (OIDC)",
        "Single Sign-On (SSO)",
        "SSL, TLS, mTLS",
    },
    "interview": {
        "System Design Interviews",
        "URL Shortener",
        "WhatsApp",
        "Twitter",
        "Netflix",
        "Uber",
    },
}


class SkillError(Exception):
    """Base exception for user-facing skill tool errors."""


class SkillLoadError(SkillError):
    """Raised when required skill files cannot be loaded."""


class TopicNotFoundError(SkillError):
    """Raised when a requested markdown section cannot be found."""


@dataclass(frozen=True)
class SkillMetadata:
    name: str
    description: str
    repository: str = ""
    homepage: str = ""
    language: str = ""
    stars: str = ""
    license: str = ""
    last_updated: str = ""
    topics: list[str] = field(default_factory=list)
    raw: dict[str, str] = field(default_factory=dict)


@dataclass
class TopicSection:
    title: str
    slug: str
    level: int
    body: str
    body_text: str
    line_start: int
    line_end: int
    parent_slug: str | None = None
    child_slugs: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)
    word_count: int = 0

    @property
    def read_minutes(self) -> int:
        return max(1, math.ceil(self.word_count / 220))

    def to_payload(self, include_body: bool = False) -> dict[str, object]:
        payload: dict[str, object] = {
            "title": self.title,
            "slug": self.slug,
            "level": self.level,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "parent_slug": self.parent_slug,
            "child_slugs": list(self.child_slugs),
            "keywords": list(self.keywords),
            "word_count": self.word_count,
            "read_minutes": self.read_minutes,
        }
        if include_body:
            payload["body"] = self.body
            payload["body_text"] = self.body_text
        return payload


@dataclass(frozen=True)
class SearchHit:
    section: TopicSection
    score: float
    reasons: list[str]
    snippet: str

    def to_payload(self) -> dict[str, object]:
        return {
            "title": self.section.title,
            "slug": self.section.slug,
            "level": self.section.level,
            "score": round(self.score, 2),
            "reasons": self.reasons,
            "line_start": self.section.line_start,
            "snippet": self.snippet,
        }


@dataclass(frozen=True)
class IssueRecord:
    number: str
    title: str
    status: str
    labels: list[str]
    url: str = ""


@dataclass(frozen=True)
class StudyPlanDay:
    day: int
    label: str
    topics: list[str]
    goals: list[str]
    exercises: list[str]
    estimated_minutes: int


@dataclass(frozen=True)
class Flashcard:
    term: str
    prompt: str
    answer: str
    source_slug: str


@dataclass(frozen=True)
class QuizQuestion:
    question: str
    answer: str
    source: str
    source_slug: str
    difficulty: str


class SystemDesignKnowledgeBase:
    """In-memory knowledge base built from the generated skill markdown files."""

    def __init__(
        self,
        root: Path,
        metadata: SkillMetadata,
        sections: list[TopicSection],
        issues_text: str,
        file_structure_text: str,
    ) -> None:
        self.root = root
        self.metadata = metadata
        self.sections = sections
        self.issues_text = issues_text
        self.file_structure_text = file_structure_text
        self.by_slug = {section.slug: section for section in sections}
        self.by_title = {normalize_title(section.title): section for section in sections}

    @classmethod
    def load(cls, root: str | Path) -> "SystemDesignKnowledgeBase":
        root_path = Path(root).resolve()
        if not root_path.exists():
            raise SkillLoadError(f"Skill directory does not exist: {root_path}")

        skill_text = read_required(root_path / SKILL_FILE)
        readme_text = read_required(root_path / README_FILE)
        issues_text = read_optional(root_path / ISSUES_FILE)
        file_structure_text = read_optional(root_path / STRUCTURE_FILE)
        metadata = parse_skill_metadata(skill_text)
        sections = parse_markdown_sections(readme_text)

        if not sections:
            raise SkillLoadError(f"No markdown sections found in {root_path / README_FILE}")

        return cls(root_path, metadata, sections, issues_text, file_structure_text)

    def top_level_topics(self) -> list[TopicSection]:
        return [
            section
            for section in self.sections
            if section.level == 1 and normalize_title(section.title) not in TOPIC_SKIP_TITLES
        ]

    def get_section(self, title_or_slug: str) -> TopicSection:
        value = title_or_slug.strip()
        if not value:
            raise TopicNotFoundError("Topic name cannot be empty.")

        slug = slugify(value)
        if slug in self.by_slug:
            return self.by_slug[slug]

        normalized = normalize_title(value)
        if normalized in self.by_title:
            return self.by_title[normalized]

        suggestions = self.suggest(value)
        hint = f" Did you mean: {', '.join(suggestions)}?" if suggestions else ""
        raise TopicNotFoundError(f"Topic not found: {value}.{hint}")

    def children(self, section: TopicSection, direct: bool = False) -> list[TopicSection]:
        if direct:
            return [self.by_slug[slug] for slug in section.child_slugs if slug in self.by_slug]
        return [
            candidate
            for candidate in self.sections
            if candidate.level > section.level
            and candidate.line_start > section.line_start
            and candidate.line_end <= section.line_end
        ]

    def ancestors(self, section: TopicSection) -> list[TopicSection]:
        chain = []
        parent_slug = section.parent_slug
        while parent_slug:
            parent = self.by_slug.get(parent_slug)
            if parent is None:
                break
            chain.append(parent)
            parent_slug = parent.parent_slug
        chain.reverse()
        return chain

    def suggest(self, query: str, limit: int = 5) -> list[str]:
        query_words = set(normalized_tokens(query))
        scored: list[tuple[int, int, str]] = []
        for section in self.sections:
            title_words = set(normalized_tokens(section.title))
            overlap = len(query_words & title_words)
            substring = 1 if normalize_title(query) in normalize_title(section.title) else 0
            if overlap or substring:
                scored.append((overlap + substring * 3, -section.level, section.title))
        scored.sort(key=lambda item: (-item[0], -item[1], item[2]))
        return [title for _, _, title in scored[:limit]]

    def search(
        self,
        query: str,
        limit: int = 10,
        level: int | None = None,
        top_level_only: bool = False,
    ) -> list[SearchHit]:
        query_text = query.strip()
        query_terms = normalized_tokens(query_text)
        if not query_terms:
            return []

        phrase = normalize_space(query_text).casefold()
        hits: list[SearchHit] = []
        for section in self.sections:
            if level is not None and section.level != level:
                continue
            if top_level_only and section.level != 1:
                continue

            score, reasons = score_match(section, query_terms, phrase)
            if score <= 0:
                continue

            hits.append(
                SearchHit(
                    section=section,
                    score=score,
                    reasons=reasons,
                    snippet=snippet_for_terms(section.body_text, query_terms),
                )
            )

        hits.sort(key=lambda hit: (-hit.score, hit.section.level, hit.section.line_start))
        return hits[: max(limit, 0)]

    def related(self, title_or_slug: str, limit: int = 8) -> list[TopicSection]:
        target = self.get_section(title_or_slug)
        target_terms = set(target.keywords) | set(normalized_tokens(target.title))
        target_terms = {term for term in target_terms if term not in STOP_WORDS and len(term) > 2}
        target_groups = focus_groups_for_title(target.title)
        scored: list[tuple[float, TopicSection]] = []

        for candidate in self.top_level_topics():
            if candidate.slug == target.slug:
                continue
            candidate_terms = set(candidate.keywords) | set(normalized_tokens(candidate.title))
            overlap = target_terms & candidate_terms
            body_bonus = sum(1 for term in target_terms if term in normalized_tokens(candidate.body_text[:2000]))
            score = len(overlap) * 8 + body_bonus * 3
            if target_groups & focus_groups_for_title(candidate.title):
                score += 14
            score += max(0.0, 25.0 - abs(candidate.line_start - target.line_start) / 8.0)
            if "cache" in target_terms and "cache" in normalized_tokens(candidate.body_text):
                score += 10
            if "load" in target_terms and "load" in normalized_tokens(candidate.body_text):
                score += 5
            if score > 0:
                scored.append((float(score), candidate))

        scored.sort(key=lambda item: (-item[0], item[1].line_start))
        return [section for _, section in scored[: max(limit, 0)]]

    def outline(self, title_or_slug: str, direct: bool = False) -> list[dict[str, object]]:
        section = self.get_section(title_or_slug)
        return [
            {
                "title": child.title,
                "slug": child.slug,
                "level": child.level,
                "line_start": child.line_start,
                "line_end": child.line_end,
                "read_minutes": child.read_minutes,
            }
            for child in self.children(section, direct=direct)
        ]

    def summarize(self, title_or_slug: str, sentences: int = 3) -> str:
        if sentences < 1:
            raise SkillError("sentences must be at least 1")

        section = self.get_section(title_or_slug)
        direct_summary = first_sentences(section.body_text, sentences)
        if direct_summary:
            return direct_summary

        child_parts = []
        for child in self.children(section, direct=True):
            child_summary = first_sentences(child.body_text, 1)
            if child_summary:
                child_parts.append(child_summary)
            if len(child_parts) >= sentences:
                break
        return " ".join(child_parts)

    def glossary(self, limit: int = 50, min_level: int = 1, max_level: int = 3) -> list[dict[str, object]]:
        entries = []
        for section in self.sections:
            if not (min_level <= section.level <= max_level):
                continue
            definition = first_sentences(section.body_text, 1)
            if not definition:
                continue
            entries.append(
                {
                    "term": section.title,
                    "slug": section.slug,
                    "definition": definition,
                    "line_start": section.line_start,
                }
            )
            if len(entries) >= limit:
                break
        return entries

    def flashcards(self, title_or_slug: str, limit: int = 10, include_root: bool = False) -> list[Flashcard]:
        if limit < 1:
            return []

        root = self.get_section(title_or_slug)
        candidates = ([root] if include_root else []) + self.children(root, direct=False)
        if not candidates:
            candidates = [root]

        cards: list[Flashcard] = []
        for section in candidates:
            answer = first_sentences(section.body_text, 2)
            if not answer:
                continue
            cards.append(
                Flashcard(
                    term=section.title,
                    prompt=f"What should you know about {section.title}?",
                    answer=answer,
                    source_slug=section.slug,
                )
            )
            if len(cards) >= limit:
                break
        return cards

    def quiz(self, title_or_slug: str, count: int = 10) -> list[QuizQuestion]:
        cards = self.flashcards(title_or_slug, limit=count)
        questions: list[QuizQuestion] = []
        for index, card in enumerate(cards, start=1):
            difficulty = "easy" if index <= 3 else "medium"
            question = f"How would you explain {card.term} in a system design interview?"
            if index % 3 == 0:
                question = f"What trade-off or failure mode should you consider for {card.term}?"
            questions.append(
                QuizQuestion(
                    question=question,
                    answer=card.answer,
                    source=card.term,
                    source_slug=card.source_slug,
                    difficulty=difficulty,
                )
            )
        return questions

    def study_plan(self, days: int = 7, focus: str = "all") -> list[StudyPlanDay]:
        if days < 1:
            raise SkillError("days must be at least 1")

        topics = self._topics_for_focus(focus)
        chunks = chunk_evenly(topics, days)
        plan = []
        for index, chunk in enumerate(chunks, start=1):
            estimated = sum(topic.read_minutes for topic in chunk) + 20
            titles = [topic.title for topic in chunk]
            goals = [
                f"Read {len(titles)} topic(s) carefully.",
                "Write one design trade-off for each topic.",
                "Explain the topics out loud without reading notes.",
            ]
            exercises = [
                f"Summarize: {titles[0]}" if titles else "Review previous notes.",
                "Create one interview-style question from today's material.",
            ]
            plan.append(
                StudyPlanDay(
                    day=index,
                    label=f"Day {index}",
                    topics=titles,
                    goals=goals,
                    exercises=exercises,
                    estimated_minutes=estimated,
                )
            )
        return plan

    def issues(self) -> list[IssueRecord]:
        records: list[IssueRecord] = []
        status = "unknown"
        issue_re = re.compile(r"^###\s+#(?P<number>\d+):\s+(?P<title>.+)$")
        labels_re = re.compile(r"^\*\*Labels:\*\*\s+(?P<labels>.*?)\s+\|")
        url_re = re.compile(r"\((https://github.com/[^)]+)\)")

        for line in self.issues_text.splitlines():
            if line.startswith("## Open Issues"):
                status = "open"
                continue
            if line.startswith("## Recently Closed Issues"):
                status = "closed"
                continue

            match = issue_re.match(line)
            if match:
                records.append(
                    IssueRecord(
                        number=match.group("number"),
                        title=match.group("title"),
                        status=status,
                        labels=[],
                    )
                )
                continue

            label_match = labels_re.match(line)
            if label_match and records:
                labels = [
                    label.strip()
                    for label in label_match.group("labels").split(",")
                    if label.strip() and label.strip() != "No labels"
                ]
                records[-1] = replace_issue(records[-1], labels=labels)
                continue

            url_match = url_re.search(line)
            if url_match and records:
                records[-1] = replace_issue(records[-1], url=url_match.group(1))

        return records

    def file_structure(self, limit: int | None = None) -> list[str]:
        lines: list[str] = []
        in_block = False
        for line in self.file_structure_text.splitlines():
            if line.strip() == "```":
                in_block = not in_block
                continue
            if in_block and line.strip():
                lines.append(line.rstrip())
        return lines[:limit] if limit else lines

    def stats(self) -> dict[str, int]:
        top_topics = self.top_level_topics()
        words = sum(section.word_count for section in self.sections)
        return {
            "sections": len(self.sections),
            "top_level_topics": len(top_topics),
            "words": words,
            "estimated_read_minutes": max(1, math.ceil(words / 220)),
            "issues": len(self.issues()),
            "structure_items": len(self.file_structure()),
        }

    def export_payload(self, include_body: bool = False) -> dict[str, object]:
        return {
            "metadata": asdict(self.metadata),
            "stats": self.stats(),
            "topics": [section.to_payload(include_body=include_body) for section in self.top_level_topics()],
            "sections": [section.to_payload(include_body=include_body) for section in self.sections],
            "issues": [asdict(issue) for issue in self.issues()],
        }

    def export(self, output: Path, fmt: str, include_body: bool = False) -> Path:
        fmt = fmt.casefold()
        output = output.resolve()
        output.parent.mkdir(parents=True, exist_ok=True)

        if fmt == "json":
            output.write_text(
                json.dumps(self.export_payload(include_body=include_body), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            return output

        if fmt == "markdown":
            output.write_text(self._export_markdown(include_body=include_body), encoding="utf-8")
            return output

        if fmt == "html":
            output.write_text(self._export_html(include_body=include_body), encoding="utf-8")
            return output

        if fmt == "csv":
            with output.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=[
                        "title",
                        "slug",
                        "level",
                        "line_start",
                        "line_end",
                        "parent_slug",
                        "word_count",
                        "read_minutes",
                        "keywords",
                        "body_text",
                    ],
                )
                writer.writeheader()
                for section in self.sections:
                    row = section.to_payload(include_body=True)
                    writer.writerow(
                        {
                            "title": row["title"],
                            "slug": row["slug"],
                            "level": row["level"],
                            "line_start": row["line_start"],
                            "line_end": row["line_end"],
                            "parent_slug": row["parent_slug"],
                            "word_count": row["word_count"],
                            "read_minutes": row["read_minutes"],
                            "keywords": ", ".join(section.keywords),
                            "body_text": section.body_text if include_body else "",
                        }
                    )
            return output

        raise SkillError(f"Unsupported export format: {fmt}")

    def _topics_for_focus(self, focus: str) -> list[TopicSection]:
        focus = focus.casefold()
        topics = self.top_level_topics()
        if focus == "all":
            return topics
        if focus not in FOCUS_GROUPS:
            names = ", ".join(["all", *sorted(FOCUS_GROUPS)])
            raise SkillError(f"Unknown focus '{focus}'. Choose one of: {names}")
        wanted = FOCUS_GROUPS[focus]
        selected = [topic for topic in topics if topic.title in wanted]
        return selected or topics

    def _export_markdown(self, include_body: bool = False) -> str:
        lines = [
            f"# {self.metadata.name or 'system-design'} index",
            "",
            self.metadata.description,
            "",
            "## Stats",
            "",
        ]
        for key, value in self.stats().items():
            lines.append(f"- **{key.replace('_', ' ').title()}**: {value}")
        lines.extend(["", "## Topics", ""])
        for topic in self.top_level_topics():
            lines.append(f"- [{topic.title}](#{topic.slug}) - {topic.word_count} words")
        lines.append("")

        for section in self.sections:
            heading = "#" * min(section.level + 1, 6)
            lines.extend([f"{heading} {section.title}", ""])
            lines.append(f"- Slug: `{section.slug}`")
            lines.append(f"- Lines: {section.line_start}-{section.line_end}")
            lines.append(f"- Keywords: {', '.join(section.keywords)}")
            if include_body:
                lines.extend(["", section.body])
            lines.append("")
        return "\n".join(lines).strip() + "\n"

    def _export_html(self, include_body: bool = False) -> str:
        stats_items = "\n".join(
            f"<li><strong>{html.escape(key.replace('_', ' ').title())}:</strong> {value}</li>"
            for key, value in self.stats().items()
        )
        topic_items = "\n".join(
            f'<li><a href="#{html.escape(topic.slug)}">{html.escape(topic.title)}</a> '
            f"<span>{topic.word_count} words</span></li>"
            for topic in self.top_level_topics()
        )
        section_items = []
        for section in self.sections:
            body = f"<p>{html.escape(first_sentences(section.body_text, 3))}</p>"
            if include_body:
                body = f"<pre>{html.escape(section.body)}</pre>"
            section_items.append(
                f'<section id="{html.escape(section.slug)}">'
                f"<h{min(section.level + 1, 6)}>{html.escape(section.title)}</h{min(section.level + 1, 6)}>"
                f"<p><strong>Lines:</strong> {section.line_start}-{section.line_end} "
                f"<strong>Read:</strong> {section.read_minutes} min</p>"
                f"<p><strong>Keywords:</strong> {html.escape(', '.join(section.keywords))}</p>"
                f"{body}</section>"
            )

        return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(self.metadata.name)} index</title>
  <style>
    body {{ font-family: Arial, sans-serif; line-height: 1.55; margin: 32px auto; max-width: 980px; padding: 0 20px; color: #1f2933; }}
    h1, h2, h3, h4 {{ line-height: 1.2; }}
    a {{ color: #1459a8; }}
    code, pre {{ background: #f4f6f8; border-radius: 6px; }}
    pre {{ overflow: auto; padding: 16px; }}
    section {{ border-top: 1px solid #d9e2ec; padding: 20px 0; }}
    span {{ color: #62748a; }}
  </style>
</head>
<body>
  <h1>{html.escape(self.metadata.name)} index</h1>
  <p>{html.escape(self.metadata.description)}</p>
  <h2>Stats</h2>
  <ul>{stats_items}</ul>
  <h2>Topics</h2>
  <ul>{topic_items}</ul>
  <h2>Sections</h2>
  {''.join(section_items)}
</body>
</html>
"""


def read_required(path: Path) -> str:
    if not path.exists():
        raise SkillLoadError(f"Required file is missing: {path}")
    return path.read_text(encoding="utf-8-sig", errors="replace")


def read_optional(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8-sig", errors="replace")


def parse_skill_metadata(text: str) -> SkillMetadata:
    frontmatter = parse_frontmatter(text)
    repository = find_markdown_link(text, "Repository")
    homepage_match = re.search(r"- \*\*Homepage:\*\*\s*(.+)", text)
    topics_match = re.search(r"- \*\*Topics:\*\*\s*(.+)", text)
    stars_match = re.search(r"- \*\*Stars:\*\*\s*(.+)", text)
    license_match = re.search(r"- \*\*License:\*\*\s*(.+)", text)
    language_match = re.search(r"- \*\*Language:\*\*\s*(.+)", text)
    updated_match = re.search(r"- \*\*Last Updated:\*\*\s*(.+)", text)
    description_match = re.search(r"## Description\s+(.+?)(?:\n\n|$)", text, flags=re.DOTALL)

    topics = []
    if topics_match:
        topics = [topic.strip() for topic in topics_match.group(1).split(",") if topic.strip()]

    return SkillMetadata(
        name=frontmatter.get("name", "system-design"),
        description=frontmatter.get("description")
        or normalize_space(description_match.group(1)) if description_match else "",
        repository=repository,
        homepage=homepage_match.group(1).strip() if homepage_match else "",
        language=language_match.group(1).strip() if language_match else "",
        stars=stars_match.group(1).strip() if stars_match else "",
        license=license_match.group(1).strip() if license_match else "",
        last_updated=updated_match.group(1).strip() if updated_match else "",
        topics=topics,
        raw=frontmatter,
    )


def parse_frontmatter(text: str) -> dict[str, str]:
    match = FRONTMATTER_RE.match(text)
    if not match:
        return {}

    values: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip()
    return values


def find_markdown_link(text: str, label: str) -> str:
    pattern = rf"\*\*{re.escape(label)}:\*\*\s*\[.*?]\((.*?)\)"
    match = re.search(pattern, text)
    return match.group(1).strip() if match else ""


def parse_markdown_sections(text: str) -> list[TopicSection]:
    lines = text.splitlines()
    heading_rows: list[tuple[int, int, str]] = []
    for index, line in enumerate(lines):
        match = HEADING_RE.match(line)
        if match:
            heading_rows.append((index, len(match.group(1)), clean_heading(match.group(2))))

    slug_counts: dict[str, int] = {}
    sections: list[TopicSection] = []
    stack: list[TopicSection] = []

    for position, (start_index, level, title) in enumerate(heading_rows):
        end_index = len(lines)
        for next_index, next_level, _ in heading_rows[position + 1 :]:
            if next_level <= level:
                end_index = next_index
                break

        base_slug = slugify(title)
        duplicate_count = slug_counts.get(base_slug, 0)
        slug_counts[base_slug] = duplicate_count + 1
        slug = base_slug if duplicate_count == 0 else f"{base_slug}-{duplicate_count + 1}"

        while stack and stack[-1].level >= level:
            stack.pop()
        parent = stack[-1] if stack else None

        body = "\n".join(lines[start_index + 1 : end_index]).strip()
        body_text = markdown_to_text(body)
        words = normalized_tokens(body_text)
        section = TopicSection(
            title=title,
            slug=slug,
            level=level,
            body=body,
            body_text=body_text,
            line_start=start_index + 1,
            line_end=end_index,
            parent_slug=parent.slug if parent else None,
            keywords=keywords_from_tokens(words),
            word_count=len(words),
        )

        if parent:
            parent.child_slugs.append(section.slug)
        sections.append(section)
        stack.append(section)

    return sections


def clean_heading(title: str) -> str:
    title = re.sub(r"\s+\{#.*?}$", "", title)
    return normalize_space(title.strip("# "))


def markdown_to_text(markdown: str) -> str:
    text = CODE_BLOCK_RE.sub(" ", markdown)
    text = IMAGE_RE.sub(" ", text)
    text = LINK_RE.sub(r"\1", text)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*\d+\.\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"[*_>#|~]", " ", text)
    text = text.replace("&amp;", "&")
    return normalize_space(text)


def normalize_space(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def normalize_title(title: str) -> str:
    return normalize_space(title).casefold()


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.casefold()).strip("-")
    return slug or "section"


def tokenize(text: str) -> list[str]:
    return WORD_RE.findall(text)


def normalize_token(token: str) -> str:
    token = token.casefold().strip(".-+")
    if len(token) > 4 and token.endswith("ing"):
        token = token[:-3]
    elif len(token) > 3 and token.endswith("es"):
        token = token[:-2]
    elif len(token) > 3 and token.endswith("s"):
        token = token[:-1]
    return token


def normalized_tokens(text: str) -> list[str]:
    return [normalize_token(token) for token in tokenize(text) if normalize_token(token)]


def keywords_from_tokens(tokens: Sequence[str], limit: int = 10) -> list[str]:
    counts: dict[str, int] = {}
    for token in tokens:
        if token in STOP_WORDS or len(token) < 3:
            continue
        counts[token] = counts.get(token, 0) + 1
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return [token for token, _ in ranked[:limit]]


def sentence_split(text: str) -> list[str]:
    if not text:
        return []
    raw = re.split(r"(?<=[.!?])\s+", text)
    return [part.strip() for part in raw if part.strip()]


def first_sentences(text: str, count: int) -> str:
    return " ".join(sentence_split(text)[:count])


def snippet_for_terms(text: str, terms: Sequence[str], width: int = 260) -> str:
    compact = normalize_space(text)
    if not compact:
        return ""

    lower = compact.casefold()
    starts = [lower.find(term) for term in terms if lower.find(term) >= 0]
    start = max((min(starts) if starts else 0) - width // 4, 0)
    snippet = compact[start : start + width]
    if start > 0:
        snippet = "..." + snippet.lstrip()
    if start + width < len(compact):
        snippet = snippet.rstrip() + "..."
    return snippet


def score_match(section: TopicSection, query_terms: Sequence[str], phrase: str) -> tuple[float, list[str]]:
    title_terms = normalized_tokens(section.title)
    body_terms = normalized_tokens(section.body_text)
    keyword_set = set(section.keywords)
    title_text = normalize_title(section.title)
    body_text = normalize_title(section.body_text)
    reasons: list[str] = []
    score = 0.0

    if phrase and phrase == title_text:
        score += 100
        reasons.append("exact title")
    elif phrase and phrase in title_text:
        score += 60
        reasons.append("title phrase")
    if phrase and phrase in body_text:
        score += 25
        reasons.append("body phrase")

    for term in query_terms:
        title_hits = title_terms.count(term)
        body_hits = body_terms.count(term)
        keyword_hit = term in keyword_set
        if title_hits:
            score += title_hits * 18
            reasons.append(f"title:{term}")
        if keyword_hit:
            score += 12
            reasons.append(f"keyword:{term}")
        if body_hits:
            score += min(body_hits, 12) * 2
            reasons.append(f"body:{term}")
        if term in section.slug:
            score += 4

    if section.level == 1 and score:
        score += 3
    elif section.level == 2 and score:
        score += 1

    return score, dedupe_preserve_order(reasons)


def dedupe_preserve_order(items: Iterable[str]) -> list[str]:
    seen = set()
    result = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


def chunk_evenly(items: Sequence[TopicSection], chunk_count: int) -> list[list[TopicSection]]:
    chunks: list[list[TopicSection]] = []
    total = len(items)
    for index in range(chunk_count):
        start = round(index * total / chunk_count)
        end = round((index + 1) * total / chunk_count)
        chunks.append(list(items[start:end]))
    return chunks


def focus_groups_for_title(title: str) -> set[str]:
    return {name for name, titles in FOCUS_GROUPS.items() if title in titles}


def replace_issue(issue: IssueRecord, **changes: object) -> IssueRecord:
    data = asdict(issue)
    data.update(changes)
    return IssueRecord(**data)


def json_print(data: object) -> None:
    print(json.dumps(data, indent=2, ensure_ascii=False))


def print_wrapped(text: str, width: int = DEFAULT_WIDTH, indent: str = "") -> None:
    if not text:
        return
    print(textwrap.indent(textwrap.fill(text, width=width), indent))


def default_output_path(fmt: str) -> Path:
    extension = "md" if fmt == "markdown" else fmt
    return Path(f"system-design-index.{extension}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="system_design_full.py",
        description="Full-fledged CLI for the local system-design skill bundle.",
    )
    parser.add_argument(
        "--skill-dir",
        type=Path,
        default=Path(__file__).resolve().parent,
        help="Path containing SKILL.md, README.md, issues.md, and file_structure.md.",
    )
    parser.add_argument("--version", action="version", version=f"system-design-full {VERSION}")

    subparsers = parser.add_subparsers(dest="command", required=True)

    add_json_flag(subparsers.add_parser("info", help="Show skill metadata and high-level stats."))
    add_json_flag(subparsers.add_parser("stats", help="Show counts, words, read time, and issue totals."))

    topics = subparsers.add_parser("topics", help="List top-level course topics.")
    topics.add_argument("--with-stats", action="store_true", help="Include word count and read time.")
    add_json_flag(topics)

    toc = subparsers.add_parser("toc", help="Print a table of contents from markdown headings.")
    toc.add_argument("--max-depth", type=int, default=3, help="Maximum heading level to display.")
    add_json_flag(toc)

    show = subparsers.add_parser("show", help="Show a topic or subsection.")
    show.add_argument("topic", help="Topic title or slug.")
    show.add_argument("--plain", action="store_true", help="Print plain text instead of markdown.")
    show.add_argument("--with-meta", action="store_true", help="Print section metadata before content.")

    outline = subparsers.add_parser("outline", help="Show subheadings under a topic.")
    outline.add_argument("topic", help="Topic title or slug.")
    outline.add_argument("--direct", action="store_true", help="Only show direct children.")
    add_json_flag(outline)

    summary = subparsers.add_parser("summary", help="Summarize a topic.")
    summary.add_argument("topic", help="Topic title or slug.")
    summary.add_argument("-n", "--sentences", type=int, default=3, help="Number of sentences.")
    add_json_flag(summary)

    search = subparsers.add_parser("search", help="Search all sections.")
    search.add_argument("query", help="Search query.")
    search.add_argument("-n", "--limit", type=int, default=10, help="Maximum results.")
    search.add_argument("--level", type=int, choices=range(1, 7), help="Restrict to one heading level.")
    search.add_argument("--top-level", action="store_true", help="Search only top-level topics.")
    add_json_flag(search)

    related = subparsers.add_parser("related", help="Find related top-level topics.")
    related.add_argument("topic", help="Topic title or slug.")
    related.add_argument("-n", "--limit", type=int, default=8, help="Maximum related topics.")
    add_json_flag(related)

    glossary = subparsers.add_parser("glossary", help="Generate a glossary from headings.")
    glossary.add_argument("-n", "--limit", type=int, default=50, help="Maximum glossary entries.")
    glossary.add_argument("--min-level", type=int, default=1, help="Minimum heading level.")
    glossary.add_argument("--max-level", type=int, default=3, help="Maximum heading level.")
    add_json_flag(glossary)

    flashcards = subparsers.add_parser("flashcards", help="Generate flashcards for a topic.")
    flashcards.add_argument("topic", help="Topic title or slug.")
    flashcards.add_argument("-n", "--limit", type=int, default=10, help="Maximum flashcards.")
    flashcards.add_argument("--include-root", action="store_true", help="Include the root topic as a card.")
    add_json_flag(flashcards)

    quiz = subparsers.add_parser("quiz", help="Generate interview-style quiz questions.")
    quiz.add_argument("topic", help="Topic title or slug.")
    quiz.add_argument("-n", "--count", type=int, default=10, help="Maximum questions.")
    add_json_flag(quiz)

    plan = subparsers.add_parser("plan", help="Generate a study plan.")
    plan.add_argument("--days", type=int, default=7, help="Number of study days.")
    plan.add_argument(
        "--focus",
        default="all",
        choices=["all", *sorted(FOCUS_GROUPS)],
        help="Topic group.",
    )
    add_json_flag(plan)

    issues = subparsers.add_parser("issues", help="List captured GitHub issues.")
    issues.add_argument("--status", choices=["open", "closed", "all"], default="all")
    add_json_flag(issues)

    tree = subparsers.add_parser("tree", help="Print captured repository file structure.")
    tree.add_argument("-n", "--limit", type=int, default=None, help="Maximum lines.")

    export = subparsers.add_parser("export", help="Export the index.")
    export.add_argument("--format", choices=["json", "markdown", "html", "csv"], default="json")
    export.add_argument("--output", type=Path, help="Output file path.")
    export.add_argument("--include-body", action="store_true", help="Include full markdown bodies.")

    subparsers.add_parser("interactive", help="Start an interactive prompt.")

    return parser


def add_json_flag(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")


def run_command(args: argparse.Namespace) -> int:
    kb = SystemDesignKnowledgeBase.load(args.skill_dir)
    command = args.command

    if command == "info":
        payload = {"metadata": asdict(kb.metadata), "stats": kb.stats(), "root": str(kb.root)}
        if args.json:
            json_print(payload)
        else:
            print(f"Name: {kb.metadata.name}")
            print(f"Description: {kb.metadata.description}")
            print(f"Repository: {kb.metadata.repository or 'unknown'}")
            print(f"Homepage: {kb.metadata.homepage or 'unknown'}")
            print(f"Stars: {kb.metadata.stars or 'unknown'}")
            print(f"Last updated: {kb.metadata.last_updated or 'unknown'}")
            print(f"Root: {kb.root}")
            print("")
            print_stats(kb.stats())
        return 0

    if command == "stats":
        stats = kb.stats()
        if args.json:
            json_print(stats)
        else:
            print_stats(stats)
        return 0

    if command == "topics":
        topics = kb.top_level_topics()
        if args.json:
            json_print([topic.to_payload(include_body=False) for topic in topics])
        else:
            for index, topic in enumerate(topics, start=1):
                if args.with_stats:
                    print(f"{index:02d}. {topic.title} ({topic.word_count} words, {topic.read_minutes} min)")
                else:
                    print(f"{index:02d}. {topic.title}")
        return 0

    if command == "toc":
        rows = [
            section.to_payload(include_body=False)
            for section in kb.sections
            if section.level <= args.max_depth
        ]
        if args.json:
            json_print(rows)
        else:
            for section in kb.sections:
                if section.level > args.max_depth:
                    continue
                indent = "  " * (section.level - 1)
                print(f"{indent}- {section.title} [{section.slug}]")
        return 0

    if command == "show":
        section = kb.get_section(args.topic)
        if args.with_meta:
            print_section_meta(section, kb)
            print("")
        if args.plain:
            print(section.body_text)
        else:
            print(f"{'#' * section.level} {section.title}")
            if section.body:
                print("")
                print(section.body)
        return 0

    if command == "outline":
        rows = kb.outline(args.topic, direct=args.direct)
        if args.json:
            json_print(rows)
        else:
            for item in rows:
                indent = "  " * max(int(item["level"]) - 2, 0)
                print(
                    f"{indent}- {item['title']} "
                    f"[{item['slug']}] line {item['line_start']} ({item['read_minutes']} min)"
                )
        return 0

    if command == "summary":
        summary = kb.summarize(args.topic, sentences=args.sentences)
        if args.json:
            json_print({"topic": args.topic, "summary": summary})
        else:
            print_wrapped(summary)
        return 0

    if command == "search":
        hits = kb.search(args.query, limit=args.limit, level=args.level, top_level_only=args.top_level)
        if args.json:
            json_print([hit.to_payload() for hit in hits])
        else:
            for index, hit in enumerate(hits, start=1):
                print(f"{index}. {hit.section.title} [{hit.section.slug}] score={hit.score:.1f}")
                print(f"   line {hit.section.line_start}; reasons: {', '.join(hit.reasons)}")
                print_wrapped(hit.snippet, indent="   ")
        return 0

    if command == "related":
        rows = kb.related(args.topic, limit=args.limit)
        if args.json:
            json_print([row.to_payload(include_body=False) for row in rows])
        else:
            for index, section in enumerate(rows, start=1):
                print(f"{index}. {section.title} [{section.slug}] - {section.read_minutes} min")
        return 0

    if command == "glossary":
        rows = kb.glossary(limit=args.limit, min_level=args.min_level, max_level=args.max_level)
        if args.json:
            json_print(rows)
        else:
            for row in rows:
                print(f"{row['term']} [{row['slug']}]")
                print_wrapped(str(row["definition"]), indent="  ")
        return 0

    if command == "flashcards":
        cards = kb.flashcards(args.topic, limit=args.limit, include_root=args.include_root)
        if args.json:
            json_print([asdict(card) for card in cards])
        else:
            for index, card in enumerate(cards, start=1):
                print(f"{index}. {card.term}")
                print_wrapped(f"Q: {card.prompt}", indent="   ")
                print_wrapped(f"A: {card.answer}", indent="   ")
        return 0

    if command == "quiz":
        questions = kb.quiz(args.topic, count=args.count)
        if args.json:
            json_print([asdict(question) for question in questions])
        else:
            for index, question in enumerate(questions, start=1):
                print(f"{index}. [{question.difficulty}] {question.question}")
                print_wrapped(f"Answer: {question.answer}", indent="   ")
        return 0

    if command == "plan":
        plan = kb.study_plan(days=args.days, focus=args.focus)
        if args.json:
            json_print([asdict(day) for day in plan])
        else:
            for day in plan:
                print(f"{day.label} ({day.estimated_minutes} min)")
                print("  Topics:")
                for topic in day.topics:
                    print(f"  - {topic}")
                print("  Goals:")
                for goal in day.goals:
                    print(f"  - {goal}")
                print("  Exercises:")
                for exercise in day.exercises:
                    print(f"  - {exercise}")
        return 0

    if command == "issues":
        records = kb.issues()
        if args.status != "all":
            records = [record for record in records if record.status == args.status]
        if args.json:
            json_print([asdict(record) for record in records])
        else:
            for record in records:
                labels = f" [{', '.join(record.labels)}]" if record.labels else ""
                print(f"#{record.number} {record.status}: {record.title}{labels}")
                if record.url:
                    print(f"  {record.url}")
        return 0

    if command == "tree":
        for line in kb.file_structure(limit=args.limit):
            print(line)
        return 0

    if command == "export":
        output = args.output or default_output_path(args.format)
        written = kb.export(output=output, fmt=args.format, include_body=args.include_body)
        print(f"Wrote {written}")
        return 0

    if command == "interactive":
        return interactive_loop(kb)

    raise SkillError(f"Unknown command: {command}")


def print_stats(stats: dict[str, int]) -> None:
    for key, value in stats.items():
        print(f"{key.replace('_', ' ').title()}: {value}")


def print_section_meta(section: TopicSection, kb: SystemDesignKnowledgeBase) -> None:
    ancestors = " > ".join(parent.title for parent in kb.ancestors(section))
    print(f"Title: {section.title}")
    print(f"Slug: {section.slug}")
    print(f"Level: {section.level}")
    print(f"Lines: {section.line_start}-{section.line_end}")
    print(f"Words: {section.word_count}")
    print(f"Read minutes: {section.read_minutes}")
    print(f"Parent path: {ancestors or '(root)'}")
    print(f"Keywords: {', '.join(section.keywords)}")


def interactive_loop(kb: SystemDesignKnowledgeBase) -> int:
    print("System Design interactive mode. Type 'help' for commands, 'quit' to exit.")
    while True:
        try:
            raw = input("system-design> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("")
            return 0

        if not raw:
            continue
        if raw in {"quit", "exit", ":q"}:
            return 0
        if raw == "help":
            print("Commands: topics, search <query>, show <topic>, summary <topic>, outline <topic>, quiz <topic>, quit")
            continue
        if raw == "topics":
            for topic in kb.top_level_topics():
                print(f"- {topic.title}")
            continue
        if raw.startswith("search "):
            for hit in kb.search(raw.removeprefix("search "), limit=5):
                print(f"- {hit.section.title} [{hit.section.slug}] score={hit.score:.1f}")
            continue
        if raw.startswith("show "):
            try:
                section = kb.get_section(raw.removeprefix("show "))
                print(f"# {section.title}\n")
                print(section.body or section.body_text)
            except SkillError as error:
                print(f"error: {error}")
            continue
        if raw.startswith("summary "):
            try:
                print_wrapped(kb.summarize(raw.removeprefix("summary "), sentences=3))
            except SkillError as error:
                print(f"error: {error}")
            continue
        if raw.startswith("outline "):
            try:
                for item in kb.outline(raw.removeprefix("outline ")):
                    print(f"- {item['title']} [{item['slug']}]")
            except SkillError as error:
                print(f"error: {error}")
            continue
        if raw.startswith("quiz "):
            try:
                for question in kb.quiz(raw.removeprefix("quiz "), count=5):
                    print(f"- {question.question}")
                    print_wrapped(question.answer, indent="  ")
            except SkillError as error:
                print(f"error: {error}")
            continue

        print("Unknown command. Type 'help' for options.")


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return run_command(args)
    except SkillError as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    except BrokenPipeError:
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
