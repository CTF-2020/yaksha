"""Per-finding code review: analyze each SAST hit like a human PR reviewer.

For every finding that carries a file:line inside the scanned workspace, this
module reads the surrounding source and produces a structured `review` dict:

  * the enclosing function (Python via `ast`, brace/`def` languages via a
    signature-scan heuristic) so the finding is judged in its real scope;
  * a local taint pass — does attacker-controlled input (request params, argv,
    env, ...) reach the flagged line through assignments inside that scope?
  * a verdict: `likely-exploitable`, `needs-validation`, or
    `likely-false-positive`, each with a confidence and evidence bullets that
    cite line numbers (the reviewer must show its work, not just conclude);
  * where the fix is mechanical, a suggested change as -/+ diff lines against
    the flagged source line, GitHub-suggestion style.

Everything is deterministic, stdlib-only, and read-only over the workspace.
Paths are resolved strictly under scan_root (same escape guard as
scanner._attach_code_context) so a crafted finding path cannot read outside
the checkout. Any per-finding failure is swallowed: a review is an
enhancement, never a reason for a scan job to fail.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

VERDICT_EXPLOITABLE = "likely-exploitable"
VERDICT_VALIDATE = "needs-validation"
VERDICT_FALSE_POSITIVE = "likely-false-positive"

_MAX_REVIEWED = 400          # per-scan cap: reviews are per-finding file reads
_MAX_FILE_BYTES = 2_000_000
_MAX_FN_LINES = 400          # cap extraction so a 5k-line "function" stays cheap
_WINDOW_RADIUS = 40          # fallback scope when no enclosing function is found
# _SIG_RES's java/csharp patterns have an ambiguous modifier-vs-type-prefix
# shape ((?:kw\s+)* followed by a lazy generic-token run) that backtracks
# catastrophically (verified: ~quadratic, seconds on a several-thousand-char
# line with no matching "(") when the overall match fails on a long line. A
# scanned repo's source is attacker-influenceable, so a single crafted long
# line (up to 200 of which are scanned per finding, per _brace_function's
# backward walk) could otherwise hang a scan. Real signature lines are never
# remotely this long, so truncating before matching costs nothing legitimate.
_MAX_SIG_LINE_LEN = 300

_LANG_BY_EXT = {
    ".py": "python",
    ".js": "js", ".jsx": "js", ".ts": "js", ".tsx": "js", ".mjs": "js", ".cjs": "js",
    ".go": "go",
    ".java": "java", ".kt": "java", ".scala": "java",
    ".rb": "ruby",
    ".php": "php",
    ".cs": "csharp",
}

# Attacker-controlled input entering the scope. Grouped per language family but
# matched permissively: a Django `request.POST` in a .py file and an Express
# `req.query` in a .ts file both count; cross-family patterns simply never
# occur in the other syntax.
_SOURCE_RES = {
    "python": re.compile(
        r"request\.(?:args|form|values|json|data|files|headers|cookies|get_json"
        r"|GET|POST|body|query_params)|os\.environ|sys\.argv|\binput\s*\("),
    "js": re.compile(
        r"\breq(?:uest)?\.(?:query|body|params|headers|cookies)\b|process\.argv"
        r"|process\.env|location\.(?:search|hash|href)|document\.(?:URL|location)"
        r"|URLSearchParams"),
    "go": re.compile(
        r"r\.(?:URL\.Query|FormValue|PostFormValue|Form\b|PostForm\b|Body\b"
        r"|Header\b|Cookie)|os\.Args|os\.Getenv"),
    "java": re.compile(
        r"\.getParameter(?:Map|Values)?\s*\(|\.getHeader\s*\(|\.getQueryString\s*\("
        r"|\.getInputStream\s*\(|\.getReader\s*\(|@RequestParam|@PathVariable"
        r"|@RequestBody"),
    "ruby": re.compile(r"\bparams\s*\[|request\.(?:params|body|env|headers)"),
    "php": re.compile(r"\$_(?:GET|POST|REQUEST|COOKIE|SERVER|FILES)\b|php://input"),
    "csharp": re.compile(r"Request\.(?:Query|Form|Params|Headers|Cookies|Body)"),
}

# Signals that the value was cleaned/parameterized on its way to the sink.
_SANITIZER_RE = re.compile(
    r"escape|quote\s*\(|shlex\.|sanitiz|parameteriz|prepared|bindparam|\bbind\b"
    r"|secure_filename|htmlspecialchars|encodeURIComponent|literal_eval"
    r"|allowlist|whitelist|validate|strip_tags|textContent|int\s*\(",
    re.IGNORECASE)

# Paths where a hit is usually fixture/demo code, not production surface.
_LOWRISK_PATH_RE = re.compile(
    r"(^|[/\\])(tests?|spec|specs|fixtures?|examples?|samples?|demo|vendor"
    r"|node_modules|third_party)([/\\]|$)|\.(test|spec)\.|_test\.",
    re.IGNORECASE)

# Rules where the "it's just a constant" downgrade must NOT fire — for a
# hardcoded credential the constant IS the finding.
_SECRET_RULE_RE = re.compile(r"secret|password|credential|token|api.?key|hardcod",
                             re.IGNORECASE)

# `x = ...` / `x := ...` / `x += ...` in any supported syntax; deliberately does
# not match ==/===/!=/<=/>= (the char before `=` must be the identifier or a
# supported operator head, and `=` must not be followed by another `=`).
_ASSIGN_RE = re.compile(
    r"^\s*(?:(?:const|let|var|final|val|my)\s+)?"
    r"(?:[A-Za-z_$][\w$]*(?:\.|::|->))*"        # obj./self. prefix — keep last part
    r"([A-Za-z_$][\w$]*)\s*(?::=|\+=|=)(?!=)\s*(\S.*)$")

_LITERAL_ARG = (r"(?:[A-Za-z_]\w*\s*=\s*)?"        # kwarg= prefix (shell=True, timeout=5)
                r"(?:[frbu]{0,2}(['\"])(?:(?!\1).)*\1|\d[\d_.]*|True|False|None|true|false|null|nil)")
_LITERAL_ARGS_RE = re.compile(
    r"\(\s*" + _LITERAL_ARG
    + r"(?:\s*,\s*" + _LITERAL_ARG.replace(r"\1", r"\2") + r")*"
    + r"\s*,?\s*\)")


def _lang_of(rel: str) -> str:
    return _LANG_BY_EXT.get(Path(rel).suffix.lower(), "generic")


def _source_re(lang: str) -> re.Pattern:
    if lang in _SOURCE_RES:
        return _SOURCE_RES[lang]
    # generic files (configs, templates): union of the big three families
    return re.compile("|".join(p.pattern for p in
                               (_SOURCE_RES["python"], _SOURCE_RES["js"], _SOURCE_RES["php"])))


# ── enclosing-scope extraction ────────────────────────────────────────────────

def _py_function(src: str, line: int):
    """Innermost def/async def containing `line`, via the real parser."""
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return None
    best = None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end = getattr(node, "end_lineno", node.lineno)
            if node.lineno <= line <= end:
                if best is None or node.lineno > best.lineno:
                    best = node
    if best is None:
        return None
    return {"name": best.name, "start": best.lineno,
            "end": min(getattr(best, "end_lineno", best.lineno),
                       best.lineno + _MAX_FN_LINES)}


# Control-flow / keyword heads that the loose brace-language signature patterns
# below would otherwise capture as a "function" — `if (cond) {`, `for (…) {`,
# `catch (e) {` all look like `name(args) {`. When the signature scan lands on
# one of these we keep walking back for the real enclosing function.
_CTRL_KEYWORDS = frozenset({
    "if", "else", "for", "while", "switch", "catch", "do", "try", "with",
    "return", "throw", "await", "typeof", "new", "case", "function", "synchronized",
})

_SIG_RES = {
    "js": re.compile(
        r"function\s*\*?\s*([A-Za-z_$][\w$]*)?\s*\(|"
        r"([A-Za-z_$][\w$]*)\s*[:=]\s*(?:async\s+)?(?:function\b|\([^)]*\)\s*=>)|"
        r"(?:async\s+)?([A-Za-z_$][\w$]*)\s*\([^;{}]*\)\s*\{\s*$"),
    "go": re.compile(r"^func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)"),
    "java": re.compile(
        r"^\s*(?:(?:public|private|protected|static|final|synchronized|abstract"
        r"|override|suspend|fun)\s+)*[\w<>\[\],.\s?]*?([A-Za-z_]\w*)\s*\([^;]*\)"
        r"(?:\s*throws\s[\w,\s.]+)?\s*\{\s*$"),
    "csharp": re.compile(
        r"^\s*(?:(?:public|private|protected|internal|static|async|virtual"
        r"|override|sealed)\s+)*[\w<>\[\],.\s?]*?([A-Za-z_]\w*)\s*\([^;]*\)\s*\{?\s*$"),
    "php": re.compile(r"function\s+&?([A-Za-z_]\w*)\s*\("),
    "ruby": re.compile(r"^\s*def\s+(?:self\.)?([\w?!]+)"),
}


def _brace_function(lines: list, line: int, lang: str):
    """Heuristic enclosing function for brace/def languages.

    Walk back from the flagged line looking for a function signature, then walk
    forward balancing braces (or, for Ruby, matching `end` at the signature's
    indent). Best-effort — a miss just means the window fallback is used.
    """
    sig_re = _SIG_RES.get(lang)
    if sig_re is None:
        return None
    for i in range(line, max(0, line - 200), -1):
        text = lines[i - 1][:_MAX_SIG_LINE_LEN]
        m = sig_re.search(text)
        if not m:
            continue
        name = next((grp for grp in m.groups() if grp), "(anonymous)")
        if name in _CTRL_KEYWORDS:
            continue        # a control-flow head, not the enclosing function
        if lang == "ruby":
            indent = len(text) - len(text.lstrip())
            for j in range(i + 1, min(len(lines), i + _MAX_FN_LINES) + 1):
                t2 = lines[j - 1]
                if t2.strip() == "end" and (len(t2) - len(t2.lstrip())) <= indent:
                    if j >= line:
                        return {"name": name, "start": i, "end": j}
                    break   # this def closed before the flagged line: keep walking back
            continue
        depth = 0
        opened = False
        for j in range(i, min(len(lines), i + _MAX_FN_LINES) + 1):
            for ch in lines[j - 1]:
                if ch == "{":
                    depth += 1
                    opened = True
                elif ch == "}":
                    depth -= 1
            if opened and depth <= 0:
                if j >= line:
                    return {"name": name, "start": i, "end": j}
                break       # candidate closed too early — keep scanning back
    return None


def _enclosing_scope(lines: list, src: str, line: int, lang: str) -> dict:
    fn = _py_function(src, line) if lang == "python" else _brace_function(lines, line, lang)
    if fn:
        return {**fn, "kind": "function"}
    return {"name": None, "start": max(1, line - _WINDOW_RADIUS),
            "end": min(len(lines), line + _WINDOW_RADIUS), "kind": "window"}


# ── local taint pass ──────────────────────────────────────────────────────────

def _taint_map(lines: list, start: int, end: int, source_re: re.Pattern) -> dict:
    """Identifiers derived from user input inside [start, end].

    Returns {ident: (assign_line, origin)} where origin is either the matched
    source text or the parent tainted identifier — enough to rebuild the chain
    for the review's flow narrative. Fixpoint over assignment lines, so
    `q = request.args…; sql = "…" + q` marks both `q` and `sql`.
    """
    tainted: dict = {}
    for _ in range(6):   # fixpoint; chains deeper than 6 hops are vanishingly rare
        changed = False
        for n in range(start, min(end, len(lines)) + 1):
            m = _ASSIGN_RE.match(lines[n - 1])
            if not m:
                continue
            lhs, rhs = m.group(1), m.group(2)
            if lhs in tainted:
                continue
            src_hit = source_re.search(rhs)
            if src_hit:
                tainted[lhs] = (n, src_hit.group(0))
                changed = True
                continue
            for t in list(tainted):   # snapshot: we may add lhs to tainted below
                if re.search(rf"\b{re.escape(t)}\b", rhs):
                    tainted[lhs] = (n, t)
                    changed = True
                    break
        if not changed:
            break
    return tainted


def _chain_for(ident: str, tainted: dict) -> list:
    """[(ident, line, origin), ...] from source to `ident` (source first)."""
    chain, seen = [], set()
    cur = ident
    while cur in tainted and cur not in seen:
        seen.add(cur)
        n, origin = tainted[cur]
        chain.append((cur, n, origin))
        cur = origin if origin in tainted else None
        if cur is None:
            break
    return list(reversed(chain))


# ── fix suggestions ───────────────────────────────────────────────────────────

_SQL_PARAM_NOTE = (
    "Bind values as parameters instead of interpolating them into the SQL text: "
    "cur.execute(\"… WHERE x = %s\", (value,)). Placeholder syntax varies by "
    "driver (%s psycopg/MySQLdb, ? sqlite3) — match yours.")


def _fix_param_sql(line: str):
    """execute(f"... {x} ...") → execute("... %s ...", (x,)) — sketch.

    Only the f-string shape can be rewritten mechanically. For the equally
    common `%`, `.format()` and string-concatenation shapes we can't reliably
    reconstruct the value list from one line, but the finding must still carry
    remediation — so fall back to parameterization advice rather than nothing.
    """
    m = re.search(r"""(execute(?:many)?\(\s*)f(['\"])(.+?)\2""", line)
    exprs = ([e.strip() for e in re.findall(r"\{([^{}:!]+)(?:[:!][^{}]*)?\}", m.group(3))]
             if m else [])
    if not m or not exprs:
        return {"diff": None, "note": _SQL_PARAM_NOTE, "kind": "advice"}
    sql = re.sub(r"\{[^{}]+\}", "%s", m.group(3))
    new = (line[:m.start()] + m.group(1) + m.group(2) + sql + m.group(2)
           + ", (" + ", ".join(exprs) + ",)" + line[m.end():])
    return {"diff": [["-", line.strip()], ["+", new.strip()]],
            "note": _SQL_PARAM_NOTE, "kind": "sketch"}


def _mk_replace(needle: str, repl: str, note: str, kind: str = "mechanical"):
    def build(line: str):
        if needle not in line:
            return None
        return {"diff": [["-", line.strip()], ["+", line.replace(needle, repl).strip()]],
                "note": note, "kind": kind}
    return build


def _fix_advice(note: str):
    return lambda _line: {"diff": None, "note": note, "kind": "advice"}


# (predicate over (rule_text, line), builder(line) -> suggestion|None) — first hit wins.
_FIX_TABLE = [
    (lambda t, l: "yaml.load(" in l and "safe_load" not in l and "Loader" not in l,
     _mk_replace("yaml.load(", "yaml.safe_load(",
                 "safe_load refuses arbitrary Python object construction; only fall back "
                 "to a custom Loader if the file genuinely needs custom tags.")),
    (lambda t, l: re.search(r"\bverify\s*=\s*False", l) is not None,
     _mk_replace("verify=False", "verify=True",
                 "Disabling TLS verification allows trivial man-in-the-middle. If a "
                 "private CA is the blocker, pass verify=\"/path/to/ca-bundle.pem\".")),
    (lambda t, l: re.search(r"\bdebug\s*=\s*True", l) is not None,
     _mk_replace("debug=True", "debug=False",
                 "Debug mode exposes the interactive debugger/console — remote code "
                 "execution if the port is reachable. Gate it on an env var for dev.")),
    (lambda t, l: re.search(r"\bshell\s*=\s*True", l) is not None,
     lambda l: {"diff": [["-", l.strip()],
                         ["+", re.sub(r",?\s*shell\s*=\s*True", "", l).strip()]],
                "note": "Drop shell=True and pass the command as an argv list "
                        "([\"prog\", arg1, ...]); if shell features are truly needed, "
                        "shlex.quote() every interpolated value.",
                "kind": "sketch"}),
    (lambda t, l: "hashlib.md5(" in l or "hashlib.sha1(" in l,
     lambda l: {"diff": [["-", l.strip()],
                         ["+", l.replace("hashlib.md5(", "hashlib.sha256(")
                                .replace("hashlib.sha1(", "hashlib.sha256(").strip()]],
                "note": "MD5/SHA-1 are collision-broken. For security uses switch to "
                        "SHA-256+ (passwords: use a KDF — bcrypt/scrypt/argon2). For a "
                        "non-security checksum, keep the digest but declare it: "
                        "hashlib.md5(data, usedforsecurity=False).",
                "kind": "sketch"}),
    (lambda t, l: re.search(r"(?<![\w.])eval\s*\(", l) is not None and "lang:python" in t,
     lambda l: {"diff": [["-", l.strip()],
                         ["+", re.sub(r"(?<![\w.])eval\s*\(", "ast.literal_eval(", l).strip()]],
                "note": "literal_eval only accepts data literals — no calls, no "
                        "attribute access. If you need expressions, evaluate against an "
                        "explicit allowlisted namespace instead of raw eval.",
                "kind": "sketch"}),
    (lambda t, l: "pickle.load" in l or "marshal.load" in l,
     _fix_advice("Never unpickle data that crosses a trust boundary — deserialization "
                 "executes arbitrary code. Prefer json for data interchange; if the "
                 "format must stay binary, sign the payload (hmac) and verify before "
                 "loading.")),
    (lambda t, l: "os.system(" in l,
     _fix_advice("os.system passes the string through a shell. Replace it with "
                 "subprocess.run([...], check=True) built from an argv LIST — each "
                 "argument a separate element, never one concatenated string — so "
                 "shell metacharacters in user input stay inert.")),
    (lambda t, l: ".innerHTML" in l and "=" in l,
     _mk_replace(".innerHTML", ".textContent",
                 "textContent never parses markup. If the value must contain HTML, "
                 "sanitize it (DOMPurify) before assignment instead.", "sketch")),
    (lambda t, l: re.search(r"['\"]http://", l) is not None,
     lambda l: {"diff": [["-", l.strip()], ["+", l.replace("http://", "https://").strip()]],
                "note": "Cleartext HTTP exposes the request (and any credential in it) "
                        "to on-path attackers.", "kind": "mechanical"}),
    (lambda t, l: _SECRET_RULE_RE.search(t) is not None,
     _fix_advice("Move the value to an environment variable or secret store and load "
                 "it at runtime (e.g. os.environ[\"SERVICE_TOKEN\"]). Treat the "
                 "committed value as compromised: rotate it, then purge it from git "
                 "history.")),
    (lambda t, l: re.search(r"sql|injection", t) is not None
                  and re.search(r"execute(?:many)?\(", l) is not None,
     _fix_param_sql),
    (lambda t, l: re.search(r"random\.(random|randint|randrange|choice)\s*\(", l) is not None
                  and re.search(r"token|secret|password|otp|nonce|session|key", t) is not None,
     _fix_advice("random is a predictable PRNG — recoverable from a handful of "
                 "outputs. Use the secrets module (secrets.token_hex / "
                 "secrets.token_urlsafe / secrets.randbelow) for anything an attacker "
                 "must not guess.")),
    (lambda t, l: re.search(r"traversal|\.\./|path.?injection", t) is not None,
     _fix_advice("Canonicalize before use: p = os.path.realpath(os.path.join(base, "
                 "user_value)) then reject unless p.startswith(os.path.realpath(base) "
                 "+ os.sep). For upload filenames, werkzeug.utils.secure_filename.")),
    (lambda t, l: re.search(r"redirect", t) is not None,
     _fix_advice("Validate the target against an allowlist of internal paths (or "
                 "require it to start with a single \"/\") before redirecting — never "
                 "redirect to a raw user-supplied URL.")),
]


def _suggest_fix(rule_text: str, line: str):
    for pred, build in _FIX_TABLE:
        try:
            if pred(rule_text, line):
                sug = build(line)
                if sug:
                    return sug
        except Exception:
            continue
    return None


# ── the review itself ─────────────────────────────────────────────────────────

def review_finding(rel: str, line_no: int, lines: list, src: str, finding: dict) -> dict:
    """Build the review dict for one finding whose file is already loaded."""
    lang = _lang_of(rel)
    source_re = _source_re(lang)
    flagged = lines[line_no - 1] if 0 < line_no <= len(lines) else ""
    scope = _enclosing_scope(lines, src, line_no, lang)
    # fix-table predicates match on this: rule metadata + a lang tag so
    # language-specific rewrites (e.g. ast.literal_eval) only fire where valid
    rule_text = (" ".join(str(finding.get(k, "")) for k in ("id", "title", "cwe")).lower()
                 + f" lang:{lang}")

    tainted = _taint_map(lines, scope["start"], scope["end"], source_re)
    direct = source_re.search(flagged)
    used = sorted(t for t in tainted
                  if re.search(rf"\b{re.escape(t)}\b", flagged))
    # sanitizer anywhere on the source→sink path: the flagged line itself or
    # any assignment line of an identifier the flagged line uses
    path_lines = [flagged] + [lines[tainted[t][0] - 1] for t in used
                              if 0 < tainted[t][0] <= len(lines)]
    sanitized = any(_SANITIZER_RE.search(pl) for pl in path_lines)
    low_path = _LOWRISK_PATH_RE.search(rel or "")
    secret_rule = _SECRET_RULE_RE.search(rule_text)
    # all call args are literals AND nothing interpolates/concatenates into them
    # (f-string braces, template-literal ${}, string + var would all sneak
    # attacker data past the "it's a constant" conclusion). The single-`(` guard
    # keeps a second call on the same line (`dangerous(x) or note("ok")`) from
    # matching on its literal paren and wrongly dismissing the real call — a
    # false "not exploitable" is the worst error direction for a security tool.
    constant_only = (not secret_rule and not direct and not used
                     and flagged.count("(") == 1
                     and _LITERAL_ARGS_RE.search(flagged) is not None
                     and not any(ch in flagged for ch in ("{", "$", "+", "%")))

    where = (f"`{scope['name']}()` (lines {scope['start']}–{scope['end']})"
             if scope.get("name") else f"lines {scope['start']}–{scope['end']}")
    evidence, flow = [], []

    if direct:
        evidence.append(f"attacker-controlled input ({direct.group(0)}) is used "
                        f"directly on the flagged line {line_no}")
        flow.append(f"{direct.group(0)} → flagged line {line_no}")
    for t in used:
        chain = _chain_for(t, tainted)
        if not chain:
            continue
        first = chain[0]
        evidence.append(f"`{t}` derives from user input "
                        f"({first[2]}, line {first[1]}) and is used on line {line_no}")
        flow.append(" → ".join(f"{c[2]} (line {c[1]})" if i == 0 else c[0]
                               for i, c in enumerate(chain))
                    + f" → flagged line {line_no}")

    # Path context outranks the taint verdict: a "vulnerable" flow inside
    # tests/fixtures/vendor is deliberate or unshipped far more often than not.
    # The taint evidence collected above stays in the review either way, so a
    # reader can still see the flow and overrule the downgrade.
    if low_path:
        verdict, confidence = VERDICT_FALSE_POSITIVE, "medium"
        evidence.append("file sits under a test/fixture/vendor path — usually not "
                        "production attack surface")
        summary = ("Hit is in test/fixture/vendored code"
                   + (" (a real input→sink flow exists — see evidence)" if direct or used else "")
                   + ". Confirm it never ships or runs in production, then suppress "
                     "with that reason.")
    elif direct or used:
        if sanitized:
            verdict, confidence = VERDICT_VALIDATE, "medium"
            evidence.append("a sanitizer/parameterization marker appears on the "
                            "input path — confirm it actually neutralizes this sink")
        else:
            verdict = VERDICT_EXPLOITABLE
            confidence = "high" if direct else "medium"
            evidence.append("no sanitization or parameterization is visible between "
                            "the input and the flagged sink")
        summary = (f"User input reaches the flagged line inside {where} with "
                   f"{'a sanitizer in the path' if sanitized else 'no visible sanitization'} — "
                   f"{'verify the sanitizer fits this sink' if sanitized else 'treat as exploitable until proven otherwise'}.")
    elif constant_only:
        verdict, confidence = VERDICT_FALSE_POSITIVE, "medium"
        evidence.append(f"every argument on the flagged line {line_no} is a constant "
                        "literal — nothing attacker-controlled")
        summary = ("The flagged call takes only constant arguments; the weakness "
                   "class is real but there is no attacker-controlled data here. "
                   "Fix opportunistically or suppress as accepted risk.")
    else:
        verdict, confidence = VERDICT_VALIDATE, ("medium" if tainted else "low")
        if tainted:
            evidence.append(f"user input enters {where} "
                            f"(e.g. line {min(v[0] for v in tainted.values())}) but no "
                            f"assignment chain reaches the flagged line {line_no}")
        else:
            evidence.append(f"no user-input source is visible inside {where} — the "
                            "flagged value may still arrive via parameters or fields")
        summary = ("Static evidence alone cannot confirm attacker reach here; trace "
                   "the flagged value's callers before deciding.")

    review = {
        "verdict": verdict,
        "confidence": confidence,
        "summary": summary,
        "evidence": evidence,
        "function": {"name": scope.get("name"), "start": scope["start"],
                     "end": scope["end"], "lang": lang, "kind": scope["kind"]},
    }
    if flow:
        review["flow"] = flow
    suggestion = _suggest_fix(rule_text, flagged)
    if suggestion:
        review["suggestion"] = suggestion
    return review


def review_findings(scan_root: Path, findings: list) -> int:
    """Attach `review` to each reviewable finding. Returns how many got one.

    Read-only and best-effort: unreadable files, path escapes, oversized files
    and parser blowups all just skip that finding.
    """
    root = Path(scan_root).resolve()
    cache: dict = {}
    reviewed = 0
    for f in findings:
        if reviewed >= _MAX_REVIEWED:
            break
        rel, line = f.get("file"), f.get("line")
        if not rel or not isinstance(line, int) or line < 1:
            continue
        try:
            target = (root / rel).resolve()
            target.relative_to(root)          # reject path escapes
        except (ValueError, OSError):
            continue
        entry = cache.get(str(target))
        if entry is None:
            try:
                if target.stat().st_size > _MAX_FILE_BYTES:
                    cache[str(target)] = False
                    continue
                src = target.read_text(encoding="utf-8", errors="replace")
            except OSError:
                cache[str(target)] = False
                continue
            entry = (src, src.splitlines())
            cache[str(target)] = entry
        if entry is False:
            continue
        src, lines = entry
        try:
            f["review"] = review_finding(rel, line, lines, src, f)
            reviewed += 1
        except Exception:
            continue
    return reviewed
