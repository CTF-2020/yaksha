"""assetgraph/model.py — data model for the persistent, accumulating asset graph.

Two node scopes, deliberately different identity rules:

  * ``repo`` / ``entry_point`` / ``data_store`` nodes are *repo-scoped* — an
    entry point only means something relative to the repo it lives in, so its
    identity includes the repo id.
  * ``external_service`` / ``trust_boundary`` nodes are *global* — identity is
    just the target/name, with no repo id. When two different repos both call
    the same external target, or both cross the same class of trust boundary,
    they resolve to the SAME node with two edges into it. That merge is the
    entire point of a graph over a list of reports: "which of our repos talk
    to this service" is a question a list of per-repo scans can't answer, a
    shared node with multiple incoming edges can.

Edges, not nodes, carry ``status``: a node persists once created (it is just
an identity + latest-observed attributes); whether it is *currently* relevant
is a property of whether any edge into it is still active, which can differ
per repo (repo A stopped calling a service repo B still calls).
"""
from __future__ import annotations

from dataclasses import dataclass, field

ASSET_KINDS = ("repo", "entry_point", "data_store", "external_service", "trust_boundary")
EDGE_STATUSES = ("active", "stale")


@dataclass
class Asset:
    id: str
    kind: str
    name: str
    attributes: dict = field(default_factory=dict)
    first_seen_at: str = ""
    last_seen_at: str = ""
    observation_count: int = 0


@dataclass
class AssetEdge:
    id: str
    from_id: str
    to_id: str
    relation: str            # "contains" | "crosses"
    status: str = "active"
    first_seen_at: str = ""
    last_seen_at: str = ""
    first_seen_report_id: str = ""
    last_seen_report_id: str = ""
