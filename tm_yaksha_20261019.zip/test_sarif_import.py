"""Tests for SARIF 2.1.0 import (sarif_import) + the /reports/import/sarif API.

Coverage: severity resolution precedence, CWE/OWASP scraping, physical vs
logical locations, ruleId/ruleIndex resolution, a round-trip through the
existing exporter (sarif.to_sarif), the HTTP endpoint (JSON + multipart), and
the payoff — an imported scanner report correlating with a DAST report into a
confirmed-exploitable verdict.
"""
from __future__ import annotations

import io
import json
import unittest

import sarif_import
import sarif as sarif_export


def _doc(results, rules=None, tool="semgrep", version="2.1.0"):
    return {
        "version": version,
        "runs": [{
            "tool": {"driver": {"name": tool, "rules": rules or []}},
            "results": results,
        }],
    }


class TestSarifImportParsing(unittest.TestCase):
    def test_minimal_result_becomes_category(self):
        doc = _doc([{
            "ruleId": "py.sqli",
            "level": "error",
            "message": {"text": "SQL injection via string formatting"},
            "locations": [{"physicalLocation": {
                "artifactLocation": {"uri": "app/db.py"},
                "region": {"startLine": 42}}}],
        }])
        report = sarif_import.from_sarif(doc)
        self.assertEqual(report["methodology"], "sast")
        self.assertEqual(len(report["categories"]), 1)
        cat = report["categories"][0]
        self.assertEqual(cat["id"], "py.sqli")
        self.assertEqual(cat["_source"], "SAST")
        self.assertEqual(cat["risk"], "High")             # level error -> High
        self.assertEqual(cat["threats"][0]["name"], "app/db.py:42")
        self.assertIn("semgrep", report["title"])

    def test_security_severity_beats_level(self):
        doc = _doc([{
            "ruleId": "r1", "level": "warning",           # would be Medium
            "properties": {"security-severity": "9.6"},   # but this wins -> Critical
            "message": {"text": "x"},
            "locations": [{"physicalLocation": {
                "artifactLocation": {"uri": "a.py"}, "region": {"startLine": 1}}}],
        }])
        self.assertEqual(sarif_import.from_sarif(doc)["categories"][0]["risk"],
                         "Critical")

    def test_rule_default_level_used_when_result_has_none(self):
        doc = _doc(
            results=[{"ruleId": "r1", "message": {"text": "x"}, "locations": []}],
            rules=[{"id": "r1", "defaultConfiguration": {"level": "note"}}])
        self.assertEqual(sarif_import.from_sarif(doc)["categories"][0]["risk"], "Low")

    def test_cwe_from_github_style_tag(self):
        doc = _doc(
            results=[{"ruleId": "r1", "level": "error",
                      "message": {"text": "x"}, "locations": []}],
            rules=[{"id": "r1", "properties": {
                "tags": ["security", "external/cwe/cwe-89"]}}])
        cat = sarif_import.from_sarif(doc)["categories"][0]
        self.assertEqual(cat["cwe"], "CWE-89")

    def test_cwe_from_relationships(self):
        doc = _doc(
            results=[{"ruleId": "r1", "level": "error",
                      "message": {"text": "x"}, "locations": []}],
            rules=[{"id": "r1", "relationships": [
                {"target": {"id": "CWE-79", "name": "XSS"}}]}])
        self.assertEqual(sarif_import.from_sarif(doc)["categories"][0]["cwe"],
                         "CWE-79")

    def test_owasp_tag_scraped(self):
        doc = _doc(
            results=[{"ruleId": "r1", "level": "error",
                      "message": {"text": "x"}, "locations": []}],
            rules=[{"id": "r1", "properties": {"tags": ["WEB-A03"]}}])
        self.assertEqual(sarif_import.from_sarif(doc)["categories"][0]["owasp"],
                         "WEB-A03")

    def test_logical_location_when_no_physical(self):
        doc = _doc([{
            "ruleId": "r1", "level": "warning", "message": {"text": "x"},
            "locations": [{"logicalLocations": [
                {"fullyQualifiedName": "com.acme.Auth.login"}]}],
        }])
        cat = sarif_import.from_sarif(doc)["categories"][0]
        self.assertEqual(cat["threats"][0]["name"], "com.acme.Auth.login")

    def test_ruleindex_fallback_when_no_ruleid(self):
        doc = _doc(
            results=[{"ruleIndex": 1, "level": "error",
                      "message": {"text": "x"}, "locations": []}],
            rules=[{"id": "first"}, {"id": "second"}])
        cat = sarif_import.from_sarif(doc)["categories"][0]
        self.assertEqual(cat["id"], "second")

    def test_multiple_hits_same_rule_group_into_one_card(self):
        loc = lambda u, n: {"physicalLocation": {
            "artifactLocation": {"uri": u}, "region": {"startLine": n}}}
        doc = _doc([
            {"ruleId": "r1", "level": "error", "message": {"text": "a"},
             "locations": [loc("x.py", 1)]},
            {"ruleId": "r1", "level": "warning", "message": {"text": "b"},
             "locations": [loc("y.py", 2)]},
        ])
        report = sarif_import.from_sarif(doc)
        self.assertEqual(len(report["categories"]), 1)
        cat = report["categories"][0]
        self.assertEqual(len(cat["threats"]), 2)
        self.assertEqual(cat["risk"], "High")   # worst of {High, Medium}
        self.assertEqual(report["scan_metadata"]["findings_total"], 2)

    def test_snippet_preserved(self):
        doc = _doc([{
            "ruleId": "r1", "level": "error", "message": {"text": "x"},
            "locations": [{"physicalLocation": {
                "artifactLocation": {"uri": "a.py"},
                "region": {"startLine": 5, "snippet": {"text": "os.system(cmd)"}}}}],
        }])
        cat = sarif_import.from_sarif(doc)["categories"][0]
        self.assertEqual(cat["threats"][0]["description"], "os.system(cmd)")


class TestSarifImportErrors(unittest.TestCase):
    def test_non_dict_rejected(self):
        with self.assertRaises(sarif_import.SarifError):
            sarif_import.from_sarif([])

    def test_missing_runs_rejected(self):
        with self.assertRaises(sarif_import.SarifError):
            sarif_import.from_sarif({"version": "2.1.0"})

    def test_wrong_version_rejected(self):
        with self.assertRaises(sarif_import.SarifError):
            sarif_import.from_sarif({"version": "1.0.0", "runs": []})

    def test_empty_runs_is_empty_report_not_error(self):
        report = sarif_import.from_sarif({"version": "2.1.0", "runs": []})
        self.assertEqual(report["categories"], [])
        self.assertEqual(report["overall_risk"], "Info")


class TestSarifRoundTrip(unittest.TestCase):
    def test_import_then_export_preserves_rule_and_location(self):
        doc = _doc(
            results=[{"ruleId": "py.sqli", "level": "error",
                      "message": {"text": "SQLi"},
                      "properties": {"security-severity": "8.9"},
                      "locations": [{"physicalLocation": {
                          "artifactLocation": {"uri": "app/db.py"},
                          "region": {"startLine": 42}}}]}],
            rules=[{"id": "py.sqli", "properties": {
                "tags": ["external/cwe/cwe-89", "WEB-A03"]}}])
        report = sarif_import.from_sarif(doc)
        report["id"] = "rt1"
        out = sarif_export.to_sarif(report)
        run = out["runs"][0]
        self.assertEqual([r["id"] for r in run["tool"]["driver"]["rules"]],
                         ["py.sqli"])
        res = run["results"][0]
        self.assertEqual(res["ruleId"], "py.sqli")
        self.assertEqual(res["level"], "error")            # High -> error
        phys = res["locations"][0]["physicalLocation"]
        self.assertEqual(phys["artifactLocation"]["uri"], "app/db.py")
        self.assertEqual(phys["region"]["startLine"], 42)


class TestSarifImportApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        cls._saved = []

    @classmethod
    def tearDownClass(cls):
        for rid in cls._saved:
            # Imported SARIF reports are sast-methodology: deletable only via
            # the SAST API surface.
            cls.client.delete(f"/api/v1/sast/reports/{rid}",
                              headers={"X-CSRF-Token": cls.csrf})

    def _sarif_bytes(self):
        return json.dumps(_doc([{
            "ruleId": "py.sqli", "level": "error", "message": {"text": "SQLi"},
            "locations": [{"physicalLocation": {
                "artifactLocation": {"uri": "app/db.py"},
                "region": {"startLine": 42}}}],
        }], rules=[{"id": "py.sqli", "properties": {
            "tags": ["external/cwe/cwe-89"]}}])).encode("utf-8")

    def test_import_json_body(self):
        r = self.client.post(
            "/api/v1/reports/import/sarif?source=CodeQL",
            data=self._sarif_bytes(), content_type="application/json",
            headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        j = r.get_json()
        self.assertEqual(j["tool"], "CodeQL")
        self.assertEqual(j["findings_total"], 1)
        self.assertEqual(j["overall_risk"], "High")
        self._saved.append(j["report_id"])
        # Imported SARIF is a SAST report: served only by the SAST API surface.
        r = self.client.get(f"/api/v1/reports/{j['report_id']}")
        self.assertEqual(r.status_code, 404)
        got = self.client.get(f"/api/v1/sast/reports/{j['report_id']}").get_json()
        self.assertEqual(got["report"]["categories"][0]["id"], "py.sqli")

    def test_import_multipart_file(self):
        data = {"file": (io.BytesIO(self._sarif_bytes()), "out.sarif"),
                "source": "semgrep"}
        r = self.client.post(
            "/api/v1/reports/import/sarif", data=data,
            content_type="multipart/form-data",
            headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        j = r.get_json()
        self.assertEqual(j["tool"], "semgrep")
        self._saved.append(j["report_id"])

    def test_invalid_json_body_rejected(self):
        r = self.client.post(
            "/api/v1/reports/import/sarif", data=b"not json",
            content_type="application/json",
            headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 400)

    def test_non_sarif_json_rejected(self):
        r = self.client.post(
            "/api/v1/reports/import/sarif", json={"hello": "world"},
            headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 400)
        self.assertIn("invalid SARIF", r.get_json()["error"])


class TestImportedReportCorrelates(unittest.TestCase):
    """The payoff: an imported scanner finding + a DAST finding at the same
    feature must correlate to confirmed_exploitable — proving import feeds the
    mediator exactly like a native SAST report."""

    def test_imported_sast_plus_dast_is_confirmed_exploitable(self):
        from correlator import engine
        from correlator.model import Verdict

        sarif = sarif_import.from_sarif(_doc(
            results=[{"ruleId": "py.sqli", "level": "error",
                      "message": {"text": "SQL injection in user search"},
                      "locations": [{"physicalLocation": {
                          "artifactLocation": {"uri": "search/users.py"},
                          "region": {"startLine": 42}}}]}],
            rules=[{"id": "py.sqli", "properties": {
                "tags": ["external/cwe/cwe-89"]}}]))
        sarif["id"] = "imp-sast"

        dast = {
            "id": "dyn1", "methodology": "dast",
            "categories": [{
                "id": "DAST-SQLI", "name": "SQL Injection", "risk": "High",
                "_source": "DAST", "cwe": "CWE-89",
                "affected_components": ["/api/users/search?q="],
                "threats": [{"name": "/api/users/search?q="}],
            }],
        }
        findings = engine.correlate([sarif, dast])
        sqli = [f for f in findings if f.family == "sql-injection"]
        self.assertTrue(sqli, "expected a sql-injection cluster")
        self.assertEqual(sqli[0].verdict, Verdict.CONFIRMED_EXPLOITABLE)


if __name__ == "__main__":
    unittest.main()
