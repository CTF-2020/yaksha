"""Server-side report normalization + sanitization for the reports API.

Turns a stored report into structured, HTML-safe views so consumers (the web
viewer, CI, other tools) get clean data through the API instead of re-deriving
structure client-side. Every string that could carry untrusted content — finding
titles, code snippets, file paths, remediations (a SAST snippet is literally repo
file content, and an /import report is fully attacker-controlled) — is
HTML-escaped here. A consumer that drops an escaped value into the DOM therefore
cannot be XSS'd regardless of its own escaping: safety is a property of the API
response, not of the client.

Public surface:
  * ``normalize_structure(report)`` — report -> {meta, categories[-> findings]}.
  * ``flat_findings(report)``       — a flat finding list with parsed file/line.
  * ``extract_paths(report)``       — unique affected paths/components/loci.
  * ``sanitize_report(report)``     — deep copy with every string HTML-escaped.
"""
from __future__ import annotations

import copy
import re

# Threat names may be prefixed like "[Static (code)] path:line" — keep the tail.
_PREFIX_RE = re.compile(r"^\[[^\]]+\]\s*(.+)$")
# "path/to/file.py:42" (not a URL) -> (path, line).
_FILE_LINE_RE = re.compile(r"^(?!\w+://)(.+?):(\d+)\b")


def html_escape(value) -> str:
    """HTML-escape a value for safe inclusion in markup (incl. attributes)."""
    return (str(value if value is not None else "")
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&#39;"))


def _num(value):
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    return int(n) if n == int(n) else n


def _split_path_line(locus: str) -> tuple[str, int | None]:
    """Parse a locus into (path, line). URLs/components keep line = None."""
    s = str(locus or "").strip()
    m = _PREFIX_RE.match(s)
    if m:
        s = m.group(1).strip()
    m = _FILE_LINE_RE.match(s)
    if m:
        return m.group(1).strip(), int(m.group(2))
    return s, None


def _category_loci(category: dict) -> list[str]:
    """Ordered, de-duplicated location strings for a category."""
    loci = [str(t["name"]) for t in category.get("threats", []) or []
            if isinstance(t, dict) and t.get("name")]
    if not loci:
        loci = [str(x) for x in (category.get("affected_components") or []) if x]
    return list(dict.fromkeys(loci))


def _threats(category: dict) -> list[dict]:
    out = []
    for t in category.get("threats", []) or []:
        if not isinstance(t, dict):
            continue
        path, line = _split_path_line(t.get("name", ""))
        out.append({
            "locus": html_escape(t.get("name", "")),
            "path": html_escape(path),
            "line": line,
            "description": html_escape(t.get("description", "")),
            "attack_vector": html_escape(t.get("attack_vector", "")),
            "control_objective": html_escape(t.get("control_objective", "")),
            "source_kind": html_escape(t.get("source_kind", "")),
        })
    return out


def normalize_structure(report: dict) -> dict:
    """Report -> a compact, HTML-safe tree: meta + categories (+ findings)."""
    cats = [c for c in report.get("categories", []) if isinstance(c, dict)]
    categories = []
    for c in cats:
        categories.append({
            "id": html_escape(c.get("id", "")),
            "title": html_escape(c.get("title") or c.get("name") or c.get("id", "")),
            "risk": html_escape(c.get("risk") or c.get("severity") or "Info"),
            "risk_score": _num(c.get("risk_score")),
            "source": html_escape(c.get("_source") or c.get("methodology")
                                  or c.get("ruleset") or ""),
            "owasp": html_escape(c.get("owasp", "")),
            "cwe": html_escape(c.get("cwe", "")),
            "verdict": html_escape(c.get("verdict", "")),
            "components": [html_escape(x) for x in (c.get("affected_components") or []) if x],
            "remediation": html_escape(c.get("remediation") or c.get("mitigation") or ""),
            "threat_count": len([t for t in (c.get("threats") or []) if isinstance(t, dict)]),
            "threats": _threats(c),
        })
    return {
        "id": html_escape(report.get("id", "")),
        "title": html_escape(report.get("title", "")),
        "methodology": html_escape(report.get("methodology", "")),
        "methodology_label": html_escape(report.get("methodology_label", "")),
        "overall_risk": html_escape(report.get("aggregate_risk")
                                    or report.get("overall_risk", "")),
        "analyzed_at": html_escape(report.get("analyzed_at", "")),
        "summary": html_escape(report.get("summary", "")),
        "category_count": len(categories),
        "categories": categories,
    }


def flat_findings(report: dict) -> list[dict]:
    """A flat, HTML-safe finding list, one row per locus, with parsed file/line."""
    out = []
    for c in report.get("categories", []) or []:
        if not isinstance(c, dict):
            continue
        rule = c.get("id") or c.get("category") or ""
        risk = c.get("risk") or c.get("severity") or "Info"
        title = c.get("title") or c.get("name") or rule
        for locus in _category_loci(c) or [""]:
            path, line = _split_path_line(locus)
            out.append({
                "rule": html_escape(rule),
                "title": html_escape(title),
                "risk": html_escape(risk),
                "path": html_escape(path),
                "line": line,
                "locus": html_escape(locus),
                "owasp": html_escape(c.get("owasp", "")),
                "cwe": html_escape(c.get("cwe", "")),
                "verdict": html_escape(c.get("verdict", "")),
            })
    return out


def extract_paths(report: dict) -> list[dict]:
    """Unique affected paths/components/loci across the report (HTML-safe)."""
    seen: dict[str, dict] = {}
    for f in flat_findings(report):
        key = f["locus"] or f["path"]
        if key and key not in seen:
            seen[key] = {"path": f["path"], "line": f["line"],
                         "locus": f["locus"], "risk": f["risk"]}
    return list(seen.values())


def sanitize_report(report: dict):
    """Deep copy of the whole report with every string value HTML-escaped.

    A drop-in replacement for the raw report that is safe to render with
    innerHTML anywhere, at the cost of showing entity-encoded text in non-HTML
    consumers (which should use the raw report or the structured views instead).
    """
    return _sanitize(copy.deepcopy(report))


def _sanitize(value):
    if isinstance(value, str):
        return html_escape(value)
    if isinstance(value, list):
        return [_sanitize(v) for v in value]
    if isinstance(value, dict):
        return {k: _sanitize(v) for k, v in value.items()}
    return value
