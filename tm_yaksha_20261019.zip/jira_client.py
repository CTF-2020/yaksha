"""jira_client.py — Jira, Azure DevOps & Linear ticket creation, Confluence
report-page publishing, and read-side fetch of Jira issues / Confluence pages,
from threat model findings."""
from __future__ import annotations
import base64
import ipaddress
import json
import logging
import os
import socket
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Optional
from urllib.parse import urlencode, urlparse

log = logging.getLogger(__name__)


class UnsafeURLError(RuntimeError):
    """Raised when a caller-configurable integration URL fails the SSRF check."""


def _assert_safe_url(url: str) -> None:
    """Refuse to make an outbound call to anything but a public https host.

    jira_url/azure_org/confluence_base_url all come from the request body
    (see app.py's _create_tickets_impl/_publish_confluence_page_impl), so
    without this check any caller could point them at an internal service or
    a cloud metadata address and have the server fetch it — and, on Jira/
    Confluence, have the server POST full finding text there too. Real Jira
    Cloud/Confluence Cloud/Azure DevOps/Linear are https-only public SaaS
    endpoints, so requiring https + a non-private resolved address costs
    nothing for the legitimate case.

    This is a resolve-then-connect check, not a fully rebinding-proof one
    (the resolved address isn't pinned for the actual request) — acceptable
    here since these are low-frequency, human-configured integration calls,
    not a hot path, but worth knowing if this helper is ever reused.
    """
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise UnsafeURLError(f"refusing to call a non-https URL: {url!r}")
    host = parsed.hostname or ""
    if not host:
        raise UnsafeURLError(f"URL has no host: {url!r}")
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror as exc:
        raise UnsafeURLError(f"could not resolve host {host!r}: {exc}") from exc
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if (ip.is_private or ip.is_loopback or ip.is_link_local or
                ip.is_multicast or ip.is_reserved or ip.is_unspecified):
            raise UnsafeURLError(
                f"refusing to call {host!r}: resolves to a non-public address ({ip})")

# ── Data model ─────────────────────────────────────────────────────────────────

@dataclass
class TicketConfig:
    provider: str          # "jira" | "azure" | "linear" | "confluence"

    # Jira
    jira_url: str = ""            # e.g. https://myorg.atlassian.net
    jira_email: str = ""
    jira_token: str = ""
    jira_project_key: str = ""
    jira_issue_type: str = "Bug"
    jira_priority_map: dict = field(default_factory=lambda: {
        "Critical": "Highest",
        "High":     "High",
        "Medium":   "Medium",
        "Low":      "Low",
    })
    jira_labels: list[str] = field(default_factory=lambda: ["threat-model", "security"])
    jira_component: str = ""

    # Azure DevOps
    azure_org: str = ""           # e.g. https://dev.azure.com/myorg
    azure_project: str = ""
    azure_token: str = ""
    azure_area_path: str = ""
    azure_work_item_type: str = "Bug"
    azure_iteration: str = ""

    # Linear
    linear_api_key: str = ""
    linear_team_id: str = ""      # Linear issues require a team UUID, not a free-text key

    # Confluence — a wiki, not a tracker: see publish_report_page() below, which
    # publishes one page per report rather than one issue per finding. Auth is
    # HTTP Basic (email:api_token), the same mechanism as Jira, since it's the
    # same Atlassian identity.
    confluence_base_url: str = ""  # e.g. https://myorg.atlassian.net
    confluence_email: str = ""
    confluence_api_token: str = ""
    confluence_space_key: str = ""


@dataclass
class CreatedTicket:
    provider: str
    ticket_id: str
    url: str
    title: str
    severity: str
    status: str = "created"
    error: str = ""


# ── HTTP helper ────────────────────────────────────────────────────────────────

def _http(method: str, url: str, headers: dict, body: dict | None = None) -> dict:
    _assert_safe_url(url)
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code} {e.reason}: {e.read().decode(errors='replace')[:400]}")


# ── Jira ───────────────────────────────────────────────────────────────────────

def _jira_headers(cfg: TicketConfig) -> dict:
    creds = base64.b64encode(f"{cfg.jira_email}:{cfg.jira_token}".encode()).decode()
    return {
        "Authorization": f"Basic {creds}",
        "Content-Type":  "application/json",
        "Accept":        "application/json",
    }


def _text_to_adf(text: str) -> dict:
    """Render a plain (possibly multi-line) string as an ADF document that
    actually preserves its line breaks.

    Jira's ADF only breaks a line on an explicit ``hardBreak`` node between
    ``text`` nodes in a paragraph — embedded ``\\n`` characters inside a
    single text node are not special and render as literal whitespace, so a
    multi-line body built as one text node (the previous approach here)
    collapses into a run-on line in the Jira UI. This splits on ``\\n`` and
    threads a ``hardBreak`` between each line instead, in one paragraph.
    A blank line becomes two consecutive hardBreaks (no text node between
    them — ADF text nodes must be non-empty).
    """
    lines = str(text or "").split("\n")
    content: list[dict] = []
    for i, line in enumerate(lines):
        if i:
            content.append({"type": "hardBreak"})
        if line:
            content.append({"type": "text", "text": line})
    return {"type": "doc", "version": 1, "content": [{"type": "paragraph", "content": content}]}


def adf_to_text(node) -> str:
    """Flatten an Atlassian Document Format node (or a plain string) to text.

    The inverse of _text_to_adf above, used on the read side: Jira Cloud
    returns description/comment bodies as ADF, not plain text. Public (not
    api/design_review.py's former private copy) since both the webhook
    ingestion path and get_issue/get_issue_comments below need it.
    """
    if isinstance(node, str):
        return node
    if not isinstance(node, dict):
        return ""
    parts = []
    if node.get("type") == "text" and node.get("text"):
        parts.append(str(node["text"]))
    for child in node.get("content") or []:
        parts.append(adf_to_text(child))
    return " ".join(p for p in parts if p)


def _jira_create(cfg: TicketConfig, title: str, description: str, severity: str) -> CreatedTicket:
    url = f"{cfg.jira_url.rstrip('/')}/rest/api/3/issue"
    priority = cfg.jira_priority_map.get(severity, "Medium")

    fields: dict = {
        "project":   {"key": cfg.jira_project_key},
        "summary":   f"[TM-{severity}] {title}",
        "issuetype": {"name": cfg.jira_issue_type},
        "priority":  {"name": priority},
        "labels":    cfg.jira_labels,
        "description": _text_to_adf(description),
    }
    if cfg.jira_component:
        fields["components"] = [{"name": cfg.jira_component}]

    resp = _http("POST", url, _jira_headers(cfg), {"fields": fields})
    issue_key = resp.get("key", "?")
    issue_url = f"{cfg.jira_url.rstrip('/')}/browse/{issue_key}"
    return CreatedTicket(provider="jira", ticket_id=issue_key, url=issue_url, title=title, severity=severity)


def add_comment(cfg: TicketConfig, issue_key: str, body: str) -> None:
    """Post a comment on an existing Jira issue.

    Everything else in this module is one-directional (TM finding -> new
    ticket); this is the reverse leg used by the design-review webhook to
    close the loop back onto the ticket that triggered the review. Jira-only
    for now — raises if cfg isn't a Jira config, same as the create path's
    ValueError on an unknown provider.
    """
    if cfg.provider != "jira":
        raise ValueError(f"add_comment is Jira-only, got provider={cfg.provider!r}")
    url = f"{cfg.jira_url.rstrip('/')}/rest/api/3/issue/{issue_key}/comment"
    payload = {"body": _text_to_adf(body)}
    _http("POST", url, _jira_headers(cfg), payload)


_JIRA_ISSUE_FIELDS = ("summary,description,status,priority,issuetype,assignee,"
                      "reporter,labels,components,created,updated,resolution")


def _normalize_issue(cfg: TicketConfig, issue: dict) -> dict:
    fields = issue.get("fields") or {}
    key = issue.get("key", "")
    resolution = fields.get("resolution") or {}
    return {
        "key": key,
        "url": f"{cfg.jira_url.rstrip('/')}/browse/{key}" if key else "",
        "summary": str(fields.get("summary") or ""),
        "description": adf_to_text(fields.get("description")),
        "status": (fields.get("status") or {}).get("name", ""),
        "priority": (fields.get("priority") or {}).get("name", ""),
        "issue_type": (fields.get("issuetype") or {}).get("name", ""),
        "assignee": (fields.get("assignee") or {}).get("displayName", ""),
        "reporter": (fields.get("reporter") or {}).get("displayName", ""),
        "labels": fields.get("labels") or [],
        "components": [c.get("name", "") for c in (fields.get("components") or [])],
        "created": fields.get("created", ""),
        "updated": fields.get("updated", ""),
        "resolution": resolution.get("name", ""),
    }


def get_issue(cfg: TicketConfig, issue_key: str) -> dict:
    """Fetch one Jira issue's full details, normalized to a flat dict
    (ADF description already flattened to plain text)."""
    if cfg.provider != "jira":
        raise ValueError(f"get_issue is Jira-only, got provider={cfg.provider!r}")
    url = f"{cfg.jira_url.rstrip('/')}/rest/api/3/issue/{issue_key}?fields={_JIRA_ISSUE_FIELDS}"
    resp = _http("GET", url, _jira_headers(cfg))
    return _normalize_issue(cfg, resp)


def get_issue_comments(cfg: TicketConfig, issue_key: str, max_results: int = 50) -> list[dict]:
    """Fetch an issue's comments, newest-last (Jira's own order), ADF bodies
    flattened to plain text."""
    if cfg.provider != "jira":
        raise ValueError(f"get_issue_comments is Jira-only, got provider={cfg.provider!r}")
    max_results = max(1, min(int(max_results), 200))
    url = f"{cfg.jira_url.rstrip('/')}/rest/api/3/issue/{issue_key}/comment?maxResults={max_results}"
    resp = _http("GET", url, _jira_headers(cfg))
    return [
        {
            "id": c.get("id", ""),
            "author": (c.get("author") or {}).get("displayName", ""),
            "body": adf_to_text(c.get("body")),
            "created": c.get("created", ""),
            "updated": c.get("updated", ""),
        }
        for c in (resp.get("comments") or [])
    ]


def search_issues(cfg: TicketConfig, jql: str, max_results: int = 50) -> list[dict]:
    """Run a JQL search, returning normalized issues (same shape as
    get_issue, minus the extra GET-per-issue cost — Jira's search already
    returns the listed fields inline)."""
    if cfg.provider != "jira":
        raise ValueError(f"search_issues is Jira-only, got provider={cfg.provider!r}")
    max_results = max(1, min(int(max_results), 100))
    query = urlencode({"jql": jql, "maxResults": max_results, "fields": _JIRA_ISSUE_FIELDS})
    url = f"{cfg.jira_url.rstrip('/')}/rest/api/3/search?{query}"
    resp = _http("GET", url, _jira_headers(cfg))
    return [_normalize_issue(cfg, issue) for issue in (resp.get("issues") or [])]


# ── Azure DevOps ───────────────────────────────────────────────────────────────

def _azure_headers(cfg: TicketConfig) -> dict:
    token = base64.b64encode(f":{cfg.azure_token}".encode()).decode()
    return {
        "Authorization": f"Basic {token}",
        "Content-Type":  "application/json-patch+json",
        "Accept":        "application/json",
    }


def _azure_create(cfg: TicketConfig, title: str, description: str, severity: str) -> CreatedTicket:
    org = cfg.azure_org.rstrip("/")
    proj = cfg.azure_project
    wit  = cfg.azure_work_item_type.replace(" ", "%20")
    url  = f"{org}/{proj}/_apis/wit/workitems/${wit}?api-version=7.1"

    ops = [
        {"op": "add", "path": "/fields/System.Title",       "value": f"[TM-{severity}] {title}"},
        {"op": "add", "path": "/fields/System.Description", "value": description},
        {"op": "add", "path": "/fields/Microsoft.VSTS.Common.Priority",
         "value": {"Critical": 1, "High": 2, "Medium": 3, "Low": 4}.get(severity, 2)},
        {"op": "add", "path": "/fields/System.Tags",        "value": "threat-model; security"},
    ]
    if cfg.azure_area_path:
        ops.append({"op": "add", "path": "/fields/System.AreaPath", "value": cfg.azure_area_path})
    if cfg.azure_iteration:
        ops.append({"op": "add", "path": "/fields/System.IterationPath", "value": cfg.azure_iteration})

    resp = _http("POST", url, _azure_headers(cfg), ops)
    item_id = str(resp.get("id", "?"))
    item_url = resp.get("_links", {}).get("html", {}).get("href", f"{org}/{proj}/_workitems/edit/{item_id}")
    return CreatedTicket(provider="azure", ticket_id=item_id, url=item_url, title=title, severity=severity)


# ── Linear ─────────────────────────────────────────────────────────────────────

_LINEAR_API_URL = "https://api.linear.app/graphql"

# Linear has no severity/priority-name mapping like Jira/Azure — it uses a
# fixed 0-4 integer scale (0 = no priority, 1 = urgent ... 4 = low).
_LINEAR_PRIORITY = {"Critical": 1, "High": 2, "Medium": 3, "Low": 4}

_LINEAR_ISSUE_CREATE_MUTATION = """
mutation IssueCreate($input: IssueCreateInput!) {
  issueCreate(input: $input) {
    success
    issue { identifier url }
  }
}
"""


def _linear_headers(cfg: TicketConfig) -> dict:
    # Linear's own convention: the raw API key in Authorization, no "Bearer"
    # prefix and no Basic auth (unlike Jira/Azure/Confluence).
    return {
        "Authorization": cfg.linear_api_key,
        "Content-Type":  "application/json",
    }


def _linear_create(cfg: TicketConfig, title: str, description: str, severity: str) -> CreatedTicket:
    variables = {
        "input": {
            "teamId":      cfg.linear_team_id,
            "title":       f"[TM-{severity}] {title}",
            "description": description,
            "priority":    _LINEAR_PRIORITY.get(severity, 3),
        }
    }
    resp = _http("POST", _LINEAR_API_URL, _linear_headers(cfg),
                 {"query": _LINEAR_ISSUE_CREATE_MUTATION, "variables": variables})
    if resp.get("errors"):
        raise RuntimeError(f"Linear API error: {resp['errors']}")
    issue = (resp.get("data") or {}).get("issueCreate", {}).get("issue") or {}
    return CreatedTicket(provider="linear", ticket_id=issue.get("identifier", "?"),
                         url=issue.get("url", ""), title=title, severity=severity)


# ── Confluence ─────────────────────────────────────────────────────────────────
# Confluence is a wiki, not an issue tracker — publishing a threat-model report
# there means one page summarizing every finding, not one page per finding.
# Deliberately NOT wired through create_tickets_from_report()'s per-finding
# loop; see publish_report_page() below.

def _confluence_headers(cfg: TicketConfig) -> dict:
    creds = base64.b64encode(f"{cfg.confluence_email}:{cfg.confluence_api_token}".encode()).decode()
    return {
        "Authorization": f"Basic {creds}",
        "Content-Type":  "application/json",
        "Accept":        "application/json",
    }


def _report_page_body(report: dict) -> str:
    """Render a report's findings as Confluence storage-format (XHTML) markup."""
    rows = []
    for cat in report.get("categories", []):
        sev = cat.get("risk", cat.get("severity", "Info"))
        rows.append(
            "<tr>"
            f"<td>{cat.get('id','')}</td>"
            f"<td>{cat.get('name','')}</td>"
            f"<td>{sev}</td>"
            f"<td>{cat.get('description','')}</td>"
            "</tr>"
        )
    table = (
        "<table><thead><tr><th>ID</th><th>Finding</th><th>Severity</th>"
        "<th>Description</th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>"
    )
    summary = report.get("summary", "")
    return f"<p>{summary}</p>{table}"


def publish_report_page(report: dict, cfg: TicketConfig) -> CreatedTicket:
    """Publish one Confluence page summarizing every finding in ``report``.

    Unlike ``create_tickets_from_report``, this always creates exactly one new
    page (no update-existing-page diffing in v1) and is not severity-filtered
    — the page is a report artifact, not a per-finding actionable ticket.
    """
    url = f"{cfg.confluence_base_url.rstrip('/')}/wiki/rest/api/content"
    title = f"{report.get('title', 'Threat Model Report')} — {report.get('id', '')}"
    payload = {
        "type":  "page",
        "title": title,
        "space": {"key": cfg.confluence_space_key},
        "body": {
            "storage": {
                "value":          _report_page_body(report),
                "representation": "storage",
            }
        },
    }
    resp = _http("POST", url, _confluence_headers(cfg), payload)
    page_id = resp.get("id", "?")
    base = cfg.confluence_base_url.rstrip("/")
    webui = (resp.get("_links") or {}).get("webui", "")
    page_url = f"{base}{webui}" if webui else f"{base}/wiki/pages/{page_id}"
    return CreatedTicket(provider="confluence", ticket_id=page_id, url=page_url,
                         title=title, severity="")


class _StorageFormatTextExtractor(HTMLParser):
    """Flattens Confluence storage-format XHTML to plain text.

    Stdlib html.parser only, matching the convention dast/engine.py already
    established in this codebase (no bs4/lxml dependency) rather than
    introducing a new one just for this.
    """

    def __init__(self):
        super().__init__()
        self._parts: list[str] = []

    def handle_data(self, data: str) -> None:
        text = data.strip()
        if text:
            self._parts.append(text)

    def text(self) -> str:
        return " ".join(self._parts)


def confluence_html_to_text(html: str) -> str:
    parser = _StorageFormatTextExtractor()
    try:
        parser.feed(html or "")
    except Exception:
        # Malformed storage-format markup shouldn't take down the fetch --
        # callers still get whatever text was extracted before the parser
        # choked, same best-effort posture as the rest of this module's
        # read path.
        pass
    return parser.text()


def _normalize_confluence_page(cfg: TicketConfig, page: dict) -> dict:
    page_id = page.get("id", "")
    base = cfg.confluence_base_url.rstrip("/")
    webui = (page.get("_links") or {}).get("webui") or ""
    body_html = ((page.get("body") or {}).get("storage") or {}).get("value", "")
    version = page.get("version") or {}
    return {
        "id": page_id,
        "title": page.get("title", ""),
        "url": f"{base}{webui}" if webui else f"{base}/wiki/pages/{page_id}",
        "space_key": (page.get("space") or {}).get("key", ""),
        "version": version.get("number", 0),
        "body_html": body_html,
        "body_text": confluence_html_to_text(body_html),
        "updated": version.get("when", ""),
    }


def get_confluence_page(cfg: TicketConfig, page_id: str) -> dict:
    """Fetch one Confluence page's full details -- storage-format HTML plus
    a flattened plain-text rendering, so a caller that just wants the
    content (not markup) doesn't have to strip it itself."""
    if cfg.provider != "confluence":
        raise ValueError(f"get_confluence_page is Confluence-only, got provider={cfg.provider!r}")
    url = (f"{cfg.confluence_base_url.rstrip('/')}/wiki/rest/api/content/{page_id}"
           f"?expand=body.storage,version,space")
    resp = _http("GET", url, _confluence_headers(cfg))
    return _normalize_confluence_page(cfg, resp)


def search_confluence_pages(cfg: TicketConfig, cql: str, limit: int = 25) -> list[dict]:
    """Run a CQL search, returning lightweight result rows (id/title/url/type
    only -- call get_confluence_page(id) for the body of a specific hit)."""
    if cfg.provider != "confluence":
        raise ValueError(f"search_confluence_pages is Confluence-only, got provider={cfg.provider!r}")
    limit = max(1, min(int(limit), 100))
    base = cfg.confluence_base_url.rstrip("/")
    query = urlencode({"cql": cql, "limit": limit})
    url = f"{base}/wiki/rest/api/content/search?{query}"
    resp = _http("GET", url, _confluence_headers(cfg))
    out = []
    for page in (resp.get("results") or []):
        webui = (page.get("_links") or {}).get("webui") or ""
        out.append({
            "id": page.get("id", ""),
            "title": page.get("title", ""),
            "url": f"{base}{webui}" if webui else "",
            "type": page.get("type", ""),
        })
    return out


# ── Severity / verdict filters ────────────────────────────────────────────────

_SEV_RANK = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}

# Same ranking as correlator.model.Verdict, most- to least-actionable. Kept as
# a local literal (not imported from correlator.model) so jira_client has no
# hard dependency on the correlator package — a finding either carries a
# "verdict" string from the correlator or it doesn't, and this module only
# needs to rank the four known values.
_VERDICT_RANK = {
    "confirmed_exploitable": 0,
    "corroborated": 1,
    "design_gap": 2,
    "blind_spot": 3,
}
_VERDICT_LABEL = {
    "confirmed_exploitable": "Confirmed exploitable",
    "corroborated": "Corroborated",
    "design_gap": "Design gap",
    "blind_spot": "Blind spot",
}


def _finding_description(finding: dict) -> str:
    parts = [
        f"Threat Model Finding\n{'='*40}",
        f"Rule:      {finding.get('id', '')}",
        f"Severity:  {finding.get('risk', finding.get('severity', ''))}",
        f"Category:  {finding.get('id', '')} — {finding.get('name', '')}",
    ]
    verdict = finding.get("verdict")
    if verdict in _VERDICT_LABEL:
        parts.append(f"Verdict:   {_VERDICT_LABEL[verdict]}")
    parts += ["", "THREATS:"]
    for t in finding.get("threats", [])[:3]:
        parts.append(f"• {t.get('name','')}: {t.get('description','')}")
        if t.get("attack_vector"):
            parts.append(f"  Attack: {t['attack_vector']}")
    parts.append("\nMITIGATIONS:")
    for m in finding.get("mitigations", [])[:4]:
        action = m if isinstance(m, str) else m.get("action", "")
        priority = "" if isinstance(m, str) else f" [{m.get('priority','')}]"
        parts.append(f"• {action}{priority}")
    if finding.get("attack_techniques"):
        parts.append("\nMITRE ATT&CK:")
        for t in finding["attack_techniques"][:4]:
            parts.append(f"• {t['id']} {t['name']} ({t['tactic']})")
    if finding.get("compliance_controls"):
        parts.append("\nCOMPLIANCE:")
        for c in finding["compliance_controls"][:4]:
            parts.append(f"• {c['framework']} {c['control_id']}: {c['control_name']}")
    return "\n".join(parts)


# ── Public API ─────────────────────────────────────────────────────────────────

def create_tickets_from_report(
    report: dict,
    cfg: TicketConfig,
    min_severity: str = "High",
    min_verdict: str | None = None,
    dry_run: bool = False,
) -> list[CreatedTicket]:
    """
    Create tickets for all findings at or above min_severity.

    report: analyzer output dict (must have 'categories' list)
    cfg:    TicketConfig for provider
    min_severity: minimum severity to ticket ("Critical"|"High"|"Medium"|"Low")
    min_verdict: minimum correlation verdict to ticket ("confirmed_exploitable"|
        "corroborated"|"design_gap"|"blind_spot"), or None to ignore verdict
        entirely. Only findings that actually carry a "verdict" field (i.e.
        came from a correlation report) are filtered by it — a plain SAST or
        manual-review report has no verdict at all, and requiring one there
        would silently ticket nothing instead of falling back to severity-only
        filtering, which is what every caller before this parameter existed
        already relied on.
    dry_run: if True, return what would be created without calling the API
    """
    threshold = _SEV_RANK.get(min_severity, 1)
    verdict_threshold = _VERDICT_RANK.get(min_verdict) if min_verdict else None
    results: list[CreatedTicket] = []

    categories = report.get("categories", [])
    for cat in categories:
        cat_sev = cat.get("risk", cat.get("severity", "Info"))
        if _SEV_RANK.get(cat_sev, 4) > threshold:
            continue
        cat_verdict = cat.get("verdict")
        if verdict_threshold is not None and cat_verdict in _VERDICT_RANK \
                and _VERDICT_RANK[cat_verdict] > verdict_threshold:
            continue

        title = f"{cat.get('id','')} — {cat.get('name','')}"
        description = _finding_description(cat)

        if dry_run:
            results.append(CreatedTicket(
                provider=cfg.provider, ticket_id="DRY-RUN", url="",
                title=title, severity=cat_sev, status="dry_run",
            ))
            continue

        try:
            if cfg.provider == "jira":
                ticket = _jira_create(cfg, title, description, cat_sev)
            elif cfg.provider == "azure":
                ticket = _azure_create(cfg, title, description, cat_sev)
            elif cfg.provider == "linear":
                ticket = _linear_create(cfg, title, description, cat_sev)
            else:
                raise ValueError(f"Unknown provider: {cfg.provider}")
            results.append(ticket)
            log.info("Created %s ticket %s for %s", cfg.provider, ticket.ticket_id, title)
        except Exception as exc:
            log.error("Failed to create ticket for %s: %s", title, exc)
            results.append(CreatedTicket(
                provider=cfg.provider, ticket_id="", url="",
                title=title, severity=cat_sev, status="error", error=str(exc),
            ))

    return results


def config_from_env() -> Optional[TicketConfig]:
    """Build TicketConfig from environment variables."""
    provider = os.getenv("TM_TICKET_PROVIDER", "").lower()
    if provider == "jira":
        return TicketConfig(
            provider="jira",
            jira_url=os.getenv("JIRA_URL", ""),
            jira_email=os.getenv("JIRA_EMAIL", ""),
            jira_token=os.getenv("JIRA_TOKEN", ""),
            jira_project_key=os.getenv("JIRA_PROJECT", ""),
            jira_issue_type=os.getenv("JIRA_ISSUE_TYPE", "Bug"),
            jira_component=os.getenv("JIRA_COMPONENT", ""),
        )
    elif provider == "azure":
        return TicketConfig(
            provider="azure",
            azure_org=os.getenv("AZURE_ORG", ""),
            azure_project=os.getenv("AZURE_PROJECT", ""),
            azure_token=os.getenv("AZURE_PAT", ""),
            azure_area_path=os.getenv("AZURE_AREA_PATH", ""),
            azure_work_item_type=os.getenv("AZURE_WORK_ITEM_TYPE", "Bug"),
        )
    elif provider == "linear":
        return TicketConfig(
            provider="linear",
            linear_api_key=os.getenv("LINEAR_API_KEY", ""),
            linear_team_id=os.getenv("LINEAR_TEAM_ID", ""),
        )
    return None
