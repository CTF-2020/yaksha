"""Parse a SARIF 2.1.0 document into a Yaksha Guard TM report.

This is the inverse of ``sarif.py`` (which exports). Ingesting SARIF is the
leverage play: any scanner that speaks the OASIS standard — semgrep, CodeQL,
Bandit, Trivy, gitleaks, ESLint security plugins, most IDEs — becomes another
CODE-evidence source feeding the correlation engine, without a bespoke adapter
per tool. TM stops competing with scanners and becomes the mediator that
adjudicates them.

The output is deliberately the *same* category shape the SAST broker emits
(``_source: "SAST"``, one card per rule, one threat per hit, CWE/OWASP in
``notes``), so the report viewer, the SARIF *exporter*, and the correlator all
consume it with zero changes — a round-trip (import a scanner's SARIF, then
export TM's own SARIF) preserves rule ids, severities and locations.

Pure and dependency-light: dict in, dict out. No Flask, no filesystem.
"""
from __future__ import annotations

import re

# Local severity vocabulary so the module stands alone (no broker.config import).
SEVERITIES = ("Critical", "High", "Medium", "Low", "Info")
_SEVERITY_ORDER = {s: i for i, s in enumerate(SEVERITIES)}
_RISK_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}

# SARIF result.level -> our severity. `none` and anything unknown fold to Info.
_LEVEL_SEVERITY = {"error": "High", "warning": "Medium", "note": "Low",
                   "none": "Info"}

_CWE_RE = re.compile(r"CWE[-_ ]?(\d+)", re.I)
_OWASP_TAG_RE = re.compile(r"\b((?:WEB|API|LLM|AI|MOB|K8S)[-_][A-Z0-9]+)\b", re.I)
# GitHub encodes CWEs as tags like "external/cwe/cwe-89".
_CWE_TAG_RE = re.compile(r"cwe[-_/]+(\d+)", re.I)

_MAX_THREATS_PER_RULE = 50
_MAX_COMPONENTS = 25
_MAX_RESULTS = 20000          # a hard ceiling so a hostile file can't exhaust memory
_MAX_MSG = 2000


class SarifError(ValueError):
    """Raised when a document is not usable SARIF."""


# ── Severity resolution ───────────────────────────────────────────────────────
def _band_from_security_severity(value) -> str | None:
    """GitHub's numeric 0-10 ``security-severity`` -> our label band."""
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    if n >= 9.0:
        return "Critical"
    if n >= 7.0:
        return "High"
    if n >= 4.0:
        return "Medium"
    if n > 0.0:
        return "Low"
    return "Info"


def _severity_for(result: dict, rule: dict) -> str:
    """Resolve one result's severity, most-authoritative signal first.

    Numeric ``security-severity`` (result then rule) beats the coarse SARIF
    ``level`` (result then rule default), because scanners that set it encode a
    finer judgement than error/warning/note.
    """
    for props in (result.get("properties"), rule.get("properties")):
        if isinstance(props, dict):
            band = _band_from_security_severity(props.get("security-severity"))
            if band:
                return band
    level = str(result.get("level", "")).lower()
    if level in _LEVEL_SEVERITY:
        return _LEVEL_SEVERITY[level]
    default = rule.get("defaultConfiguration")
    if isinstance(default, dict):
        level = str(default.get("level", "")).lower()
        if level in _LEVEL_SEVERITY:
            return _LEVEL_SEVERITY[level]
    return "Info"


def _worst(severities) -> str:
    best = "Info"
    for s in severities:
        if _SEVERITY_ORDER.get(s, 99) < _SEVERITY_ORDER.get(best, 99):
            best = s
    return best


# ── Metadata scraping ─────────────────────────────────────────────────────────
def _rule_tags(rule: dict) -> list[str]:
    props = rule.get("properties")
    tags = props.get("tags") if isinstance(props, dict) else None
    return [str(t) for t in tags] if isinstance(tags, list) else []


def _cwes(rule: dict, result: dict) -> list[str]:
    """CWE ids from rule tags, rule relationships, and any free text."""
    found: set[str] = set()
    for tag in _rule_tags(rule):
        m = _CWE_TAG_RE.search(tag) or _CWE_RE.search(tag)
        if m:
            found.add(f"CWE-{int(m.group(1))}")
    # relationships[].target.id often carries the CWE for CodeQL/semgrep.
    for rel in rule.get("relationships", []) or []:
        if isinstance(rel, dict):
            tgt = rel.get("target", {})
            m = _CWE_RE.search(str(tgt.get("id", "")) + " " + str(tgt.get("name", "")))
            if m:
                found.add(f"CWE-{int(m.group(1))}")
    blob = " ".join([
        str(rule.get("id", "")), str(rule.get("name", "")),
        _text(rule.get("shortDescription")), _text(rule.get("fullDescription")),
        _text(result.get("message")),
    ])
    for m in _CWE_RE.finditer(blob):
        found.add(f"CWE-{int(m.group(1))}")
    return sorted(found, key=lambda c: int(c.split("-")[1]))


def _owasp(rule: dict, result: dict) -> str:
    for tag in _rule_tags(rule):
        m = _OWASP_TAG_RE.search(tag)
        if m:
            return m.group(1).upper().replace("_", "-")
    blob = str(rule.get("id", "")) + " " + _text(rule.get("shortDescription"))
    m = _OWASP_TAG_RE.search(blob.upper())
    return m.group(1).upper().replace("_", "-") if m else ""


def _text(node) -> str:
    """Pull ``.text`` out of a SARIF multiformatMessageString, tolerating shapes."""
    if isinstance(node, dict):
        return str(node.get("text") or node.get("markdown") or "")[:_MAX_MSG]
    if isinstance(node, str):
        return node[:_MAX_MSG]
    return ""


# ── Rule index + location ─────────────────────────────────────────────────────
def _build_rule_index(run: dict) -> tuple[dict, list]:
    """Return (rules_by_id, rules_by_index) across driver + extensions.

    Results reference rules by ``ruleId`` (string) or ``ruleIndex`` (into the
    driver's own rules array); we resolve id first, index as a fallback.
    """
    driver = (run.get("tool") or {}).get("driver") or {}
    driver_rules = [r for r in (driver.get("rules") or []) if isinstance(r, dict)]
    by_id: dict[str, dict] = {}
    for comp in [driver] + list((run.get("tool") or {}).get("extensions") or []):
        if not isinstance(comp, dict):
            continue
        for rule in comp.get("rules") or []:
            if isinstance(rule, dict) and rule.get("id"):
                by_id.setdefault(str(rule["id"]), rule)
    return by_id, driver_rules


def _resolve_rule(result: dict, by_id: dict, driver_rules: list) -> tuple[str, dict]:
    """(rule_id, rule_dict) for a result, via ruleId then ruleIndex."""
    rid = result.get("ruleId")
    if rid is None:
        rule_ref = result.get("rule")
        if isinstance(rule_ref, dict):
            rid = rule_ref.get("id")
    if rid is not None and str(rid) in by_id:
        return str(rid), by_id[str(rid)]
    idx = result.get("ruleIndex")
    if isinstance(idx, int) and 0 <= idx < len(driver_rules):
        rule = driver_rules[idx]
        return str(rule.get("id") or rid or f"rule-{idx}"), rule
    return (str(rid) if rid is not None else "unknown-rule"), {}


def _primary_location(result: dict) -> tuple[str, str]:
    """(locus, snippet) for the first physical location, else a logical name."""
    for loc in result.get("locations", []) or []:
        if not isinstance(loc, dict):
            continue
        phys = loc.get("physicalLocation") or {}
        art = phys.get("artifactLocation") or {}
        uri = str(art.get("uri") or "").strip()
        if uri:
            region = phys.get("region") or {}
            line = region.get("startLine")
            locus = f"{uri}:{int(line)}" if isinstance(line, int) else uri
            snippet = _text((region.get("snippet") or {})) if isinstance(region, dict) else ""
            return locus, snippet
        logical = loc.get("logicalLocations") or []
        if logical and isinstance(logical[0], dict):
            name = logical[0].get("fullyQualifiedName") or logical[0].get("name")
            if name:
                return str(name), ""
    return "(no location)", ""


# ── Rule help / remediation ───────────────────────────────────────────────────
def _remediation(rule: dict) -> str:
    for key in ("help",):
        node = rule.get(key)
        txt = _text(node)
        if txt:
            return txt
    props = rule.get("properties")
    if isinstance(props, dict):
        for key in ("remediation", "fix", "recommendation"):
            if props.get(key):
                return str(props[key])[:_MAX_MSG]
    return "Review the flagged code and remediate per secure-coding guidance."


def _rule_title(rule: dict, rule_id: str) -> str:
    return (_text(rule.get("shortDescription"))
            or str(rule.get("name") or "")
            or rule_id)


# ── Category assembly ─────────────────────────────────────────────────────────
def _category(rule_id: str, rule: dict, hits: list[dict]) -> dict:
    severity = _worst(h["severity"] for h in hits)
    cwes = hits[0]["cwes"]
    owasp = hits[0]["owasp"]
    title = _rule_title(rule, rule_id)
    remediation = _remediation(rule)
    locations = [h["locus"] for h in hits]
    threats = [{
        "name": h["locus"],
        "description": h["snippet"] or h["message"] or "(no snippet captured)",
        "attack_vector": title,
        "control_objective": " | ".join(
            b for b in (owasp, ", ".join(cwes)) if b),
        "false_positive_guidance":
            "Imported from an external scanner; confirm the flagged line is "
            "reachable with attacker-controlled input before remediating.",
    } for h in hits[:_MAX_THREATS_PER_RULE]]

    return {
        "id": rule_id,
        "category": "SAST",
        "name": title,
        "title": title,
        "risk": severity,
        "risk_score": _RISK_SCORE.get(severity, 1),
        "_source": "SAST",
        "ruleset": "imported-sarif",
        "cwe": ", ".join(cwes),
        "owasp": owasp,
        "description": (
            f"{len(hits)} occurrence(s) of {title} imported from SARIF "
            f"(rule {rule_id})."),
        "affected_components": locations[:_MAX_COMPONENTS],
        "mitigation": remediation,
        "remediation": remediation,
        "mitigations": [{"action": remediation, "priority": "Immediate"}],
        "threats": threats,
        "notes": (
            f"OWASP: {owasp or 'n/a'}  ·  CWE: {', '.join(cwes) or 'n/a'}  ·  "
            f"source: SARIF import"),
    }


def _file_line_snippet(result: dict) -> tuple[str, int | None, str]:
    """(file, line, snippet) from the first physical location, else ('', None, '').

    Unlike :func:`_primary_location` (which renders a display locus string),
    this keeps file and line separate so callers can feed the broker's finding
    pipeline — code-context attachment, delta fingerprints, and GitHub
    annotations all need the raw path and line number.
    """
    for loc in result.get("locations", []) or []:
        if not isinstance(loc, dict):
            continue
        phys = loc.get("physicalLocation") or {}
        art = phys.get("artifactLocation") or {}
        uri = str(art.get("uri") or "").strip()
        if not uri:
            continue
        region = phys.get("region") or {}
        line = region.get("startLine")
        snippet = _text(region.get("snippet") or {}) if isinstance(region, dict) else ""
        return uri, (int(line) if isinstance(line, int) else None), snippet
    return "", None, ""


_MAX_SNIPPET = 300


def to_findings(doc: dict, engine: str = "") -> list[dict]:
    """Convert a SARIF 2.1.0 document into broker-shaped finding dicts.

    Each finding carries the keys the broker's scan pipeline already understands
    (``id``/``title``/``severity``/``file``/``line``/``snippet``/``cwe``/
    ``owasp``/``remediation``) plus ``engine``/``domain`` provenance, so results
    from an external scanner merge into the same report, delta baseline, and
    GitHub annotation flow as the built-in engine. Raises :class:`SarifError`
    on a document with no usable SARIF structure.
    """
    if not isinstance(doc, dict):
        raise SarifError("SARIF document must be a JSON object")
    runs = doc.get("runs")
    if not isinstance(runs, list):
        raise SarifError("SARIF document has no 'runs' array")
    version = str(doc.get("version", ""))
    if version and not version.startswith("2."):
        raise SarifError(f"unsupported SARIF version {version!r} (need 2.x)")

    tool = engine.strip() or _tool_name(runs)
    findings: list[dict] = []
    for run in runs:
        if not isinstance(run, dict):
            continue
        by_id, driver_rules = _build_rule_index(run)
        for result in run.get("results") or []:
            if not isinstance(result, dict):
                continue
            if len(findings) >= _MAX_RESULTS:
                return findings
            rule_id, rule = _resolve_rule(result, by_id, driver_rules)
            file, line, snippet = _file_line_snippet(result)
            snippet = (snippet or _text(result.get("message")))[:_MAX_SNIPPET]
            cwes = _cwes(rule, result)
            findings.append({
                "id": rule_id,
                "title": _rule_title(rule, rule_id),
                "severity": _severity_for(result, rule),
                "file": file,
                "line": line,
                "snippet": snippet,
                "cwe": ", ".join(cwes),
                "owasp": _owasp(rule, result),
                "remediation": _remediation(rule),
                "engine": tool,
                "domain": tool,
            })
    return findings


def _tool_name(runs: list[dict]) -> str:
    for run in runs:
        driver = (run.get("tool") or {}).get("driver") or {}
        name = str(driver.get("name") or "").strip()
        if name:
            return name
    return "external scanner"


def from_sarif(doc: dict, source_name: str = "") -> dict:
    """Convert a parsed SARIF 2.1.0 document into a TM report dict.

    ``source_name`` overrides the tool name shown in the title. Raises
    :class:`SarifError` if the document has no recognizable SARIF structure.
    """
    if not isinstance(doc, dict):
        raise SarifError("SARIF document must be a JSON object")
    runs = doc.get("runs")
    version = str(doc.get("version", ""))
    if not isinstance(runs, list):
        raise SarifError("SARIF document has no 'runs' array")
    if version and not version.startswith("2."):
        raise SarifError(f"unsupported SARIF version {version!r} (need 2.x)")

    # ruleId -> {rule, hits[]}, first-seen order preserved for stable output.
    groups: dict[str, dict] = {}
    total = 0
    for run in runs:
        if not isinstance(run, dict):
            continue
        by_id, driver_rules = _build_rule_index(run)
        for result in run.get("results") or []:
            if not isinstance(result, dict):
                continue
            total += 1
            if total > _MAX_RESULTS:
                break
            rule_id, rule = _resolve_rule(result, by_id, driver_rules)
            locus, snippet = _primary_location(result)
            hit = {
                "severity": _severity_for(result, rule),
                "locus": locus,
                "snippet": snippet,
                "message": _text(result.get("message")),
                "cwes": _cwes(rule, result),
                "owasp": _owasp(rule, result),
            }
            g = groups.setdefault(rule_id, {"rule": rule, "hits": []})
            if not g["rule"] and rule:
                g["rule"] = rule
            g["hits"].append(hit)

    categories = [_category(rid, g["rule"], g["hits"]) for rid, g in groups.items()]
    categories.sort(key=lambda c: (_SEVERITY_ORDER.get(c["risk"], 99),
                                   -len(c["threats"])))

    all_sevs = [h_sev for g in groups.values() for h_sev in
                (hit["severity"] for hit in g["hits"])]
    overall = _worst(all_sevs) if all_sevs else "Info"
    counts = {s: 0 for s in SEVERITIES}
    for s in all_sevs:
        counts[s] += 1

    tool = source_name.strip() or _tool_name(runs)
    recommendations = list(dict.fromkeys(
        c["mitigation"] for c in categories if c.get("mitigation")))

    return {
        "title": f"SARIF · {tool}",
        "methodology": "sast",
        "methodology_label": f"Imported SARIF ({tool})",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "summary": (
            f"Imported {total} finding(s) from {tool} SARIF across "
            f"{len(groups)} rule(s): "
            + ", ".join(f"{counts[s]} {s}" for s in SEVERITIES if counts[s])
            + ("." if total else "no findings.")),
        "categories": categories,
        "recommendations": recommendations,
        "scan_metadata": {
            "source": "sarif-import",
            "tool": tool,
            "findings_total": total,
            "rules_triggered": len(groups),
            "severity_counts": counts,
        },
    }
