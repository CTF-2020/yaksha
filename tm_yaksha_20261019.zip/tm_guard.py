#!/usr/bin/env python3
"""tm_guard.py — pre-merge / coding-agent guardrail: block new insecure code.

Exits 0 (pass) or 1 (fail) based on whether the *diff* introduces a finding at
or above --fail-on. Where tm_gate.py gates a design document, this gates code
a change is about to introduce: the piece neither codemodel's on-demand
reachability report nor the SAST broker's scheduled repo scans cover — a
dangerous sink an AI coding agent (or anyone) just added, caught before it's
committed or merged. Only the diff's own added lines are considered, so
touching an old file never resurrects that file's pre-existing debt as a
blocker.

Usage:
    python tm_guard.py --staged                       # gate what's about to be committed
    python tm_guard.py --against origin/main           # gate a branch vs. its merge base
    python tm_guard.py --staged --fail-on Critical
    python tm_guard.py --against origin/main --format github
    python tm_guard.py --staged --format json --out guard-report.json

Git pre-commit hook (.git/hooks/pre-commit):
    #!/bin/sh
    python tm_guard.py --staged --fail-on High || exit 1

Claude Code hook (project .claude/settings.json) — run the gate before a `git
commit` the agent issues actually executes, and block it on a High+ finding:
    {
      "hooks": {
        "PreToolUse": [{
          "matcher": "Bash",
          "hooks": [{
            "type": "command",
            "command": "case \"$CLAUDE_TOOL_INPUT_COMMAND\" in *'git commit'*) python tm_guard.py --staged --fail-on High ;; esac"
          }]
        }]
      }
    }

GitHub Actions PR gate:
    - name: TM Guard (new insecure code)
      run: |
        git fetch origin ${{ github.base_ref }} --depth=1
        python tm_guard.py --against origin/${{ github.base_ref }} --format github --fail-on High
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from guard import diff as guard_diff
from guard import scan as guard_scan

_SEV_RANK = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}


class GitError(RuntimeError):
    pass


def _git(args: list[str], cwd: str) -> str:
    # Explicit UTF-8 decoding: text=True alone decodes with the platform locale
    # codepage (cp1252 on Windows by default), which raises on any diff
    # containing non-cp1252 bytes — real source trees routinely do (emoji,
    # non-ASCII identifiers/comments, UTF-8 fixtures).
    try:
        proc = subprocess.run(["git", *args], cwd=cwd, capture_output=True,
                              encoding="utf-8", errors="replace", timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise GitError(f"git {' '.join(args)} failed to run: {exc}") from None
    if proc.returncode not in (0, 1):
        raise GitError(f"git {' '.join(args)} failed: {(proc.stderr or '').strip()[:300]}")
    return proc.stdout or ""


def _repo_root(start: str) -> str:
    return _git(["rev-parse", "--show-toplevel"], start).strip()


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="TM Guard — pre-merge / coding-agent code security gate",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--staged", action="store_true",
                     help="Gate what's currently staged for commit (git diff --cached)")
    src.add_argument("--against", metavar="REF",
                     help="Gate this branch's changes since REF (git diff REF...HEAD)")
    p.add_argument("--repo", default=".", help="Path inside the git repo (default: cwd)")
    p.add_argument("--fail-on", default="High",
                   choices=["Critical", "High", "Medium", "Low"],
                   help="Severity that causes a non-zero exit (default: High)")
    p.add_argument("--format", default="text", choices=["text", "json", "github"])
    p.add_argument("--out", metavar="FILE", help="Write report to file instead of stdout")
    return p.parse_args()


def _diff_text(args: argparse.Namespace) -> tuple[str, str]:
    root = _repo_root(args.repo)
    if args.staged:
        text = _git(["diff", "--cached"], root)
    else:
        text = _git(["diff", f"{args.against}...HEAD"], root)
    return root, text


def _report(findings: list, args: argparse.Namespace, root: str, note: str = "") -> dict:
    threshold = _SEV_RANK.get(args.fail_on, 1)
    counts: dict[str, int] = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1
    blocking = sum(1 for f in findings if _SEV_RANK.get(f.severity, 9) <= threshold)
    return {
        "gate_result": "FAIL" if blocking else "PASS",
        "fail_on": args.fail_on,
        "repo": root,
        "new_findings": len(findings),
        "blocking_findings": blocking,
        "severity_counts": counts,
        "note": note,
        "findings": [
            {"severity": f.severity, "family": f.family, "title": f.title,
             "file": f.file, "line": f.line, "description": f.description,
             "cwe": f.cwe, "remediation": f.remediation,
             "blocking": _SEV_RANK.get(f.severity, 9) <= threshold}
            for f in findings
        ],
    }


def _run(args: argparse.Namespace) -> tuple[dict, int]:
    try:
        root, diff_text = _diff_text(args)
    except GitError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        sys.exit(2)

    added = guard_diff.parse_added_lines(diff_text)
    findings: list = []
    note = ""
    if not added:
        note = "No added lines to scan (empty diff)."
    else:
        try:
            findings = guard_scan.scan_diff(root, added)
        except Exception as exc:  # a scan failure must not silently pass the gate
            print(f"[ERROR] scan failed: {exc}", file=sys.stderr)
            sys.exit(2)

    report = _report(findings, args, root, note)
    exit_code = 1 if report["gate_result"] == "FAIL" else 0
    return report, exit_code


def _format_text(r: dict) -> str:
    lines = [
        f"\n{'='*60}",
        "  TM GUARD - new code in this change",
        f"{'='*60}",
        f"  Result   : {r['gate_result']}",
        f"  Fail-on  : {r['fail_on']}+",
        f"  Repo     : {r['repo']}",
        f"  Findings : {r['new_findings']} new"
        f" ({r['blocking_findings']} at/above threshold)",
    ]
    if r["note"]:
        lines.append(f"  Note     : {r['note']}")
    if r["findings"]:
        lines.append("")
        lines.append("  NEW FINDINGS:")
        for f in r["findings"]:
            mark = "[BLOCK]" if f["blocking"] else "[info] "
            lines.append(f"  {mark} [{f['severity']:8s}] {f['file']}:{f['line']}  {f['title']}")
            if f["remediation"]:
                lines.append(f"           Fix: {f['remediation']}")
    lines.append(f"\n{'='*60}\n")
    return "\n".join(lines)


def _format_github(r: dict) -> str:
    lines = []
    for f in r["findings"]:
        level = "error" if f["blocking"] else "warning"
        title = f"TM-Guard-{f['severity']}"
        msg = f"{f['title']} - {f['remediation']}".replace("\n", " ")
        lines.append(f"::{level} file={f['file']},line={f['line']},title={title}::{msg}")
    if r["gate_result"] == "PASS":
        lines.append("::notice title=TM Guard::No new blocking findings.")
    return "\n".join(lines)


def main():
    args = _parse_args()
    report, exit_code = _run(args)

    if args.format == "json":
        output = json.dumps(report, indent=2)
    elif args.format == "github":
        output = _format_github(report)
    else:
        output = _format_text(report)

    if args.out:
        Path(args.out).write_text(output, encoding="utf-8")
        print(f"Report written to {args.out}")
        icon = "PASS" if report["gate_result"] == "PASS" else "FAIL"
        print(f"{icon}: {report['blocking_findings']} blocking / "
              f"{report['new_findings']} new finding(s)")
    else:
        print(output)

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
