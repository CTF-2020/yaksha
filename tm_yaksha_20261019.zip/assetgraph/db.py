"""SQLite store for the asset graph — nodes + edges, persisted independent of
any single report's lifetime.

Stdlib ``sqlite3`` only, mirroring :mod:`lineage.db` / :mod:`suppressions.db`:
connection-per-call with WAL + a busy timeout, and an idempotent :func:`init`
so ``DB_PATH`` can be repointed by tests without any "already initialized"
staleness.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import closing
from pathlib import Path

from .model import Asset, AssetEdge

DB_PATH = Path.home() / ".tm_assetgraph.db"

_init_lock = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS assets (
    id                 TEXT PRIMARY KEY,
    kind               TEXT NOT NULL,
    name               TEXT NOT NULL DEFAULT '',
    attributes         TEXT NOT NULL DEFAULT '{}',
    first_seen_at      TEXT NOT NULL DEFAULT '',
    last_seen_at       TEXT NOT NULL DEFAULT '',
    observation_count  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_assets_kind ON assets(kind);

CREATE TABLE IF NOT EXISTS asset_edges (
    id                      TEXT PRIMARY KEY,
    from_id                 TEXT NOT NULL,
    to_id                   TEXT NOT NULL,
    relation                TEXT NOT NULL,
    status                  TEXT NOT NULL DEFAULT 'active',
    first_seen_at           TEXT NOT NULL DEFAULT '',
    last_seen_at            TEXT NOT NULL DEFAULT '',
    first_seen_report_id    TEXT NOT NULL DEFAULT '',
    last_seen_report_id     TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_edges_from ON asset_edges(from_id);
CREATE INDEX IF NOT EXISTS ix_edges_to   ON asset_edges(to_id);
CREATE INDEX IF NOT EXISTS ix_edges_status ON asset_edges(status);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    """Ensure the schema exists for the CURRENT DB_PATH. Cheap and idempotent."""
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)


def _row_to_asset(row: sqlite3.Row) -> Asset:
    return Asset(id=row["id"], kind=row["kind"], name=row["name"],
                attributes=json.loads(row["attributes"]),
                first_seen_at=row["first_seen_at"], last_seen_at=row["last_seen_at"],
                observation_count=row["observation_count"])


def _row_to_edge(row: sqlite3.Row) -> AssetEdge:
    return AssetEdge(id=row["id"], from_id=row["from_id"], to_id=row["to_id"],
                     relation=row["relation"], status=row["status"],
                     first_seen_at=row["first_seen_at"], last_seen_at=row["last_seen_at"],
                     first_seen_report_id=row["first_seen_report_id"],
                     last_seen_report_id=row["last_seen_report_id"])


def get_asset(asset_id: str) -> Asset | None:
    init()
    with closing(_connect()) as conn:
        row = conn.execute("SELECT * FROM assets WHERE id = ?", (asset_id,)).fetchone()
    return _row_to_asset(row) if row else None


def upsert_asset(a: Asset) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT INTO assets(id,kind,name,attributes,first_seen_at,last_seen_at,observation_count)"
            " VALUES (?,?,?,?,?,?,?)"
            " ON CONFLICT(id) DO UPDATE SET"
            "   name=excluded.name, attributes=excluded.attributes,"
            "   last_seen_at=excluded.last_seen_at, observation_count=excluded.observation_count",
            (a.id, a.kind, a.name, json.dumps(a.attributes), a.first_seen_at,
             a.last_seen_at, a.observation_count))


def all_assets(kind: str | None = None) -> list[Asset]:
    init()
    q = "SELECT * FROM assets"
    params = []
    if kind:
        q += " WHERE kind = ?"
        params.append(kind)
    q += " ORDER BY last_seen_at DESC"
    with closing(_connect()) as conn:
        rows = conn.execute(q, params).fetchall()
    return [_row_to_asset(r) for r in rows]


def upsert_edge(e: AssetEdge) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT INTO asset_edges"
            "(id,from_id,to_id,relation,status,first_seen_at,last_seen_at,"
            " first_seen_report_id,last_seen_report_id)"
            " VALUES (?,?,?,?,?,?,?,?,?)"
            " ON CONFLICT(id) DO UPDATE SET"
            "   status=excluded.status, last_seen_at=excluded.last_seen_at,"
            "   last_seen_report_id=excluded.last_seen_report_id",
            (e.id, e.from_id, e.to_id, e.relation, e.status, e.first_seen_at,
             e.last_seen_at, e.first_seen_report_id, e.last_seen_report_id))


def set_edge_status(edge_id: str, status: str, at: str) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute("UPDATE asset_edges SET status = ?, last_seen_at = ? WHERE id = ?",
                     (status, at, edge_id))


def edges_from(asset_id: str, status: str | None = None) -> list[AssetEdge]:
    init()
    q = "SELECT * FROM asset_edges WHERE from_id = ?"
    params = [asset_id]
    if status:
        q += " AND status = ?"
        params.append(status)
    with closing(_connect()) as conn:
        rows = conn.execute(q, params).fetchall()
    return [_row_to_edge(r) for r in rows]


def edges_to(asset_id: str, status: str | None = None) -> list[AssetEdge]:
    init()
    q = "SELECT * FROM asset_edges WHERE to_id = ?"
    params = [asset_id]
    if status:
        q += " AND status = ?"
        params.append(status)
    with closing(_connect()) as conn:
        rows = conn.execute(q, params).fetchall()
    return [_row_to_edge(r) for r in rows]


def counts() -> dict:
    init()
    with closing(_connect()) as conn:
        total_assets = conn.execute("SELECT COUNT(*) FROM assets").fetchone()[0]
        total_edges = conn.execute("SELECT COUNT(*) FROM asset_edges").fetchone()[0]
        active_edges = conn.execute(
            "SELECT COUNT(*) FROM asset_edges WHERE status = 'active'").fetchone()[0]
    return {"assets": total_assets, "edges": total_edges, "active_edges": active_edges}
