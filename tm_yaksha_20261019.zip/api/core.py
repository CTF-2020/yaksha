"""Core API discovery endpoints."""
from __future__ import annotations

from flask import Blueprint, jsonify


bp = Blueprint("core_api", __name__, url_prefix="/api/v1")


@bp.get("")
def api_manifest():
    """Describe the stable v1 API groups for clients and integrations."""
    return jsonify({
        "success": True,
        "version": "v1",
        "legacy_api_supported": True,
        "apis": {
            "analysis": {
                "create_review": "/api/v1/analysis/reviews",
                "create_stream_job": "/api/v1/analysis/jobs",
                "stream_events": "/api/v1/analysis/jobs/{job_id}/events",
            },
            "diagrams": {
                "architecture": "/api/v1/diagrams/architecture",
            },
            "reports": {
                "list": "/api/v1/reports",
                "get": "/api/v1/reports/{report_id}",
                "delete": "/api/v1/reports/{report_id}",
                "export_html": "/api/v1/reports/{report_id}/export",
                "export_sarif": "/api/v1/reports/{report_id}/export/sarif",
                "findings": "/api/v1/reports/{report_id}/findings",
                "findings_search": "/api/v1/reports/findings/search",
                "trends": "/api/v1/reports/trends",
                "families": "/api/v1/reports/families",
                "import_sarif": "/api/v1/reports/import/sarif",
            },
            "nav": {
                "get": "/api/v1/nav",
            },
            "dashboard": {
                "overview": "/api/v1/dashboard",
            },
            "sast": {
                "status": "/api/v1/sast",
                "repos": "/api/v1/sast/repos",
                "scan": "/api/v1/sast/repos/{repo_id}/scan",
                "pipeline": "/api/v1/sast/repos/{repo_id}/pipeline",
                "jobs": "/api/v1/sast/jobs",
                "metrics": "/api/v1/sast/metrics",
                "reports": "/api/v1/sast/reports",
                "remediation_propose": "/api/v1/sast/repos/{repo_id}/remediation/propose",
                "remediation_open_pr": "/api/v1/sast/repos/{repo_id}/remediation/open-pr",
                "remediation_queue": "/api/v1/sast/remediation/queue",
            },
            "correlation": {
                "status": "/api/v1/correlate",
                "sources": "/api/v1/correlate/sources",
                "run": "/api/v1/correlate/run",
                "attack_paths": "/api/v1/correlate/attack-paths",
                "chain_reasoning": "/api/v1/correlate/chain-reasoning",
            },
            "lineage": {
                "status": "/api/v1/lineage",
                "threats": "/api/v1/lineage/threats",
                "threat": "/api/v1/lineage/threats/{threat_id}",
                "sync": "/api/v1/lineage/sync",
            },
            "assetgraph": {
                "status": "/api/v1/assetgraph",
                "assets": "/api/v1/assetgraph/assets",
                "asset": "/api/v1/assetgraph/assets/{asset_id}",
                "asset_repos": "/api/v1/assetgraph/assets/{asset_id}/repos",
                "sync": "/api/v1/assetgraph/sync",
            },
            # DAST is soft-disabled (blueprint not registered, see api/__init__.py)
            # -- no "dast" section here since the manifest should only advertise
            # routes that actually answer.
            "design_review": {
                "webhook": "/api/v1/design-review/webhook",
            },
            "code_model": {
                "status": "/api/v1/code-model",
                "repos": "/api/v1/code-model/repos",
                "analyze": "/api/v1/code-model/analyze",
                "drift": "/api/v1/code-model/drift",
            },
            "rules": {
                "list": "/api/v1/rules",
                "facets": "/api/v1/rules/facets",
                "stats": "/api/v1/rules/stats",
                "get": "/api/v1/rules/{key}",
            },
            "aibom": {
                "status": "/api/v1/aibom",
                "repos": "/api/v1/aibom/repos",
                "scan": "/api/v1/aibom/repos/{repo_id}/scan",
                "jobs": "/api/v1/aibom/jobs",
                "inventory": "/api/v1/aibom/inventory",
            },
            "suppressions": {
                "list": "/api/v1/suppressions",
                "create": "/api/v1/suppressions",
                "delete": "/api/v1/suppressions/{suppression_id}",
                "report_suppressed": "/api/v1/reports/{report_id}/suppressed",
                "suppress_finding": "/api/v1/reports/{report_id}/suppress",
            },
            "controls": {
                "get": "/api/v1/reports/{report_id}/controls",
                "export": "/api/v1/reports/{report_id}/controls/export",
            },
            "sbom": {
                "analyze": "/api/v1/sbom/analyze",
            },
            "pqc": {
                "assess_text": "/api/v1/pqc/assess",
                "assess_report": "/api/v1/reports/{report_id}/pqc",
            },
            "patterns": {
                "list": "/api/v1/patterns",
                "list_ruleset": "/api/v1/patterns/{ruleset}",
                "get": "/api/v1/patterns/{ruleset}/{rule_id}",
            },
            "enrichment": {
                "attack": "/api/v1/reports/{report_id}/enrich/attack",
                "compliance": "/api/v1/reports/{report_id}/enrich/compliance",
                "frameworks": "/api/v1/compliance/frameworks",
            },
            "lookups": {
                "attack": "/api/v1/lookups/attack/{category}",
                "compliance": "/api/v1/lookups/compliance/{category}",
            },
            "tickets": {
                "create": "/api/v1/reports/{report_id}/tickets",
            },
        },
    })
