"""Tests for verdict_reconciliation.py -- cross-REPORT verdict reconciliation
(same finding, different verdicts across two or more LIVE reports at once),
distinct from verdict_tracking.py's cross-SCAN sequential drift tracking.

report_db/suppressions are isolated onto temp stores, same pattern as
test_fleet.py/test_confidence_decay.py.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import report_db
import suppressions
import verdict_reconciliation as vr
from suppressions import db as supp_db
from suppressions import store as supp_store
from suppressions.engine import finding_fingerprint


def _cat(cid, verdict, family="sql-injection", loci=None):
    return {"id": cid, "name": cid, "title": cid, "risk": "High", "family": family,
            "verdict": verdict, "threats": [{"name": l} for l in (loci or [f"{cid}.py:1"])],
            "affected_components": loci or [f"{cid}.py:1"]}


def _report(rid, cats, methodology="correlation", title="R"):
    return {"id": rid, "title": title, "methodology": methodology,
            "overall_risk": cats[0]["risk"] if cats else "Info", "categories": cats}


class ReconcileTests(unittest.TestCase):
    """Pure-function tests of reconcile() itself, no store involved."""

    def test_single_instance_is_never_a_conflict(self):
        rec = vr.reconcile([{"verdict": "design_gap"}])
        self.assertFalse(rec["conflict"])
        self.assertEqual(rec["effective_verdict"], "design_gap")

    def test_agreeing_instances_are_not_a_conflict(self):
        rec = vr.reconcile([{"verdict": "corroborated"}, {"verdict": "corroborated"}])
        self.assertFalse(rec["conflict"])
        self.assertEqual(rec["distinct_verdicts"], ["corroborated"])

    def test_disagreeing_instances_are_a_conflict(self):
        rec = vr.reconcile([{"verdict": "blind_spot"}, {"verdict": "confirmed_exploitable"}])
        self.assertTrue(rec["conflict"])
        self.assertEqual(rec["distinct_verdicts"], ["confirmed_exploitable", "blind_spot"])

    def test_effective_verdict_is_most_actionable_not_first_or_last(self):
        # Order in the input list must not matter -- confirmed_exploitable
        # outranks design_gap and corroborated regardless of position.
        rec = vr.reconcile([{"verdict": "design_gap"}, {"verdict": "confirmed_exploitable"},
                           {"verdict": "corroborated"}])
        self.assertEqual(rec["effective_verdict"], "confirmed_exploitable")

    def test_actively_exploited_always_wins(self):
        rec = vr.reconcile([{"verdict": "confirmed_exploitable"}, {"verdict": "actively_exploited"}])
        self.assertEqual(rec["effective_verdict"], "actively_exploited")


class StoreBackedTests(unittest.TestCase):
    def setUp(self):
        self._orp = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        supp_db.init()

    def _restore(self):
        report_db.DB_PATH = self._orp
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp

    def test_same_finding_same_verdict_across_two_reports_is_not_a_conflict(self):
        cat = _cat("A", "corroborated")
        report_db.upsert_report(_report("r1", [cat]))
        report_db.upsert_report(_report("r2", [cat]))
        self.assertEqual(vr.conflicts(), [])
        s = vr.summary()
        self.assertEqual(s["total_findings"], 1)
        self.assertEqual(s["conflicts"], 0)

    def test_same_finding_different_verdict_across_two_live_reports_is_a_conflict(self):
        cat_a = _cat("A", "blind_spot")
        cat_b = _cat("A", "confirmed_exploitable")   # same fingerprint (same id/family/loci)
        self.assertEqual(finding_fingerprint(cat_a), finding_fingerprint(cat_b))
        report_db.upsert_report(_report("r1", [cat_a]))
        report_db.upsert_report(_report("r2", [cat_b]))

        items = vr.conflicts()
        self.assertEqual(len(items), 1)
        self.assertTrue(items[0]["conflict"])
        self.assertEqual(items[0]["effective_verdict"], "confirmed_exploitable")
        self.assertEqual(len(items[0]["instances"]), 2)
        report_ids = {i["report_id"] for i in items[0]["instances"]}
        self.assertEqual(report_ids, {"r1", "r2"})

    def test_effective_verdict_lookup_by_fingerprint(self):
        cat_a = _cat("A", "design_gap")
        cat_b = _cat("A", "actively_exploited")
        report_db.upsert_report(_report("r1", [cat_a]))
        report_db.upsert_report(_report("r2", [cat_b]))
        fp = finding_fingerprint(cat_a)
        self.assertEqual(vr.effective_verdict(fp), "actively_exploited")

    def test_effective_verdict_unknown_fingerprint_returns_none(self):
        self.assertIsNone(vr.effective_verdict("nope-not-tracked"))

    def test_suppressed_instance_excluded_from_reconciliation(self):
        cat_a = _cat("A", "blind_spot")
        cat_b = _cat("A", "confirmed_exploitable")
        report_db.upsert_report(_report("r1", [cat_a]))
        report_db.upsert_report(_report("r2", [cat_b]))
        suppressions.add_suppression({
            "scope": "rule", "match": "A", "reason": "accepted", "author": "carol"})
        # Both instances share rule id "A", so both get suppressed -> no
        # live verdict-carrying instance left at all for this fingerprint.
        self.assertEqual(vr.conflicts(), [])
        self.assertIsNone(vr.effective_verdict(finding_fingerprint(cat_a)))

    def test_sast_dast_methodologies_excluded(self):
        cat_a = _cat("A", "blind_spot")
        cat_b = _cat("A", "confirmed_exploitable")
        report_db.upsert_report(_report("r1", [cat_a], methodology="sast"))
        report_db.upsert_report(_report("r2", [cat_b], methodology="dast"))
        self.assertEqual(vr.conflicts(), [])

    def test_different_fingerprints_never_conflict_with_each_other(self):
        report_db.upsert_report(_report("r1", [_cat("A", "blind_spot")]))
        report_db.upsert_report(_report("r2", [_cat("B", "confirmed_exploitable")]))
        self.assertEqual(vr.conflicts(), [])

    def test_three_way_conflict_worst_wins_and_all_instances_present(self):
        cat_a = _cat("A", "design_gap")
        cat_b = _cat("A", "corroborated")
        cat_c = _cat("A", "actively_exploited")
        report_db.upsert_report(_report("r1", [cat_a]))
        report_db.upsert_report(_report("r2", [cat_b]))
        report_db.upsert_report(_report("r3", [cat_c]))
        items = vr.conflicts()
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["effective_verdict"], "actively_exploited")
        self.assertEqual(len(items[0]["instances"]), 3)
        self.assertEqual(set(items[0]["distinct_verdicts"]),
                         {"design_gap", "corroborated", "actively_exploited"})

    def test_conflicts_worst_first_across_multiple_findings(self):
        report_db.upsert_report(_report("r1", [
            _cat("QUIET", "design_gap", family="misc-a"),
        ]))
        report_db.upsert_report(_report("r2", [
            _cat("QUIET", "corroborated", family="misc-a"),
        ]))
        report_db.upsert_report(_report("r3", [
            _cat("LOUD", "blind_spot", family="misc-b"),
        ]))
        report_db.upsert_report(_report("r4", [
            _cat("LOUD", "actively_exploited", family="misc-b"),
        ]))
        items = vr.conflicts()
        self.assertEqual(len(items), 2)
        self.assertEqual(items[0]["title"], "LOUD")   # actively_exploited ranks worse

    def test_summary_conflict_pct(self):
        report_db.upsert_report(_report("r1", [_cat("A", "blind_spot")]))
        report_db.upsert_report(_report("r2", [_cat("A", "confirmed_exploitable")]))
        report_db.upsert_report(_report("r3", [_cat("B", "design_gap")]))
        s = vr.summary()
        self.assertEqual(s["total_findings"], 2)
        self.assertEqual(s["conflicts"], 1)
        self.assertEqual(s["conflict_pct"], 50.0)

    def test_summary_with_no_reports_at_all(self):
        s = vr.summary()
        self.assertEqual(s["total_findings"], 0)
        self.assertEqual(s["conflict_pct"], 0.0)
        self.assertEqual(s["worst_conflicts"], [])


class ReconciliationApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._op = report_db.DB_PATH
        self.addCleanup(lambda: setattr(report_db, "DB_PATH", self._op))
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()

    def test_summary_endpoint(self):
        resp = self.client.get("/api/v1/reconciliation/summary")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["total_findings"], 0)

    def test_conflicts_endpoint(self):
        report_db.upsert_report(_report("r1", [_cat("A", "blind_spot")]))
        report_db.upsert_report(_report("r2", [_cat("A", "confirmed_exploitable")]))
        resp = self.client.get("/api/v1/reconciliation/conflicts")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["count"], 1)
        self.assertEqual(d["conflicts"][0]["effective_verdict"], "confirmed_exploitable")

    def test_conflicts_endpoint_rejects_bad_limit(self):
        resp = self.client.get("/api/v1/reconciliation/conflicts?limit=notanumber")
        self.assertEqual(resp.status_code, 400)


if __name__ == "__main__":
    unittest.main(verbosity=2)
