"""Regression floors for the offline analysis engine's measured accuracy.

The benchmark harness (benchmark/harness.py) scores the deterministic reviewer
against the labelled corpus. This test turns that measurement into a CI gate: a
rule or phrasing change that drops recall, specificity or precision below the
floors fails here. Floors sit deliberately BELOW the current numbers so the
corpus can grow harder without a brittle exact-match assertion.

Current measured (2026-07-30, 53 cases spanning all 7 rulesets incl. all 10 OWASP
LLM categories): recall 100%, specificity 100%, precision 100%, F1 100%, severity
accuracy 100%, clean-design over-warn 0%. The prior severity-accuracy gap (88%,
two negation-phrased designs under-rated to WARN) was root-caused and fixed: a
clause-boundary bug in the negation scanner let a negation cue from an unrelated
earlier clause bleed into a later control-phrase check, and the RISK_SIGNALS list
was missing common phrasings (no MFA, no rate limiting). Floors stay below the
measured numbers so the corpus can grow harder without a brittle exact-match
assertion.
"""
from __future__ import annotations

import unittest

from benchmark import harness


class TestAccuracyFloors(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = harness.evaluate()

    def test_recall_floor(self):
        self.assertGreaterEqual(self.m["recall"], 0.90, self.m["confusion"])

    def test_specificity_floor(self):
        # The engine must stay quiet on securely-described designs.
        self.assertGreaterEqual(self.m["specificity"], 0.95, self.m["confusion"])

    def test_precision_floor(self):
        self.assertGreaterEqual(self.m["precision"], 0.95, self.m["confusion"])

    def test_f1_floor(self):
        self.assertGreaterEqual(self.m["f1"], 0.92)

    def test_severity_accuracy_floor(self):
        self.assertGreaterEqual(self.m["severity_recall"], 0.90)

    def test_clean_design_does_not_overwarn(self):
        self.assertLessEqual(self.m["clean_design"]["overwarn_rate"], 0.10,
                             "the engine is over-warning on a fully-secure design")
        self.assertEqual(self.m["clean_design"]["overall_risk"], "Low")


class TestNegationRobustness(unittest.TestCase):
    """Directly guards the negation-aware control suppression: a design that
    describes its weaknesses by NEGATING controls ("no MFA", "not encrypted")
    must still be caught, and the securely-phrased twin must stay quiet."""

    @classmethod
    def setUpClass(cls):
        cls.detail = harness.evaluate()["cases_detail"]

    def test_every_vuln_case_is_raised(self):
        missed = [c["rule_id"] for c in self.detail if not c["recall_hit"]]
        self.assertEqual(missed, [], f"vuln designs not raised: {missed}")

    def test_every_safe_case_stays_quiet(self):
        fired = [c["rule_id"] for c in self.detail if not c["specificity_hit"]]
        self.assertEqual(fired, [], f"safe designs falsely flagged: {fired}")


class TestHarnessReport(unittest.TestCase):
    def test_format_report_renders(self):
        text = harness.format_report(harness.evaluate())
        self.assertIn("measured accuracy", text)
        self.assertIn("recall", text)


if __name__ == "__main__":
    unittest.main()
