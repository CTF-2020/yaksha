"""Tests for fleet.py -- fleet-wide correlation posture across registered
SAST repos / DAST targets.

report_db is isolated onto a temp DB (same pattern as test_dashboard.py);
the registered-repo list itself is mocked directly (fleet._registered_repos)
rather than touching the real broker/dast stores, since attribution logic --
not the repo registry itself -- is what this module owns.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

import fleet
import report_db
import suppressions
from suppressions import db as supp_db
from suppressions import store as supp_store


def _sast_report(rid, repo_id, title="SAST scan"):
    return {"id": rid, "title": title, "methodology": "sast",
            "overall_risk": "High", "analyzed_at": "2026-08-01T00:00:00Z",
            "scan_metadata": {"repo_id": repo_id, "repo_name": f"repo-{repo_id}"},
            "categories": []}


def _dast_report(rid, target_id, title="DAST scan"):
    return {"id": rid, "title": title, "methodology": "dast",
            "overall_risk": "Medium", "analyzed_at": "2026-08-01T00:00:00Z",
            "scan_metadata": {"target_id": target_id, "target_name": f"target-{target_id}"},
            "categories": []}


def _cat(cid, verdict, family="sql-injection", loci=None):
    return {"id": cid, "name": cid, "title": cid, "risk": "High", "family": family,
            "verdict": verdict, "threats": [{"name": l} for l in (loci or [f"{cid}.py:1"])],
            "affected_components": loci or [f"{cid}.py:1"]}


def _correlation_report(rid, source_ids, cats, title="Correlation", analyzed_at="2026-08-01T00:00:00Z"):
    return {"id": rid, "title": title, "methodology": "correlation",
            "overall_risk": cats[0]["risk"] if cats else "Info", "analyzed_at": analyzed_at,
            "scan_metadata": {"source_reports": [{"id": sid} for sid in source_ids]},
            "categories": cats}


class FleetTests(unittest.TestCase):
    def setUp(self):
        self._op = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        supp_db.init()

    def _restore(self):
        report_db.DB_PATH = self._op
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp

    def _mock_repos(self, repos):
        return mock.patch.object(fleet, "_registered_repos", return_value=repos)

    def test_uncorrelated_repo_reports_zero_and_not_correlated(self):
        with self._mock_repos([{"kind": "sast", "key": "r1", "name": "svc-a", "url": ""}]):
            rows = fleet.repo_posture()
        self.assertEqual(len(rows), 1)
        self.assertFalse(rows[0]["correlated"])
        self.assertIsNone(rows[0]["report_id"])
        self.assertEqual(rows[0]["actively_exploited"], 0)

    def test_correlation_report_attributed_via_sast_source(self):
        report_db.upsert_report(_sast_report("s1", "r1"))
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], [_cat("A", "confirmed_exploitable")]))
        with self._mock_repos([{"kind": "sast", "key": "r1", "name": "svc-a", "url": ""}]):
            rows = fleet.repo_posture()
        self.assertTrue(rows[0]["correlated"])
        self.assertEqual(rows[0]["report_id"], "c1")
        self.assertEqual(rows[0]["confirmed_exploitable"], 1)

    def test_correlation_report_attributed_via_dast_source(self):
        report_db.upsert_report(_dast_report("d1", "t1"))
        report_db.upsert_report(_correlation_report(
            "c1", ["d1"], [_cat("A", "actively_exploited")]))
        with self._mock_repos([{"kind": "dast", "key": "t1", "name": "app-x", "url": ""}]):
            rows = fleet.repo_posture()
        self.assertTrue(rows[0]["correlated"])
        self.assertEqual(rows[0]["actively_exploited"], 1)

    def test_unregistered_repo_ids_do_not_leak_into_results(self):
        # A correlation report attributed to a repo that isn't in the
        # registered-repo list must not fabricate a row for it.
        report_db.upsert_report(_sast_report("s1", "unknown-repo"))
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], [_cat("A", "confirmed_exploitable")]))
        with self._mock_repos([{"kind": "sast", "key": "r1", "name": "svc-a", "url": ""}]):
            rows = fleet.repo_posture()
        self.assertEqual(len(rows), 1)
        self.assertFalse(rows[0]["correlated"])

    def test_only_most_recent_correlation_report_counts(self):
        report_db.upsert_report(_sast_report("s1", "r1"))
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], [_cat("A", "confirmed_exploitable")], analyzed_at="2026-07-01T00:00:00Z"))
        report_db.upsert_report(_correlation_report(
            "c2", ["s1"], [_cat("B", "corroborated")], analyzed_at="2026-08-01T00:00:00Z"))
        with self._mock_repos([{"kind": "sast", "key": "r1", "name": "svc-a", "url": ""}]):
            rows = fleet.repo_posture()
        # report_db.all_reports() orders newest-first by created_at (id-derived
        # timestamp), not analyzed_at -- c2 was upserted after c1, so it wins.
        self.assertEqual(rows[0]["report_id"], "c2")
        self.assertEqual(rows[0]["confirmed_exploitable"], 0)
        self.assertEqual(rows[0]["corroborated"], 1)

    def test_suppressed_finding_excluded_from_counts(self):
        report_db.upsert_report(_sast_report("s1", "r1"))
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], [_cat("A", "confirmed_exploitable")]))
        suppressions.add_suppression({
            "scope": "rule", "match": "A", "reason": "accepted", "author": "carol"})
        with self._mock_repos([{"kind": "sast", "key": "r1", "name": "svc-a", "url": ""}]):
            rows = fleet.repo_posture()
        self.assertEqual(rows[0]["confirmed_exploitable"], 0)
        self.assertEqual(rows[0]["total_actionable"], 0)

    def test_worst_repo_sorts_first(self):
        report_db.upsert_report(_sast_report("s1", "r1"))
        report_db.upsert_report(_sast_report("s2", "r2"))
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], [_cat("A", "corroborated")]))
        report_db.upsert_report(_correlation_report(
            "c2", ["s2"], [_cat("B", "actively_exploited")]))
        with self._mock_repos([
            {"kind": "sast", "key": "r1", "name": "quiet-repo", "url": ""},
            {"kind": "sast", "key": "r2", "name": "hot-repo", "url": ""},
        ]):
            rows = fleet.repo_posture()
        self.assertEqual(rows[0]["name"], "hot-repo")

    def test_uncorrelated_repos_sink_below_correlated_ones(self):
        report_db.upsert_report(_sast_report("s1", "r1"))
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], [_cat("A", "design_gap")]))
        with self._mock_repos([
            {"kind": "sast", "key": "r1", "name": "correlated-repo", "url": ""},
            {"kind": "sast", "key": "r2", "name": "never-scanned", "url": ""},
        ]):
            rows = fleet.repo_posture()
        self.assertEqual(rows[0]["name"], "correlated-repo")
        self.assertEqual(rows[1]["name"], "never-scanned")

    def test_summary_totals_and_coverage(self):
        report_db.upsert_report(_sast_report("s1", "r1"))
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], [_cat("A", "actively_exploited"), _cat("B", "confirmed_exploitable")]))
        with self._mock_repos([
            {"kind": "sast", "key": "r1", "name": "svc-a", "url": ""},
            {"kind": "sast", "key": "r2", "name": "svc-b", "url": ""},
        ]):
            s = fleet.summary()
        self.assertEqual(s["repos"], 2)
        self.assertEqual(s["correlated"], 1)
        self.assertEqual(s["uncorrelated"], 1)
        self.assertEqual(s["coverage_pct"], 50.0)
        self.assertEqual(s["totals"]["actively_exploited"], 1)
        self.assertEqual(s["totals"]["confirmed_exploitable"], 1)
        self.assertEqual(len(s["worst_repos"]), 1)

    def test_summary_with_no_registered_repos(self):
        with self._mock_repos([]):
            s = fleet.summary()
        self.assertEqual(s["repos"], 0)
        self.assertEqual(s["coverage_pct"], 0.0)
        self.assertEqual(s["worst_repos"], [])


class FleetApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._op = report_db.DB_PATH
        self.addCleanup(lambda: setattr(report_db, "DB_PATH", self._op))
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()

    def test_summary_endpoint(self):
        with mock.patch.object(fleet, "_registered_repos", return_value=[
            {"kind": "sast", "key": "r1", "name": "svc-a", "url": ""}]):
            resp = self.client.get("/api/v1/fleet/summary")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["repos"], 1)

    def test_repos_endpoint(self):
        with mock.patch.object(fleet, "_registered_repos", return_value=[
            {"kind": "dast", "key": "t1", "name": "app-x", "url": ""}]):
            resp = self.client.get("/api/v1/fleet/repos")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["count"], 1)
        self.assertEqual(d["repos"][0]["name"], "app-x")


if __name__ == "__main__":
    unittest.main()
