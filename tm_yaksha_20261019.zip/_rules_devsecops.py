"""_rules_devsecops.py — DevSecOps and Secure SDLC offline rules.

Sources:
  - Green (2025): Ch.7 Security Testing & Verification, DevSecOps, SAST/DAST/IAST, ASVS
  - Nichols (2024): Ch.11 Best Practices, Ch.13/14 Architecture Design & Development
"""
DEVSECOPS_RULES: list[dict] = [
    # ── SAST ──────────────────────────────────────────────────────────────────
    {
        "id": "DSO-SAST-01",
        "category": "SAST",
        "question": "Is Static Application Security Testing (SAST) integrated in CI to scan code before merge?",
        "rationale": "SAST finds injection, auth, and crypto flaws at the code level before deployment. Cost to fix: 1× in dev vs. 100× in production. (Green Ch.7 p.275)",
        "severity": "High",
        "patterns_to_check": ["repository", "code", "pull request", "merge", "git", "branch", "developer", "ci"],
        "mitigations": [
            "Integrate a SAST tool (Semgrep, SonarQube, CodeQL, Checkmarx) into CI — fail builds on High/Critical findings",
            "Configure SAST rules to cover OWASP Top 10 categories for the language in use",
            "Review and triage all SAST findings within 48hrs of detection — never suppress without documented justification",
        ],
        "references": ["https://owasp.org/www-community/controls/Static_Code_Analysis"],
    },
    {
        "id": "DSO-SAST-02",
        "category": "SAST",
        "question": "Are SAST scan results reviewed by security-trained engineers, not dismissed as noise?",
        "rationale": "SAST without triage processes produces alert fatigue. The team must own the findings. (Green Ch.7; Nichols Ch.11)",
        "severity": "Medium",
        "patterns_to_check": ["code review", "security review", "static analysis", "lint", "sast", "code scan"],
        "mitigations": [
            "Assign a security champion per team responsible for SAST triage",
            "Track false positive rate over time — tune rules quarterly to reduce noise without missing real issues",
        ],
        "references": ["https://owasp.org/www-community/controls/Static_Code_Analysis"],
    },
    # ── DAST ──────────────────────────────────────────────────────────────────
    {
        "id": "DSO-DAST-01",
        "category": "DAST",
        "question": "Is Dynamic Application Security Testing (DAST) run against staging environments before production releases?",
        "rationale": "DAST finds runtime vulnerabilities (XSS, SQLi, auth bypass) that SAST misses — it tests the running application, not the code. (Green Ch.7 p.275)",
        "severity": "High",
        "patterns_to_check": ["web", "api", "application", "staging", "test environment", "qa", "release", "deploy"],
        "mitigations": [
            "Run DAST (OWASP ZAP, Burp Suite Enterprise, Nuclei) against staging on every release candidate",
            "Include authenticated scan profiles — unauthenticated DAST misses the majority of vulnerabilities",
            "Gate production deployment on DAST completing with no High/Critical findings",
        ],
        "references": ["https://owasp.org/www-project-zap/"],
    },
    # ── SCA ───────────────────────────────────────────────────────────────────
    {
        "id": "DSO-SCA-01",
        "category": "SCA",
        "question": "Is Software Composition Analysis (SCA) blocking builds with critically vulnerable dependencies?",
        "rationale": "Third-party libraries represent 70-90% of modern application code. SCA is the only systematic way to track their vulnerability status. (Green Ch.7; Nichols Ch.11)",
        "severity": "High",
        "patterns_to_check": ["npm", "pip", "maven", "gradle", "composer", "gem", "cargo", "nuget", "dependency", "library", "package"],
        "mitigations": [
            "Enable Dependabot or Renovate for automated dependency update PRs — critical fixes should auto-merge after CI passes",
            "Integrate OWASP Dependency-Check or Snyk in CI to block builds on CVSS 9+ vulnerabilities",
            "Generate and store an SBOM (CycloneDX or SPDX) for every production release",
        ],
        "references": ["https://owasp.org/www-project-dependency-check/"],
    },
    # ── Secrets Scanning ──────────────────────────────────────────────────────
    {
        "id": "DSO-SECRET-01",
        "category": "SECRETS_SCANNING",
        "question": "Is automated secret scanning (truffleHog, git-secrets, Gitleaks) preventing credentials from reaching version control?",
        "rationale": "Credentials committed to git persist in history forever. Automated scanning must prevent them before they're pushed. (Nichols Ch.11; Green Ch.5)",
        "severity": "Critical",
        "patterns_to_check": ["git", "repository", "github", "gitlab", "bitbucket", "commit", "source control", "version control"],
        "mitigations": [
            "Install pre-commit hook running Gitleaks or git-secrets on every commit locally",
            "Run secret scanning in CI as a required status check — block merges on any secret detected",
            "Rotate any credential discovered in git history immediately; assume it is already compromised",
        ],
        "references": ["https://github.com/gitleaks/gitleaks"],
    },
    # ── IaC Security ─────────────────────────────────────────────────────────
    {
        "id": "DSO-IAC-01",
        "category": "IAC_SECURITY",
        "question": "Is IaC security scanning (Checkov, tfsec, cfn-nag) integrated as a CI gate before infrastructure changes apply?",
        "rationale": "IaC misconfiguration deploys insecure infrastructure automatically and at scale. Catching it in PR is exponentially cheaper. (Green Ch.5 p.213; Nichols Ch.13)",
        "severity": "High",
        "patterns_to_check": ["terraform", "cloudformation", "bicep", "pulumi", "cdk", "ansible", "helm", "kubernetes manifest", "yaml", "deploy infrastructure"],
        "mitigations": [
            "Run Checkov and tfsec on every PR touching IaC files — fail on High/Critical policy violations",
            "Apply OPA or Sentinel policies in Terraform Cloud / Atlantis to enforce organisational security baselines",
            "Scan Helm charts and Kubernetes manifests for privileged containers, missing resource limits, and host namespace sharing",
        ],
        "references": ["https://www.checkov.io/"],
    },
    # ── Container Image Scanning ──────────────────────────────────────────────
    {
        "id": "DSO-CONTAINER-01",
        "category": "CONTAINER_SECURITY",
        "question": "Are container images scanned for CVEs and misconfigurations before deployment to production?",
        "rationale": "Base images regularly contain hundreds of vulnerabilities. An un-scanned image carries every one of them into production. (Green Ch.5 Containers; Nichols Ch.13)",
        "severity": "High",
        "patterns_to_check": ["docker", "container", "image", "kubernetes", "k8s", "dockerfile", "registry", "ecr", "gcr", "acr"],
        "mitigations": [
            "Scan images with Trivy or Grype in CI — block deployment if Critical CVEs are present",
            "Use minimal base images (distroless, Alpine) to reduce attack surface",
            "Pin image tags to digests (SHA256) not mutable tags — ensures the scanned image is what's deployed",
        ],
        "references": ["https://github.com/aquasecurity/trivy"],
    },
    # ── Penetration Testing ───────────────────────────────────────────────────
    {
        "id": "DSO-PENTEST-01",
        "category": "PENETRATION_TESTING",
        "question": "Is periodic penetration testing (at least annually) conducted against production by independent testers?",
        "rationale": "Automated scanning finds known patterns; manual penetration testing discovers logic flaws and chained vulnerabilities that tools miss. (Green Ch.7 p.276; Nichols Ch.9)",
        "severity": "High",
        "patterns_to_check": ["production", "api", "web application", "external facing", "user-facing", "public", "customer"],
        "mitigations": [
            "Conduct annual external penetration test by an accredited third party for all internet-facing systems",
            "Run quarterly internal penetration tests for critical internal systems",
            "Track all pentest findings in the risk register — verify remediation within defined SLAs",
        ],
        "references": ["https://owasp.org/www-project-web-security-testing-guide/"],
    },
    # ── ASVS ─────────────────────────────────────────────────────────────────
    {
        "id": "DSO-ASVS-01",
        "category": "ASVS",
        "question": "Is the OWASP Application Security Verification Standard (ASVS) used to define and verify security requirements?",
        "rationale": "ASVS provides a structured baseline of 286 security requirements across 14 areas — without it, coverage is ad-hoc. (Green Ch.7 ASVS p.276)",
        "severity": "Medium",
        "patterns_to_check": ["web application", "api", "application security", "security requirements", "testing", "verification"],
        "mitigations": [
            "Apply ASVS Level 1 (minimum baseline) for all applications; Level 2 for customer-facing; Level 3 for critical/regulated",
            "Map ASVS controls to your test plan — every ASVS requirement should have a corresponding automated or manual test",
            "Reference ASVS V2 (AuthN), V3 (Session), V5 (Input), V6 (Crypto) as mandatory for any web/API application",
        ],
        "references": ["https://owasp.org/www-project-application-security-verification-standard/"],
    },
    # ── Signed Artifacts ──────────────────────────────────────────────────────
    {
        "id": "DSO-SIGN-01",
        "category": "ARTIFACT_SIGNING",
        "question": "Are release artifacts, container images, and build outputs cryptographically signed and verified (SLSA Level 2+)?",
        "rationale": "Unsigned artifacts allow supply chain attackers to substitute malicious builds that pass through pipelines undetected. (Green Ch.7; Nichols Ch.8)",
        "severity": "High",
        "patterns_to_check": ["artifact", "release", "build", "package", "deploy", "binary", "container image", "helm chart"],
        "mitigations": [
            "Implement Sigstore/Cosign for container image signing — verify signatures at admission into Kubernetes",
            "Target SLSA Level 2 for all production software: hosted build platform with build attestations",
            "Sign npm/PyPI packages with package-level signing before publishing to registries",
        ],
        "references": ["https://slsa.dev/spec/v1.0/"],
    },
    # ── Security Training ─────────────────────────────────────────────────────
    {
        "id": "DSO-TRAIN-01",
        "category": "SECURITY_TRAINING",
        "question": "Do developers receive role-specific secure coding training annually, including OWASP Top 10 and language-specific secure patterns?",
        "rationale": "Developers write the code. Training directly reduces the introduction rate of vulnerabilities at source. (Nichols Ch.11 p.338; Green Ch.7)",
        "severity": "Medium",
        "patterns_to_check": ["developer", "engineer", "coding", "development team", "sprint", "feature development"],
        "mitigations": [
            "Mandate OWASP Top 10 training for all developers annually — track completion and test scores",
            "Supplement with language-specific secure coding guides (Python, Java, JavaScript) and framework-specific OWASP cheat sheets",
            "Run capture-the-flag (CTF) sessions for developers to practice attacking and defending real vulnerabilities",
        ],
        "references": ["https://owasp.org/www-project-secure-coding-practices-quick-reference-guide/"],
    },
    # ── SIEM / SOAR Integration ───────────────────────────────────────────────
    {
        "id": "DSO-SIEM-01",
        "category": "SIEM_SOAR",
        "question": "Is security logging from all application components (auth events, errors, access logs) ingested into a centralised SIEM?",
        "rationale": "Siloed logs prevent correlation. SIEM integration enables detection of multi-step attacks spanning multiple systems. (Green Ch.6 p.243; Nichols Ch.9)",
        "severity": "High",
        "patterns_to_check": ["log", "logging", "monitoring", "production", "application", "api", "authentication", "event"],
        "mitigations": [
            "Standardise log format (JSON/CEF) across all services — every log entry must include: timestamp, service, user ID, action, outcome, source IP",
            "Ship all security-relevant logs to SIEM (Splunk, Microsoft Sentinel) within 60 seconds of event occurrence",
            "Define SOAR playbooks for: brute force detection, privilege escalation, data exfiltration patterns",
        ],
        "references": ["https://www.splunk.com/en_us/blog/learn/siem-vs-soar.html"],
    },
    {
        "id": "DSO-SIEM-02",
        "category": "SIEM_SOAR",
        "question": "Are SOAR playbooks defined for the top 5 most likely incidents, with tested automated containment?",
        "rationale": "SOAR without tested playbooks provides false assurance. Mean Time to Respond (MTTR) improves only when automation is validated. (Green Ch.6 SOAR p.252)",
        "severity": "Medium",
        "patterns_to_check": ["incident response", "soc", "alert", "detection", "soar", "playbook", "automation"],
        "mitigations": [
            "Define and test SOAR playbooks for: credential compromise, ransomware detection, data exfiltration, DDoS, insider threat",
            "Measure MTTD (Mean Time to Detect) and MTTR (Mean Time to Respond) — set targets and review monthly",
            "Run quarterly tabletop exercises simulating the top 3 threat scenarios relevant to your industry",
        ],
        "references": ["https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-61r2.pdf"],
    },
    # ── Post-Quantum Cryptography ─────────────────────────────────────────────
    {
        "id": "DSO-PQC-01",
        "category": "POST_QUANTUM_CRYPTO",
        "question": "Is there a post-quantum cryptography (PQC) migration plan for RSA and ECC-based systems?",
        "rationale": "Shor's algorithm on a sufficiently powerful quantum computer breaks RSA and ECC. NIST PQC standards (ML-KEM, ML-DSA, SLH-DSA) are the migration path. (Green Ch.5 p.174)",
        "severity": "Medium",
        "patterns_to_check": ["rsa", "ecdsa", "ecc", "diffie-hellman", "public key", "certificate", "pki", "asymmetric", "tls"],
        "mitigations": [
            "Inventory all systems using RSA/ECC: TLS certificates, code signing keys, JWT signing, SSH keys, PKI hierarchy",
            "Adopt NIST PQC standards: ML-KEM (key encapsulation), ML-DSA (digital signatures), SLH-DSA (stateless hash-based signatures)",
            "Enable hybrid key exchange (classical + PQC) in TLS 1.3 as an interim measure using X25519+ML-KEM768",
        ],
        "references": ["https://www.nist.gov/pqcrypto"],
    },
    # ── AI Security Architecture ──────────────────────────────────────────────
    {
        "id": "DSO-AI-01",
        "category": "AI_SECURITY",
        "question": "Are AI model API endpoints protected with rate limiting, input validation, and RBAC — not open to unauthenticated access?",
        "rationale": "AI APIs without protection are vulnerable to abuse, adversarial queries, and model extraction (as demonstrated by the DeepSeek case study). (Green Ch.5 AI Security p.222)",
        "severity": "Critical",
        "patterns_to_check": ["ai", "llm", "model", "ml", "machine learning", "inference", "api", "endpoint", "gpt", "claude"],
        "mitigations": [
            "Enforce RBAC/ABAC on all AI model endpoints — never expose unauthenticated inference endpoints",
            "Apply input validation against adversarial query patterns and rate-limit per user/session",
            "Disable weak encryption on AI data flows (3DES, SSL) — enforce TLS 1.3 minimum on all AI API communications",
        ],
        "references": ["https://genai.owasp.org/"],
    },
    {
        "id": "DSO-AI-02",
        "category": "AI_SECURITY",
        "question": "Is training data governance in place — classified before ingestion, supply chain vetted, poisoning detection active?",
        "rationale": "Poisoned training data implants backdoors that survive deployment. DeepSeek case study illustrates supply chain risk in AI data pipelines. (Green Ch.5 p.227)",
        "severity": "High",
        "patterns_to_check": ["training data", "dataset", "fine-tuning", "model training", "rag", "embedding", "vector database", "knowledge base"],
        "mitigations": [
            "Classify all data before feeding into AI models — apply data governance controls proportional to sensitivity tier",
            "Vet training data supply chain: verify provenance, apply anomaly detection on distributions before training",
            "Implement adversarial training and red-team exercises against AI models quarterly",
        ],
        "references": ["https://genai.owasp.org/llmrisk/llm03-training-data-poisoning/"],
    },
]
