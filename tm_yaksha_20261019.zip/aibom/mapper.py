"""Map AI-BOM engine output to (a) a Yaksha Guard TM report and (b) a
CycloneDX 1.6 AI-BOM document.

The TM report reuses the existing viewer contract (categories -> threats), same
as broker.mapper: the first category is always the AI inventory itself (what was
found, per category, with evidence), followed by one category per triggered risk
rule. The CycloneDX document is the interchange artifact — libraries become
`library` components with purls, model ids become `machine-learning-model`
components, endpoints become services, and TM-specific data rides in properties.
"""
from __future__ import annotations

import uuid

from . import config, signatures as sig

_RISK_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}
_SEV_ORDER = {s: i for i, s in enumerate(sig.SEVERITIES)}
_MAX_THREATS = 50
_MAX_COMPONENTS = 25

_CATEGORY_LABELS = {
    "provider-sdk": "Provider SDKs", "framework": "Orchestration frameworks",
    "agent-framework": "Agent frameworks", "vector-db": "Vector stores",
    "local-inference": "Local inference", "ml-runtime": "ML runtimes",
    "tokenizer": "Tokenizers", "mcp": "MCP", "guardrails": "Guardrails",
    "evaluation": "Evaluation", "model": "Models referenced",
    "endpoint": "Provider endpoints", "credential": "Credential references",
    "model-artifact": "Committed model artifacts",
}


def _severity_counts(findings: list[dict]) -> dict:
    counts = {s: 0 for s in sig.SEVERITIES}
    for f in findings:
        counts[f.get("severity", "Info")] = counts.get(f.get("severity", "Info"), 0) + 1
    return counts


def _highest_severity(findings: list[dict]) -> str:
    best = "Info"
    for f in findings:
        if _SEV_ORDER.get(f.get("severity", "Info"), 99) < _SEV_ORDER.get(best, 99):
            best = f["severity"]
    return best


# ── TM report ─────────────────────────────────────────────────────────────────
def _inventory_category(components: list[dict], stats: dict) -> dict:
    """The always-present card: what AI this repo actually contains."""
    threats = []
    for comp in sorted(components, key=lambda c: (c["category"], c["name"].lower()))[:_MAX_THREATS]:
        ev = comp["evidence"][0] if comp["evidence"] else {"file": "?", "line": "?", "snippet": ""}
        version = f" @ {comp['version']}" if comp.get("version") else ""
        threats.append({
            "name": f"{comp['name']}{version}  ({_CATEGORY_LABELS.get(comp['category'], comp['category'])})",
            "description": ev.get("snippet") or "(no snippet)",
            "attack_vector": f"{comp['provider']} · via {', '.join(comp['sources'])} "
                             f"· first seen {ev['file']}:{ev['line']}",
            "control_objective": f"confidence {comp['confidence']}",
        })
    flags = stats.get("flags", {})
    flag_bits = [label for key, label in (
        ("provider_apis", "provider APIs"), ("local_models", "local models"),
        ("rag", "RAG"), ("agents", "agents"), ("mcp", "MCP")) if flags.get(key)]
    by_cat = stats.get("by_category", {})
    return {
        "id": "AIBOM-INVENTORY",
        "category": "AI-BOM", "name": "AI usage inventory",
        "title": "AI usage inventory",
        "risk": "Info", "risk_score": 1, "_source": "AI-BOM", "ruleset": "AI-BOM",
        "description": (
            f"{stats.get('components_total', 0)} AI component(s) across "
            f"{stats.get('files_with_ai', 0)} file(s): "
            + (", ".join(f"{n} {_CATEGORY_LABELS.get(cat, cat).lower()}"
                         for cat, n in sorted(by_cat.items())) or "none")
            + (f". Capabilities: {', '.join(flag_bits)}." if flag_bits else ".")
        ),
        "affected_components": [
            f"{c['name']} ({c['category']})" for c in components][:_MAX_COMPONENTS],
        "mitigation": "Keep this inventory current; every entry is attack surface "
                      "that should appear in the system's threat model.",
        "remediation": "Review each component for necessity, version pinning, and "
                       "data-flow exposure.",
        "mitigations": [{"action": "Feed this inventory into the threat model and "
                                   "AI governance register.", "priority": "Routine"}],
        "threats": threats,
        "notes": f"Providers: {', '.join(stats.get('providers', [])) or 'none'}  ·  "
                 f"Models: {', '.join(stats.get('models', [])[:15]) or 'none'}",
    }


def _finding_category(rule_id: str, findings: list[dict]) -> dict:
    first = findings[0]
    severity = _highest_severity(findings)
    remediation = first.get("remediation", "")
    return {
        "id": rule_id,
        "category": "AI-BOM",
        "name": sig.RULES[rule_id]["title"],
        "title": sig.RULES[rule_id]["title"],
        "risk": severity,
        "risk_score": _RISK_SCORE.get(severity, 1),
        "_source": "AI-BOM", "ruleset": "AI-BOM",
        "description": f"{len(findings)} occurrence(s) of "
                       f"{sig.RULES[rule_id]['title']} ({rule_id}).",
        "affected_components": [f"{f['file']}:{f['line']}" for f in findings][:_MAX_COMPONENTS],
        "mitigation": remediation,
        "remediation": remediation,
        "mitigations": [{"action": remediation,
                         "priority": "Immediate" if severity in ("Critical", "High")
                         else "Planned"}],
        "threats": [{
            "name": f"{f['file']}:{f['line']}",
            "description": f.get("snippet") or "(no snippet)",
            "attack_vector": f.get("title", ""),
            "control_objective": " | ".join(b for b in (f.get("owasp"), f.get("cwe")) if b),
            "false_positive_guidance":
                "Static AI-usage signals are heuristic; confirm the flagged code is "
                "live and reachable before remediating.",
        } for f in findings[:_MAX_THREATS]],
        "notes": f"OWASP: {first.get('owasp', 'n/a')}  ·  CWE: {first.get('cwe') or 'n/a'}  ·  "
                 f"confidence: {first.get('confidence', 'high')}",
    }


def result_to_report(result: dict, repo: dict, meta: dict) -> dict:
    components = result["components"]
    findings = result["findings"]
    stats = result["stats"]

    groups: dict[str, list[dict]] = {}
    for f in findings:
        groups.setdefault(f["id"], []).append(f)
    categories = [_inventory_category(components, stats)] + sorted(
        (_finding_category(rid, fs) for rid, fs in groups.items()),
        key=lambda c: (_SEV_ORDER.get(c["risk"], 99), -len(c["threats"])),
    )

    counts = _severity_counts(findings)
    overall = _highest_severity(findings) if findings else "Info"
    commit = meta.get("commit") and f" @ {meta['commit']}" or ""
    scope = f"{repo.get('name', repo.get('id', 'repo'))}{commit}"

    summary = (
        f"AI-BOM scan of {scope}: {stats['components_total']} AI component(s) "
        f"({', '.join(stats['providers']) or 'no external providers'}), "
        f"{len(stats['models'])} distinct model id(s), and {len(findings)} "
        f"AI-specific finding(s): "
        + (", ".join(f"{counts[s]} {s}" for s in sig.SEVERITIES if counts[s]) or "none")
        + "." if stats.get("ai_detected")
        else f"AI-BOM scan of {scope}: no AI usage detected in "
             f"{stats['files_scanned']} scanned file(s)."
    )

    seen, recommendations = set(), []
    for c in categories[1:]:
        if c["remediation"] and c["remediation"] not in seen:
            seen.add(c["remediation"])
            recommendations.append(c["remediation"])

    return {
        "title": f"AI-BOM · {repo.get('name', repo.get('id', 'repo'))}",
        "methodology": "aibom",
        "methodology_label": "AI Bill of Materials & LLM Usage Inventory",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "analyzed_at": config.now_iso(),
        "summary": summary,
        "categories": categories,
        "recommendations": recommendations,
        "scan_metadata": {
            "repo_id": repo.get("id"),
            "repo_name": repo.get("name"),
            "findings_total": len(findings),
            "rules_triggered": len(groups),
            "severity_counts": counts,
            **{k: v for k, v in stats.items() if k != "by_category"},
            "by_category": stats.get("by_category", {}),
            **meta,
        },
    }


# ── CycloneDX 1.6 AI-BOM ─────────────────────────────────────────────────────
_PURL_ECOSYSTEM = {"manifest:package.json": "npm", "manifest:go.mod": "golang"}


def _purl(comp: dict) -> str | None:
    if comp["type"] != "library":
        return None
    eco = "pypi"
    for source in comp["sources"]:
        if source in _PURL_ECOSYSTEM:
            eco = _PURL_ECOSYSTEM[source]
            break
        if source == "import" and comp["name"].startswith("@"):
            eco = "npm"
    name = comp["name"]
    if eco == "npm" and "/" in name:            # scoped npm package
        ns, _, base = name.partition("/")
        base_purl = f"pkg:npm/{ns}/{base}"
    else:
        base_purl = f"pkg:{eco}/{name}"
    return base_purl + (f"@{comp['version']}" if comp.get("version") else "")


def _cdx_component(comp: dict) -> dict:
    ctype = {"library": "library", "model": "machine-learning-model",
             "model-artifact": "machine-learning-model",
             "credential-ref": "data"}.get(comp["type"], "library")
    entry = {
        "type": ctype,
        "bom-ref": f"{comp['type']}:{comp['name']}",
        "name": comp["name"],
        "properties": [
            {"name": "tm:aibom:category", "value": comp["category"]},
            {"name": "tm:aibom:provider", "value": comp["provider"]},
            {"name": "tm:aibom:confidence", "value": comp["confidence"]},
            {"name": "tm:aibom:sources", "value": ",".join(comp["sources"])},
        ] + [{"name": "tm:aibom:evidence",
              "value": f"{e['file']}:{e['line']}"} for e in comp["evidence"][:5]],
    }
    if comp.get("version"):
        entry["version"] = comp["version"]
    purl = _purl(comp)
    if purl:
        entry["purl"] = purl
    if comp["provider"] not in ("Unknown", "(local artifact)"):
        entry["supplier"] = {"name": comp["provider"]}
    return entry


def to_cyclonedx(result: dict, repo: dict, meta: dict) -> dict:
    components = result["components"]
    services = [{
        "bom-ref": f"endpoint:{c['name']}",
        "name": c["name"],
        "provider": {"name": c["provider"]},
        "properties": [{"name": "tm:aibom:category", "value": "endpoint"}],
    } for c in components if c["type"] == "endpoint"]

    return {
        "bomFormat": "CycloneDX",
        "specVersion": "1.6",
        "serialNumber": f"urn:uuid:{uuid.uuid4()}",
        "version": 1,
        "metadata": {
            "timestamp": config.now_iso(),
            "tools": [{"vendor": "Yaksha Guard", "name": "TM AI-BOM scanner",
                       "version": "1.0"}],
            "component": {
                "type": "application",
                "name": repo.get("name", repo.get("id", "repo")),
                "bom-ref": f"application:{repo.get('id', 'repo')}",
                "properties": [
                    {"name": "tm:aibom:commit", "value": str(meta.get("commit", ""))},
                    {"name": "tm:aibom:branch", "value": str(meta.get("branch", ""))},
                ],
            },
        },
        "components": [_cdx_component(c) for c in components
                       if c["type"] != "endpoint"],
        "services": services,
        "properties": [
            {"name": f"tm:aibom:flag:{k}", "value": str(v).lower()}
            for k, v in result["stats"].get("flags", {}).items()
        ],
    }


# ── Org rollup entry (one per repo, feeds /inventory) ─────────────────────────
def to_rollup(result: dict, repo: dict, meta: dict, job_id: str,
              report_id: str | None) -> dict:
    stats = result["stats"]
    counts = _severity_counts(result["findings"])
    return {
        "repo_id": repo.get("id"),
        "repo_name": repo.get("name"),
        "scanned_at": config.now_iso(),
        "commit": meta.get("commit"),
        "job_id": job_id,
        "report_id": report_id,
        "ai_detected": stats.get("ai_detected", False),
        "providers": stats.get("providers", []),
        "models": stats.get("models", [])[:25],
        "by_category": stats.get("by_category", {}),
        "flags": stats.get("flags", {}),
        "components_total": stats.get("components_total", 0),
        "findings_total": len(result["findings"]),
        "severity_counts": counts,
        "overall_risk": _highest_severity(result["findings"])
        if result["findings"] else "Info",
    }
