"""fleet.py — fleet-wide correlation posture: every registered SAST repo and
DAST target's most-recent correlation coverage, rolled into one cross-repo
view, worst-first.

"Registered" means present in broker.config.load_repos() (SAST) or
dast.config.load_targets() (DAST) -- the same registries dashboard/service.py's
_sast()/_dast() sections already read, so "fleet" here is exactly the set of
repos/targets the rest of the app already treats as registered, not a
separately-maintained list.

A correlation report doesn't scan a repo directly -- it correlates a *set* of
prior scan reports (correlator/service.py's ``sources``, persisted as
scan_metadata.source_reports). Each of those source reports carries the
repo/target it came from in its OWN scan_metadata (broker/mapper.py's
repo_id/repo_name for SAST, dast/mapper.py's target_id/target_name for DAST).
So attributing a correlation report to a repo means tracing its sources back
through that metadata -- a correlation report has no repo_id of its own.

A repo with no correlation report attributed to it yet is "uncorrelated", not
a clean bill of health -- the same distinction dashboard/service.py's
_verdicts() already draws between "verdict counted" and "not yet correlated".
Only the MOST RECENT correlation report touching a repo counts (mirrors
_sast()/_dast()'s "latest scan per repo" convention): older correlation runs
for the same repo are superseded, not summed, so re-correlating after fixing
findings actually lowers a repo's posture instead of the fix being buried
under a stale earlier run's counts.

Verdict counts are recomputed from the latest report's categories (with
suppressions applied), not read off its precomputed scan_metadata.verdict_counts
-- that field predates any suppression decisions made after the report was
saved, and would keep counting a since-risk-accepted finding forever. Same
"suppressed findings don't count toward posture" rule dashboard/service.py's
_verdicts()/_governance() already apply.
"""
from __future__ import annotations

import report_db
import suppressions

_VERDICT_ORDER = ("actively_exploited", "confirmed_exploitable", "corroborated",
                  "design_gap", "blind_spot")


def _registered_repos() -> list[dict]:
    """Every registered SAST repo + DAST target, unified to one shape."""
    out: list[dict] = []
    try:
        from broker import config as bconfig
        for r in bconfig.load_repos():
            out.append({"kind": "sast", "key": str(r.get("id")),
                       "name": r.get("name") or r.get("id"), "url": r.get("url", "")})
    except Exception:
        pass
    try:
        from dast import config as dconfig
        for t in dconfig.load_targets():
            out.append({"kind": "dast", "key": str(t.get("id")),
                       "name": t.get("name") or t.get("id"), "url": t.get("url", "")})
    except Exception:
        pass
    return out


def _source_repo_index(reports: list[dict]) -> dict[str, tuple[str, str]]:
    """Map source-report-id -> (kind, key) for every SAST/DAST report on file."""
    index: dict[str, tuple[str, str]] = {}
    for r in reports:
        method = str(r.get("methodology", "")).lower()
        meta = r.get("scan_metadata") or {}
        rid = r.get("id")
        if not rid:
            continue
        if method == "sast" and meta.get("repo_id"):
            index[rid] = ("sast", str(meta["repo_id"]))
        elif method == "dast" and meta.get("target_id"):
            index[rid] = ("dast", str(meta["target_id"]))
    return index


def _latest_correlation_by_repo(reports: list[dict],
                                index: dict[str, tuple[str, str]]) -> dict[tuple[str, str], dict]:
    """The most recent correlation report attributed to each repo/target.

    ``reports`` must already be newest-first (report_db.all_reports()'s
    contract) so the first match encountered per key is the latest one.
    """
    latest: dict[tuple[str, str], dict] = {}
    for r in reports:
        if str(r.get("methodology", "")).lower() != "correlation":
            continue
        meta = r.get("scan_metadata") or {}
        touched: set[tuple[str, str]] = set()
        for s in meta.get("source_reports") or []:
            key = index.get(s.get("id")) if isinstance(s, dict) else None
            if key:
                touched.add(key)
        for key in touched:
            latest.setdefault(key, r)   # first hit wins -- reports is newest-first
    return latest


def _verdict_counts(report: dict, supps) -> dict:
    counts = {v: 0 for v in _VERDICT_ORDER}
    annotated = suppressions.annotate_report(report, supps)
    for cat in annotated.get("categories") or []:
        if not isinstance(cat, dict) or cat.get("suppressed"):
            continue
        v = cat.get("verdict")
        if v in counts:
            counts[v] += 1
    return counts


def repo_posture() -> list[dict]:
    """One row per registered repo/target: its latest correlation verdict
    breakdown, worst first, or "uncorrelated" if none has ever touched it."""
    reports = report_db.all_reports(limit=2000)   # newest-first
    index = _source_repo_index(reports)
    latest_by_repo = _latest_correlation_by_repo(reports, index)
    supps = suppressions.load_suppressions()

    out = []
    for repo in _registered_repos():
        key = (repo["kind"], repo["key"])
        latest = latest_by_repo.get(key)
        if latest is None:
            out.append({**repo, "correlated": False, "report_id": None, "report_title": None,
                       "analyzed_at": None, "overall_risk": None, "total_actionable": 0,
                       **{v: 0 for v in _VERDICT_ORDER}})
            continue
        counts = _verdict_counts(latest, supps)
        out.append({
            **repo, "correlated": True, "report_id": latest.get("id"),
            "report_title": latest.get("title") or latest.get("id"),
            "analyzed_at": latest.get("analyzed_at"),
            "overall_risk": latest.get("overall_risk"),
            "total_actionable": sum(counts.values()),
            **counts,
        })

    def _rank(row):
        # Worst first: any active incident, then confirmed-exploitable count,
        # then everything else actionable. Uncorrelated repos sink to the
        # bottom -- nothing proven yet is not automatically worse than a repo
        # that has a real confirmed exploit sitting in it.
        return (0 if row["correlated"] else 1,
                -row.get("actively_exploited", 0), -row.get("confirmed_exploitable", 0),
                -row.get("total_actionable", 0))
    out.sort(key=_rank)
    return out


def summary() -> dict:
    """Fleet-wide rollup: totals across every registered repo's latest
    correlation posture, plus correlation coverage (how many repos have ever
    actually been correlated, not just scanned)."""
    rows = repo_posture()
    totals = {v: 0 for v in _VERDICT_ORDER}
    for row in rows:
        for v in _VERDICT_ORDER:
            totals[v] += row.get(v, 0)
    correlated = sum(1 for r in rows if r["correlated"])
    worst = [r for r in rows if r["correlated"]
            and (r["actively_exploited"] or r["confirmed_exploitable"])]
    return {
        "repos": len(rows),
        "correlated": correlated,
        "uncorrelated": len(rows) - correlated,
        "coverage_pct": round(100.0 * correlated / len(rows), 1) if rows else 0.0,
        "totals": totals,
        "worst_repos": worst[:10],
        "repos_detail": rows,
    }
