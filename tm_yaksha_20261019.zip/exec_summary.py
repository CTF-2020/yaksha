"""Executive correlation summary — a plain-English narrative rollup for an
audience that wants paragraphs, not a dashboard, to read.

Deterministic and template-based (same philosophy as correlator/mapper.py's
per-run summary sentence), not LLM-generated -- but this synthesizes across
EVERY report/scan/tool at once rather than one correlation run. It is built
directly on top of dashboard.service.build() instead of re-aggregating from
report_db/verdict_tracking/etc: every number this text states is the exact
number already shown on the Overview dashboard, so the two can never quietly
disagree with each other.
"""
from __future__ import annotations

from datetime import datetime, timezone

from dashboard import service as dashboard_service


def _s(n: int, word: str, plural: str | None = None) -> str:
    return word if n == 1 else (plural or f"{word}s")


def _headline(data: dict) -> str:
    tm = data["threat_model"]
    counts = data["verdicts"]["counts"]
    active = counts.get("actively_exploited", 0)
    confirmed = counts.get("confirmed_exploitable", 0)
    sla = data["verdict_sla"]
    breached = sla["counts"].get("breached", 0) if sla["tracked"] else 0
    crit_high = tm["critical_high"]

    if active:
        return (f"{active} actively-exploited {_s(active, 'weakness', 'weaknesses')} confirmed by "
                f"production evidence — immediate action required.")
    if confirmed:
        return (f"{confirmed} confirmed-exploitable {_s(confirmed, 'weakness', 'weaknesses')} proven "
                f"by static + runtime evidence.")
    if breached:
        return (f"{breached} {_s(breached, 'finding')} past its remediation SLA — no confirmed "
                f"exploits yet, but response is overdue.")
    if crit_high:
        return f"{crit_high} Critical/High {_s(crit_high, 'finding')} open, none yet confirmed exploitable."
    if not tm["reports"]:
        return "No security data yet — run a threat model or scan to get started."
    return "No Critical or High severity findings open — posture is clean."


def _posture_paragraph(data: dict) -> str:
    tm = data["threat_model"]
    reports, findings = tm["reports"], tm["findings"]
    if not reports:
        return ("No reports have been analyzed yet — run a threat model, code scan, or SAST "
                "scan to populate this summary.")
    sev = tm["severity"]
    parts = [
        f"Across {reports} {_s(reports, 'report')} covering {findings} {_s(findings, 'finding')}, "
        f"{tm['critical_high']} {_s(tm['critical_high'], 'is', 'are')} Critical or High severity "
        f"({sev['Critical']} Critical, {sev['High']} High, {sev['Medium']} Medium, "
        f"{sev['Low']} Low, {sev['Info']} Info)."
    ]
    trend = tm.get("trend") or []
    if len(trend) >= 2:
        a, b = trend[-2], trend[-1]
        delta = (b.get("Critical", 0) + b.get("High", 0)) - (a.get("Critical", 0) + a.get("High", 0))
        if delta > 0:
            parts.append(f"That is {delta} more Critical/High than the previous report — risk is trending up.")
        elif delta < 0:
            parts.append(f"That is {abs(delta)} fewer Critical/High than the previous report — risk is trending down.")
        else:
            parts.append("Critical/High volume is unchanged from the previous report.")
    fams = data.get("families") or []
    if fams:
        f = fams[0]
        nice = str(f["family"]).replace("-", " ")
        parts.append(f"The largest weakness family is {nice} ({f['total']} findings, "
                     f"{f.get('high_plus', 0)} High or above).")
    return " ".join(parts)


def _validation_paragraph(data: dict) -> str:
    v = data["verdicts"]
    counts, total_correlated, unverdicted = v["counts"], v["total_correlated"], v["unverdicted"]
    if not total_correlated and not unverdicted:
        return ("No findings have gone through cross-tool correlation yet — run correlation to "
                "distinguish proven risk from theoretical risk.")
    parts = [f"{total_correlated} {_s(total_correlated, 'finding')} "
             f"{_s(total_correlated, 'has', 'have')} been cross-tool correlated"
             + (f"; {unverdicted} more {_s(unverdicted, 'has', 'have')} not yet been correlated."
                if unverdicted else ".")]
    active = counts.get("actively_exploited", 0)
    confirmed = counts.get("confirmed_exploitable", 0)
    corroborated = counts.get("corroborated", 0)
    blind = counts.get("blind_spot", 0)
    gaps = counts.get("design_gap", 0)
    if active:
        parts.append(f"{active} {_s(active, 'is', 'are')} actively exploited — confirmed by a real "
                     f"production incident, the highest-confidence signal this platform produces.")
    if confirmed:
        parts.append(f"{confirmed} {_s(confirmed, 'is', 'are')} confirmed exploitable — a static root "
                     f"cause with an independent runtime proof.")
    if corroborated:
        parts.append(f"{corroborated} {_s(corroborated, 'is', 'are')} corroborated "
                     f"(design intent backed by evidence).")
    if blind:
        parts.append(f"{blind} {_s(blind, 'is', 'are')} blind {_s(blind, 'spot')} — scanning found real "
                     f"weaknesses the threat model never anticipated, meaning the model itself needs updating.")
    if gaps:
        parts.append(f"{gaps} {_s(gaps, 'is', 'are')} design {_s(gaps, 'gap')} — modeled as a risk but "
                     f"neither confirmed nor cleared by any scan yet.")
    return " ".join(parts)


def _remediation_paragraph(data: dict) -> str:
    sla, debt, alerts = data["verdict_sla"], data["design_debt"], data["verdict_alerts"]
    parts = []
    if sla["tracked"]:
        breached, at_risk = sla["counts"].get("breached", 0), sla["counts"].get("at_risk", 0)
        if breached:
            parts.append(f"{breached} {_s(breached, 'finding')} past its verdict's remediation SLA window.")
        elif at_risk:
            parts.append(f"No SLA breaches, but {at_risk} {_s(at_risk, 'finding')} within 20% of its deadline.")
        else:
            parts.append(f"All {sla['tracked']} SLA-tracked findings are within their remediation window.")
    if alerts["unacknowledged"]:
        n = alerts["unacknowledged"]
        parts.append(f"{n} unacknowledged verdict {_s(n, 'escalation')} — a finding became more "
                     f"actionable since it was last reviewed.")
    if debt["open"]:
        net = debt["net_recent"]
        trend_word = "growing" if net > 0 else ("shrinking" if net < 0 else "flat")
        parts.append(f"The design-debt backlog (modeled but unproven risk) is {trend_word}: "
                     f"{debt['open']} open, {'+' if net >= 0 else ''}{net} over the last "
                     f"{debt['window_days']} days (oldest {debt['oldest_days']} days).")
    return " ".join(parts) if parts else "No remediation-tracking data yet."


def _coverage_paragraph(data: dict) -> str:
    tm, sast, dast, aibom = data["threat_model"], data["sast"], data["dast"], data["aibom"]
    parts = []
    by_meth = tm.get("by_methodology") or {}
    if by_meth:
        mix = ", ".join(f"{v} {k}" for k, v in sorted(by_meth.items(), key=lambda kv: -kv[1]))
        parts.append(f"Report mix: {mix}.")
    estate = []
    if sast.get("available") and sast.get("repos"):
        estate.append(f"{sast['repos']} {_s(sast['repos'], 'repo')} on continuous SAST")
    if dast.get("available") and dast.get("targets"):
        estate.append(f"{dast['targets']} {_s(dast['targets'], 'target')} on DAST")
    if aibom.get("available") and aibom.get("repos_with_ai"):
        estate.append(f"{aibom['repos_with_ai']} {_s(aibom['repos_with_ai'], 'repo')} using AI/LLM components")
    if estate:
        parts.append("Estate coverage: " + ", ".join(estate) + ".")
    reach = data.get("reachable_dependencies") or {}
    if reach.get("count"):
        n = reach["count"]
        parts.append(f"{n} vulnerable {_s(n, 'dependency has', 'dependencies have')} a proven "
                     f"reachable call path from an entry point.")
    return " ".join(parts) if parts else "No SAST/AI-BOM coverage recorded yet."


def _accountability_paragraph(data: dict) -> str:
    gov = data.get("governance") or {}
    total = gov.get("total_actionable", 0)
    accepted = gov.get("risk_accepted", 0)
    parts = []
    if total:
        owned, coverage, urgent = gov.get("owned", 0), gov.get("coverage_pct", 0.0), gov.get("unowned_urgent", 0)
        parts.append(f"{owned} of {total} correlated {_s(total, 'finding')} "
                     f"({coverage:g}%) {_s(owned, 'has', 'have')} an assigned owner.")
        if urgent:
            parts.append(f"{urgent} actively-exploited or confirmed-exploitable "
                         f"{_s(urgent, 'finding')} {_s(urgent, 'has', 'have')} no owner yet — "
                         f"the highest-confidence risk this platform produces, unassigned.")
    elif not accepted:
        return ("No correlated findings yet to assign — accountability tracking begins once "
                "findings have a verdict.")
    if accepted:
        by_state = gov.get("risk_accepted_by_state") or {}
        mix = ", ".join(f"{v} {k.replace('_', ' ')}" for k, v in
                        sorted(by_state.items(), key=lambda kv: -kv[1]))
        parts.append(f"{accepted} {_s(accepted, 'finding')} {_s(accepted, 'is', 'are')} "
                     f"under an active risk-acceptance decision ({mix}).")
    return " ".join(parts)


def build() -> dict:
    """The full executive summary: a headline plus four narrative sections,
    all derived from dashboard.service.build() so the prose can never drift
    from the numbers already on the Overview dashboard."""
    data = dashboard_service.build()
    return {
        "success": data["success"],
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "headline": _headline(data),
        "sections": [
            {"key": "posture", "title": "Security Posture", "text": _posture_paragraph(data)},
            {"key": "validation", "title": "Validation & Correlation", "text": _validation_paragraph(data)},
            {"key": "remediation", "title": "Remediation Health", "text": _remediation_paragraph(data)},
            {"key": "coverage", "title": "Coverage", "text": _coverage_paragraph(data)},
            {"key": "accountability", "title": "Accountability",
             "text": _accountability_paragraph(data)},
        ],
        "as_of": {"reports": data["threat_model"]["reports"], "findings": data["threat_model"]["findings"]},
    }
