"""Tests for codemodel/config_extractor.py's Dockerfile privilege detection.

Run:  python -m unittest test_config_extractor   (stdlib only)
"""
from __future__ import annotations

import unittest

from codemodel import config_extractor as ce
from codemodel.model import SystemModel


def _dockerfile_boundaries(source: str) -> list:
    model = SystemModel()
    ce.extract(source, "Dockerfile", model)
    return [b for b in model.trust_boundaries if b.kind == "privilege"]


class DockerfileRootDetectionTests(unittest.TestCase):
    def test_no_user_directive_flags_root(self):
        src = "FROM python:3.12\nCOPY . /app\nCMD [\"python\", \"app.py\"]\n"
        self.assertEqual(len(_dockerfile_boundaries(src)), 1)

    def test_explicit_user_root_still_flags_root(self):
        # The exact case this control most needs to catch — must not be suppressed.
        src = "FROM python:3.12\nUSER root\nCMD [\"python\", \"app.py\"]\n"
        self.assertEqual(len(_dockerfile_boundaries(src)), 1)

    def test_non_root_user_directive_clears_the_flag(self):
        src = "FROM python:3.12\nUSER appuser\nCMD [\"python\", \"app.py\"]\n"
        self.assertEqual(_dockerfile_boundaries(src), [])

    def test_unrelated_comment_mentioning_user_does_not_suppress_the_flag(self):
        src = ("FROM python:3.12\n"
               "# create a non-root user for safety later\n"
               "CMD [\"python\", \"app.py\"]\n")
        self.assertEqual(len(_dockerfile_boundaries(src)), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
