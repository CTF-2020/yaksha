"""Suppression / risk-acceptance API.

CRUD over the suppression store plus two report-aware conveniences:

  * ``GET  /api/v1/suppressions``                — list every suppression (with an
    ``expired`` flag), newest first.
  * ``POST /api/v1/suppressions``                — create one (validated); body is
    a Suppression JSON (scope, match, reason, author, state, report_id?, expires_at?,
    max_verdict?).
  * ``DELETE /api/v1/suppressions/<id>``         — remove one.
  * ``GET  /api/v1/reports/<id>/suppressed``     — the report annotated with which
    findings are suppressed + the active-vs-suppressed severity summary.
  * ``POST /api/v1/reports/<id>/suppress``       — accept-risk a specific finding by
    fingerprint OR index, capturing a display label from the live report so the
    caller does not have to compute a fingerprint by hand.

Writes go through the same CSRF/auth gate as the rest of the app (enforced in the
app's before_request). Suppressions never delete findings — they annotate — so
this endpoint cannot destroy evidence.
"""
from __future__ import annotations

import time

from flask import Blueprint, jsonify, request

import app as tm_app
import suppressions
from suppressions import engine, store

bp = Blueprint("suppressions_api", __name__, url_prefix="/api/v1")


def _load_report(report_id: str):
    """Reuse the reports API loader semantics (validation, SAST gating)."""
    from api.reports import _load
    return _load(report_id)


@bp.get("/suppressions")
def list_all():
    items = store.list_suppressions()
    items.sort(key=lambda d: d.get("created_at", 0), reverse=True)
    return jsonify({"success": True, "count": len(items), "suppressions": items})


@bp.post("/suppressions")
def create():
    body = request.get_json(silent=True) or {}
    try:
        supp = store.add_suppression(body)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify({"success": True, "suppression": supp.public_dict()}), 201


@bp.delete("/suppressions/<supp_id>")
def delete(supp_id: str):
    removed = store.delete_suppression(supp_id)
    if not removed:
        return jsonify({"success": False, "error": "Not found"}), 404
    return jsonify({"success": True, "deleted": supp_id})


@bp.get("/reports/<report_id>/suppressed")
def report_suppressed(report_id: str):
    """The report with suppressions applied: per-finding flags + summary."""
    report, err = _load_report(report_id)
    if err:
        return err
    annotated = engine.annotate_report(report, suppressions.load_suppressions())
    return jsonify({
        "success": True,
        "summary": annotated["suppression_summary"],
        "active_severity_counts": annotated["active_severity_counts"],
        "suppressed_severity_counts": annotated["suppressed_severity_counts"],
        "findings": [
            {
                "index": i,
                "fingerprint": c.get("fingerprint"),
                "id": c.get("id"),
                "name": c.get("name") or c.get("title"),
                "family": c.get("family"),
                "risk": c.get("risk") or c.get("severity"),
                "suppressed": bool(c.get("suppressed")),
                "suppression": c.get("suppression"),
            }
            for i, c in enumerate(annotated["categories"])
            if isinstance(c, dict)
        ],
    })


@bp.post("/reports/<report_id>/suppress")
def suppress_finding(report_id: str):
    """Accept-risk one finding in a report by ``fingerprint`` or ``index``.

    Body: {reason, author, state?, scope?, expires_at?, fingerprint?|index?,
    global?, max_verdict?}. Resolves the target finding from the live report to
    capture its fingerprint + a human label, so a caller working from the viewer
    can suppress with one click. ``scope`` defaults to "finding"; pass
    "family"/"rule" to widen from the resolved finding's family/rule id.
    ``global`` (bool) makes it apply across all reports instead of just this
    one. ``max_verdict`` (one of suppressions.model.VERDICTS) caps how
    actionable a correlated finding may be and still get muted by a
    family/rule-scoped suppression — recommended when widening scope beyond
    "finding", so accepting today's design-gap version of a family does not
    silently swallow tomorrow's confirmed-exploitable one.

    The resolved finding's own ``verdict`` (if it carries one) is captured
    automatically and enforces suppressions.model.MAX_EXPIRY_DAYS — an
    "accepted" decision against a confirmed_exploitable/actively_exploited
    finding cannot be granted indefinitely (or longer than policy allows)
    even if the caller passes ``expires_at: 0`` or a later date.
    """
    report, err = _load_report(report_id)
    if err:
        return err
    body = request.get_json(silent=True) or {}
    categories = [c for c in (report.get("categories") or []) if isinstance(c, dict)]

    target = None
    fp = str(body.get("fingerprint") or "").strip()
    if fp:
        target = next((c for c in categories
                       if engine.finding_fingerprint(c) == fp), None)
    elif "index" in body:
        try:
            idx = int(body["index"])
        except (TypeError, ValueError):
            return jsonify({"success": False, "error": "index must be an integer"}), 400
        if 0 <= idx < len(categories):
            target = categories[idx]
    if target is None:
        return jsonify({"success": False,
                        "error": "finding not found (pass a valid fingerprint or index)"}), 404

    scope = str(body.get("scope") or "finding").strip()
    if scope == "family":
        match = str(target.get("family") or "").strip().lower() \
            or engine._family(target)
    elif scope == "rule":
        match = str(target.get("id") or target.get("category") or "").strip()
    else:
        scope = "finding"
        match = engine.finding_fingerprint(target)

    label = str(target.get("name") or target.get("title") or match)[:400]
    record = {
        "scope": scope,
        "match": match,
        "reason": body.get("reason"),
        "author": body.get("author"),
        "state": body.get("state") or "accepted",
        "report_id": "" if body.get("global") else report_id,
        "expires_at": body.get("expires_at") or 0,
        "label": label,
        "max_verdict": body.get("max_verdict") or "",
        "verdict": target.get("verdict") or "",
    }
    try:
        supp = store.add_suppression(record)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify({"success": True, "suppression": supp.public_dict(time.time())}), 201
