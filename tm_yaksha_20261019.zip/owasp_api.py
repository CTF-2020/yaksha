"""owasp_api.py — OWASP API Security Top 10 2023 knowledge base."""
from __future__ import annotations

OWASP_API_TOP10: dict[str, dict] = {
    "API1": {
        "id": "API1:2023",
        "name": "Broken Object Level Authorization",
        "description": (
            "APIs expose endpoints that handle object identifiers. "
            "Without proper authorization checks at the object level, attackers manipulate IDs "
            "to access or modify other users' data (BOLA/IDOR)."
        ),
        "common_examples": [
            "Accessing /api/orders/12345 and changing the ID to retrieve another user's order",
            "PUT /api/users/99/profile modifying a different user's profile by changing the user ID",
            "Bulk data export endpoints that ignore per-object ownership checks",
        ],
        "mitigations": [
            "Enforce object-level authorization on every endpoint using the authenticated user's identity",
            "Use indirect object references (GUIDs, random tokens) instead of sequential integers",
            "Log and alert on repeated cross-tenant access denials",
        ],
    },
    "API2": {
        "id": "API2:2023",
        "name": "Broken Authentication",
        "description": (
            "Authentication mechanisms are often implemented incorrectly, "
            "allowing attackers to compromise authentication tokens or exploit implementation flaws "
            "to assume other users' identities temporarily or permanently."
        ),
        "common_examples": [
            "JWT tokens not validated for algorithm confusion (RS256 → HS256 attack)",
            "API keys without expiry or rotation mechanism sent in query parameters",
            "OAuth flows missing PKCE, allowing authorization code interception",
        ],
        "mitigations": [
            "Validate JWT signature, algorithm (allowlist only), issuer, audience, and expiry on every request",
            "Support API key rotation and immediate revocation; never accept keys in query strings",
            "Enforce PKCE for all OAuth authorization code flows; bind tokens to client fingerprints",
        ],
    },
    "API3": {
        "id": "API3:2023",
        "name": "Broken Object Property Level Authorization",
        "description": (
            "APIs expose more object properties than required, or allow clients to update properties "
            "they shouldn't have access to. Includes both excessive data exposure and mass assignment."
        ),
        "common_examples": [
            "GET /api/users returns password_hash, internal_role, and created_at for all callers",
            "POST /api/profile accepting is_admin: true in the request body and binding it to the model",
            "PATCH endpoint allowing modification of read-only fields like account_balance or subscription_tier",
        ],
        "mitigations": [
            "Use response DTOs that explicitly allowlist returned fields — never return raw ORM objects",
            "Apply mass assignment protection: explicitly allowlist writable fields on every write operation",
            "Enforce field-level authorization: certain properties readable/writable only by specific roles",
        ],
    },
    "API4": {
        "id": "API4:2023",
        "name": "Unrestricted Resource Consumption",
        "description": (
            "APIs that do not enforce limits on request frequency or payload size are vulnerable to "
            "denial of service, excessive billing, and resource exhaustion."
        ),
        "common_examples": [
            "No rate limiting on POST /api/analyze — single client can exhaust third-party API quota",
            "GET /api/records with no pagination — returning millions of rows per call",
            "File upload endpoint accepting 10GB payloads causing OOM crashes",
        ],
        "mitigations": [
            "Enforce per-client rate limits (token bucket or leaky bucket) on every endpoint",
            "Mandate pagination with a hard maximum page size (e.g., max 100 records per request)",
            "Enforce file upload size limits and MIME type validation at the API boundary",
        ],
    },
    "API5": {
        "id": "API5:2023",
        "name": "Broken Function Level Authorization",
        "description": (
            "Complex access control policies with different roles and groups lead to authorization "
            "mistakes when administrative or sensitive functions are exposed without proper enforcement."
        ),
        "common_examples": [
            "DELETE /api/admin/users/{id} accessible to regular users because the route is 'hidden'",
            "PUT /api/products/{id} intended for admins but enforced only on the frontend, not the API",
            "Internal management endpoints reachable from the public internet without auth",
        ],
        "mitigations": [
            "Enforce role-based authorization server-side on every route — never rely on obscurity",
            "Deny all HTTP methods not explicitly needed for each endpoint",
            "Separate admin APIs from public APIs at the network level (different port, host, VPC)",
        ],
    },
    "API6": {
        "id": "API6:2023",
        "name": "Unrestricted Access to Sensitive Business Flows",
        "description": (
            "Some APIs expose business flows (buying, booking, voting) without controls preventing "
            "automated abuse. Attackers write scripts to perform actions at scale that cause business harm."
        ),
        "common_examples": [
            "Ticket-purchasing API allowing bots to buy all available inventory in milliseconds",
            "Referral bonus API allowing automated account creation to farm rewards",
            "OTP endpoint allowing unlimited guesses due to missing rate limiting",
        ],
        "mitigations": [
            "Apply CAPTCHA or behavioral analysis (device fingerprint, mouse movement) on critical flows",
            "Enforce per-user/per-device rate limits on business-critical endpoints",
            "Use idempotency keys on payment/order operations to prevent replay-based fraud",
        ],
    },
    "API7": {
        "id": "API7:2023",
        "name": "Server Side Request Forgery",
        "description": (
            "Modern APIs fetch remote resources based on user-supplied URLs. Without validation, "
            "attackers coerce the server to make requests to internal services, cloud metadata "
            "endpoints, or other unintended destinations."
        ),
        "common_examples": [
            "Webhook URL accepting http://169.254.169.254/latest/meta-data/ to steal AWS IAM credentials",
            "Import-from-URL feature fetching internal admin panels via http://localhost:8080/admin",
            "PDF generator fetching attacker-controlled URL that points to internal Redis instance",
        ],
        "mitigations": [
            "Validate user-supplied URLs against a positive allowlist of permitted schemes, hosts, and ports",
            "Block all requests to private IP ranges (RFC 1918), loopback, and cloud metadata IPs",
            "Use a dedicated egress proxy with enforced allowlist for all server-side HTTP requests",
        ],
    },
    "API8": {
        "id": "API8:2023",
        "name": "Security Misconfiguration",
        "description": (
            "Security misconfiguration in APIs includes overly permissive CORS, verbose error messages "
            "exposing stack traces, missing TLS enforcement, default credentials, and unnecessary "
            "HTTP methods or features being enabled."
        ),
        "common_examples": [
            "CORS configured with Access-Control-Allow-Origin: * on authenticated endpoints",
            "500 errors returning full Python/Java stack traces with file paths and query strings",
            "TLS 1.0/1.1 still accepted due to missing protocol downgrade controls",
        ],
        "mitigations": [
            "Lock CORS to specific trusted origins — never use wildcard on authenticated endpoints",
            "Return generic error messages in production; log details server-side only",
            "Enforce TLS 1.2+ with strong cipher suites; use HSTS with long max-age",
        ],
    },
    "API9": {
        "id": "API9:2023",
        "name": "Improper Inventory Management",
        "description": (
            "Organizations often fail to track all deployed API versions, resulting in unpatched "
            "legacy endpoints remaining in production. Shadow APIs and undocumented endpoints "
            "are common attack vectors."
        ),
        "common_examples": [
            "API v1 left running in production after v2 launch — v1 lacks v2's security fixes",
            "Internal microservice APIs accidentally exposed on the public load balancer",
            "Third-party integrations not listed in API inventory, not reviewed during security audits",
        ],
        "mitigations": [
            "Maintain an up-to-date API inventory with owner, version, exposure level, and sunset date",
            "Enforce a deprecation policy — decommission old API versions on a fixed schedule",
            "Run API discovery/traffic analysis tools to detect undocumented shadow endpoints",
        ],
    },
    "API10": {
        "id": "API10:2023",
        "name": "Unsafe Consumption of APIs",
        "description": (
            "Developers inherently trust third-party APIs without applying the same security scrutiny "
            "as they would to user input. Attackers exploit this trust by compromising the third-party "
            "service or performing MitM attacks on the integration."
        ),
        "common_examples": [
            "Third-party API returns malicious JavaScript; application renders it without sanitization",
            "Partner webhook payload contains SQL injection payload passed directly to a query",
            "TLS certificate verification disabled for a third-party API due to a legacy integration",
        ],
        "mitigations": [
            "Validate and sanitize all data received from third-party APIs as if it were user input",
            "Always verify TLS certificates for third-party API connections — never disable verification",
            "Monitor third-party API behavior for unexpected changes in response structure or content",
        ],
    },
}
