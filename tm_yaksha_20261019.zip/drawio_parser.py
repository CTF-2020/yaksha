"""drawio_parser.py -- Extract text descriptions from .drawio / draw.io XML files."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET


def parse_drawio(xml_content: str) -> str:
    """
    Parse a .drawio XML string and return a text description
    suitable for use as architecture input to the threat analyzer.
    """
    try:
        root = ET.fromstring(xml_content)
    except ET.ParseError as e:
        raise ValueError(f"Invalid draw.io XML: {e}")

    nodes = []
    edges = []

    # draw.io stores cells inside <mxCell> elements
    for cell in root.iter("mxCell"):
        value = cell.get("value", "").strip()
        style = cell.get("style", "")
        edge = cell.get("edge", "0")
        source = cell.get("source")
        target = cell.get("target")
        cell_id = cell.get("id")

        if not value or value in ("", "0", "1"):
            continue

        # Clean HTML tags from labels
        value = re.sub(r"<[^>]+>", " ", value).strip()
        value = re.sub(r"&lt;", "<", value)
        value = re.sub(r"&gt;", ">", value)
        value = re.sub(r"&amp;", "&", value)
        value = re.sub(r"\s+", " ", value).strip()

        if not value:
            continue

        if edge == "1":
            edges.append({"label": value, "source": source, "target": target})
        else:
            nodes.append({"id": cell_id, "label": value, "style": style})

    if not nodes and not edges:
        raise ValueError(
            "No components found in draw.io file. Ensure the diagram has labeled shapes."
        )

    # Build id -> label map
    id_map = {n["id"]: n["label"] for n in nodes}

    lines = ["# Architecture Components (extracted from draw.io diagram)\n"]

    if nodes:
        lines.append("## Components")
        for n in nodes:
            lines.append(f"- {n['label']}")
        lines.append("")

    if edges:
        lines.append("## Data Flows / Connections")
        for e in edges:
            src_label = id_map.get(e["source"], e["source"] or "?")
            tgt_label = id_map.get(e["target"], e["target"] or "?")
            label = e["label"]
            lines.append(f"- {src_label} -> [{label}] -> {tgt_label}")
        lines.append("")

    return "\n".join(lines)
