"""Read-side fetch of Jira issues and Confluence pages -- the reverse leg of
api/tickets.py (which only pushes: create ticket, publish report page).

Routes:
  GET /api/v1/jira/issues/<issue_key>            one issue's full details
  GET /api/v1/jira/issues/<issue_key>/comments   that issue's comments
  GET /api/v1/jira/search?jql=...&max_results=   JQL search, normalized issues
  GET /api/v1/confluence/pages/<page_id>         one page's full details
                                                  (storage-format HTML + flattened text)
  GET /api/v1/confluence/search?cql=...&limit=   CQL search, lightweight result rows

Credentials are never accepted from the query string (that would land live
Jira/Confluence tokens in access logs and browser history) -- every route
resolves them server-side from settings_db, same precedence and same keys
(jira.url/jira.email/jira.token/..., confluence.base_url/email/api_token/...)
app.py's _create_tickets_impl / _publish_confluence_page_impl already use for
the write side. All GET, so none of this needs a CSRF token (app.py's
before_request only gates non-GET/HEAD/OPTIONS).
"""
from __future__ import annotations

import os
import re

from flask import Blueprint, jsonify, request

import jira_client
import settings_db

jira_bp = Blueprint("jira_fetch_api", __name__, url_prefix="/api/v1/jira")
confluence_bp = Blueprint("confluence_fetch_api", __name__, url_prefix="/api/v1/confluence")

# Jira Cloud/Server issue keys: one or more uppercase letters/digits (project
# key, starting with a letter), a dash, and the numeric sequence -- e.g.
# SEC-101. Rejecting anything else before it reaches a URL keeps a stray
# path segment from being interpreted as part of the REST path.
_ISSUE_KEY_RE = re.compile(r"^[A-Z][A-Z0-9]*-\d+$")
# Confluence page ids are purely numeric.
_PAGE_ID_RE = re.compile(r"^\d+$")


def _jira_cfg() -> jira_client.TicketConfig:
    return jira_client.TicketConfig(
        provider="jira",
        jira_url=settings_db.resolve_str("jira.url", os.environ.get("JIRA_URL"), ""),
        jira_email=settings_db.resolve_str("jira.email", os.environ.get("JIRA_EMAIL"), ""),
        jira_token=settings_db.resolve_str("jira.token", os.environ.get("JIRA_TOKEN"), ""),
        jira_project_key=settings_db.resolve_str("jira.project", os.environ.get("JIRA_PROJECT"), ""),
    )


def _confluence_cfg() -> jira_client.TicketConfig:
    return jira_client.TicketConfig(
        provider="confluence",
        confluence_base_url=settings_db.resolve_str(
            "confluence.base_url", os.environ.get("CONFLUENCE_BASE_URL"), ""),
        confluence_email=settings_db.resolve_str(
            "confluence.email", os.environ.get("CONFLUENCE_EMAIL"), ""),
        confluence_api_token=settings_db.resolve_str(
            "confluence.api_token", os.environ.get("CONFLUENCE_API_TOKEN"), ""),
        confluence_space_key=settings_db.resolve_str(
            "confluence.space_key", os.environ.get("CONFLUENCE_SPACE_KEY"), ""),
    )


def _upstream_error(exc: Exception):
    """Map a jira_client RuntimeError (its _http wraps every HTTPError as
    "HTTP <code> <reason>: <body>") back to a matching status code, so a
    bad issue key surfaces as 404 rather than a blanket 502."""
    msg = str(exc)
    if msg.startswith("HTTP 404"):
        return jsonify({"success": False, "error": "Not found"}), 404
    if msg.startswith("HTTP 401") or msg.startswith("HTTP 403"):
        return jsonify({"success": False, "error": "Not authorized -- check the configured "
                                                     "credentials"}), 502
    return jsonify({"success": False, "error": msg}), 502


# ── Jira ─────────────────────────────────────────────────────────────────────

@jira_bp.get("/issues/<issue_key>")
def get_issue(issue_key: str):
    if not _ISSUE_KEY_RE.match(issue_key):
        return jsonify({"success": False, "error": "Invalid issue key"}), 400
    cfg = _jira_cfg()
    if not all([cfg.jira_url, cfg.jira_email, cfg.jira_token]):
        return jsonify({"success": False, "error": "Jira is not configured (jira_url, "
                                                     "jira_email, jira_token)"}), 400
    try:
        issue = jira_client.get_issue(cfg, issue_key)
    except jira_client.UnsafeURLError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    except Exception as exc:
        return _upstream_error(exc)
    return jsonify({"success": True, "issue": issue})


@jira_bp.get("/issues/<issue_key>/comments")
def get_issue_comments(issue_key: str):
    if not _ISSUE_KEY_RE.match(issue_key):
        return jsonify({"success": False, "error": "Invalid issue key"}), 400
    cfg = _jira_cfg()
    if not all([cfg.jira_url, cfg.jira_email, cfg.jira_token]):
        return jsonify({"success": False, "error": "Jira is not configured (jira_url, "
                                                     "jira_email, jira_token)"}), 400
    try:
        max_results = int(request.args.get("max_results", 50))
    except ValueError:
        max_results = 50
    try:
        comments = jira_client.get_issue_comments(cfg, issue_key, max_results=max_results)
    except jira_client.UnsafeURLError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    except Exception as exc:
        return _upstream_error(exc)
    return jsonify({"success": True, "comments": comments})


@jira_bp.get("/search")
def search_issues():
    jql = request.args.get("jql", "").strip()
    if not jql:
        return jsonify({"success": False, "error": "jql is required"}), 400
    cfg = _jira_cfg()
    if not all([cfg.jira_url, cfg.jira_email, cfg.jira_token]):
        return jsonify({"success": False, "error": "Jira is not configured (jira_url, "
                                                     "jira_email, jira_token)"}), 400
    try:
        max_results = int(request.args.get("max_results", 50))
    except ValueError:
        max_results = 50
    try:
        issues = jira_client.search_issues(cfg, jql, max_results=max_results)
    except jira_client.UnsafeURLError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    except Exception as exc:
        return _upstream_error(exc)
    return jsonify({"success": True, "issues": issues})


# ── Confluence ───────────────────────────────────────────────────────────────

@confluence_bp.get("/pages/<page_id>")
def get_page(page_id: str):
    if not _PAGE_ID_RE.match(page_id):
        return jsonify({"success": False, "error": "Invalid page id"}), 400
    cfg = _confluence_cfg()
    if not all([cfg.confluence_base_url, cfg.confluence_email, cfg.confluence_api_token]):
        return jsonify({"success": False, "error": "Confluence is not configured "
                                                     "(confluence_base_url, confluence_email, "
                                                     "confluence_api_token)"}), 400
    try:
        page = jira_client.get_confluence_page(cfg, page_id)
    except jira_client.UnsafeURLError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    except Exception as exc:
        return _upstream_error(exc)
    return jsonify({"success": True, "page": page})


@confluence_bp.get("/search")
def search_pages():
    cql = request.args.get("cql", "").strip()
    if not cql:
        return jsonify({"success": False, "error": "cql is required"}), 400
    cfg = _confluence_cfg()
    if not all([cfg.confluence_base_url, cfg.confluence_email, cfg.confluence_api_token]):
        return jsonify({"success": False, "error": "Confluence is not configured "
                                                     "(confluence_base_url, confluence_email, "
                                                     "confluence_api_token)"}), 400
    try:
        limit = int(request.args.get("limit", 25))
    except ValueError:
        limit = 25
    try:
        pages = jira_client.search_confluence_pages(cfg, cql, limit=limit)
    except jira_client.UnsafeURLError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    except Exception as exc:
        return _upstream_error(exc)
    return jsonify({"success": True, "pages": pages})
