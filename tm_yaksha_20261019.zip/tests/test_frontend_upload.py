"""Regression tests for upload-driven review UI behavior."""
from pathlib import Path


ROOT = Path(__file__).parent.parent


def test_drop_zone_preserves_file_input_when_label_changes():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    assert 'id="file-inp"' in html
    assert 'id="drop-zone-label"' in html
    assert "dz.textContent =" not in html


def test_drop_zone_does_not_use_recursive_inline_click_handler():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    assert 'id="drop-zone" onclick=' not in html
    assert "event.target === fi" in html
    assert "fi.addEventListener('click'" in html


def test_upload_review_keeps_typed_architecture_in_formdata():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    assert "form.append('architecture', arch);" in html


def test_upload_input_supports_multiple_files():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    assert 'id="file-inp"' in html
    assert " multiple" in html
    assert "supporting documents" in html.lower()


def test_review_form_appends_every_selected_file():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    assert "Array.from(fileInput?.files || [])" in html
    assert "files.forEach(file => form.append('file', file));" in html
    assert "form.append('file', file);" not in html
    assert "Array.from(e.dataTransfer.files || [])" in html


def test_issue_count_and_issue_numbers_are_rendered():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    fallback = (ROOT / "static" / "tm_fallback.js").read_text(encoding="utf-8")

    assert "Issues Identified" in html
    assert "issues analyzed" in html
    assert "risk-number" in html
    assert "buildRiskCard(c, index)" in html
    assert "Issues Identified" in fallback
    assert "risk-number" in fallback


def test_issue_cards_have_distinct_visual_identity():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    fallback = (ROOT / "static" / "tm_fallback.js").read_text(encoding="utf-8")

    assert "function issueFamily(c)" in html
    assert "class=\"issue-lane\"" in html
    assert "risk-fingerprint" in html
    assert "issue-scope-strip" in html
    assert "--issue-accent" in html
    assert "function issueFamily(c)" in fallback
    assert "issue-lane" in fallback
    assert "risk-fingerprint" in fallback


def test_stride_and_pasta_tabs_render_detailed_methodology_content():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")

    assert "function strideDetailHtml(item)" in html
    assert "DREAD Score" in html
    assert "Validation Questions" in html
    assert "Recommended Tests" in html
    assert "pasta-overview-grid" in html
    assert "Stage Objective" in html
    assert "Assumptions to Validate" in html
    assert "Attack Tree Validation Details" in html


def test_existing_diagrams_are_moved_into_architecture_diagram_tab():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")

    assert "Architecture Diagram" in html
    assert "function collectReportDiagrams(report)" in html
    assert "report.diagram" in html
    assert "analysis.diagrams" in html
    assert "analysis.diagram" in html
    assert "renderDiagramsPanel(report)" in html


def test_report_pqc_assessment_route_is_wired_to_frontend():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")

    assert "function runReportPqc()" in html
    assert "id=\"btn-run-pqc\"" in html
    assert "onclick=\"runReportPqc()\"" in html
    assert "'/api/reports/' + encodeURIComponent(currentReportId) + '/pqc'" in html
    assert "const hasPqc   = !!report.pqc_assessment;" in html


def test_controls_tab_renders_explanatory_control_cards():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")

    assert "function controlRationale" in html
    assert "function renderControlRegisterCards" in html
    assert "ctrl-card" in html
    assert "Why it matters" in html
    assert "How to verify" in html
    assert "Threat context" in html
    assert "Owner and evidence" in html


def test_sbom_analysis_route_is_wired_to_upload_ui():
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")

    assert "id=\"btn-sbom\"" in html
    assert "function analyzeSbomFile()" in html
    assert "apiFetch('/api/sbom', 'POST', form)" in html
    assert "form.append('file', files[0]);" in html
