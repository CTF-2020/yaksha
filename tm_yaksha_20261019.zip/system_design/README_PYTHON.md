# system-design-skill Python wrapper

This folder now contains a full Python tool around the generated `system-design`
skill files. It keeps the original markdown content intact and adds a CLI,
searchable knowledge base, summaries, outlines, study plans, quiz/flashcard
generation, exports, and an interactive mode.

## Files

- `system_design_full.py` - full standalone CLI and importable knowledge base.
- `system_design_skill.py` - earlier lightweight CLI/module kept for compatibility.
- `test_system_design_skill.py` - unit tests for parsing and study helpers.
- `test_system_design_full.py` - unit tests for the full standalone script.
- `pyproject.toml` - optional install metadata and console script entry point.
- `examples/basic_usage.py` - minimal Python import example.

## Run directly

```powershell
python system_design_full.py info
python system_design_full.py stats
python system_design_full.py topics --with-stats
python system_design_full.py toc --max-depth 3
python system_design_full.py show "Caching" --with-meta
python system_design_full.py summary "Caching" -n 2
python system_design_full.py outline "Caching"
python system_design_full.py search "cache invalidation" -n 3
python system_design_full.py related "Caching"
python system_design_full.py glossary -n 20
python system_design_full.py flashcards "Caching" -n 5
python system_design_full.py quiz "Caching" -n 3
python system_design_full.py plan --focus interview --days 2
python system_design_full.py issues --status open
python system_design_full.py tree -n 20
python system_design_full.py export --format html --output system-design-index.html
python system_design_full.py interactive
```

## Install locally

From this folder:

```powershell
python -m pip install -e .
system-design-skill info
system-design-full search "rate limiting"
```

## Use from Python

```python
from pathlib import Path

from system_design_full import SystemDesignKnowledgeBase

skill = SystemDesignKnowledgeBase.load(Path(__file__).resolve().parent)

print(skill.title)
print(skill.summarize("Caching", sentences=2))

for result in skill.search("consistent hashing", limit=3):
    print(result.section.title, result.score)
```

## JSON output

Commands that are useful for scripts support `--json`:

```powershell
python system_design_full.py topics --json
python system_design_full.py outline "Caching" --json
python system_design_full.py quiz "Caching" --json
python system_design_full.py export --format json --output skill_index.json --include-body
```

## Validate

```powershell
python -m unittest test_system_design_full.py
python -m unittest test_system_design_skill.py
python -m py_compile system_design_full.py system_design_skill.py test_system_design_full.py test_system_design_skill.py
```
