"""_rules_architecture.py — Security Architecture Principles offline rules.

Sources:
  - Nichols (2024): Ch.4 Architecture Principles, Ch.5 Risk/Governance, Ch.11 Best Practices, Ch.12 Adaptability
  - Green (2025): Ch.1 Security Architecture, Ch.2 Frameworks, Ch.5 System Security
"""
ARCHITECTURE_RULES: list[dict] = [
    # ── Zero Trust ─────────────────────────────────────────────────────────────
    {
        "id": "ARCH-ZT-01",
        "category": "ZERO_TRUST",
        "question": "Is zero trust enforced — no implicit trust based on network location (VPN/internal-only doesn't equal trusted)?",
        "rationale": "Perimeter-based trust is obsolete. Once inside the network, attackers move laterally without challenge. Zero trust verifies every request regardless of origin. (Green Ch.5 ZTA; Nichols Ch.4 p.103)",
        "severity": "High",
        "patterns_to_check": ["vpn", "trusted network", "internal network", "private network", "intranet", "corporate network", "behind the firewall"],
        "mitigations": [
            "Adopt Microsoft RaMP (Rapid Modernisation Plan) or NIST SP 800-207 as your ZTA implementation guide",
            "Enforce continuous verification on every request: authenticate identity, validate device health, authorise per-resource",
            "Apply micro-segmentation — no implicit east-west trust between internal services",
        ],
        "references": ["https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-207.pdf"],
    },
    {
        "id": "ARCH-ZT-02",
        "category": "ZERO_TRUST",
        "question": "Are micro-segmentation and per-session authorisation applied to internal service-to-service communication?",
        "rationale": "Flat internal networks mean a single compromised host can reach all services. Micro-segmentation limits blast radius. (Green Ch.5 p.215; Nichols Ch.4)",
        "severity": "High",
        "patterns_to_check": ["microservice", "service-to-service", "internal api", "service mesh", "east-west", "lateral"],
        "mitigations": [
            "Implement a service mesh (Istio, Linkerd) with mTLS for all internal service-to-service traffic",
            "Apply per-service network policies using Kubernetes NetworkPolicy or cloud-native firewall rules",
        ],
        "references": ["https://csrc.nist.gov/publications/detail/sp/800-207/final"],
    },
    # ── Defence in Depth ───────────────────────────────────────────────────────
    {
        "id": "ARCH-DID-01",
        "category": "DEFENCE_IN_DEPTH",
        "question": "Are multiple overlapping security layers implemented (Physical → Perimeter → Network → Host → Application → Data)?",
        "rationale": "Single-layer security fails at one point of compromise. Defence in depth ensures each layer independently limits attacker progression. (Green Ch.1 p.68; Nichols Ch.4 p.103)",
        "severity": "High",
        "patterns_to_check": ["firewall", "perimeter", "network", "web application", "api", "database", "host"],
        "mitigations": [
            "Audit each layer: Physical (access control, CCTV), Perimeter (NGFW, IDS/IPS), Network (VLAN, NAC), Host (EDR, hardening), Application (WAF, SAST), Data (AES-256, DLP)",
            "Ensure controls at each layer are independently effective — no single point where bypass grants full access",
        ],
        "references": ["https://www.nist.gov/cyberframework"],
    },
    {
        "id": "ARCH-DID-02",
        "category": "DEFENCE_IN_DEPTH",
        "question": "Is a DMZ (demilitarised zone) used to isolate public-facing services from the internal network?",
        "rationale": "Without a DMZ, a compromised public-facing server has direct access to internal systems. (Green Ch.5 p.200)",
        "severity": "High",
        "patterns_to_check": ["web server", "api gateway", "load balancer", "public", "internet-facing", "external", "dmz"],
        "mitigations": [
            "Place all public-facing services in a DMZ with separate firewall rules from the internal network",
            "Restrict DMZ-to-internal traffic to the minimum required data flows only",
        ],
        "references": ["https://cheatsheetseries.owasp.org/cheatsheets/Network_Segmentation_Cheat_Sheet.html"],
    },
    # ── Principle of Least Privilege ──────────────────────────────────────────
    {
        "id": "ARCH-POLP-01",
        "category": "LEAST_PRIVILEGE",
        "question": "Are all human and service accounts operating with minimum required privileges — no standing admin rights?",
        "rationale": "Standing admin/root access dramatically amplifies the blast radius of credential compromise. JIT access limits exposure. (Nichols Ch.11 p.309; Green Ch.5 p.101)",
        "severity": "Critical",
        "patterns_to_check": ["admin", "root", "superuser", "administrator", "privileged", "service account", "sysadmin"],
        "mitigations": [
            "Implement PAM (Privileged Access Management) — CyberArk, BeyondTrust, or Vault — for all privileged accounts",
            "Replace standing admin access with JIT (just-in-time) provisioning with automatic expiry",
            "Audit all service account permissions quarterly; right-size to minimum required",
        ],
        "references": ["https://www.cisa.gov/sites/default/files/publications/ESF_SECURING_THE_SOFTWARE_SUPPLY_CHAIN_DEVELOPERS.PDF"],
    },
    {
        "id": "ARCH-POLP-02",
        "category": "LEAST_PRIVILEGE",
        "question": "Is RBAC or ABAC enforced with clearly defined roles mapped to minimum required permissions?",
        "rationale": "Without formal role definitions, permissions accumulate. Quarterly reviews are required to detect privilege creep. (Nichols Ch.11; Green Ch.5 RBAC/ABAC)",
        "severity": "High",
        "patterns_to_check": ["role", "permission", "access control", "rbac", "abac", "user group", "entitlement"],
        "mitigations": [
            "Define RBAC roles from scratch using need-to-know; never clone existing high-privilege roles as templates",
            "Implement ABAC where context (time, location, device) matters for access decisions",
            "Run quarterly permission reviews using IGA (Identity Governance and Administration) tooling",
        ],
        "references": ["https://csrc.nist.gov/publications/detail/sp/800-162/final"],
    },
    # ── Fail Secure ────────────────────────────────────────────────────────────
    {
        "id": "ARCH-FS-01",
        "category": "FAIL_SECURE",
        "question": "Do all systems default to a deny/secure state on failure — no fail-open behaviour?",
        "rationale": "Systems that fail open (allow all on error) trade security for availability. Fail secure is the only acceptable design for security controls. (Nichols Ch.4 p.107)",
        "severity": "Critical",
        "patterns_to_check": ["exception", "error handling", "fallback", "default allow", "catch", "timeout", "connection refused"],
        "mitigations": [
            "Review all exception handlers: on authentication failure, default to deny — never allow on timeout",
            "Test failure modes explicitly in QA: disconnect database, overload auth service — verify system denies access",
            "Document fail-secure behaviour as a security requirement for every component",
        ],
        "references": ["https://owasp.org/www-project-application-security-verification-standard/"],
    },
    # ── Separation of Duties ──────────────────────────────────────────────────
    {
        "id": "ARCH-SOD-01",
        "category": "SEPARATION_OF_DUTIES",
        "question": "Is there enforced separation between those who develop, approve, and deploy to production?",
        "rationale": "A single person who writes, approves, and deploys code can introduce malicious changes without detection. (Nichols Ch.4 p.108; Green Ch.7 DevSecOps)",
        "severity": "High",
        "patterns_to_check": ["deploy", "production", "release", "merge", "ci/cd", "pipeline", "github", "gitlab"],
        "mitigations": [
            "Enforce branch protection: require 2+ approvals from non-authors before merge to main/production branches",
            "Separate deployment credentials from development credentials — developers cannot deploy directly to production",
            "Use OIDC federation for CI/CD to avoid static deployment secrets",
        ],
        "references": ["https://slsa.dev/spec/v1.0/"],
    },
    # ── Security by Design ────────────────────────────────────────────────────
    {
        "id": "ARCH-SBD-01",
        "category": "SECURITY_BY_DESIGN",
        "question": "Is security integrated into the SDLC from requirements — threat modeled before development begins?",
        "rationale": "Retrofitting security after development is 30× more expensive than designing it in. Security requirements must precede code. (Green Ch.7 p.272; Nichols Ch.4 p.103)",
        "severity": "High",
        "patterns_to_check": ["design", "requirements", "user story", "feature", "architecture", "new system", "api", "sdlc"],
        "mitigations": [
            "Add security acceptance criteria to every user story: define what 'secure' looks like before coding",
            "Conduct STRIDE threat model during design phase — before the sprint begins",
            "Include security architect review as a gate before any new component goes to production",
        ],
        "references": ["https://owasp.org/www-project-devsecops-guideline/"],
    },
    {
        "id": "ARCH-SBD-02",
        "category": "SECURITY_BY_DESIGN",
        "question": "Are security requirements (authentication, authorisation, encryption, logging) specified before development?",
        "rationale": "Without defined security requirements, developers implement the feature correctly but insecurely by omission. (Green Ch.7 Secure by Design; Nichols Ch.6)",
        "severity": "Medium",
        "patterns_to_check": ["feature", "new api", "microservice", "component", "module", "service", "integration"],
        "mitigations": [
            "Use a security requirements template covering: AuthN/AuthZ model, data sensitivity, logging events, error handling, cryptography",
            "Reference OWASP ASVS Level 1/2/3 as your security requirements baseline per component risk",
        ],
        "references": ["https://owasp.org/www-project-application-security-verification-standard/"],
    },
    # ── Risk Management ────────────────────────────────────────────────────────
    {
        "id": "ARCH-RISK-01",
        "category": "RISK_MANAGEMENT",
        "question": "Is a formal risk register maintained with residual risk formally accepted by business owners?",
        "rationale": "Without documented risk acceptance, security teams assume responsibility for residual risks that business owners should own. (Nichols Ch.5 p.133; Green Ch.4 p.179)",
        "severity": "Medium",
        "patterns_to_check": ["risk", "residual", "accept", "tolerance", "appetite", "assessment", "compliance"],
        "mitigations": [
            "Maintain a risk register with: risk ID, description, likelihood, impact, inherent score, controls, residual score, owner, acceptance date",
            "Require written risk acceptance from business owners for every residual risk above the organisation's risk tolerance",
            "Review and re-sign risk acceptances annually or after significant architecture changes",
        ],
        "references": ["https://www.iso.org/standard/75652.html"],
    },
    {
        "id": "ARCH-RISK-02",
        "category": "RISK_MANAGEMENT",
        "question": "Are risk treatment decisions (accept/transfer/avoid/mitigate) documented and reviewed periodically?",
        "rationale": "Risk decisions made without documentation become invisible — accepted risks accumulate without review. (Green Ch.4; Nichols Ch.5)",
        "severity": "Medium",
        "patterns_to_check": ["risk treatment", "risk acceptance", "insurance", "third party risk", "vendor risk", "risk decision"],
        "mitigations": [
            "Document every risk treatment decision with rationale, owner, and review date",
            "Review all risk acceptances after significant incidents or architecture changes — prior acceptance may no longer apply",
        ],
        "references": ["https://www.iso.org/standard/75652.html"],
    },
    # ── BCP / DR ───────────────────────────────────────────────────────────────
    {
        "id": "ARCH-BCP-01",
        "category": "BCP_DR",
        "question": "Are RTO and RPO defined for all critical systems, with tested recovery procedures?",
        "rationale": "Untested BCP/DR plans fail when needed most. RTO/RPO must be derived from business requirements, not assumptions. (Nichols Ch.2 p.67; Green Ch.4 BIA)",
        "severity": "High",
        "patterns_to_check": ["database", "critical system", "production", "backup", "availability", "uptime", "sla", "recovery"],
        "mitigations": [
            "Define RTO (max downtime) and RPO (max data loss) for each critical system based on business impact analysis",
            "Test DR procedures at least annually — tabletop exercises do not replace actual failover tests",
            "Maintain runbooks with step-by-step recovery procedures accessible without the failed system",
        ],
        "references": ["https://www.iso.org/standard/75106.html"],
    },
    # ── Asset Classification ───────────────────────────────────────────────────
    {
        "id": "ARCH-ASSET-01",
        "category": "ASSET_CLASSIFICATION",
        "question": "Are all data assets classified by sensitivity (Public/Internal/Confidential/Restricted) with controls enforced per classification?",
        "rationale": "Without data classification, all data receives the same (often insufficient) protection. Classification directs where to invest security controls. (Green Ch.4 Asset Identification; Nichols Ch.5)",
        "severity": "Medium",
        "patterns_to_check": ["pii", "personal data", "confidential", "sensitive", "customer data", "financial", "health data", "proprietary"],
        "mitigations": [
            "Define a data classification taxonomy (typically 3-4 tiers) mapped to specific technical controls per tier",
            "Tag all data stores and API responses with their classification — enforce controls at tag level via policy engine",
            "Apply GDPR Article 32 and sector-specific requirements as minimum controls for personal data",
        ],
        "references": ["https://www.nist.gov/system/files/documents/2022/05/31/SP800-60Vol1Rev1.pdf"],
    },
    # ── Continuous Monitoring / OODA Loop ─────────────────────────────────────
    {
        "id": "ARCH-MON-01",
        "category": "CONTINUOUS_MONITORING",
        "question": "Is continuous security monitoring operational — Observe, Orient, Decide, Act (OODA Loop) applied to threat detection?",
        "rationale": "An architect who cycles the OODA loop faster than an adversary maintains the initiative. Static controls without monitoring fail silently. (Nichols Ch.7 & Ch.12 OODA Loop)",
        "severity": "High",
        "patterns_to_check": ["production", "live", "deployment", "operations", "soc", "siem", "monitoring", "alert"],
        "mitigations": [
            "Deploy SIEM with correlation rules for authentication failures, data access anomalies, and privilege escalation",
            "Define SLAs for detection-to-containment: Critical ≤ 1h, High ≤ 4h, Medium ≤ 24h",
            "Conduct quarterly purple team exercises: test detection capability before an adversary does",
        ],
        "references": ["https://www.nist.gov/cyberframework/framework"],
    },
    # ── Patch Management ──────────────────────────────────────────────────────
    {
        "id": "ARCH-PATCH-01",
        "category": "PATCH_MANAGEMENT",
        "question": "Is a defined patch cadence enforced: Critical ≤72hr, High ≤7 days, Medium/Low ≤30 days?",
        "rationale": "Most breaches exploit known vulnerabilities with available patches. Patching cadence is the difference between protected and exposed. (Nichols Ch.11 p.330)",
        "severity": "High",
        "patterns_to_check": ["patch", "update", "vulnerability", "cve", "library", "dependency", "os", "firmware"],
        "mitigations": [
            "Enforce SLA-based patch management: Critical (CVSS 9+) within 24-72hrs, High within 7 days, Medium/Low within 30 days",
            "Track all unpatched assets with compensating controls documented for any exception beyond SLA",
            "Integrate SCA scanning in CI to flag vulnerable dependencies before they reach production",
        ],
        "references": ["https://www.cisa.gov/known-exploited-vulnerabilities-catalog"],
    },
    # ── Security Architecture Review ──────────────────────────────────────────
    {
        "id": "ARCH-SAR-01",
        "category": "SECURITY_ARCHITECTURE_REVIEW",
        "question": "Is a formal security architecture review (SAR) conducted and documented for all new systems before go-live?",
        "rationale": "Architecture reviews catch design-level flaws that code reviews miss. Cost to fix at design = 1×; cost to fix in production = 100×. (Nichols Ch.4; Green Ch.1)",
        "severity": "High",
        "patterns_to_check": ["new system", "launch", "go-live", "production", "new service", "microservice", "architecture", "design review"],
        "mitigations": [
            "Establish a Security Architecture Review Board (SARB) that gates new systems before production deployment",
            "Use a standardised SAR template: scope, data flows, trust boundaries, STRIDE threats, controls, residual risk",
            "Retain SAR documents for the life of the system — architecture decisions must be traceable",
        ],
        "references": ["https://www.ncsc.gov.uk/collection/cyber-security-design-principles"],
    },
    # ── SABSA / Frameworks ────────────────────────────────────────────────────
    {
        "id": "ARCH-FWRK-01",
        "category": "SECURITY_FRAMEWORKS",
        "question": "Is security architecture aligned to an established framework (SABSA, TOGAF ADM, NIST CSF, ISO 27001) for consistent coverage?",
        "rationale": "Ad-hoc security architectures have coverage gaps. Frameworks provide structured assurance that all domains are addressed. (Green Ch.2 SABSA/TOGAF; Nichols Ch.5)",
        "severity": "Medium",
        "patterns_to_check": ["framework", "governance", "policy", "compliance", "nist", "iso", "architecture program"],
        "mitigations": [
            "Select and adopt one primary framework (SABSA for risk-driven, NIST CSF for US-centric, ISO 27001 for international compliance)",
            "Map all security controls to framework domains — identify gaps where controls are absent",
            "Use SABSA's six-layer matrix (Contextual → Conceptual → Logical → Physical → Component → Operational) to structure architecture outputs",
        ],
        "references": ["https://sabsa.org/sabsa-executive-summary/"],
    },
    # ── MFA Enforcement ───────────────────────────────────────────────────────
    {
        "id": "ARCH-MFA-01",
        "category": "MFA",
        "question": "Is phishing-resistant MFA (FIDO2/WebAuthn, hardware token) enforced for all privileged and remote access?",
        "rationale": "SMS/TOTP MFA is bypassed by real-time phishing attacks. Only phishing-resistant MFA (FIDO2) provides genuine protection. (Nichols Ch.11 p.325)",
        "severity": "Critical",
        "patterns_to_check": ["login", "authentication", "remote access", "vpn", "admin", "privileged", "sso", "identity"],
        "mitigations": [
            "Migrate all privileged and remote access to FIDO2/WebAuthn (passkeys, hardware security keys)",
            "Enforce MFA at IdP level (not just application) — route all authentication through SSO with MFA required",
            "Apply MFA to: VPN, cloud console, email, code repositories, CI/CD systems, and all admin panels",
        ],
        "references": ["https://www.cisa.gov/sites/default/files/2022-10/mfa-fact-sheet-oct22-508c.pdf"],
    },
]
