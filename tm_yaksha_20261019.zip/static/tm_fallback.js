(function () {
  'use strict';

  function qs(selector) { return document.querySelector(selector); }
  function qsa(selector) { return Array.prototype.slice.call(document.querySelectorAll(selector)); }
  function text(value) { return value == null ? '' : String(value); }
  function esc(value) {
    return text(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function toast(message, type) {
    var el = qs('#toast');
    if (!el) return;
    el.textContent = message;
    el.className = 'show ' + (type || '');
    window.clearTimeout(window.__tmFallbackToastTimer);
    window.__tmFallbackToastTimer = window.setTimeout(function () { el.className = ''; }, 3500);
  }

  function setStatus(message, type) {
    var el = qs('#analysis-status');
    if (!el) return;
    el.textContent = message || '';
    el.className = message ? 'analysis-status show ' + (type || 'info') : 'analysis-status';
  }

  function fetchCsrf() {
    return fetch('/api/csrf-token', { cache: 'no-store', credentials: 'same-origin' })
      .then(function (r) {
        if (!r.ok) throw new Error('Unable to prepare secure request token');
        return r.json();
      })
      .then(function (d) {
        if (!d.token) throw new Error('Secure request token missing');
        return d.token;
      });
  }

  function apiFetch(url, method, body) {
    method = (method || 'GET').toUpperCase();
    return fetchCsrf().then(function (token) {
      var headers = { 'X-CSRF-Token': token };
      var opts = { method: method, headers: headers, credentials: 'same-origin' };
      if (body instanceof FormData) {
        opts.body = body;
      } else if (body) {
        headers['Content-Type'] = 'application/json';
        opts.body = JSON.stringify(body);
      }
      return fetch(url, opts);
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (!r.ok) throw new Error((data.error || data.message || r.statusText || 'Request failed') + ' (' + r.status + ')');
        return data;
      });
    });
  }

  function selectedMethods() {
    var checked = qsa('#method-grid input[type="checkbox"]:checked').map(function (box) { return box.value; });
    return checked.length ? checked : ['owasp'];
  }

  function setSelectedMethods(methods) {
    var preset = {
      all: ['owasp', 'owasp_api', 'owasp_llm', 'stride', 'pasta', 'owasp_cloud', 'cis_cloud', 'yaml_rules', 'offline'],
      api_ai: ['owasp_api', 'owasp_llm'],
      cloud_all: ['owasp_cloud', 'cis_cloud'],
      llm: ['owasp_llm']
    };
    var wanted = [];
    var list = Array.isArray(methods) ? methods : [methods];
    list.forEach(function (method) {
      (preset[method] || [method]).forEach(function (value) {
        if (wanted.indexOf(value) === -1) wanted.push(value);
      });
    });
    qsa('#method-grid input[type="checkbox"]').forEach(function (box) {
      box.checked = wanted.indexOf(box.value) !== -1;
    });
  }

  function resetPipeline() {
    for (var i = 0; i <= 6; i++) {
      var dot = qs('#step-' + i);
      var label = qs('#slabel-' + i);
      if (dot) { dot.className = 'step-dot'; dot.textContent = String(i + 1); }
      if (label) label.className = 'step-label';
    }
  }

  function setPipeline(step) {
    for (var i = 0; i <= 6; i++) {
      var dot = qs('#step-' + i);
      var label = qs('#slabel-' + i);
      if (!dot || !label) continue;
      if (i < step) {
        dot.className = 'step-dot done';
        dot.textContent = 'OK';
        label.className = 'step-label done';
      } else if (i === step) {
        dot.className = 'step-dot active';
        dot.textContent = String(i + 1);
        label.className = 'step-label active';
      } else {
        dot.className = 'step-dot';
        dot.textContent = String(i + 1);
        label.className = 'step-label';
      }
    }
  }

  function riskColor(risk) {
    return {
      Critical: '#ef4444',
      High: '#f97316',
      Medium: '#eab308',
      Low: '#22c55e',
      Info: '#3b82f6'
    }[risk] || '#7a90b0';
  }

  var issueFamilies = [
    { key: 'ai', label: 'AI/LLM', short: 'AI', color: '#a78bfa', test: /\b(ai|llm|rag|model|prompt|agent|embedding)\b/ },
    { key: 'api', label: 'API', short: 'API', color: '#38bdf8', test: /\b(api|endpoint|rest|graphql|object level|bola)\b/ },
    { key: 'web', label: 'Web', short: 'WEB', color: '#22c55e', test: /\b(web|owasp|xss|csrf|ssrf|injection|session)\b/ },
    { key: 'cloud', label: 'Cloud', short: 'CLD', color: '#60a5fa', test: /\b(cloud|aws|azure|gcp|kubernetes|container|iam|s3)\b/ },
    { key: 'stride', label: 'STRIDE', short: 'STR', color: '#f59e0b', test: /\b(stride|spoof|tamper|repudiation|information disclosure|denial|privilege)\b/ },
    { key: 'sbom', label: 'SBOM', short: 'SBM', color: '#fb7185', test: /\b(sbom|dependency|component|package|cve|vulnerable)\b/ },
    { key: 'pqc', label: 'PQC', short: 'PQC', color: '#ef4444', test: /\b(pqc|quantum|rsa|ecdsa|ecc|3des|sha-1|md5)\b/ },
    { key: 'compliance', label: 'Compliance', short: 'CMP', color: '#eab308', test: /\b(compliance|control|pci|hipaa|gdpr|soc|nist|cis)\b/ }
  ];

  function issueFamily(c) {
    var id = text(c && (c.id || c.category)).toUpperCase();
    var source = text(c && (c._source || c.methodology)).toLowerCase();
    var name = text(c && (c.name || c.title)).toLowerCase();
    var notes = text(c && (c.notes || c.description)).toLowerCase();
    var all = [id.toLowerCase(), source, name, notes].join(' ');
    if (id.indexOf('AI-') === 0 || id.indexOf('LLM-') === 0) return issueFamilies[0];
    if (id.indexOf('API-') === 0) return issueFamilies[1];
    if (id.indexOf('WEB-') === 0 || /^A0\d/.test(id)) return issueFamilies[2];
    if (id === 'PQC') return issueFamilies[6];
    if (source.indexOf('cis') !== -1 || id.indexOf('CIS') === 0) return issueFamilies[7];
    for (var i = 0; i < issueFamilies.length; i++) {
      if (issueFamilies[i].test.test(all)) return issueFamilies[i];
    }
    return { key: 'design', label: 'Design', short: 'DSN', color: '#00c4a7' };
  }

  function previewList(items, max) {
    var clean = (items || []).filter(Boolean).map(function (item) { return text(item).trim(); }).filter(Boolean);
    if (!clean.length) return '';
    var shown = clean.slice(0, max || 2).join(', ');
    return clean.length > (max || 2) ? shown + ' +' + (clean.length - (max || 2)) : shown;
  }

  var findingTitles = {
    'AI-LLM01': 'Prompt Injection',
    'AI-LLM02': 'Insecure Output Handling',
    'AI-LLM03': 'Training Data and Model Poisoning',
    'AI-LLM04': 'Model Denial of Service',
    'AI-LLM05': 'Supply Chain Vulnerabilities',
    'AI-LLM06': 'Sensitive Information Disclosure',
    'AI-LLM07': 'Insecure Plugin and Tool Design',
    'AI-LLM08': 'Excessive Agency',
    'AI-LLM09': 'Overreliance',
    'AI-LLM10': 'Model Theft',
    'API-API1': 'Broken Object Level Authorization',
    'API-API2': 'Broken Authentication',
    'API-API3': 'Broken Object Property Level Authorization',
    'API-API4': 'Unrestricted Resource Consumption',
    'API-API5': 'Broken Function Level Authorization',
    'API-API6': 'Unrestricted Access to Sensitive Business Flows',
    'API-API7': 'Server Side Request Forgery',
    'API-API8': 'Security Misconfiguration',
    'API-API9': 'Improper Inventory Management',
    'API-API10': 'Unsafe Consumption of APIs',
    'WEB-A01': 'Broken Access Control',
    'WEB-A02': 'Cryptographic Failures',
    'WEB-A03': 'Injection',
    'WEB-A04': 'Insecure Design',
    'WEB-A05': 'Security Misconfiguration',
    'WEB-A06': 'Vulnerable and Outdated Components',
    'WEB-A07': 'Identification and Authentication Failures',
    'WEB-A08': 'Software and Data Integrity Failures',
    'WEB-A09': 'Security Logging and Monitoring Failures',
    'WEB-A10': 'Server-Side Request Forgery'
  };

  function humanizeFindingId(id) {
    var clean = text(id).trim();
    if (!clean) return 'Security Finding';
    if (findingTitles[clean]) return findingTitles[clean];
    return clean
      .replace(/^[A-Z]+-/, '')
      .replace(/_/g, ' ')
      .replace(/-/g, ' ')
      .replace(/\b\w/g, function (ch) { return ch.toUpperCase(); });
  }

  function findingTitle(c) {
    var id = text(c && (c.id || c.category)).trim();
    var name = text(c && (c.name || c.title)).trim();
    if (name && name !== id && !/^[A-Z]+-[A-Z0-9_]+$/.test(name)) return name;
    return humanizeFindingId(id || name);
  }

  function findingSummary(c) {
    var threat = ((c && c.threats) || []).find(function (t) { return t && (t.name || t.description); }) || {};
    return (c && (c.description || c.framework_description || threat.description || threat.name || c.notes)) || '';
  }

  var attackVectorDetails = {
    'AI-LLM01': {
      title: 'Prompt injection through user input, RAG content, or tool output',
      path: [
        'Attacker submits instructions through chat, uploaded documents, retrieved RAG content, or tool responses.',
        'Those instructions are mixed into model context without strict separation from system/developer instructions.',
        'The model may disclose protected context, call tools incorrectly, or bypass intended policy.'
      ],
      verify: [
        'Check every untrusted text source entering the prompt: user message, RAG retrieval, web fetch, tool output, and agent messages.',
        'Confirm retrieved documents are treated as quoted data, not executable instructions.'
      ]
    },
    'AI-LLM02': {
      title: 'Unsafe model output passed into browser, SQL, shell, code, or downstream tools',
      path: [
        'Attacker manipulates the model into producing unsafe HTML, SQL, shell commands, file paths, URLs, or tool parameters.',
        'Application code trusts that output and renders or executes it without validation.'
      ],
      verify: ['Validate every model-output sink with schemas, allowlists, escaping, parameterization, and sandboxing.']
    },
    'AI-LLM03': {
      title: 'Poisoned training data, RAG documents, or vector-store entries influence model behavior',
      path: [
        'Attacker gets malicious content into ingestion or training paths.',
        'Retrieval or training promotes poisoned content into future model context.'
      ],
      verify: ['Review vector database write access, document provenance, tenant isolation, ingestion scanning, and retrieval anomaly monitoring.']
    },
    'API-API1': {
      title: 'Broken object-level authorization through ID or object reference manipulation',
      path: [
        'Attacker changes object IDs, tenant IDs, file keys, or record identifiers in API calls.',
        'The API checks login but not ownership of the requested object.'
      ],
      verify: ['Check every endpoint accepting IDs, object keys, tenant IDs, or bulk object lists for server-side per-object authorization.']
    }
  };

  function attackVectorDetail(c) {
    var id = text(c && (c.id || c.category)).trim();
    var detail = attackVectorDetails[id];
    var vectors = ((c && c.threats) || []).map(function (t) { return t && t.attack_vector; }).filter(Boolean);
    if (!detail && !vectors.length) return '';
    var title = detail ? detail.title : vectors[0];
    var pathItems = detail ? detail.path : vectors.map(function (v) { return 'Detected vector signal: ' + v; });
    var verifyItems = detail ? detail.verify : [];
    var html = '<div class="attack-vector-box"><div class="attack-vector-title">Attack Vector</div>';
    html += '<div class="attack-vector-text">' + esc(title) + '</div>';
    if (pathItems.length) html += '<ul class="attack-vector-list">' + pathItems.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>';
    if (verifyItems.length) html += '<div class="attack-vector-title" style="margin-top:10px;color:var(--orange)">What to verify</div><ul class="attack-vector-list">' + verifyItems.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>';
    return html + '</div>';
  }

  function revealReportWhenStacked() {
    if (window.innerWidth > 900) return;
    var target = qs('#report-content') || qs('.panel-right');
    if (!target) return;
    window.setTimeout(function () {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
  }

  function renderFallbackReport(report) {
    var empty = qs('#empty-state');
    var content = qs('#report-content');
    if (empty) empty.style.display = 'none';
    if (!content) return;
    var categories = report.categories || [];
    var recommendations = report.recommendations || [];
    var risk = report.aggregate_risk || report.overall_risk || 'Info';
    var color = riskColor(risk);
    var html = '';
    html += '<div class="report-header">';
    html += '<h2>' + esc(report.title || 'Security Review') + '</h2>';
    html += '<div class="meta">' + esc(report.methodology_label || report.methodology || 'Offline security review') + '</div>';
    html += '</div>';
    html += '<div class="risk-banner" style="border-color:' + color + '33;background:' + color + '08;color:' + color + '">';
    html += '<div><div class="risk-count">' + esc(categories.length) + '</div><div class="risk-label">Issues Identified</div>';
    html += '<div class="risk-meta">Fallback renderer active</div></div></div>';
    html += '<div class="summary-box">' + esc(report.summary || 'Security review complete.') + '</div>';
    html += '<div class="section-title">Findings</div><div class="risk-cards">';
    categories.slice(0, 40).forEach(function (c, index) {
      var cRisk = c.risk || c.severity || 'Info';
      var cColor = riskColor(cRisk);
      var family = issueFamily(c);
      var cTitle = findingTitle(c);
      var cSummary = findingSummary(c);
      var cAttackVector = attackVectorDetail(c);
      var components = (c.affected_components || []).filter(Boolean);
      var componentPreview = previewList(components, 2);
      var threatCount = (c.threats || []).length;
      var mitigationCount = (c.mitigations || []).length;
      var scopePills = [];
      if (componentPreview) scopePills.push(['Scope', componentPreview]);
      if (c._source || c.methodology) scopePills.push(['Source', c._source || c.methodology]);
      if (threatCount) scopePills.push(['Threats', String(threatCount)]);
      if (mitigationCount) scopePills.push(['Controls', String(mitigationCount)]);
      html += '<div class="risk-card issue-' + esc(family.key) + '" style="--issue-accent:' + family.color + ';--severity-color:' + cColor + '">';
      html += '<div class="risk-card-header">';
      html += '<span class="issue-lane"><span class="issue-lane-code">' + esc(family.short) + '</span><span class="issue-lane-label">' + esc(family.label) + '</span></span>';
      html += '<span class="risk-main"><span class="risk-title-row"><span class="risk-name">' + esc(cTitle) + '</span><span class="risk-family">' + esc(family.label) + '</span></span>';
      if (cSummary) html += '<span class="risk-summary">' + esc(cSummary) + '</span>';
      html += '<span class="risk-fingerprint"><span class="risk-number">#' + String(index + 1).padStart(2, '0') + '</span>';
      html += '<span class="risk-id">' + esc(c.id || c.category || family.key.toUpperCase()) + '</span>';
      html += '<span class="issue-metric">Threats <strong>' + esc(threatCount) + '</strong></span>';
      html += '<span class="issue-metric">Controls <strong>' + esc(mitigationCount) + '</strong></span>';
      if (componentPreview) html += '<span class="issue-metric">Scope <strong>' + esc(componentPreview) + '</strong></span>';
      html += '</span>';
      html += '</span>';
      html += '<span class="risk-meta-stack"><span class="risk-chip" style="color:' + cColor + ';border-color:' + cColor + '33;background:' + cColor + '12">' + esc(cRisk) + '</span></span>';
      html += '</div><div class="risk-card-body open">';
      if (scopePills.length) {
        html += '<div class="issue-scope-strip">' + scopePills.map(function (pill) {
          return '<span class="scope-pill">' + esc(pill[0]) + ' <strong>' + esc(pill[1]) + '</strong></span>';
        }).join('') + '</div>';
      }
      if (cSummary) html += '<div class="finding-overview">' + esc(cSummary) + '</div>';
      html += cAttackVector;
      html += '<div class="threat-row">' + esc(c.description || c.finding || c.detail || '') + '</div>';
      ((c.threats || []).slice(0, 4)).forEach(function (t) {
        html += '<div class="threat-ticket"><div class="threat-header"><span class="threat-tag">THREAT</span><span class="threat-name">' + esc(t.name || 'Threat') + '</span></div>';
        html += '<div class="threat-row">' + esc(t.description || '') + '</div></div>';
      });
      if (c.mitigation || c.remediation) html += '<div class="mit-item"><span>' + esc(c.mitigation || c.remediation) + '</span></div>';
      html += '</div></div>';
    });
    html += '</div>';
    if (recommendations.length) {
      html += '<div class="recs-box"><div class="recs-title">Recommendations</div><ol class="recs-list">';
      recommendations.slice(0, 25).forEach(function (rec) { html += '<li>' + esc(rec) + '</li>'; });
      html += '</ol></div>';
    }
    content.innerHTML = html;
    content.style.display = '';
    revealReportWhenStacked();
  }

  function runAnalyze() {
    var btn = qs('#btn-analyze');
    if (btn && btn.disabled) return;
    var apiKey = (qs('#inp-key') && qs('#inp-key').value || '').trim();
    var arch = (qs('#inp-arch') && qs('#inp-arch').value || '').trim();
    var title = (qs('#inp-title') && qs('#inp-title').value || '').trim() || 'Security Review';
    var fileInput = qs('#file-inp');
    var files = fileInput && fileInput.files ? Array.prototype.slice.call(fileInput.files) : [];
    var genDiags = !!(qs('#tog-diags') && qs('#tog-diags').checked);

    if (!arch && !files.length) {
      toast('Architecture description required.', 'error');
      setStatus('Architecture description required before starting review.', 'error');
      return;
    }

    if (btn) { btn.disabled = true; btn.className += ' loading'; }
    if (qs('#empty-state')) qs('#empty-state').style.display = 'none';
    if (qs('#report-content')) qs('#report-content').style.display = 'none';
    resetPipeline();
    setPipeline(0);
    setStatus(apiKey ? 'Submitting security review request...' : 'Offline mode: selected patterns will run locally.', 'info');
    toast(apiKey ? 'Initiating security review...' : 'Running offline security review...', 'info');

    var body;
    if (files.length) {
      body = new FormData();
      body.append('title', title);
      body.append('api_key', apiKey);
      body.append('architecture', arch);
      selectedMethods().forEach(function (m) { body.append('methodology', m); });
      body.append('generate_diagrams', genDiags ? 'true' : 'false');
      files.forEach(function (file) { body.append('file', file); });
    } else {
      body = {
        title: title,
        api_key: apiKey,
        architecture: arch,
        methodology: selectedMethods(),
        generate_diagrams: genDiags
      };
    }

    apiFetch('/api/analyze/stream', 'POST', body).then(function (jobData) {
      setStatus('Review job started. Streaming analysis progress...', 'info');
      return new Promise(function (resolve, reject) {
        var es = new EventSource('/api/analyze/stream/' + encodeURIComponent(jobData.job_id));
        es.onmessage = function (event) {
          var evt;
          try { evt = JSON.parse(event.data); } catch (e) { return; }
          if (evt.event === 'step') {
            setPipeline(Math.min(6, ({ parallel_start: 1, owasp: 2, owasp_llm: 2, owasp_api: 3, stride: 3, pasta: 3, owasp_cloud: 4, cis_cloud: 4, offline: 4, diagrams: 5 })[evt.step] || 1));
            setStatus(evt.label || 'Running analysis...', evt.status === 'error' ? 'error' : 'info');
          } else if (evt.event === 'result') {
            es.close();
            setPipeline(6);
            renderFallbackReport(evt.report || {});
            setStatus(window.innerWidth <= 900 ? 'Security review complete. Opening the report below...' : 'Security review complete. Report rendered on the right.', 'success');
            toast('Security review complete.', 'success');
            resolve();
          } else if (evt.event === 'error') {
            es.close();
            reject(new Error(evt.message || 'Analysis failed'));
          }
        };
        es.onerror = function () {
          es.close();
          reject(new Error('Stream connection lost'));
        };
      });
    }).catch(function (error) {
      resetPipeline();
      setStatus('Error: ' + error.message, 'error');
      toast('Error: ' + error.message, 'error');
    }).then(function () {
      if (btn) {
        btn.disabled = false;
        btn.className = btn.className.replace(/\s*loading/g, '');
      }
    });
  }

  function runDiagram() {
    var apiKey = (qs('#inp-key') && qs('#inp-key').value || '').trim();
    var arch = (qs('#inp-arch') && qs('#inp-arch').value || '').trim();
    var title = (qs('#inp-title') && qs('#inp-title').value || '').trim() || 'Architecture Diagram';
    if (!arch) {
      toast('Architecture description required.', 'error');
      setStatus('Architecture description required before generating diagram.', 'error');
      return;
    }
    setStatus('Generating architecture diagram from your input...', 'info');
    apiFetch('/api/diagram/architecture', 'POST', { title: title, api_key: apiKey, architecture: arch })
      .then(function (data) {
        var content = qs('#report-content');
        if (qs('#empty-state')) qs('#empty-state').style.display = 'none';
        if (content) {
          content.style.display = '';
          content.innerHTML = '<div class="report-header"><h2>' + esc(title) + '</h2><div class="meta">Architecture Diagram</div></div><pre class="diagram-code" style="display:block">' + esc((data.diagrams && data.diagrams.architecture) || data.diagram || '') + '</pre>';
        }
        setStatus('Architecture diagram generated.', 'success');
        toast('Architecture diagram generated.', 'success');
      })
      .catch(function (error) {
        setStatus('Diagram error: ' + error.message, 'error');
        toast('Diagram error: ' + error.message, 'error');
      });
  }

  var templates = {
    api: {
      app: 'E-commerce platform with REST API backend and React SPA frontend.',
      arch: 'React SPA -> API Gateway (AWS) -> Node.js microservices (auth-svc, product-svc, order-svc) -> PostgreSQL + Redis. Services communicate via internal REST. JWT auth with refresh tokens stored in HttpOnly cookies.',
      method: 'all'
    },
    cloud: {
      app: 'Multi-tenant SaaS platform deployed on AWS with customer data isolation.',
      arch: 'CloudFront CDN -> ALB -> ECS Fargate containers -> RDS Aurora multi-tenant database + S3 per-tenant buckets. IAM roles per service. Secrets in AWS Secrets Manager. VPC with private subnets. CloudTrail logging enabled.',
      method: 'cloud_all'
    },
    llm: {
      app: 'AI-powered document analysis assistant with RAG pipeline and tool-use capabilities.',
      arch: 'React frontend -> FastAPI backend -> LLM agent -> vector database + PostgreSQL. Agent can call web search, code execution, and file read tools. User documents are uploaded to object storage, chunked, and embedded on ingest.',
      method: 'owasp_llm'
    }
  };

  function fillUseCase(key) {
    var tpl = templates[key];
    if (!tpl) return;
    if (qs('#inp-title')) qs('#inp-title').value = tpl.app;
    if (qs('#inp-arch')) qs('#inp-arch').value = tpl.arch;
    setSelectedMethods(tpl.method);
    qsa('.nav-dropdown').forEach(function (d) { d.className = d.className.replace(/\s*open/g, ''); });
    toast('Template loaded - review and click Analyze.', 'info');
  }

  function toggleNav(id, event) {
    if (event && event.stopPropagation) event.stopPropagation();
    var target = qs('#nav-' + id);
    if (!target) return;
    var isOpen = target.className.indexOf('open') !== -1;
    qsa('.nav-dropdown').forEach(function (d) { d.className = d.className.replace(/\s*open/g, ''); });
    if (!isOpen) target.className += ' open';
  }

  function attachFallback() {
    if (typeof window.doAnalyze === 'function' && window.doAnalyze !== runAnalyze) return;
    window.doAnalyze = runAnalyze;
    window.generateArchitectureDiagram = runDiagram;
    window.fillUseCase = fillUseCase;
    window.toggleNav = toggleNav;
    var analyze = qs('#btn-analyze');
    var diagram = qs('#btn-arch-diagram');
    var form = qs('#review-form');
    if (form && !form.__tmFallbackBound) {
      form.__tmFallbackBound = true;
      form.addEventListener('submit', function (event) {
        event.preventDefault();
        runAnalyze();
      });
    }
    if (analyze && !analyze.__tmFallbackBound) {
      analyze.__tmFallbackBound = true;
      analyze.addEventListener('click', function (event) {
        event.preventDefault();
        runAnalyze();
      });
    }
    if (diagram && !diagram.__tmFallbackBound) {
      diagram.__tmFallbackBound = true;
      diagram.addEventListener('click', function (event) {
        event.preventDefault();
        runDiagram();
      });
    }
    document.addEventListener('click', function () {
      qsa('.nav-dropdown').forEach(function (d) { d.className = d.className.replace(/\s*open/g, ''); });
    });
    document.documentElement.setAttribute('data-tm-fallback', 'active');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attachFallback);
  } else {
    attachFallback();
  }
}());
