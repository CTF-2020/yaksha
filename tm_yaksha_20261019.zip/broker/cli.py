"""Standalone broker entry point.

Lets the broker run as a separate process next to the internal repos (the case
the architecture is designed for: source can't leave the network, but a security
team still needs central visibility). Two output modes:

  local   - save the report straight into this host's ~/.tm_reports via the app
            (use when the broker shares a host/volume with the TM server)
  remote  - POST the finished report to a TM server's /api/v1/sast/import using
            a shared secret (use when the broker is network-segregated)

Usage:
  python -m broker.cli scan <path-or-git-url> [--name NAME] [--branch B]
         [--severity Critical|High|Medium|Low|Info]
         [--server https://tm.internal --token <secret>]   # remote mode

Exit codes: 0 ok (no findings), 1 ok (findings present), 2 error.
"""
from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request

from . import config, mapper, scanner


def _push_remote(report: dict, server: str, token: str) -> str:
    base = server.rstrip("/")
    # Non-GET requests need a CSRF token; fetch the freely-available one first.
    with urllib.request.urlopen(f"{base}/api/csrf-token", timeout=30) as resp:
        csrf = json.loads(resp.read()).get("token", "")
    req = urllib.request.Request(
        f"{base}/api/v1/sast/import",
        data=json.dumps(report).encode("utf-8"),
        headers={"Content-Type": "application/json", "X-CSRF-Token": csrf,
                 "X-Broker-Token": token},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read()).get("id", "")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="broker.cli", description="SAST broker scanner.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sc = sub.add_parser("scan", help="Scan a repo and emit/push a report.")
    sc.add_argument("target", help="Local path or git URL")
    sc.add_argument("--name", default="", help="Display name (defaults to the target)")
    sc.add_argument("--branch", default="", help="Git branch")
    sc.add_argument("--severity", default="Low", choices=list(config.SEVERITIES))
    sc.add_argument("--server", default="", help="Remote TM server base URL (remote mode)")
    sc.add_argument("--token", default=config.IMPORT_TOKEN,
                    help="Shared secret for /api/v1/sast/import (remote mode)")
    args = ap.parse_args(argv)

    repo = {
        "id": config.slugify(args.name or args.target),
        "name": args.name or args.target,
        "url": args.target,
        "branch": args.branch,
    }
    try:
        scan_root, meta = scanner.prepare_workspace(repo, progress=lambda m: print(m, file=sys.stderr))
        findings = scanner.run_scan(scan_root, args.severity)
    except scanner.ScanError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    report = mapper.findings_to_report(findings, repo, meta, args.severity)

    if args.server:
        if not args.token:
            print("ERROR: --token (or TM_BROKER_TOKEN) required for remote mode", file=sys.stderr)
            return 2
        try:
            rid = _push_remote(report, args.server, args.token)
        except (urllib.error.URLError, urllib.error.HTTPError) as exc:
            print(f"ERROR: push failed: {exc}", file=sys.stderr)
            return 2
        print(f"Pushed report {rid} to {args.server} ({len(findings)} finding(s))")
    else:
        # Local save through the host app's report store.
        import app as tm_app
        rid = tm_app._save_report(report, report["title"])
        print(f"Saved report {rid} locally ({len(findings)} finding(s))")

    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
