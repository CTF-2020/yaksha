"""design_gap_agenda.py — per-finding worklist for the open design-gap backlog.

verdict_tracking.design_debt_summary() already tracks the AGGREGATE "design
debt" trend (open count, oldest age, burn-down) -- but there was no way to see
*which* design gaps make up that backlog, or what to actually do about each
one. This module is the read-only, per-finding counterpart.

Each open design_gap finding (a threat the model anticipated but that no scan
has yet confirmed or cleared -- see correlator/model.py's Verdict docstring)
is aged against its SLA (verdict_tracking's own 30-day window for this
verdict) and enriched with whether the rule catalog has ANY known detection
rule for its CWE (rules_catalog.related). That answers the operator's actual
next question: is this unconfirmed because nothing scans for it (write a
detection rule, or schedule a manual review), or because a rule exists and
the scanner just hasn't reached it yet (check scan scope/reachability, or
re-run)? A design_gap finding never qualifies for canary.py's regression
replay -- that module only generates cases for the two PROVEN verdicts -- so
"what would resolve this" needs its own answer instead of just linking there.

Same read pipeline as triage.py: report_db.search_findings for the live,
cross-report finding set, suppressions-filtered so a risk-accepted design gap
doesn't show up asking for action nobody wants taken, ownership-annotated so
each item can be routed. No new storage.
"""
from __future__ import annotations

import time

import ownership
import report_db
import rules_catalog
import suppressions
import verdict_tracking
from suppressions.engine import matches_row

_DAY = 86400.0


def _next_step(cwe: str) -> tuple[str, list[dict]]:
    cwes = [c.strip() for c in (cwe or "").split(",") if c.strip()]
    rules = rules_catalog.related(cwes, limit=3)
    if rules:
        return "rule_exists", rules
    return "no_rule", []


_NEXT_STEP_LABEL = {
    "rule_exists": "Detection rule(s) exist for this CWE -- verify scan scope/"
                   "reachability, or re-run the scanner.",
    "no_rule": "No cataloged detection rule matches this CWE -- write a "
               "custom rule or schedule a manual review.",
}


def _rows(now: float) -> list[dict]:
    rows = report_db.search_findings(verdict="design_gap", limit=2000, include_sast=True)
    if not rows:
        return []

    active_supps = suppressions.active_suppressions(suppressions.load_suppressions())
    if active_supps:
        rows = [r for r in rows if not any(matches_row(s, r) for s in active_supps)]
    if not rows:
        return []

    ownership.annotate_rows(rows)
    since = verdict_tracking.since_map([r.get("fingerprint") for r in rows])
    sla_days = verdict_tracking.sla_days_for("design_gap")

    out = []
    for r in rows:
        fp = r.get("fingerprint") or ""
        started = since.get(fp) or r.get("created_at") or now
        age_days = round((now - started) / _DAY, 1)
        action, related_rules = _next_step(r.get("cwe") or "")
        out.append({
            **r,
            "age_days": age_days,
            "sla_days": sla_days,
            "overdue": age_days > sla_days,
            "next_step": action,
            "next_step_label": _NEXT_STEP_LABEL[action],
            "related_rules": related_rules,
        })
    return out


def agenda(limit: int = 100, now: float | None = None) -> dict:
    """Open design-gap findings, oldest (most overdue) first, each carrying a
    concrete suggested next validation step."""
    at = now if now is not None else time.time()
    rows = _rows(at)
    rows.sort(key=lambda r: -r["age_days"])

    by_next_step = {"rule_exists": 0, "no_rule": 0}
    for r in rows:
        by_next_step[r["next_step"]] = by_next_step.get(r["next_step"], 0) + 1

    return {
        "total": len(rows),
        "overdue": sum(1 for r in rows if r["overdue"]),
        "by_next_step": by_next_step,
        "items": rows[:max(1, min(limit, 500))],
    }
