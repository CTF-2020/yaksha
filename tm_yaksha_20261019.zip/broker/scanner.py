"""Repository access and scan-engine invocation.

The broker reaches a repo two ways:
  * a local path  -> scanned in place (read-only walk; nothing is mutated)
  * a git URL     -> shallow-cloned / refreshed into a private workspace

The scan engine is run as a subprocess with list arguments (never a shell),
a hard timeout, and git's interactive prompt disabled, so a hostile repo URL
or a hanging clone cannot wedge or escalate inside the server process.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

from . import config, github

log = logging.getLogger(__name__)


class ScanError(RuntimeError):
    """Raised when workspace prep or the scan engine fails."""


_GIT_SCHEMES = {"https", "http", "ssh", "git", "file"}
_SCP_LIKE = ("git@", "ssh://")
# URL userinfo (e.g. the injected ``x-access-token:<tok>@`` clone credential).
_CRED_RE = re.compile(r"(https?://)[^/@\s]*@")


def _redact(text: str) -> str:
    """Strip URL userinfo from git output before it enters an error/log.

    Modern git already redacts credentials in transport errors, but the "token
    never appears in a job log" guarantee must be enforced by us, not left to the
    host's git version or the particular error path.
    """
    return _CRED_RE.sub(r"\1***@", text or "")


def looks_like_git_url(url: str) -> bool:
    """True for git URLs (https/ssh/git/file or scp-like git@host:path)."""
    url = (url or "").strip()
    if any(url.startswith(p) for p in _SCP_LIKE):
        return True
    parsed = urlparse(url)
    return parsed.scheme in _GIT_SCHEMES and bool(parsed.netloc or parsed.path)


def _url_scheme_host(url: str) -> tuple[str, str]:
    """Best-effort (scheme, host) for a git URL, incl. scp-like git@host:path."""
    u = (url or "").strip()
    if any(u.startswith(p) for p in _SCP_LIKE) and not u.startswith("ssh://"):
        host = u.split("@", 1)[1].split(":", 1)[0].lower() if "@" in u else ""
        return "ssh", host
    parsed = urlparse(u)
    return (parsed.scheme or "").lower(), (parsed.hostname or "").lower()


def check_clone_policy(url: str) -> None:
    """Enforce the configured clone scheme/host allowlist; raise if disallowed.

    file:// (local-path read) and cleartext http are off unless explicitly
    enabled, and an optional host allowlist constrains which git hosts may be
    cloned. SSH/git/https to any host stay allowed by default.
    """
    scheme, host = _url_scheme_host(url)
    if scheme == "file" and not config.ALLOW_FILE_SCHEME:
        raise ScanError("file:// clones are disabled (set TM_BROKER_ALLOW_FILE=1 to allow)")
    if scheme == "http" and not config.ALLOW_HTTP_SCHEME:
        raise ScanError("cleartext http clones are disabled (set TM_BROKER_ALLOW_HTTP=1 to allow)")
    if config.ALLOWED_GIT_HOSTS and host and host not in config.ALLOWED_GIT_HOSTS:
        raise ScanError(f"git host not in allowlist: {host}")


def validate_remote(url: str, token: str = "", branch: str = "") -> str | None:
    """Pre-flight a git repo registration: reachable, authenticated, and (when
    given) the branch exists. Returns a redacted error message, or None if OK.

    Runs `git ls-remote --heads` — no clone, no working tree — so a bad URL,
    missing token, or mistyped branch fails at registration time in the
    dashboard instead of at the first scan (where it surfaces minutes later as
    a failed job). Credential userinfo never appears in the returned message:
    _run_git redacts stderr before it reaches the ScanError.
    """
    try:
        check_clone_policy(url)
        authed = github.authed_clone_url(url, token)
        out = _run_git(["ls-remote", "--heads", "--", authed]
                       + ([branch] if branch else []))
    except ScanError as exc:
        return str(exc)
    if branch and not out.strip():
        return f'branch "{branch}" not found on the remote'
    return None


def _git_env() -> dict:
    env = dict(os.environ)
    env["GIT_TERMINAL_PROMPT"] = "0"           # never block on credential prompts
    env["GIT_ASKPASS"] = env.get("GIT_ASKPASS", "echo")
    env.setdefault("GCM_INTERACTIVE", "never")
    return env


def _run_git(args: list[str], cwd: str | None = None) -> str:
    cmd_logged = _redact(" ".join(["git", *args]))
    started = time.monotonic()
    try:
        proc = subprocess.run(
            ["git", *args],
            cwd=cwd,
            env=_git_env(),
            capture_output=True,
            text=True,
            timeout=config.CLONE_TIMEOUT,
        )
    except FileNotFoundError as exc:  # pragma: no cover - git missing
        log.error("process failed to start: %s (cwd=%s)", cmd_logged, cwd)
        raise ScanError("git executable not found on the broker host") from exc
    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - started
        log.warning("process timed out after %.1fs: %s (cwd=%s)", elapsed, cmd_logged, cwd)
        raise ScanError(f"git {args[0]} timed out after {config.CLONE_TIMEOUT}s") from exc
    elapsed = time.monotonic() - started
    if proc.returncode != 0:
        detail = _redact(proc.stderr or proc.stdout or "").strip().splitlines()
        log.warning("process exited %d in %.1fs: %s (cwd=%s)",
                    proc.returncode, elapsed, cmd_logged, cwd)
        raise ScanError(f"git {args[0]} failed: {detail[-1] if detail else 'unknown error'}")
    log.info("process exited 0 in %.1fs: %s (cwd=%s)", elapsed, cmd_logged, cwd)
    return proc.stdout.strip()


def prepare_workspace(repo: dict, progress=None, ref: str | None = None) -> tuple[Path, dict]:
    """Return (scan_root, source_meta) for a registered repo.

    For local repos the path is used in place. For git repos the working tree is
    shallow-cloned on first use and hard-refreshed on subsequent scans. The `--`
    separator keeps a URL from ever being parsed as a git option.

    `ref` lets a webhook scan an exact point in history — typically a pull
    request's `refs/pull/<n>/head`, so a fork PR is fetched from the trusted base
    repo rather than the contributor's fork. When a GitHub token is configured it
    is injected into the https clone URL for private repos; the token is only ever
    passed as a git argument, never emitted to the progress log.
    """
    def emit(msg):
        if progress:
            progress(msg)

    url = (repo.get("url") or "").strip()
    branch = (repo.get("branch") or "").strip()

    if ref is not None and not github.is_valid_ref(ref):
        raise ScanError(f"refusing to fetch unsafe ref: {ref!r}")

    if not looks_like_git_url(url):
        path = Path(url)
        if not path.exists() or not path.is_dir():
            raise ScanError(f"local repo path does not exist or is not a directory: {url}")
        emit(f"Using local working tree at {path}")
        return path, {"source": "local", "path": str(path), **_local_meta(path)}

    check_clone_policy(url)
    token = repo.get("github_token") or config.GITHUB_TOKEN
    clone_url = github.authed_clone_url(url, token)   # never logged
    dest = config.WORKSPACE_DIR / repo["id"]

    if (dest / ".git").exists():
        emit("Refreshing existing clone")
        if ref:
            emit(f"Fetching {ref}")
            _run_git(["-C", str(dest), "fetch", "--depth", "1", "--force", "--", clone_url, ref])
            _run_git(["-C", str(dest), "reset", "--hard", "FETCH_HEAD"])
        else:
            _run_git(["-C", str(dest), "fetch", "--depth", "1", "--prune", "--", clone_url]
                     + ([branch] if branch else []))
            _run_git(["-C", str(dest), "reset", "--hard", "FETCH_HEAD"])
    else:
        if dest.exists():
            shutil.rmtree(dest, ignore_errors=True)
        emit(f"Cloning {url}")
        args = ["clone", "--depth", "1", "--single-branch"]
        if branch and not ref:
            args += ["--branch", branch]
        _run_git(args + ["--", clone_url, str(dest)])
        if ref:
            emit(f"Fetching {ref}")
            _run_git(["-C", str(dest), "fetch", "--depth", "1", "--force", "--", clone_url, ref])
            _run_git(["-C", str(dest), "reset", "--hard", "FETCH_HEAD"])

    gc_workspace(dest)
    scanned_ref = ref or branch or "(default)"
    return dest, {"source": "git", "url": url, "branch": branch or "(default)",
                  "scanned_ref": scanned_ref, **_local_meta(dest)}


def gc_workspace(dest: Path) -> None:
    """Best-effort `git gc --auto` so a repeatedly refreshed clone stops growing."""
    if not (Path(dest) / ".git").exists():
        return
    try:
        _run_git(["-C", str(dest), "gc", "--auto"])
    except ScanError:
        pass


def _local_meta(path: Path) -> dict:
    """Best-effort commit metadata; absent for non-git working trees."""
    if not (path / ".git").exists():
        return {}
    try:
        commit = _run_git(["-C", str(path), "rev-parse", "--short", "HEAD"])
        subject = _run_git(["-C", str(path), "log", "-1", "--pretty=%s"])
        return {"commit": commit, "commit_subject": subject[:120]}
    except ScanError:
        return {}


def run_scan(scan_root: Path, severity: str = "Low") -> list[dict]:
    """Invoke the scan engine over `scan_root` and return its findings list.

    The engine emits {"target","count","findings":[...]} on stdout and uses
    exit code 1 to mean "findings present" (not an error), 2 for usage errors.
    """
    if severity not in config.SEVERITY_ORDER:
        severity = "Low"
    if not config.SCANNER_PATH.exists():
        raise ScanError(f"scan engine not found: {config.SCANNER_PATH} "
                        "(set TM_BROKER_SCANNER)")

    cmd = [config.SCANNER_PYTHON, str(config.SCANNER_PATH), str(scan_root),
           "--format", "json", "--severity", severity]
    if config.SCANNER_RULES:
        cmd += ["--rules", config.SCANNER_RULES]

    code, stdout, stderr = _exec_capped(cmd, config.SCAN_TIMEOUT, config.MAX_SCAN_OUTPUT)
    if code == 2:
        raise ScanError(f"scan engine error: {stderr.strip()[:300]}")
    try:
        payload = json.loads(stdout or "{}")
    except ValueError as exc:
        raise ScanError("scan engine produced non-JSON output "
                        "(possibly truncated at the output cap)") from exc

    findings = payload.get("findings", [])
    if not isinstance(findings, list):
        raise ScanError("scan engine output missing a findings list")
    if len(findings) > config.MAX_FINDINGS:
        findings = findings[:config.MAX_FINDINGS]
    _attach_code_context(scan_root, findings)
    return findings


# Lines of source shown on each side of the flagged line, so a finding carries
# the vulnerable code in context — not just the single matched line.
_CONTEXT_RADIUS = 3
_MAX_LINE_LEN = 200
# Don't re-read the same file from disk more than this many times per scan.
_context_cache: dict = {}


def _attach_code_context(scan_root: Path, findings: list[dict]) -> None:
    """Add a `code_context` excerpt (numbered lines around the hit) to each finding.

    Best-effort and read-only: any unreadable/oversized file is simply skipped,
    leaving the engine's single-line `snippet` as the fallback. Paths are resolved
    strictly under scan_root so a crafted finding path cannot read outside the
    workspace.
    """
    root = Path(scan_root).resolve()
    cache: dict = {}
    for f in findings:
        rel = f.get("file")
        line = f.get("line")
        if not rel or not isinstance(line, int) or line < 1:
            continue
        try:
            target = (root / rel).resolve()
            target.relative_to(root)          # reject path escapes
        except (ValueError, OSError):
            continue
        lines = cache.get(str(target))
        if lines is None:
            try:
                if target.stat().st_size > 2_000_000:
                    continue
                lines = target.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            cache[str(target)] = lines
        start = max(1, line - _CONTEXT_RADIUS)
        end = min(len(lines), line + _CONTEXT_RADIUS)
        out = []
        for n in range(start, end + 1):
            marker = "→" if n == line else " "   # → marks the flagged line
            text = lines[n - 1][:_MAX_LINE_LEN]
            out.append(f"{marker} {n:>5} | {text}")
        if out:
            f["code_context"] = "\n".join(out)


def _exec_capped(cmd: list[str], timeout: int, max_bytes: int,
                 cwd: str | None = None) -> tuple[int, str, str]:
    """Run a subprocess, draining stdout/stderr with a byte cap.

    A runaway child can neither exhaust memory (we stop *keeping* output past the
    cap) nor deadlock on a full pipe (we keep *reading* and discard the overflow).
    Returns (returncode, stdout_text, stderr_text).
    """
    cmd_logged = _redact(" ".join(cmd))
    started = time.monotonic()
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            cwd=cwd)
    out, err = bytearray(), bytearray()

    def drain(stream, buf: bytearray, cap: int) -> None:
        try:
            while True:
                chunk = stream.read(65536)
                if not chunk:
                    break
                if len(buf) < cap:
                    buf.extend(chunk[: cap - len(buf)])
                # past the cap: keep reading, discard, so the child never blocks
        finally:
            try:
                stream.close()
            except OSError:
                pass

    t_out = threading.Thread(target=drain, args=(proc.stdout, out, max_bytes), daemon=True)
    t_err = threading.Thread(target=drain, args=(proc.stderr, err, 1 << 20), daemon=True)
    t_out.start()
    t_err.start()
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        proc.kill()
        proc.wait()
        t_out.join(5)
        t_err.join(5)
        elapsed = time.monotonic() - started
        log.warning("process timed out after %.1fs: %s (cwd=%s)", elapsed, cmd_logged, cwd)
        raise ScanError(f"scan engine timed out after {timeout}s") from exc
    t_out.join(10)
    t_err.join(10)
    elapsed = time.monotonic() - started
    level = logging.INFO if proc.returncode == 0 else logging.WARNING
    log.log(level, "process exited %d in %.1fs (%dB out / %dB err): %s (cwd=%s)",
             proc.returncode, elapsed, len(out), len(err), cmd_logged, cwd)
    return proc.returncode, out.decode("utf-8", "replace"), err.decode("utf-8", "replace")
