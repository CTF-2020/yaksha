"""Data model for the correlation (mediator) engine.

The engine reduces three heterogeneous evidence streams to one vocabulary:

  * an **Observation** is a single normalized finding lifted out of one saved
    report category (a SAST rule group, a DAST rule group, or a threat-model
    category). Every observation knows its *source kind*, its *weakness family*,
    a *locus* (where in the system it lives) and a *severity*.

  * a **CorrelatedFinding** is a cluster of observations that the engine has
    decided describe the same underlying weakness — typically the same bug seen
    statically in code, dynamically at runtime, and/or anticipated in the threat
    model. Its *verdict* is the mediator's judgement about what the agreement (or
    disagreement) between sources means for the reader.

Both are plain dataclasses so the engine stays pure and unit-testable; the
Flask/report layer only touches the mapper.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class SourceKind(str, Enum):
    """The class of evidence a finding came from.

    These three are deliberately method-agnostic: any static analyzer is CODE,
    any dynamic/black-box tool is RUNTIME, any architecture/threat-model review
    is DESIGN. Correlation power comes from *distinct* kinds agreeing, so we
    collapse tool identity down to these buckets.
    """

    CODE = "code"        # static analysis / SAST — root cause in source
    RUNTIME = "runtime"  # dynamic analysis / DAST — reproducible at runtime
    DESIGN = "design"    # threat model / architecture review — anticipated risk
    # A real production incident (WAF block, SIEM alert, IR ticket, bug-bounty
    # report) confirming this weakness was actually triggered, not merely
    # proven reachable in a lab. Qualitatively stronger than RUNTIME: a DAST
    # probe proves "this *could* be exploited"; an incident proves "this
    # *was*". See incidents.py (ingestion) and Verdict.ACTIVELY_EXPLOITED.
    INCIDENT = "incident"


class Verdict(str, Enum):
    """What the mediator concludes from the sources present in a cluster."""

    # A real-world incident corroborates this weakness — the strongest
    # possible evidence, above even confirmed_exploitable: that verdict says
    # two independent methods agree the flaw *could* be exploited; this says
    # it actually was, in production. Takes precedence over every other
    # combination of evidence in a cluster (see engine.py:_verdict).
    ACTIVELY_EXPLOITED = "actively_exploited"
    CONFIRMED_EXPLOITABLE = "confirmed_exploitable"  # static root cause + runtime proof
    CORROBORATED = "corroborated"                    # design threat + code or runtime evidence
    DESIGN_GAP = "design_gap"                         # modeled, but no code/runtime evidence either way
    BLIND_SPOT = "blind_spot"                         # code/runtime evidence with no modeled threat


# Ordered worst-first, matching the scanners' vocabulary.
SEVERITIES = ("Critical", "High", "Medium", "Low", "Info")
SEVERITY_ORDER = {s: i for i, s in enumerate(SEVERITIES)}
SEVERITY_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}


def worst(*severities: str) -> str:
    """Return the most severe label among the arguments."""
    best = "Info"
    for sev in severities:
        if SEVERITY_ORDER.get(sev, 99) < SEVERITY_ORDER.get(best, 99):
            best = sev
    return best


@dataclass
class Observation:
    """One normalized finding drawn from a single report category."""

    kind: SourceKind
    family: str                       # canonical weakness slug, e.g. "sql-injection"
    family_title: str                 # human title for the family
    severity: str                     # Critical|High|Medium|Low|Info
    title: str                        # the original finding title
    locus_tokens: frozenset           # normalized location tokens (file/url/component words)
    locus_label: str                  # human-readable location(s)
    cwes: frozenset = frozenset()     # e.g. {"CWE-89"}
    owasp: str = ""                   # e.g. "WEB-A03"
    stride: tuple = ()
    remediation: str = ""
    evidence: str = ""                # snippet / http evidence / rationale
    report_id: str = ""
    report_title: str = ""
    methodology: str = ""
    category_id: str = ""
    # Sink-reachability facts from the code model (unauthenticated/tainted/hops/…),
    # or None when this observation carries no such evidence (SAST pattern match,
    # DAST probe, design finding). See codemodel/threats.py for the producer.
    reachability: dict | None = None
    # Per-component reachability breakdown for a vulnerable-dependency (SBOM)
    # observation whose category bundles several CVE'd packages together --
    # {component_name: reachability_fact} for just the ones proven reachable.
    # None for every non-SBOM observation. See
    # correlator/engine.py:annotate_dependency_reachability.
    dependency_reachability: dict | None = None
    # Business-impact tier inferred from route/asset naming (payments, PII, …),
    # or None when nothing matched. See codemodel/business_impact.py.
    business_impact: dict | None = None
    # Worst confidence/likelihood/impact across matched rule-catalog entries
    # sharing this finding's CWE ({"confidence": "HIGH"|...,  "likelihood":
    # ..., "impact": ..., "matched_rules": n}), or None when no catalog rule
    # matched or none carried the metadata. See
    # app.py:_aggregate_rule_risk_rating and correlator/engine.py:_confidence.
    rule_risk_rating: dict | None = None
    # Every CVE id mentioned in this finding's text (today, only vulnerable-
    # component/SBOM findings ever carry one — see sbom_parser.KNOWN_VULNS),
    # pulled by epss_kev.extract_cves in engine.observe_report. Empty for
    # every other finding; matching these against a fetched EPSS/KEV lookup
    # table is what _epss_kev turns into a real-world exploitation signal.
    cves: frozenset = frozenset()

    @property
    def score(self) -> int:
        return SEVERITY_SCORE.get(self.severity, 1)


@dataclass
class CorrelatedFinding:
    """A cluster of observations judged to be the same weakness."""

    family: str
    family_title: str
    observations: list = field(default_factory=list)
    verdict: Verdict = Verdict.BLIND_SPOT
    severity: str = "Info"            # escalated severity after correlation
    base_severity: str = "Info"       # worst observed severity before escalation
    confidence: float = 0.0           # 0..1 corroboration confidence
    confidence_reason: str = ""       # what pushed it above bare source-count, "" when nothing did
    priority: float = 0.0             # sort key, higher = act first
    exploitability: float = 0.0       # 0..1 attacker-reachability, from code-model facts
    exploitability_reason: str = ""   # human-readable basis for the score, "" when unknown
    business_impact: float = 0.0      # 0..1 asset/route criticality, from naming heuristics
    business_impact_reason: str = ""  # human-readable basis for the score, "" when unknown
    # Real-world exploitation signal from EPSS probability + CISA KEV, for any
    # member finding naming a CVE. 0.0/"" when no lookup table was supplied or
    # no member's CVE(s) matched anything in it -- "unknown", not "safe", same
    # convention as exploitability/business_impact. See engine._epss_kev.
    epss_kev: float = 0.0
    epss_kev_reason: str = ""
    # Per-component reachability breakdown, union of every member observation's
    # dependency_reachability -- which exact CVE'd package(s) in this cluster
    # are proven reachable, not just a category-wide score. {} when none.
    dependency_reachability: dict = field(default_factory=dict)

    @property
    def kinds(self) -> set:
        return {o.kind for o in self.observations}

    @property
    def source_count(self) -> int:
        """Number of *distinct* evidence classes agreeing."""
        return len(self.kinds)
