# Yaksha Guard API v1

The `/api/v1` surface groups the app by capability while keeping the original
legacy `/api/...` routes working for the current frontend.

**Deprecation policy:** the unversioned legacy `/api/...` routes in `app.py`
are frozen — bug fixes only. New endpoints land exclusively under `/api/v1`
(blueprints in `api/`); the frontend should migrate call sites opportunistically
so the legacy surface can eventually be removed.

## Discovery

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/v1` | List available v1 API groups and canonical paths. |

## Analysis

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/v1/analysis/reviews` | Run a review and return the completed report. |
| POST | `/api/v1/analysis/jobs` | Start a streaming review job. |
| GET | `/api/v1/analysis/jobs/{job_id}/events` | Stream progress and final report events. |

## Diagrams

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/v1/diagrams/architecture` | Generate a Mermaid architecture diagram from text or uploads. |

## Reports

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/v1/reports` | List recent saved reports. |
| GET | `/api/v1/reports/{report_id}` | Fetch one saved report. |
| DELETE | `/api/v1/reports/{report_id}` | Delete one saved report. |
| GET | `/api/v1/reports/{report_id}/export` | Export one report as HTML. |

## Controls

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/v1/reports/{report_id}/controls` | Generate a control register for a report. |
| GET | `/api/v1/reports/{report_id}/controls/export` | Export the control register as CSV or HTML with `?format=csv` or `?format=html`. |

## Enrichment And Lookups

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/v1/patterns` | List all offline threat-modeling patterns with full analyst context. |
| GET | `/api/v1/patterns/{ruleset}` | List enriched patterns for one ruleset such as `web`, `api`, `ai`, `cloud`, `architecture`, or `devsecops`. |
| GET | `/api/v1/patterns/{ruleset}/{rule_id}` | Fetch one enriched offline pattern by rule ID. |
| GET | `/api/v1/reports/{report_id}/enrich/attack` | Add MITRE ATT&CK mappings to a report. |
| GET | `/api/v1/reports/{report_id}/enrich/compliance` | Add compliance mappings to a report. |
| GET | `/api/v1/compliance/frameworks` | List mapped compliance frameworks. |
| GET | `/api/v1/lookups/attack/{category}` | Look up ATT&CK techniques for a category. |
| GET | `/api/v1/lookups/compliance/{category}` | Look up compliance controls for a category. |

## SBOM, PQC, And Tickets

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/v1/sbom/analyze` | Analyze a CycloneDX or SPDX SBOM. |
| POST | `/api/v1/pqc/assess` | Assess architecture text or uploads for PQC migration risk. |
| GET | `/api/v1/reports/{report_id}/pqc` | Run and persist PQC assessment for a saved report. |
| POST | `/api/v1/reports/{report_id}/tickets` | Create Jira or Azure DevOps tickets for report findings. |

## Notes

- POST requests still require the CSRF token returned by `/api/csrf-token`.
- Existing frontend URLs are still supported so no current UI flow has to migrate immediately.
- The v1 routes are implemented with feature-specific Flask blueprints under `api/`.
