import unittest
from pathlib import Path

try:
    from .system_design_full import SystemDesignKnowledgeBase
except ImportError:
    from system_design_full import SystemDesignKnowledgeBase


ROOT = Path(__file__).resolve().parent


class SystemDesignFullScriptTests(unittest.TestCase):
    def setUp(self):
        self.kb = SystemDesignKnowledgeBase.load(ROOT)

    def test_loads_metadata_and_stats(self):
        self.assertEqual(self.kb.metadata.name, "system-design")
        stats = self.kb.stats()
        self.assertGreater(stats["sections"], 100)
        self.assertGreater(stats["words"], 10000)

    def test_resolves_topic_by_title_or_slug(self):
        by_title = self.kb.get_section("Caching")
        by_slug = self.kb.get_section("caching")

        self.assertEqual(by_title.slug, "caching")
        self.assertEqual(by_title.slug, by_slug.slug)

    def test_search_and_related_topics(self):
        hits = self.kb.search("cache invalidation", limit=3)
        related = self.kb.related("Caching", limit=3)

        self.assertEqual(hits[0].section.title, "Cache Invalidation")
        self.assertTrue(any(item.title == "Content Delivery Network (CDN)" for item in related))

    def test_generates_learning_assets(self):
        summary = self.kb.summarize("Caching", sentences=2)
        cards = self.kb.flashcards("Caching", limit=3)
        quiz = self.kb.quiz("Caching", count=3)

        self.assertIn("cache", summary.casefold())
        self.assertEqual(len(cards), 3)
        self.assertEqual(len(quiz), 3)
        self.assertTrue(quiz[0].answer)

    def test_exports_index_payload(self):
        payload = self.kb.export_payload(include_body=False)

        self.assertEqual(payload["metadata"]["name"], "system-design")
        self.assertIn("topics", payload)
        self.assertGreater(len(payload["sections"]), 100)


if __name__ == "__main__":
    unittest.main()
