"""Derive threat-model findings from an extracted :class:`SystemModel`.

This is the step that makes the engine a *threat-modeling* engine rather than an
inventory tool: it reasons about control **presence vs absence** on the attack
surface. A sink reachable from an entry point is a weakness; the same sink
reachable from an *unauthenticated* entry point is a worse one; a state-changing
endpoint with no auth control is a threat even when no injection sink is present.

Output is a list of category dicts in the standard Yaksha Guard report shape,
tagged ``_source: "CODEMODEL"`` and carrying CWE/OWASP so the correlation engine
can line them up against SAST/DAST/threat-model findings.
"""
from __future__ import annotations

from . import business_impact

# Local family -> (owasp, stride) so we can tag categories without importing the
# correlator (which would be a cycle). CWE comes from the sink itself.
_FAMILY_META = {
    "sql-injection": ("WEB-A03", ["Tampering"]),
    "command-injection": ("WEB-A03", ["Tampering", "Elevation of Privilege"]),
    "code-injection": ("WEB-A03", ["Tampering", "Elevation of Privilege"]),
    "deserialization": ("WEB-A08", ["Tampering", "Elevation of Privilege"]),
    "template-injection": ("WEB-A03", ["Tampering"]),
    "ssrf": ("WEB-A10", ["Information Disclosure", "Spoofing"]),
    "path-traversal": ("WEB-A01", ["Information Disclosure"]),
    "open-redirect": ("WEB-A01", ["Spoofing"]),
    "broken-access-control": ("WEB-A01", ["Elevation of Privilege"]),
    "sensitive-data-exposure": ("WEB-A02", ["Information Disclosure"]),
    "crypto-failure": ("WEB-A02", ["Information Disclosure"]),
    "security-misconfig": ("WEB-A05", ["Information Disclosure"]),
    "excessive-agency": ("LLM06", ["Tampering", "Elevation of Privilege"]),
}

# When a dangerous sink is reached through an agent-tool entry point (rather
# than a web route), it is simultaneously an OWASP LLM Top 10 finding — the
# tool grants the LLM more capability than it constrains. Carried as a second
# tag (`owasp_llm`) alongside the sink family's own WEB-* mapping so the
# report shows both angles without duplicating the finding.
_AGENTIC_OWASP_LLM = "LLM06"

_SEVERITY_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}
_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}

# Base severity for a reachable sink family, before auth escalation.
_SINK_SEVERITY = {
    "command-injection": "High", "code-injection": "High", "deserialization": "High",
    "template-injection": "High", "ssrf": "High", "sql-injection": "Medium",
    "path-traversal": "Medium", "open-redirect": "Medium",
}
_STATE_CHANGING = {"POST", "PUT", "PATCH", "DELETE"}
_REMEDIATION = {
    "sql-injection": "Use parameterized queries / an ORM; never build SQL from input.",
    "command-injection": "Avoid shells; pass argument lists and validate against an allow-list.",
    "code-injection": "Remove eval/exec on request-derived data; use a safe parser.",
    "deserialization": "Never deserialize untrusted data with pickle/yaml.load; use safe formats.",
    "template-injection": "Never render user input as a template; pass it as data.",
    "ssrf": "Validate outbound URLs against an allow-list and block internal ranges.",
    "path-traversal": "Canonicalize and confine file paths to an allowed base directory.",
    "open-redirect": "Validate redirect targets against an allow-list of known URLs.",
    "broken-access-control": "Enforce authentication and authorization on this endpoint.",
    "sensitive-data-exposure": "Move secrets to a secret manager / environment; rotate exposed ones.",
    "crypto-failure": "Use TLS for all transport; never send credentials or data over cleartext HTTP.",
    "security-misconfig": "Harden the configuration; disable debug and permissive CORS in production.",
    "excessive-agency": "Constrain tool scope and arguments (allow-list, schema validation), and "
                        "require human confirmation before high-impact actions.",
}


def _worst(sevs):
    best = "Info"
    for s in sevs:
        if _ORDER.get(s, 9) < _ORDER.get(best, 9):
            best = s
    return best


def _merge_impact(hints) -> dict | None:
    """Worst (highest-score) business-impact hint across a group of entry
    points — same "one hit is enough to mark the whole cluster" rule the
    correlator applies at the finding level (see
    correlator/engine.py:_business_impact), just one layer earlier."""
    tags = [h for h in hints if h]
    if not tags:
        return None
    return max(tags, key=lambda h: h.get("score", 0.0))


def _category(idx, family, name, severity, components, threats, note, method_hint="",
              extra_owasp="", reachability=None, impact_texts=None, impact_hints=None):
    owasp, stride = _FAMILY_META.get(family, ("", []))
    cwe = next((t.get("_cwe", "") for t in threats if t.get("_cwe")), "")
    remediation = _REMEDIATION.get(family, "Review and remediate per secure-design guidance.")
    for t in threats:
        t.pop("_cwe", None)
    cat = {
        "id": f"CM-{idx:03d}",
        "category": "Code-derived threat model",
        "name": name,
        "title": name,
        "risk": severity,
        "risk_score": _SEVERITY_SCORE.get(severity, 1),
        "_source": "CODEMODEL",
        "family": family,
        "ruleset": "CodeModel",
        "cwe": cwe,
        "owasp": owasp,
        "stride": stride,
        "description": note,
        "affected_components": components[:25],
        "mitigation": remediation,
        "remediation": remediation,
        "mitigations": [{"action": remediation, "priority": "Immediate"}],
        "threats": threats,
        "notes": f"OWASP: {owasp or 'n/a'}  ·  CWE: {cwe or 'n/a'}  ·  "
                 f"STRIDE: {'/'.join(stride) or 'n/a'}  ·  derived from code structure",
    }
    if extra_owasp:
        cat["owasp_llm"] = extra_owasp
        cat["agentic"] = True
        cat["notes"] += f"  ·  Also: {extra_owasp} (agent-tool reachable — excessive agency)"
    if reachability:
        cat["reachability"] = reachability
    impact = _merge_impact(impact_hints) if impact_hints is not None \
        else business_impact.classify(*(impact_texts or []))
    if impact:
        cat["business_impact"] = impact
    return cat


def derive(model) -> list[dict]:
    categories: list[dict] = []
    idx = 1

    # 1) reachable sinks grouped by weakness family across the whole surface
    by_family: dict[str, list] = {}
    for ep in model.entry_points:
        for s in ep.reachable_sinks:
            by_family.setdefault(s.family, []).append((ep, s))

    _CONF_RANK = {"high": 3, "medium": 2, "low": 1}
    for family, pairs in sorted(by_family.items()):
        components, threats, sevs = [], [], []
        any_unauth = False
        any_tool_ep = False
        any_tainted = False
        min_hops = None
        best_conf = "medium"
        for ep, s in pairs:
            is_tool = ep.kind == "agent-tool"
            base = _SINK_SEVERITY.get(family, "Medium")
            if s.tainted and base == "Medium":
                base = "High"
            if not ep.authenticated:
                any_unauth = True
                base = "Critical" if base == "High" else "High"
            if is_tool:
                any_tool_ep = True
            if s.tainted:
                any_tainted = True
            if min_hops is None or s.hops < min_hops:
                min_hops = s.hops
            if _CONF_RANK.get(s.confidence, 2) > _CONF_RANK.get(best_conf, 2):
                best_conf = s.confidence
            sevs.append(base)
            hop = "in handler" if s.hops == 0 else f"{s.hops} call hop(s) away"
            if is_tool:
                reach = "invokable by the LLM/agent runtime with no observed argument constraint"
            else:
                reach = "reachable WITHOUT authentication" if not ep.authenticated \
                    else "behind an auth control"
            components.append(f"{ep.locus} → {s.name} ({s.file}:{s.line})")
            threats.append({
                "name": f"{ep.locus}  ({ep.file}:{ep.line})",
                "description": f"{'Agent tool' if is_tool else 'Entry point'} reaches a "
                               f"{family} sink '{s.name}' ({s.file}:{s.line}, {hop}); {reach}"
                               + (" and an argument is attacker-controlled." if s.tainted else "."),
                "attack_vector": (f"Prompt injection driving {family} via tool '{ep.handler}'"
                                  if is_tool else f"{family} via {ep.locus}"),
                "control_objective": (
                    "No argument allow-listing or human-in-the-loop confirmation observed "
                    "before this tool executes. " if is_tool else
                    ("No authentication control on the entry point. " if not ep.authenticated
                     else "")) + "No input validation observed.",
                "_cwe": s.cwe,
            })
        name = _FAMILY_TITLE.get(family, family.replace("-", " ").title())
        note_bits = []
        if any_unauth:
            note_bits.append("at least one is reachable without authentication")
        if any_tool_ep:
            note_bits.append("at least one is an LLM-invokable agent tool with no observed "
                             "argument constraint (excessive agency)")
        note = (f"{len(pairs)} entry-point path(s) reach a {name.lower()} sink"
                + (" — " + "; ".join(note_bits) + "." if note_bits else "."))
        categories.append(_category(
            idx, family, name, _worst(sevs), components, threats, note,
            extra_owasp=_AGENTIC_OWASP_LLM if any_tool_ep else "",
            reachability={
                "confirmed": True,
                "unauthenticated": any_unauth,
                "tainted": any_tainted,
                "min_hops": min_hops if min_hops is not None else 0,
                "agent_tool": any_tool_ep,
                "sink_confidence": best_conf,
            },
            impact_hints=[ep.reachable_impact for ep, s in pairs]))
        idx += 1

    # 2) unauthenticated state-changing entry points with no dangerous sink of
    #    their own (pure access-control gap / model blind spot)
    dangerous_eps = {id(ep) for ep in model.entry_points for _ in ep.reachable_sinks}
    open_eps = [ep for ep in model.entry_points
                if not ep.authenticated and id(ep) not in dangerous_eps
                and (ep.method in _STATE_CHANGING or ep.method == "*")]
    if open_eps:
        components = [f"{ep.locus} ({ep.file}:{ep.line})" for ep in open_eps]
        threats = [{
            "name": f"{ep.locus}  ({ep.file}:{ep.line})",
            "description": f"State-changing endpoint '{ep.handler}' has no observable "
                           "authentication or authorization control.",
            "attack_vector": f"Unauthenticated access to {ep.locus}",
            "control_objective": "Authentication + authorization on state-changing operations.",
        } for ep in open_eps]
        categories.append(_category(
            idx, "broken-access-control", "Unauthenticated state-changing endpoints",
            "High", components, threats,
            f"{len(open_eps)} state-changing endpoint(s) expose no authentication control.",
            reachability={
                "confirmed": True,
                "unauthenticated": True,
                "tainted": False,
                "min_hops": 0,
                "agent_tool": False,
                "sink_confidence": "high",
            },
            impact_hints=[ep.reachable_impact for ep in open_eps]))
        idx += 1

    # 3) hardcoded secrets
    hard = [s for s in model.secrets if not s.managed]
    if hard:
        components = [f"{s.name} ({s.file}:{s.line})" for s in hard]
        threats = [{
            "name": f"{s.name}  ({s.file}:{s.line})",
            "description": f"Secret '{s.name}' appears hardcoded in source/config.",
            "attack_vector": "Credential disclosure via source access",
            "control_objective": "Secrets kept out of source; loaded from a secret store.",
            "_cwe": "CWE-798",
        } for s in hard]
        categories.append(_category(
            idx, "sensitive-data-exposure", "Hardcoded secrets", "High",
            components, threats, f"{len(hard)} hardcoded secret(s) found in code/config.",
            impact_texts=[f"{s.name} {s.file}" for s in hard]))
        idx += 1

    # 4) cleartext external transport
    cleartext = [e for e in model.external_calls if e.kind == "http" and not e.encrypted]
    if cleartext:
        components = [f"{e.target} ({e.file}:{e.line})" for e in cleartext]
        threats = [{
            "name": f"{e.target}  ({e.file}:{e.line})",
            "description": "Outbound call uses cleartext HTTP.",
            "attack_vector": "Man-in-the-middle on cleartext transport",
            "control_objective": "TLS on all outbound transport.",
            "_cwe": "CWE-319",
        } for e in cleartext]
        categories.append(_category(
            idx, "crypto-failure", "Cleartext transport (HTTP)", "Medium",
            components, threats, f"{len(cleartext)} outbound call(s) use cleartext HTTP.",
            impact_texts=[f"{e.target} {e.file}" for e in cleartext]))
        idx += 1

    # 5) misconfiguration controls flagged by the config extractor
    misconfig = [c for c in model.controls
                 if ("CORS: *" in c.mechanism or "debug" in c.mechanism.lower()
                     or "TLS verification disabled" in c.mechanism)]
    if misconfig:
        components = [f"{c.mechanism} ({c.file})" for c in misconfig]
        threats = [{
            "name": c.mechanism,
            "description": f"Insecure configuration: {c.mechanism} in {c.file or 'config'}.",
            "attack_vector": "Security misconfiguration",
            "control_objective": "Production-hardened configuration.",
            "_cwe": "CWE-16",
        } for c in misconfig]
        categories.append(_category(
            idx, "security-misconfig", "Security misconfiguration", "Medium",
            components, threats, f"{len(misconfig)} insecure configuration setting(s).",
            impact_texts=[f"{c.mechanism} {c.file}" for c in misconfig]))
        idx += 1

    # 6) LLM/agent-invokable tool functions with no observed argument
    #    validation AND no dangerous sink reachable from them (a tool that
    #    *does* reach a dangerous sink is already reported, at higher
    #    severity with an LLM06 tag, by section 1 above — this section is the
    #    weaker "attack surface exists, unconstrained" signal for the rest).
    tool_eps = [ep for ep in model.entry_points if ep.kind == "agent-tool"]
    unvalidated_tools = [ep for ep in tool_eps
                         if not ep.reachable_sinks
                         and not any(c.kind == "validation" for c in ep.controls)]
    if unvalidated_tools:
        components = [f"{ep.locus} ({ep.file}:{ep.line})" for ep in unvalidated_tools]
        threats = [{
            "name": f"{ep.locus}  ({ep.file}:{ep.line})",
            "description": f"Tool '{ep.handler}' is invokable by the LLM/agent runtime with "
                           "no observed argument validation before use.",
            "attack_vector": f"Prompt injection driving unconstrained arguments into '{ep.handler}'",
            "control_objective": "Validate/allow-list tool arguments; require confirmation "
                                 "for high-impact actions.",
            "_cwe": "CWE-20",
        } for ep in unvalidated_tools]
        categories.append(_category(
            idx, "excessive-agency", "Agent tool without argument validation", "Medium",
            components, threats,
            f"{len(unvalidated_tools)} LLM-invokable tool(s) have no observed input validation.",
            impact_hints=[ep.reachable_impact for ep in unvalidated_tools]))
        idx += 1

    # 7) cloud/IaC misconfiguration (Terraform-derived; see terraform_extractor.py)
    cloud_misconfig = [c for c in model.controls if c.kind == "cloud-misconfig"]
    if cloud_misconfig:
        components = [f"{c.mechanism} ({c.file}:{c.line})" for c in cloud_misconfig]
        threats = [{
            "name": c.mechanism,
            "description": f"Terraform-declared resource has a security misconfiguration: "
                           f"{c.mechanism} ({c.file}:{c.line}).",
            "attack_vector": "Cloud infrastructure misconfiguration",
            "control_objective": "Harden the Terraform resource configuration per cloud "
                                 "provider security guidance.",
            "_cwe": "CWE-16",
        } for c in cloud_misconfig]
        categories.append(_category(
            idx, "security-misconfig", "Cloud infrastructure misconfiguration (Terraform)",
            "High", components, threats,
            f"{len(cloud_misconfig)} Terraform-declared resource(s) have a security "
            "misconfiguration.",
            impact_texts=[f"{c.mechanism} {c.file}" for c in cloud_misconfig]))
        idx += 1

    categories.sort(key=lambda c: (_ORDER.get(c["risk"], 9), c["name"]))
    return categories


_FAMILY_TITLE = {
    "sql-injection": "SQL Injection", "command-injection": "OS Command Injection",
    "code-injection": "Code Injection", "deserialization": "Insecure Deserialization",
    "template-injection": "Server-Side Template Injection", "ssrf": "Server-Side Request Forgery",
    "path-traversal": "Path Traversal", "open-redirect": "Open Redirect",
}
