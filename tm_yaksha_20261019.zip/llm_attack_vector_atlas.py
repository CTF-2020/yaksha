"""Offline LLM attack-vector atlas imported from the companion checklist.

The checklist is stored as data so Yaksha Guard can use it without any
external model or network dependency. This module converts each row into the
same rule shape used by the OWASP LLM offline review engine.
"""
from __future__ import annotations

from pathlib import Path
import re


CHECKLIST_PATH = Path(__file__).resolve().parent / "data" / "llm-attack-vector-checklist.md"

REFERENCES = [
    "https://genai.owasp.org/llm-top-10/",
    "https://atlas.mitre.org/",
    "https://www.nist.gov/itl/ai-risk-management-framework",
    "local://data/llm-attack-vector-checklist.md",
]

DOMAIN_PROFILES: dict[str, dict[str, object]] = {
    "A": {
        "category": "LLM01",
        "severity": "High",
        "theme": "Prompt and Input Manipulation",
        "controls": [
            "Separate instructions from untrusted data with explicit trust labels and immutable system/developer messages.",
            "Scan retrieved, uploaded, and tool-returned content for instruction-like text before it enters model context.",
            "Constrain tool choice and instruction authority server-side instead of relying on model judgment alone.",
            "Regression test direct and indirect prompt-injection paths across languages, encodings, and multi-turn flows.",
        ],
        "signals": [
            "prompt injection",
            "system prompt",
            "developer instruction",
            "retrieved document",
            "webpage content",
            "tool output",
        ],
    },
    "B": {
        "category": "LLM03",
        "severity": "High",
        "theme": "RAG, Context, Memory, and Embeddings",
        "controls": [
            "Authorize retrieval results before prompt assembly and preserve tenant, user, and document permissions in indexes.",
            "Track source provenance, ingestion time, parser version, and content owner for every retrieved chunk.",
            "Isolate memory by tenant, user, session, and purpose; expire or review memory writes before reuse.",
            "Monitor retrieval drift, poisoning indicators, stale documents, and anomalous ranking changes.",
        ],
        "signals": [
            "rag",
            "retrieval",
            "vector database",
            "embedding",
            "memory",
            "context window",
            "knowledge base",
        ],
    },
    "C": {
        "category": "LLM06",
        "severity": "High",
        "theme": "Sensitive Data and Privacy",
        "controls": [
            "Classify data before model calls and redact secrets, credentials, PII, PHI, and regulated fields from prompts and logs.",
            "Keep prompt, cache, transcript, export, evaluation, and incident data scoped by tenant and retention policy.",
            "Apply privacy review to vendor routing, telemetry, fine-tuning, support bundles, and shared prompt caches.",
            "Detect and block exfiltration of sensitive data through model output, tool parameters, and downstream integrations.",
        ],
        "signals": [
            "sensitive data",
            "pii",
            "phi",
            "secret",
            "credential",
            "tenant data",
            "prompt cache",
            "conversation export",
        ],
    },
    "D": {
        "category": "LLM07",
        "severity": "Critical",
        "theme": "Tool Use, Function Calling, and Execution",
        "controls": [
            "Use explicit server-side allowlists for tools, URLs, commands, repositories, schemas, and cloud/API operations.",
            "Authorize every tool call against the real user, tenant, action, object, and requested parameters.",
            "Sandbox execution, restrict egress, block metadata access, and default tool credentials to least privilege.",
            "Bind previews, approvals, execution parameters, and audit records to the exact action that will run.",
        ],
        "signals": [
            "tool call",
            "function calling",
            "agent tool",
            "browser tool",
            "code execution",
            "shell command",
            "api tool",
            "webhook",
        ],
    },
    "E": {
        "category": "LLM08",
        "severity": "High",
        "theme": "Quorum, Approval, Consensus, and Control Gates",
        "controls": [
            "Make approval prompts explicit about actor, action, object, parameters, risk, and irreversible impact.",
            "Require independence for quorum voters across model, prompt, context source, tool path, and identity.",
            "Fail closed on approval timeout, stale evidence, split decisions, policy cache errors, and unresolved dissent.",
            "Record who approved what exact action, with immutable evidence and replayable execution context.",
        ],
        "signals": [
            "approval",
            "human approval",
            "quorum",
            "consensus",
            "control gate",
            "policy decision",
            "reviewer",
        ],
    },
    "F": {
        "category": "LLM08",
        "severity": "Critical",
        "theme": "Identity, Authorization, and Tenant Boundaries",
        "controls": [
            "Resolve identity and authorization server-side for each model action instead of trusting prompt text.",
            "Bind tokens to issuer, audience, tenant, user, session, scope, and allowed tool/action.",
            "Prevent cross-tenant data access in prompts, memory, retrieval, caches, logs, exports, and tool calls.",
            "Use break-glass, impersonation, service-account, and delegation paths only with explicit approval and audit.",
        ],
        "signals": [
            "authorization",
            "tenant boundary",
            "cross tenant",
            "service account",
            "oauth token",
            "session token",
            "rbac",
            "identity context",
        ],
    },
    "G": {
        "category": "LLM05",
        "severity": "High",
        "theme": "Supply Chain, Dependency, and Model Lifecycle",
        "controls": [
            "Verify model, adapter, prompt package, dataset, tokenizer, guardrail, and tool/plugin provenance before use.",
            "Pin trusted versions, require signed artifacts, scan dependencies, and separate promotion from production rollout.",
            "Run adversarial regression tests after model, prompt, retrieval, parser, or policy changes.",
            "Monitor vendor routing, model deprecation, benchmark drift, and dependency compromise indicators.",
        ],
        "signals": [
            "model artifact",
            "fine tuning",
            "training data",
            "prompt package",
            "plugin",
            "dependency",
            "model routing",
            "tokenizer",
        ],
    },
    "H": {
        "category": "LLM02",
        "severity": "High",
        "theme": "Output Handling and Downstream Effects",
        "controls": [
            "Treat model output as untrusted before rendering, executing, storing, forwarding, or copying it.",
            "Use strict output schemas, escaping, sanitization, and policy checks for HTML, Markdown, SQL, code, configs, and IaC.",
            "Separate explanatory text from executable actions and require review for destructive generated changes.",
            "Scan generated artifacts for injection, insecure configuration, hidden content, and unsafe copy/paste behavior.",
        ],
        "signals": [
            "model output",
            "generated code",
            "generated sql",
            "markdown output",
            "html output",
            "terraform",
            "kubernetes",
            "copy button",
        ],
    },
    "I": {
        "category": "LLM04",
        "severity": "High",
        "theme": "Denial of Service, Cost, and Resource Exhaustion",
        "controls": [
            "Bound tokens, retries, loops, concurrent jobs, tool calls, uploads, retrieval fanout, and streaming duration.",
            "Enforce per-user, tenant, route, and model quotas with backpressure and abuse detection.",
            "Cancel downstream work when users cancel streams and cap chained agent/tool workflows.",
            "Alert on cost spikes, queue starvation, resource exhaustion, and retry storms.",
        ],
        "signals": [
            "token limit",
            "rate limit",
            "quota",
            "retry loop",
            "streaming",
            "large upload",
            "resource exhaustion",
            "cost spike",
        ],
    },
    "J": {
        "category": "LLM10",
        "severity": "Medium",
        "theme": "Extraction, Side Channels, and Model Theft",
        "controls": [
            "Protect prompts, weights, adapters, embeddings, eval data, routing policies, and safety configurations.",
            "Rate-limit probing, monitor systematic queries, and detect distillation, membership inference, and prompt extraction attempts.",
            "Reduce observable side channels in latency, confidence, refusal behavior, routing, cache hits, and token accounting.",
            "Use canaries and anomaly detection for prompt leakage, training-data reconstruction, and model cloning attempts.",
        ],
        "signals": [
            "model theft",
            "prompt extraction",
            "system prompt leak",
            "distillation",
            "membership inference",
            "side channel",
            "model weights",
            "adapter",
        ],
    },
    "K": {
        "category": "LLM08",
        "severity": "High",
        "theme": "Multi-Agent, Delegation, and Autonomy",
        "controls": [
            "Define which agents can delegate, approve, execute, or override decisions, and bind those powers to policy.",
            "Limit agent-to-agent trust, shared scratchpads, shared tools, and autonomous recursion.",
            "Require independent context and authorization for reviewer, planner, executor, and verifier roles.",
            "Log delegation chains, task handoffs, tool choices, and final actions for incident review.",
        ],
        "signals": [
            "multi agent",
            "agent delegation",
            "autonomous agent",
            "planner",
            "executor",
            "reviewer agent",
            "agent swarm",
            "handoff",
        ],
    },
    "L": {
        "category": "LLM01",
        "severity": "High",
        "theme": "Multimodal, File, and Parser Inputs",
        "controls": [
            "Parse uploads in isolated services and treat extracted OCR, metadata, alt text, and embedded content as untrusted.",
            "Normalize and validate file type, size, archive depth, embedded URLs, macros, and cross-format content.",
            "Apply prompt-injection scanning to images, PDFs, office files, audio transcripts, diagrams, and hidden text layers.",
            "Preserve provenance and security labels from the original file through parsed chunks and model prompts.",
        ],
        "signals": [
            "file upload",
            "pdf",
            "ocr",
            "image input",
            "audio transcript",
            "metadata",
            "macro",
            "parser",
        ],
    },
    "M": {
        "category": "LLM09",
        "severity": "Medium",
        "theme": "UX, Social Engineering, and Human Factors",
        "controls": [
            "Design AI UI to show uncertainty, source provenance, risky actions, and exact approval parameters clearly.",
            "Avoid anthropomorphic authority, misleading confidence, or summaries that hide security-relevant details.",
            "Protect users from persuasive model output, phishing-like generated content, and unsafe copy/paste instructions.",
            "Train operators to inspect evidence rather than trusting fluent summaries or model-assigned severity alone.",
        ],
        "signals": [
            "approval summary",
            "ai generated",
            "recommendation",
            "operator",
            "support agent",
            "confidence score",
            "citation",
            "ui summary",
        ],
    },
    "N": {
        "category": "LLM09",
        "severity": "Medium",
        "theme": "Monitoring, Incident Response, and Governance",
        "controls": [
            "Log prompt, retrieval, tool, approval, output, policy, and user identity events with privacy-aware retention.",
            "Create incident playbooks for prompt injection, data leakage, memory poisoning, tool abuse, and model compromise.",
            "Track model, prompt, dataset, policy, and tool versions so incidents can be reproduced and scoped.",
            "Alert on anomalies in retrieval, token use, tool calls, refusals, approvals, tenant access, and sensitive output.",
        ],
        "signals": [
            "monitoring",
            "incident response",
            "audit log",
            "model version",
            "prompt version",
            "telemetry",
            "governance",
            "playbook",
        ],
    },
    "O": {
        "category": "LLM07",
        "severity": "Critical",
        "theme": "MCP, Plugins, and External Connectors",
        "controls": [
            "Approve MCP/plugin servers explicitly and verify transport, identity, schema, executable path, and package provenance.",
            "Constrain connector schemas so they cannot hide arbitrary URL, file, command, credential, or network capabilities.",
            "Bind OAuth tokens, tenant context, and tool permissions to the intended server and action.",
            "Audit server discovery, permission prompts, cross-server requests, downgrade paths, and local transport exposure.",
        ],
        "signals": [
            "mcp server",
            "mcp tool",
            "plugin server",
            "connector",
            "oauth token",
            "tool schema",
            "local transport",
            "server discovery",
        ],
    },
}

DOMAIN_BY_NAME = {
    str(profile["theme"]).lower(): key for key, profile in DOMAIN_PROFILES.items()
}

SEVERITY_KEYWORDS = {
    "Critical": [
        "credential",
        "secret",
        "token",
        "cross-tenant",
        "authorization",
        "permission",
        "shell",
        "command",
        "code execution",
        "delete",
        "deploy",
        "payment",
        "database",
        "metadata",
        "ssrf",
        "dns rebinding",
        "privilege",
        "exfiltration",
        "oauth",
        "mcp",
    ],
    "High": [
        "prompt injection",
        "jailbreak",
        "poisoning",
        "bypass",
        "leak",
        "unsafe",
        "untrusted",
        "tool",
        "rag",
        "memory",
        "model artifact",
        "supply chain",
    ],
}

STOPWORDS = {
    "about",
    "access",
    "action",
    "actions",
    "after",
    "against",
    "allow",
    "allowed",
    "another",
    "before",
    "being",
    "break",
    "can",
    "carry",
    "cause",
    "change",
    "client",
    "contain",
    "content",
    "control",
    "controls",
    "could",
    "data",
    "does",
    "from",
    "grant",
    "have",
    "hidden",
    "into",
    "later",
    "make",
    "model",
    "more",
    "one",
    "other",
    "passed",
    "policy",
    "prompt",
    "prompts",
    "request",
    "safe",
    "server",
    "service",
    "source",
    "system",
    "that",
    "their",
    "the",
    "them",
    "through",
    "tool",
    "tools",
    "trusted",
    "untrusted",
    "unintended",
    "user",
    "users",
    "when",
    "where",
    "with",
    "without",
}

PHRASE_EXPANSIONS: dict[str, list[str]] = {
    "browsing tools": ["browser tool", "browsing tool", "web browsing tool"],
    "fetched pages": ["web fetch", "url fetch", "browser fetch"],
    "fetch steered": ["url fetch", "browser fetch"],
    "code execution": ["code execution", "sandboxed execution"],
    "shell command": ["shell command", "command execution"],
    "cloud metadata": ["cloud metadata", "metadata endpoint", "imds"],
    "cross-tenant": ["cross tenant", "tenant boundary"],
    "oauth token": ["oauth token", "access token"],
    "permission prompt": ["permission prompt", "approval prompt"],
    "local transport": ["local transport", "local mcp transport"],
}


def _normalise_cell(value: str) -> str:
    return re.sub(r"\s+", " ", value.replace("&amp;", "&")).strip()


def _slug_phrases(text: str) -> list[str]:
    words = [
        word
        for word in re.findall(r"[a-z0-9][a-z0-9+\-]*", text.lower())
        if len(word) >= 3 and word not in STOPWORDS
    ]
    phrases: list[str] = []
    for size in (3, 2):
        for index in range(0, max(len(words) - size + 1, 0)):
            phrase = " ".join(words[index : index + size])
            if any(token not in STOPWORDS for token in phrase.split()):
                phrases.append(phrase)
    return phrases


def _domain_key(section_title: str) -> str | None:
    lowered = section_title.lower().strip()
    return DOMAIN_BY_NAME.get(lowered)


def _row_domain_from_id(vector_id: str) -> str | None:
    number = int(vector_id.split("-")[1])
    # These ranges follow the source checklist section ordering. They are used
    # only as a fallback if a future edit removes a section heading.
    if number <= 43:
        return "A"
    if number <= 79:
        return "B"
    if number <= 116:
        return "C"
    if number <= 162:
        return "D"
    if number <= 193:
        return "E"
    if number <= 228:
        return "F"
    if number <= 263:
        return "G"
    if number <= 306:
        return "H"
    if number <= 344:
        return "I"
    if number <= 375:
        return "J"
    if number <= 390:
        return "K"
    if number <= 405:
        return "L"
    if number <= 410:
        return "M"
    if number <= 418:
        return "N"
    return "O"


def _severity(default: str, vector: str, question: str) -> str:
    combined = f"{vector} {question}".lower()
    for severity, keywords in SEVERITY_KEYWORDS.items():
        if any(keyword in combined for keyword in keywords):
            return severity
    return default


def _patterns(vector: str, question: str, profile: dict[str, object]) -> list[str]:
    combined = f"{vector} {question}".lower()
    expansions: list[str] = []
    for phrase, mapped in PHRASE_EXPANSIONS.items():
        if phrase in combined:
            expansions.extend(expansion.lower() for expansion in mapped)

    candidates: list[str] = [
        vector.lower(),
        *expansions,
        *[phrase.lower() for phrase in _slug_phrases(vector)[:8]],
        *[phrase.lower() for phrase in _slug_phrases(question)[:8]],
    ]

    # Add only domain signals that appear in the vector or the review question.
    for signal in profile.get("signals", []):
        signal_text = str(signal).lower()
        if signal_text in combined:
            candidates.append(signal_text)

    seen: set[str] = set()
    results: list[str] = []
    for candidate in candidates:
        value = re.sub(r"\s+", " ", candidate).strip(" .,:;!?")
        if not value or value in seen:
            continue
        if value in STOPWORDS:
            continue
        if len(value) < 4 and value not in {"rag", "mcp", "jwt", "sql"}:
            continue
        seen.add(value)
        results.append(value)
    return results[:12]


def _make_rule(vector_id: str, vector: str, question: str, domain: str) -> dict:
    profile = DOMAIN_PROFILES[domain]
    category = str(profile["category"])
    theme = str(profile["theme"])
    severity = _severity(str(profile["severity"]), vector, question)
    controls = list(profile["controls"])
    return {
        "id": f"AI-LLM-ATLAS-{int(vector_id.split('-')[1]):03d}",
        "source_attack_vector_id": vector_id,
        "category": category,
        "question": question,
        "rationale": (
            f"{vector} is a concrete {theme.lower()} abuse path. "
            "Review it when the architecture combines LLM context, untrusted input, "
            "sensitive data, tools, memory, approvals, or external connectors."
        ),
        "severity": severity,
        "patterns_to_check": _patterns(vector, question, profile),
        "mitigations": controls,
        "references": REFERENCES,
        "attack_vector": vector,
        "control_objective": controls[0],
        "pattern_family": theme,
    }


def _parse_checklist() -> list[dict]:
    if not CHECKLIST_PATH.exists():
        raise FileNotFoundError(f"Missing offline LLM attack-vector checklist: {CHECKLIST_PATH}")

    rules: list[dict] = []
    current_domain: str | None = None
    heading_re = re.compile(r"^##\s+([A-O])\.\s+(.+?)\s*$")
    row_re = re.compile(r"^\|\s*(LLM-\d+)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*$")

    for line in CHECKLIST_PATH.read_text(encoding="utf-8").splitlines():
        heading = heading_re.match(line)
        if heading:
            current_domain = heading.group(1)
            heading_domain = _domain_key(heading.group(2))
            if heading_domain:
                current_domain = heading_domain
            continue

        row = row_re.match(line)
        if not row:
            continue

        vector_id, vector, question = row.groups()
        if vector_id == "ID":
            continue
        domain = current_domain or _row_domain_from_id(vector_id)
        if not domain or domain not in DOMAIN_PROFILES:
            continue
        rules.append(_make_rule(vector_id, _normalise_cell(vector), _normalise_cell(question), domain))

    rules.sort(key=lambda rule: int(str(rule["source_attack_vector_id"]).split("-")[1]))
    return rules


LLM_ATTACK_VECTOR_RULES = _parse_checklist()
