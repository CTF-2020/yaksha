"""External open-source SAST engines running alongside the built-in scanner.

The built-in scan engine (SAR scan.py) is Python/config-focused; this module
closes the JS/TS/Go/Java gap by driving off-the-shelf open-source engines as
subprocesses and normalizing their SARIF output into the broker's own finding
shape. Everything downstream — the report mapper, code-context attachment,
delta fingerprints, GitHub annotations, the correlator — consumes the merged
stream with zero changes.

Design constraints:
  * Availability-aware: an engine runs only when its binary is on PATH *and*
    the repo actually contains sources in a language it covers. A missing tool
    is a dashboard fact, never an error.
  * Failure-isolated: one engine crashing, timing out, or emitting garbage is
    recorded in the scan metadata and skipped; it can never fail the scan job.
  * Subprocess-hardened the same way as the built-in engine: list argv (no
    shell), per-engine timeout, capped output (via scanner._exec_capped).

Engines are invoked, never linked or redistributed, so copyleft engine licenses
(LGPL etc.) do not attach to this codebase.
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

from . import config
from .scanner import _attach_code_context, _exec_capped

# ── Language detection ────────────────────────────────────────────────────────
# Extension -> language id. Only languages some registered engine covers.
_EXT_LANG = {
    ".js": "js", ".jsx": "js", ".mjs": "js", ".cjs": "js",
    ".ts": "ts", ".tsx": "ts",
    ".go": "go",
    ".java": "java",
    ".py": "py",
    ".rb": "ruby", ".php": "php", ".kt": "kotlin", ".scala": "scala",
    ".c": "c", ".h": "c", ".cpp": "cpp", ".cc": "cpp", ".cs": "csharp",
}
# Directories that are dependency/build output, not first-party code. Scanning
# them would be slow and would drown the report in vendored findings.
_SKIP_DIRS = {".git", "node_modules", "vendor", "dist", "build", "target",
              "venv", ".venv", "__pycache__", ".tox", ".mypy_cache", "site-packages"}
_MAX_WALK_FILES = 20000


def detect_languages(scan_root: Path) -> set[str]:
    """Language ids present under `scan_root` (bounded, dependency dirs skipped)."""
    langs: set[str] = set()
    seen = 0
    stack = [Path(scan_root)]
    while stack:
        current = stack.pop()
        try:
            entries = list(current.iterdir())
        except OSError:
            continue
        for entry in entries:
            if seen >= _MAX_WALK_FILES or len(langs) == len(set(_EXT_LANG.values())):
                return langs
            if entry.is_dir():
                if entry.name not in _SKIP_DIRS and not entry.name.startswith("."):
                    stack.append(entry)
                continue
            seen += 1
            lang = _EXT_LANG.get(entry.suffix.lower())
            if lang:
                langs.add(lang)
    return langs


# ── Engine registry ───────────────────────────────────────────────────────────
# Each spec: display name, candidate binary names (first found wins), the
# languages it covers, its license (surfaced in the API for governance), and an
# argv builder. `cwd=True` runs the engine *inside* the repo (gosec resolves
# Go packages relative to the module root).
#
# Exit codes are deliberately ignored for success/failure: every one of these
# tools uses a nonzero exit to mean "findings present". The success criterion
# is "stdout parsed as SARIF"; anything else is an engine error.
# `default_auto=False` keeps an engine out of the "auto" set but still selectable
# by naming it in the csv form of TM_BROKER_EXTERNAL_ENGINES. njsscan overlaps
# Opengrep's js/ts coverage completely, so running both under "auto" only
# manufactures duplicate findings (now deduplicated, but still wasted work); it
# is opt-in for anyone who specifically wants its Node.js ruleset.
ENGINES: dict[str, dict] = {
    "opengrep": {
        "name": "Opengrep",
        "binaries": ("opengrep", "semgrep"),   # CLI-compatible fork/original
        "languages": {"js", "ts", "go", "java", "py", "ruby", "php", "kotlin",
                      "scala", "c", "cpp", "csharp"},
        "license": "LGPL-2.1 (invoked as a subprocess)",
        "default_auto": True,
        # `--metrics=off` exists only on the original semgrep CLI (opengrep
        # removed the flag along with the telemetry itself and rejects it).
        # `--config` is resolved per-scan, scoped to the languages actually
        # detected in the target, so a local (offline) ruleset or a narrower
        # registry pack selection is preferred over the full network registry.
        "args": lambda binpath, root, langs: [
            binpath, "scan", "--sarif", "--quiet",
            *(["--metrics=off"] if "semgrep" in Path(binpath).stem.lower() else []),
            *[part for cfg in config.resolve_opengrep_config(langs) for part in ("--config", cfg)],
            str(root)],
        "cwd": False,
    },
    "gosec": {
        "name": "Gosec",
        "binaries": ("gosec",),
        "languages": {"go"},
        "license": "Apache-2.0",
        "default_auto": True,
        "args": lambda binpath, root, langs: [binpath, "-fmt", "sarif", "-quiet", "./..."],
        "cwd": True,
    },
    "njsscan": {
        "name": "njsscan",
        "binaries": ("njsscan",),
        "languages": {"js", "ts"},
        "license": "LGPL-3.0 (invoked as a subprocess)",
        "default_auto": False,
        "args": lambda binpath, root, langs: [binpath, "--sarif", str(root)],
        "cwd": False,
    },
    "bandit": {
        "name": "Bandit",
        "binaries": ("bandit",),
        "languages": {"py"},
        "license": "Apache-2.0",
        "default_auto": True,
        "args": lambda binpath, root, langs: [binpath, "-r", "-q", "-f", "sarif", str(root)],
        "cwd": False,
    },
}


def _find_binary(spec: dict) -> str | None:
    for name in spec["binaries"]:
        path = shutil.which(name)
        if path:
            return path
    return None


def available_engines() -> list[dict]:
    """Availability roster for the status API / dashboard (no secrets, no paths
    beyond the resolved binary)."""
    mode = config.EXTERNAL_ENGINES
    selected = _selected_ids()
    out = []
    for eid, spec in ENGINES.items():
        binpath = _find_binary(spec)
        entry = {
            "id": eid,
            "name": spec["name"],
            "languages": sorted(spec["languages"]),
            "license": spec["license"],
            "available": bool(binpath),
            "binary": binpath,
            "enabled": eid in selected and mode != "off",
        }
        if eid == "opengrep":
            # Surface whether opengrep reads local rules or hits the registry, so
            # the offline posture is visible (and choosable) from the dashboard.
            entry["rules"] = ", ".join(config.resolve_opengrep_config())
            entry["rules_offline"] = config.opengrep_rules_are_local()
        out.append(entry)
    return out


def _selected_ids() -> set[str]:
    """Engine ids enabled by TM_BROKER_EXTERNAL_ENGINES ("auto"/"off"/csv).

    "auto" runs every engine flagged ``default_auto`` (which excludes engines
    that only duplicate another's coverage); the csv form can still name any
    registered engine explicitly, opt-in engines included.
    """
    mode = config.EXTERNAL_ENGINES
    if mode in ("off", "0", "false", "none", ""):
        return set()
    if mode in ("auto", "1", "true", "on"):
        return {eid for eid, spec in ENGINES.items() if spec.get("default_auto", True)}
    return {e.strip() for e in mode.split(",") if e.strip() in ENGINES}


# ── Finding normalization ─────────────────────────────────────────────────────
def _normalize_finding(root: Path, finding: dict) -> None:
    """Rewrite the SARIF artifact URI into a repo-relative forward-slash path.

    SARIF tools variously emit relative paths, absolute paths, and file:// URIs;
    delta fingerprints and GitHub annotations need one canonical form (the same
    one the built-in engine emits).
    """
    uri = str(finding.get("file") or "")
    # Strip only the 2-slash scheme so a `file:///abs/path` URI keeps its leading
    # slash (`/abs/path`) and is still recognised as absolute below — stripping
    # `file:///` would eat the slash and defeat the relative-to-root rewrite.
    if uri.startswith("file://"):
        uri = uri[len("file://"):]
        # A Windows file URI is `file:///C:/...` — the path component keeps a
        # leading slash before the drive (`/C:/...`), which Windows Path neither
        # treats as absolute nor prefix-matches against the scan root. Drop it.
        if len(uri) >= 3 and uri[0] == "/" and uri[2] == ":" and uri[1].isalpha():
            uri = uri[1:]
    path = Path(uri)
    # A "/"-rooted POSIX path is not `is_absolute()` under Windows path
    # semantics (no drive), but SARIF produced on another platform — or by a
    # POSIX-minded tool on this one — still means it as absolute.
    if path.is_absolute() or uri.startswith("/"):
        try:
            path = path.resolve().relative_to(Path(root).resolve())
        except (ValueError, OSError):
            # Foreign-platform absolute path: fall back to a plain
            # forward-slash prefix match against the scan root.
            root_fs = str(Path(root)).replace("\\", "/").rstrip("/")
            uri_fs = uri.replace("\\", "/")
            if root_fs and uri_fs.startswith(root_fs + "/"):
                path = Path(uri_fs[len(root_fs) + 1:])
    finding["file"] = str(path).replace("\\", "/")


def _meets_threshold(severity: str, threshold: str) -> bool:
    order = config.SEVERITY_ORDER
    return order.get(severity, 99) <= order.get(threshold, order["Low"])


# ── Cross-engine deduplication ────────────────────────────────────────────────
_WS = None  # lazily-compiled whitespace regex


def _norm_snippet(text: str) -> str:
    global _WS
    if _WS is None:
        import re
        _WS = re.compile(r"\s+")
    return _WS.sub(" ", (text or "").strip().lower())


def _dedup_key(f: dict):
    """Identity of the *weakness* a finding describes, independent of which
    engine reported it.

    Two engines that both cover a language (e.g. Opengrep and njsscan over JS)
    report the same bug under different rule ids, so the rule id can't be part
    of the key. We key on the locus (file:line) plus the weakness signal: the
    normalized CWE set when present — which distinguishes two *different*
    weaknesses that happen to sit on one line — otherwise the normalized code
    snippet, then the message. Keeping CWE-less findings keyed on their snippet
    is deliberately conservative: distinct rules with distinct messages stay
    separate rather than being force-merged on locus alone.
    """
    # The built-in scanner emits OS-native separators (os.path.relpath on
    # Windows gives backslashes); SARIF-importing engines normalize to forward
    # slashes. Without this, the same file never produces the same key across
    # sources and merge_with_builtin's cross-engine dedup silently no-ops.
    file = (f.get("file") or "").lower().replace("\\", "/")
    line = f.get("line")
    cwes = _cwe_set(f.get("cwe"))
    signal = cwes or _norm_snippet(f.get("snippet") or "") or \
        _norm_snippet(f.get("title") or f.get("id") or "")
    return (file, line, signal)


# CWE ids that different SAST tools commonly report at different specificity for
# what is, at a given locus, the *same* underlying weakness — e.g. Opengrep tags
# JS eval() as CWE-95 "Eval Injection" while the built-in scanner tags the exact
# same line with its formal CWE-94 "Code Injection" parent. Canonicalize the
# child to its parent for dedup-key purposes only, so the two still collapse
# into one finding instead of surviving as look-alike duplicates under
# different rule ids. Deliberately small and hand-curated: only pairs actually
# observed to describe one weakness go here — this must never grow broad enough
# to merge genuinely distinct CWEs that happen to share a locus.
_CWE_CANONICAL = {"CWE-95": "CWE-94"}


def _cwe_set(raw) -> tuple:
    if not raw:
        return ()
    import re
    ids = {m.upper() for m in re.findall(r"cwe-\d+", str(raw), re.I)}
    return tuple(sorted(_CWE_CANONICAL.get(c, c) for c in ids))


def _dedup_across_engines(findings: list[dict]) -> tuple[list[dict], int]:
    """Collapse findings that describe the same weakness at the same locus.

    Input order is authoritative (callers pass findings in registry order), so
    the first engine to report a weakness owns the surviving finding; a later
    engine that finds the same thing only lifts the severity if it graded it
    higher and is recorded in ``corroborated_by``. Returns (unique, removed)."""
    order = config.SEVERITY_ORDER
    survivors: dict = {}
    removed = 0
    for f in findings:
        key = _dedup_key(f)
        winner = survivors.get(key)
        if winner is None:
            survivors[key] = f
            continue
        removed += 1
        # Same weakness from another engine: merge provenance, keep the higher
        # severity, and never lose a snippet/remediation the survivor lacks.
        corrob = winner.setdefault("corroborated_by", [])
        other = f.get("engine")
        if other and other != winner.get("engine") and other not in corrob:
            corrob.append(other)
        if order.get(f.get("severity"), 99) < order.get(winner.get("severity"), 99):
            winner["severity"] = f.get("severity")
        if not winner.get("snippet") and f.get("snippet"):
            winner["snippet"] = f["snippet"]
        if not winner.get("remediation") and f.get("remediation"):
            winner["remediation"] = f["remediation"]
    return list(survivors.values()), removed


def merge_with_builtin(builtin_findings: list[dict], ext_findings: list[dict],
                       emit=None) -> tuple[list[dict], int]:
    """Merge the built-in scanner's findings with `run_engines`'s output,
    deduplicating across *all* sources.

    `run_engines` already collapses duplicates among the external engines
    themselves, but callers (service.py, pipeline.py) historically just did
    ``findings.extend(ext_findings)`` afterwards — so a weakness the built-in
    scanner and e.g. Opengrep both caught (same file:line, same CWE/snippet,
    different rule id) survived as two separate findings. Built-in findings
    are passed first, so they keep the precedence `_dedup_across_engines`
    already gives to whichever list comes first.
    """
    unique, removed = _dedup_across_engines(builtin_findings + ext_findings)
    if removed and emit:
        emit(f"Merged {removed} duplicate finding(s) between the built-in "
             f"scanner and external engines")
    return unique, removed


def _driver_version(doc: dict) -> str:
    for run in doc.get("runs") or []:
        if isinstance(run, dict):
            driver = (run.get("tool") or {}).get("driver") or {}
            v = driver.get("version") or driver.get("semanticVersion")
            if v:
                return str(v)[:40]
    return ""


# ── Runner ────────────────────────────────────────────────────────────────────
def _run_one_engine(eid: str, spec: dict, root: Path, langs: set,
                    severity: str, emit) -> tuple[dict, list[dict]]:
    """Run a single engine to completion, fully failure-isolated.

    Returns (meta_entry, kept_findings). Findings are severity-filtered and
    path-normalized but NOT yet deduplicated or capped (that happens once,
    across all engines, so the cap counts unique weaknesses). Any exception is
    turned into an ``error`` meta entry — an engine can never raise out of here.
    """
    import sarif_import
    entry = {"engine": eid, "name": spec["name"], "status": "", "findings": 0}

    binpath = _find_binary(spec)
    if not binpath:
        entry["status"] = "unavailable"
        return entry, []
    if not (langs & spec["languages"]):
        entry["status"] = "skipped (no matching sources)"
        return entry, []

    emit(f"Running {spec['name']}")
    started = time.monotonic()
    try:
        cmd = spec["args"](binpath, root, langs)
        code, stdout, stderr = _exec_capped(
            cmd, config.ENGINE_TIMEOUT, config.MAX_SCAN_OUTPUT,
            cwd=str(root) if spec["cwd"] else None)
        try:
            doc = json.loads(stdout or "")
        except ValueError:
            raise RuntimeError(
                f"non-SARIF output (exit {code}): "
                f"{(stderr or stdout).strip()[:200]}") from None
        engine_findings = sarif_import.to_findings(doc, engine=spec["name"])
    except Exception as exc:  # noqa: BLE001 — one engine must never fail the scan
        entry["status"] = "error"
        entry["error"] = str(exc)[:300]
        emit(f"{spec['name']} failed: {str(exc)[:120]}")
        return entry, []

    entry["seconds"] = round(time.monotonic() - started, 1)
    entry["version"] = _driver_version(doc)
    if eid == "opengrep":
        entry["ruleset"] = ", ".join(config.resolve_opengrep_config(langs))

    kept = []
    for f in engine_findings:
        if not _meets_threshold(f.get("severity", "Info"), severity):
            continue
        _normalize_finding(root, f)
        kept.append(f)
    entry["status"] = "ok"
    entry["findings"] = len(kept)
    emit(f"{spec['name']}: {len(kept)} finding(s)")
    return entry, kept


def _coverage_gaps(langs: set, run_ids: list, meta: list) -> list[dict]:
    """Languages present in the scan target where a normally-enabled
    (``default_auto``) engine that covers them turned out unavailable.

    Previously this was only a fact buried in each engine's own meta entry
    (``{"status": "unavailable"}``) — visible if you went looking for that one
    engine, invisible otherwise. A repo with Go files and no gosec on PATH
    would silently fall back to whatever partial Go coverage Opengrep's
    generic rules happen to provide (or none at all) with nothing in the scan
    summary to say so.
    """
    meta_by_id = {m["engine"]: m for m in meta}
    gaps = []
    for lang in sorted(langs):
        expected = [eid for eid in run_ids
                    if ENGINES[eid].get("default_auto") and lang in ENGINES[eid]["languages"]]
        missing = [eid for eid in expected
                  if meta_by_id.get(eid, {}).get("status") == "unavailable"]
        if not missing:
            continue
        still_covered = [eid for eid in expected
                         if meta_by_id.get(eid, {}).get("status") not in ("unavailable", "error")]
        gaps.append({
            "language": lang,
            "missing_engines": [ENGINES[e]["name"] for e in missing],
            "still_covered_by": [ENGINES[e]["name"] for e in still_covered],
        })
    return gaps


def run_engines(scan_root: Path, severity: str = "Low",
                progress=None) -> tuple[list[dict], list[dict]]:
    """Run every enabled+available+applicable external engine over `scan_root`.

    Engines run concurrently on a bounded pool (they are independent subprocesses
    that mostly wait off-CPU), then their findings are merged in registry order,
    deduplicated across engines, capped at MAX_FINDINGS, and given code context.

    Returns (findings, meta): the unique findings at-or-above the severity
    threshold, and one meta entry per considered engine recording what happened
    (ok / unavailable / skipped / error), how long it took, its version, and —
    when duplicates were merged — a scan-level ``_dedup`` note.
    """
    from concurrent.futures import ThreadPoolExecutor

    def emit(msg):
        if progress:
            progress(msg)

    selected = _selected_ids()
    if not selected:
        return [], []
    if severity not in config.SEVERITY_ORDER:
        severity = "Low"

    root = Path(scan_root)
    langs = detect_languages(root)
    run_ids = [eid for eid in ENGINES if eid in selected]   # registry order

    # Fan out; collect keyed by engine id so the merge stays deterministic
    # regardless of which subprocess finishes first.
    results: dict[str, tuple[dict, list[dict]]] = {}
    workers = min(config.ENGINE_PARALLELISM, len(run_ids)) or 1
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_run_one_engine, eid, ENGINES[eid], root, langs,
                               severity, emit): eid for eid in run_ids}
        for fut in futures:
            eid = futures[fut]
            results[eid] = fut.result()   # _run_one_engine never raises

    meta = [results[eid][0] for eid in run_ids]
    merged: list[dict] = []
    for eid in run_ids:                    # registry order = dedup precedence
        merged.extend(results[eid][1])

    unique, removed = _dedup_across_engines(merged)
    if removed:
        emit(f"Merged {removed} duplicate finding(s) across engines")
        meta.append({"engine": "(dedup)", "name": "Cross-engine dedup",
                     "status": "ok", "duplicates_removed": removed,
                     "unique_findings": len(unique)})

    gaps = _coverage_gaps(langs, run_ids, meta)
    if gaps:
        for g in gaps:
            cov = (f"still covered by {', '.join(g['still_covered_by'])}"
                  if g["still_covered_by"] else "NO engine covers it this scan")
            emit(f"Coverage gap: {g['language']} — "
                f"{', '.join(g['missing_engines'])} unavailable ({cov})")
        meta.append({"engine": "(coverage)", "name": "Coverage gaps",
                     "status": "warn", "gaps": gaps})

    capped = unique[:config.MAX_FINDINGS]
    _attach_code_context(root, capped)
    return capped, meta
