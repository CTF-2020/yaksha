"""Flat, sortable, cross-report triage worklist.

The PRD's AppSec persona wants "one triage queue where duplicates are merged
and confirmed-exploitable findings float to the top with proof" instead of
reopening report after report. This module is the read-only aggregation
behind that: it reads the same ``findings`` SQL table the dashboard and
``/api/v1/reports/findings/search`` already use (report_db.search_findings),
applies the same suppression decisions the single-report viewer and dashboard
apply (suppressions.matches_row — see suppressions/engine.py), then sorts and
paginates in Python. No new storage, no new finding identity.

Unlike the dashboard's cross-report severity totals, SAST/DAST findings are
INCLUDED by default here: this is meant to be the one unified queue across
every tool, not another per-tab breakdown.
"""
from __future__ import annotations

import csv
import io

import report_db
import ssvc
import suppressions
import ownership
from suppressions.engine import matches_row

_SEV_RANK = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
_VERDICT_RANK = {"actively_exploited": 0, "confirmed_exploitable": 1, "corroborated": 2,
                 "design_gap": 3, "blind_spot": 4, "": 5}
# ssvc.ACTION_RANK already orders act < attend < track_star < track < "" --
# reused rather than duplicated so the two never drift apart.
_SSVC_RANK = ssvc.ACTION_RANK

# Column -> sort key. Each takes one finding row (report_db.search_findings shape)
# and returns a value that sorts ascending in the natural triage order (worst
# first) so the UI's default view needs no explicit ``order``.
SORT_KEYS = {
    "severity": lambda r: _SEV_RANK.get(r.get("severity"), 9),
    "verdict": lambda r: _VERDICT_RANK.get(r.get("verdict") or "", 9),
    "ssvc_action": lambda r: _SSVC_RANK.get(r.get("ssvc_action") or "", 9),
    "family": lambda r: str(r.get("family") or "").lower(),
    "rule": lambda r: str(r.get("rule") or "").lower(),
    "title": lambda r: str(r.get("title") or "").lower(),
    "report": lambda r: str(r.get("report_title") or "").lower(),
    "methodology": lambda r: str(r.get("methodology") or "").lower(),
    "created_at": lambda r: -(r.get("created_at") or 0),  # newest first by default
    # Unassigned sorts last regardless of direction's usual asc/desc flip
    # would suggest, since "no owner" is never the thing worth surfacing
    # first -- handled by the empty string sorting after any real name.
    "owner": lambda r: (str(r.get("owner") or "") == "", str(r.get("owner") or "").lower()),
}
DEFAULT_SORT = "severity"

# Hard cap on how many candidate rows are pulled from SQL before suppression
# filtering/sort/paginate happen in Python -- generous enough for any real
# install (see report_db.all_reports's own 2000-report cap) without letting an
# unbounded findings table make every triage page load scan the whole table.
_CANDIDATE_CAP = 5000


def _filtered_sorted(*, severity: str | None = None, family: str | None = None,
                     methodology: str | None = None, verdict: str | None = None,
                     ssvc_action: str | None = None,
                     owner: str | None = None,
                     q: str | None = None, sort: str = DEFAULT_SORT, order: str = "asc",
                     include_suppressed: bool = False) -> list[dict]:
    """Every matching row (suppression-aware, owner-annotated, sorted), not yet
    paginated -- the shared pipeline behind both queue() (paginated JSON) and
    export_rows() (the full filtered set, for SARIF/CSV export)."""
    sort_key = SORT_KEYS.get(sort, SORT_KEYS[DEFAULT_SORT])

    rows = report_db.search_findings(
        family=family, severity=severity, methodology=methodology,
        verdict=verdict, ssvc_action=ssvc_action, text=q, limit=_CANDIDATE_CAP, include_sast=True)

    active_supps = suppressions.active_suppressions(suppressions.load_suppressions())
    if active_supps:
        kept = []
        for row in rows:
            hit = next((s for s in active_supps if matches_row(s, row)), None)
            if hit is None:
                row["suppressed"] = False
            elif include_suppressed:
                row["suppressed"] = True
                row["suppression"] = {"id": hit.id, "reason": hit.reason,
                                      "author": hit.author, "state": hit.state}
            else:
                continue
            kept.append(row)
        rows = kept
    else:
        for row in rows:
            row["suppressed"] = False

    ownership.annotate_rows(rows)
    if owner is not None:
        # owner="" (explicit) filters to unassigned findings, same convention
        # search_findings already uses for verdict.
        rows = [r for r in rows if (r.get("owner") or "") == owner]

    rows.sort(key=sort_key, reverse=(order == "desc"))
    return rows


def queue(*, severity: str | None = None, family: str | None = None,
          methodology: str | None = None, verdict: str | None = None,
          ssvc_action: str | None = None,
          owner: str | None = None,
          q: str | None = None, sort: str = DEFAULT_SORT, order: str = "asc",
          page: int = 1, per_page: int = 50,
          include_suppressed: bool = False) -> dict:
    """The flat worklist: filtered, suppression-aware, sorted, paginated.

    ``verdict=""`` (explicit empty string) filters to never-correlated
    findings, same convention as report_db.search_findings; ``verdict=None``
    (the default) leaves verdict out of the filter. ``ssvc_action`` follows
    the identical convention. ``owner`` follows the same convention: ``""``
    filters to unassigned findings, ``None`` leaves it out.
    """
    page = max(1, page)
    per_page = max(1, min(per_page, 200))

    rows = _filtered_sorted(severity=severity, family=family, methodology=methodology,
                            verdict=verdict, ssvc_action=ssvc_action, owner=owner,
                            q=q, sort=sort, order=order,
                            include_suppressed=include_suppressed)

    total = len(rows)
    pages = max(1, -(-total // per_page))  # ceil div
    page = min(page, pages)
    start = (page - 1) * per_page
    page_rows = rows[start:start + per_page]

    return {
        "findings": page_rows, "total": total, "page": page,
        "pages": pages, "per_page": per_page,
        "severity_counts": _tally(rows, "severity"),
    }


def export_rows(*, severity: str | None = None, family: str | None = None,
                methodology: str | None = None, verdict: str | None = None,
                ssvc_action: str | None = None,
                owner: str | None = None,
                q: str | None = None, sort: str = DEFAULT_SORT, order: str = "asc",
                include_suppressed: bool = False) -> list[dict]:
    """The full filtered/sorted set, unpaginated (capped at _CANDIDATE_CAP by
    the same SQL query queue() uses) -- for bulk CSV export rather than a UI
    page."""
    return _filtered_sorted(severity=severity, family=family, methodology=methodology,
                            verdict=verdict, ssvc_action=ssvc_action, owner=owner,
                            q=q, sort=sort, order=order,
                            include_suppressed=include_suppressed)


_CSV_COLUMNS = ["severity", "verdict", "ssvc_action", "title", "family", "rule", "methodology",
                "report_title", "report_id", "path", "line", "locus", "cwe", "owasp",
                "owner", "owner_source", "suppressed", "finding_id"]


def to_csv(rows: list[dict]) -> str:
    """Render finding rows (report_db.search_findings shape) as CSV text."""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=_CSV_COLUMNS, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return buf.getvalue()


def _tally(rows: list[dict], field: str) -> dict:
    counts: dict[str, int] = {}
    for r in rows:
        v = r.get(field) or "?"
        counts[v] = counts.get(v, 0) + 1
    return counts
