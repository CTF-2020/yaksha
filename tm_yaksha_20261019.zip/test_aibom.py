"""AI-BOM module tests (stdlib unittest).

Run from the tm project root:
    python -m unittest test_aibom

Engine tests build synthetic working trees on disk and scan them, so manifest
parsing, AST imports, content signals, artifact handling, and the context
gating are exercised against real files rather than mocks.
"""
from __future__ import annotations

import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

# Isolate all module state before anything imports the configs.
_TMP = tempfile.mkdtemp(prefix="tm_aibom_test_")
os.environ["TM_AIBOM_DIR"] = os.path.join(_TMP, "aibom_state")
os.environ.setdefault("TM_BROKER_DIR", os.path.join(_TMP, "broker_state"))
os.environ.setdefault("TM_BROKER_WORKSPACE", os.path.join(_TMP, "broker_ws"))

from aibom import config, db, engine, mapper, service  # noqa: E402
from aibom import signatures as sig                     # noqa: E402

# Deliberately fake credentials (structure-valid, never real).
_FAKE_ANT_KEY = "sk-ant-api03-" + "A" * 40
_FAKE_OAI_KEY = "sk-proj-" + "B" * 40


def _write(root: Path, rel: str, content: str | bytes) -> None:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, bytes):
        path.write_bytes(content)
    else:
        path.write_text(content, encoding="utf-8")


def _build_ai_repo(root: Path) -> None:
    _write(root, "requirements.txt",
           "flask==3.0.0\nanthropic\nopenai==1.40.0\nchromadb>=0.5\n")
    _write(root, "package.json", json.dumps({
        "name": "web", "dependencies": {
            "@anthropic-ai/sdk": "^0.27.0", "ai": "^3.0.0", "express": "^4.19.0"}}))
    _write(root, "app.py", "\n".join([
        "import os",
        "import openai",
        "from anthropic import Anthropic",
        "from flask import request",
        "",
        f'LEAKED = "{_FAKE_ANT_KEY}"',
        'BASE = "https://api.openai.com/v1"',
        'client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])',
        'MODEL = "claude-sonnet-4-20250514"',
        'ALIAS = "claude-3-5-haiku-latest"',
        "def handle():",
        '    prompt = "Summarize: " + request.args.get("q")',
        "    resp = client.messages.create(model=MODEL, messages=[])",
        "    os.system(resp.content)",
    ]))
    _write(root, "agent.py", "\n".join([
        "import subprocess",
        "from langchain.tools import tool",
        "",
        "@tool",
        "def run_shell(cmd: str) -> str:",
        "    return subprocess.run(cmd, shell=True, capture_output=True).stdout",
    ]))
    _write(root, "rag.py", "\n".join([
        "import chromadb",
        "def search(db, query):",
        "    return db.similarity_search(query)",
    ]))
    _write(root, "mcp_server.py", "from mcp.server import Server\n")
    _write(root, "hf.py", "\n".join([
        "from transformers import AutoModel",
        'model = AutoModel.from_pretrained("bert-base-uncased")',
    ]))
    _write(root, ".env", f"OPENAI_API_KEY={_FAKE_OAI_KEY}\nDEBUG=1\n")
    _write(root, "models/classifier.pkl", b"\x80\x04fake")
    _write(root, "weights.gguf", b"GGUFfake")
    # Must be skipped entirely:
    _write(root, "node_modules/evil/index.js", f'const k = "{_FAKE_ANT_KEY}";')


def _ids(result: dict) -> set[str]:
    return {f["id"] for f in result["findings"]}


def _component(result: dict, ctype: str, name: str) -> dict | None:
    return next((c for c in result["components"]
                 if c["type"] == ctype and c["name"].lower() == name.lower()), None)


# ── Engine ────────────────────────────────────────────────────────────────────
class TestEngineAiRepo(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(tempfile.mkdtemp(prefix="aibom_repo_"))
        _build_ai_repo(cls.root)
        cls.result = engine.scan(cls.root)

    def test_manifest_components(self):
        anthropic = _component(self.result, "library", "anthropic")
        self.assertIsNotNone(anthropic)
        self.assertEqual(anthropic["provider"], "Anthropic")
        self.assertIn("manifest:requirements.txt", anthropic["sources"])
        self.assertIn("import", anthropic["sources"])          # AST pass merged in
        openai_lib = _component(self.result, "library", "openai")
        self.assertEqual(openai_lib["version"], "1.40.0")
        self.assertIsNotNone(_component(self.result, "library", "chromadb"))
        self.assertIsNotNone(_component(self.result, "library", "@anthropic-ai/sdk"))
        self.assertIsNotNone(_component(self.result, "library", "ai"))
        self.assertIsNone(_component(self.result, "library", "express"))
        self.assertIsNone(_component(self.result, "library", "flask"))

    def test_model_endpoint_credential_components(self):
        model = _component(self.result, "model", "claude-sonnet-4-20250514")
        self.assertIsNotNone(model)
        self.assertEqual(model["provider"], "Anthropic")
        self.assertIsNotNone(_component(self.result, "endpoint", "api.openai.com"))
        self.assertIsNotNone(_component(self.result, "credential-ref", "ANTHROPIC_API_KEY"))
        self.assertIsNotNone(_component(self.result, "credential-ref", "OPENAI_API_KEY"))
        self.assertIsNotNone(_component(self.result, "model-artifact", "weights.gguf"))
        self.assertIsNotNone(_component(self.result, "model-artifact", "classifier.pkl"))

    def test_risk_findings_present(self):
        ids = _ids(self.result)
        for expected in ("AIBOM-KEY-001", "AIBOM-KEY-002", "AIBOM-INJ-001",
                         "AIBOM-OUT-001", "AIBOM-AGY-001", "AIBOM-SUP-001",
                         "AIBOM-SUP-002", "AIBOM-SUP-003", "AIBOM-MOD-001",
                         "AIBOM-MCP-001", "AIBOM-RAG-001", "AIBOM-AGN-001"):
            self.assertIn(expected, ids)

    def test_hardcoded_key_is_critical_and_redacted(self):
        key_findings = [f for f in self.result["findings"] if f["id"] == "AIBOM-KEY-001"]
        self.assertTrue(key_findings)
        self.assertEqual(key_findings[0]["severity"], "Critical")
        for f in self.result["findings"]:
            self.assertNotIn(_FAKE_ANT_KEY, f["snippet"])
            self.assertNotIn(_FAKE_OAI_KEY, f["snippet"])
        self.assertIn("REDACTED", key_findings[0]["snippet"])

    def test_unpinned_only_fires_for_unpinned_ai_deps(self):
        unpinned = [f for f in self.result["findings"] if f["id"] == "AIBOM-SUP-002"]
        self.assertEqual({f["title"].split("— ")[-1] for f in unpinned}, {"anthropic"})

    def test_skip_dirs_are_skipped(self):
        for f in self.result["findings"]:
            self.assertNotIn("node_modules", f["file"])
        for c in self.result["components"]:
            for ev in c["evidence"]:
                self.assertNotIn("node_modules", ev["file"])

    def test_stats_and_flags(self):
        stats = self.result["stats"]
        self.assertTrue(stats["ai_detected"])
        self.assertIn("Anthropic", stats["providers"])
        self.assertIn("claude-sonnet-4-20250514", stats["models"])
        for flag in ("provider_apis", "local_models", "rag", "agents", "mcp"):
            self.assertTrue(stats["flags"][flag], flag)


class TestEngineCleanAndGating(unittest.TestCase):
    def test_clean_repo_has_nothing(self):
        root = Path(tempfile.mkdtemp(prefix="aibom_clean_"))
        _write(root, "main.py", "import json\nprint(json.dumps({}))\n")
        _write(root, "requirements.txt", "flask==3.0.0\nrequests==2.32.0\n")
        result = engine.scan(root)
        self.assertEqual(result["components"], [])
        self.assertEqual(result["findings"], [])
        self.assertFalse(result["stats"]["ai_detected"])

    def test_lone_pickle_does_not_create_ai_context(self):
        root = Path(tempfile.mkdtemp(prefix="aibom_pkl_"))
        _write(root, "models/classifier.pkl", b"\x80\x04fake")
        result = engine.scan(root)
        self.assertNotIn("AIBOM-SUP-001", _ids(result))     # gated: no AI context
        self.assertFalse(result["stats"]["ai_detected"])

    def test_plain_subprocess_use_is_quiet(self):
        root = Path(tempfile.mkdtemp(prefix="aibom_sub_"))
        _write(root, "ops.py", "import subprocess\nsubprocess.run(['ls'])\n")
        result = engine.scan(root)
        self.assertEqual(result["findings"], [])


# ── Mapper ────────────────────────────────────────────────────────────────────
class TestMapper(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root = Path(tempfile.mkdtemp(prefix="aibom_map_"))
        _build_ai_repo(root)
        cls.result = engine.scan(root)
        cls.repo = {"id": "web-app", "name": "web-app"}
        cls.meta = {"commit": "abc1234", "branch": "main"}

    def test_report_shape(self):
        report = mapper.result_to_report(self.result, self.repo, self.meta)
        self.assertEqual(report["methodology"], "aibom")
        self.assertEqual(report["overall_risk"], "Critical")
        self.assertEqual(report["categories"][0]["id"], "AIBOM-INVENTORY")
        self.assertTrue(report["recommendations"])
        self.assertIn("web-app", report["title"])
        self.assertTrue(report["scan_metadata"]["ai_detected"])
        # Non-inventory categories ordered worst severity first.
        sev_order = {s: i for i, s in enumerate(sig.SEVERITIES)}
        risks = [sev_order[c["risk"]] for c in report["categories"][1:]]
        self.assertEqual(risks, sorted(risks))

    def test_cyclonedx_document(self):
        bom = mapper.to_cyclonedx(self.result, self.repo, self.meta)
        self.assertEqual(bom["bomFormat"], "CycloneDX")
        self.assertEqual(bom["specVersion"], "1.6")
        self.assertEqual(bom["metadata"]["component"]["name"], "web-app")
        purls = {c.get("purl") for c in bom["components"]}
        self.assertIn("pkg:pypi/openai@1.40.0", purls)
        self.assertIn("pkg:npm/@anthropic-ai/sdk@0.27.0", purls)
        types = {c["type"] for c in bom["components"]}
        self.assertIn("machine-learning-model", types)
        self.assertIn("api.openai.com", {s["name"] for s in bom["services"]})
        # Redaction holds all the way into the BOM document.
        blob = json.dumps(bom)
        self.assertNotIn(_FAKE_ANT_KEY, blob)

    def test_rollup(self):
        roll = mapper.to_rollup(self.result, self.repo, self.meta, "aibom_1_ab", "rpt_1")
        self.assertEqual(roll["repo_id"], "web-app")
        self.assertTrue(roll["ai_detected"])
        self.assertEqual(roll["overall_risk"], "Critical")
        self.assertIn("Anthropic", roll["providers"])


def _isolate_aibom_store(testcase: unittest.TestCase) -> None:
    """Redirect the aibom job/bom/inventory store to a fresh temp dir.

    The `TM_AIBOM_DIR` env var set at the top of this file only isolates
    `aibom.config` the *first* time it's imported in the process — under a
    full `pytest .` run, some other test file (anything importing `app`)
    typically imports it first with the real `~/.tm_aibom` paths already
    baked into its module-level constants, so this file's env-var trick
    silently no-ops and any test that actually writes a job/bom corrupts the
    real store. Patching the already-imported constants directly is immune
    to import order.
    """
    tmp = Path(tempfile.mkdtemp(prefix="tm_aibom_isolate_"))
    state_dir = tmp / "aibom_state"
    bom_dir = state_dir / "boms"
    latest_dir = state_dir / "latest"
    bom_dir.mkdir(parents=True, exist_ok=True)
    latest_dir.mkdir(parents=True, exist_ok=True)
    for target, attr, value in (
        (config, "STATE_DIR", state_dir),
        (config, "JOBS_PATH", state_dir / "jobs.json"),
        (config, "BOM_DIR", bom_dir),
        (config, "LATEST_DIR", latest_dir),
        (db, "DB_PATH", state_dir / "aibom.db"),
    ):
        patcher = mock.patch.object(target, attr, value)
        patcher.start()
        testcase.addCleanup(patcher.stop)


# ── Config persistence ────────────────────────────────────────────────────────
class TestConfig(unittest.TestCase):
    def setUp(self):
        _isolate_aibom_store(self)

    def test_job_id_safety(self):
        self.assertTrue(config.is_safe_job_id("aibom_1720000000_a1b2c3"))
        for bad in ("", "x", "../../etc", "aibom_1_zz/..", "aibom_1_A1B2C3",
                    "dast_1720000000_a1b2c3"):
            self.assertFalse(config.is_safe_job_id(bad), bad)

    def test_bom_roundtrip_and_unsafe_rejection(self):
        job_id = f"aibom_{int(time.time())}_abc123"
        config.save_bom(job_id, {"bomFormat": "CycloneDX"})
        self.assertEqual(config.load_bom(job_id)["bomFormat"], "CycloneDX")
        self.assertIsNone(config.load_bom("../evil"))
        with self.assertRaises(ValueError):
            config.save_bom("../evil", {})


# ── Service end-to-end (local repo, report saving stubbed) ────────────────────
class TestServiceEndToEnd(unittest.TestCase):
    def setUp(self):
        _isolate_aibom_store(self)

    def test_scan_local_repo_produces_report_bom_and_rollup(self):
        root = Path(tempfile.mkdtemp(prefix="aibom_svc_"))
        _build_ai_repo(root)
        saved = {}

        def fake_save(report):
            saved["report"] = report
            return "rpt_aibom_test"

        orig = service.AibomService._save_report
        service.AibomService._save_report = staticmethod(fake_save)
        try:
            svc = service.AibomService()
            repo = {"id": "svc-repo", "name": "svc-repo", "url": str(root)}
            job_id = svc.submit_scan(repo)
            deadline = time.time() + 30
            job = svc.get_job(job_id)
            while job["status"] in ("queued", "running") and time.time() < deadline:
                time.sleep(0.1)
                job = svc.get_job(job_id)
            self.assertEqual(job["status"], "done", job.get("error"))
            self.assertEqual(job["report_id"], "rpt_aibom_test")
            self.assertTrue(job["bom_available"])
            self.assertTrue(job["stats"]["ai_detected"])
            self.assertEqual(saved["report"]["methodology"], "aibom")
            self.assertIsNotNone(config.load_bom(job_id))
            inventory = config.load_inventory()
            self.assertIn("svc-repo", [e["repo_id"] for e in inventory])
            # Re-submitting while nothing is running yields a fresh job id shape.
            self.assertTrue(config.is_safe_job_id(job_id))
        finally:
            service.AibomService._save_report = orig

    def test_missing_local_path_errors_cleanly(self):
        svc = service.AibomService()
        repo = {"id": "ghost", "name": "ghost", "url": str(Path(_TMP) / "nope")}
        job_id = svc.submit_scan(repo)
        deadline = time.time() + 15
        job = svc.get_job(job_id)
        while job["status"] in ("queued", "running") and time.time() < deadline:
            time.sleep(0.1)
            job = svc.get_job(job_id)
        self.assertEqual(job["status"], "error")
        self.assertIn("does not exist", job["error"])


# ── API through the Flask app ─────────────────────────────────────────────────
class TestApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()
        token = json.loads(cls.client.get("/api/csrf-token").data)["token"]
        cls.hdr = {"X-CSRF-Token": token, "Content-Type": "application/json"}

    def test_status(self):
        d = json.loads(self.client.get("/api/v1/aibom").data)
        self.assertTrue(d["success"])
        self.assertGreater(d["signatures"]["py_packages"], 40)
        self.assertGreater(d["signatures"]["risk_rules"], 8)

    def test_dashboard_page(self):
        r = self.client.get("/aibom")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"AI-BOM", r.data)

    def test_repos_listed(self):
        d = json.loads(self.client.get("/api/v1/aibom/repos").data)
        self.assertTrue(d["success"])
        self.assertIsInstance(d["repos"], list)

    def test_scan_unknown_repo_404(self):
        r = self.client.post("/api/v1/aibom/repos/no-such-repo/scan",
                             headers=self.hdr, data="{}")
        self.assertEqual(r.status_code, 404)

    def test_bad_ids_rejected(self):
        r = self.client.post("/api/v1/aibom/repos/..%2fevil/scan",
                             headers=self.hdr, data="{}")
        self.assertIn(r.status_code, (400, 404))
        # Werkzeug normalizes the traversal out of the path (404) before our
        # own guard (400) could even see it; either rejection is correct.
        r = self.client.get("/api/v1/aibom/jobs/..%2fevil/bom")
        self.assertIn(r.status_code, (400, 404))
        r = self.client.get("/api/v1/aibom/jobs/evil..id/bom")
        self.assertEqual(r.status_code, 400)
        r = self.client.get("/api/v1/aibom/jobs/aibom_1_ffffff")
        self.assertEqual(r.status_code, 404)

    def test_inventory_endpoint(self):
        d = json.loads(self.client.get("/api/v1/aibom/inventory").data)
        self.assertTrue(d["success"])
        self.assertIn("totals", d)


if __name__ == "__main__":
    unittest.main()
