"""Lightweight, regex-based extraction from configuration files.

Half of a system's real security posture lives in config, not code: TLS, CORS,
security headers, container privilege, and hardcoded secrets in env files. A full
parser per format is out of scope for the MVP, so this uses targeted line
patterns and feeds the same :class:`SystemModel` (secrets, external calls,
controls, trust boundaries) the AST extractor populates.
"""
from __future__ import annotations

import re

from .model import Control, ExternalCall, Secret, TrustBoundary

_CONFIG_NAMES = ("dockerfile",)
_CONFIG_SUFFIXES = (".env", ".yml", ".yaml", ".tf", ".ini", ".cfg", ".toml", ".conf")

_ENV_SECRET_RE = re.compile(
    r'^\s*([A-Za-z0-9_]*(?:PASSWORD|SECRET|TOKEN|API[_-]?KEY|ACCESS[_-]?KEY|'
    r'PRIVATE[_-]?KEY|CREDENTIAL)[A-Za-z0-9_]*)\s*[=:]\s*(.+?)\s*$', re.I)
_URL_RE = re.compile(r'https?://[^\s"\'<>]+', re.I)
_CLEARTEXT_RE = re.compile(r'http://[^\s"\'<>]+', re.I)


def is_config_file(lower_path: str) -> bool:
    base = lower_path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    if any(base == n or base.startswith(n + ".") for n in _CONFIG_NAMES):
        return True
    return base.startswith(".env") or lower_path.endswith(_CONFIG_SUFFIXES)


def extract(source: str, rel: str, model) -> None:
    base = rel.rsplit("/", 1)[-1].lower()
    if base == "dockerfile" or base.startswith("dockerfile."):
        _extract_dockerfile(source, rel, model)
    elif base.startswith(".env"):
        _extract_env(source, rel, model)
    else:
        _extract_generic(source, rel, model)


def _extract_env(source: str, rel: str, model) -> None:
    for i, line in enumerate(source.splitlines(), 1):
        if line.lstrip().startswith("#"):
            continue
        m = _ENV_SECRET_RE.match(line)
        if m:
            value = m.group(2).strip().strip('"\'')
            placeholder = value in ("", "changeme", "your-secret", "xxx") \
                or value.startswith("${") or value.startswith("$(")
            model.secrets.append(
                Secret(m.group(1), rel, i, managed=placeholder))


def _extract_dockerfile(source: str, rel: str, model) -> None:
    runs_as_root = True
    for i, line in enumerate(source.splitlines(), 1):
        stripped = line.strip()
        low = stripped.lower()
        if low.startswith("user ") and "root" not in low:
            runs_as_root = False
        if low.startswith("env ") or low.startswith("arg "):
            m = _ENV_SECRET_RE.match(stripped[4:])
            if m and m.group(2).strip():
                model.secrets.append(Secret(m.group(1), rel, i, managed=False))
        for url in _CLEARTEXT_RE.findall(stripped):
            model.external_calls.append(ExternalCall("http", "dockerfile", rel, i, encrypted=False))
    if runs_as_root:
        model.trust_boundaries.append(TrustBoundary(
            "Container runs as root", "privilege",
            f"{rel} sets no non-root USER — a container escape runs as root on the host."))


def _extract_generic(source: str, rel: str, model) -> None:
    low = source.lower()
    # CORS wildcard
    if re.search(r'(allow[_-]?origin[s]?["\']?\s*[:=]\s*["\']?\*)', low) \
            or "access-control-allow-origin: *" in low:
        model.controls.append(Control("headers", "CORS: * (permissive)", "global", rel, 0))
        model.trust_boundaries.append(TrustBoundary(
            "Permissive CORS", "network",
            f"{rel} allows any origin (Access-Control-Allow-Origin: *)."))
    # TLS disabled hints
    if re.search(r'(ssl|tls)[_-]?(verify|enabled?)\s*[:=]\s*(false|0|no|off)', low):
        model.controls.append(Control("tls", "TLS verification disabled", "global", rel, 0))
    # debug enabled
    if re.search(r'debug\s*[:=]\s*(true|1|on)\b', low):
        model.controls.append(Control("headers", "debug mode enabled", "global", rel, 0))
    # cleartext service URLs
    for _ in _CLEARTEXT_RE.findall(source):
        model.external_calls.append(ExternalCall("http", "config", rel, 0, encrypted=False))
        break
