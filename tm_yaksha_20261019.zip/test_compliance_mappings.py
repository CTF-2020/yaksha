"""Regression tests for compliance_mappings.py's category-id -> control lookup.

owasp.py and offline_patterns.py's _framework_report stamp category ids with a
display-year suffix ("A01:2021", "API1:2023") that must be stripped before the
bare-key OWASP_*_COMPLIANCE tables are looked up — otherwise a real, populated
table is silently never reached.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import compliance_mappings
import report_db


class GetControlsColonSuffixTests(unittest.TestCase):
    def test_bare_key_still_resolves(self):
        controls = compliance_mappings.get_controls("A01")
        self.assertTrue(controls)

    def test_owasp_web_colon_suffix_resolves_to_bare_key(self):
        controls = compliance_mappings.get_controls("A01:2021")
        self.assertTrue(controls, "A01:2021 should resolve to OWASP_WEB_COMPLIANCE's A01 entry")
        self.assertEqual(controls, compliance_mappings.get_controls("A01"))

    def test_owasp_api_colon_suffix_routes_to_api_ruleset(self):
        controls = compliance_mappings.get_controls("API1:2023")
        self.assertTrue(controls, "API1:2023 should resolve to OWASP_API_COMPLIANCE's API1 entry")
        self.assertEqual(controls, compliance_mappings.get_controls("API1", ruleset="api"))

    def test_unknown_colon_suffixed_category_returns_empty_not_error(self):
        self.assertEqual(compliance_mappings.get_controls("A99:2021"), [])


class EnrichCategoriesColonSuffixTests(unittest.TestCase):
    def test_enrich_categories_populates_compliance_controls_for_colon_suffixed_id(self):
        categories = [{"id": "A02:2021", "name": "Cryptographic Failures"}]
        compliance_mappings.enrich_categories(categories)
        self.assertTrue(categories[0]["compliance_controls"])
        self.assertTrue(categories[0]["compliance_frameworks"])


def _cat(cid, risk, title=None, verdict=None):
    cat = {"id": cid, "name": title or cid, "title": title or cid, "risk": risk}
    if verdict:
        cat["verdict"] = verdict
    compliance_mappings.enrich_categories([cat])
    return cat


class WeightedComplianceSummaryTests(unittest.TestCase):
    def test_same_severity_no_verdict_keeps_severity_as_impact(self):
        cats = [_cat("A01", "High", "Broken Access Control")]
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        entry = weighted["SOC 2"][0]
        self.assertEqual(entry["control_id"], "CC6.1")
        self.assertEqual(entry["impact"], "High")
        self.assertEqual(entry["verdict"], "")
        self.assertEqual(entry["finding"], "Broken Access Control")

    def test_actively_exploited_escalates_impact_two_tiers(self):
        # Medium base + actively_exploited bump(2) -> Critical (index 2-2=0)
        cats = [_cat("A03", "Medium", "SQL Injection", verdict="actively_exploited")]
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        entry = next(e for e in weighted["SOC 2"] if e["control_id"] == "CC8.1")
        self.assertEqual(entry["impact"], "Critical")
        self.assertEqual(entry["verdict"], "actively_exploited")

    def test_confirmed_exploitable_escalates_impact_one_tier(self):
        cats = [_cat("A03", "Medium", "SQL Injection", verdict="confirmed_exploitable")]
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        entry = next(e for e in weighted["SOC 2"] if e["control_id"] == "CC8.1")
        self.assertEqual(entry["impact"], "High")

    def test_bump_floors_at_critical_not_below(self):
        cats = [_cat("A01", "Critical", "Broken Access Control", verdict="actively_exploited")]
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        entry = weighted["SOC 2"][0]
        self.assertEqual(entry["impact"], "Critical")

    def test_corroborated_design_gap_blind_spot_do_not_escalate(self):
        for verdict in ("corroborated", "design_gap", "blind_spot"):
            with self.subTest(verdict=verdict):
                cats = [_cat("A01", "High", "Broken Access Control", verdict=verdict)]
                weighted = compliance_mappings.weighted_compliance_summary(cats)
                entry = weighted["SOC 2"][0]
                self.assertEqual(entry["impact"], "High")
                self.assertEqual(entry["verdict"], verdict)

    def test_low_severity_findings_are_excluded(self):
        cats = [_cat("A01", "Low", "Minor issue")]
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        self.assertEqual(weighted, {})

    def test_worst_finding_wins_when_multiple_share_a_control(self):
        # Both A01 findings map to SOC2 CC6.1; the actively-exploited one
        # must set the control's impact/finding, not whichever came first.
        cats = [_cat("A01", "Medium", "Weak session config"),
               _cat("A01", "Medium", "Auth bypass", verdict="actively_exploited")]
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        entry = weighted["SOC 2"][0]
        self.assertEqual(entry["control_id"], "CC6.1")
        self.assertEqual(entry["impact"], "Critical")
        self.assertEqual(entry["finding"], "Auth bypass")
        self.assertEqual(entry["finding_count"], 2)

    def test_sorted_worst_impact_first_within_a_framework(self):
        cats = [_cat("A03", "Medium", "SQLi", verdict="corroborated"),   # stays Medium
               _cat("A05", "High", "Misconfig")]                        # stays High -> should sort before Medium
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        pci = weighted["PCI DSS 4.0"]
        impacts = [e["impact"] for e in pci]
        self.assertEqual(impacts, sorted(impacts, key=lambda i: compliance_mappings._IMPACT_TIERS.index(i)))

    def test_unverdicted_finding_unaffected_by_bump_table(self):
        cats = [_cat("A01", "High", "Broken Access Control", verdict=None)]
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        self.assertEqual(weighted["SOC 2"][0]["impact"], "High")

    def test_no_qualifying_findings_returns_empty_dict(self):
        self.assertEqual(compliance_mappings.weighted_compliance_summary([]), {})

    def test_flat_and_weighted_summaries_agree_on_which_controls_fail(self):
        cats = [_cat("A01", "Critical", "Auth bypass", verdict="actively_exploited"),
               _cat("A02", "Medium", "Weak crypto")]
        flat = compliance_mappings.compliance_summary(cats)
        weighted = compliance_mappings.weighted_compliance_summary(cats)
        for fw in flat:
            flat_ids = set(flat[fw])
            weighted_ids = {e["control_id"] for e in weighted.get(fw, [])}
            self.assertEqual(flat_ids, weighted_ids, fw)


class EnrichComplianceEndpointTests(unittest.TestCase):
    """The /enrich/compliance route must persist both the legacy flat gap
    summary and the new verdict-weighted one on the saved report."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.tm_app = tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._op = report_db.DB_PATH
        self.addCleanup(lambda: setattr(report_db, "DB_PATH", self._op))
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()

    def test_enrich_endpoint_returns_and_persists_weighted_summary(self):
        report = {
            "id": "100_1_cxtest01", "title": "Compliance test", "methodology": "codemodel",
            "overall_risk": "Critical",
            "categories": [{"id": "A01", "name": "Broken Access Control", "risk": "Critical",
                           "verdict": "actively_exploited"}],
        }
        report_db.upsert_report(report)
        resp = self.client.get(f"/api/reports/{report['id']}/enrich/compliance")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertIn("compliance_gap_weighted", d)
        entry = d["compliance_gap_weighted"]["SOC 2"][0]
        self.assertEqual(entry["impact"], "Critical")
        self.assertEqual(entry["verdict"], "actively_exploited")

        saved = report_db.get_report(report["id"])
        self.assertIn("compliance_gap_weighted", saved)
        self.assertIn("compliance_gap_summary", saved)


if __name__ == "__main__":
    unittest.main()
