"""Tests for epss_kev.py — EPSS/KEV caching, lookup and CVE extraction.

Run:  python -m unittest test_epss_kev   (stdlib only, no pytest needed)

Every test isolates the on-disk cache to a temp directory (swap ``_CACHE``,
restore in ``addCleanup`` — the same idiom test_confidence_decay.py uses for
DB_PATH) so nothing here ever touches the real data/epss_kev_cache.json a
live refresh writes to. Network calls (refresh_kev/refresh_epss) are
exercised against a stub urlopen, never the real network — this suite must
pass offline and in CI.
"""
from __future__ import annotations

import json
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest import mock

import epss_kev


def _kev_response(entries):
    return json.dumps({"vulnerabilities": entries}).encode("utf-8")


def _epss_response(rows):
    return json.dumps({"data": rows}).encode("utf-8")


class _StubResponse:
    def __init__(self, body: bytes):
        self._body = body

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class EpssKevTestCase(unittest.TestCase):
    def setUp(self):
        self._orig = epss_kev._CACHE
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        self.addCleanup(lambda: setattr(epss_kev, "_CACHE", self._orig))
        epss_kev._CACHE = Path(self._td.name) / "epss_kev_cache.json"


class ExtractCvesTests(unittest.TestCase):
    def test_extracts_and_normalizes(self):
        found = epss_kev.extract_cves("Exploiting known vulnerability cve-2021-44228 in log4j")
        self.assertEqual(found, frozenset({"CVE-2021-44228"}))

    def test_multiple_blobs_and_ids(self):
        found = epss_kev.extract_cves("see CVE-2020-1234", "and CVE-2019-0001, also CVE-2020-1234")
        self.assertEqual(found, frozenset({"CVE-2020-1234", "CVE-2019-0001"}))

    def test_no_match_returns_empty_frozenset(self):
        self.assertEqual(epss_kev.extract_cves("nothing here", ""), frozenset())

    def test_ignores_short_malformed_ids(self):
        # "CVE-99-1" doesn't match the 4-digit-year, 4+-digit-sequence shape.
        self.assertEqual(epss_kev.extract_cves("CVE-99-1"), frozenset())


class CacheLoadSaveTests(EpssKevTestCase):
    def test_missing_cache_file_is_empty(self):
        self.assertIsNone(epss_kev.lookup("CVE-2021-44228"))
        status = epss_kev.cache_status()
        self.assertEqual(status["kev_count"], 0)
        self.assertEqual(status["epss_count"], 0)
        self.assertIsNone(status["kev_updated_at"])

    def test_corrupt_cache_file_treated_as_empty(self):
        epss_kev._CACHE.parent.mkdir(parents=True, exist_ok=True)
        epss_kev._CACHE.write_text("{not valid json", encoding="utf-8")
        self.assertIsNone(epss_kev.lookup("CVE-2021-44228"))

    def test_save_is_atomic_no_tmp_left_behind(self):
        epss_kev._save(epss_kev._empty_cache())
        self.assertTrue(epss_kev._CACHE.exists())
        self.assertFalse(epss_kev._CACHE.with_suffix(".json.tmp").exists())


class LookupTests(EpssKevTestCase):
    def _seed(self, kev=None, epss=None):
        data = epss_kev._empty_cache()
        data["kev"] = kev or {}
        data["epss"] = epss or {}
        epss_kev._save(data)

    def test_lookup_unknown_cve_is_none(self):
        self._seed()
        self.assertIsNone(epss_kev.lookup("CVE-2099-99999"))

    def test_lookup_kev_only(self):
        self._seed(kev={"CVE-2021-44228": {"date_added": "2021-12-10",
                                            "vendor_project": "Apache",
                                            "product": "Log4j2", "ransomware": "Known"}})
        fact = epss_kev.lookup("cve-2021-44228")   # lowercase input normalizes
        self.assertEqual(fact["cve"], "CVE-2021-44228")
        self.assertTrue(fact["kev"])
        self.assertEqual(fact["kev_date_added"], "2021-12-10")
        self.assertEqual(fact["kev_ransomware"], "Known")
        self.assertIsNone(fact["epss"])

    def test_lookup_epss_only(self):
        self._seed(epss={"CVE-2020-1234": {"score": 0.42, "percentile": 0.7, "date": "2026-01-01"}})
        fact = epss_kev.lookup("CVE-2020-1234")
        self.assertFalse(fact["kev"])
        self.assertAlmostEqual(fact["epss"], 0.42)
        self.assertAlmostEqual(fact["epss_percentile"], 0.7)

    def test_lookup_both_sources(self):
        self._seed(
            kev={"CVE-2021-44228": {"date_added": "2021-12-10", "ransomware": "Known"}},
            epss={"CVE-2021-44228": {"score": 0.99, "percentile": 0.999, "date": "2026-01-01"}},
        )
        fact = epss_kev.lookup("CVE-2021-44228")
        self.assertTrue(fact["kev"])
        self.assertAlmostEqual(fact["epss"], 0.99)

    def test_lookup_empty_string_is_none(self):
        self._seed()
        self.assertIsNone(epss_kev.lookup(""))
        self.assertIsNone(epss_kev.lookup("   "))

    def test_combined_lookup_only_returns_known_cves(self):
        self._seed(kev={"CVE-2021-44228": {"date_added": "2021-12-10"}})
        table = epss_kev.combined_lookup(["CVE-2021-44228", "CVE-9999-0001", ""])
        self.assertEqual(set(table), {"CVE-2021-44228"})


class RefreshKevTests(EpssKevTestCase):
    def test_refresh_kev_populates_cache(self):
        entries = [
            {"cveID": "CVE-2021-44228", "dateAdded": "2021-12-10",
             "vendorProject": "Apache", "product": "Log4j2",
             "knownRansomwareCampaignUse": "Known"},
            {"cveID": "CVE-2022-22965", "dateAdded": "2022-04-01",
             "vendorProject": "VMware", "product": "Spring", "knownRansomwareCampaignUse": "Unknown"},
        ]
        with mock.patch.object(epss_kev.urllib.request, "urlopen",
                               return_value=_StubResponse(_kev_response(entries))):
            count = epss_kev.refresh_kev()
        self.assertEqual(count, 2)
        fact = epss_kev.lookup("CVE-2021-44228")
        self.assertTrue(fact["kev"])
        self.assertEqual(fact["kev_ransomware"], "Known")
        status = epss_kev.cache_status()
        self.assertEqual(status["kev_count"], 2)
        self.assertIsNotNone(status["kev_updated_at"])

    def test_refresh_kev_replaces_wholesale(self):
        self._seed_kev({"CVE-STALE-0001": {"date_added": "2000-01-01"}})
        with mock.patch.object(epss_kev.urllib.request, "urlopen",
                               return_value=_StubResponse(_kev_response([
                                   {"cveID": "CVE-2021-44228", "dateAdded": "2021-12-10"}]))):
            epss_kev.refresh_kev()
        self.assertIsNone(epss_kev.lookup("CVE-STALE-0001"))
        self.assertIsNotNone(epss_kev.lookup("CVE-2021-44228"))

    def _seed_kev(self, kev):
        data = epss_kev._empty_cache()
        data["kev"] = kev
        epss_kev._save(data)

    def test_refresh_kev_network_failure_leaves_cache_untouched(self):
        self._seed_kev({"CVE-2021-44228": {"date_added": "2021-12-10"}})
        with mock.patch.object(epss_kev.urllib.request, "urlopen",
                               side_effect=urllib.error.URLError("boom")):
            with self.assertRaises(urllib.error.URLError):
                epss_kev.refresh_kev()
        # existing entry survived the failed refresh
        self.assertIsNotNone(epss_kev.lookup("CVE-2021-44228"))

    def test_refresh_kev_skips_entries_without_cve_id(self):
        with mock.patch.object(epss_kev.urllib.request, "urlopen",
                               return_value=_StubResponse(_kev_response([
                                   {"dateAdded": "2021-12-10"},   # no cveID
                                   {"cveID": "CVE-2021-44228", "dateAdded": "2021-12-10"},
                               ]))):
            count = epss_kev.refresh_kev()
        self.assertEqual(count, 1)


class RefreshEpssTests(EpssKevTestCase):
    def test_refresh_epss_empty_input_is_noop(self):
        self.assertEqual(epss_kev.refresh_epss([]), 0)
        status = epss_kev.cache_status()
        self.assertEqual(status["epss_count"], 0)
        self.assertIsNone(status["epss_updated_at"])

    def test_refresh_epss_populates_cache(self):
        rows = [{"cve": "CVE-2021-44228", "epss": "0.99999", "percentile": "1.00000",
                 "date": "2026-01-01"}]
        with mock.patch.object(epss_kev.urllib.request, "urlopen",
                               return_value=_StubResponse(_epss_response(rows))):
            count = epss_kev.refresh_epss(["CVE-2021-44228"])
        self.assertEqual(count, 1)
        fact = epss_kev.lookup("CVE-2021-44228")
        self.assertAlmostEqual(fact["epss"], 0.99999, places=4)

    def test_refresh_epss_batches_large_input(self):
        ids = [f"CVE-2020-{i:04d}" for i in range(1, 251)]   # 3 batches of 100
        calls = []

        def fake_urlopen(req, timeout=None):
            calls.append(req.full_url)
            batch = req.full_url.split("cve=")[1].split(",")
            rows = [{"cve": c, "epss": "0.1", "percentile": "0.5", "date": "2026-01-01"}
                    for c in batch]
            return _StubResponse(_epss_response(rows))

        with mock.patch.object(epss_kev.urllib.request, "urlopen", side_effect=fake_urlopen):
            count = epss_kev.refresh_epss(ids)
        self.assertEqual(count, 250)
        self.assertEqual(len(calls), 3)

    def test_refresh_epss_skips_unparseable_rows(self):
        rows = [{"cve": "CVE-2021-44228", "epss": "not-a-number", "percentile": "0.5"}]
        with mock.patch.object(epss_kev.urllib.request, "urlopen",
                               return_value=_StubResponse(_epss_response(rows))):
            count = epss_kev.refresh_epss(["CVE-2021-44228"])
        self.assertEqual(count, 0)
        self.assertIsNone(epss_kev.lookup("CVE-2021-44228"))


class RefreshAllTests(EpssKevTestCase):
    def test_partial_failure_reported_independently(self):
        def fake_urlopen(req, timeout=None):
            if "cisa.gov" in req.full_url:
                raise urllib.error.URLError("kev down")
            return _StubResponse(_epss_response(
                [{"cve": "CVE-2021-44228", "epss": "0.5", "percentile": "0.5", "date": "x"}]))

        with mock.patch.object(epss_kev.urllib.request, "urlopen", side_effect=fake_urlopen):
            result = epss_kev.refresh_all(["CVE-2021-44228"])
        self.assertIsNotNone(result["kev_error"])
        self.assertIsNone(result["epss_error"])
        self.assertEqual(result["epss"], 1)


class KnownCvesTests(unittest.TestCase):
    def test_returns_every_cve_in_sbom_known_vulns(self):
        import sbom_parser
        expected = {entry[-1] for vulns in sbom_parser.KNOWN_VULNS.values() for entry in vulns}
        self.assertEqual(epss_kev.known_cves(), frozenset(expected))
        self.assertTrue(all(c.startswith("CVE-") for c in epss_kev.known_cves()))


if __name__ == "__main__":
    unittest.main()
