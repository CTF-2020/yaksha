"""lineage/engine.py — pure matching logic: observations -> lineage updates.

Reuses the correlator's own normalization (:func:`correlator.engine.observe_report`)
so a design finding and a code finding are compared on the same vocabulary
(weakness family, CWE-derived, locus tokens) the correlator already trusts for
a single-run reconciliation. What this module adds is *persistence*: a
:class:`ThreatLineage` keeps the identity of one underlying risk stable across
every report that has ever touched it, not just the reports handed to one
correlation call, and its ``founding_locus`` — the token signature of the
observation that first created it — never changes, so relatedness matching
stays anchored to where the risk was first identified rather than drifting
as new, loosely-related findings pile on.

Known limitation: this only *adds* evidence — a lineage entry never moves
backward (e.g. from "confirmed" to "predicted") even if a later scan no longer
finds the code-side evidence. Detecting that a finding disappeared needs to
know which loci a scan actually covered, which is a materially bigger feature
(the same shape as ``arch_drift``, applied over time) than a sync step should
take on; a lineage can currently only be closed out explicitly, not inferred.
"""
from __future__ import annotations

import hashlib
import time

from correlator import taxonomy
from correlator.engine import observe_report
from correlator.model import SourceKind

from .model import LineageEvent, ThreatLineage

_KIND_LABEL = {SourceKind.DESIGN: "design", SourceKind.CODE: "code",
              SourceKind.RUNTIME: "runtime"}


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _threat_id(family: str, locus_tokens) -> str:
    raw = family + "\x1f" + "|".join(sorted(locus_tokens))
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:16]


def _status_from_kinds(kinds: set[str]) -> str:
    has_design = "design" in kinds
    has_code = "code" in kinds
    has_runtime = "runtime" in kinds
    if has_code and has_runtime:
        return "confirmed"
    if has_design and (has_code or has_runtime):
        return "realized"
    if has_design:
        return "predicted"
    return "blind_spot"


def _find_match(family: str, locus_tokens, existing: list[ThreatLineage]) -> ThreatLineage | None:
    for t in existing:
        if t.family == family and taxonomy.locus_related(set(t.founding_locus), locus_tokens):
            return t
    return None


def sync_observations(observations: list, existing: list[ThreatLineage],
                       now: str | None = None) -> tuple[list[ThreatLineage], list[tuple[str, LineageEvent]]]:
    """Match observations against ``existing`` (mutated in place) and return
    (threats touched, [(threat_id, event), ...]) for the caller to persist.

    An observation with no locus is skipped — a lineage entry needs a location
    to be re-identifiable in a later, different report; a locus-less finding
    (a global misconfiguration flag, say) has nothing stable to match on.
    """
    now = now or now_iso()
    touched: list[ThreatLineage] = []
    events: list[tuple[str, LineageEvent]] = []

    for obs in observations:
        if not obs.locus_tokens:
            continue
        kind_label = _KIND_LABEL.get(obs.kind, "design")
        match = _find_match(obs.family, obs.locus_tokens, existing)

        if match is None:
            threat = ThreatLineage(
                id=_threat_id(obs.family, obs.locus_tokens),
                family=obs.family, family_title=obs.family_title,
                status=_status_from_kinds({kind_label}),
                founding_locus=sorted(obs.locus_tokens),
                kinds_seen=[kind_label],
                first_seen_at=now, first_seen_report_id=obs.report_id,
                first_seen_report_title=obs.report_title, first_seen_kind=kind_label,
                updated_at=now,
            )
            existing.append(threat)
            target = threat
        else:
            kinds = set(match.kinds_seen) | {kind_label}
            match.kinds_seen = sorted(kinds)
            match.status = _status_from_kinds(kinds)
            match.updated_at = now
            target = match

        touched.append(target)
        events.append((target.id, LineageEvent(
            at=now, report_id=obs.report_id, report_title=obs.report_title,
            kind=kind_label, methodology=obs.methodology, severity=obs.severity,
            title=obs.title, locus_label=obs.locus_label,
        )))

    return touched, events


def sync_report(report: dict, existing: list[ThreatLineage],
                now: str | None = None) -> tuple[list[ThreatLineage], list[tuple[str, LineageEvent]]]:
    """Convenience wrapper: extract observations from a saved report and sync them."""
    return sync_observations(observe_report(report), existing, now)
