"""Map DAST engine findings to the Yaksha Guard TM report shape.

Same target shape as the SAST mapper — `report.categories[]`, each with a risk,
title, affected_components, threats[], mitigations[] — so the existing report
viewer renders a dynamic scan with no renderer changes. Findings are grouped by
rule id into one card per weakness class; each hit (URL[+parameter]) becomes a
threat ticket inside it. The only difference from the SAST mapper is that a hit
is located by URL/parameter/evidence rather than file:line/snippet.
"""
from __future__ import annotations

from . import config

_RISK_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}
_MAX_THREATS_PER_RULE = 50
_MAX_COMPONENTS = 25


def _highest_severity(findings: list[dict]) -> str:
    best = "Info"
    for f in findings:
        sev = f.get("severity", "Info")
        if config.SEVERITY_ORDER.get(sev, 99) < config.SEVERITY_ORDER.get(best, 99):
            best = sev
    return best


def _severity_counts(findings: list[dict]) -> dict:
    counts = {s: 0 for s in config.SEVERITIES}
    for f in findings:
        counts[f.get("severity", "Info")] = counts.get(f.get("severity", "Info"), 0) + 1
    return counts


def _loc(f: dict) -> str:
    return f"{f.get('url', '?')}" + (f" [{f['param']}]" if f.get("param") else "")


def _threat_from_finding(f: dict) -> dict:
    meta_bits = [b for b in (f.get("owasp"), f.get("cwe"),
                             f.get("confidence") and f"confidence: {f['confidence']}") if b]
    threat = {
        "name": _loc(f),
        "description": f.get("evidence") or "(no evidence captured)",
        "attack_vector": f.get("title", ""),
        "control_objective": " | ".join(meta_bits),
        "false_positive_guidance":
            "Reproduce the request against an authorized environment before acting; "
            "passive header findings may be intentional for public, non-sensitive "
            "responses.",
    }
    # Reproduction evidence — the dynamic-scan equivalent of a source file:line +
    # vulnerable code: the exact request sent and the response bytes that prove it.
    if f.get("request"):
        threat["request"] = f["request"]
    if f.get("evidence_snippet"):
        threat["evidence_snippet"] = f["evidence_snippet"]
    return threat


def _category_from_group(rule_id: str, findings: list[dict]) -> dict:
    first = findings[0]
    severity = _highest_severity(findings)
    locations = [_loc(f) for f in findings]
    remediation = first.get("remediation", "") or "Remediate per secure-configuration guidance."
    return {
        "id": rule_id,
        "category": "DAST",
        "name": first.get("title", rule_id),
        "title": first.get("title", rule_id),
        "risk": severity,
        "risk_score": _RISK_SCORE.get(severity, 1),
        "_source": "DAST",
        "ruleset": "DAST",
        "description": (
            f"{len(findings)} occurrence(s) of {first.get('title', rule_id)} "
            f"observed by dynamic analysis ({rule_id})."
        ),
        "affected_components": locations[:_MAX_COMPONENTS],
        "mitigation": remediation,
        "remediation": remediation,
        "mitigations": [{"action": remediation, "priority": "Immediate"}],
        "threats": [_threat_from_finding(f) for f in findings[:_MAX_THREATS_PER_RULE]],
        "notes": (
            f"OWASP: {first.get('owasp', 'n/a')}  ·  CWE: {first.get('cwe', 'n/a')}  ·  "
            f"method: {first.get('method', 'GET')}"
        ),
    }


def findings_to_report(findings: list[dict], target: dict, meta: dict,
                       severity_threshold: str) -> dict:
    """Build a TM report dict ready for `_save_report`."""
    groups: dict[str, list[dict]] = {}
    for f in findings:
        groups.setdefault(f.get("id", "UNKNOWN"), []).append(f)

    categories = sorted(
        (_category_from_group(rid, fs) for rid, fs in groups.items()),
        key=lambda c: (config.SEVERITY_ORDER.get(c["risk"], 99), -len(c["threats"])),
    )

    counts = _severity_counts(findings)
    overall = _highest_severity(findings) if findings else "Info"
    name = target.get("name", target.get("id", "target"))
    url = target.get("url", "")
    crawl = (f"{meta.get('pages_crawled', 0)} page(s), "
             f"{meta.get('requests_made', 0)} request(s)")

    summary = (
        f"Dynamic analysis of {name} ({url}) crawled {crawl} and found "
        f"{len(findings)} finding(s) at or above the {severity_threshold} threshold "
        f"across {len(groups)} rule(s): "
        + (", ".join(f"{counts[s]} {s}" for s in config.SEVERITIES if counts[s])
           + "." if findings else "no findings at or above the threshold.")
    )

    seen, recommendations = set(), []
    for c in categories:
        rec = c["mitigation"]
        if rec and rec not in seen:
            seen.add(rec)
            recommendations.append(rec)

    return {
        "title": f"DAST · {name}",
        "methodology": "dast",
        "methodology_label": "Dynamic Application Security Testing",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "analyzed_at": config.now_iso(),
        "summary": summary,
        "categories": categories,
        "recommendations": recommendations,
        "scan_metadata": {
            "target_id": target.get("id"),
            "target_name": name,
            "target_url": url,
            "severity_threshold": severity_threshold,
            "findings_total": len(findings),
            "rules_triggered": len(groups),
            "severity_counts": counts,
            **meta,
        },
    }
