"""Tests for broker/remediation.py — the human-gated fix-PR loop.

Mocks broker.remediation.prepare_workspace (no real clone), scanner._run_git
(no real git subprocess for fetch/diff/apply/push), and GitHubClient (no real
network) — same conventions as test_broker.py's TestCodeModelAutoTrigger and
TestChecksApi. propose_fix's file-read/patch-generation logic runs for real
against a temp directory so the line-matching/diff-building code is actually
exercised, not just its call graph.
"""
from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import report_db
import suppressions
from broker import config as broker_config
from broker import db as broker_db
from broker import github, remediation, scanner
from suppressions import db as supp_db
from suppressions import store as supp_store


def _report_with_threat(category_id="PY-YAML-001", file="app.py", line=10,
                        suggestion=None):
    threat = {"name": f"{file}:{line}", "line": line}
    if suggestion is not None:
        threat["review"] = {"suggestion": suggestion}
    return {
        "id": "r1",
        "categories": [
            {"id": category_id, "name": "Unsafe YAML load",
             "threats": [threat]},
        ],
    }


_MECHANICAL_SUGGESTION = {
    "diff": [["-", 'yaml.load(data)'], ["+", 'yaml.safe_load(data)']],
    "note": "safe_load refuses arbitrary object construction.",
    "kind": "mechanical",
}

_ADVICE_ONLY_SUGGESTION = {
    "diff": None,
    "note": "Never unpickle data that crosses a trust boundary.",
    "kind": "advice",
}


class FindThreatTests(unittest.TestCase):
    def test_finds_matching_threat(self):
        report = _report_with_threat()
        threat = remediation.find_threat(report, "PY-YAML-001", "app.py", 10)
        self.assertIsNotNone(threat)
        self.assertEqual(threat["line"], 10)

    def test_wrong_category_returns_none(self):
        report = _report_with_threat()
        self.assertIsNone(remediation.find_threat(report, "OTHER-ID", "app.py", 10))

    def test_wrong_line_returns_none(self):
        report = _report_with_threat()
        self.assertIsNone(remediation.find_threat(report, "PY-YAML-001", "app.py", 99))

    def test_wrong_file_returns_none(self):
        report = _report_with_threat()
        self.assertIsNone(remediation.find_threat(report, "PY-YAML-001", "other.py", 10))


class ProposeFixTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="remediation_test_")
        self.repo = {"id": "r", "url": "https://github.com/acme/widgets", "branch": "main"}

    def _write(self, rel: str, content: str):
        path = os.path.join(self.tmp, rel)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(content)

    def test_finding_not_found(self):
        report = _report_with_threat()
        result = remediation.propose_fix(self.repo, report, "NOPE", "app.py", 10, "main")
        self.assertFalse(result["eligible"])
        self.assertIn("not found", result["reason"])

    def test_advice_only_suggestion_is_not_eligible(self):
        report = _report_with_threat(suggestion=_ADVICE_ONLY_SUGGESTION)
        result = remediation.propose_fix(self.repo, report, "PY-YAML-001", "app.py", 10, "main")
        self.assertFalse(result["eligible"])
        self.assertIn("no mechanical fix", result["reason"])

    def test_diff_error_is_not_eligible(self):
        report = _report_with_threat(suggestion=_MECHANICAL_SUGGESTION)
        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git",
                               side_effect=scanner.ScanError("fetch failed")):
            result = remediation.propose_fix(
                self.repo, report, "PY-YAML-001", "app.py", 10, "main")
        self.assertFalse(result["eligible"])
        self.assertIn("could not diff", result["reason"])

    def test_line_not_in_added_lines_is_not_eligible(self):
        report = _report_with_threat(suggestion=_MECHANICAL_SUGGESTION)
        # A diff that adds a line in app.py, but not line 10.
        diff_text = (
            "diff --git a/app.py b/app.py\n"
            "--- a/app.py\n+++ b/app.py\n"
            "@@ -1,1 +1,2 @@\n+import os\n line1\n"
        )
        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git", return_value=diff_text):
            result = remediation.propose_fix(
                self.repo, report, "PY-YAML-001", "app.py", 10, "main")
        self.assertFalse(result["eligible"])
        self.assertIn("not on a line the diff", result["reason"])

    def _added_diff_for_line(self, file: str, line: int) -> str:
        return (f"diff --git a/{file} b/{file}\n"
               f"--- a/{file}\n+++ b/{file}\n"
               f"@@ -1,1 +1,{line} @@\n" + "+x\n" * line)

    def test_eligible_finding_produces_a_patch(self):
        self._write("app.py", "\n".join(f"line{i}" for i in range(1, 10))
                    + "\nyaml.load(data)\nlast\n")
        report = _report_with_threat(suggestion=_MECHANICAL_SUGGESTION)
        diff_text = self._added_diff_for_line("app.py", 10)
        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git", return_value=diff_text):
            result = remediation.propose_fix(
                self.repo, report, "PY-YAML-001", "app.py", 10, "main")
        self.assertTrue(result["eligible"], result.get("reason"))
        self.assertIn("-yaml.load(data)", result["patch"])
        self.assertIn("+yaml.safe_load(data)", result["patch"])
        self.assertEqual(result["kind"], "mechanical")

    def test_drifted_file_is_not_eligible(self):
        # Line 10 no longer matches the suggestion's recorded "old" text.
        self._write("app.py", "\n".join(f"line{i}" for i in range(1, 10))
                    + "\nsomething_else_entirely()\nlast\n")
        report = _report_with_threat(suggestion=_MECHANICAL_SUGGESTION)
        diff_text = self._added_diff_for_line("app.py", 10)
        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git", return_value=diff_text):
            result = remediation.propose_fix(
                self.repo, report, "PY-YAML-001", "app.py", 10, "main")
        self.assertFalse(result["eligible"])
        self.assertIn("changed since this finding was scanned", result["reason"])

    def test_malicious_against_is_rejected_before_any_git_call(self):
        # A crafted "branch name" shaped like a git option (e.g. --upload-pack=...)
        # must never reach `git fetch` as a positional arg — is_valid_ref() has to
        # reject it up front, and _run_git must never be invoked at all.
        report = _report_with_threat(suggestion=_MECHANICAL_SUGGESTION)
        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git") as run_git:
            result = remediation.propose_fix(
                self.repo, report, "PY-YAML-001", "app.py", 10,
                "--upload-pack=touch /tmp/pwned")
        self.assertFalse(result["eligible"])
        self.assertIn("could not diff", result["reason"])
        run_git.assert_not_called()

    def test_valid_against_is_passed_with_a_double_dash_separator(self):
        report = _report_with_threat(suggestion=_MECHANICAL_SUGGESTION)
        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git", return_value="") as run_git:
            remediation.propose_fix(
                self.repo, report, "PY-YAML-001", "app.py", 10, "main")
        fetch_call = run_git.call_args_list[0].args[0]
        self.assertIn("--", fetch_call)
        self.assertLess(fetch_call.index("--"), fetch_call.index("main"))


class OpenPrTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="remediation_pr_test_")
        self.repo = {
            "id": "r", "url": "https://github.com/acme/widgets", "branch": "main",
            "remediation_enabled": True, "github_full_name": "acme/widgets",
            "github_token": "tok",
        }
        self.patch_text = ("--- a/app.py\n+++ b/app.py\n"
                           "@@ -10 +10 @@\n-yaml.load(data)\n+yaml.safe_load(data)\n")

    def test_disabled_repo_raises(self):
        repo = dict(self.repo, remediation_enabled=False)
        with self.assertRaises(remediation.RemediationError):
            remediation.open_pr(repo, self.patch_text, "app.py", "PY-YAML-001", "r1")

    def test_unresolvable_repo_raises(self):
        repo = dict(self.repo, github_full_name="", url="https://example.com/not-github")
        with self.assertRaises(remediation.RemediationError):
            remediation.open_pr(repo, self.patch_text, "app.py", "PY-YAML-001", "r1")

    def test_malicious_branch_is_rejected_before_any_git_call(self):
        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git") as run_git:
            with self.assertRaises(remediation.RemediationError):
                remediation.open_pr(
                    self.repo, self.patch_text, "app.py", "PY-YAML-001", "r1",
                    branch="--upload-pack=touch /tmp/pwned")
        run_git.assert_not_called()

    def test_successful_flow_opens_pr_and_comments(self):
        calls = []

        class CaptureClient(github.GitHubClient):
            def create_pull_request(self, full_name, title, head, base, body_md=""):
                calls.append(("pr", full_name, title, head, base))
                return {"number": 42, "html_url": "https://github.com/acme/widgets/pull/42"}

            def upsert_pr_comment(self, full_name, number, body_md, marker=None):
                calls.append(("comment", full_name, number))
                return {}

        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git", return_value="") as run_git, \
             mock.patch.object(remediation, "GitHubClient", CaptureClient):
            result = remediation.open_pr(
                self.repo, self.patch_text, "app.py", "PY-YAML-001", "r1")

        self.assertTrue(result["success"])
        self.assertEqual(result["pr_number"], 42)
        self.assertEqual(result["pr_url"], "https://github.com/acme/widgets/pull/42")
        # First token of each git invocation, skipping any leading `-c key=val`
        # config overrides (the commit call uses them for author identity).
        def _op(args):
            i = 0
            while i < len(args) and args[i] == "-c":
                i += 2
            return args[i]
        git_ops = [_op(c.args[0]) for c in run_git.call_args_list]
        self.assertEqual(git_ops, ["apply", "apply", "checkout", "add", "commit", "push"])
        self.assertEqual([c[0] for c in calls], ["pr", "comment"])
        self.assertEqual(calls[0][1], "acme/widgets")

    def test_git_apply_failure_raises_and_leaves_no_pr_call(self):
        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git",
                               side_effect=scanner.ScanError("patch does not apply")), \
             mock.patch.object(remediation, "GitHubClient") as client_cls:
            with self.assertRaises(remediation.RemediationError):
                remediation.open_pr(self.repo, self.patch_text, "app.py",
                                    "PY-YAML-001", "r1")
        client_cls.assert_not_called()

    def test_pr_creation_failure_after_push_raises_with_branch_context(self):
        class FailingClient(github.GitHubClient):
            def create_pull_request(self, *a, **k):
                raise github.GitHubError("422 validation failed")

        with mock.patch.object(remediation, "prepare_workspace",
                               return_value=(self.tmp, {})), \
             mock.patch.object(scanner, "_run_git", return_value=""), \
             mock.patch.object(remediation, "GitHubClient", FailingClient):
            with self.assertRaises(remediation.RemediationError) as ctx:
                remediation.open_pr(self.repo, self.patch_text, "app.py",
                                    "PY-YAML-001", "r1")
        self.assertIn("was pushed", str(ctx.exception))


def _sast_report(rid, category_id="PY-SQL-001", file="app.py", line=42,
                 suggestion=None, title="SQL Injection"):
    threat = {"name": f"{file}:{line}", "line": line}
    if suggestion is not None:
        threat["review"] = {"suggestion": suggestion}
    return {
        "id": rid, "title": "SAST scan", "methodology": "sast",
        "categories": [
            {"id": category_id, "name": title, "risk": "High", "threats": [threat]},
        ],
    }


def _correlation_report(rid, source_ids, category_id, locus, verdict,
                        risk="High", title="Correlated"):
    return {
        "id": rid, "title": title, "methodology": "correlation",
        "scan_metadata": {"source_reports": [{"id": sid} for sid in source_ids]},
        "categories": [
            {"id": category_id, "name": title, "risk": risk, "verdict": verdict,
             "threats": [{"name": f"[Static (code)] {locus}", "description": "root cause"}]},
        ],
    }


class QueueTests(unittest.TestCase):
    """broker.remediation.queue() -- verdict-driven fix-PR prioritization.

    Isolates report_db and the broker repo registry (config.STATE_DIR /
    broker.db) onto temp stores, same pattern tests/test_admin.py's
    _IsolatedStoresMixin uses for the same two stores.

    IMPORTANT: config.REPOS_PATH (the legacy JSON mirror of the repo
    registry) is a module-level constant computed once at import time from
    the REAL STATE_DIR -- reassigning config.STATE_DIR at runtime does NOT
    move it. Every config.upsert_repo()/load_repos() call still mirrors a
    write to whatever REPOS_PATH currently points at, so it must be patched
    explicitly too or every run of this test silently overwrites the real
    ~/.tm_broker/repos.json backup file with fake test repos (this actually
    happened once during development -- see git history/session notes).
    """

    def setUp(self):
        self._orp = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self._ocs = broker_config.STATE_DIR
        self._orpp = broker_config.REPOS_PATH
        self._obd = broker_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        root = Path(self._td.name)

        report_db.DB_PATH = root / "reports.db"
        report_db.init()
        supp_db.DB_PATH = root / "suppressions.db"
        supp_store._BACKUP_PATH = root / "supp.json"
        supp_db.init()
        broker_config.STATE_DIR = root / "tm_broker"
        broker_config.REPOS_PATH = root / "tm_broker" / "repos.json"
        broker_db.DB_PATH = root / "tm_broker" / "broker.db"
        broker_db.init()

    def _restore(self):
        report_db.DB_PATH = self._orp
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp
        broker_config.STATE_DIR = self._ocs
        broker_config.REPOS_PATH = self._orpp
        broker_db.DB_PATH = self._obd

    def _register_repo(self, repo_id, sast_report_id, remediation_enabled=True):
        broker_config.upsert_repo({
            "id": repo_id, "name": f"repo-{repo_id}", "url": "https://github.com/acme/x",
            "branch": "main", "remediation_enabled": remediation_enabled,
            "last_scan": {"report_id": sast_report_id, "risk": "High", "findings": 1},
        })

    def test_repo_without_remediation_enabled_is_excluded(self):
        sast = _sast_report("s1", suggestion=_MECHANICAL_SUGGESTION)
        report_db.upsert_report(sast)
        self._register_repo("r1", "s1", remediation_enabled=False)
        self.assertEqual(remediation.queue(), [])

    def test_finding_without_mechanical_fix_is_excluded(self):
        sast = _sast_report("s1", suggestion=_ADVICE_ONLY_SUGGESTION)
        report_db.upsert_report(sast)
        self._register_repo("r1", "s1")
        self.assertEqual(remediation.queue(), [])

    def test_fix_eligible_finding_appears_unverdicted_when_never_correlated(self):
        sast = _sast_report("s1", suggestion=_MECHANICAL_SUGGESTION)
        report_db.upsert_report(sast)
        self._register_repo("r1", "s1")
        items = remediation.queue()
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["verdict"], "")
        self.assertEqual(items[0]["file"], "app.py")
        self.assertEqual(items[0]["line"], 42)

    def test_correlated_finding_carries_its_verdict(self):
        sast = _sast_report("s1", suggestion=_MECHANICAL_SUGGESTION)
        report_db.upsert_report(sast)
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], "CORR-001", "app.py:42", "confirmed_exploitable"))
        self._register_repo("r1", "s1")
        items = remediation.queue()
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["verdict"], "confirmed_exploitable")

    def test_verdicted_findings_rank_before_unverdicted(self):
        sast1 = _sast_report("s1", category_id="A", file="a.py", line=1,
                             suggestion=_MECHANICAL_SUGGESTION, title="A finding")
        sast2 = _sast_report("s2", category_id="B", file="b.py", line=1,
                             suggestion=_MECHANICAL_SUGGESTION, title="B finding")
        report_db.upsert_report(sast1)
        report_db.upsert_report(sast2)
        report_db.upsert_report(_correlation_report(
            "c1", ["s2"], "CORR-001", "b.py:1", "actively_exploited"))
        self._register_repo("r1", "s1")
        self._register_repo("r2", "s2")
        items = remediation.queue()
        self.assertEqual(len(items), 2)
        self.assertEqual(items[0]["verdict"], "actively_exploited")
        self.assertEqual(items[1]["verdict"], "")

    def test_more_actionable_verdict_ranks_first(self):
        sast1 = _sast_report("s1", category_id="A", file="a.py", line=1,
                             suggestion=_MECHANICAL_SUGGESTION, title="A finding")
        sast2 = _sast_report("s2", category_id="B", file="b.py", line=1,
                             suggestion=_MECHANICAL_SUGGESTION, title="B finding")
        report_db.upsert_report(sast1)
        report_db.upsert_report(sast2)
        report_db.upsert_report(_correlation_report(
            "c1", ["s1"], "CORR-001", "a.py:1", "design_gap"))
        report_db.upsert_report(_correlation_report(
            "c2", ["s2"], "CORR-002", "b.py:1", "actively_exploited"))
        self._register_repo("r1", "s1")
        self._register_repo("r2", "s2")
        items = remediation.queue()
        self.assertEqual(items[0]["repo_id"], "r2")
        self.assertEqual(items[0]["verdict"], "actively_exploited")
        self.assertEqual(items[1]["repo_id"], "r1")
        self.assertEqual(items[1]["verdict"], "design_gap")

    def test_suppressed_finding_excluded_from_queue(self):
        sast = _sast_report("s1", suggestion=_MECHANICAL_SUGGESTION)
        report_db.upsert_report(sast)
        self._register_repo("r1", "s1")
        suppressions.add_suppression({
            "scope": "rule", "match": "PY-SQL-001", "reason": "accepted", "author": "carol"})
        self.assertEqual(remediation.queue(), [])

    def test_repo_id_filter_scopes_to_one_repo(self):
        sast1 = _sast_report("s1", category_id="A", file="a.py", line=1,
                             suggestion=_MECHANICAL_SUGGESTION, title="A finding")
        sast2 = _sast_report("s2", category_id="B", file="b.py", line=1,
                             suggestion=_MECHANICAL_SUGGESTION, title="B finding")
        report_db.upsert_report(sast1)
        report_db.upsert_report(sast2)
        self._register_repo("r1", "s1")
        self._register_repo("r2", "s2")
        items = remediation.queue(repo_id="r1")
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["repo_id"], "r1")

    def test_no_registered_repos_returns_empty(self):
        self.assertEqual(remediation.queue(), [])


class RemediationQueueApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orp = report_db.DB_PATH
        self._ocs = broker_config.STATE_DIR
        self._orpp = broker_config.REPOS_PATH
        self._obd = broker_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        root = Path(self._td.name)
        report_db.DB_PATH = root / "reports.db"
        report_db.init()
        broker_config.STATE_DIR = root / "tm_broker"
        broker_config.REPOS_PATH = root / "tm_broker" / "repos.json"
        broker_db.DB_PATH = root / "tm_broker" / "broker.db"
        broker_db.init()

    def _restore(self):
        report_db.DB_PATH = self._orp
        broker_config.STATE_DIR = self._ocs
        broker_config.REPOS_PATH = self._orpp
        broker_db.DB_PATH = self._obd

    def test_queue_endpoint(self):
        report_db.upsert_report(_sast_report("s1", suggestion=_MECHANICAL_SUGGESTION))
        broker_config.upsert_repo({
            "id": "r1", "name": "repo-r1", "url": "https://github.com/acme/x",
            "remediation_enabled": True, "last_scan": {"report_id": "s1"},
        })
        resp = self.client.get("/api/v1/sast/remediation/queue")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["count"], 1)

    def test_queue_endpoint_rejects_bad_limit(self):
        resp = self.client.get("/api/v1/sast/remediation/queue?limit=nope")
        self.assertEqual(resp.status_code, 400)

    def test_queue_endpoint_rejects_bad_repo_id(self):
        resp = self.client.get("/api/v1/sast/remediation/queue?repo_id=..%2fetc")
        self.assertEqual(resp.status_code, 400)


if __name__ == "__main__":
    unittest.main(verbosity=2)
