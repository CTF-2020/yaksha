"""epss_kev.py — EPSS exploitation-probability + CISA KEV "actively exploited"
enrichment for CVE-bearing findings (today, exclusively the vulnerable-
component/SBOM findings that carry a CVE id — see sbom_parser.KNOWN_VULNS).

Two independent real-world signals a homegrown reachability/business-impact
heuristic (codemodel/business_impact.py, correlator/engine.py's
``_exploitability``) can never produce on its own, because both come from
outside the scanned code entirely:

  * EPSS (https://www.first.org/epss/) — a daily-updated probability (0..1)
    that a given CVE will be exploited in the wild in the next 30 days, plus
    its percentile rank against every other scored CVE.
  * CISA KEV (https://www.cisa.gov/known-exploited-vulnerabilities-catalog) —
    a curated catalog of CVEs CISA has *confirmed* are being actively
    exploited right now. Ground truth, not a probability.

Both are fetched over the network and cached to disk (data/epss_kev_cache.json)
so correlation never blocks on, or fails because of, a live call: every reader
in this module (``lookup``, ``combined_lookup``, ``extract_cves``) is a pure,
filesystem-only (or no-I/O-at-all) function against the last successful
fetch — consistent with the correlator engine's own purity contract (see
correlator/engine.py's module docstring). Only ``refresh_kev``/``refresh_epss``
touch the network, and only when explicitly invoked (CLI or an admin action,
see api/epss_kev.py) — never on a normal report/correlation code path, and a
failed refresh never corrupts or empties an existing cache (the on-disk file
is only overwritten after a fully successful fetch+parse).

EPSS is refreshed *targeted*, not as a full daily mirror: FIRST.org scores
roughly a quarter-million CVEs, but TM only ever needs scores for CVE ids
that actually showed up in a scan (today, sbom_parser.KNOWN_VULNS' ~30
entries plus whatever future sources add) — mirroring one CVE per scored
finding rather than the entire catalog. KEV, by contrast, is small enough
(~1600 entries, under 200KB once trimmed to the fields TM actually uses) to
mirror in full on every refresh, so a local lookup never misses an entry
just because nobody happened to ask for that exact CVE by name yet.
"""
from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Iterable

_CACHE = Path(__file__).resolve().parent / "data" / "epss_kev_cache.json"
_KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
_EPSS_URL = "https://api.first.org/data/v1/epss"
_CVE_RE = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)
_DEFAULT_TIMEOUT = 10
_USER_AGENT = "tm-yaksha-guard-epss-kev/1.0"
_TS_FMT = "%Y-%m-%dT%H:%M:%SZ"

# FIRST.org's documented practical limit sits comfortably above this; batching
# defensively means one oversized request can't fail an entire refresh.
_EPSS_BATCH = 100


def extract_cves(*texts: str) -> frozenset[str]:
    """Every CVE id mentioned across the given free-text blobs, normalized
    upper-case. Pure regex, no I/O — mirrors correlator/taxonomy.extract_cwes'
    shape so callers can lift both out of the same category text in one pass."""
    found: set[str] = set()
    for t in texts:
        if t:
            found.update(m.group(0).upper() for m in _CVE_RE.finditer(str(t)))
    return frozenset(found)


def _empty_cache() -> dict:
    return {"kev_updated_at": "", "epss_updated_at": "", "kev": {}, "epss": {}}


def _load() -> dict:
    if not _CACHE.exists():
        return _empty_cache()
    try:
        data = json.loads(_CACHE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return _empty_cache()
    if not isinstance(data, dict):
        return _empty_cache()
    data.setdefault("kev_updated_at", "")
    data.setdefault("epss_updated_at", "")
    data.setdefault("kev", {})
    data.setdefault("epss", {})
    if not isinstance(data["kev"], dict):
        data["kev"] = {}
    if not isinstance(data["epss"], dict):
        data["epss"] = {}
    return data


def _save(data: dict) -> None:
    _CACHE.parent.mkdir(parents=True, exist_ok=True)
    tmp = _CACHE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(_CACHE)   # atomic on both POSIX and Windows


def lookup(cve: str) -> dict | None:
    """Cached EPSS/KEV facts for one CVE id, or None if neither source has
    ever produced data for it. Pure filesystem read — never touches the
    network, so it's always safe to call from a request/report code path."""
    cve = str(cve or "").strip().upper()
    if not cve:
        return None
    data = _load()
    epss = data["epss"].get(cve)
    kev = data["kev"].get(cve)
    if epss is None and kev is None:
        return None
    return {
        "cve": cve,
        "epss": epss.get("score") if epss else None,
        "epss_percentile": epss.get("percentile") if epss else None,
        "kev": kev is not None,
        "kev_date_added": kev.get("date_added") if kev else None,
        "kev_ransomware": kev.get("ransomware") if kev else "",
    }


def combined_lookup(cves: Iterable[str]) -> dict[str, dict]:
    """``{cve: fact}`` for every id in ``cves`` the cache has data for — the
    lookup table shape ``correlator.engine`` threads through as
    ``epss_kev_lookup`` (see engine._epss_kev)."""
    out: dict[str, dict] = {}
    for cve in cves:
        fact = lookup(cve)
        if fact:
            out[fact["cve"]] = fact
    return out


def cache_status() -> dict:
    """Freshness/size info for an admin/CLI view — never touches the network."""
    data = _load()
    return {
        "kev_updated_at": data.get("kev_updated_at") or None,
        "epss_updated_at": data.get("epss_updated_at") or None,
        "kev_count": len(data.get("kev") or {}),
        "epss_count": len(data.get("epss") or {}),
    }


# ── Network refresh (explicit call only — CLI / admin action) ─────────────────

def refresh_kev(timeout: int = _DEFAULT_TIMEOUT) -> int:
    """Pull CISA's full known-exploited-vulnerabilities catalog and replace
    the cached KEV table wholesale (small enough to mirror in full — see
    module docstring). Returns the number of entries stored.

    Raises ``urllib.error.URLError``/``ValueError`` on network or parse
    failure — callers (the CLI, the admin endpoint) decide whether to
    surface or swallow that. The existing cache is left untouched until a
    fetch fully succeeds, so a failed refresh never empties or corrupts it.
    """
    req = urllib.request.Request(_KEV_URL, headers={"User-Agent": _USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    entries: dict[str, dict] = {}
    for v in payload.get("vulnerabilities", []) or []:
        cve = str(v.get("cveID", "")).strip().upper()
        if not cve:
            continue
        entries[cve] = {
            "date_added": v.get("dateAdded", ""),
            "vendor_project": v.get("vendorProject", ""),
            "product": v.get("product", ""),
            "ransomware": v.get("knownRansomwareCampaignUse", ""),
        }
    data = _load()
    data["kev"] = entries
    data["kev_updated_at"] = time.strftime(_TS_FMT, time.gmtime())
    _save(data)
    return len(entries)


def refresh_epss(cves: Iterable[str], timeout: int = _DEFAULT_TIMEOUT) -> int:
    """Fetch EPSS scores for the given CVE ids (batched — FIRST.org accepts a
    comma-separated ``cve=`` list) and merge them into the cache. A no-op
    (returns 0) for empty input, rather than fetching the entire ~250k-CVE
    catalog nobody asked for. Returns the number of CVEs updated.

    Same failure contract as ``refresh_kev``: raises on a hard network/parse
    error, and only ever merges in results from batches that fully
    succeeded — a failure partway through still keeps whatever earlier
    batches in this call (and every prior call) already wrote.
    """
    ids = sorted({c.strip().upper() for c in cves if c and c.strip()})
    if not ids:
        return 0
    data = _load()
    updated = 0
    for i in range(0, len(ids), _EPSS_BATCH):
        batch = ids[i:i + _EPSS_BATCH]
        url = f"{_EPSS_URL}?cve={','.join(batch)}"
        req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        for row in payload.get("data", []) or []:
            cve = str(row.get("cve", "")).strip().upper()
            if not cve:
                continue
            try:
                score = float(row.get("epss", 0.0))
                pct = float(row.get("percentile", 0.0))
            except (TypeError, ValueError):
                continue
            data["epss"][cve] = {"score": round(score, 5), "percentile": round(pct, 5),
                                 "date": row.get("date", "")}
            updated += 1
        # Save after each successful batch so a later batch's failure doesn't
        # discard progress already made in this same refresh call.
        data["epss_updated_at"] = time.strftime(_TS_FMT, time.gmtime())
        _save(data)
    return updated


def refresh_all(cves: Iterable[str] = (), timeout: int = _DEFAULT_TIMEOUT) -> dict:
    """Convenience for the CLI/admin action: refresh KEV in full, then EPSS
    for the given CVE ids. Each half is independently best-effort — one
    failing doesn't block the other — and the return shape says exactly
    what happened to each so a caller can report a partial failure honestly
    instead of a bare exception.
    """
    result = {"kev": None, "kev_error": None, "epss": None, "epss_error": None}
    try:
        result["kev"] = refresh_kev(timeout=timeout)
    except (urllib.error.URLError, OSError, ValueError, TimeoutError) as exc:
        result["kev_error"] = str(exc)
    try:
        result["epss"] = refresh_epss(cves, timeout=timeout)
    except (urllib.error.URLError, OSError, ValueError, TimeoutError) as exc:
        result["epss_error"] = str(exc)
    return result


def known_cves() -> frozenset[str]:
    """Every CVE id TM's own static detectors can ever emit (see
    sbom_parser.KNOWN_VULNS) — the default seed list for an EPSS refresh
    when the caller has no report-derived CVE set of its own (e.g. a
    scheduled/CLI refresh run outside of any correlation pass)."""
    import sbom_parser
    out = set()
    for vulns in sbom_parser.KNOWN_VULNS.values():
        for entry in vulns:
            cve = entry[-1]
            if cve:
                out.add(str(cve).upper())
    return frozenset(out)


def _cli_refresh() -> None:  # pragma: no cover - thin CLI wrapper
    cves = known_cves()
    print(f"Refreshing KEV catalog and EPSS scores for {len(cves)} known CVE id(s)...")
    result = refresh_all(cves)
    if result["kev_error"]:
        print(f"  KEV refresh FAILED: {result['kev_error']}")
    else:
        print(f"  KEV refresh OK: {result['kev']} entries")
    if result["epss_error"]:
        print(f"  EPSS refresh FAILED: {result['epss_error']}")
    else:
        print(f"  EPSS refresh OK: {result['epss']} CVE(s) scored")


if __name__ == "__main__":  # pragma: no cover
    _cli_refresh()
