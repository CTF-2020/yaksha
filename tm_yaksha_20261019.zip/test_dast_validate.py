"""Tests for dast.validate — attack-path validation from a completed DAST scan.

Locus vocabulary in the fixtures is deliberately minimal (every side reduces
to the single shared token "page2") so relatedness under
correlator.taxonomy.locus_related is unambiguous — jaccard 1.0, not a
borderline single-token overlap — rather than depending on the exact
tokenizer/threshold internals to land the right side of a fuzzy match.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from broker import config as broker_config
from broker import db as broker_db
from dast import validate


def _repo(id_="repo-1", url="https://github.com/acme/widget.git"):
    return {"id": id_, "url": url, "name": "widget"}


def _codemodel_report(rid, repo_id, tainted=True):
    return {
        "id": rid, "title": f"Code Model {repo_id}", "methodology": "codemodel",
        "scan_metadata": {
            "repo_id": repo_id, "repo_name": repo_id,
            "attack_surface": [{
                "method": "GET", "path": "/page2", "handler": "page2",
                "file": "page2.py", "line": 1, "authenticated": False, "controls": [],
                "sinks": [{"kind": "template", "family": "xss", "cwe": "CWE-79",
                          "name": "page2", "file": "page2.py", "line": 12,
                          "hops": 0, "tainted": tainted}],
            }],
        },
    }


def _dast_report(rid, locus="/page2"):
    return {
        "id": rid, "title": "DAST", "methodology": "dast",
        "categories": [{
            "id": "D1", "name": "Reflected XSS", "risk": "High", "_source": "DAST",
            "cwe": "CWE-79", "affected_components": [locus],
            "threats": [{"name": locus, "description": "reflected in response body"}],
        }],
    }


class _IsolatedBrokerRegistry(unittest.TestCase):
    def setUp(self):
        self._orig_db_path = broker_db.DB_PATH
        self._orig_repos_path = broker_config.REPOS_PATH
        self._td = tempfile.TemporaryDirectory()
        broker_db.DB_PATH = Path(self._td.name) / "broker.db"
        broker_config.REPOS_PATH = Path(self._td.name) / "repos.json"

    def tearDown(self):
        broker_db.DB_PATH = self._orig_db_path
        broker_config.REPOS_PATH = self._orig_repos_path
        self._td.cleanup()


class TestRepoIdForTarget(_IsolatedBrokerRegistry):
    def test_matches_via_explicit_github_full_name_on_target(self):
        broker_config.upsert_repo(_repo())
        self.assertEqual(validate.repo_id_for_target({"github_full_name": "acme/widget"}),
                         "repo-1")

    def test_matches_via_repo_url_derivation(self):
        broker_config.upsert_repo(_repo())
        target = {"repo_url": "https://github.com/acme/widget.git"}
        self.assertEqual(validate.repo_id_for_target(target), "repo-1")

    def test_no_match_returns_none(self):
        broker_config.upsert_repo(_repo())
        self.assertIsNone(validate.repo_id_for_target({"github_full_name": "someone/else"}))

    def test_target_with_no_repo_link_returns_none(self):
        self.assertIsNone(validate.repo_id_for_target({}))


class TestLatestCodemodelReport(unittest.TestCase):
    def setUp(self):
        import report_db
        self._orig = report_db.DB_PATH
        self._td = tempfile.TemporaryDirectory()
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        self.report_db = report_db

    def tearDown(self):
        self.report_db.DB_PATH = self._orig
        self._td.cleanup()

    def test_returns_none_when_no_codemodel_report_for_repo(self):
        self.assertIsNone(validate.latest_codemodel_report("repo-x"))

    def test_ignores_codemodel_reports_for_other_repos(self):
        self.report_db.upsert_report(_codemodel_report("cm1", "other-repo"))
        self.assertIsNone(validate.latest_codemodel_report("repo-x"))

    def test_ignores_non_codemodel_reports(self):
        self.report_db.upsert_report(
            {"id": "d1", "methodology": "dast", "scan_metadata": {"repo_id": "repo-x"}})
        self.assertIsNone(validate.latest_codemodel_report("repo-x"))

    def test_returns_the_matching_codemodel_report(self):
        self.report_db.upsert_report(_codemodel_report("cm1", "repo-x"))
        got = validate.latest_codemodel_report("repo-x")
        self.assertEqual(got["id"], "cm1")

    def test_returns_the_newest_when_multiple_exist(self):
        self.report_db.upsert_report(_codemodel_report("cm1", "repo-x"))
        self.report_db.upsert_report(_codemodel_report("cm2", "repo-x"))
        self.assertEqual(validate.latest_codemodel_report("repo-x")["id"], "cm2")


class TestValidate(_IsolatedBrokerRegistry):
    def setUp(self):
        super().setUp()
        import report_db
        self._orig_report = report_db.DB_PATH
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        self.report_db = report_db

    def tearDown(self):
        self.report_db.DB_PATH = self._orig_report
        super().tearDown()

    def test_no_repo_link_returns_none(self):
        self.assertIsNone(validate.validate(_dast_report("d1"), {}))

    def test_repo_linked_but_never_scanned_returns_none(self):
        broker_config.upsert_repo(_repo())
        target = {"github_full_name": "acme/widget"}
        self.assertIsNone(validate.validate(_dast_report("d1"), target))

    def test_produces_a_confirmed_path_when_dast_matches_codemodel_sink(self):
        broker_config.upsert_repo(_repo())
        self.report_db.upsert_report(_codemodel_report("cm1", "repo-1"))
        target = {"github_full_name": "acme/widget", "name": "widget-prod"}

        report = validate.validate(_dast_report("d1", locus="/page2"), target)

        self.assertIsNotNone(report)
        self.assertEqual(report["methodology"], "attackpath")
        self.assertGreaterEqual(report["scan_metadata"]["paths_total"], 1)
        self.assertGreaterEqual(report["scan_metadata"]["confirmed"], 1)
        self.assertIn("widget-prod", report["title"])

    def test_no_matching_sink_yields_zero_confirmed_paths_not_none(self):
        """A validation run that finds nothing to confirm is still a real,
        renderable report — the caller distinguishes 'nothing to validate
        against' (None) from 'validated and found no confirmed path' (a
        report with confirmed=0), and only the former is a no-op."""
        broker_config.upsert_repo(_repo())
        self.report_db.upsert_report(_codemodel_report("cm1", "repo-1", tainted=False))
        target = {"github_full_name": "acme/widget"}

        report = validate.validate(_dast_report("d1", locus="/totally/unrelated"), target)

        self.assertIsNotNone(report)
        self.assertEqual(report["scan_metadata"]["confirmed"], 0)


if __name__ == "__main__":
    unittest.main()
