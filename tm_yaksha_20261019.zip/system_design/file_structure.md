# Repository File Structure

Total items: 56

```
📁 .github
📄 .gitignore
📄 CODE_OF_CONDUCT.md
📄 CONTRIBUTING.md
📄 LICENSE
📄 README.md
📁 diagrams
  📄 funding.yml
  📄 issue_template.md
  📄 pull_request_template.md
  📄 stale.yml
  📄 README.md
  📄 api-gateway.excalidraw
  📄 caching.excalidraw
  📄 cap.excalidraw
  📄 cdn.excalidraw
  📄 circuit-breaker.excalidraw
  📄 clustering.excalidraw
  📄 consistent-hashing.excalidraw
  📄 cqrs.excalidraw
  📄 database-replication.excalidraw
  📄 db-dbms.excalidraw
  📄 disaster-recovery.excalidraw
  📄 distributed-transactions.excalidraw
  📄 domain-name-system.excalidraw
  📄 enterprise-service-bus.excalidraw
  📄 event-driven-architecture.excalidraw
  📄 event-sourcing.excalidraw
  📄 federated-database.excalidraw
  📄 geohashing-quadtrees.excalidraw
  📄 indexes.excalidraw
  📄 library.excalidrawlib
  📄 load-balancing.excalidraw
  📄 lp-ws-sse.excalidraw
  📄 message-brokers.excalidraw
  📄 message-queues.excalidraw
  📄 monoliths-microservices.excalidraw
  📄 n-tier-architecture.excalidraw
  📄 netflix.excalidraw
  📄 oauth-openid-connect.excalidraw
  📄 osi.excalidraw
  📄 pacelc.excalidraw
  📄 proxy.excalidraw
  📄 pubsub.excalidraw
  📄 rate-limiting.excalidraw
  📄 scaling.excalidraw
  📄 service-discovery.excalidraw
  📄 sharding.excalidraw
  📄 sso.excalidraw
  📄 tcp-udp.excalidraw
  📄 transactions.excalidraw
  📄 twitter.excalidraw
  📄 uber.excalidraw
  📄 url-shortener.excalidraw
  📄 virtualization-containerization.excalidraw
  📄 whatsapp.excalidraw
```
