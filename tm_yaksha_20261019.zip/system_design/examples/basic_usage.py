"""Small example for using system_design_skill.py as a library."""

from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from system_design_full import SystemDesignKnowledgeBase  # noqa: E402


def main() -> int:
    skill = SystemDesignKnowledgeBase.load(ROOT)

    print(skill.metadata.name)
    print()
    print(skill.summarize("Caching", sentences=2))
    print()

    for result in skill.search("consistent hashing", limit=3):
        print(f"{result.section.title}: score={result.score}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
