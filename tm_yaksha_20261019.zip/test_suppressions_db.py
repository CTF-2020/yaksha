"""Tests for the SQLite suppressions store (suppressions/db.py).

Isolates onto a temp DB, styled like test_report_db.py's TestReportDbModule.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from suppressions import db
from suppressions.model import Suppression


def _supp(**kw):
    base = {"scope": "rule", "match": "WEB-A03-01", "reason": "accepted risk",
            "author": "alice"}
    base.update(kw)
    return Suppression.from_dict(base)


class TestSuppressionsDb(unittest.TestCase):
    def setUp(self):
        self._orig_path = db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        db.DB_PATH = Path(self._td.name) / "suppressions.db"
        db.init()

    def _restore(self):
        db.DB_PATH = self._orig_path

    def test_upsert_and_count(self):
        db.upsert(_supp())
        self.assertEqual(db.count(), 1)

    def test_dedup_on_scope_match_report(self):
        db.upsert(_supp(match="R1", reason="first"))
        db.upsert(_supp(match="R1", reason="second"))
        all_ = db.all_suppressions()
        self.assertEqual(len(all_), 1)
        self.assertEqual(all_[0].reason, "second")

    def test_different_report_id_does_not_dedup(self):
        db.upsert(_supp(match="R1", report_id="rep-a"))
        db.upsert(_supp(match="R1", report_id="rep-b"))
        self.assertEqual(db.count(), 2)

    def test_delete(self):
        s = _supp()
        db.upsert(s)
        self.assertTrue(db.delete(s.id))
        self.assertFalse(db.delete(s.id))
        self.assertEqual(db.count(), 0)

    def test_prune_expired(self):
        db.upsert(_supp(match="R1", expires_at=1000))
        db.upsert(_supp(match="R2", expires_at=0))
        self.assertEqual(db.prune_expired(now=5000), 1)
        self.assertEqual(db.count(), 1)

    def test_backfill_is_additive_and_idempotent(self):
        n = db.backfill([_supp(match="R1"), _supp(match="R2")])
        self.assertEqual(n, 2)
        self.assertEqual(db.count(), 2)

    def test_delete_all(self):
        db.upsert(_supp(match="R1"))
        db.upsert(_supp(match="R2"))
        self.assertEqual(db.delete_all(), 2)
        self.assertEqual(db.count(), 0)

    def test_db_path_survives_repointing(self):
        # A fresh DB_PATH must always get its schema created (no stale
        # "already initialized" shortcut) — matches report_db's contract.
        db.upsert(_supp())
        other = Path(tempfile.mkdtemp()) / "other.db"
        db.DB_PATH = other
        self.assertEqual(db.count(), 0)


if __name__ == "__main__":
    unittest.main()
