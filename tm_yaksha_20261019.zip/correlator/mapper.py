"""Render correlated findings into the Yaksha Guard TM report shape.

Target shape is the same ``report.categories[]`` the existing viewer renders, so
a correlation run appears as just another report — one card per correlated
weakness, sorted by mediated priority, with each contributing tool's evidence as
a threat ticket inside it. The card's verdict, confidence and corroboration count
are the value this engine adds over reading the source reports individually.
"""
from __future__ import annotations

import time

import ssvc

from .model import SEVERITY_SCORE, SEVERITIES, SEVERITY_ORDER, SourceKind, Verdict

_VERDICT_LABEL = {
    Verdict.ACTIVELY_EXPLOITED: "Actively exploited (production incident)",
    Verdict.CONFIRMED_EXPLOITABLE: "Confirmed exploitable",
    Verdict.CORROBORATED: "Corroborated",
    Verdict.DESIGN_GAP: "Design gap (unvalidated)",
    Verdict.BLIND_SPOT: "Blind spot (unmodeled)",
}
_KIND_LABEL = {
    SourceKind.CODE: "Static (code)",
    SourceKind.RUNTIME: "Dynamic (runtime)",
    SourceKind.DESIGN: "Threat model (design)",
    SourceKind.INCIDENT: "Production incident",
}
_VERDICT_ACTION = {
    Verdict.ACTIVELY_EXPLOITED:
        "A real production incident (WAF block, SIEM alert, IR ticket, bug-bounty "
        "report) confirms this weakness was actually triggered — not a lab proof, "
        "an observed fact. Treat as the highest-priority item in the backlog and "
        "remediate immediately.",
    Verdict.CONFIRMED_EXPLOITABLE:
        "Both a static root cause and a runtime proof exist — treat as a live, "
        "reachable vulnerability and remediate before release.",
    Verdict.CORROBORATED:
        "A modeled threat is backed by concrete scan evidence — prioritise; the "
        "design risk is real, not theoretical.",
    Verdict.DESIGN_GAP:
        "This threat was modeled but neither confirmed nor cleared by scanning — "
        "either it is well-mitigated or it is untested. Add a targeted test/scan "
        "to close the loop.",
    Verdict.BLIND_SPOT:
        "Scanning found this but the threat model does not cover it — update the "
        "threat model so the weakness class is tracked and owned.",
}


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _threat_from_observation(obs) -> dict:
    meta = [b for b in (
        obs.owasp,
        ", ".join(sorted(obs.cwes)) if obs.cwes else "",
        "STRIDE " + "/".join(obs.stride) if obs.stride else "",
    ) if b]
    return {
        "name": f"[{_KIND_LABEL[obs.kind]}] {obs.locus_label}",
        "description": obs.evidence or obs.title,
        "attack_vector": f"{obs.title}  ·  from {obs.report_title or obs.report_id}",
        "control_objective": " | ".join(meta),
        "source_kind": obs.kind.value,
        "source_report": obs.report_id,
    }


def _category_from_finding(finding, index: int) -> dict:
    verdict = finding.verdict
    kinds = finding.kinds
    tools = ", ".join(_KIND_LABEL[k] for k in
                      (SourceKind.CODE, SourceKind.RUNTIME, SourceKind.DESIGN,
                       SourceKind.INCIDENT) if k in kinds)
    remediations = [o.remediation for o in finding.observations if o.remediation]
    seen, merged = set(), []
    for r in remediations:
        if r not in seen:
            seen.add(r)
            merged.append(r)
    remediation = merged[0] if merged else "Review and remediate per secure-coding guidance."
    all_cwes = sorted({c for o in finding.observations for c in o.cwes})
    owasp_ids = sorted({o.owasp for o in finding.observations if o.owasp})
    locations = list(dict.fromkeys(
        loc for o in finding.observations for loc in [o.locus_label]
        if loc and loc != "(no specific location)"))

    ssvc_result = ssvc.decide(
        severity=finding.severity, verdict=verdict.value,
        exploitability=finding.exploitability, business_impact=finding.business_impact,
        epss_kev=finding.epss_kev, epss_kev_reason=finding.epss_kev_reason)

    description = (
        f"{_VERDICT_LABEL[verdict]} — correlated across {finding.source_count} "
        f"independent source(s): {tools}. {_VERDICT_ACTION[verdict]}"
    )
    if finding.exploitability_reason:
        description += f" Code-model reachability: {finding.exploitability_reason}"
    if finding.business_impact_reason:
        description += f" Business impact: {finding.business_impact_reason}."
    if finding.epss_kev_reason:
        description += f" Real-world exploitation: {finding.epss_kev_reason}"
    if finding.dependency_reachability:
        reachable_names = ", ".join(sorted(finding.dependency_reachability))
        description += (
            f" Reachable component(s) among those flagged: {reachable_names} — "
            f"a real call into this package was traced from an entry point; "
            f"any other component(s) in this finding have no such proof yet."
        )
    description += f" SSVC recommendation ({ssvc_result.action_label}): {ssvc_result.reason}"

    notes = (
        f"Verdict: {_VERDICT_LABEL[verdict]}  ·  confidence: {finding.confidence:.0%}  ·  "
        f"sources: {tools}  ·  "
        f"OWASP: {', '.join(owasp_ids) or 'n/a'}  ·  CWE: {', '.join(all_cwes) or 'n/a'}  ·  "
        f"SSVC: {ssvc_result.action_label}"
    )
    if finding.confidence_reason:
        notes += f"  ·  {finding.confidence_reason}"
    if finding.exploitability_reason:
        notes += f"  ·  exploitability: {finding.exploitability:.0%} ({finding.exploitability_reason})"
    if finding.business_impact_reason:
        notes += f"  ·  business impact: {finding.business_impact:.0%} ({finding.business_impact_reason})"
    if finding.epss_kev_reason:
        notes += f"  ·  real-world exploitation: {finding.epss_kev:.0%} ({finding.epss_kev_reason})"

    return {
        "id": f"CORR-{index:03d}",
        "category": "Correlation",
        "name": f"{finding.family_title}",
        "title": f"{finding.family_title}",
        "risk": finding.severity,
        "risk_score": SEVERITY_SCORE.get(finding.severity, 1),
        "_source": "CORRELATION",
        "ruleset": "Correlation",
        "verdict": verdict.value,
        "verdict_label": _VERDICT_LABEL[verdict],
        "confidence": finding.confidence,
        "confidence_reason": finding.confidence_reason,
        "corroboration": finding.source_count,
        "base_severity": finding.base_severity,
        "priority_score": finding.priority,
        "exploitability": finding.exploitability,
        "exploitability_reason": finding.exploitability_reason,
        "business_impact": finding.business_impact,
        "business_impact_reason": finding.business_impact_reason,
        "epss_kev": finding.epss_kev,
        "epss_kev_reason": finding.epss_kev_reason,
        "ssvc_action": ssvc_result.action,
        "ssvc_action_label": ssvc_result.action_label,
        "ssvc_reason": ssvc_result.reason,
        "ssvc_decision_points": {
            "exploitation": ssvc_result.exploitation,
            "exposure": ssvc_result.exposure,
            "automatable": ssvc_result.automatable,
            "human_impact": ssvc_result.human_impact,
        },
        "dependency_reachability": finding.dependency_reachability,
        "description": description,
        "affected_components": locations[:25] or ["(no specific location)"],
        "mitigation": remediation,
        "remediation": remediation,
        "mitigations": [{"action": r, "priority": "Immediate"} for r in merged[:6]]
                       or [{"action": remediation, "priority": "Immediate"}],
        "threats": [_threat_from_observation(o) for o in finding.observations],
        "notes": notes,
    }


def _verdict_counts(findings) -> dict:
    counts = {v.value: 0 for v in Verdict}
    for f in findings:
        counts[f.verdict.value] += 1
    return counts


def findings_to_report(findings, sources: list[dict], meta: dict) -> dict:
    """Build a TM report dict from correlated findings, ready for ``_save_report``."""
    categories = [_category_from_finding(f, i + 1) for i, f in enumerate(findings)]

    counts = {s: 0 for s in SEVERITIES}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1
    overall = "Info"
    for f in findings:
        if SEVERITY_ORDER.get(f.severity, 99) < SEVERITY_ORDER.get(overall, 99):
            overall = f.severity

    verdicts = _verdict_counts(findings)
    active = verdicts[Verdict.ACTIVELY_EXPLOITED.value]
    confirmed = verdicts[Verdict.CONFIRMED_EXPLOITABLE.value]
    corroborated = verdicts[Verdict.CORROBORATED.value]
    blind = verdicts[Verdict.BLIND_SPOT.value]
    gaps = verdicts[Verdict.DESIGN_GAP.value]

    src_desc = ", ".join(
        f"{s.get('title', s.get('id', '?'))} ({s.get('methodology', '?')})"
        for s in sources) or "no sources"

    summary = (
        f"Correlated {meta.get('observation_count', 0)} finding(s) from "
        f"{len(sources)} report(s) into {len(findings)} weakness cluster(s). "
        + (f"{active} actively exploited (confirmed by a production incident), "
           if active else "")
        + f"{confirmed} confirmed exploitable (static + runtime agree), "
        f"{corroborated} corroborated (design + evidence), "
        f"{blind} blind spot(s) (evidence with no modeled threat), "
        f"{gaps} design gap(s) (modeled but unvalidated). "
        f"Sources: {src_desc}."
    )

    # Cross-source recommendations, most urgent verdicts first.
    recommendations = []
    if active:
        recommendations.append(
            f"Remediate {active} actively-exploited weakness(es) immediately — "
            "each is confirmed by a real production incident, not a lab proof.")
    if confirmed:
        recommendations.append(
            f"Remediate {confirmed} confirmed-exploitable weakness(es) next — "
            "each has both a static root cause and a runtime proof.")
    if blind:
        recommendations.append(
            f"Extend the threat model to cover {blind} blind-spot weakness(es) that "
            "scanning found but design review missed.")
    if gaps:
        recommendations.append(
            f"Add targeted tests for {gaps} modeled threat(s) that scanning neither "
            "confirmed nor cleared.")
    for c in categories:
        rec = c["mitigation"]
        if rec and rec not in recommendations:
            recommendations.append(rec)

    return {
        "title": meta.get("report_title", "Correlation Analysis"),
        "methodology": "correlation",
        "methodology_label": "Cross-Tool Correlation (Mediator)",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "analyzed_at": now_iso(),
        "summary": summary,
        "categories": categories,
        "recommendations": recommendations[:12],
        "scan_metadata": {
            "engine": "correlator",
            "source_reports": [
                {"id": s.get("id"), "title": s.get("title"),
                 "methodology": s.get("methodology")} for s in sources],
            "findings_total": len(findings),
            "verdict_counts": verdicts,
            "severity_counts": counts,
            "actively_exploited": active,
            "confirmed_exploitable": confirmed,
            "blind_spots": blind,
            "design_gaps": gaps,
            **meta,
        },
    }
