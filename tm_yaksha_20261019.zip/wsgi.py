"""wsgi.py — Production WSGI entry point.

Linux/Mac:  gunicorn --bind 0.0.0.0:5001 --workers 4 --timeout 120 --access-logfile - wsgi:application
Windows:    python wsgi.py  (uses waitress)
Docker:     CMD set in Dockerfile

Binding: defaults to loopback. Set TM_HOST=0.0.0.0 to expose beyond this
machine — the app holds GitHub tokens (broker) and drives scans on demand, so
network exposure without TM_API_KEY set means anyone on the LAN can use both.
"""
from __future__ import annotations
import os
import sys

import bootstrap_admin  # noqa: F401 — provisions TM_ADMIN_EMAIL/PASSWORD on first boot
from app import app as application


def _resolve_host() -> str:
    host = os.environ.get("TM_HOST", "127.0.0.1").strip() or "127.0.0.1"
    if host != "127.0.0.1" and not os.environ.get("TM_API_KEY", "").strip():
        print("  WARNING: binding to a non-loopback address with no TM_API_KEY set.\n"
              "  Anyone who can reach this host can run scans and read reports.\n"
              "  Set TM_API_KEY to require authentication.", file=sys.stderr)
    return host


if __name__ == "__main__":
    port = int(os.environ.get("TM_PORT", 5001))
    host = _resolve_host()
    try:
        from waitress import serve
        print(f"\n  TM — Threat Modeling Platform")
        print(f"  Production server (waitress) → http://{host}:{port}\n")
        serve(application, host=host, port=port, threads=8,
              channel_timeout=120, cleanup_interval=30)
    except ImportError:
        print("waitress not installed — falling back to Flask dev server (not for production)")
        application.run(host=host, port=port, debug=False)
