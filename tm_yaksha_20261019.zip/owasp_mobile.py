"""owasp_mobile.py — OWASP Mobile Top 10 (2024) + Kubernetes Top 10 checklist data."""
from __future__ import annotations

OWASP_MOBILE_2024: list[dict] = [
    {
        "id": "M1:2024", "name": "Improper Credential Usage", "stride": ["I", "S"],
        "items": [
            "API keys, tokens, or private keys hard-coded in app binary",
            "Credentials stored in SharedPreferences/NSUserDefaults (unencrypted)",
            "Credentials in query parameters (appear in server logs)",
        ],
        "mitigation": "Use platform keychain/keystore; never hard-code credentials; secrets manager for backend keys",
    },
    {
        "id": "M2:2024", "name": "Inadequate Supply Chain Security", "stride": ["T"],
        "items": [
            "Third-party SDKs without security review (ad, analytics SDKs)",
            "No code signing or integrity verification on app updates",
            "Dependencies not pinned to specific versions",
        ],
        "mitigation": "Review third-party SDKs; enforce code signing; pin dependency versions with hash verification",
    },
    {
        "id": "M3:2024", "name": "Insecure Authentication / Authorization", "stride": ["S", "E"],
        "items": [
            "Certificate pinning absent or bypassable (Frida, SSLUnpinning)",
            "Authentication state stored client-side and trusted by server",
            "Biometric bypass possible via device-level attack",
        ],
        "mitigation": "Certificate pinning; server-side session validation; require device integrity attestation",
    },
    {
        "id": "M4:2024", "name": "Insufficient Input / Output Validation", "stride": ["T", "I"],
        "items": [
            "Deep link parameters (myapp://) processed without validation",
            "QR code / NFC input processed without sanitization",
            "WebView loads untrusted URLs with JavaScript bridge access",
        ],
        "mitigation": "Validate all deep link parameters; disable JavaScript bridge for untrusted content; allowlist WebView URLs",
    },
    {
        "id": "M5:2024", "name": "Insecure Communication", "stride": ["I"],
        "items": [
            "HTTP used for any sensitive data transmission",
            "Sensitive data in URL query parameters (cached in proxy logs)",
        ],
        "mitigation": "TLS 1.2+ for all communication; use request body not URL for sensitive data; enforce HSTS",
    },
    {
        "id": "M6:2024", "name": "Inadequate Privacy Controls", "stride": ["I"],
        "items": [
            "Excessive permissions requested beyond app function",
            "Sensitive data in device logs accessible to other apps",
            "Clipboard used for passwords/tokens",
            "Screenshots cache sensitive screens (app switcher exposure)",
        ],
        "mitigation": "Minimum required permissions; suppress logs in production; clear clipboard on background; FLAG_SECURE on sensitive screens",
    },
    {
        "id": "M7:2024", "name": "Insufficient Binary Protections", "stride": ["T", "E"],
        "items": [
            "No root/jailbreak detection (or trivially bypassed)",
            "Debug build shipped to production",
            "Sensitive business logic in client code reversible via decompilation",
        ],
        "mitigation": "Enable ProGuard/R8 obfuscation; root/jailbreak detection; remove debug symbols from release builds",
    },
    {
        "id": "M8:2024", "name": "Security Misconfiguration", "stride": ["I", "E"],
        "items": [
            "Android: android:debuggable='true' or android:allowBackup='true' in prod",
            "iOS: ATS exceptions for HTTP traffic",
            "Firebase URLs accessible without authentication",
        ],
        "mitigation": "Review AndroidManifest.xml and Info.plist before release; enforce Firebase security rules",
    },
    {
        "id": "M9:2024", "name": "Insecure Data Storage", "stride": ["I"],
        "items": [
            "PII stored unencrypted in SQLite, files, or SharedPreferences",
            "Sensitive data on external storage accessible to other apps",
            "Keychain/KeyStore not used for credential storage",
        ],
        "mitigation": "Encrypt local databases (SQLCipher); use platform keychain/keystore; avoid external storage for sensitive data",
    },
    {
        "id": "M10:2024", "name": "Insufficient Cryptography", "stride": ["I"],
        "items": [
            "Weak algorithms: MD5, SHA-1, DES, ECB mode AES",
            "Hard-coded encryption keys",
            "IV/salt reused across encryptions",
        ],
        "mitigation": "AES-256-GCM; unique random IV per encryption; derive keys with PBKDF2/Argon2; use platform crypto APIs",
    },
]

OWASP_KUBERNETES_TOP10: list[dict] = [
    {
        "id": "K01", "name": "Insecure Workload Configurations", "stride": ["E"],
        "items": [
            "Container running as root (runAsNonRoot: false)",
            "privileged: true or allowPrivilegeEscalation: true",
            "Host namespaces shared (hostPID, hostNetwork, hostIPC)",
            "Writable root filesystem",
            "No CPU/memory resource limits (resource exhaustion DoS)",
        ],
        "mitigation": "Enforce PodSecurityStandards (Restricted); set runAsNonRoot; read-only root FS; set resource limits",
    },
    {
        "id": "K02", "name": "Supply Chain Vulnerabilities", "stride": ["T"],
        "items": [
            "Base images not scanned (Trivy, Grype) in CI",
            "Images pulled without digest pinning",
            "No image signing (Cosign, Notary)",
            "Build pipeline secrets accessible to workloads at runtime",
        ],
        "mitigation": "Image scanning in CI; digest pinning; Cosign signing; separate build secrets from runtime",
    },
    {
        "id": "K03", "name": "Overly Permissive RBAC", "stride": ["E"],
        "items": [
            "Service accounts with cluster-admin or wildcard resource permissions",
            "Default service account token auto-mounted on all pods",
            "Helm charts installed with overly broad RBAC by default",
        ],
        "mitigation": "Least-privilege RBAC; disable default SA token auto-mount; review Helm chart permissions before install",
    },
    {
        "id": "K04", "name": "Lack of Centralized Policy Enforcement", "stride": ["E"],
        "items": [
            "No admission controller (OPA/Gatekeeper, Kyverno) enforcing security baselines",
            "Workloads deployable without passing security policy checks",
            "No network policies — all pod-to-pod communication allowed",
        ],
        "mitigation": "OPA Gatekeeper or Kyverno for admission control; default-deny NetworkPolicy; PodSecurityAdmission",
    },
    {
        "id": "K05", "name": "Inadequate Logging & Monitoring", "stride": ["R"],
        "items": [
            "Kubernetes API server audit logging disabled",
            "No runtime security monitoring (Falco, Tetragon)",
            "Container stdout/stderr not forwarded to centralized logging",
        ],
        "mitigation": "Enable API server audit logging; deploy Falco for runtime anomaly detection; centralize logs",
    },
    {
        "id": "K06", "name": "Broken Authentication Mechanisms", "stride": ["S"],
        "items": [
            "Anonymous authentication enabled on API server",
            "Service account tokens used for human authentication",
            "No OIDC integration for human user authentication",
        ],
        "mitigation": "Disable anonymous auth; OIDC for human users; short-lived tokens via TokenRequest API",
    },
    {
        "id": "K07", "name": "Missing Network Segmentation Controls", "stride": ["I"],
        "items": [
            "No NetworkPolicy — all pods can communicate freely",
            "Sensitive workloads (DB, secrets manager) reachable from all namespaces",
            "Egress not restricted — compromised pod can reach external attacker infrastructure",
        ],
        "mitigation": "Default-deny ingress and egress NetworkPolicy; namespace isolation; Cilium or Calico for advanced policy",
    },
    {
        "id": "K08", "name": "Secrets Management Failures", "stride": ["I"],
        "items": [
            "Kubernetes Secrets stored base64-encoded (not encrypted at rest)",
            "Secrets mounted as environment variables (visible in process list)",
            "Secrets hard-coded in ConfigMaps or Dockerfiles",
        ],
        "mitigation": "Enable etcd encryption at rest; mount secrets as files not env vars; use Vault or KMS for secret management",
    },
    {
        "id": "K09", "name": "Misconfigured Cluster Components", "stride": ["E"],
        "items": [
            "etcd accessible without TLS or authentication",
            "kubelet with anonymous auth enabled",
            "Dashboard exposed publicly without authentication",
        ],
        "mitigation": "Secure all control plane components with TLS + auth; restrict Dashboard access; run CIS Kubernetes Benchmark",
    },
    {
        "id": "K10", "name": "Outdated & Vulnerable Kubernetes Components", "stride": ["T"],
        "items": [
            "Kubernetes version with known critical CVEs (check k8s.io/cve-feed)",
            "CNI plugin, ingress controller, or cert-manager with unpatched vulnerabilities",
            "No upgrade process defined for cluster components",
        ],
        "mitigation": "Track Kubernetes CVEs; upgrade to supported versions; automate component vulnerability scanning",
    },
]

OWASP_MOBILE: list[dict] = OWASP_MOBILE_2024 + OWASP_KUBERNETES_TOP10
