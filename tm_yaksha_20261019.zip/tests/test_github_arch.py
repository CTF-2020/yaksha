"""tests/test_github_arch.py — GitHub-repo input for threat modeling.

The analyze routes accept a git URL; the repo is cloned (broker workspace) and
its code-derived architecture is appended to the threat-model input. The URL
gate must never let the endpoint read an arbitrary local filesystem path.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

import app as tm_app
import report_db
from codemodel import describe, diagram, extractor


FLASK_APP = '''
import sqlite3
from flask import Flask, request

app = Flask(__name__)
API_KEY = "sk-live-hardcoded-123456"

@app.route("/orders", methods=["POST"])
def create_order():
    conn = sqlite3.connect("orders.db")
    conn.execute("INSERT INTO orders VALUES ('%s')" % request.form["item"])
    return "ok"
'''


def _fixture_repo(tmp_path: Path) -> Path:
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "app.py").write_text(FLASK_APP, encoding="utf-8")
    return repo


# ── describe_model rendering ──────────────────────────────────────────────────

def test_describe_model_renders_design_facts(tmp_path):
    model = extractor.build_model(str(_fixture_repo(tmp_path)))
    text = describe.describe_model(model, "https://github.com/org/repo @ abc1234")

    assert "https://github.com/org/repo @ abc1234" in text
    assert "Entry points" in text
    assert "/orders" in text
    assert "Data stores" in text or "sqlite" in text.lower()


def test_describe_model_is_capped(tmp_path):
    model = extractor.build_model(str(_fixture_repo(tmp_path)))
    # Inflate the model far past the cap.
    model.entry_points = model.entry_points * 5000
    text = describe.describe_model(model)
    assert len(text) <= describe.MAX_CHARS


# ── Code-derived DFD ──────────────────────────────────────────────────────────

def test_dfd_is_valid_mermaid_with_boundaries(tmp_path):
    model = extractor.build_model(str(_fixture_repo(tmp_path)))
    dfd = diagram.to_mermaid_dfd(model, "My App")
    # A Mermaid init directive precedes the graph header for layout tuning.
    assert dfd.startswith("%%{init:")
    assert "flowchart LR" in dfd
    assert "Actor" in dfd
    assert "subgraph" in dfd
    # The sqlite store shows up as a Mermaid cylinder node.
    assert "sqlite" in dfd.lower()
    # Balanced subgraph/end blocks (includes the Legend subgraph).
    assert dfd.count("subgraph") == dfd.count("  end")
    # Always carries a legend so the diagram is self-explanatory.
    assert 'subgraph LEGEND' in dfd


def test_dfd_flags_unauthenticated_entry(tmp_path):
    model = extractor.build_model(str(_fixture_repo(tmp_path)))
    dfd = diagram.to_mermaid_dfd(model)
    # The /orders POST has no auth control -> Actor ingress tagged unauth with
    # the Spoofing/Elevation STRIDE letters, and drawn as a red boundary cross.
    assert "S,E unauth" in dfd
    assert "classDef sevCrit" in dfd
    assert "stroke:#ef4444" in dfd


def test_dfd_marks_cleartext_external_call():
    from codemodel import model as m

    sm = m.SystemModel(root="/x")
    ep = m.EntryPoint(method="GET", path="/x", handler="h", file="a.py", line=1,
                      authenticated=True)
    sm.entry_points.append(ep)
    sm.external_calls.append(
        m.ExternalCall(kind="http", target="http://legacy.internal/api",
                       file="a.py", line=1, encrypted=False))
    dfd = diagram.to_mermaid_dfd(sm)
    assert "cleartext" in dfd
    # Cleartext egress is Information Disclosure + Tampering, styled a warn box.
    assert "I,T cleartext" in dfd
    assert "classDef warnbox" in dfd


def test_dfd_handles_empty_model():
    from codemodel import model as m
    dfd = diagram.to_mermaid_dfd(m.SystemModel())
    assert dfd.startswith("%%{init:")
    assert "flowchart LR" in dfd
    assert dfd.count("subgraph") == dfd.count("  end")


def _model_with_reachable_sink(tainted: bool):
    from codemodel import model as m
    sm = m.SystemModel(root="/x")
    ep = m.EntryPoint(method="POST", path="/orders", handler="create_order",
                      file="app/orders.py", line=12, authenticated=False)
    ep.reachable_sinks = [
        m.Sink(kind="sql", family="sql-injection", cwe="CWE-89",
               name="cursor.execute", file="app/orders.py", line=20, tainted=tainted),
    ]
    sm.entry_points.append(ep)
    return sm


def test_dfd_draws_reachable_sinks_as_dangerous_operations():
    dfd = diagram.to_mermaid_dfd(_model_with_reachable_sink(tainted=True), "App")
    # The sink shows up in its own boundary as a parallelogram node.
    assert "Dangerous operations" in dfd
    assert "SQL query @ orders.py:20" in dfd
    assert dfd.count("subgraph") == dfd.count("  end")


def test_dfd_tainted_flow_is_a_labelled_attack_edge():
    dfd = diagram.to_mermaid_dfd(_model_with_reachable_sink(tainted=True))
    # Real attack path entry -> sink, labelled with the STRIDE tag + CWE, and
    # highlighted as a thick red link via linkStyle (not a plain edge).
    assert "|T CWE-89|" in dfd
    assert "stroke:#ef4444,stroke-width:3px" in dfd
    # A tainted SQL sink is a High-severity node.
    assert "classDef sevHigh" in dfd


def test_dfd_untainted_sink_is_warn_not_danger():
    dfd = diagram.to_mermaid_dfd(_model_with_reachable_sink(tainted=False))
    # Untainted reachable sink: no CWE attack label, no thick-red attack link.
    assert "|T CWE-89|" not in dfd
    assert "stroke:#ef4444,stroke-width:3px" not in dfd
    assert "classDef warnbox" in dfd


def test_dfd_threat_summary_counts_exploitable_paths():
    dfd = diagram.to_mermaid_dfd(_model_with_reachable_sink(tainted=True), "App")
    # The trust-boundary title carries a derived threat summary.
    assert "1 exploitable path(s)" in dfd
    assert "1 unauth entry(s)" in dfd


def test_dfd_flags_hardcoded_secret():
    from codemodel import model as m
    sm = m.SystemModel(root="/x")
    sm.secrets.append(m.Secret(name="API_KEY", file="settings.py", line=3, managed=False))
    sm.secrets.append(m.Secret(name="DB_URL", file="settings.py", line=4, managed=True))
    dfd = diagram.to_mermaid_dfd(sm)
    assert "Hardcoded secrets" in dfd
    assert "API_KEY" in dfd          # hardcoded -> shown
    assert "DB_URL" not in dfd       # managed -> not a finding
    assert dfd.count("subgraph") == dfd.count("  end")


# ── URL gate: no filesystem reach ─────────────────────────────────────────────

@pytest.mark.parametrize("bad", [
    r"C:\Users\User\secrets",
    "/etc",
    "..",
    "not a url at all",
    "",
])
def test_github_arch_rejects_non_git_urls(bad):
    with pytest.raises(ValueError):
        tm_app._architecture_from_github(bad)


def test_github_arch_rejects_file_scheme_by_default(tmp_path):
    # looks_like_git_url accepts file://, so the broker clone policy must refuse it.
    with pytest.raises(ValueError):
        tm_app._architecture_from_github(f"file:///{tmp_path.as_posix()}")


def test_github_arch_rejects_oversized_url():
    with pytest.raises(ValueError):
        tm_app._architecture_from_github("https://github.com/a/" + "b" * 500)


# ── Route integration (clone mocked out) ──────────────────────────────────────

def _isolate(tmp_path, monkeypatch):
    monkeypatch.setattr(tm_app, "REPORTS_DIR", tmp_path)
    monkeypatch.setattr(report_db, "DB_PATH", tmp_path / "reports.db")


def test_analyze_route_uses_github_derived_architecture(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    monkeypatch.setattr(
        tm_app, "_github_arch_and_diagram",
        lambda url, branch="": (f"DERIVED-ARCH for {url} ({branch or 'default'})",
                                "flowchart LR\n  A-->B"))

    captured = {}

    def fake_analyze(api_key, architecture_text, **kwargs):
        captured["arch"] = architecture_text
        return {"title": kwargs.get("title", "T"), "methodology": "owasp",
                "summary": "ok", "overall_risk": "Low", "categories": [],
                "recommendations": [], "analyzed_at": "2026-07-17T00:00:00"}

    monkeypatch.setattr(tm_app.analyzer, "analyze", fake_analyze)

    client = tm_app.app.test_client()
    resp = client.post(
        "/api/analyze",
        json={"title": "Repo TM", "api_key": "", "architecture": "",
              "methodology": "offline",
              "github_url": "https://github.com/org/repo", "github_branch": "main"},
        headers={"X-CSRF-Token": tm_app._CSRF_TOKEN})

    assert resp.status_code == 200, resp.get_data(as_text=True)
    assert "DERIVED-ARCH for https://github.com/org/repo (main)" in captured["arch"]
    # The code-derived DFD is attached to the report diagrams.
    assert resp.get_json()["report"]["diagrams"]["codemodel"] == "flowchart LR\n  A-->B"
    # Typed text + derived text are merged when both are present.
    resp = client.post(
        "/api/analyze",
        json={"architecture": "My typed design.", "api_key": "",
              "methodology": "offline",
              "github_url": "https://github.com/org/repo"},
        headers={"X-CSRF-Token": tm_app._CSRF_TOKEN})
    assert resp.status_code == 200
    assert captured["arch"].startswith("My typed design.")
    assert "DERIVED-ARCH" in captured["arch"]


def test_analyze_route_no_github_has_no_codemodel_diagram(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    monkeypatch.setattr(
        tm_app.analyzer, "analyze",
        lambda api_key, arch, **kw: {"title": "T", "methodology": "owasp",
                                     "summary": "ok", "overall_risk": "Low",
                                     "categories": [], "recommendations": [],
                                     "analyzed_at": "2026-07-17T00:00:00"})
    client = tm_app.app.test_client()
    resp = client.post(
        "/api/analyze",
        json={"architecture": "Plain typed design.", "api_key": "",
              "methodology": "offline"},
        headers={"X-CSRF-Token": tm_app._CSRF_TOKEN})
    assert resp.status_code == 200
    assert "codemodel" not in (resp.get_json()["report"].get("diagrams") or {})


def test_analyze_route_surfaces_clone_errors_as_400(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)

    def boom(url, branch=""):
        raise ValueError("git clone failed: repository not found")

    monkeypatch.setattr(tm_app, "_github_arch_and_diagram", boom)
    client = tm_app.app.test_client()
    resp = client.post(
        "/api/analyze",
        json={"architecture": "", "api_key": "", "methodology": "offline",
              "github_url": "https://github.com/org/missing"},
        headers={"X-CSRF-Token": tm_app._CSRF_TOKEN})
    assert resp.status_code == 400
    assert "repository not found" in resp.get_json()["error"]


def test_analyze_stream_route_accepts_github_url(tmp_path, monkeypatch):
    _isolate(tmp_path, monkeypatch)
    monkeypatch.setattr(tm_app, "_github_arch_and_diagram",
                        lambda url, branch="": ("DERIVED-ARCH stream",
                                                "flowchart LR\n  A-->B"))
    monkeypatch.setattr(
        tm_app.analyzer, "analyze",
        lambda api_key, arch, **kw: {"title": "T", "methodology": "owasp",
                                     "summary": "ok", "overall_risk": "Low",
                                     "categories": [], "recommendations": [],
                                     "analyzed_at": "2026-07-17T00:00:00"})
    client = tm_app.app.test_client()
    resp = client.post(
        "/api/analyze/stream",
        json={"architecture": "", "api_key": "", "methodology": "offline",
              "github_url": "https://github.com/org/repo"},
        headers={"X-CSRF-Token": tm_app._CSRF_TOKEN})
    assert resp.status_code == 200
    assert resp.get_json()["job_id"]
