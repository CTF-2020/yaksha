"""guard/diff.py — turn a unified diff into per-file added-line sets.

A pre-merge / coding-agent gate must fail on code a change *introduces*, not
on pre-existing findings in a file it happens to touch — otherwise editing one
line of a legacy file resurrects all of that file's debt as a blocker, which
trains people to route around the gate instead of trusting it. This module is
the piece that makes the gate diff-scoped: parse `git diff` output into
{file: {added line numbers}}, so the scanner can keep only findings that land
on a line the diff actually added.
"""
from __future__ import annotations

import re

_NEW_FILE_RE = re.compile(r"^\+\+\+ b/(.+)$")
_HUNK_RE = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@")


def parse_added_lines(diff_text: str) -> dict[str, set[int]]:
    """Map each file touched by a unified diff to the new-side lines it adds.

    Only ``+`` lines count toward the result. Context (` `) and removed (``-``)
    lines still advance the new-side line counter so later hunks in the same
    file land on the right numbers; a ``-`` line consumes no new-side number
    since it only exists on the old side.
    """
    added: dict[str, set[int]] = {}
    current_file: str | None = None
    line_no: int | None = None

    for raw in diff_text.splitlines():
        m = _NEW_FILE_RE.match(raw)
        if m:
            current_file = m.group(1)
            added.setdefault(current_file, set())
            line_no = None
            continue

        h = _HUNK_RE.match(raw)
        if h:
            line_no = int(h.group(1))
            continue

        if current_file is None or line_no is None:
            continue  # before the first hunk of a file, or a non-diff line

        if raw.startswith("+"):
            added[current_file].add(line_no)
            line_no += 1
        elif raw.startswith("-"):
            pass  # old-side only
        elif raw.startswith("\\"):
            pass  # "\ No newline at end of file" — not a real line
        else:
            line_no += 1  # context line, present on both sides

    return added
