"""lineage — persistent design-to-code threat traceability.

Tracks one underlying risk's identity across every report that has ever
touched it, so a design-time prediction and the code finding that later
realizes it are linked, not just independently reported. See lineage/engine.py
for the matching logic and lineage/service.py for the API-facing orchestration.
"""
