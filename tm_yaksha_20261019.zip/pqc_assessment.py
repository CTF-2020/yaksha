"""pqc_assessment.py — Post-Quantum Cryptography assessment module.

Evaluates architecture descriptions and configurations for quantum-vulnerable algorithms
and provides migration recommendations aligned to NIST PQC standards.

Source: Green (2025) Ch.5 p.174 — Quantum Computing Impact on Cryptography
  - Shor's algorithm breaks RSA/ECC/DH
  - NIST PQC standards: ML-KEM (key encapsulation), ML-DSA (digital signatures), SLH-DSA (hash-based signatures)
"""
from __future__ import annotations
import re

# ── Vulnerable algorithm patterns ──────────────────────────────────────────────
QUANTUM_VULNERABLE: list[dict] = [
    {
        "algorithm": "RSA",
        "pattern":   r"\brsa\b|\brsa[-_]\d{3,4}\b",
        "use_case":  "Asymmetric encryption, digital signatures, TLS key exchange",
        "broken_by": "Shor's algorithm (polynomial time on quantum computer)",
        "severity":  "Critical",
        "migration": "ML-KEM (key encapsulation) + ML-DSA (signatures) from NIST FIPS 203/204",
        "timeline":  "Q-Day estimated 2030–2035; begin migration now for long-lived systems",
    },
    {
        "algorithm": "ECDSA / ECC",
        "pattern":   r"\becdsa\b|\becc\b|\belliptic curve\b|\bp-256\b|\bp-384\b|\bp-521\b|\bsecp256\b|\bsecp384\b",
        "use_case":  "Digital signatures (TLS, code signing, JWT RS256/ES256), key exchange",
        "broken_by": "Shor's algorithm",
        "severity":  "Critical",
        "migration": "ML-DSA (FIPS 204) for signatures; SLH-DSA (FIPS 205) as stateless alternative",
        "timeline":  "Urgent for code signing keys with long verification validity",
    },
    {
        "algorithm": "Diffie-Hellman (DH/DHE)",
        "pattern":   r"\bdiffie.hellman\b|\bdhe\b|\bdhparam\b|\bgroup14\b|\bgroup16\b|\bmodp\b",
        "use_case":  "TLS key exchange, IKE/IPSec, SSH",
        "broken_by": "Shor's algorithm",
        "severity":  "High",
        "migration": "ML-KEM (FIPS 203) for key encapsulation; use X25519+ML-KEM768 hybrid in TLS 1.3",
        "timeline":  "Enable hybrid key exchange in TLS 1.3 immediately as an interim measure",
    },
    {
        "algorithm": "3DES / Triple DES",
        "pattern":   r"\b3des\b|\btriple.des\b|\btdes\b|\bdes3\b|\bdes-ede\b",
        "use_case":  "Legacy symmetric encryption (should not be in use)",
        "broken_by": "Classical cryptanalysis (SWEET32 attack); quantum accelerates further",
        "severity":  "Critical",
        "migration": "AES-256-GCM immediately — 3DES is already deprecated by NIST (2017)",
        "timeline":  "Immediate — 3DES has known classical attacks; quantum is secondary concern",
    },
    {
        "algorithm": "MD5",
        "pattern":   r"\bmd5\b|\bmd5sum\b",
        "use_case":  "Hash functions (broken classically)",
        "broken_by": "Classical collision attacks; quantum Grover's algorithm halves effective key length",
        "severity":  "Critical",
        "migration": "SHA-256 minimum; SHA-3 (Keccak) preferred; SHA-512 for highest assurance",
        "timeline":  "Immediate — MD5 is classically broken",
    },
    {
        "algorithm": "SHA-1",
        "pattern":   r"\bsha.?1\b|\bsha1\b",
        "use_case":  "Hash functions",
        "broken_by": "Classical SHAttered collision attack; Grover's reduces effective security to 80-bit",
        "severity":  "High",
        "migration": "SHA-256 or SHA-3; for TLS use SHA-384+ in certificate signatures",
        "timeline":  "Immediate — SHA-1 certificates deprecated by all major browsers",
    },
    {
        "algorithm": "RC4",
        "pattern":   r"\brc4\b|\barcfour\b",
        "use_case":  "Stream cipher (legacy TLS)",
        "broken_by": "Classical bias attacks; prohibited by RFC 7465",
        "severity":  "Critical",
        "migration": "AES-256-GCM or ChaCha20-Poly1305 in TLS 1.3",
        "timeline":  "Immediate — RC4 is prohibited in TLS",
    },
    {
        "algorithm": "RSA < 2048-bit",
        "pattern":   r"\brsa.?1024\b|\brsa.?512\b|\bkey.?size.?1024\b",
        "use_case":  "Weak RSA key sizes",
        "broken_by": "Classical factorisation already feasible for 512/1024-bit; quantum compounds",
        "severity":  "Critical",
        "migration": "RSA-3072 or RSA-4096 as classical interim; migrate to ML-DSA/ML-KEM for PQC",
        "timeline":  "Immediate — 1024-bit RSA is classically broken",
    },
]

# ── PQC Migration standards ────────────────────────────────────────────────────
PQC_STANDARDS: list[dict] = [
    {
        "standard":    "ML-KEM (CRYSTALS-Kyber)",
        "fips":        "FIPS 203",
        "use_case":    "Key Encapsulation Mechanism (replaces RSA/DH for key exchange)",
        "security_level": "ML-KEM-512 (NIST L1), ML-KEM-768 (L3), ML-KEM-1024 (L5)",
        "hybrid_mode": "X25519+ML-KEM-768 in TLS 1.3 for hybrid classical+PQC key exchange",
        "nist_url":    "https://doi.org/10.6028/NIST.FIPS.203",
    },
    {
        "standard":    "ML-DSA (CRYSTALS-Dilithium)",
        "fips":        "FIPS 204",
        "use_case":    "Digital Signatures (replaces ECDSA/RSA for signing)",
        "security_level": "ML-DSA-44 (L2), ML-DSA-65 (L3), ML-DSA-87 (L5)",
        "hybrid_mode": "Ed25519+ML-DSA-65 hybrid for code signing during transition",
        "nist_url":    "https://doi.org/10.6028/NIST.FIPS.204",
    },
    {
        "standard":    "SLH-DSA (SPHINCS+)",
        "fips":        "FIPS 205",
        "use_case":    "Stateless Hash-Based Signatures (conservative, no structured lattice assumptions)",
        "security_level": "SLH-DSA-SHA2-128s (L1), SLH-DSA-SHAKE-256s (L5)",
        "hybrid_mode": "Best for firmware signing and long-validity certificates — no hybrid mode needed",
        "nist_url":    "https://doi.org/10.6028/NIST.FIPS.205",
    },
]

# ── Quantum-safe algorithms ────────────────────────────────────────────────────
QUANTUM_SAFE: list[str] = [
    "AES-128", "AES-256", "AES-GCM", "ChaCha20-Poly1305",  # symmetric (Grover halves, but still safe at 256-bit)
    "SHA-256", "SHA-384", "SHA-512", "SHA-3", "BLAKE2", "BLAKE3",  # hashing (Grover halves, 256-bit → 128-bit security)
    "ML-KEM", "ML-DSA", "SLH-DSA",  # NIST PQC standards
    "CRYSTALS-Kyber", "CRYSTALS-Dilithium", "SPHINCS+",  # underlying algorithms
]


def assess_text(text: str) -> dict:
    """
    Scan architecture text for quantum-vulnerable cryptographic algorithms.
    Returns assessment report with findings and migration recommendations.
    """
    text_lower = text.lower()
    findings: list[dict] = []
    seen_algorithms: set[str] = set()

    for entry in QUANTUM_VULNERABLE:
        if re.search(entry["pattern"], text_lower):
            alg = entry["algorithm"]
            if alg in seen_algorithms:
                continue
            seen_algorithms.add(alg)
            findings.append({
                "algorithm":  alg,
                "severity":   entry["severity"],
                "use_case":   entry["use_case"],
                "broken_by":  entry["broken_by"],
                "migration":  entry["migration"],
                "timeline":   entry["timeline"],
            })

    # Check for PQC indicators (positive)
    pqc_detected = [s for s in QUANTUM_SAFE if s.lower() in text_lower]

    # Determine overall risk
    sevs = {f["severity"] for f in findings}
    if "Critical" in sevs:
        overall_risk = "Critical"
    elif "High" in sevs:
        overall_risk = "High"
    elif "Medium" in sevs:
        overall_risk = "Medium"
    elif findings:
        overall_risk = "Low"
    else:
        overall_risk = "None"

    # Priority finding for action
    priority_order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    sorted_findings = sorted(findings, key=lambda f: priority_order.get(f["severity"], 4))

    summary = (
        f"PQC Assessment: {len(findings)} quantum-vulnerable algorithm(s) detected. "
        f"Overall risk: {overall_risk}. "
        + (f"PQC-safe algorithms present: {', '.join(pqc_detected[:3])}." if pqc_detected else "No NIST PQC algorithms detected.")
    )

    return {
        "overall_risk":          overall_risk,
        "findings":              sorted_findings,
        "findings_count":        len(findings),
        "critical_count":        sum(1 for f in findings if f["severity"] == "Critical"),
        "pqc_safe_detected":     pqc_detected,
        "pqc_standards":         PQC_STANDARDS,
        "summary":               summary,
        "migration_urgency":     "Immediate" if "Critical" in sevs else ("Within 12 months" if "High" in sevs else "Within 24 months"),
        "recommended_first_step": sorted_findings[0]["migration"] if sorted_findings else "No vulnerable algorithms detected — document PQC readiness for future review",
    }


def pqc_to_category(assessment: dict) -> dict | None:
    """Convert PQC assessment to analyzer 'category' format for UI rendering."""
    if not assessment["findings"]:
        return None
    return {
        "id":    "PQC",
        "name":  "Post-Quantum Cryptography Risk",
        "risk":  assessment["overall_risk"],
        "risk_score": {"Critical": 9, "High": 7, "Medium": 5, "Low": 3}.get(assessment["overall_risk"], 5),
        "affected_components": [f["algorithm"] for f in assessment["findings"]],
        "threats": [
            {
                "name":         f"{f['algorithm']} — Quantum Vulnerable",
                "description":  f"Broken by {f['broken_by']}. Use case: {f['use_case']}",
                "attack_vector": "Quantum computer running Shor's or Grover's algorithm",
                "impact":        f"{f['severity']} — {f['timeline']}",
            }
            for f in assessment["findings"][:4]
        ],
        "mitigations": [
            {"action": f"Replace {f['algorithm']} with {f['migration']}", "priority": "Immediate" if f["severity"] == "Critical" else "Short-term"}
            for f in assessment["findings"][:4]
        ],
        "notes": assessment["summary"],
        "pqc_standards": assessment["pqc_standards"],
        "migration_urgency": assessment["migration_urgency"],
    }
