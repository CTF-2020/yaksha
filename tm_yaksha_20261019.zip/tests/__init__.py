# Package marker: without this, `python -m unittest discover -s . -p "test_*.py"`
# silently skips this directory (unittest discovery only descends into packages),
# leaving 161 tests unrun.
