# PRD — Yaksha Guard: Unified Security Assurance Platform

**Status:** Draft v1 · **Owner:** Security Engineering · **Last updated:** 2026-07-16

---

## 1. Summary

Yaksha Guard today is several capable-but-separate tools sharing one Flask app: a
design-time **threat modeling** analyzer, a **SAST** broker driving a static
code scanner, a **DAST** engine that drives a running app, a **code-derived
threat model** engine, and a **correlation (mediator) engine** that reconciles
their findings. This PRD defines the product that ties them into a single,
lifecycle-spanning security assurance platform: **one system model, assessed at
design, in code, and at runtime, with every finding reconciled into one
prioritized, verdict-driven view.**

The thesis: individual scanners each produce a partial, noisy picture. The value
is not another scanner — it is the **mediator layer** that says *"this SQL
injection was modeled in design, found in code, and proven at runtime; it is
confirmed-exploitable, fix it first"* versus *"this was modeled but never tested"*
or *"code found this but the threat model never covered it."*

## 2. Problem statement

Security teams run design review, SAST, and DAST as disconnected activities. The
result:

- **No corroboration.** A SAST "possible SQLi" and a DAST "confirmed SQLi" at the
  same endpoint are never linked, so triage can't tell theoretical from proven.
- **Blind spots go unnoticed.** Code/runtime scanners find weaknesses the threat
  model never anticipated — and nobody updates the model.
- **Design gaps go unvalidated.** Threats are modeled and then neither confirmed
  nor cleared by any scan; they sit forever as "unknown."
- **Alert fatigue.** Duplicate, uncorrelated findings across three tools bury the
  few that matter.
- **No lifecycle memory.** Nothing tracks whether a modeled threat was ever
  actually tested, or whether a system's real attack surface matches its diagram.

## 3. Goals / Non-goals

### Goals
- G1 — A single platform that ingests **design, static, and dynamic** findings for
  one system and produces **one correlated, deduplicated, prioritized report**.
- G2 — Every correlated finding carries an actionable **verdict**:
  confirmed-exploitable, corroborated, design-gap, or blind-spot.
- G3 — **Reconcile code/runtime reality against the threat model** — surface drift
  (modeled-but-absent, present-but-unmodeled).
- G4 — First-class **SDLC integration**: CI gates, SARIF output, PR feedback.
- G5 — **Safe by construction** — never executes analyzed code, never scans an
  unregistered target, crash-safe persistence.
- G6 — **Measurable** — the platform reports its own detection accuracy and
  coverage, not just findings.

### Non-goals (this version)
- N1 — Not a replacement for a commercial multi-language SAST; deep IR/dataflow
  across many languages is a separate, longer track.
- N2 — Not a runtime protection / WAF / RASP product.
- N3 — Not an autonomous exploit or attack tool; DAST stays non-destructive.
- N4 — No multi-tenant SaaS/billing in this version (single-org deployment).

## 4. Users & personas

| Persona | Need the platform serves |
| --- | --- |
| **Security architect** | Build a threat model, then see which modeled threats are actually validated by code/runtime evidence, and where the model is incomplete. |
| **AppSec engineer** | One triage queue where duplicates are merged and confirmed-exploitable findings float to the top with proof. |
| **Developer** | Findings inline on the PR (SARIF), with a clear fix and a signal of how certain the platform is. |
| **Eng/Sec leadership** | Coverage and trend: how much of the attack surface is modeled, tested, and clean over time. |

## 5. The unified concept

```
        DESIGN                     CODE                      RUNTIME
   Threat Model engine     SAST + Code-Model engine        DAST engine
   (STRIDE/PASTA/OWASP/     (SAR scan.py findings +         (crawl + passive
    LLM/cloud/STRIDE-LM)     extracted entry points,         + safe active probes
                             trust boundaries, controls)     against a live app)
        │                          │                              │
        └──────────────┬───────────┴───────────────┬─────────────┘
                       ▼                            ▼
                 Normalized findings  (shared report categories[] shape)
                                    │
                                    ▼
                     ┌─────────────────────────────┐
                     │   CORRELATION / MEDIATOR      │  ← the product's core
                     │   • weakness taxonomy (CWE/    │
                     │     OWASP families)            │
                     │   • locus matching             │
                     │     (file:line ↔ URL ↔ comp.)  │
                     │   • verdict + confidence        │
                     └─────────────┬───────────────┘
                                   ▼
              Unified report · CI gate · SARIF · trend dashboard
```

Everything already emits the same `report.categories[]` shape and persists to one
store, so the mediator can treat design, code, and runtime findings as one
corpus keyed by weakness family and locus.

## 6. Functional requirements

### 6.1 Ingestion & the shared model
- FR1 — All producers (threat model, SAST, DAST, code-model) emit the canonical
  finding shape: `risk`, `owasp`, `cwe`, `stride`, `affected_components`,
  `threats[]`, `mitigations[]`, and a `_source` tag (`SAST`/`DAST`/`CODEMODEL`/design).
- FR2 — A **project** groups the reports for one system so correlation runs over
  the right corpus (today correlation is manual report-selection; a project
  entity is required).
- FR3 — Every finding normalizes to a **weakness family** (CWE-first, then OWASP,
  then keyword) and a **locus** (file:line, URL[+param], or component tokens).

### 6.2 Correlation & verdicts
- FR4 — Cluster findings across sources by family + locus proximity.
- FR5 — Assign a verdict per cluster:
  - **Confirmed-exploitable** — static root cause AND runtime proof agree.
  - **Corroborated** — a modeled threat backed by code or runtime evidence.
  - **Design-gap** — modeled but no scan evidence either way (needs a test).
  - **Blind-spot** — scan evidence with no matching modeled threat (model incomplete).
- FR6 — Compute a **confidence** (rises with distinct agreeing sources) and a
  **priority** (severity + verdict + confidence); escalate confirmed-exploitable
  to at least High.
- FR7 — Deduplicate: one card per weakness cluster, each contributing tool's
  evidence as a sub-item.

### 6.3 Model reconciliation (design ↔ reality)
- FR8 — From code, extract the **actual attack surface** (entry points, trust
  boundaries, data stores, controls) and diff it against the threat model.
- FR9 — Report **coverage** (modeled threats with a validating test) and **drift**
  (unmodeled entry points, unmodeled weakness classes).

### 6.4 SDLC integration
- FR10 — **SARIF 2.1.0** export for any report → GitHub/GitLab code scanning + IDEs.
- FR11 — **CI gate**: a webhook-triggered scan posts a pass/fail status/check and a
  PR comment; the gate threshold is configurable per repo/target.
- FR12 — **Baseline & suppression**: diff-only mode (only new findings fail a PR),
  accept-risk with expiry, dedup across runs.
- FR13 — Ticketing: auto-create/update a tracker issue (Jira) per correlated
  finding, deduped by fingerprint.

### 6.5 Safety & trust
- FR14 — Code is **never executed**; SAST parses statically, DAST is GET-only,
  budget/rate/time-bounded, canary-based, non-destructive.
- FR15 — Scans run only against **registered** repos/targets (the authorization
  boundary); webhooks authenticate by HMAC.
- FR16 — Persistence is **crash-safe** (atomic writes, rotating index backups,
  self-heal on corruption). No single corrupt write can lose reports.
- FR17 — The regex-driven scanners are **ReDoS-audited**; inputs are length-capped.

### 6.6 Measurability
- FR18 — A benchmark harness runs a labeled corpus and reports precision / recall /
  F1 per engine; results surface on the dashboard as the platform's stated confidence.
- FR19 — The correlation report states, per finding, *why* it reached its verdict
  (which sources, which evidence).

## 7. Key user flows

1. **Model → validate.** Architect builds a threat model → registers the repo and
   the running target → runs SAST + code-model + DAST → runs correlation →
   receives a report where each modeled threat is confirmed, corroborated, or
   flagged as an untested design-gap, plus blind-spots to add to the model.
2. **PR gate.** A push triggers SAST (and, on deploy, DAST) → correlation runs on
   the project's latest reports → SARIF + a PR check; the build fails only on new
   findings at or above the gate threshold.
3. **Triage.** AppSec opens the unified queue sorted by priority; confirmed-
   exploitable items are at the top with static + runtime evidence side by side.

## 8. Architecture (high level)

- **Producers** (existing): `analyzer.py` (design), `broker/` + external SAR
  `scan.py` (SAST), `dast/engine.py` (DAST), `codemodel/` (code-derived model).
- **Mediator** (existing): `correlator/` — taxonomy, engine, mapper, service.
- **Platform services**: `report_store.py` (crash-safe persistence), `sarif.py`
  (export), `redos_audit.py` (safety), Flask API blueprints under `api/`.
- **New for this PRD**: a **Project** entity (groups reports + repo + target),
  an **auto-correlate-on-scan** trigger, a **baseline/suppression store**, and a
  **coverage/trend dashboard**.

## 9. Non-functional requirements
- NFR1 — A correlation run over a project's reports completes in < 5 s for typical
  corpora (hundreds of findings).
- NFR2 — Scans are bounded (SAST subprocess timeout; DAST request/page/time
  budgets) and **concurrency-capped** (bounded worker pool — a gap today).
- NFR3 — No secret (tokens, cookies, keys) is ever written to a report, log, or
  SSE stream (asserted by test).
- NFR4 — All new code is stdlib-first, unit-tested, and runs offline.

## 10. Success metrics
- **Signal quality:** ≥ 40% reduction in triaged finding count after dedup/merge
  vs. the sum of the raw tool outputs.
- **Confirmation rate:** % of static findings that get a runtime verdict (the
  platform's core value — trends up as coverage grows).
- **Model completeness:** blind-spots per project trends down over time.
- **Adoption:** % of PRs where the gate ran; developer suppression/override rate.
- **Trust:** published precision/recall per engine, stable or improving.

## 11. Phasing

| Phase | Scope | Exit criteria |
| --- | --- | --- |
| **P0 (done)** | Producers + correlation engine + SARIF + crash-safe store + DAST refinements | All shipped, tested. |
| **P1** | Project entity; auto-correlate on scan; unified queue view | One click from "run scans" to a correlated project report. |
| **P2** | Baseline/suppression; diff-only PR gate; concurrency cap | Teams can adopt on a noisy repo without drowning. |
| **P3** | Coverage/trend dashboard; model-reconciliation drift report | Leadership can see modeled-vs-tested-vs-clean over time. |
| **P4** | Detection depth: tree-sitter multi-language SAST core; calibrated confidence | Coverage beyond Python; externally-benchmarked accuracy. |

## 12. Risks & mitigations
- **False positives erode trust** → conservative detection thresholds, confidence
  scoring, suppression lifecycle, published accuracy.
- **Locus matching mislinks findings** → CWE-first family resolution, Jaccard
  locus thresholds, singleton fallback (never force-merge).
- **Scope creep toward commercial SAST** → keep the mediator as the differentiator;
  treat multi-language depth as an explicit, separate track (P4).
- **Data loss / corruption** → already mitigated (atomic store, backups); extend
  the same discipline to any new stateful store.

## 13. Open questions
- Q1 — Project entity: new store, or derive projects from linked repo+target?
- Q2 — Auto-DAST is riskier than auto-SAST (drives a live app) — gate it behind an
  explicit "authorized target + environment" flag?
- Q3 — Where does the code-derived model become the *canonical* attack surface vs.
  a suggestion the architect confirms?
- Q4 — SARIF is per-report today; do we emit a single merged correlated SARIF for
  the PR check, or one run per engine?

---

### Appendix A — What already exists (P0 inventory)
- Threat modeling: `analyzer.py`, STRIDE/PASTA/OWASP (web/api/llm/cloud/mobile),
  STRIDE-LM (in the `tm 2` snapshot, port pending), MITRE/compliance/SBOM/PQC.
- SAST: `broker/` (job queue, git workspace, GitHub CI gate) → external SAR
  `scan.py` (regex + interprocedural AST taint).
- Code-derived TM: `codemodel/` (entry points, trust boundaries, control-presence,
  call-graph sink reachability).
- DAST: `dast/engine.py` (crawl + passive + safe active probes; now with SRI and
  boolean-blind SQLi).
- Mediator: `correlator/` (taxonomy, clustering, verdicts).
- Platform: `report_store.py`, `sarif.py`, `redos_audit.py`, Flask `api/` blueprints.
