"""stride_pasta.py — STRIDE and PASTA threat modeling methodology knowledge base."""
from __future__ import annotations

STRIDE: dict = {
    "S": {
        "id": "S", "name": "Spoofing", "security_property": "Authentication",
        "description": "Attacker impersonates another user, system, or component to gain unauthorized access",
        "examples": [
            "Forged JWT tokens claiming admin identity via algorithm confusion (RS256→HS256)",
            "DNS spoofing to redirect traffic to attacker-controlled server",
            "Session hijacking via stolen or predicted session tokens",
            "OAuth token theft enabling impersonation of legitimate user",
        ],
        "mitigations": [
            {"action": "Strong MFA with hardware token or TOTP for all privileged accounts", "priority": "Immediate"},
            {"action": "Cryptographic signing of all identity tokens — verify signature on every request", "priority": "Immediate"},
            {"action": "Strict JWT validation: verify algorithm, issuer, audience, and expiry", "priority": "Immediate"},
        ],
    },
    "T": {
        "id": "T", "name": "Tampering", "security_property": "Integrity",
        "description": "Unauthorized modification of data in transit, at rest, or in processing",
        "examples": [
            "MITM modification of API requests before they reach the server",
            "SQL injection modifying critical database records",
            "Binary patching or DLL injection modifying application logic",
            "Tampered environment variables in cloud function configuration",
        ],
        "mitigations": [
            {"action": "TLS 1.3 for all data in transit — reject downgrades", "priority": "Immediate"},
            {"action": "HMAC or digital signatures on all sensitive data at rest", "priority": "Short-term"},
            {"action": "Parameterized queries everywhere — no string concatenation for SQL", "priority": "Immediate"},
            {"action": "Immutable infrastructure: deploy-only, no runtime modification", "priority": "Long-term"},
        ],
    },
    "R": {
        "id": "R", "name": "Repudiation", "security_property": "Non-repudiation",
        "description": "User or attacker denies having performed an action — missing or inadequate audit trail",
        "examples": [
            "Attacker deletes application logs after unauthorized access",
            "Missing audit trail for financial or privileged administrative actions",
            "No timestamping or signing of critical user actions",
            "Log injection to alter or corrupt audit records",
        ],
        "mitigations": [
            {"action": "Immutable, append-only audit log with cryptographic chaining (Merkle tree)", "priority": "Short-term"},
            {"action": "Centralized SIEM with tamper-evident log shipping — no log access from app tier", "priority": "Short-term"},
            {"action": "Signed audit events with user identity, timestamp, and action parameters", "priority": "Short-term"},
        ],
    },
    "I": {
        "id": "I", "name": "Information Disclosure", "security_property": "Confidentiality",
        "description": "Exposure of sensitive information to unauthorized parties through leakage or attack",
        "examples": [
            "Verbose error messages exposing stack traces, internal IPs, or file paths",
            "Unencrypted PII in database backups or log files",
            "Directory traversal exposing source code or configuration files",
            "Excessive data return in API responses (user records include password hashes)",
        ],
        "mitigations": [
            {"action": "AES-256 encryption at rest for all sensitive data — separate key management", "priority": "Immediate"},
            {"action": "Generic error messages in production — detailed errors only in dev/staging", "priority": "Immediate"},
            {"action": "Data classification: tag PII, mark fields as sensitive, enforce access controls by tag", "priority": "Short-term"},
            {"action": "API response filtering: return only explicitly required fields (allowlist)", "priority": "Short-term"},
        ],
    },
    "D": {
        "id": "D", "name": "Denial of Service", "security_property": "Availability",
        "description": "Making the system unavailable to legitimate users through resource exhaustion or disruption",
        "examples": [
            "Resource exhaustion via unauthenticated or low-cost endpoints",
            "ReDoS: catastrophic regex backtracking on attacker-controlled input",
            "Amplification attacks via misconfigured DNS, NTP, or UDP services",
            "Slowloris: incomplete HTTP requests exhausting connection pool",
        ],
        "mitigations": [
            {"action": "Rate limiting by IP, user, and API key on all public endpoints", "priority": "Immediate"},
            {"action": "CDN with DDoS protection (Cloudflare, AWS Shield) in front of all services", "priority": "Short-term"},
            {"action": "Resource quotas: max connections per IP, max request body size, max query depth", "priority": "Immediate"},
            {"action": "Audit all regex patterns for catastrophic backtracking — use re2 where possible", "priority": "Short-term"},
        ],
    },
    "E": {
        "id": "E", "name": "Elevation of Privilege", "security_property": "Authorization",
        "description": "Attacker gains capabilities beyond those granted, escalating from lower to higher privilege",
        "examples": [
            "IDOR: changing `userId` parameter to access another user's resources",
            "JWT algorithm confusion granting admin role without valid credentials",
            "Path traversal breaking out of application sandbox to execute system commands",
            "Mass assignment: extra fields in request body update privileged attributes",
        ],
        "mitigations": [
            {"action": "Centralized authorization: every request validated against permissions before action", "priority": "Immediate"},
            {"action": "Object-level authorization checks on every resource access — not just endpoint-level", "priority": "Immediate"},
            {"action": "Input validation on all privilege-bearing parameters — reject unexpected values", "priority": "Immediate"},
            {"action": "Principle of least privilege: start with no permissions, explicitly grant needed ones", "priority": "Short-term"},
        ],
    },
}

PASTA_STAGES: list = [
    {
        "stage": 1, "name": "Definition of Objectives",
        "description": "Identify business objectives, security requirements, and compliance constraints for this system",
        "key_questions": [
            "What are the business-critical assets and operations?",
            "What compliance frameworks apply (SOC2, PCI-DSS, HIPAA, GDPR)?",
            "What is the organization's risk appetite?",
            "What are the legal and regulatory security obligations?",
        ],
        "outputs": ["Business impact analysis", "Security policy requirements", "Risk appetite definition", "Compliance matrix"],
    },
    {
        "stage": 2, "name": "Definition of Technical Scope",
        "description": "Enumerate all technical components, network boundaries, data flows, and external dependencies",
        "key_questions": [
            "What is the full technology stack (languages, frameworks, cloud providers)?",
            "What are all external integrations and third-party dependencies?",
            "What are the network trust zones and segmentation boundaries?",
            "What data types flow through the system and where do they rest?",
        ],
        "outputs": ["Technical architecture map", "Network topology diagram", "Asset inventory", "Data flow inventory"],
    },
    {
        "stage": 3, "name": "Application Decomposition",
        "description": "Decompose application into components, trust boundaries, and data flows — basis for all subsequent analysis",
        "key_questions": [
            "What are the trust boundaries between components?",
            "Where does user-controlled input enter the system?",
            "What are all the authentication and authorization enforcement points?",
            "Which components process the most sensitive data?",
        ],
        "outputs": ["Level 1 Data Flow Diagram (DFD)", "Use case inventory", "Trust boundary map", "Entry point catalog"],
    },
    {
        "stage": 4, "name": "Threat Analysis",
        "description": "Enumerate threats using STRIDE, threat intelligence, and attack pattern libraries (ATT&CK, CAPEC)",
        "key_questions": [
            "Who are the realistic threat actors (insider, nation-state, script kiddie, competitor)?",
            "What attacker capabilities are realistic given the system's exposure?",
            "What historical attacks have targeted similar architectures?",
            "What ATT&CK techniques apply to this attack surface?",
        ],
        "outputs": ["Threat enumeration list", "Threat actor profiles", "ATT&CK technique mapping", "Attack pattern library hits"],
    },
    {
        "stage": 5, "name": "Vulnerability and Weakness Analysis",
        "description": "Map vulnerabilities in specific components to the threats identified in Stage 4",
        "key_questions": [
            "Which OWASP Top 10 categories are present in the identified components?",
            "Are there known CVEs in identified dependencies?",
            "What CWE weaknesses are introduced by the design choices?",
            "Where do existing controls have gaps that leave vulnerabilities exposed?",
        ],
        "outputs": ["Vulnerability list per component", "CVE mapping for dependencies", "CWE classification", "Control gap analysis"],
    },
    {
        "stage": 6, "name": "Attack Modeling",
        "description": "Build attack trees and attack chains showing how threat actors exploit identified vulnerabilities",
        "key_questions": [
            "What is the minimal attack chain to achieve the highest-impact goal?",
            "Which vulnerabilities can be chained to escalate from low to critical impact?",
            "What are the pivot points in the architecture where one compromise enables broader access?",
            "How many steps does each attack path require — what is the attacker cost?",
        ],
        "outputs": ["Attack trees per threat goal", "Attack chains (multi-step paths)", "Exploit scenarios with impact", "Attack surface heat map"],
    },
    {
        "stage": 7, "name": "Risk and Impact Analysis",
        "description": "Calculate risk scores, prioritize risks, and define residual risk after mitigations",
        "key_questions": [
            "What is the business impact of each successful attack?",
            "What is the likelihood given attacker capabilities and existing controls?",
            "Which mitigations provide the highest risk reduction per unit of effort?",
            "What residual risks remain after all recommended mitigations are applied?",
        ],
        "outputs": ["Risk register with CVSS-aligned scores", "Prioritized mitigation roadmap", "Residual risk assessment", "Executive risk summary"],
    },
]
