"""guard — pre-merge / coding-agent guardrail: gate new code, not old debt.

See tm_guard.py at the repo root for the CLI entrypoint.
"""
