"""Report API routes.

Beyond the raw report CRUD, this exposes report *structure* as first-class API
resources — a normalized category/finding tree, a flat finding list, and the set
of affected paths — all served as HTML-safe JSON via ``report_view`` so a
consumer never has to re-derive structure or worry about escaping untrusted
finding content (see ``report_view`` for why the API, not the client, owns
output safety).
"""
from __future__ import annotations

import json
import secrets

from flask import Blueprint, jsonify, request

import app as tm_app
import report_db
import report_view
import sarif_import


bp = Blueprint("reports_api", __name__, url_prefix="/api/v1/reports")

_MAX_SARIF_BYTES = 16 * 1024 * 1024   # matches app MAX_CONTENT_LENGTH


def _load(report_id: str):
    """Load a saved report via the app's validated store.

    Returns (report_dict, None) on success or (None, flask_response) on error, so
    every structure route shares one validation + not-found path.
    """
    if not tm_app._validate_report_id(report_id):
        return None, (jsonify({"success": False, "error": "Invalid report id"}), 400)
    report = tm_app.report_db.get_report(report_id)
    if report is None:
        return None, (jsonify({"success": False, "error": "Report not found"}), 404)
    # SAST reports are served only under /api/v1/sast — see api/sast.py.
    if tm_app._is_sast_methodology(report.get("methodology")):
        return None, (jsonify({"success": False, "error": "Report not found"}), 404)
    return report, None


@bp.get("")
def list_reports():
    """List saved reports."""
    return tm_app._list_reports_impl()


@bp.get("/<report_id>")
def get_report(report_id: str):
    """Get a saved report (raw)."""
    return tm_app._get_report_impl(report_id)


@bp.get("/<report_id>/structure")
def report_structure(report_id: str):
    """Normalized, HTML-safe category/finding tree for a report."""
    report, err = _load(report_id)
    if err:
        return err
    return jsonify({"success": True,
                    "structure": report_view.normalize_structure(report)})


@bp.get("/<report_id>/findings")
def report_findings(report_id: str):
    """Flat, HTML-safe finding list (one row per locus, file/line parsed)."""
    report, err = _load(report_id)
    if err:
        return err
    findings = report_view.flat_findings(report)
    return jsonify({"success": True, "count": len(findings), "findings": findings})


@bp.get("/<report_id>/paths")
def report_paths(report_id: str):
    """Unique affected paths/components/loci across the report (HTML-safe)."""
    report, err = _load(report_id)
    if err:
        return err
    paths = report_view.extract_paths(report)
    return jsonify({"success": True, "count": len(paths), "paths": paths})


@bp.get("/<report_id>/safe")
def report_safe(report_id: str):
    """The full report with every string HTML-escaped — safe for innerHTML."""
    report, err = _load(report_id)
    if err:
        return err
    return jsonify({"success": True, "report": report_view.sanitize_report(report)})


@bp.delete("/<report_id>")
def delete_report(report_id: str):
    """Delete a saved report."""
    return tm_app._delete_report_impl(report_id)


@bp.get("/<report_id>/export")
def export_report(report_id: str):
    """Export a report as HTML."""
    return tm_app._export_report_impl(report_id)


@bp.get("/<report_id>/export/sarif")
def export_report_sarif(report_id: str):
    """Export a report as SARIF 2.1.0."""
    return tm_app._export_report_sarif_impl(report_id)


@bp.get("/<report_id>/canary-tests")
def canary_tests(report_id: str):
    """List verdict-gated, replayable canary/regression cases (JSON, no script text)."""
    return tm_app._canary_tests_impl(report_id)


@bp.get("/<report_id>/canary-tests.sh")
def canary_tests_sh(report_id: str):
    """Download the runnable bash regression script."""
    return tm_app._canary_tests_sh_impl(report_id)


@bp.get("/trends")
def report_trends():
    """Severity time series across saved reports (from the SQLite mirror).

    Optional ``methodology`` and ``target`` filters; ``limit`` caps the number
    of reports returned (newest first). Each row carries per-severity counts so
    a client can chart a risk trajectory over time.
    """
    methodology = request.args.get("methodology") or None
    target = request.args.get("target") or None
    try:
        limit = int(request.args.get("limit", 100))
    except (TypeError, ValueError):
        limit = 100
    try:
        rows = report_db.trends(methodology=methodology, target=target, limit=limit)
    except Exception as exc:  # pragma: no cover - defensive
        return jsonify({"success": False, "error": f"trend query failed: {exc}"}), 500
    return jsonify({"success": True, "count": len(rows), "trends": rows})


@bp.get("/findings/search")
def findings_search():
    """Cross-scan finding search over the SQLite mirror.

    Filters: ``family`` (canonical weakness slug, e.g. ``sql-injection``),
    ``severity``, ``cwe`` (substring), ``methodology``, ``verdict`` (one of the
    correlator's confirmed_exploitable/corroborated/design_gap/blind_spot, or
    the literal empty string to find findings that were never correlated).
    Results are HTML-escaped so a consumer can render them directly — finding
    content is untrusted.
    """
    try:
        limit = int(request.args.get("limit", 200))
    except (TypeError, ValueError):
        limit = 200
    try:
        rows = report_db.search_findings(
            family=request.args.get("family") or None,
            severity=request.args.get("severity") or None,
            cwe=request.args.get("cwe") or None,
            methodology=request.args.get("methodology") or None,
            verdict=request.args.get("verdict") if "verdict" in request.args else None,
            limit=limit)
    except Exception as exc:  # pragma: no cover - defensive
        return jsonify({"success": False, "error": f"finding query failed: {exc}"}), 500
    safe = [{k: (report_view.html_escape(v) if isinstance(v, str) else v)
             for k, v in row.items()} for row in rows]
    return jsonify({"success": True, "count": len(safe), "findings": safe})


@bp.get("/families")
def families():
    """Finding counts per weakness family across every saved report."""
    try:
        rows = report_db.family_summary(include_sast=request.args.get("include_sast") == "1")
    except Exception as exc:  # pragma: no cover - defensive
        return jsonify({"success": False, "error": f"family query failed: {exc}"}), 500
    return jsonify({"success": True, "count": len(rows), "families": rows})


@bp.post("/import/sarif")
def import_sarif():
    """Import an external scanner's SARIF 2.1.0 as a saved SAST report.

    Accepts either a raw SARIF JSON body (Content-Type application/json / +sarif)
    or a multipart upload under the ``file`` field, so both `curl -d @out.sarif`
    and a browser file picker work. The imported report is saved through the
    app's normal store, so it appears in the report list and — because it is
    tagged as CODE evidence — immediately becomes a correlation source.
    """
    source_name = ""
    doc = None

    upload = request.files.get("file")
    if upload is not None:
        raw = upload.read(_MAX_SARIF_BYTES + 1)
        if len(raw) > _MAX_SARIF_BYTES:
            return jsonify({"success": False, "error": "SARIF file too large"}), 413
        source_name = str(request.form.get("source", "")).strip()
        try:
            doc = json.loads(raw.decode("utf-8-sig"))
        except (ValueError, UnicodeDecodeError):
            return jsonify({"success": False, "error": "file is not valid JSON"}), 400
    else:
        source_name = str(request.args.get("source", "")).strip()
        doc = request.get_json(silent=True)
        if doc is None:
            return jsonify({"success": False,
                            "error": "provide a SARIF file (multipart 'file') "
                                     "or a JSON body"}), 400

    try:
        report = sarif_import.from_sarif(doc, source_name=source_name)
    except sarif_import.SarifError as exc:
        return jsonify({"success": False, "error": f"invalid SARIF: {exc}"}), 400

    report_id = tm_app._save_report(report, report["title"])
    meta = report.get("scan_metadata", {})
    return jsonify({
        "success": True,
        "report_id": report_id,
        "title": report["title"],
        "tool": meta.get("tool", ""),
        "overall_risk": report.get("overall_risk"),
        "findings_total": meta.get("findings_total", 0),
        "rules_triggered": meta.get("rules_triggered", 0),
        "severity_counts": meta.get("severity_counts", {}),
    }), 201


@bp.get("/<report_id>/shared")
@tm_app.limiter.limit("30 per minute")
def report_shared(report_id: str):
    """Token-gated public view of one report — no TM_API_KEY, no session.

    ``?token=`` must match the ``share_token`` generated for this report at
    save time (see ``_save_report``). Meant for handing a single report to
    someone outside the app (a client, a stakeholder) without giving them the
    master API key or a login. Exempted from the global auth gate in
    ``app._auth_and_csrf`` — this route is its own auth.
    """
    if not tm_app._validate_report_id(report_id):
        return jsonify({"success": False, "error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None or tm_app._is_sast_methodology(report.get("methodology")):
        return jsonify({"success": False, "error": "Report not found"}), 404
    expected = report.get("share_token", "")
    provided = request.args.get("token", "")
    if not expected or not secrets.compare_digest(provided, expected):
        return jsonify({"success": False, "error": "Invalid or missing token"}), 403
    safe = report_view.sanitize_report(report)
    safe.pop("share_token", None)
    return jsonify({"success": True, "report": safe})


@bp.get("/<report_id>/enrich/attack")
def enrich_attack(report_id: str):
    """Enrich a report with MITRE ATT&CK mappings."""
    return tm_app._enrich_attack_impl(report_id)


@bp.get("/<report_id>/enrich/compliance")
def enrich_compliance(report_id: str):
    """Enrich a report with compliance mappings."""
    return tm_app._enrich_compliance_impl(report_id)
