"""Verdict transition tracking + aging/SLA — alerts when a finding gets *more*
actionable, and flags findings that have sat at their current verdict longer
than that verdict's remediation window allows.

The correlator re-judges the same underlying weakness every time reports are
re-correlated: a design-only risk can later gain code evidence (blind_spot ->
corroborated), or a modeled-but-unproven gap can get a runtime exploit chained
onto it (design_gap -> confirmed_exploitable). That transition is the single
highest-signal event this tool can raise — a risk operators may have
deprioritized just became provably worse — yet nothing surfaced it before now:
each report was judged in isolation, with no memory of what the same finding's
verdict used to be.

Identity across reports reuses :func:`suppressions.finding_fingerprint` (rule id
+ weakness family + CWE + line-insensitive locus) — the same report-independent
identity the suppression workflow already relies on to survive re-scans, so
"the same finding" means one thing across this codebase instead of two.

Two SQLite tables, stdlib only, same connection-per-call + WAL pattern as
report_db.py/suppressions/db.py:

  * ``verdict_history`` — one row per fingerprint: the last verdict observed
    for it, so the next correlation run has something to compare against.
  * ``verdict_alerts``  — append-only log of every *escalation* (verdict rank
    decreased, i.e. became more actionable) ever detected, for a durable feed
    independent of whichever report happens to still exist.

De-escalations (evidence disappearing on a later scan) update the history
silently but never raise an alert -- alerts exist to flag things getting
worse, not better. A finding seen for the first time never alerts either;
there is nothing yet to compare it against.

Aging/SLA reuses the same ``verdict_history`` row: ``verdict_since`` is the
timestamp the *current* verdict was assigned (it resets on any verdict
change, escalation or de-escalation alike -- the clock measures how long a
finding has sat at its present actionability, not how long it has existed).
The per-verdict windows mirror control_register.py's severity->priority SLA
tiers exactly (P1 72hrs / P2 7d / P3 30d / P4 90d), applied by verdict rank
instead of severity, so a proven-exploitable finding gets the same urgency
budget here as a Critical control does there.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

from suppressions import finding_fingerprint
from suppressions.model import VERDICT_RANK, VERDICTS

DB_PATH = Path.home() / ".tm_verdict_history.db"

_init_lock = threading.Lock()

# Same day-thresholds as control_register.py's P1-P4 severity->priority SLA
# tiers (72hrs/7d/30d/90d), applied by verdict rank instead of severity.
# "actively_exploited" gets the tightest window of all: a confirmed
# production incident, not a lab proof, so same-day response is expected.
_SLA_DAYS = {
    "actively_exploited": 1,
    "confirmed_exploitable": 3,
    "corroborated": 7,
    "design_gap": 30,
    "blind_spot": 90,
}
_DAY = 86400.0

_SCHEMA = """
CREATE TABLE IF NOT EXISTS verdict_history (
    fingerprint   TEXT PRIMARY KEY,
    family        TEXT,
    rule          TEXT,
    title         TEXT,
    verdict       TEXT NOT NULL,
    report_id     TEXT,
    report_title  TEXT,
    first_seen    REAL,
    updated_at    REAL,
    verdict_since REAL
);
CREATE TABLE IF NOT EXISTS verdict_alerts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    fingerprint   TEXT NOT NULL,
    family        TEXT,
    title         TEXT,
    from_verdict  TEXT NOT NULL,
    to_verdict    TEXT NOT NULL,
    report_id     TEXT,
    report_title  TEXT,
    at            REAL,
    acknowledged  INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_valerts_at    ON verdict_alerts(at);
CREATE INDEX IF NOT EXISTS ix_valerts_ack   ON verdict_alerts(acknowledged);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)
            # verdict_since predates SLA tracking on any install that already
            # ran CREATE TABLE IF NOT EXISTS with the old column set -- add it
            # once, idempotently, same pattern as users_db.py's role column.
            cols = {row["name"] for row in conn.execute("PRAGMA table_info(verdict_history)")}
            if "verdict_since" not in cols:
                conn.execute("ALTER TABLE verdict_history ADD COLUMN verdict_since REAL")
                # Backfill: best guess is "since it was first observed", which
                # is exact for every row that has never actually changed
                # verdict, and only overstates age (never understates it) for
                # rows that transitioned before this column existed --
                # understating a finding's age is the direction that would
                # hide risk, so erring long here is the safe side.
                conn.execute(
                    "UPDATE verdict_history SET verdict_since = first_seen "
                    "WHERE verdict_since IS NULL")


def record_transitions(report: dict, now: float | None = None) -> list[dict]:
    """Diff every verdict-bearing category in ``report`` against its last known
    verdict; return the escalations detected (also durably logged). History is
    updated for every verdict-bearing category regardless of direction.

    Categories without a verdict at all (plain SAST/manual findings, never
    touched by the correlator) are skipped entirely -- there is nothing to
    track for them.
    """
    at = now if now is not None else time.time()
    report_id = str(report.get("id") or "")
    report_title = str(report.get("title") or report_id)
    alerts: list[dict] = []

    init()
    with closing(_connect()) as conn, conn:
        for cat in report.get("categories") or []:
            if not isinstance(cat, dict):
                continue
            verdict = cat.get("verdict")
            if verdict not in VERDICT_RANK:
                continue
            fp = finding_fingerprint(cat)
            title = str(cat.get("name") or cat.get("title") or cat.get("id") or "Finding")
            family = str(cat.get("family") or "")
            rule = str(cat.get("id") or cat.get("category") or "")

            prev = conn.execute(
                "SELECT verdict, first_seen, verdict_since FROM verdict_history "
                "WHERE fingerprint = ?", (fp,)).fetchone()
            verdict_changed = prev is not None and prev["verdict"] != verdict

            if verdict_changed and VERDICT_RANK[verdict] < VERDICT_RANK[prev["verdict"]]:
                conn.execute(
                    "INSERT INTO verdict_alerts"
                    "(fingerprint,family,title,from_verdict,to_verdict,report_id,"
                    "report_title,at,acknowledged) VALUES (?,?,?,?,?,?,?,?,0)",
                    (fp, family, title, prev["verdict"], verdict, report_id,
                     report_title, at))
                alerts.append({
                    "fingerprint": fp, "family": family, "title": title,
                    "from_verdict": prev["verdict"], "to_verdict": verdict,
                    "report_id": report_id, "report_title": report_title, "at": at,
                })

            first_seen = prev["first_seen"] if prev is not None else at
            # The SLA clock measures time at the CURRENT verdict, so it resets
            # on any change (escalation or de-escalation) and only carries
            # forward when the verdict is unchanged from last time.
            if prev is None or verdict_changed:
                verdict_since = at
            else:
                verdict_since = prev["verdict_since"] or first_seen
            conn.execute(
                "INSERT OR REPLACE INTO verdict_history"
                "(fingerprint,family,rule,title,verdict,report_id,report_title,"
                "first_seen,updated_at,verdict_since) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (fp, family, rule, title, verdict, report_id, report_title,
                 first_seen, at, verdict_since))

    return alerts


_CHUNK = 400


def since_map(fingerprints: list[str]) -> dict[str, float]:
    """Bulk fingerprint -> verdict_since lookup, chunked under SQLite's bound
    parameter limit -- same convention as ownership.py's _overrides_map, for
    callers (confidence_decay.py) that need "how long has this finding sat at
    its current verdict" for many findings at once rather than one query each.
    A fingerprint never correlated yet (not in verdict_history) is simply
    absent from the result rather than defaulting to 0 -- there is no verdict
    age to report until the correlator has actually seen it once.
    """
    uniq = [fp for fp in {f for f in fingerprints if f}]
    if not uniq:
        return {}
    init()
    out: dict[str, float] = {}
    with closing(_connect()) as conn:
        for i in range(0, len(uniq), _CHUNK):
            chunk = uniq[i:i + _CHUNK]
            placeholders = ",".join("?" * len(chunk))
            rows = conn.execute(
                f"SELECT fingerprint, verdict_since, first_seen FROM verdict_history "
                f"WHERE fingerprint IN ({placeholders})", chunk).fetchall()
            for r in rows:
                out[r["fingerprint"]] = r["verdict_since"] or r["first_seen"]
    return out


def all_alerts(since: float | None = None) -> list[dict]:
    """Every escalation alert ever recorded, optionally restricted to
    ``at >= since``, oldest first -- for aggregate analysis (correlator's
    self_quality.py) rather than list_alerts' UI-facing "most recent N,
    newest first" feed."""
    init()
    q = "SELECT * FROM verdict_alerts"
    params: list = []
    if since is not None:
        q += " WHERE at >= ?"
        params.append(since)
    q += " ORDER BY at ASC, id ASC"
    with closing(_connect()) as conn:
        rows = conn.execute(q, params).fetchall()
    return [dict(r) for r in rows]


def current_verdict_map(fingerprints: list[str]) -> dict[str, str]:
    """Bulk fingerprint -> its CURRENT verdict (verdict_history.verdict),
    chunked the same way since_map() is. De-escalations update this table
    silently (no alert raised -- see the module docstring), so this is how a
    caller finds out whether a past escalation still holds."""
    uniq = [fp for fp in {f for f in fingerprints if f}]
    if not uniq:
        return {}
    init()
    out: dict[str, str] = {}
    with closing(_connect()) as conn:
        for i in range(0, len(uniq), _CHUNK):
            chunk = uniq[i:i + _CHUNK]
            placeholders = ",".join("?" * len(chunk))
            rows = conn.execute(
                f"SELECT fingerprint, verdict FROM verdict_history "
                f"WHERE fingerprint IN ({placeholders})", chunk).fetchall()
            for r in rows:
                out[r["fingerprint"]] = r["verdict"]
    return out


def sla_days_for(verdict: str) -> int:
    """Public accessor for a verdict's SLA window -- callers outside this
    module (design_gap_agenda.py) shouldn't reach into _SLA_DAYS directly."""
    return _SLA_DAYS.get(verdict, _SLA_DAYS["design_gap"])


def list_alerts(limit: int = 50, unacknowledged_only: bool = False) -> list[dict]:
    init()
    q = "SELECT * FROM verdict_alerts"
    if unacknowledged_only:
        q += " WHERE acknowledged = 0"
    q += " ORDER BY at DESC, id DESC LIMIT ?"
    with closing(_connect()) as conn:
        rows = conn.execute(q, (max(1, min(limit, 1000)),)).fetchall()
    return [dict(r) for r in rows]


def acknowledge_alert(alert_id: int) -> bool:
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute(
            "UPDATE verdict_alerts SET acknowledged = 1 WHERE id = ?", (alert_id,))
        return cur.rowcount > 0


def unacknowledged_count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM verdict_alerts WHERE acknowledged = 0").fetchone()[0]


def _sla_row(row: sqlite3.Row, now: float) -> dict:
    verdict = row["verdict"]
    since = row["verdict_since"] or row["first_seen"] or now
    age_days = (now - since) / _DAY
    sla_days = _SLA_DAYS.get(verdict, _SLA_DAYS["design_gap"])
    remaining_days = sla_days - age_days
    if remaining_days < 0:
        status = "breached"
    elif remaining_days <= sla_days * 0.2:
        status = "at_risk"
    else:
        status = "ok"
    return {
        "fingerprint": row["fingerprint"], "family": row["family"], "title": row["title"],
        "verdict": verdict, "report_id": row["report_id"], "report_title": row["report_title"],
        "verdict_since": since, "age_days": round(age_days, 1), "sla_days": sla_days,
        "remaining_days": round(remaining_days, 1), "status": status,
    }


def sla_status(now: float | None = None, statuses: tuple[str, ...] = ()) -> list[dict]:
    """Age every tracked finding against its verdict's SLA window, worst first.

    ``statuses``, if given, restricts the result to those status values (e.g.
    ``("breached",)``); empty (the default) returns everything currently
    tracked. Findings whose current verdict is neither a real correlator
    verdict aren't in ``verdict_history`` at all, so there is nothing to
    filter for that case -- only correlator-derived findings ever get a row.
    """
    at = now if now is not None else time.time()
    init()
    with closing(_connect()) as conn:
        rows = conn.execute("SELECT * FROM verdict_history").fetchall()
    out = [_sla_row(r, at) for r in rows]
    if statuses:
        out = [r for r in out if r["status"] in statuses]
    out.sort(key=lambda r: r["remaining_days"])
    return out


def sla_summary(now: float | None = None) -> dict:
    """Breached/at-risk/ok counts overall and per verdict, plus the worst
    offenders capped to a short list for a dashboard callout."""
    rows = sla_status(now)
    counts = {"breached": 0, "at_risk": 0, "ok": 0}
    by_verdict = {v: {"breached": 0, "at_risk": 0, "ok": 0} for v in VERDICTS}
    for r in rows:
        counts[r["status"]] += 1
        if r["verdict"] in by_verdict:
            by_verdict[r["verdict"]][r["status"]] += 1
    breached = [r for r in rows if r["status"] == "breached"]
    return {
        "tracked": len(rows), "counts": counts, "by_verdict": by_verdict,
        "worst": breached[:8],
    }


def design_debt_summary(now: float | None = None, window_days: float = 30) -> dict:
    """"Design debt" = findings the threat model anticipated but that have no
    code/runtime evidence either way (verdict == design_gap) -- work the model
    predicted but nobody has proven or disproven yet. Burn-down tracks whether
    that backlog is shrinking:

      * ``open``         -- how many are sitting at design_gap right now.
      * ``oldest_days``  -- age of the longest-standing one (verdict_since).
      * ``opened_recent``   -- currently-open findings that entered design_gap
        within the window (new debt still on the books). A finding that both
        entered AND resolved again inside the same window is counted only in
        ``resolved_recent``, not here -- this counts the *current* backlog's
        composition, not a full historical ledger of every transition.
      * ``resolved_recent`` -- escalated OUT of design_gap within the window,
        i.e. gained code/runtime/incident evidence and became corroborated,
        confirmed_exploitable, or actively_exploited (a real close, not a
        guess -- reuses the same verdict_alerts log the escalation-alert
        feature already writes, since design_gap -> any of those is itself
        an escalation by definition of the rank order).
      * ``net_recent``   -- opened minus resolved; negative means the backlog
        is burning down, positive means it is growing.

    A design_gap -> blind_spot move is a verdict change but not an escalation
    (blind_spot ranks *less* actionable), so it is deliberately not counted as
    "resolved" here -- the modeled risk didn't get proven safe, evidence for
    something else just appeared elsewhere.
    """
    at = now if now is not None else time.time()
    window_start = at - window_days * _DAY
    init()
    with closing(_connect()) as conn:
        open_rows = conn.execute(
            "SELECT verdict_since, first_seen FROM verdict_history WHERE verdict = 'design_gap'"
        ).fetchall()
        opened_recent = conn.execute(
            "SELECT COUNT(*) FROM verdict_history WHERE verdict = 'design_gap' "
            "AND COALESCE(verdict_since, first_seen) >= ?", (window_start,)).fetchone()[0]
        resolved_recent = conn.execute(
            "SELECT COUNT(*) FROM verdict_alerts WHERE from_verdict = 'design_gap' "
            "AND to_verdict IN ('confirmed_exploitable', 'corroborated', "
            "'actively_exploited') AND at >= ?",
            (window_start,)).fetchone()[0]

    open_n = len(open_rows)
    oldest_days = 0.0
    if open_rows:
        oldest_since = min(r["verdict_since"] or r["first_seen"] or at for r in open_rows)
        oldest_days = round((at - oldest_since) / _DAY, 1)

    return {
        "open": open_n, "oldest_days": oldest_days,
        "opened_recent": opened_recent, "resolved_recent": resolved_recent,
        "net_recent": opened_recent - resolved_recent, "window_days": window_days,
    }


def delete_all() -> int:
    """Wipe all tracked history and alerts. Used by the admin flush action."""
    init()
    with closing(_connect()) as conn, conn:
        n = conn.execute("SELECT COUNT(*) FROM verdict_alerts").fetchone()[0]
        conn.execute("DELETE FROM verdict_alerts")
        conn.execute("DELETE FROM verdict_history")
    return n
