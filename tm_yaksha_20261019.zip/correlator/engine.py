"""The correlation (mediator) engine.

Pipeline:

  1. **Ingest** — walk each saved report's ``categories[]`` and lift every one to
     a normalized :class:`Observation` (source kind, weakness family, locus,
     severity, CWE/OWASP, remediation).
  2. **Cluster** — within each weakness family, group code/runtime observations
     that share a locus, and let design (threat-model) observations corroborate
     every evidence cluster of that family. A design finding tagged only with an
     OWASP category (an umbrella like A03) corroborates every concrete child
     family under it that has evidence, instead of one arbitrary child.
  3. **Adjudicate** — assign each cluster a :class:`Verdict`, a corroboration
     confidence, an escalated severity and a priority score.

The output is a list of :class:`CorrelatedFinding`, ready for the mapper to
render into a normal TM report. The engine is pure: it takes report dicts in and
returns dataclasses out, with no Flask or filesystem dependency.
"""
from __future__ import annotations

from epss_kev import extract_cves

from . import taxonomy
from .model import (
    SEVERITY_SCORE,
    CorrelatedFinding,
    Observation,
    SourceKind,
    Verdict,
    worst,
)

# Which methodology / _source a category came from -> evidence class.
_CODE_METHODS = {"sast"}
_RUNTIME_METHODS = {"dast"}
_INCIDENT_METHODS = {"incident"}
_SOURCE_TAG = {"SAST": SourceKind.CODE, "DAST": SourceKind.RUNTIME,
               "CODEMODEL": SourceKind.CODE, "SBOM": SourceKind.CODE,
               "INCIDENT": SourceKind.INCIDENT}


def _source_kind(report: dict, category: dict) -> SourceKind:
    """Decide the evidence class of one category.

    A per-category ``_source`` tag (set by the SAST/DAST/incidents mappers)
    wins; otherwise the report-level methodology decides, defaulting design
    for everything that is neither static, dynamic, nor an incident
    (owasp/stride/pasta/api/llm/…).
    """
    tag = str(category.get("_source", "")).upper()
    if tag in _SOURCE_TAG:
        return _SOURCE_TAG[tag]
    method = str(report.get("methodology", "")).lower()
    if method in _CODE_METHODS:
        return SourceKind.CODE
    if method in _RUNTIME_METHODS:
        return SourceKind.RUNTIME
    if method in _INCIDENT_METHODS:
        return SourceKind.INCIDENT
    return SourceKind.DESIGN


def _category_text(category: dict) -> str:
    """A blob of every free-text field, for CWE/keyword scraping."""
    bits = [str(category.get(k, "")) for k in
            ("id", "name", "title", "description", "notes", "mitigation", "remediation")]
    for t in category.get("threats", []) or []:
        if isinstance(t, dict):
            bits.append(str(t.get("control_objective", "")))
            bits.append(str(t.get("attack_vector", "")))
    return " ".join(b for b in bits if b)


def _category_locations(category: dict) -> list[str]:
    locs = [str(c) for c in (category.get("affected_components") or []) if c]
    for t in category.get("threats", []) or []:
        if isinstance(t, dict) and t.get("name"):
            locs.append(str(t["name"]))
    return locs


def _first_remediation(category: dict) -> str:
    if category.get("remediation"):
        return str(category["remediation"])
    if category.get("mitigation"):
        return str(category["mitigation"])
    for m in category.get("mitigations", []) or []:
        if isinstance(m, dict) and m.get("action"):
            return str(m["action"])
        if isinstance(m, str) and m.strip():
            return m
    return ""


def observe_report(report: dict) -> list[Observation]:
    """Turn one saved report into a list of normalized observations."""
    report_id = str(report.get("id", ""))
    report_title = str(report.get("title", "")) or report_id
    methodology = str(report.get("methodology", ""))
    out: list[Observation] = []

    for cat in report.get("categories", []) or []:
        if not isinstance(cat, dict):
            continue
        kind = _source_kind(report, cat)
        text = _category_text(cat)
        cwes = taxonomy.extract_cwes(str(cat.get("cwe", "")), text)
        owasp = taxonomy.extract_owasp(str(cat.get("id", "")),
                                       str(cat.get("owasp", "")), text)
        title = str(cat.get("name") or cat.get("title") or cat.get("id") or "Finding")
        family, family_title = taxonomy.resolve_family(
            title, cwes, owasp, notes=str(cat.get("notes", "")))
        locations = _category_locations(cat)
        tokens = taxonomy.locus_tokens(*locations)
        locus_label = "; ".join(dict.fromkeys(locations))[:400] or "(no specific location)"
        severity = str(cat.get("risk") or cat.get("severity") or "Info").capitalize()
        if severity not in SEVERITY_SCORE:
            severity = "Info"

        out.append(Observation(
            kind=kind,
            family=family,
            family_title=family_title,
            severity=severity,
            title=title,
            locus_tokens=tokens,
            locus_label=locus_label,
            cwes=cwes,
            owasp=owasp,
            stride=taxonomy.family_stride(family) or tuple(cat.get("stride", []) or ()),
            remediation=_first_remediation(cat),
            evidence=str(cat.get("description", ""))[:600],
            report_id=report_id,
            report_title=report_title,
            methodology=methodology,
            category_id=str(cat.get("id", "")),
            reachability=cat.get("reachability") if isinstance(cat.get("reachability"), dict) else None,
            dependency_reachability=cat.get("dependency_reachability")
            if isinstance(cat.get("dependency_reachability"), dict) else None,
            business_impact=cat.get("business_impact") if isinstance(cat.get("business_impact"), dict) else None,
            rule_risk_rating=cat.get("rule_risk_rating")
            if isinstance(cat.get("rule_risk_rating"), dict) else None,
            cves=extract_cves(text),
        ))
    return out


# ── Dependency reachability ────────────────────────────────────────────────────
# A PyPI/npm distribution name often differs from the module it's imported
# under; this only needs the handful of exceptions among sbom_parser.KNOWN_VULNS
# entries that are actually Python-importable — everything else (log4j, npm
# packages, …) is assumed self-named and simply never matches, which is the
# correct fallback (see annotate_dependency_reachability).
_IMPORT_ALIASES = {
    "pyyaml": ("yaml",),
    "pillow": ("pil",),
}


def _import_roots(package: str) -> tuple[str, ...]:
    key = package.strip().lower().replace("_", "-")
    return _IMPORT_ALIASES.get(key, (key.replace("-", "_"),))


def _component_names(category: dict) -> list[str]:
    """Package names out of a vulnerable-component category's
    ``affected_components`` (``name@version`` entries — see
    sbom_parser.sbom_to_categories)."""
    names = []
    for c in category.get("affected_components") or []:
        name = str(c).split("@", 1)[0].strip()
        if name:
            names.append(name)
    return names


def _merge_reachability(facts: list[dict]) -> dict:
    return {
        "unauthenticated": any(f.get("unauthenticated") for f in facts),
        "tainted": any(f.get("tainted") for f in facts),
        "agent_tool": any(f.get("agent_tool") for f in facts),
        "min_hops": min((f.get("min_hops", 99) for f in facts), default=0),
    }


def _dependency_hits(root: str, codemodel_reports: list[dict]) -> list[dict]:
    """Reachability facts for every reachable third-party call whose import
    root exactly matches ``root``, drawn from codemodel's structured
    ``scan_metadata.attack_surface`` (the ``deps`` field — see
    codemodel/mapper.py). An exact-key lookup against every call into the
    package, not a text match against a formatted sink description, so it
    covers any use of the package — not just the handful that also match one
    of codemodel's hardcoded dangerous-sink shapes (sql/eval/deserialize/…).
    """
    hits = []
    for r in codemodel_reports:
        surface = (r.get("scan_metadata") or {}).get("attack_surface") or []
        for ep in surface:
            for d in ep.get("deps") or []:
                if str(d.get("root", "")).lower() == root:
                    hits.append({
                        "unauthenticated": not ep.get("authenticated", False),
                        "tainted": bool(d.get("tainted")),
                        "min_hops": d.get("hops", 0),
                        "agent_tool": ep.get("kind") == "agent-tool",
                    })
    return hits


def annotate_dependency_reachability(reports: list[dict]) -> list[dict]:
    """Borrow a code-model reachability fact onto vulnerable-component (SBOM)
    categories whose package is actually called somewhere reachable in a
    sibling code-model report — so "this CVE is in a reachable code path"
    becomes a real exploitability signal instead of being thrown away.

    ``sbom_parser.sbom_to_categories`` buckets every vulnerable component of a
    given severity into ONE category (``affected_components`` can list several
    unrelated CVE'd packages), so a single merged ``reachability`` fact for the
    whole category can't say which of them is actually the reachable one. This
    also builds ``dependency_reachability``, a per-component breakdown --
    ``{component_name: reachability_fact}`` for every component that turned up
    reachable, letting a caller distinguish "1 of 4 CVEs in this bucket has a
    proven path" from "all 4 do", instead of the whole bucket reading as
    equally exploitable. ``reachability`` itself is left as the same merge
    across every reachable component in the bucket as before (unchanged
    scoring behavior — see ``_exploitability``) so this is purely additive.

    Purely additive and best-effort: a category that already carries
    ``reachability``, or whose package never turns up in any reachable call,
    is left alone — the engine already treats a missing fact as "unknown",
    not "safe". Returns a new list; input reports are not mutated.
    """
    codemodel_reports = [r for r in reports
                          if str(r.get("methodology", "")).lower() == "codemodel"]
    if not codemodel_reports:
        return reports

    out = []
    for r in reports:
        if str(r.get("methodology", "")).lower() != "sbom":
            out.append(r)
            continue
        r = dict(r)
        r["categories"] = [dict(c) for c in (r.get("categories") or [])]
        for cat in r["categories"]:
            if cat.get("reachability"):
                continue
            per_component: dict[str, list[dict]] = {}
            for name in _component_names(cat):
                hits = [hit for root in _import_roots(name)
                        for hit in _dependency_hits(root, codemodel_reports)]
                if hits:
                    per_component[name] = hits
            if per_component:
                cat["dependency_reachability"] = {
                    name: _merge_reachability(hits) for name, hits in per_component.items()
                }
                all_hits = [h for hits in per_component.values() for h in hits]
                cat["reachability"] = _merge_reachability(all_hits)
        out.append(r)
    return out


# ── Clustering ────────────────────────────────────────────────────────────────
def _union_find(items: list, related) -> list[list]:
    """Group ``items`` into connected components under the ``related`` predicate."""
    parent = list(range(len(items)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        parent[find(i)] = find(j)

    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            if related(items[i], items[j]):
                union(i, j)

    groups: dict[int, list] = {}
    for i, item in enumerate(items):
        groups.setdefault(find(i), []).append(item)
    return list(groups.values())


def _cluster_family(observations: list[Observation]) -> list[list[Observation]]:
    """Cluster one family's observations into correlated groups.

    Evidence (code/runtime) observations are grouped by locus proximity; each
    design observation then corroborates *every* evidence cluster in the family
    (a modeled "Injection" threat backs each concrete injection site). A family
    with only design observations yields a single design-gap cluster.
    """
    design = [o for o in observations if o.kind is SourceKind.DESIGN]
    evidence = [o for o in observations if o.kind is not SourceKind.DESIGN]

    if not evidence:
        return [list(design)] if design else []

    # Two evidence findings merge only when *both* carry a locus and those loci
    # overlap. A locus-less evidence finding stays its own cluster rather than
    # linking to everything in the family (which would fabricate one over-broad
    # confirmed-exploitable finding); false-split is safer here than false-merge.
    evidence_clusters = _union_find(
        evidence,
        lambda a, b: bool(a.locus_tokens) and bool(b.locus_tokens)
        and taxonomy.locus_related(a.locus_tokens, b.locus_tokens))
    return [cluster + design for cluster in evidence_clusters]


def _expand_owasp_designs(by_family: dict) -> None:
    """Distribute OWASP-category design findings onto their concrete children.

    A threat-model finding carrying only an OWASP category (e.g. "A03 Injection")
    lands in an ``owasp:<id>`` bucket. If any concrete family under that category
    carries real scan evidence, the design finding corroborates *each* such family
    and is consumed from the bucket; if nothing under the category has evidence it
    stays a standalone design gap. Mutates ``by_family`` in place.
    """
    for key in [k for k in by_family if k.startswith("owasp:")]:
        cat = key.split(":", 1)[1]
        bucket = by_family[key]
        designs = [o for o in bucket if o.kind is SourceKind.DESIGN]
        if not designs:
            continue
        evid_siblings = [
            slug for slug in taxonomy.families_for_owasp(cat)
            if slug in by_family
            and any(o.kind is not SourceKind.DESIGN for o in by_family[slug])]
        if not evid_siblings:
            continue
        for slug in evid_siblings:
            by_family[slug].extend(designs)
        remaining = [o for o in bucket if o.kind is not SourceKind.DESIGN]
        if remaining:
            by_family[key] = remaining
        else:
            del by_family[key]


# ── Adjudication ──────────────────────────────────────────────────────────────
def _verdict(kinds: set) -> Verdict:
    # An observed production incident outranks everything else, alone or in
    # combination: it is not "this could be exploited" (confirmed_exploitable,
    # static+runtime proof) but "this was" -- real-world ground truth, the
    # strongest evidence the engine can ever see. It wins even as the sole
    # kind in a cluster (a finding no scanner modeled or matched, but a SIEM/
    # WAF/IR ticket confirms happened, is still the most urgent thing here).
    if SourceKind.INCIDENT in kinds:
        return Verdict.ACTIVELY_EXPLOITED
    has_code = SourceKind.CODE in kinds
    has_runtime = SourceKind.RUNTIME in kinds
    has_design = SourceKind.DESIGN in kinds
    if has_code and has_runtime:
        return Verdict.CONFIRMED_EXPLOITABLE
    if has_design and (has_code or has_runtime):
        return Verdict.CORROBORATED
    if has_design:
        return Verdict.DESIGN_GAP
    return Verdict.BLIND_SPOT


_RATING_SCORE = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
_RATING_BUMP = {"HIGH": 0.04, "MEDIUM": 0.015, "LOW": 0.0}


def _rule_catalog_bump(members: list[Observation]) -> tuple[float, str]:
    """Extra confidence from established rule-catalog corroboration,
    independent of how many of *our* sources agree.

    Multi-source agreement (the base score below) says how many independent
    detection methods saw this; a matched catalog rule's confidence/
    likelihood/impact metadata says something different -- an established
    ruleset (gitlab-sast-rules, semgrep-community, …) independently judged
    this exact weakness pattern as a reliable, consequential match. That
    matters most for a single-source finding, where it is the only
    corroboration available at all. Worst (highest) rating across the three
    dimensions on each member's rule_risk_rating (see
    app.py:_aggregate_rule_risk_rating), summed and capped so three
    catalog-HIGH dimensions (+0.12) stay below the code+runtime bonus
    (+0.15) -- catalog corroboration should never outweigh actual multi-tool
    proof, only add texture where that proof is thin.
    """
    ratings = [o.rule_risk_rating for o in members if o.rule_risk_rating]
    if not ratings:
        return 0.0, ""
    best = max(ratings, key=lambda r: sum(_RATING_SCORE.get(str(r.get(f, "")).upper(), 0)
                                          for f in ("confidence", "likelihood", "impact")))
    bump = 0.0
    bits = []
    for field in ("confidence", "likelihood", "impact"):
        val = str(best.get(field, "")).upper()
        bump += _RATING_BUMP.get(val, 0.0)
        if val:
            bits.append(f"{field} {val.lower()}")
    if bump <= 0:
        return 0.0, ""
    n = best.get("matched_rules", 0)
    reason = (f"Matched {n} rule-catalog entr{'y' if n == 1 else 'ies'} for this weakness "
              f"rated {', '.join(bits)}.")
    return round(bump, 3), reason


def _confidence(kinds: set, members: list[Observation]) -> tuple[float, str]:
    if SourceKind.INCIDENT in kinds:
        # Confidence here isn't "how many independent tools agree" -- it's
        # "did this actually happen". A production incident is near-certain
        # ground truth regardless of tool-agreement count, so it floors
        # confidence at a near-max value instead of building up from 0.4 the
        # way multi-source corroboration does.
        return 0.97, ("Corroborated by an observed production incident — the "
                      "strongest evidence available, treated as near-certain "
                      "regardless of how many scanners also saw it.")
    distinct = len(kinds)
    conf = 0.4 + 0.25 * (distinct - 1)
    if SourceKind.CODE in kinds and SourceKind.RUNTIME in kinds:
        conf += 0.15   # dynamic proof of a static root cause is the strongest signal
    bump, reason = _rule_catalog_bump(members)
    conf += bump
    return round(min(1.0, conf), 3), reason


_VERDICT_BUMP = {
    Verdict.ACTIVELY_EXPLOITED: 3.0,
    Verdict.CONFIRMED_EXPLOITABLE: 2.0,
    Verdict.CORROBORATED: 1.0,
    Verdict.BLIND_SPOT: 0.25,
    Verdict.DESIGN_GAP: 0.0,
}


def _exploitability(members: list[Observation]) -> tuple[float, str]:
    """Attacker-reachability score, independent of how many tools agree.

    Source-count/verdict answers "how many independent methods saw this"; it says
    nothing about whether the flaw is actually *wired to* the outside world. The
    code model is the one source that walks the call graph from a real entry point
    to a sink, so when any observation in the cluster carries its reachability
    facts (unauthenticated caller, tainted argument, hop distance), that is a
    stronger exploitability signal than mere multi-tool corroboration — a pattern
    match two SAST engines both flagged is not more *reachable* for having two
    opinions, but one the code model proved reaches an unauthenticated entry point
    with tainted input is.

    Absent any code-model coverage the score is 0.0 (unknown, not "safe") and the
    finding falls back to today's severity/verdict/confidence ranking untouched —
    this is purely additive.
    """
    facts = [o.reachability for o in members if o.reachability]
    if not facts:
        return 0.0, ""

    unauthenticated = any(f.get("unauthenticated") for f in facts)
    tainted = any(f.get("tainted") for f in facts)
    agent_tool = any(f.get("agent_tool") for f in facts)
    min_hops = min((f.get("min_hops", 99) for f in facts), default=99)

    score = 0.35  # the code model confirmed this sink/endpoint is reachable at all
    if unauthenticated:
        score += 0.30
    if tainted:
        score += 0.25
    if min_hops <= 0:
        score += 0.10
    elif min_hops <= 2:
        score += 0.05
    score = round(min(1.0, score), 3)

    bits = ["reachable from an unauthenticated entry point" if unauthenticated
            else "reachable from an authenticated entry point"]
    if tainted:
        bits.append("attacker-controlled input traced to the sink")
    if agent_tool:
        bits.append("invokable by an LLM/agent tool")
    bits.append("in the handler body" if min_hops <= 0
                else f"{min_hops} call hop(s) from the entry point")
    reason = "; ".join(bits)
    return score, reason[0].upper() + reason[1:] + "."


def _business_impact(members: list[Observation]) -> tuple[float, str]:
    """Asset/route criticality score, independent of technical exploitability.

    ``_exploitability`` answers "can this be reached and proven"; it says
    nothing about "does it matter if it is" — a finding on ``/healthcheck``
    and one on ``/api/payments/charge`` can be equally reachable yet carry
    very different business risk. Each observation may carry a
    ``business_impact`` tier inferred from the affected route/asset naming
    (see codemodel/business_impact.py); this picks the worst (highest-score)
    tier seen across the cluster, since one code-derived observation naming
    the payments path is enough to mark the whole correlated weakness as
    high business impact even if a SAST match on the same locus carries no
    such fact itself.

    Absent any tagged observation the score is 0.0 ("unknown", not "low") and
    the finding falls back to today's ranking untouched — purely additive,
    same convention as ``_exploitability``.
    """
    tags = [o.business_impact for o in members if o.business_impact]
    if not tags:
        return 0.0, ""
    best = max(tags, key=lambda t: t.get("score", 0.0))
    return float(best.get("score", 0.0)), str(best.get("reason", ""))


def _epss_kev(members: list[Observation], lookup_table: dict | None) -> tuple[float, str]:
    """Real-world exploitation signal from EPSS probability + CISA KEV, for
    any member finding naming a CVE (today, only vulnerable-component/SBOM
    findings ever do — see sbom_parser.KNOWN_VULNS).

    ``_exploitability`` answers "does the code model prove this is reachable
    from here"; ``_business_impact`` answers "does it matter if it is". Both
    are inferred entirely from the scanned code itself. This is the one
    signal that comes from *outside* it: is this exact CVE, independent of
    this codebase, known or predicted to be exploited in the wild right now?
    A CISA KEV listing is ground truth (confirmed active exploitation), so it
    floors the score at 0.9 regardless of what EPSS alone would say; absent a
    KEV hit the score is the CVE's raw EPSS probability (already 0..1). The
    worst (highest) score across every CVE any member names wins, mirroring
    ``_business_impact``'s "one bad component taints the whole cluster" rule.

    ``lookup_table`` is built by the caller (correlator/service.py) from
    epss_kev.combined_lookup — this function does no network or filesystem
    I/O itself, keeping the engine pure. Absent a table, or no member's CVE(s)
    resolving in it, the score is 0.0 ("unknown", not "safe") and the finding
    falls back to today's ranking untouched — purely additive, same
    convention as exploitability/business_impact.
    """
    if not lookup_table:
        return 0.0, ""
    best: tuple[float, str, dict] | None = None
    for o in members:
        for cve in o.cves:
            fact = lookup_table.get(cve)
            if not fact:
                continue
            score = 0.9 if fact.get("kev") else float(fact.get("epss") or 0.0)
            if best is None or score > best[0]:
                best = (score, cve, fact)
    if best is None:
        return 0.0, ""
    score, cve, fact = best
    bits = [cve]
    if fact.get("kev"):
        note = "listed in CISA's Known Exploited Vulnerabilities catalog"
        if fact.get("kev_date_added"):
            note += f" since {fact['kev_date_added']}"
        if str(fact.get("kev_ransomware", "")).lower() == "known":
            note += " (known ransomware use)"
        bits.append(note)
    if fact.get("epss") is not None:
        pct = fact.get("epss_percentile")
        note = f"EPSS {fact['epss'] * 100:.1f}% predicted exploitation probability in the next 30 days"
        if pct is not None:
            note += f" ({pct * 100:.0f}th percentile)"
        bits.append(note)
    reason = "; ".join(bits)
    return round(min(1.0, score), 3), reason[0].upper() + reason[1:] + "."


def _dependency_reachability(members: list[Observation]) -> dict:
    """Union every member observation's per-component reachability breakdown
    into one dict for the cluster -- almost always at most one SBOM
    observation per cluster, but a dict union rather than "take the first"
    keeps this correct if more than one ever contributes."""
    out: dict = {}
    for o in members:
        if o.dependency_reachability:
            out.update(o.dependency_reachability)
    return out


def _adjudicate(family: str, family_title: str,
                members: list[Observation],
                epss_kev_lookup: dict | None = None) -> CorrelatedFinding:
    kinds = {o.kind for o in members}
    verdict = _verdict(kinds)
    base = worst(*[o.severity for o in members]) if members else "Info"

    # A confirmed-exploitable weakness is at least High: two independent methods
    # agree it is reachable, so it should never sit below High regardless of how
    # conservatively either tool scored it on its own. An actively-exploited one
    # is floored at Critical -- real-world exploitation outranks even that lab
    # proof, regardless of how any individual source scored it.
    severity = base
    if verdict is Verdict.ACTIVELY_EXPLOITED:
        severity = "Critical"
    elif verdict is Verdict.CONFIRMED_EXPLOITABLE and \
            SEVERITY_SCORE.get(base, 1) < SEVERITY_SCORE["High"]:
        severity = "High"

    confidence, confidence_reason = _confidence(kinds, members)
    exploitability, exploitability_reason = _exploitability(members)
    business_impact, business_impact_reason = _business_impact(members)
    epss_kev_score, epss_kev_reason = _epss_kev(members, epss_kev_lookup)
    dependency_reachability = _dependency_reachability(members)
    priority = round(
        SEVERITY_SCORE.get(severity, 1) + _VERDICT_BUMP[verdict] + confidence
        + exploitability + business_impact + epss_kev_score, 3)

    return CorrelatedFinding(
        family=family,
        family_title=family_title,
        observations=members,
        verdict=verdict,
        severity=severity,
        base_severity=base,
        confidence=confidence,
        confidence_reason=confidence_reason,
        priority=priority,
        exploitability=exploitability,
        exploitability_reason=exploitability_reason,
        business_impact=business_impact,
        business_impact_reason=business_impact_reason,
        epss_kev=epss_kev_score,
        epss_kev_reason=epss_kev_reason,
        dependency_reachability=dependency_reachability,
    )


def correlate(reports: list[dict], epss_kev_lookup: dict | None = None) -> list[CorrelatedFinding]:
    """Correlate a set of saved reports into ranked cross-source findings."""
    reports = annotate_dependency_reachability(reports)
    observations: list[Observation] = []
    for report in reports:
        observations.extend(observe_report(report))
    return correlate_observations(observations, epss_kev_lookup=epss_kev_lookup)


def correlate_observations(
        observations: list[Observation],
        epss_kev_lookup: dict | None = None) -> list[CorrelatedFinding]:
    """Correlate already-ingested observations into ranked cross-source findings.

    Pure and report-agnostic — callers that have already parsed reports (to count
    observations, say) can hand the list straight in without re-parsing.

    ``epss_kev_lookup`` is an optional ``{cve: fact}`` table (see
    epss_kev.combined_lookup) the caller builds by reading the on-disk
    EPSS/KEV cache -- the one piece of external, filesystem-backed intel this
    otherwise-pure engine folds in, injected rather than fetched here so the
    engine itself never touches the filesystem or network.
    """
    by_family: dict[str, list[Observation]] = {}
    for obs in observations:
        by_family.setdefault(obs.family, []).append(obs)

    _expand_owasp_designs(by_family)

    findings: list[CorrelatedFinding] = []
    for family, obs_list in by_family.items():
        title = obs_list[0].family_title
        for members in _cluster_family(obs_list):
            if members:
                findings.append(_adjudicate(family, title, members, epss_kev_lookup))

    findings.sort(key=lambda f: (-f.priority, f.family))
    return findings
