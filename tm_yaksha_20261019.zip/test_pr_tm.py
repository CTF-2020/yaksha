"""Regression test for broker/pr_tm.py's changed_files() git-argument-injection guard.

base_branch comes from a GitHub pull_request webhook's base.ref (broker/github.py's
parse_webhook), which is otherwise unvalidated before reaching git — see the
matching fix + tests in test_remediation.py for the analogous `against` field.
"""
from __future__ import annotations

import tempfile
import unittest
from unittest import mock

from broker import pr_tm, scanner


class ChangedFilesInjectionGuardTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="pr_tm_test_")

    def test_malicious_base_branch_never_reaches_run_git(self):
        # The bad value must never appear in any _run_git call — it should
        # skip straight to the safe HEAD~1..HEAD fallback instead.
        with mock.patch.object(scanner, "_run_git", return_value="") as run_git:
            pr_tm.changed_files(self.tmp, "--upload-pack=touch /tmp/pwned")
        for call in run_git.call_args_list:
            self.assertNotIn("--upload-pack=touch /tmp/pwned", call.args[0])
        self.assertEqual(run_git.call_count, 1)
        self.assertEqual(run_git.call_args_list[0].args[0],
                         ["diff", "--name-only", "--diff-filter=d", "HEAD~1", "HEAD"])

    def test_valid_base_branch_is_passed_with_a_double_dash_separator(self):
        with mock.patch.object(scanner, "_run_git", return_value="") as run_git:
            pr_tm.changed_files(self.tmp, "main")
        fetch_call = run_git.call_args_list[0].args[0]
        self.assertIn("--", fetch_call)
        self.assertLess(fetch_call.index("--"), fetch_call.index("main"))


if __name__ == "__main__":
    unittest.main()
