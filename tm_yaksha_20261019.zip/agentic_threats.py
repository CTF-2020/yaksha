"""agentic_threats.py — Detection and analysis of AI/agentic-specific attack surfaces."""
from __future__ import annotations
import re
from typing import TypedDict


class AiDetectionResult(TypedDict, total=False):
    is_ai: bool
    confidence: str
    matched_categories: list[str]
    matched_keywords: dict[str, list[str]]
    total_matches: int
    sub_patterns: dict[str, bool]


class ApiDetectionResult(TypedDict, total=False):
    is_api: bool
    confidence: str
    matched_categories: list[str]
    total_matches: int

# Keywords that indicate AI/LLM/agentic components in an architecture
_AI_KEYWORDS: dict[str, list[str]] = {
    "llm_providers": [
        "openai", "anthropic", "claude", "gpt", "gemini", "mistral", "llama",
        "cohere", "huggingface", "bedrock", "vertex ai", "azure openai",
    ],
    "frameworks": [
        "langchain", "langgraph", "autogpt", "crewai", "autogen", "llamaindex",
        "haystack", "semantic kernel", "mcp", "model context protocol",
        "dspy", "guidance", "outlines",
    ],
    "vector_stores": [
        "pinecone", "weaviate", "chroma", "chromadb", "qdrant", "faiss",
        "milvus", "pgvector", "redis vector", "opensearch knn",
    ],
    "patterns": [
        "rag", "retrieval augmented", "retrieval-augmented", "embedding",
        "fine-tuning", "fine tuning", "finetuning", "lora", "qlora",
        "similarity search", "vector search", "semantic search",
    ],
    "agentic": [
        "agent", "agentic", "multi-agent", "multiagent", "swarm", "orchestrator",
        "tool use", "tool call", "function calling", "function call",
        "plugin", "code interpreter", "computer use", "autonomous agent",
        "ai agent", "llm agent",
    ],
    "inference": [
        "llm", "large language model", "language model", "inference",
        "prompt", "chatbot", "conversational ai", "nlp pipeline",
        "transformer", "attention mechanism",
    ],
    "model_supply_chain": [
        "model weights", "model checkpoint", "checkpoint", "model registry",
        "hugging face", "huggingface", "model card", "pretrained model",
        "base model", "model provenance",
    ],
    "generic_ai_signal": [
        "ai-generated", "ai generated", "ai decision", "ai recommendation",
        "artificial intelligence", "generative ai",
    ],
}

# All keywords flattened for quick detection
_ALL_KEYWORDS: set[str] = {kw for group in _AI_KEYWORDS.values() for kw in group}

_AI_NEGATION_RE = re.compile(
    r"\b("
    r"no|without|not using|does not use|doesn't use|do not use|don't use|not in scope|out of scope|not present|absent"
    r")\s+("
    r"ai|llm|large language model|language model|model|gpt|claude|rag|retrieval|vector|embedding|agent|agentic|tool calling|function calling"
    r")\b"
    r"|\b("
    r"ai|llm|large language model|language model|rag|vector store|agent|agentic"
    r")\s+("
    r"is not used|are not used|not used|disabled|absent|not present|out of scope"
    r")\b",
    re.IGNORECASE,
)


def _keyword_matches(text_lower: str, keyword: str) -> bool:
    """Match AI keywords as terms, not substrings.

    This prevents false positives such as "rag" matching "storage".
    """
    keyword_lower = keyword.lower().strip()
    if not keyword_lower:
        return False
    return bool(re.search(rf"(?<![a-z0-9]){re.escape(keyword_lower)}(?![a-z0-9])", text_lower))


def detect_ai_architecture(architecture_text: str) -> dict:
    """
    Detect if architecture contains AI/LLM/agentic components.
    Returns detailed detection result for use in threat analysis routing.
    """
    text_lower = architecture_text.lower()
    negated_ai_surface = bool(_AI_NEGATION_RE.search(architecture_text or ""))
    matched_by_category: dict[str, list[str]] = {}

    for category, keywords in _AI_KEYWORDS.items():
        hits = [kw for kw in keywords if _keyword_matches(text_lower, kw)]
        if hits:
            matched_by_category[category] = hits

    total_matches = sum(len(v) for v in matched_by_category.values())
    matched_categories = list(matched_by_category.keys())

    # Confidence scoring
    if total_matches >= 5 or len(matched_categories) >= 3:
        confidence = "high"
    elif total_matches >= 2 or len(matched_categories) >= 2:
        confidence = "medium"
    elif total_matches >= 1:
        confidence = "low"
    else:
        confidence = "none"

    # Detect specific sub-patterns for targeted analysis
    has_rag = bool(matched_by_category.get("patterns") or matched_by_category.get("vector_stores"))
    has_agents = bool(matched_by_category.get("agentic"))
    has_multi_agent = any(kw in text_lower for kw in ["multi-agent", "multiagent", "swarm", "orchestrator"])
    has_tool_use = any(kw in text_lower for kw in ["tool use", "tool call", "function calling", "plugin", "mcp"])
    has_fine_tuning = any(kw in text_lower for kw in ["fine-tuning", "fine tuning", "finetuning", "lora", "qlora"])
    has_external_llm = bool(matched_by_category.get("llm_providers"))

    return {
        "is_ai": confidence != "none" and not negated_ai_surface,
        "confidence": confidence,
        "negated_ai_surface": negated_ai_surface,
        "matched_categories": matched_categories,
        "matched_keywords": {k: v for k, v in matched_by_category.items()},
        "total_matches": total_matches,
        "sub_patterns": {
            "has_rag": has_rag,
            "has_agents": has_agents,
            "has_multi_agent": has_multi_agent,
            "has_tool_use": has_tool_use,
            "has_fine_tuning": has_fine_tuning,
            "has_external_llm": has_external_llm,
        },
    }


def is_ai_analysis_applicable(detection: dict) -> bool:
    """Return True only when there is concrete AI/LLM/agentic evidence.

    Low-signal terms like "prompt", "inference", "plugin", or "agent" alone
    should not cause OWASP LLM findings on a normal web/API architecture.
    """
    if detection.get("negated_ai_surface"):
        return False

    matched = detection.get("matched_keywords", {}) or {}
    if matched.get("llm_providers") or matched.get("frameworks") or matched.get("vector_stores"):
        return True

    high_signal_patterns = {
        "rag", "retrieval augmented", "retrieval-augmented", "embedding",
        "fine-tuning", "fine tuning", "finetuning", "lora", "qlora",
        "similarity search", "vector search", "semantic search",
    }
    if any(keyword in high_signal_patterns for keyword in matched.get("patterns", [])):
        return True

    high_signal_inference = {
        "llm", "large language model", "language model", "chatbot",
        "conversational ai", "nlp pipeline", "transformer", "attention mechanism",
    }
    if any(keyword in high_signal_inference for keyword in matched.get("inference", [])):
        return True

    high_signal_agentic = {
        "agentic", "multi-agent", "multiagent", "swarm", "tool use",
        "tool call", "function calling", "function call", "code interpreter",
        "computer use", "mcp", "model context protocol", "autonomous agent",
        "ai agent", "llm agent",
    }
    if any(keyword in high_signal_agentic for keyword in matched.get("agentic", [])):
        return True

    if matched.get("model_supply_chain") or matched.get("generic_ai_signal"):
        return True

    return False



def get_agentic_attack_surface(detection: dict, architecture_text: str) -> dict:
    """
    Given AI detection results, return targeted agentic attack surface analysis.
    This is injected into the prompt for Claude to generate specific threats.
    """
    if not detection.get("is_ai"):
        return {}

    sub = detection.get("sub_patterns", {})
    attack_surfaces = []

    # Always present for any AI system
    attack_surfaces.append({
        "surface": "LLM Inference Endpoint",
        "risks": ["Prompt injection via user inputs", "System prompt extraction", "Model DoS via token flooding"],
        "priority": "Critical",
    })

    if sub.get("has_rag"):
        attack_surfaces.append({
            "surface": "RAG Pipeline (Retrieval + Vector Store)",
            "risks": [
                "Indirect prompt injection via poisoned retrieved documents",
                "Vector DB poisoning skewing retrieval toward adversarial content",
                "PII leakage via memorization of indexed sensitive documents",
                "Embedding inversion attacks recovering source documents",
            ],
            "priority": "Critical",
        })

    if sub.get("has_agents"):
        attack_surfaces.append({
            "surface": "Agent Execution Layer",
            "risks": [
                "Excessive agency: agent performs irreversible actions without oversight",
                "Tool parameter injection: crafted inputs manipulate tool arguments",
                "Agent loop hijacking via injected instructions in tool responses",
                "Resource exhaustion via unbounded agent recursion",
            ],
            "priority": "Critical",
        })

    if sub.get("has_multi_agent"):
        attack_surfaces.append({
            "surface": "Multi-Agent Coordination",
            "risks": [
                "Cross-agent context contamination: compromised agent poisons shared memory",
                "Trust escalation: low-trust agent masquerades as high-trust agent",
                "Orchestrator compromise: root agent hijacked controls all sub-agents",
                "Replay attacks on agent message queues",
            ],
            "priority": "Critical",
        })

    if sub.get("has_tool_use"):
        attack_surfaces.append({
            "surface": "Tool / Plugin / Function Calling Layer",
            "risks": [
                "Insecure plugin design: excessive permissions granted to tools",
                "Tool output injection: malicious content in tool responses hijacks agent",
                "Unauthorized tool invocation escalating agent privileges",
                "Side-channel data exfiltration via tool call patterns",
            ],
            "priority": "High",
        })

    if sub.get("has_fine_tuning"):
        attack_surfaces.append({
            "surface": "Fine-Tuning / Training Pipeline",
            "risks": [
                "Training data poisoning via malicious fine-tuning examples",
                "Backdoor implantation in fine-tuned model weights",
                "Membership inference: training data reconstructed from model outputs",
                "Supply chain compromise of pre-trained base model",
            ],
            "priority": "High",
        })

    if sub.get("has_external_llm"):
        providers = detection.get("matched_keywords", {}).get("llm_providers", [])
        attack_surfaces.append({
            "surface": f"External LLM Provider API ({', '.join(providers) or 'Third-party'})",
            "risks": [
                "API key theft enabling unauthorized inference or billing fraud",
                "Sensitive data sent to third-party LLM violating data residency requirements",
                "Provider-side model behavior changes breaking security assumptions",
                "Rate limit exhaustion (LLM DoS via key compromise)",
            ],
            "priority": "High",
        })

    return {
        "detection": detection,
        "attack_surfaces": attack_surfaces,
        "owasp_llm_applicable": True,
        "recommended_frameworks": ["OWASP LLM Top 10 2025", "MITRE ATLAS", "OWASP Top 10 for LLM Applications"],
    }


# Keywords indicating a heavily API-driven architecture
_API_KEYWORDS: dict[str, list[str]] = {
    "protocols": ["rest", "graphql", "grpc", "json api", "openapi", "swagger", "api gateway"],
    "patterns": ["endpoint", "microservice", "webhook", "oauth", "jwt", "api key", "rate limit"],
    "infrastructure": ["kong", "apigee", "aws api gateway", "nginx", "traefik", "envoy"],
}


def detect_api_architecture(architecture_text: str) -> ApiDetectionResult:
    """Detect if architecture is API-heavy. Returns detection result for methodology routing."""
    text_lower = architecture_text.lower()
    matched_by_category: dict[str, list[str]] = {}

    for category, keywords in _API_KEYWORDS.items():
        hits = [kw for kw in keywords if kw in text_lower]
        if hits:
            matched_by_category[category] = hits

    total_matches = sum(len(v) for v in matched_by_category.values())
    if total_matches >= 4 or len(matched_by_category) >= 2:
        confidence = "high"
    elif total_matches >= 2:
        confidence = "medium"
    elif total_matches >= 1:
        confidence = "low"
    else:
        confidence = "none"

    return ApiDetectionResult(
        is_api=confidence != "none",
        confidence=confidence,
        matched_categories=list(matched_by_category.keys()),
        total_matches=total_matches,
    )
