"""Render an extracted model + derived threats into a Yaksha Guard report.

Two things are surfaced: the derived threat categories (from :mod:`threats`) and
an architecture-inventory category summarizing the attack surface and trust
boundaries the extractor found — so a reader gets both "here are the problems"
and "here is the system I inferred from your code".
"""
from __future__ import annotations

import time

_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _architecture_category(model) -> dict:
    st = model.stats()
    ep_lines = []
    for ep in sorted(model.entry_points, key=lambda e: (e.authenticated, e.path))[:40]:
        if ep.kind == "agent-tool":
            lock = "🤖 tool"
        else:
            lock = "🔓 open" if not ep.authenticated else "🔒 auth"
        ep_lines.append({
            "name": f"{lock}  {ep.locus}",
            "description": f"{ep.handler} ({ep.file}:{ep.line}) · {ep.framework}"
                           + (f" · reaches {len(ep.reachable_sinks)} sink(s)"
                              if ep.reachable_sinks else ""),
            "attack_vector": "Attack surface entry point",
            "control_objective": ", ".join(c.mechanism for c in ep.controls) or "no controls observed",
        })
    boundaries = "; ".join(b.name for b in model.trust_boundaries) or "none inferred"
    return {
        "id": "CM-ARCH",
        "category": "Architecture (code-derived)",
        "name": "Attack surface & trust boundaries",
        "title": "Attack surface & trust boundaries",
        "risk": "Info",
        "risk_score": 1,
        "_source": "CODEMODEL",
        "ruleset": "CodeModel",
        "description": (
            f"Extracted {st['entry_points']} entry point(s) "
            f"({st['unauthenticated_entry_points']} with no observed auth), "
            f"{st['data_stores']} data store(s), {st['external_calls']} external call(s), "
            f"{st['trust_boundaries']} trust boundary(ies). Boundaries: {boundaries}."),
        "affected_components": [b.name for b in model.trust_boundaries],
        "mitigation": "Confirm this inferred model matches the intended architecture; "
                      "investigate any entry point or boundary you did not expect.",
        "remediation": "Reconcile against the design/threat model.",
        "mitigations": [{"action": "Reconcile against the design/threat model.",
                         "priority": "Short-term"}],
        "threats": ep_lines,
        "notes": "; ".join(f"{b.name}: {b.description}" for b in model.trust_boundaries),
    }


def _attack_surface(model) -> list[dict]:
    """Structured entry-point -> reachable-sink graph for attack-path synthesis.

    The architecture *category* renders this as prose for humans; this preserves
    it as data in ``scan_metadata`` so the attack-path synthesizer can chain each
    unauthenticated entry point to the tainted sink it reaches, without re-running
    the extractor. Bounded so a huge repo can't bloat the saved report.
    """
    surface = []
    for ep in model.entry_points[:200]:
        surface.append({
            "method": ep.method, "path": ep.path, "handler": ep.handler,
            "file": ep.file, "line": ep.line, "framework": ep.framework,
            "kind": ep.kind, "authenticated": ep.authenticated,
            "controls": [{"kind": c.kind, "mechanism": c.mechanism} for c in ep.controls],
            "sinks": [{
                "kind": s.kind, "family": s.family, "cwe": s.cwe, "name": s.name,
                "file": s.file, "line": s.line, "hops": s.hops,
                "tainted": s.tainted, "confidence": s.confidence,
            } for s in ep.reachable_sinks[:40]],
            # Every third-party call reachable from this entry point, not just
            # ones matching a dangerous-sink pattern — lets a vulnerable-
            # dependency (SBOM) finding be checked for reachability by exact
            # import-root match (see correlator/engine.py).
            "deps": [{
                "root": d.root, "name": d.name, "file": d.file, "line": d.line,
                "hops": d.hops, "tainted": d.tainted,
            } for d in ep.reachable_deps[:40]],
        })
    return surface


def build_report(model, threat_categories: list[dict], repo: dict, meta: dict) -> dict:
    categories = list(threat_categories)
    categories.append(_architecture_category(model))

    overall = "Info"
    for c in categories:
        if _ORDER.get(c["risk"], 9) < _ORDER.get(overall, 9):
            overall = c["risk"]

    st = model.stats()
    name = repo.get("name", repo.get("id", "repo"))
    threats_n = len(threat_categories)
    summary = (
        f"Code-derived threat model of {name}: analyzed {st['files_scanned']} file(s), "
        f"inferred {st['entry_points']} entry point(s) "
        f"({st['unauthenticated_entry_points']} unauthenticated), "
        f"{st['data_stores']} data store(s), {st['trust_boundaries']} trust boundary(ies). "
        f"Derived {threats_n} threat finding(s). "
        f"Frameworks: {', '.join(sorted(model.frameworks)) or 'none detected'}."
    )
    recommendations = []
    seen = set()
    for c in categories:
        rec = c.get("mitigation", "")
        if rec and rec not in seen:
            seen.add(rec)
            recommendations.append(rec)

    return {
        "title": f"Code-Derived Threat Model · {name}",
        "methodology": "codemodel",
        "methodology_label": "Code-Derived Threat Model",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "analyzed_at": now_iso(),
        "summary": summary,
        "categories": categories,
        "recommendations": recommendations[:12],
        "scan_metadata": {
            "engine": "codemodel",
            "repo_id": repo.get("id"),
            "repo_name": name,
            "frameworks": sorted(model.frameworks),
            "languages": sorted(model.languages),
            "stats": st,
            "trust_boundaries": [
                {"name": b.name, "kind": b.kind, "description": b.description}
                for b in model.trust_boundaries],
            "attack_surface": _attack_surface(model),
            # Structured code facts for architecture-drift detection (diffing the
            # inferred model against a declared design). Bounded, additive.
            "data_stores": [
                {"kind": d.kind, "engine": d.engine, "file": d.file, "line": d.line}
                for d in model.data_stores[:100]],
            "external_calls": [
                {"kind": c.kind, "target": c.target, "file": c.file,
                 "line": c.line, "encrypted": c.encrypted}
                for c in model.external_calls[:100]],
            "code_controls": [
                {"kind": c.kind, "mechanism": c.mechanism, "scope": c.scope}
                for c in model.controls[:100]],
            "parse_errors": model.parse_errors[:20],
            **meta,
        },
    }
