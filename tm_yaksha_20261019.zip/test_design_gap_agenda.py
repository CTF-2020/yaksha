"""Tests for the per-finding design-gap worklist (design_gap_agenda.py).

Isolated onto temp stores for report_db, suppressions, ownership and
verdict_tracking -- writing through the real ones would pollute
~/.tm_reports / ~/.tm_suppressions.db / ~/.tm_ownership.db /
~/.tm_verdict_history.db (same isolation set as test_triage.py, plus
verdict_tracking since this module ages findings against it).
"""
from __future__ import annotations

import tempfile
import time
import unittest
from pathlib import Path

import design_gap_agenda
import ownership
import report_db
import verdict_tracking
from suppressions import db as supp_db
from suppressions import store as supp_store
import suppressions


def _cat(cid, verdict="design_gap", family="sql-injection", cwe="CWE-89", loci=None):
    loci = loci or [f"{cid}.py:1"]
    return {"id": cid, "name": cid, "title": cid, "risk": "High", "family": family,
            "cwe": cwe, "verdict": verdict, "threats": [{"name": l} for l in loci],
            "affected_components": loci}


def _report(rid, cats, methodology="correlation", title="R"):
    return {"id": rid, "title": title, "methodology": methodology,
            "overall_risk": cats[0]["risk"] if cats else "Info", "categories": cats}


class AgendaTests(unittest.TestCase):
    def setUp(self):
        self._orp = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self._oop = ownership.DB_PATH
        self._ovp = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        report_db.DB_PATH = self._orp
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp
        ownership.DB_PATH = self._oop
        verdict_tracking.DB_PATH = self._ovp

    def test_empty_store_gives_empty_agenda(self):
        a = design_gap_agenda.agenda()
        self.assertEqual(a["total"], 0)
        self.assertEqual(a["items"], [])

    def test_non_design_gap_finding_excluded(self):
        report_db.upsert_report(_report("r1", [_cat("A", verdict="confirmed_exploitable")]))
        a = design_gap_agenda.agenda()
        self.assertEqual(a["total"], 0)

    def test_design_gap_finding_appears_with_age_from_verdict_tracking(self):
        cat = _cat("A")
        report_db.upsert_report(_report("r1", [cat]))
        started = time.time() - 10 * 86400  # 10 days ago
        verdict_tracking.record_transitions(_report("r1", [cat]), now=started)

        a = design_gap_agenda.agenda(now=started + 10 * 86400)
        self.assertEqual(a["total"], 1)
        item = a["items"][0]
        self.assertAlmostEqual(item["age_days"], 10.0, delta=0.1)
        self.assertEqual(item["sla_days"], 30)
        self.assertFalse(item["overdue"])

    def test_overdue_past_sla_window(self):
        cat = _cat("A")
        report_db.upsert_report(_report("r1", [cat]))
        started = time.time() - 45 * 86400
        verdict_tracking.record_transitions(_report("r1", [cat]), now=started)

        a = design_gap_agenda.agenda(now=started + 45 * 86400)
        self.assertEqual(a["overdue"], 1)
        self.assertTrue(a["items"][0]["overdue"])

    def test_finding_never_tracked_by_verdict_history_still_appears(self):
        # No record_transitions call at all -- since_map has nothing for this
        # fingerprint, so age falls back to the finding's own created_at.
        report_db.upsert_report(_report("r1", [_cat("A")]))
        a = design_gap_agenda.agenda()
        self.assertEqual(a["total"], 1)
        self.assertGreaterEqual(a["items"][0]["age_days"], 0)

    def test_next_step_no_rule_for_unmatched_cwe(self):
        report_db.upsert_report(_report("r1", [_cat("A", cwe="CWE-999999")]))
        a = design_gap_agenda.agenda()
        self.assertEqual(a["items"][0]["next_step"], "no_rule")
        self.assertEqual(a["by_next_step"]["no_rule"], 1)

    def test_next_step_rule_exists_for_known_cwe(self):
        # CWE-89 (SQL injection) is populated in every real-world rule
        # catalog ruleset this project ships with.
        report_db.upsert_report(_report("r1", [_cat("A", cwe="CWE-89")]))
        a = design_gap_agenda.agenda()
        item = a["items"][0]
        if item["next_step"] == "rule_exists":
            self.assertTrue(item["related_rules"])
            self.assertEqual(a["by_next_step"]["rule_exists"], 1)
        else:
            # Offline/stripped catalog install -- still a legitimate answer.
            self.assertEqual(item["next_step"], "no_rule")

    def test_suppressed_finding_excluded(self):
        report_db.upsert_report(_report("r1", [_cat("A")]))
        suppressions.add_suppression({
            "scope": "rule", "match": "A", "reason": "accepted", "author": "dave"})
        a = design_gap_agenda.agenda()
        self.assertEqual(a["total"], 0)

    def test_sast_dast_methodology_included_by_default(self):
        # Unlike verdict_reconciliation.py, design gaps are never emitted by
        # raw sast/dast reports (only correlation output carries a verdict),
        # so this just confirms include_sast doesn't accidentally exclude
        # a correlation-methodology report.
        report_db.upsert_report(_report("r1", [_cat("A")], methodology="correlation"))
        a = design_gap_agenda.agenda()
        self.assertEqual(a["total"], 1)

    def test_oldest_first_ordering(self):
        cat_a, cat_b = _cat("A", loci=["a.py:1"]), _cat("B", loci=["b.py:1"])
        report_db.upsert_report(_report("r1", [cat_a, cat_b]))
        now = time.time()
        verdict_tracking.record_transitions(_report("r1", [cat_a]), now=now - 5 * 86400)
        verdict_tracking.record_transitions(_report("r1", [cat_b]), now=now - 20 * 86400)

        a = design_gap_agenda.agenda(now=now)
        self.assertEqual([i["rule"] for i in a["items"]], ["B", "A"])

    def test_limit_caps_items_but_not_totals(self):
        cats = [_cat(f"C{i}", loci=[f"f{i}.py:1"]) for i in range(5)]
        report_db.upsert_report(_report("r1", cats))
        a = design_gap_agenda.agenda(limit=2)
        self.assertEqual(a["total"], 5)
        self.assertEqual(len(a["items"]), 2)


class DesignGapAgendaApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orp = report_db.DB_PATH
        self._oop = ownership.DB_PATH
        self._ovp = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        report_db.DB_PATH = self._orp
        ownership.DB_PATH = self._oop
        verdict_tracking.DB_PATH = self._ovp

    def test_agenda_endpoint(self):
        report_db.upsert_report(_report("r1", [_cat("A")]))
        resp = self.client.get("/api/v1/correlate/design-debt/agenda")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["total"], 1)

    def test_agenda_endpoint_bad_limit_falls_back_to_default(self):
        resp = self.client.get("/api/v1/correlate/design-debt/agenda?limit=notanumber")
        # Same convention as /trend and /design-debt on this blueprint: a
        # malformed int falls back to the default rather than 400ing.
        self.assertEqual(resp.status_code, 200)


if __name__ == "__main__":
    unittest.main(verbosity=2)
