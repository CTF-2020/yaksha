"""Code-derived threat modeling engine for Yaksha Guard.

Reads a codebase and lifts it into threat-model vocabulary — entry points (attack
surface), trust boundaries, data stores, external calls, security controls and
secrets — then derives threat findings by reasoning about control presence vs
absence on that surface. Output is a standard report that both renders in the
viewer and feeds the correlation engine (tagged ``_source: "CODEMODEL"``).

Public surface:
  * ``extractor.build_model(root) -> SystemModel`` — the pure architecture lift.
  * ``threats.derive(model) -> list[category]`` — control-gap threat derivation.
  * ``service.analyze_repo(repo) -> report_dict`` — end-to-end over a registered repo.
"""
from __future__ import annotations

from . import extractor, mapper, service, threats  # noqa: F401
from .model import EntryPoint, SystemModel, TrustBoundary  # noqa: F401

__all__ = ["extractor", "mapper", "service", "threats",
           "EntryPoint", "SystemModel", "TrustBoundary"]
