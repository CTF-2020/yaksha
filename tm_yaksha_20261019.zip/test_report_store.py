"""Tests for the crash-safe report store — the data-loss regression guard.

Run:  python -m unittest test_report_store

These reproduce the corruption modes that can silently empty the report index
(BOM, truncated/partial JSON, wrong type, empty file) and assert the store
fails safe: it either returns a valid index or self-heals from a backup, and it
never lets a bad write clobber a good backup. The most important case,
``test_bom_index_does_not_empty``, is the exact scenario that previously caused
every report file to be pruned.
"""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

import report_store as rs


class TestAtomicWrite(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix="rs_test_"))
        self.p = self.dir / "f.json"

    def test_atomic_write_roundtrip(self):
        rs.atomic_write_json(self.p, {"a": 1})
        self.assertEqual(rs.read_json(self.p), {"a": 1})

    def test_atomic_write_leaves_no_temp_files(self):
        rs.atomic_write_json(self.p, {"a": 1})
        leftovers = [x for x in self.dir.iterdir() if x.name.endswith(".tmp")]
        self.assertEqual(leftovers, [])

    def test_atomic_write_preserves_prior_on_failure(self):
        rs.atomic_write_json(self.p, {"good": True})
        # json.dumps of a set raises TypeError *before* any replace happens.
        with self.assertRaises(TypeError):
            rs.atomic_write_json(self.p, {"bad": {1, 2, 3}})
        self.assertEqual(rs.read_json(self.p), {"good": True})   # old version intact

    def test_atomic_replace_retries_transient_permission_error(self):
        # Simulate a Windows sharing violation on the first few os.replace calls
        # (antivirus/indexer holding the target); the write must still succeed.
        import unittest.mock as mock
        real_replace = os.replace
        calls = {"n": 0}

        def flaky(src, dst):
            calls["n"] += 1
            if calls["n"] <= 3:
                raise PermissionError(13, "temporarily locked")
            return real_replace(src, dst)

        with mock.patch("report_store.os.replace", side_effect=flaky):
            with mock.patch("report_store._REPLACE_BACKOFF", 0):   # no test delay
                rs.atomic_write_json(self.p, {"survived": True})
        self.assertEqual(calls["n"], 4)                    # 3 failures + 1 success
        self.assertEqual(rs.read_json(self.p), {"survived": True})

    def test_atomic_replace_raises_after_exhausting_retries(self):
        import unittest.mock as mock
        with mock.patch("report_store.os.replace",
                        side_effect=PermissionError(13, "locked forever")):
            with mock.patch("report_store._REPLACE_BACKOFF", 0):
                with self.assertRaises(PermissionError):
                    rs.atomic_write_json(self.p, {"x": 1})
        # The temp file must not be left behind on ultimate failure.
        leftovers = [x for x in self.dir.iterdir() if x.name.endswith(".tmp")]
        self.assertEqual(leftovers, [])


class TestReadJson(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix="rs_test_"))
        self.p = self.dir / "f.json"

    def test_bom_is_tolerated(self):
        self.p.write_bytes(("﻿" + json.dumps([1, 2, 3])).encode("utf-8"))
        self.assertEqual(rs.read_json(self.p), [1, 2, 3])

    def test_truncated_returns_default(self):
        self.p.write_text('[{"id": "a"}, {"id": ')   # partial write
        self.assertIsNone(rs.read_json(self.p, default=None))

    def test_missing_returns_default(self):
        self.assertEqual(rs.read_json(self.dir / "nope.json", default=[]), [])


class TestIndexDurability(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix="rs_test_"))
        self.idx = self.dir / "_index.json"

    def test_save_creates_backup_of_prior_good(self):
        rs.save_index(self.idx, [{"id": "v1"}])
        rs.save_index(self.idx, [{"id": "v2"}])   # rotates v1 into .bak1
        self.assertEqual(rs.read_json(self.idx.with_suffix(".json.bak1")), [{"id": "v1"}])

    def test_bom_index_does_not_empty(self):
        # THE regression: a BOM'd index must not read back as empty.
        rs.save_index(self.idx, [{"id": "real1"}, {"id": "real2"}])
        # simulate an external editor rewriting the index WITH a BOM
        raw = self.idx.read_text(encoding="utf-8")
        self.idx.write_bytes(("﻿" + raw).encode("utf-8"))
        loaded = rs.load_index(self.idx)
        self.assertEqual(len(loaded), 2)

    def test_corrupt_index_self_heals_from_backup(self):
        rs.save_index(self.idx, [{"id": "a"}, {"id": "b"}])          # -> becomes .bak1 next save
        rs.save_index(self.idx, [{"id": "a"}, {"id": "b"}, {"id": "c"}])
        self.idx.write_text("{ this is not json")                    # corrupt the primary
        loaded = rs.load_index(self.idx)
        self.assertTrue(any(e["id"] == "c" for e in loaded) or len(loaded) >= 2)
        self.assertGreaterEqual(len(loaded), 2)                       # not emptied

    def test_empty_current_does_not_overwrite_good_backup(self):
        rs.save_index(self.idx, [{"id": "keep"}])   # good
        rs.save_index(self.idx, [{"id": "keep"}])   # backup now holds the good one
        # Now write an empty index; rotation must NOT promote the empty one.
        rs.save_index(self.idx, [])
        self.assertEqual(rs.newest_valid_backup(self.idx), [{"id": "keep"}])

    def test_missing_index_is_legitimately_empty(self):
        self.assertEqual(rs.load_index(self.idx), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
