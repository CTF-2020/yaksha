"""PR-scoped threat modeling (broker/pr_tm.py) + SAST exclusion in report_db.

pr_tm turns a pull_request scan's changed-file diff into a codemodel threat
model without a full-repo pass; the report_db viewer queries must never
surface methodology='sast' rows unless a caller opts in.
"""
from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import report_db
from broker import pr_tm


PR_CTX = {"kind": "pull_request", "number": 7, "base_branch": "main",
          "sha": "a" * 40}


class TestEnabled(unittest.TestCase):
    def test_default_on(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("TM_BROKER_PR_TM", None)
            self.assertTrue(pr_tm.enabled({}))

    def test_env_kill_switch(self):
        with mock.patch.dict(os.environ, {"TM_BROKER_PR_TM": "off"}):
            self.assertFalse(pr_tm.enabled({}))

    def test_per_repo_opt_out(self):
        with mock.patch.dict(os.environ, {"TM_BROKER_PR_TM": "on"}):
            self.assertFalse(pr_tm.enabled({"pr_tm": "false"}))
            self.assertTrue(pr_tm.enabled({"pr_tm": "on"}))


class TestRun(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        self.root = Path(self._td.name)
        (self.root / "svc").mkdir()
        (self.root / "svc" / "handler.py").write_text(
            "import subprocess\n"
            "from flask import Flask, request\n"
            "app = Flask(__name__)\n"
            "@app.route('/run', methods=['POST'])\n"
            "def run_cmd():\n"
            "    cmd = request.form['cmd']\n"
            "    return subprocess.check_output(cmd, shell=True)\n",
            encoding="utf-8")
        (self.root / "README.md").write_text("docs only", encoding="utf-8")

    def test_not_a_pr_returns_none(self):
        self.assertIsNone(pr_tm.run(self.root, {"name": "r"},
                                    {"kind": "push"}, lambda r: "x"))

    def test_no_changed_files_returns_none(self):
        with mock.patch.object(pr_tm, "changed_files", return_value=[]):
            self.assertIsNone(pr_tm.run(self.root, {"name": "r"}, PR_CTX,
                                        lambda r: "x"))

    def test_builds_and_saves_pr_scoped_model(self):
        saved = {}

        def save(report):
            saved.update(report)
            return "rid-123"

        changed = ["svc/handler.py", "README.md", "gone.py"]  # gone.py deleted
        with mock.patch.object(pr_tm, "changed_files", return_value=changed):
            out = pr_tm.run(self.root, {"name": "payments"}, PR_CTX, save)

        self.assertEqual(out["report_id"], "rid-123")
        self.assertEqual(out["files"], 2)          # gone.py skipped
        self.assertEqual(saved["title"], "PR #7 Threat Model · payments")
        self.assertEqual(saved["methodology"], "codemodel")
        # The staged tree only held changed files, so the model is PR-scoped.
        meta = saved.get("scan_metadata") or saved.get("meta") or {}
        flat = str(meta) + str(saved.get("analyses", ""))
        self.assertIn("pr-diff", str(saved))

    def test_hostile_path_never_escapes_staging(self):
        with mock.patch.object(pr_tm, "changed_files",
                               return_value=["../escape.py", "svc/handler.py"]):
            out = pr_tm.run(self.root, {"name": "r"}, PR_CTX, lambda r: "rid")
        self.assertEqual(out["files"], 1)          # traversal name dropped

    def test_run_posts_threat_model_comment_to_pr(self):
        from broker import github
        posted = {}

        def fake_report(repo, gh_ctx, report, rid, changed_files=0, log=None):
            posted.update(report_id=rid, files=changed_files, pr=gh_ctx.get("number"))

        with mock.patch.object(pr_tm, "changed_files", return_value=["svc/handler.py"]):
            with mock.patch.object(github, "report_tm_to_pr", side_effect=fake_report):
                out = pr_tm.run(self.root, {"name": "payments"}, PR_CTX,
                                lambda r: "rid-77")
        self.assertEqual(out["report_id"], "rid-77")
        self.assertEqual(posted, {"report_id": "rid-77", "files": 1, "pr": 7})

    def test_run_comment_failure_never_breaks_the_scan(self):
        from broker import github
        with mock.patch.object(pr_tm, "changed_files", return_value=["svc/handler.py"]):
            with mock.patch.object(github, "report_tm_to_pr",
                                   side_effect=RuntimeError("GitHub down")):
                out = pr_tm.run(self.root, {"name": "r"}, PR_CTX, lambda r: "rid-9")
        # The report is still saved and returned despite the comment failing.
        self.assertEqual(out["report_id"], "rid-9")


class TestChangedFiles(unittest.TestCase):
    def test_fetch_failure_is_nonfatal_and_diff_parsed(self):
        calls = []

        def fake_git(args, cwd=None):
            calls.append(args[0])
            if args[0] == "fetch":
                raise RuntimeError("no such remote")
            return "a.py\n\nsub/b.py\n"

        with mock.patch.object(pr_tm.scanner, "_run_git", side_effect=fake_git):
            files = pr_tm.changed_files(Path("."), "main")
        self.assertEqual(files, ["a.py", "sub/b.py"])
        self.assertEqual(calls, ["fetch", "diff"])

    def test_diff_is_tree_to_tree_not_merge_base(self):
        # The broker's depth-1 PR clone has no merge base, so the diff must be a
        # two-dot tree comparison of the fetched base tip against HEAD — never a
        # three-dot "base...HEAD" that would fail with "no merge base".
        seen = {}

        def fake_git(args, cwd=None):
            if args[0] == "fetch":
                # depth-1 fetch of the base branch into FETCH_HEAD
                self.assertIn("--depth", args)
                self.assertEqual(args[args.index("--depth") + 1], "1")
                self.assertEqual(args[-1], "main")
                return ""
            if args[0] == "diff":
                seen["diff_args"] = args
                return "svc/handler.py\n"
            return ""

        with mock.patch.object(pr_tm.scanner, "_run_git", side_effect=fake_git):
            files = pr_tm.changed_files(Path("."), "main")
        self.assertEqual(files, ["svc/handler.py"])
        da = seen["diff_args"]
        self.assertIn("FETCH_HEAD", da)
        self.assertIn("HEAD", da)
        self.assertTrue(all("..." not in a for a in da))   # no three-dot ref


class TestReportDbSastExclusion(unittest.TestCase):
    """Viewer-facing queries hide methodology='sast' unless opted in."""

    def setUp(self):
        self._orig_path = report_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        cat = {"id": "R1", "name": "SQL Injection", "title": "SQL Injection",
               "risk": "High", "cwe": "CWE-89", "owasp": "",
               "threats": [{"name": "db.py:10"}],
               "affected_components": ["db.py:10"]}
        for rid, meth in (("1_1_aa", "sast"), ("1_2_bb", "codemodel")):
            report_db.upsert_report({
                "id": rid, "title": rid, "methodology": meth,
                "overall_risk": "High",
                "analyzed_at": "2026-07-18T00:00:00Z", "categories": [cat]})

    def _restore(self):
        report_db.DB_PATH = self._orig_path

    def test_list_reports_hides_sast_by_default(self):
        meths = {r["methodology"] for r in report_db.list_reports()}
        self.assertEqual(meths, {"codemodel"})
        meths = {r["methodology"] for r in report_db.list_reports(include_sast=True)}
        self.assertEqual(meths, {"sast", "codemodel"})

    def test_trends_hide_sast_by_default(self):
        self.assertEqual({r["methodology"] for r in report_db.trends()},
                         {"codemodel"})

    def test_search_hides_sast_by_default(self):
        rows = report_db.search_findings(family="sql-injection")
        self.assertEqual({r["methodology"] for r in rows}, {"codemodel"})
        rows = report_db.search_findings(family="sql-injection", include_sast=True)
        self.assertEqual({r["methodology"] for r in rows}, {"sast", "codemodel"})

    def test_family_summary_hides_sast_by_default(self):
        total = sum(r["total"] for r in report_db.family_summary())
        total_all = sum(r["total"] for r in report_db.family_summary(include_sast=True))
        self.assertEqual(total, 1)
        self.assertEqual(total_all, 2)


if __name__ == "__main__":
    unittest.main()
