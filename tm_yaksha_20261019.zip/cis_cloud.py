"""cis_cloud.py -- CIS Cloud Foundations Benchmark domain definitions."""
from __future__ import annotations

CIS_CLOUD_DOMAINS: dict[str, dict] = {
    "D01": {
        "id": "CIS-D01",
        "name": "Identity and Access Management",
        "description": (
            "Controls governing IAM users, roles, MFA enforcement, password policy, "
            "access key rotation, and least-privilege role configuration."
        ),
        "key_controls": [
            "Avoid use of root account; ensure root has MFA enabled",
            "Ensure MFA is enabled for all IAM users with console access",
            "Ensure access keys are rotated every 90 days or less",
            "Ensure IAM policies are attached only to groups or roles, not users",
            "Ensure no IAM policies allow full '*:*' administrative privileges",
            "Use IAM Access Analyzer to identify external access to resources",
        ],
        "cis_level": "Level 1 & 2",
    },
    "D02": {
        "id": "CIS-D02",
        "name": "Logging and Monitoring",
        "description": (
            "Controls ensuring audit trails, log integrity, and alerting are in place "
            "across all cloud accounts and regions."
        ),
        "key_controls": [
            "Ensure CloudTrail is enabled and logging to all regions",
            "Ensure CloudTrail log file validation is enabled",
            "Ensure CloudTrail logs are encrypted using KMS CMK",
            "Ensure CloudTrail S3 bucket is not publicly accessible",
            "Ensure AWS Config is enabled in all regions",
            "Ensure a log metric filter and alarm exist for management console auth failures",
            "Ensure a log metric filter and alarm exist for root account usage",
            "Ensure a log metric filter and alarm exist for IAM policy changes",
        ],
        "cis_level": "Level 1 & 2",
    },
    "D03": {
        "id": "CIS-D03",
        "name": "Network Configuration",
        "description": (
            "Controls for VPC design, security groups, NACLs, peering, and preventing "
            "unrestricted network access to sensitive services."
        ),
        "key_controls": [
            "Ensure no security groups allow 0.0.0.0/0 to port 22 (SSH)",
            "Ensure no security groups allow 0.0.0.0/0 to port 3389 (RDP)",
            "Ensure VPC default security group restricts all traffic",
            "Ensure VPC Flow Logs are enabled for all VPCs",
            "Ensure routing tables for VPC peering are minimally permissive",
            "Ensure no default VPCs are used in production environments",
        ],
        "cis_level": "Level 1 & 2",
    },
    "D04": {
        "id": "CIS-D04",
        "name": "Storage Security",
        "description": (
            "Controls covering S3 bucket security, encryption, access logging, "
            "versioning, and public access prevention."
        ),
        "key_controls": [
            "Ensure S3 Block Public Access is enabled at account and bucket level",
            "Ensure all S3 buckets employ server-side encryption (SSE-S3 or SSE-KMS)",
            "Ensure S3 bucket versioning is enabled for critical data buckets",
            "Ensure S3 bucket access logging is enabled",
            "Ensure S3 buckets with sensitive data have MFA Delete enabled",
            "Ensure S3 lifecycle configuration is set to expire objects per retention policy",
        ],
        "cis_level": "Level 1 & 2",
    },
    "D05": {
        "id": "CIS-D05",
        "name": "Database Security",
        "description": (
            "Controls for RDS, Aurora, DynamoDB, and other managed databases covering "
            "encryption, public accessibility, backup, and access control."
        ),
        "key_controls": [
            "Ensure RDS instances are not publicly accessible",
            "Ensure RDS instances have encryption at rest enabled",
            "Ensure automated backups are enabled for all RDS instances (7+ day retention)",
            "Ensure RDS DB snapshots are not publicly accessible",
            "Ensure Multi-AZ is enabled for Tier-1 RDS instances",
            "Ensure RDS deletion protection is enabled on production instances",
        ],
        "cis_level": "Level 1 & 2",
    },
    "D06": {
        "id": "CIS-D06",
        "name": "Compute and VM Security",
        "description": (
            "Controls for EC2 instances, ECS/EKS workloads, and serverless functions "
            "covering IMDSv2, patch management, and hardened AMIs."
        ),
        "key_controls": [
            "Ensure EC2 instances require IMDSv2 (disable IMDSv1)",
            "Ensure EC2 instances do not have public IPs unless explicitly required",
            "Ensure all EC2 instances use approved and patched AMIs",
            "Ensure EBS volumes are encrypted by default",
            "Ensure EC2 instances are managed via Systems Manager (no direct SSH)",
            "Ensure no EC2 key pairs are in use for production (use SSM Session Manager)",
        ],
        "cis_level": "Level 1 & 2",
    },
    "D07": {
        "id": "CIS-D07",
        "name": "Key Management and Cryptography",
        "description": (
            "Controls ensuring AWS KMS CMKs are properly configured, rotated, "
            "and used for encryption of sensitive services."
        ),
        "key_controls": [
            "Ensure rotation is enabled for customer-managed KMS keys",
            "Ensure KMS key policies do not allow public access (Principal: '*')",
            "Ensure CloudTrail, SNS topics, and SQS queues are encrypted with CMK",
            "Ensure all custom KMS keys have defined key administrators and key users",
            "Ensure ACM certificates are renewed before expiry (90-day monitoring)",
        ],
        "cis_level": "Level 2",
    },
    "D08": {
        "id": "CIS-D08",
        "name": "Container and Serverless Security",
        "description": (
            "Controls for container image hygiene, ECR scanning, EKS hardening, "
            "Lambda function security, and workload isolation."
        ),
        "key_controls": [
            "Ensure ECR image scanning is enabled on push",
            "Ensure ECR repositories are not publicly accessible",
            "Ensure EKS control plane logging is enabled for all log types",
            "Ensure Lambda functions do not have deprecated runtimes",
            "Ensure Lambda execution roles follow least-privilege",
            "Ensure Kubernetes RBAC does not grant cluster-admin to default service accounts",
        ],
        "cis_level": "Level 1 & 2",
    },
}
