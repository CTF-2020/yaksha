"""Tests for the ReDoS static auditor.

Run:  python -m unittest test_redos_audit

Checks the three catastrophic shapes are flagged, common safe patterns are not
(false-alarm control), and the bounded_search input cap holds.
"""
from __future__ import annotations

import re
import unittest

import redos_audit as ra


class TestDangerous(unittest.TestCase):
    def test_nested_quantifier(self):
        for evil in [r"(a+)+", r"(a*)*", r"(\d+)*$", r"([a-z]+)*", r"(.*)+"]:
            with self.subTest(evil=evil):
                kinds = {f["kind"] for f in ra.audit_pattern(evil)}
                self.assertIn("nested-quantifier", kinds)

    def test_quantified_overlapping_alternation(self):
        for evil in [r"(a|ab)+", r"(a|a)*", r"(x|xy)+"]:
            with self.subTest(evil=evil):
                kinds = {f["kind"] for f in ra.audit_pattern(evil)}
                self.assertIn("quantified-overlapping-alternation", kinds)

    def test_adjacent_unbounded(self):
        for evil in [r".*.*", r"\s*\s*", r".+.+"]:
            with self.subTest(evil=evil):
                kinds = {f["kind"] for f in ra.audit_pattern(evil)}
                self.assertIn("adjacent-unbounded-quantifiers", kinds)


class TestSafe(unittest.TestCase):
    def test_common_safe_patterns_not_flagged(self):
        safe = [
            r"^\d{4}-\d{2}-\d{2}$",
            r"CWE-(\d+)",
            r"[a-z0-9]+",
            r"https?://[^\s]+",
            r"^(GET|POST|PUT|DELETE)$",     # alternation, no quantifier on the group
            r"\bword\b",
            r"(?:abc)+",                     # quantified group, but no inner quantifier
        ]
        for p in safe:
            with self.subTest(p=p):
                self.assertEqual(ra.audit_pattern(p), [], f"false alarm on {p!r}")


class TestSourceScan(unittest.TestCase):
    def test_audit_source_file(self, ):
        import tempfile, os
        src = 'import re\nA = re.compile(r"(a+)+")\nB = re.compile(r"[a-z]+")\n'
        d = tempfile.mkdtemp(prefix="redos_")
        p = os.path.join(d, "m.py")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(src)
        findings = ra.audit_source_file(p)
        self.assertTrue(any(f["kind"] == "nested-quantifier" for f in findings))
        self.assertTrue(all(f["line"] == 2 for f in findings))   # only the evil one, line 2


class TestBoundedSearch(unittest.TestCase):
    def test_caps_input_length(self):
        pat = re.compile(r"needle")
        self.assertIsNotNone(ra.bounded_search(pat, "x" * 10 + "needle", max_len=1_000_000))
        # oversized input is truncated before the needle -> no match, but no hang
        big = "x" * 50 + "needle"
        self.assertIsNone(ra.bounded_search(pat, big, max_len=10))

    def test_none_is_safe(self):
        self.assertIsNone(ra.bounded_search(re.compile("a"), None))


if __name__ == "__main__":
    unittest.main(verbosity=2)
