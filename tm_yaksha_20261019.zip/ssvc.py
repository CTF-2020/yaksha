"""ssvc.py — Stakeholder-Specific Vulnerability Categorization triage action
for a correlated finding.

The correlator's ``priority`` field (correlator/model.py) is a single sort
key: severity + verdict-bump + confidence + exploitability + business_impact
+ epss_kev, summed. That answers "what order should I work through the
queue" but not "what am I actually supposed to DO about this one" — a
numeric rank doesn't distinguish "drop everything" from "put it on the
backlog", it only orders them. SSVC (CISA's Stakeholder-Specific
Vulnerability Categorization, https://www.cisa.gov/ssvc) is built exactly
for that second question: a small decision tree over a handful of
qualitative points that outputs one of a few concrete actions.

This module is a practical ADAPTATION of SSVC's Deployer-tree structure
(exploitation x exposure x automatable x human-impact -> action), not a
reproduction of CISA's published decision table — that table runs to dozens
of rows per point combination and is calibrated by CISA's own analysts;
reconstructing it from memory risks silently fabricating guidance that only
looks authoritative. What's reused here is SSVC's shape (the same four
decision points, the same four actions) with a monotonic decision function
of my own, documented in ``_action`` below, sized to what a correlated
finding here can actually evidence:

  * exploitation  — from the correlator's own verdict (an ACTIVELY_EXPLOITED
    finding already IS "active" exploitation, from a real incident) and the
    epss_kev score (correlator/engine.py:_epss_kev floors it at 0.9 for a
    CISA KEV hit, so a high value here already means "confirmed exploited
    somewhere in the wild", not just "high verdict").
  * exposure      — from the exploitability score (correlator/engine.py:
    _exploitability), which is itself built from code-model reachability
    facts (unauthenticated caller, tainted input, hop distance).
  * automatable    — near-max exploitability (unauthenticated AND tainted AND
    at/near the entry point — no human tailoring needed to reach and trigger
    it) or a CISA KEV entry flagged for known ransomware use (real-world
    evidence exploitation was automated/repeatable at scale).
  * human_impact  — from severity plus the business-impact tier (asset/route
    criticality; codemodel/business_impact.py).

Every decision point defaults to its least-alarming value when the evidence
behind it is simply absent (an unscored/uncorrelated finding), matching the
"unknown, not fabricated" convention every other correlator signal already
follows — this never invents urgency the input didn't earn.
"""
from __future__ import annotations

from dataclasses import dataclass

ACT, ATTEND, TRACK_STAR, TRACK = "act", "attend", "track_star", "track"
_ACTIONS = (ACT, ATTEND, TRACK_STAR, TRACK)
_ACTION_LABEL = {
    ACT: "Act",
    ATTEND: "Attend",
    TRACK_STAR: "Track*",
    TRACK: "Track",
}
_ACTION_GUIDANCE = {
    ACT: "Remediate immediately — mobilize whatever response the organization "
         "uses for its most urgent security work.",
    ATTEND: "Prioritize for the next remediation cycle and give it security-team "
            "attention now, even if it doesn't warrant an emergency response.",
    TRACK_STAR: "Track with closer monitoring than a routine backlog item — "
                "revisit if exposure, exploitation, or impact evidence changes.",
    TRACK: "Track in the normal remediation backlog; no urgent action indicated "
           "by current evidence.",
}
# Sort key for a triage queue: worst (most urgent) action first.
ACTION_RANK = {ACT: 0, ATTEND: 1, TRACK_STAR: 2, TRACK: 3, "": 9}

_EXPLOITATION_RANK = {"active": 0, "poc": 1, "none": 2}
_EXPOSURE_RANK = {"open": 0, "controlled": 1, "small": 2}
_HUMAN_IMPACT_RANK = {"very_high": 0, "high": 1, "medium": 2, "low": 3}


@dataclass
class SSVCResult:
    exploitation: str          # active | poc | none
    exposure: str              # open | controlled | small
    automatable: bool
    human_impact: str          # very_high | high | medium | low
    action: str                # act | attend | track_star | track
    reason: str

    @property
    def action_label(self) -> str:
        return _ACTION_LABEL[self.action]


def _exploitation(verdict: str, epss_kev: float) -> str:
    if verdict == "actively_exploited" or epss_kev >= 0.85:
        return "active"
    if verdict == "confirmed_exploitable" or epss_kev >= 0.3:
        return "poc"
    return "none"


def _exposure(exploitability: float) -> str:
    # >=0.65 is only reachable when the code model proved at least an
    # unauthenticated caller (see engine._exploitability's 0.35 base + 0.30
    # unauthenticated bump); >0 but below that means some reachability
    # evidence exists (e.g. authenticated-only) without proving open access.
    if exploitability >= 0.65:
        return "open"
    if exploitability > 0.0:
        return "controlled"
    # No code-model coverage at all -- unknown, not "safe". Defaults to the
    # middle tier rather than "small" so an unscored finding never reads as
    # provably low-exposure; see module docstring.
    return "controlled"


def _automatable(exploitability: float, epss_kev_reason: str) -> bool:
    # Near-max exploitability only occurs when unauthenticated AND tainted
    # AND at/near the entry point all held (see engine._exploitability) --
    # no human tailoring needed to reach and trigger the sink.
    if exploitability >= 0.85:
        return True
    # This module only ever sees a reason string this app generated itself
    # (engine._epss_kev's fixed template — see its docstring), not arbitrary
    # external text, so a substring check here is a safe, simple way to read
    # back a fact (known ransomware use) that isn't otherwise surfaced as its
    # own field on CorrelatedFinding.
    return "ransomware" in (epss_kev_reason or "").lower()


def _human_impact(severity: str, business_impact: float) -> str:
    if severity == "Critical" and business_impact >= 0.7:
        return "very_high"
    if severity == "Critical" or (severity == "High" and business_impact >= 0.4):
        return "high"
    if severity == "High" or business_impact >= 0.4 or \
            (severity == "Medium" and business_impact >= 0.15):
        return "medium"
    return "low"


def _action(exploitation: str, exposure: str, automatable: bool, human_impact: str) -> str:
    if exploitation == "active":
        if human_impact in ("high", "very_high") or automatable or exposure == "open":
            return ACT
        return ATTEND
    if exploitation == "poc":
        if automatable and exposure == "open":
            return ACT
        if human_impact in ("high", "very_high") or exposure == "open":
            return ATTEND
        if human_impact == "medium" or exposure == "controlled":
            return TRACK_STAR
        return TRACK
    # exploitation == "none"
    if human_impact == "very_high" and exposure == "open":
        return ATTEND
    if human_impact in ("high", "very_high") or (automatable and exposure == "open"):
        return TRACK_STAR
    return TRACK


_EXPLOITATION_TEXT = {
    "active": "the underlying weakness is being actively exploited",
    "poc": "a working exploit/reachability proof exists but no confirmed real-world exploitation",
    "none": "no exploitation evidence (in the wild or proof-of-concept)",
}
_EXPOSURE_TEXT = {
    "open": "reachable from an unauthenticated entry point",
    "controlled": "reachability is limited or unproven",
    "small": "exposure is minimal",
}


def decide(*, severity: str, verdict: str, exploitability: float = 0.0,
          business_impact: float = 0.0, epss_kev: float = 0.0,
          epss_kev_reason: str = "") -> SSVCResult:
    """Derive the four SSVC decision points and the resulting action from a
    correlated finding's already-computed signals. Pure function — takes
    plain values (not a CorrelatedFinding) so it has no dependency on the
    correlator package and stays independently testable.
    """
    exploitation = _exploitation(verdict, epss_kev)
    exposure = _exposure(exploitability)
    automatable = _automatable(exploitability, epss_kev_reason)
    human_impact = _human_impact(severity, business_impact)
    action = _action(exploitation, exposure, automatable, human_impact)

    bits = [_EXPLOITATION_TEXT[exploitation], _EXPOSURE_TEXT[exposure]]
    if automatable:
        bits.append("exploitable without attacker customization (automatable)")
    bits.append(f"{human_impact.replace('_', ' ')} impact if exploited")
    reason = f"{_ACTION_GUIDANCE[action]} ({'; '.join(bits)}.)"

    return SSVCResult(exploitation=exploitation, exposure=exposure,
                      automatable=automatable, human_impact=human_impact,
                      action=action, reason=reason)
