"""Directory-level orchestration: walk a repo, extract per-file facts, and join
them into one :class:`SystemModel`.

The join is where cross-file intelligence happens:
  * a **call graph** over function names resolves which sensitive sinks are
    *reachable from* each entry point (a handler that calls a helper that runs a
    shell command is a command-injection entry point);
  * **Django URL patterns** are linked to their view functions so a route in
    ``urls.py`` inherits the controls declared on the view elsewhere;
  * **global controls** (before_request auth, CSRF/headers middleware) are
    applied to every HTTP entry point;
  * **trust boundaries** are inferred from the stores, external calls and
    privilege-crossing sinks that were found.
"""
from __future__ import annotations

import os

from . import business_impact
from . import config_extractor, polyglot_extractor as poly, python_extractor as px
from . import terraform_extractor as tf
from . import signatures as sig
from .model import (
    Control,
    EntryPoint,
    SystemModel,
    TrustBoundary,
)

# extension -> polyglot language id (Python has its own AST path)
_POLY_EXTS = {
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".go": "go",
    ".java": "java",
}
# generated/vendored/test file name patterns never worth modeling
_POLY_NAME_SKIP = (".min.js", ".d.ts", "_test.go", ".test.js", ".test.ts",
                   ".spec.js", ".spec.ts", ".bundle.js")

# Directories that are never application code.
_SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "__pycache__", "dist",
              "build", ".tox", ".mypy_cache", ".pytest_cache", "site-packages",
              "vendor", "migrations", ".idea", ".vscode", "tests", "test"}
_MAX_FILES = 4000
_MAX_FILE_BYTES = 1_500_000
_MAX_REACH_DEPTH = 2


def _iter_files(root: str):
    count = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d.lower() not in _SKIP_DIRS
                       and not d.startswith(".")]
        for name in filenames:
            yield os.path.join(dirpath, name)
            count += 1
            if count >= _MAX_FILES:
                return


def _rel(root: str, path: str) -> str:
    return os.path.relpath(path, root).replace("\\", "/")


def build_model(root: str) -> SystemModel:
    """Extract a SystemModel from every source/config file under ``root``."""
    model = SystemModel(root=root)
    py_facts: list[px.FileFacts] = []
    poly_facts: dict[str, list] = {}     # language -> [FileFacts]

    for path in _iter_files(root):
        rel = _rel(root, path)
        lower = path.lower()
        try:
            if os.path.getsize(path) > _MAX_FILE_BYTES:
                continue
        except OSError:
            continue

        ext = os.path.splitext(lower)[1]
        if ext in _POLY_EXTS and not lower.endswith(_POLY_NAME_SKIP):
            lang = _POLY_EXTS[ext]
            src = _safe_read(path)
            if src is None:
                model.parse_errors.append(f"{rel}: unreadable")
                continue
            model.languages.add(lang)
            poly_facts.setdefault(lang, []).append(
                poly.analyze_source(src, rel, lang))
            model.files_scanned += 1
            continue

        if lower.endswith(".py"):
            model.languages.add("python")
            facts = _safe_read(path)
            if facts is None:
                model.parse_errors.append(f"{rel}: unreadable")
                continue
            ff = px.analyze_python_source(facts, rel)
            if getattr(ff, "parse_error", ""):
                model.parse_errors.append(ff.parse_error)
                continue
            py_facts.append(ff)
        elif lower.endswith(".tf"):
            model.languages.add("terraform")
            src = _safe_read(path)
            if src is not None:
                tf.extract(src, rel, model)
        elif config_extractor.is_config_file(lower):
            src = _safe_read(path)
            if src is not None:
                config_extractor.extract(src, rel, model)
        model.files_scanned += 1

    # Config-derived controls (headers/tls from yml, Dockerfile…) apply to every
    # language; code-derived globals are scoped to their own language batch so a
    # Go auth middleware never authenticates the Express routes of a mixed repo.
    config_controls = list(model.controls)
    _assemble_python(model, py_facts)
    for lang in sorted(poly_facts):
        _assemble_poly(model, poly_facts[lang], config_controls)
    _infer_trust_boundaries(model)
    return model


def _safe_read(path: str):
    # utf-8-sig strips a leading BOM (U+FEFF) if present — a bare "utf-8" read
    # keeps it, and ast.parse then fails with "invalid non-printable character",
    # silently dropping BOM-prefixed source files (common in Windows-authored
    # repos) from the whole threat model. It is a no-op on files without a BOM.
    try:
        with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


# ── python join ───────────────────────────────────────────────────────────────
def _assemble_python(model: SystemModel, files: list[px.FileFacts]):
    # global function map for the call graph (first definition wins on collision)
    fn_map: dict[str, px.FunctionInfo] = {}
    for ff in files:
        model.frameworks |= ff.frameworks
        model.external_calls.extend(ff.external_calls)
        model.data_stores.extend(ff.data_stores)
        model.secrets.extend(ff.secrets)
        model.controls.extend(ff.global_controls)
        for name, fn in ff.functions.items():
            fn.file = ff.rel_path
            fn_map.setdefault(name, fn)

    has_global_auth = any(c.kind == "auth" for c in model.controls)
    global_ep_controls = [c for c in model.controls
                          if c.kind in ("csrf", "headers", "rate-limit", "tls")]

    # entry points from route handlers + LLM/agent-invokable tool functions
    for ff in files:
        for name, fn in ff.functions.items():
            if fn.is_route:
                model.entry_points.append(_entrypoint_from_fn(
                    fn, ff.rel_path, fn_map, has_global_auth, global_ep_controls))
            elif fn.is_agent_tool:
                model.entry_points.append(_agent_tool_entrypoint(fn, ff.rel_path, fn_map))

    # entry points from Django urlpatterns, inheriting the view's controls
    for ff in files:
        for u in ff.django_urls:
            view_fn = fn_map.get(u["view"])
            controls = list(view_fn.controls) if view_fn else []
            controls += ff.cbv_controls.get(u["view"], [])
            authed = bool([c for c in controls if c.kind == "auth"]) or has_global_auth
            ep = EntryPoint(
                method=u["method"], path=u["path"], handler=u["view"] or "(view)",
                file=ff.rel_path, line=u["line"], framework="django", kind="http",
                authenticated=authed, controls=controls + global_ep_controls)
            if view_fn:
                ep.reachable_sinks = _reachable_sinks(view_fn, fn_map)
                ep.reachable_deps = _reachable_deps(view_fn, fn_map)
                ep.reachable_impact = _reachable_impact(view_fn, fn_map)
            else:
                ep.reachable_impact = business_impact.nearest_match(
                    [(f"{ep.path} {ep.handler} {ep.file}", 0)])
            model.entry_points.append(ep)


def _assemble_poly(model: SystemModel, files: list, config_controls: list):
    """Join one language's polyglot FileFacts: same call-graph reachability as
    the Python path, with global controls scoped to this batch + config."""
    fn_map = {}
    batch_controls: list = []
    for ff in files:
        model.frameworks |= ff.frameworks
        model.external_calls.extend(ff.external_calls)
        model.data_stores.extend(ff.data_stores)
        model.secrets.extend(ff.secrets)
        batch_controls.extend(ff.global_controls)
        for name, fn in ff.functions.items():
            fn.file = ff.rel_path
            fn_map.setdefault(name, fn)
    model.controls.extend(batch_controls)

    scope = batch_controls + config_controls
    has_global_auth = any(c.kind == "auth" for c in scope)
    global_ep_controls = [c for c in scope
                          if c.kind in ("csrf", "headers", "rate-limit", "tls")]

    for ff in files:
        for name, fn in ff.functions.items():
            if fn.is_route:
                model.entry_points.append(_entrypoint_from_fn(
                    fn, ff.rel_path, fn_map, has_global_auth, global_ep_controls))
            elif fn.is_agent_tool:
                model.entry_points.append(_agent_tool_entrypoint(fn, ff.rel_path, fn_map))


def _entrypoint_from_fn(fn, rel, fn_map, has_global_auth, global_ep_controls) -> EntryPoint:
    ep_auth = [c for c in fn.controls if c.kind == "auth"]
    controls = list(fn.controls) + list(global_ep_controls)
    return EntryPoint(
        method=fn.route_method, path=fn.route_path, handler=fn.name,
        file=rel, line=fn.lineno, framework=fn.framework or "web", kind="http",
        authenticated=bool(ep_auth) or has_global_auth,
        controls=controls,
        reachable_sinks=_reachable_sinks(fn, fn_map),
        reachable_deps=_reachable_deps(fn, fn_map),
        reachable_impact=_reachable_impact(fn, fn_map),
    )


def _agent_tool_entrypoint(fn, rel, fn_map) -> EntryPoint:
    """An LLM/agent-invokable tool function, modeled as an entry point.

    Unlike an HTTP route, the "client" here is the LLM's tool-call decision —
    reachable via (indirect) prompt injection, not a network auth boundary.
    ``authenticated`` is always False: it isn't that the tool lacks a login
    check, it's that no *argument constraint* was observed, which the severity
    escalation in threats.py treats the same way (untrusted input reaching a
    sink unchecked).
    """
    return EntryPoint(
        method="TOOL", path=fn.tool_name or fn.name, handler=fn.name,
        file=rel, line=fn.lineno, framework="agent", kind="agent-tool",
        authenticated=False, controls=list(fn.controls),
        reachable_sinks=_reachable_sinks(fn, fn_map),
        reachable_deps=_reachable_deps(fn, fn_map),
        reachable_impact=_reachable_impact(fn, fn_map),
    )


def _bfs_facts(fn, fn_map: dict, get_facts) -> list:
    """Bounded BFS over the name-based call graph, collecting ``get_facts(f)``
    from ``fn`` and everything it transitively calls, each tagged with its hop
    distance (0 = in the handler body, 1 = one call away, …). Shared by sink
    and dependency-call reachability — same traversal, different fact list.
    """
    seen_fns = {fn.name}
    out = [(item, 0) for item in get_facts(fn)]

    frontier = [(callee, 1) for callee in fn.calls]
    while frontier:
        name, depth = frontier.pop()
        if name in seen_fns or depth > _MAX_REACH_DEPTH:
            continue
        seen_fns.add(name)
        target = fn_map.get(name)
        if not target:
            continue
        out.extend((item, depth) for item in get_facts(target))
        frontier.extend((c, depth + 1) for c in target.calls)
    return out


def _reachable_sinks(fn, fn_map: dict) -> list:
    """Sinks in the handler plus those in functions it transitively calls."""
    return [_clone_sink(s, hops) for s, hops in _bfs_facts(fn, fn_map, lambda f: f.sinks)]


def _reachable_deps(fn, fn_map: dict) -> list:
    """Third-party dependency calls in the handler plus those in functions it
    transitively calls (see DependencyUse)."""
    return [_clone_dep(d, hops) for d, hops in _bfs_facts(fn, fn_map, lambda f: f.dep_calls)]


def _impact_text(f) -> str:
    """Text a business-impact keyword can match against for one function:
    its route path / agent-tool name (when it is itself an entry point),
    its own name, and the file it lives in."""
    return " ".join(filter(None, [
        getattr(f, "route_path", ""), getattr(f, "tool_name", ""),
        f.name, getattr(f, "file", ""),
    ]))


def _reachable_impact(fn, fn_map: dict) -> dict | None:
    """Business-impact signal from walking the call graph: the nearest
    keyword-tier hit among this entry point's own name and everything it
    transitively calls (same bounded BFS as sinks/deps), scored down by hop
    distance. See business_impact.nearest_match for why this is a strict
    upgrade over matching the entry point's own name alone."""
    candidates = _bfs_facts(fn, fn_map, lambda f: [_impact_text(f)])
    return business_impact.nearest_match(candidates)


def _clone_sink(s, hops):
    from .model import Sink
    return Sink(kind=s.kind, family=s.family, cwe=s.cwe, name=s.name, file=s.file,
                line=s.line, hops=hops, tainted=s.tainted, confidence=s.confidence)


def _clone_dep(d, hops):
    from .model import DependencyUse
    return DependencyUse(root=d.root, name=d.name, file=d.file, line=d.line,
                         hops=hops, tainted=d.tainted)


# ── trust boundaries ──────────────────────────────────────────────────────────
def _infer_trust_boundaries(model: SystemModel):
    b = model.trust_boundaries
    if model.entry_points:
        b.append(TrustBoundary(
            "Client ↔ Application", "network",
            f"{len(model.entry_points)} externally-reachable entry point(s) accept "
            "untrusted input over the network."))
    if model.data_stores:
        engines = ", ".join(sorted({d.engine for d in model.data_stores}))
        b.append(TrustBoundary(
            "Application ↔ Data store", "persistence",
            f"Connects to data store(s): {engines}."))
    http_ext = [e for e in model.external_calls if e.kind == "http"]
    if http_ext:
        cleartext = sum(1 for e in http_ext if not e.encrypted)
        b.append(TrustBoundary(
            "Application ↔ External service", "external-service",
            f"{len(http_ext)} outbound HTTP call(s)"
            + (f", {cleartext} over cleartext HTTP." if cleartext else ".")))
    if any(e.kind == "queue" for e in model.external_calls):
        b.append(TrustBoundary(
            "Application ↔ Message broker", "external-service",
            "Publishes/consumes over a message queue (an implicit trust boundary "
            "if messages are not authenticated)."))
    if any(s.kind in ("command", "code-eval") for ep in model.entry_points
           for s in ep.reachable_sinks):
        b.append(TrustBoundary(
            "Application ↔ Operating system", "privilege",
            "Reachable code paths execute shell commands or evaluate code — a "
            "privilege boundary to the host."))
    ai_frameworks = model.frameworks & (sig.AGENT_FRAMEWORK_ROOTS | sig.LLM_PROVIDER_ROOTS)
    llm_calls = [e for e in model.external_calls if e.kind == "llm"]
    tool_eps = [e for e in model.entry_points if e.kind == "agent-tool"]
    if ai_frameworks or llm_calls or tool_eps:
        names = ", ".join(sorted(ai_frameworks)) or "LLM API"
        detail = f"Integrates with LLM/agent tooling ({names})"
        if tool_eps:
            detail += f"; {len(tool_eps)} tool function(s) are invokable by the LLM/agent runtime"
        b.append(TrustBoundary(
            "Application ↔ LLM provider", "external-service",
            detail + ". Prompt content and tool-call arguments cross into a "
            "third-party model provider, and model output is treated as "
            "trusted unless explicitly validated (OWASP LLM01/LLM02/LLM06)."))
