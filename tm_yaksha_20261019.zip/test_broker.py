"""Tests for the SAST broker service.

Run:  python -m unittest test_broker
Covers the pure mapper/scanner-URL logic, a real scan-engine invocation against
a vulnerable fixture, and the full Flask surface (register repo -> scan -> poll
-> report saved and viewable). The scan-engine tests skip cleanly if the engine
is not present on this host.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from broker import config, github, mapper
from broker.scanner import looks_like_git_url, run_scan, ScanError

ENGINE_AVAILABLE = config.SCANNER_PATH.exists()

VULN_SRC = (
    "import os\n"
    "from flask import request\n"
    "def handler():\n"
    "    os.system('ls ' + request.args.get('dir'))  # command injection\n"
)


def _make_vuln_repo() -> str:
    d = tempfile.mkdtemp(prefix="broker_fixture_")
    Path(d, "app.py").write_text(VULN_SRC, encoding="utf-8")
    return d


class TestUrlClassification(unittest.TestCase):
    def test_git_urls(self):
        for u in ("https://git.internal/x.git", "git@github.com:org/repo.git",
                  "ssh://git@host/repo", "file:///srv/repo"):
            self.assertTrue(looks_like_git_url(u), u)

    def test_local_paths(self):
        for p in ("D:\\src\\app", "/home/user/app", "./relative", "C:/code/x"):
            self.assertFalse(looks_like_git_url(p), p)


class TestMapper(unittest.TestCase):
    def _findings(self):
        return [
            {"id": "SAR-APPSEC-011", "title": "OS command injection",
             "domain": "Application Security", "severity": "Critical",
             "stride": ["T", "E", "I"], "owasp": "A03:2021 Injection",
             "iso27001": "A.8.28", "cwe": "CWE-78", "remediation": "Use argv APIs.",
             "file": "app.py", "line": 5, "snippet": "os.system('ls ' + target)"},
            {"id": "SAR-LOG-001", "title": "Sensitive data in logs",
             "domain": "Logging", "severity": "Medium", "stride": ["I"],
             "owasp": "A09", "iso27001": "A.8.15", "cwe": "CWE-532",
             "remediation": "Redact secrets.", "file": "b.py", "line": 9,
             "snippet": "log.info(password)"},
        ]

    def test_report_shape(self):
        repo = {"id": "demo", "name": "demo-svc"}
        rep = mapper.findings_to_report(self._findings(), repo, {"commit": "abc1234"}, "Low")
        self.assertEqual(rep["overall_risk"], "Critical")  # worst severity wins
        self.assertEqual(rep["methodology"], "sast")
        self.assertEqual(len(rep["categories"]), 2)        # one card per rule
        # Critical card sorts first.
        self.assertEqual(rep["categories"][0]["id"], "SAR-APPSEC-011")
        cat = rep["categories"][0]
        self.assertEqual(cat["risk"], "Critical")
        self.assertIn("app.py:5", cat["affected_components"])
        self.assertTrue(cat["threats"])              # per-location threat tickets
        self.assertTrue(cat["mitigations"][0]["action"])
        self.assertEqual(rep["scan_metadata"]["findings_total"], 2)
        self.assertEqual(rep["scan_metadata"]["commit"], "abc1234")

    def test_empty_findings(self):
        rep = mapper.findings_to_report([], {"id": "x", "name": "x"}, {}, "Low")
        self.assertEqual(rep["overall_risk"], "Info")
        self.assertEqual(rep["categories"], [])

    def test_threat_carries_vulnerable_code_context(self):
        findings = [{
            "id": "SAR-DATA-001", "title": "Hardcoded credential", "domain": "Data",
            "severity": "Critical", "owasp": "A07", "cwe": "CWE-798",
            "remediation": "vault", "file": "app.py", "line": 5,
            "snippet": 'api_key="x"',
            "code_context": "    3 | import os\n    4 | # cfg\n→     5 | api_key=\"x\"",
        }]
        rep = mapper.findings_to_report(findings, {"id": "d", "name": "d"}, {}, "Low")
        threat = rep["categories"][0]["threats"][0]
        self.assertEqual(threat["name"], "app.py:5")
        self.assertEqual(threat["line"], 5)
        self.assertIn("api_key", threat["code_context"])
        self.assertIn("→", threat["code_context"])  # flagged-line marker


class TestCodeContext(unittest.TestCase):
    def _repo(self):
        d = tempfile.mkdtemp(prefix="ctx_fixture_")
        Path(d, "app.py").write_text(
            "import os\n"          # 1
            "SECRET = 'a'\n"       # 2
            "API_KEY = 'live'\n"   # 3  <- flagged
            "def go():\n"          # 4
            "    return 1\n",      # 5
            encoding="utf-8")
        return d

    def test_attaches_numbered_context_around_hit(self):
        from broker import scanner
        d = self._repo()
        findings = [{"id": "R1", "file": "app.py", "line": 3, "snippet": "API_KEY"}]
        scanner._attach_code_context(Path(d), findings)
        ctx = findings[0]["code_context"]
        self.assertIn("API_KEY = 'live'", ctx)
        self.assertIn("SECRET = 'a'", ctx)       # a line above
        self.assertIn("def go():", ctx)          # a line below
        # The flagged line 3 carries the arrow marker; a neighbour does not.
        arrowed = [ln for ln in ctx.splitlines() if ln.startswith("→")]
        self.assertEqual(len(arrowed), 1)
        self.assertIn("3 |", arrowed[0])

    def test_rejects_path_escape(self):
        from broker import scanner
        d = self._repo()
        findings = [{"id": "R", "file": "../../../etc/passwd", "line": 1,
                     "snippet": "x"}]
        scanner._attach_code_context(Path(d), findings)
        self.assertNotIn("code_context", findings[0])

    def test_missing_line_or_file_is_skipped(self):
        from broker import scanner
        d = self._repo()
        findings = [
            {"id": "R", "file": "app.py", "snippet": "x"},          # no line
            {"id": "R", "line": 3, "snippet": "x"},                  # no file
            {"id": "R", "file": "nope.py", "line": 2, "snippet": "x"},  # missing file
        ]
        scanner._attach_code_context(Path(d), findings)
        for f in findings:
            self.assertNotIn("code_context", f)


class TestGitHubModule(unittest.TestCase):
    SECRET = "s3cr3t-webhook"

    def _sig(self, body: bytes, secret=None) -> str:
        import hashlib
        import hmac
        mac = hmac.new((secret or self.SECRET).encode(), body, hashlib.sha256)
        return "sha256=" + mac.hexdigest()

    def test_signature_roundtrip(self):
        body = b'{"zen":"ok"}'
        self.assertTrue(github.verify_signature(self.SECRET, body, self._sig(body)))
        # Wrong secret, tampered body, and malformed header all fail.
        self.assertFalse(github.verify_signature("nope", body, self._sig(body)))
        self.assertFalse(github.verify_signature(self.SECRET, b'{"zen":"x"}', self._sig(body)))
        self.assertFalse(github.verify_signature(self.SECRET, body, "deadbeef"))
        self.assertFalse(github.verify_signature("", body, self._sig(body)))

    def test_full_name_from_url(self):
        for u in ("https://github.com/Org/Repo.git", "git@github.com:Org/Repo.git",
                  "https://github.com/Org/Repo", "ssh://git@github.com/Org/Repo.git"):
            self.assertEqual(config.github_full_name_from_url(u), "org/repo", u)
        self.assertIsNone(config.github_full_name_from_url("https://git.internal/x.git"))

    def test_parse_push(self):
        p = github.parse_webhook("push", {
            "ref": "refs/heads/main", "after": "a" * 40,
            "repository": {"full_name": "org/repo"}})
        self.assertEqual(p["kind"], "push")
        self.assertEqual(p["branch"], "main")
        self.assertEqual(p["sha"], "a" * 40)
        # Branch deletion / tag pushes are ignored.
        self.assertEqual(github.parse_webhook("push", {
            "ref": "refs/heads/main", "after": "0" * 40, "deleted": True,
            "repository": {"full_name": "org/repo"}})["kind"], "ignored")
        self.assertEqual(github.parse_webhook("push", {
            "ref": "refs/tags/v1", "after": "a" * 40,
            "repository": {"full_name": "org/repo"}})["kind"], "ignored")

    def test_parse_pull_request(self):
        p = github.parse_webhook("pull_request", {
            "action": "synchronize", "number": 7,
            "pull_request": {"head": {"sha": "b" * 40}},
            "repository": {"full_name": "org/repo"}})
        self.assertEqual(p["kind"], "pull_request")
        self.assertEqual(p["ref"], "refs/pull/7/head")
        self.assertEqual(p["number"], 7)
        self.assertTrue(github.is_valid_ref(p["ref"]))
        # Irrelevant actions (e.g. labeled) are ignored.
        self.assertEqual(github.parse_webhook("pull_request", {
            "action": "labeled", "number": 7,
            "pull_request": {"head": {"sha": "b" * 40}},
            "repository": {"full_name": "org/repo"}})["kind"], "ignored")

    def test_unsafe_ref_rejected(self):
        self.assertFalse(github.is_valid_ref("--upload-pack=evil"))
        self.assertFalse(github.is_valid_ref("ref with space"))
        self.assertTrue(github.is_valid_ref("refs/pull/12/head"))

    def test_pull_request_bad_number_ignored_not_crash(self):
        # This route parses before the signature is verified, so a hostile
        # unauthenticated payload must degrade to "ignored", never raise.
        for bad in ("not-an-int", None, 0, -3, "0", 1.5e999):
            p = github.parse_webhook("pull_request", {
                "action": "opened", "number": bad,
                "pull_request": {"head": {"sha": "b" * 40}},
                "repository": {"full_name": "org/repo"}})
            self.assertEqual(p["kind"], "ignored", f"number={bad!r}")
        # A numeric string is still accepted and normalised to an int.
        p = github.parse_webhook("pull_request", {
            "action": "opened", "number": "42",
            "pull_request": {"head": {"sha": "b" * 40}},
            "repository": {"full_name": "org/repo"}})
        self.assertEqual(p["kind"], "pull_request")
        self.assertEqual(p["number"], 42)
        self.assertEqual(p["ref"], "refs/pull/42/head")

    def test_git_output_redaction(self):
        from broker import scanner
        self.assertEqual(
            scanner._redact(
                "fatal: unable to access "
                "'https://x-access-token:SEKRET@github.com/o/r.git/'"),
            "fatal: unable to access 'https://***@github.com/o/r.git/'")
        # Nothing to redact -> unchanged.
        self.assertEqual(scanner._redact("Could not resolve host: x"),
                         "Could not resolve host: x")

    def test_authed_clone_url(self):
        u = github.authed_clone_url("https://github.com/org/repo.git", "TOK")
        self.assertIn("x-access-token:TOK@github.com", u)
        # ssh / local untouched, empty token untouched.
        self.assertEqual(github.authed_clone_url("git@github.com:org/repo.git", "TOK"),
                         "git@github.com:org/repo.git")
        self.assertEqual(github.authed_clone_url("https://github.com/org/repo.git", ""),
                         "https://github.com/org/repo.git")

    def test_gate_and_comment(self):
        findings = [{"id": "R1", "title": "SQLi", "severity": "High",
                     "file": "a.py", "line": 1, "snippet": "q"}]
        rep = mapper.findings_to_report(findings, {"id": "x", "name": "x"}, {}, "Low")
        self.assertFalse(github.gate_passes(rep, "High"))   # High present -> fail
        self.assertTrue(github.gate_passes(rep, "Critical"))  # only Crit fails
        body = github.build_comment(rep, "https://tm/#report=1", False, "High", "abc1234567")
        self.assertIn("yaksha-guard-sast", body)            # upsert marker
        self.assertIn("Failed", body)
        self.assertIn("SQLi", body)

    def test_tm_comment_uses_distinct_marker(self):
        report = {"title": "PR #7 Threat Model", "categories": [
            {"risk": "High", "title": "SQL Injection", "threats": [{"name": "a"}]},
            {"risk": "Medium", "title": "SSRF", "threats": []}]}
        body = github.build_tm_comment(report, "https://tm/#report=9", changed_files=3)
        # Its own marker, NOT the SAST one — so the two comments never clobber.
        self.assertIn("yaksha-guard-threat-model", body)
        self.assertNotIn("yaksha-guard-sast", body)
        self.assertIn("Threat Model", body)
        self.assertIn("SQL Injection", body)
        self.assertIn("3", body)                            # changed-file count

    def test_tm_comment_empty_is_graceful(self):
        body = github.build_tm_comment({"categories": []}, "", changed_files=1)
        self.assertIn("No design-level threats", body)
        self.assertIn("yaksha-guard-threat-model", body)

    def test_report_tm_to_pr_upserts_with_marker(self):
        calls = {}

        class FakeClient:
            def __init__(self, token, api_base=None): calls["token"] = token
            def upsert_pr_comment(self, fn, num, body, marker=None):
                calls["comment"] = (fn, num, marker); return {}

        with mock.patch.object(github, "GitHubClient", FakeClient):
            github.report_tm_to_pr(
                {"github_token": "tok"},
                {"kind": "pull_request", "number": 7, "full_name": "acme/x"},
                {"categories": [{"risk": "High", "title": "T", "threats": []}]},
                "rid-1", changed_files=2)
        self.assertEqual(calls["comment"][0], "acme/x")
        self.assertEqual(calls["comment"][1], 7)
        self.assertEqual(calls["comment"][2], github._TM_COMMENT_MARKER)

    def test_report_tm_to_pr_skips_without_token_or_pr(self):
        class Boom:
            def __init__(self, *a, **k): raise AssertionError("must not call GitHub")
        with mock.patch.object(github, "GitHubClient", Boom):
            # no token
            github.report_tm_to_pr({}, {"kind": "pull_request", "number": 1,
                                        "full_name": "a/b"}, {"categories": []}, "r")
            # not a PR
            github.report_tm_to_pr({"github_token": "t"}, {"kind": "push"},
                                   {"categories": []}, "r")

    def test_redact_repo(self):
        red = config.redact_repo({"id": "x", "github_token": "T", "webhook_secret": ""})
        self.assertNotIn("github_token", red)
        self.assertTrue(red["github_token_set"])
        self.assertFalse(red["webhook_secret_set"])


class TestChecksApi(unittest.TestCase):
    """Check Run annotations + the auto-fallback to commit status."""

    def _findings(self, n=2):
        out = []
        for i in range(n):
            out.append({"id": f"R{i}", "title": f"Finding {i}", "severity":
                        ["Critical", "Medium", "Low"][i % 3], "owasp": "A03",
                        "cwe": "CWE-78", "remediation": "Fix it.",
                        "file": f"src/mod{i}.py", "line": i, "snippet": "bad()"})
        return out

    def test_build_annotations_mapping(self):
        anns = github.build_annotations(self._findings(3))
        self.assertEqual(len(anns), 3)
        # severity -> level, and start_line clamped to >= 1.
        self.assertEqual(anns[0]["annotation_level"], "failure")   # Critical
        self.assertEqual(anns[1]["annotation_level"], "warning")   # Medium
        self.assertEqual(anns[2]["annotation_level"], "notice")    # Low
        self.assertEqual(anns[0]["start_line"], 1)                 # line 0 -> 1
        self.assertEqual(anns[0]["path"], "src/mod0.py")
        self.assertIn("CWE-78", anns[0]["message"])
        self.assertTrue(anns[0]["title"].startswith("Critical:"))

    def test_annotation_path_normalisation(self):
        # Backslashes, leading ./, and an absolute path inside scan_root.
        self.assertEqual(github._annotation_path("a\\b\\c.py"), "a/b/c.py")
        self.assertEqual(github._annotation_path("./x.py"), "x.py")
        self.assertEqual(
            github._annotation_path("C:/ws/repo/sub/app.py", "C:/ws/repo"),
            "sub/app.py")
        # A dotfile must not lose its leading dot.
        self.assertEqual(github._annotation_path(".github/ci.yml"), ".github/ci.yml")

    def test_build_annotations_cap(self):
        self.assertEqual(len(github.build_annotations(self._findings(10), limit=4)), 4)

    def test_check_run_payload_and_batching(self):
        captured = []

        class CaptureClient(github.GitHubClient):
            def __init__(self): super().__init__("tok")
            def _request(self, method, path, body=None):
                captured.append((method, path, body))
                return {"id": 555} if path.endswith("/check-runs") else {}

        rep = mapper.findings_to_report(self._findings(2), {"id": "x", "name": "x"}, {}, "Low")
        github._post_check_run(CaptureClient(), "org/repo", "d" * 40, rep, None,
                               False, "High", "", self._findings(60), None,
                               log=lambda m: None)
        posts = [c for c in captured if c[0] == "POST"]
        patches = [c for c in captured if c[0] == "PATCH"]
        self.assertEqual(len(posts), 1)
        self.assertTrue(posts[0][1].endswith("/repos/org/repo/check-runs"))
        body = posts[0][2]
        self.assertEqual(body["name"], "Yaksha Guard SAST")
        self.assertEqual(body["head_sha"], "d" * 40)
        self.assertEqual(body["conclusion"], "failure")             # gate breached
        self.assertEqual(len(body["output"]["annotations"]), 50)    # first batch
        self.assertEqual(len(patches), 1)                           # 60 -> 50 + 10
        self.assertEqual(len(patches[0][2]["output"]["annotations"]), 10)

    def test_report_to_pr_prefers_check_run(self):
        import unittest.mock as mock
        calls = {"check": 0, "status": 0, "comment": 0}

        class Client:
            def __init__(self, token, api_base=None): pass
            def create_check_run(self, *a, **k):
                calls["check"] += 1; return {"id": 1}
            def update_check_run(self, *a, **k): return {}
            def set_commit_status(self, *a, **k): calls["status"] += 1; return {}
            def upsert_pr_comment(self, *a, **k): calls["comment"] += 1; return {}

        rep = mapper.findings_to_report(self._findings(1), {"id": "x", "name": "x"}, {}, "Low")
        with mock.patch.object(github, "GitHubClient", Client):
            github.report_to_pr({"github_token": "t"},
                                {"full_name": "o/r", "sha": "a" * 40, "number": 3},
                                rep, "rid", None, findings=self._findings(1))
        self.assertEqual(calls["check"], 1)
        self.assertEqual(calls["status"], 0)     # check run succeeded -> no status
        self.assertEqual(calls["comment"], 1)    # PR comment still posted

    def test_report_to_pr_falls_back_to_status(self):
        import unittest.mock as mock
        calls = {"check": 0, "status": 0, "comment": 0}

        class Client:
            def __init__(self, token, api_base=None): pass
            def create_check_run(self, *a, **k):
                calls["check"] += 1
                raise github.GitHubError("403: Resource not accessible by personal access token")
            def set_commit_status(self, *a, **k): calls["status"] += 1; return {}
            def upsert_pr_comment(self, *a, **k): calls["comment"] += 1; return {}

        rep = mapper.findings_to_report(self._findings(1), {"id": "x", "name": "x"}, {}, "Low")
        with mock.patch.object(github, "GitHubClient", Client):
            github.report_to_pr({"github_token": "t"},
                                {"full_name": "o/r", "sha": "a" * 40, "number": 3},
                                rep, "rid", None, findings=self._findings(1))
        self.assertEqual(calls["check"], 1)
        self.assertEqual(calls["status"], 1)     # auto mode fell back
        self.assertEqual(calls["comment"], 1)


@unittest.skipUnless(ENGINE_AVAILABLE, "scan engine not installed on this host")
class TestRealScan(unittest.TestCase):
    def test_engine_flags_command_injection(self):
        repo = _make_vuln_repo()
        try:
            findings = run_scan(Path(repo), "Low")
        finally:
            pass
        ids = {f["id"] for f in findings}
        self.assertIn("SAR-APPSEC-011", ids,
                      f"expected command-injection finding, got {ids}")


class TestBrokerApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        cls.repo_dir = _make_vuln_repo()

    def _post(self, path, json_body):
        return self.client.post(path, json=json_body,
                                headers={"X-CSRF-Token": self.csrf})

    def test_status_and_page(self):
        self.assertEqual(self.client.get("/api/v1/sast").status_code, 200)
        page = self.client.get("/broker")
        self.assertEqual(page.status_code, 200)
        self.assertIn(b"SAST Broker", page.data)

    def test_full_scan_flow(self):
        # Register the local vulnerable repo.
        r = self._post("/api/v1/sast/repos",
                       {"name": "broker-test-repo", "url": self.repo_dir})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        repo_id = r.get_json()["repo"]["id"]

        # Trigger a scan.
        r = self._post(f"/api/v1/sast/repos/{repo_id}/scan", {"severity": "Low"})
        self.assertEqual(r.status_code, 202)
        job_id = r.get_json()["job_id"]

        # Poll the job to completion.
        deadline = time.time() + 120
        job = None
        while time.time() < deadline:
            job = self.client.get(f"/api/v1/sast/jobs/{job_id}").get_json()["job"]
            if job["status"] in ("done", "error"):
                break
            time.sleep(0.5)
        self.assertIsNotNone(job)
        if not ENGINE_AVAILABLE:
            self.assertEqual(job["status"], "error")  # no engine -> clean failure
            return
        self.assertEqual(job["status"], "done", job.get("error"))
        self.assertGreaterEqual(job["stats"]["findings_total"], 1)

        # The saved report is served by the SAST API surface only — the general
        # report API must not expose it.
        report_id = job["report_id"]
        self.assertEqual(self.client.get(f"/api/reports/{report_id}").status_code, 404)
        rep = self.client.get(f"/api/v1/sast/reports/{report_id}").get_json()
        self.assertTrue(rep["report"]["categories"])
        self.assertEqual(rep["report"]["methodology"], "sast")

        # A manual scan also auto-builds the code-derived architecture model
        # (see broker/service.py) over the same checkout — assert it landed
        # and clean it up too, so this test leaves nothing behind.
        cm_report_id = job.get("codemodel_report_id")
        self.assertIsNotNone(cm_report_id)
        cm_rep = self.client.get(f"/api/reports/{cm_report_id}").get_json()
        self.assertEqual(cm_rep["report"]["methodology"], "codemodel")

        # Cleanup registry entry + saved reports.
        self.client.delete(f"/api/v1/sast/reports/{report_id}",
                           headers={"X-CSRF-Token": self.csrf})
        self.client.delete(f"/api/reports/{cm_report_id}",
                           headers={"X-CSRF-Token": self.csrf})
        self.client.delete(f"/api/v1/sast/repos/{repo_id}",
                           headers={"X-CSRF-Token": self.csrf})


class TestJobDeletion(unittest.TestCase):
    """delete_job removes one job from history without touching the report
    it may have produced, and is a safe no-op-returns-False on an unknown id."""

    def _service(self):
        from broker.service import BrokerService
        with mock.patch.object(config, "load_jobs", return_value=[]):
            return BrokerService()

    def test_delete_removes_job_and_persists(self):
        svc = self._service()
        svc._jobs["j1"] = {"id": "j1", "status": "done", "started_at": "2026-01-01T00:00:00Z"}
        with mock.patch.object(config, "save_jobs") as save_mock:
            self.assertTrue(svc.delete_job("j1"))
            save_mock.assert_called_once()
        self.assertIsNone(svc.get_job("j1"))

    def test_delete_unknown_job_returns_false_without_persisting(self):
        svc = self._service()
        with mock.patch.object(config, "save_jobs") as save_mock:
            self.assertFalse(svc.delete_job("does-not-exist"))
            save_mock.assert_not_called()

    def test_delete_does_not_touch_the_jobs_report(self):
        svc = self._service()
        svc._jobs["j1"] = {"id": "j1", "status": "done", "report_id": "rep-1",
                           "started_at": "2026-01-01T00:00:00Z"}
        with mock.patch.object(config, "save_jobs"):
            svc.delete_job("j1")
        self.assertIsNone(svc.get_job("j1"))  # job gone
        # (the report itself lives in report_db, untouched by delete_job --
        # this test only asserts delete_job never reaches for report_db at all)

    def test_api_route_deletes_job_and_404s_for_unknown_id(self):
        import app as tm_app
        from broker.service import get_service
        client = tm_app.app.test_client()
        csrf = tm_app._CSRF_TOKEN
        get_service()._jobs["job-del-test"] = {
            "id": "job-del-test", "status": "done", "started_at": "2026-01-01T00:00:00Z"}
        try:
            with mock.patch.object(config, "save_jobs"):
                r = client.delete("/api/v1/sast/jobs/job-del-test",
                                  headers={"X-CSRF-Token": csrf})
                self.assertEqual(r.status_code, 200)
                self.assertTrue(r.get_json()["success"])
                self.assertIsNone(get_service().get_job("job-del-test"))

                r2 = client.delete("/api/v1/sast/jobs/job-del-test",
                                   headers={"X-CSRF-Token": csrf})
                self.assertEqual(r2.status_code, 404)
        finally:
            get_service()._jobs.pop("job-del-test", None)


class TestWebhookFlow(unittest.TestCase):
    """Webhook auth + dispatch with the GitHub network calls mocked out."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        cls.repo_dir = _make_vuln_repo()
        cls.secret = "hook-secret-123"

    @classmethod
    def tearDownClass(cls):
        for rid in ("hooktest", "pingrepo", "prflow"):
            config.remove_repo(rid)

    def _sig(self, body: bytes) -> str:
        import hashlib
        import hmac
        return "sha256=" + hmac.new(self.secret.encode(), body, hashlib.sha256).hexdigest()

    def _hook(self, event, payload, sign=True, secret=None):
        body = config_json(payload)
        headers = {"X-GitHub-Event": event, "Content-Type": "application/json"}
        if sign:
            import hashlib
            import hmac
            s = (secret or self.secret).encode()
            headers["X-Hub-Signature-256"] = "sha256=" + hmac.new(s, body, hashlib.sha256).hexdigest()
        return self.client.post("/api/v1/sast/webhook", data=body, headers=headers)

    def test_webhook_rejects_bad_signature(self):
        # Register a GitHub-wired repo first so a secret exists to check against.
        self.client.post("/api/v1/sast/repos",
                         json={"name": "hooktest", "url": "https://github.com/acme/hooktest.git",
                               "webhook_secret": self.secret},
                         headers={"X-CSRF-Token": self.csrf})
        r = self._hook("push", {"ref": "refs/heads/main", "after": "a" * 40,
                                "repository": {"full_name": "acme/hooktest"}}, sign=False)
        self.assertEqual(r.status_code, 401, r.get_data(as_text=True))

    def test_ping(self):
        self.client.post("/api/v1/sast/repos",
                         json={"name": "pingrepo", "url": "https://github.com/acme/pingrepo.git",
                               "webhook_secret": self.secret},
                         headers={"X-CSRF-Token": self.csrf})
        r = self._hook("ping", {"zen": "ok", "repository": {"full_name": "acme/pingrepo"}})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.get_json().get("pong"))

    def test_unregistered_repo_404(self):
        # Valid global secret but no matching repo -> 404 (never auto-registers).
        import os
        os.environ["dummy"] = "1"
        config.GITHUB_WEBHOOK_SECRET = self.secret
        try:
            r = self._hook("push", {"ref": "refs/heads/main", "after": "a" * 40,
                                    "repository": {"full_name": "ghost/none"}})
            self.assertEqual(r.status_code, 404, r.get_data(as_text=True))
        finally:
            config.GITHUB_WEBHOOK_SECRET = ""

    def test_pr_webhook_dispatches_and_reports(self):
        import unittest.mock as mock

        # A registered repo pointing at our LOCAL fixture (so the scan runs
        # without real git/network), matched to a GitHub full_name explicitly.
        r = self.client.post(
            "/api/v1/sast/repos",
            json={"name": "prflow", "url": self.repo_dir,
                  "github_full_name": "acme/prflow", "github_token": "tok",
                  "webhook_secret": self.secret},
            headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))

        calls = {}

        class FakeClient:
            def __init__(self, token, api_base=None): calls["token"] = token
            def create_check_run(self, *a, **k):
                # Simulate a classic PAT: no checks:write -> 403, force fallback.
                raise github.GitHubError("POST /check-runs -> 403: Resource not accessible")
            def set_commit_status(self, fn, sha, state, desc, url=""):
                calls["status"] = (fn, sha, state); return {}
            def upsert_pr_comment(self, fn, num, body):
                calls["comment"] = (fn, num, body); return {}

        with mock.patch.object(github, "GitHubClient", FakeClient):
            payload = {"action": "opened", "number": 42,
                       "pull_request": {"head": {"sha": "c" * 40}},
                       "repository": {"full_name": "acme/prflow"}}
            resp = self._hook("pull_request", payload)
            self.assertEqual(resp.status_code, 202, resp.get_data(as_text=True))
            job_id = resp.get_json()["job_id"]

            deadline = time.time() + 120
            job = None
            while time.time() < deadline:
                job = self.client.get(f"/api/v1/sast/jobs/{job_id}").get_json()["job"]
                if job["status"] in ("done", "error"):
                    break
                time.sleep(0.5)

        if not ENGINE_AVAILABLE:
            self.skipTest("scan engine not installed")
        self.assertEqual(job["status"], "done", job.get("error"))
        self.assertEqual(job["pr_number"], 42)
        # GitHub was told the verdict and a PR comment was upserted.
        self.assertIn("status", calls)
        self.assertEqual(calls["status"][0], "acme/prflow")
        self.assertEqual(calls["status"][1], "c" * 40)
        self.assertIn("comment", calls)
        self.assertEqual(calls["comment"][1], 42)
        self.assertIn("yaksha-guard-sast", calls["comment"][2])


class TestConcurrencySerialization(unittest.TestCase):
    """Two scans of the same repo must not run their workspace phase at once."""

    def test_same_repo_scans_are_serialized(self):
        import threading
        from broker import scanner as bscanner
        from broker.service import BrokerService

        svc = BrokerService()
        state = {"cur": 0, "max": 0}
        guard = threading.Lock()

        def fake_prepare(repo, progress=None, ref=None):
            with guard:
                state["cur"] += 1
                state["max"] = max(state["max"], state["cur"])
            time.sleep(0.15)                     # hold the workspace phase open
            with guard:
                state["cur"] -= 1
            return Path("."), {}

        orig_prepare, orig_scan = bscanner.prepare_workspace, bscanner.run_scan
        bscanner.prepare_workspace = fake_prepare
        bscanner.run_scan = lambda root, sev: []
        svc._save_report = lambda report: "rid"   # don't touch the real report store
        save_jobs_patch = mock.patch.object(config, "save_jobs")  # nor the real job history
        save_jobs_patch.start()
        try:
            repo = {"id": "concurrency-test", "name": "ct", "url": "/tmp/nope"}
            # Distinct commit ids so dedup treats them as two events (both run) and
            # the per-repo lock — not dedup — is what serializes them.
            j1 = svc.submit_scan(repo, gh_ctx={"sha": "cc-1"})
            j2 = svc.submit_scan(repo, gh_ctx={"sha": "cc-2"})
            deadline = time.time() + 10
            while time.time() < deadline:
                jobs = {j["id"]: j for j in svc.list_jobs()}
                if all(jobs.get(j, {}).get("status") in ("done", "error")
                       for j in (j1, j2)):
                    break
                time.sleep(0.05)
        finally:
            bscanner.prepare_workspace = orig_prepare
            bscanner.run_scan = orig_scan
            save_jobs_patch.stop()
        # If the per-repo lock works, the two workspace phases never overlapped.
        self.assertEqual(state["max"], 1,
                         "workspace prep for the same repo ran concurrently")


class TestDelta(unittest.TestCase):
    """Fingerprints + baseline delta partitioning (#1, #11)."""

    def test_fingerprint_stable_across_line_sep_whitespace(self):
        from broker import delta
        bs = chr(92)
        a = {"id": "R1", "file": "a/b.py", "line": 5, "snippet": "os.system(x)"}
        b = {"id": "R1", "file": "a" + bs + "b.py", "line": 40, "snippet": "os.system(x)   "}
        self.assertEqual(delta.finding_fingerprint(a), delta.finding_fingerprint(b))

    def test_fingerprint_distinguishes_rule_and_path(self):
        from broker import delta
        base = {"id": "R1", "file": "a.py", "snippet": "bad()"}
        self.assertNotEqual(delta.finding_fingerprint(base),
                            delta.finding_fingerprint({**base, "id": "R2"}))
        self.assertNotEqual(delta.finding_fingerprint(base),
                            delta.finding_fingerprint({**base, "file": "b.py"}))

    def test_partition_new_vs_known(self):
        from broker import delta
        old = {"id": "R1", "file": "a.py", "snippet": "old()"}
        new = {"id": "R2", "file": "b.py", "snippet": "new()"}
        baseline = delta.fingerprints([old])
        fresh, known = delta.partition_new([old, new], baseline)
        self.assertEqual([f["id"] for f in fresh], ["R2"])
        self.assertEqual([f["id"] for f in known], ["R1"])


class TestConfigStores(unittest.TestCase):
    """SHA cache (#3), baselines, workspace pruning (#6)."""

    def test_sha_cache_roundtrip(self):
        config.sha_cache_put("repoZ", "deadbeef", "rep_123")
        self.assertEqual(config.sha_cache_get("repoZ", "deadbeef"), "rep_123")
        self.assertIsNone(config.sha_cache_get("repoZ", "nope"))
        self.assertIsNone(config.sha_cache_get("", ""))

    def test_baseline_roundtrip(self):
        config.save_baseline("repoZ", "main", {"aa", "bb"})
        self.assertEqual(config.load_baseline("repoZ", "main"), {"aa", "bb"})
        self.assertEqual(config.load_baseline("repoZ", "absent-branch"), set())

    def test_prune_stale_workspaces(self):
        stale = config.WORKSPACE_DIR / "zzz-stale-workspace-test"
        stale.mkdir(exist_ok=True)
        old = time.time() - 999 * 86400
        os.utime(stale, (old, old))
        removed = config.prune_stale_workspaces(max_age_days=1)
        self.assertIn("zzz-stale-workspace-test", removed)
        self.assertFalse(stale.exists())


class TestClonePolicy(unittest.TestCase):
    """Clone scheme / host allowlist (#7)."""

    def test_file_and_http_disabled_by_default(self):
        from broker import scanner
        self.assertFalse(config.ALLOW_FILE_SCHEME)  # default posture
        with self.assertRaises(scanner.ScanError):
            scanner.check_clone_policy("file:///etc/passwd")
        with self.assertRaises(scanner.ScanError):
            scanner.check_clone_policy("http://insecure.example/x.git")
        # https / ssh are always fine.
        scanner.check_clone_policy("https://github.com/o/r.git")
        scanner.check_clone_policy("git@github.com:o/r.git")

    def test_host_allowlist(self):
        from broker import scanner
        orig = config.ALLOWED_GIT_HOSTS
        config.ALLOWED_GIT_HOSTS = {"git.internal"}
        try:
            scanner.check_clone_policy("https://git.internal/o/r.git")
            with self.assertRaises(scanner.ScanError):
                scanner.check_clone_policy("https://github.com/o/r.git")
        finally:
            config.ALLOWED_GIT_HOSTS = orig


class TestOutputCap(unittest.TestCase):
    """Bounded subprocess output (#5)."""

    def test_exec_capped_truncates_and_returns_code(self):
        import sys
        from broker import scanner
        code, out, err = scanner._exec_capped(
            [sys.executable, "-c", "print('A'*100000)"], timeout=30, max_bytes=1000)
        self.assertEqual(code, 0)
        self.assertLessEqual(len(out), 1000)          # capped, no OOM
        code, out, err = scanner._exec_capped(
            [sys.executable, "-c", "import sys; sys.exit(2)"], timeout=30, max_bytes=1000)
        self.assertEqual(code, 2)


class TestSeverityNormalisation(unittest.TestCase):
    """Off-scale severities clamp to Info (#8)."""

    def test_non_canonical_severity_clamped(self):
        findings = [{"id": "R", "title": "t", "severity": "Informational",
                     "file": "a.py", "line": 1, "snippet": "x"}]
        rep = mapper.findings_to_report(findings, {"id": "x", "name": "x"}, {}, "Low")
        counts = rep["scan_metadata"]["severity_counts"]
        self.assertEqual(set(counts), set(config.SEVERITIES))   # no stray key
        self.assertEqual(counts["Info"], 1)
        self.assertEqual(rep["overall_risk"], "Info")


class TestWorkerPoolAndScheduler(unittest.TestCase):
    """Bounded pool (#4) and scheduler selection (#9)."""

    def test_worker_pool_is_bounded(self):
        from broker.service import BrokerService
        svc = BrokerService()
        svc._ensure_workers()
        svc._ensure_workers()                          # idempotent
        self.assertEqual(len(svc._workers), config.BROKER_WORKERS)

    def test_due_repos_selection(self):
        from broker.service import BrokerService
        now = time.time()
        recent = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now - 600))
        stale = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now - 5 * 3600))
        repos = [
            {"id": "no-interval"},                                        # never
            {"id": "never-scanned", "scan_interval_hours": 1},           # due (no last)
            {"id": "recent", "scan_interval_hours": 1,
             "last_scan": {"at": recent}},                               # not due
            {"id": "overdue", "scan_interval_hours": 1,
             "last_scan": {"at": stale}},                                # due
        ]
        due = {r["id"] for r in BrokerService.due_repos(repos, now)}
        self.assertEqual(due, {"never-scanned", "overdue"})


class TestMetrics(unittest.TestCase):
    """Per-repo metrics/trend (#12)."""

    def test_metrics_aggregates_done_jobs(self):
        from broker.service import BrokerService
        svc = BrokerService()
        svc._jobs = {
            "j1": {"id": "j1", "repo_id": "r", "repo_name": "r", "status": "done",
                   "started_at": "2026-07-17T10:00:00Z", "finished_at": "2026-07-17T10:01:00Z",
                   "stats": {"findings_total": 5, "overall_risk": "High"}},
            "j2": {"id": "j2", "repo_id": "r", "repo_name": "r", "status": "done",
                   "started_at": "2026-07-17T11:00:00Z", "finished_at": "2026-07-17T11:01:00Z",
                   "stats": {"findings_total": 2, "overall_risk": "Medium"}},
            "j3": {"id": "j3", "repo_id": "r", "status": "error",
                   "started_at": "2026-07-17T12:00:00Z"},
        }
        m = svc.metrics()
        self.assertEqual(m["total_scans"], 2)          # error job excluded
        repo = next(x for x in m["repos"] if x["repo_id"] == "r")
        self.assertEqual(repo["scans"], 2)
        self.assertEqual(repo["last_findings"], 2)     # newest first
        self.assertEqual(repo["last_risk"], "Medium")


class TestDeltaGatingAndSarif(unittest.TestCase):
    """New-only gate + comment (#1) and SARIF code-scanning upload (#2)."""

    def _findings(self, sev="High"):
        return [{"id": "R1", "title": "SQLi", "severity": sev,
                 "file": "a.py", "line": 1, "snippet": "q"}]

    def test_gate_passes_findings_new_only(self):
        # Whole report has a High; but if the *new* set is empty the gate passes.
        self.assertFalse(github.gate_passes_findings(self._findings("High"), "High"))
        self.assertTrue(github.gate_passes_findings([], "High"))
        self.assertTrue(github.gate_passes_findings(self._findings("Low"), "High"))

    def test_comment_shows_delta(self):
        rep = mapper.findings_to_report(self._findings(), {"id": "x", "name": "x"}, {}, "Low")
        body = github.build_comment(rep, "", True, "High", "abc1234567",
                                    delta={"new": 0, "known": 3, "base": "main"})
        self.assertIn("new", body.lower())
        self.assertIn("pre-existing", body.lower())

    def test_upload_sarif_payload(self):
        import base64
        import gzip
        import json as _json
        captured = {}

        class CaptureClient(github.GitHubClient):
            def __init__(self): super().__init__("tok")
            def _request(self, method, path, body=None):
                captured["method"], captured["path"], captured["body"] = method, path, body
                return {"id": "sarif-1"}

        rep = mapper.findings_to_report(self._findings(), {"id": "x", "name": "x"}, {}, "Low")
        import sarif as sarif_mod
        CaptureClient().upload_sarif("o/r", "d" * 40, "refs/heads/main",
                                     sarif_mod.to_sarif(rep))
        self.assertEqual(captured["method"], "POST")
        self.assertTrue(captured["path"].endswith("/repos/o/r/code-scanning/sarifs"))
        self.assertEqual(captured["body"]["commit_sha"], "d" * 40)
        # The sarif field is gzip+base64 of the SARIF JSON.
        raw = gzip.decompress(base64.b64decode(captured["body"]["sarif"]))
        self.assertEqual(_json.loads(raw)["version"], "2.1.0")


@unittest.skipUnless(ENGINE_AVAILABLE, "scan engine not installed on this host")
class TestPipeline(unittest.TestCase):
    """One-button SAST + code-model + correlation (#10)."""

    def test_pipeline_runs_and_correlates(self):
        from broker import pipeline
        repo = {"id": "pipeline-test", "name": "pipeline-test", "url": _make_vuln_repo()}
        result = pipeline.run(repo, severity="Low")
        # SAST + code-model reports produced, plus a correlation report.
        self.assertGreaterEqual(len(result["reports"]), 2)
        self.assertTrue(result["correlation_report_id"])
        stages = {s["stage"] for s in result["steps"]}
        self.assertIn("sast", stages)
        self.assertIn("codemodel", stages)
        self.assertIn("correlation", stages)


class TestPipelineApiErrorHandling(unittest.TestCase):
    """POST /repos/<id>/pipeline must only convert *expected* failures
    (ScanError: bad remote, clone/engine failure) into a clean 400 — a real
    bug anywhere in the pipeline must still surface as a logged 500, not get
    silently repackaged as a client error.
    """

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN

    def setUp(self):
        r = self.client.post("/api/v1/sast/repos",
                             json={"name": "pipe-err-repo", "url": _make_vuln_repo()},
                             headers={"X-CSRF-Token": self.csrf})
        self.repo_id = r.get_json()["repo"]["id"]
        self.addCleanup(
            lambda: self.client.delete(f"/api/v1/sast/repos/{self.repo_id}",
                                       headers={"X-CSRF-Token": self.csrf}))

    def _pipeline(self):
        return self.client.post(f"/api/v1/sast/repos/{self.repo_id}/pipeline", json={},
                                headers={"X-CSRF-Token": self.csrf})

    def test_scan_error_from_pipeline_becomes_a_clean_400(self):
        from broker import pipeline
        with mock.patch.object(pipeline, "run",
                               side_effect=ScanError("git host not in allowlist")):
            r = self._pipeline()
        self.assertEqual(r.status_code, 400)
        self.assertIn("allowlist", r.get_json()["error"])

    def test_unexpected_bug_in_pipeline_is_not_masked_as_a_400(self):
        # Regression: a bare `except Exception` used to swallow *any*
        # failure from pipeline.run() — a real bug (e.g. a KeyError from a
        # codemodel/correlator regression) was reported as a 400 client
        # error instead of surfacing as a logged 500.
        from broker import pipeline
        with mock.patch.object(pipeline, "run", side_effect=KeyError("boom")):
            r = self._pipeline()
        self.assertEqual(r.status_code, 500)


class TestDashboardApi(unittest.TestCase):
    """API surface the dashboard relies on: interval field + status fields."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN

    def _post(self, path, body):
        return self.client.post(path, json=body, headers={"X-CSRF-Token": self.csrf})

    def test_status_exposes_dashboard_fields(self):
        d = self.client.get("/api/v1/sast").get_json()
        for key in ("workers", "baseline_gating", "scheduler"):
            self.assertIn(key, d)
        self.assertIsInstance(d["workers"], int)

    def test_register_with_scan_interval(self):
        r = self._post("/api/v1/sast/repos",
                       {"name": "interval-test", "url": "/tmp/x", "scan_interval_hours": 6})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        self.assertEqual(r.get_json()["repo"]["scan_interval_hours"], 6)
        # Re-registering without the field keeps the stored interval.
        r2 = self._post("/api/v1/sast/repos", {"name": "interval-test", "url": "/tmp/x"})
        self.assertEqual(r2.get_json()["repo"]["scan_interval_hours"], 6)
        self.client.delete("/api/v1/sast/repos/interval-test",
                           headers={"X-CSRF-Token": self.csrf})

    def test_invalid_interval_rejected(self):
        for bad in ("abc", -3, 999999999):
            r = self._post("/api/v1/sast/repos",
                           {"name": "bad-interval", "url": "/tmp/x", "scan_interval_hours": bad})
            self.assertEqual(r.status_code, 400, f"interval={bad!r}")


class TestWebhookDedup(unittest.TestCase):
    """At-least-once webhook delivery must not launch duplicate scans."""

    def _running_job(self, svc, **fields):
        jid = svc._new_job_id()
        job = {"id": jid, "repo_id": None, "status": "running", "trigger": "manual",
               "commit": None, "pr_number": None, "started_at": config.now_iso()}
        job.update(fields)
        svc._jobs[jid] = job
        return jid

    def test_find_inflight_matches_full_event_identity(self):
        from broker.service import BrokerService
        svc = BrokerService()
        jid = self._running_job(svc, repo_id="r1", trigger="pull_request",
                                commit="sha1", pr_number=7)
        # exact same event -> found
        self.assertEqual(svc._find_inflight("r1", "pull_request", "sha1", 7), jid)
        # different sha / kind / pr -> not the same event
        self.assertIsNone(svc._find_inflight("r1", "pull_request", "sha2", 7))
        self.assertIsNone(svc._find_inflight("r1", "push", "sha1", 7))
        self.assertIsNone(svc._find_inflight("r1", "pull_request", "sha1", 8))

    def test_finished_job_does_not_dedup(self):
        from broker.service import BrokerService
        svc = BrokerService()
        self._running_job(svc, repo_id="r1", trigger="push", commit="sha1", status="done")
        self.assertIsNone(svc._find_inflight("r1", "push", "sha1", None))

    def test_submit_collapses_redelivered_event(self):
        from broker.service import BrokerService
        svc = BrokerService()
        jid = self._running_job(svc, repo_id="r2", trigger="pull_request",
                                commit="deadbeef", pr_number=3)
        before = svc._queue.qsize()
        # A redelivery of the same PR event returns the in-flight id, enqueues nothing.
        got = svc.submit_scan({"id": "r2"}, gh_ctx={"kind": "pull_request",
                                                    "sha": "deadbeef", "number": 3})
        self.assertEqual(got, jid)
        self.assertEqual(svc._queue.qsize(), before)

    def test_push_and_pr_same_sha_stay_distinct(self):
        from broker.service import BrokerService
        svc = BrokerService()
        self._running_job(svc, repo_id="r3", trigger="push", commit="sha9", pr_number=None)
        # A PR for the same commit is a different event (gates instead of baselining).
        self.assertIsNone(svc._find_inflight("r3", "pull_request", "sha9", 5))


class TestPrBaseBranch(unittest.TestCase):
    """Delta gating must diff against the PR's real target branch (#2)."""

    def test_parse_captures_base_ref(self):
        p = github.parse_webhook("pull_request", {
            "action": "opened", "number": 5,
            "pull_request": {"head": {"sha": "h" * 40}, "base": {"ref": "develop"}},
            "repository": {"full_name": "org/repo"}})
        self.assertEqual(p["base_branch"], "develop")

    def test_apply_delta_uses_gh_ctx_base(self):
        from broker import delta
        from broker.service import BrokerService
        svc = BrokerService()
        existing = {"id": "R1", "file": "a.py", "snippet": "old()"}
        new = {"id": "R2", "file": "b.py", "snippet": "new()"}
        # Baseline recorded for the 'develop' branch (not the repo's 'main' default).
        config.save_baseline("rb", "develop", delta.fingerprints([existing]))
        gate, info = svc._apply_delta(
            "nojob", {"id": "rb", "branch": "main"}, "refs/pull/5/head",
            {"kind": "pull_request", "base_branch": "develop"}, [existing, new])
        self.assertEqual(info["base"], "develop")     # used PR base, not repo default
        self.assertEqual([f["id"] for f in gate], ["R2"])   # only the new one gates
        self.assertEqual(info["new"], 1)


class TestRegistrationValidation(unittest.TestCase):
    """Registration-time pre-flight (validate_remote / POST repos validate:true).

    Motivated by a real failure: a private repo registered with no token and a
    garbage branch produced 'Authentication failed' only at first scan. With
    validate:true the same mistakes must be a 400 at registration instead.
    """

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        # A real local git repo served over file:// gives an offline,
        # deterministic "remote" with a known branch.
        cls.git_dir = tempfile.mkdtemp(prefix="broker_validate_")
        subprocess.run(["git", "init", "-q", "-b", "main", cls.git_dir], check=True)
        (Path(cls.git_dir) / "readme.txt").write_text("x", encoding="utf-8")
        subprocess.run(["git", "-C", cls.git_dir, "-c", "user.email=t@t", "-c",
                        "user.name=t", "add", "-A"], check=True)
        subprocess.run(["git", "-C", cls.git_dir, "-c", "user.email=t@t", "-c",
                        "user.name=t", "commit", "-q", "-m", "init"], check=True)
        cls.file_url = Path(cls.git_dir).as_uri()  # file:///C:/...

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.git_dir, ignore_errors=True)

    def _post(self, path, json_body):
        return self.client.post(path, json=json_body,
                                headers={"X-CSRF-Token": self.csrf})

    def test_validate_remote_ok_and_branch_check(self):
        from broker import scanner
        with mock.patch.object(scanner.config, "ALLOW_FILE_SCHEME", True):
            self.assertIsNone(scanner.validate_remote(self.file_url))
            self.assertIsNone(scanner.validate_remote(self.file_url, branch="main"))
            err = scanner.validate_remote(self.file_url, branch="no-such-branch")
        self.assertIn("no-such-branch", err or "")
        self.assertIn("not found", err or "")

    def test_validate_remote_unreachable_host(self):
        from broker import scanner
        err = scanner.validate_remote("https://127.0.0.1:1/nope.git")
        self.assertIsNotNone(err)
        self.assertIn("failed", err.lower())

    def test_validate_remote_respects_clone_policy(self):
        from broker import scanner
        # file:// is disabled by default — validation must refuse it too, not
        # provide a side channel that probes local paths.
        with mock.patch.object(scanner.config, "ALLOW_FILE_SCHEME", False):
            err = scanner.validate_remote(self.file_url)
        self.assertIn("file://", err or "")

    def test_register_with_validate_rejects_unreachable(self):
        r = self._post("/api/v1/sast/repos",
                       {"name": "badremote", "url": "https://127.0.0.1:1/nope.git",
                        "validate": True})
        self.assertEqual(r.status_code, 400, r.get_data(as_text=True))
        self.assertIn("validation failed", r.get_json()["error"])
        # And the entry must NOT have been saved.
        repos = self.client.get("/api/v1/sast/repos").get_json()["repos"]
        self.assertNotIn("badremote", [x["id"] for x in repos])

    def test_register_without_validate_keeps_offline_behavior(self):
        r = self._post("/api/v1/sast/repos",
                       {"name": "offline-entry", "url": "https://127.0.0.1:1/nope.git"})
        self.assertEqual(r.status_code, 201)
        self.client.delete("/api/v1/sast/repos/offline-entry",
                           headers={"X-CSRF-Token": self.csrf})


class TestCodeModelAutoTrigger(unittest.TestCase):
    """A manual scan should auto-build the code-derived architecture model
    (entry points / trust boundaries / data stores) over the same checkout,
    so the Visualiser's Architecture map has real data without a separate
    trip through the Code Model page. Webhook-triggered scans (push/PR) must
    skip it — that path runs unattended and shouldn't gain cost or report
    noise from every commit. A codemodel failure must never fail the scan.
    """

    def _run_job(self, gh_ctx=None, codemodel_side_effect=None):
        from broker import engines as bengines
        from broker import scanner as bscanner
        from broker.service import BrokerService
        from codemodel import service as cm_service

        svc = BrokerService()
        saved = []
        svc._save_report = lambda report: saved.append(report) or f"rid-{len(saved)}"
        repo = {"id": "cm-trigger-test", "name": "cmt", "url": "/tmp/nope"}
        fake_root = Path(".")

        with mock.patch.object(bscanner, "prepare_workspace",
                                return_value=(fake_root, {"source": "local"})), \
             mock.patch.object(bscanner, "run_scan", return_value=[]), \
             mock.patch.object(bengines, "run_engines", return_value=([], {})), \
             mock.patch.object(config, "save_jobs"), \
             mock.patch.object(cm_service, "analyze_path",
                                side_effect=codemodel_side_effect,
                                return_value={"title": "Code-Derived Threat Model",
                                              "methodology": "codemodel",
                                              "categories": [], "scan_metadata": {}}) as cm_mock:
            job_id = svc.submit_scan(repo, gh_ctx=gh_ctx)
            deadline = time.time() + 10
            job = None
            while time.time() < deadline:
                job = svc.get_job(job_id)
                if job["status"] in ("done", "error"):
                    break
                time.sleep(0.02)
        return job, cm_mock, saved

    def test_manual_scan_triggers_codemodel(self):
        job, cm_mock, saved = self._run_job(gh_ctx=None)
        self.assertEqual(job["status"], "done", job.get("error"))
        cm_mock.assert_called_once()
        called_root = cm_mock.call_args.args[0]
        self.assertEqual(called_root, str(Path(".")))
        self.assertEqual(len(saved), 2)   # the SAST report + the codemodel report
        self.assertIsNotNone(job.get("codemodel_report_id"))
        self.assertNotEqual(job.get("codemodel_report_id"), job.get("report_id"))

    def test_webhook_scan_skips_codemodel(self):
        job, cm_mock, saved = self._run_job(gh_ctx={"kind": "push", "sha": "abc123"})
        self.assertEqual(job["status"], "done", job.get("error"))
        cm_mock.assert_not_called()
        self.assertEqual(len(saved), 1)   # only the SAST report
        self.assertNotIn("codemodel_report_id", job)

    def test_codemodel_failure_does_not_fail_scan_job(self):
        job, cm_mock, saved = self._run_job(
            gh_ctx=None, codemodel_side_effect=RuntimeError("boom"))
        self.assertEqual(job["status"], "done", job.get("error"))
        cm_mock.assert_called_once()
        self.assertEqual(len(saved), 1)   # only the SAST report; codemodel never saved
        self.assertNotIn("codemodel_report_id", job)
        self.assertTrue(any("Code model skipped: boom" in line for line in job["log"]))


def config_json(payload) -> bytes:
    import json as _json
    return _json.dumps(payload).encode("utf-8")


if __name__ == "__main__":
    unittest.main(verbosity=2)
