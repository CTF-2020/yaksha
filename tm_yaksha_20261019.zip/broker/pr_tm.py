"""PR-scoped threat modeling: code-model over only the files a PR changed.

On a pull_request scan the broker already has the PR head checked out in the
repo workspace (a depth-1 clone). This module fetches the base branch tip and
takes a tree-to-tree diff base..HEAD — no shared history required — stages just
the changed files into a temporary tree, and runs the code-model threat engine
over that tree: a threat model for the PR without a full-repo scan.

The resulting report is a normal ``codemodel`` threat model, so it appears
in the report viewer alongside hand-run threat models (unlike raw SAST scan
reports, which stay broker-tab-only). Failures here never fail the scan job:
the caller logs and moves on.

Kill switches: ``TM_BROKER_PR_TM=off`` globally, or ``pr_tm: false`` on a
registered repo.
"""
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

import settings_db

from . import scanner
from .github import is_valid_ref


def enabled(repo: dict) -> bool:
    if not settings_db.resolve_bool(
            "broker.pr_tm_enabled", os.environ.get("TM_BROKER_PR_TM"), True):
        return False
    per_repo = repo.get("pr_tm")
    if per_repo is None:
        return True
    return str(per_repo).strip().lower() not in ("off", "0", "false", "no")


def _diff_names(root: str, a: str, b: str) -> list[str]:
    out = scanner._run_git(
        ["diff", "--name-only", "--diff-filter=d", a, b], cwd=root)
    return [ln.strip() for ln in out.splitlines() if ln.strip()]


def changed_files(scan_root: Path, base_branch: str) -> list[str]:
    """Repo-relative paths the PR head changes versus the base branch tip.

    The broker prepares a PR workspace as a *depth-1* clone reset to the PR
    head, so there is no shared history and a merge-base (three-dot) diff would
    fail with "no merge base". Instead we fetch the base branch tip (depth 1 is
    enough — we only need its tree) and take a tree-to-tree diff base..HEAD,
    which needs no common ancestor. Deleted files are excluded (nothing to
    model). Falls back to the immediate parent, then to empty, so a scan is
    never blocked by an un-diffable workspace.
    """
    root = str(scan_root)
    if is_valid_ref(base_branch):
        try:
            # FETCH_HEAD is repointed to the base tip; HEAD stays the PR head.
            scanner._run_git(["fetch", "--depth", "1", "--", "origin", base_branch], cwd=root)
            return _diff_names(root, "FETCH_HEAD", "HEAD")
        except Exception:
            pass
    try:
        return _diff_names(root, "HEAD~1", "HEAD")
    except Exception:
        return []


def run(scan_root, repo: dict, gh_ctx: dict, save_report, log=lambda m: None):
    """Build and save a PR-scoped threat model.

    Returns ``{"report_id", "files"}`` or ``None`` when not applicable
    (not a PR, no base branch, or no modelable changed files).
    """
    ctx = gh_ctx or {}
    base = str(ctx.get("base_branch") or "").strip()
    number = ctx.get("number")
    if ctx.get("kind") != "pull_request" or not base:
        return None

    files = changed_files(Path(scan_root), base)
    if not files:
        log("PR threat model: no changed files vs base — skipped")
        return None

    stage = Path(tempfile.mkdtemp(prefix="tm_pr_"))
    try:
        staged = 0
        stage_resolved = stage.resolve()
        for rel in files:
            src = Path(scan_root) / rel
            if not src.is_file():
                continue
            dst = stage / rel
            # git paths are repo-relative, but never let a hostile name escape
            # the staging tree.
            if not str(dst.resolve()).startswith(str(stage_resolved)):
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            staged += 1
        if not staged:
            log("PR threat model: changed files absent from head — skipped")
            return None

        import codemodel.service
        name = repo.get("name") or repo.get("id") or "repo"
        pr_repo = dict(repo)
        pr_repo["name"] = f"{name} · PR #{number}"
        report = codemodel.service.analyze_path(str(stage), pr_repo, {
            "scope": "pr-diff",
            "pr_number": number,
            "base_branch": base,
            "changed_files": staged,
        })
        report["title"] = f"PR #{number} Threat Model · {name}"
        rid = save_report(report)

        # Post the design-level model back to the PR as its own comment so a
        # reviewer sees it inline (best-effort; never fails the scan job).
        try:
            from . import github
            github.report_tm_to_pr(repo, gh_ctx, report, rid,
                                   changed_files=staged, log=log)
        except Exception as exc:
            log(f"PR threat-model comment skipped: {exc}")

        return {"report_id": rid, "files": staged}
    finally:
        shutil.rmtree(stage, ignore_errors=True)
