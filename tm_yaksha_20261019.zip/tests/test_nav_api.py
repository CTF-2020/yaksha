"""Portal navigation: portal_nav.py is the single source of truth.

GET /api/v1/nav must mirror it, and every server-rendered navbar (shared
_portal_nav.html partial and the index.html topbar) must render from it —
so a tab added or renamed in portal_nav.py shows up everywhere at once.
"""
from __future__ import annotations

import unittest

import app as tm_app
import portal_nav


EXPECTED_LABELS = ["Overview", "Analyse", "Triage", "Code", "Integrations",
                   "Rules", "AIBOM"]


class NavApiTests(unittest.TestCase):
    def setUp(self):
        self.client = tm_app.app.test_client()

    def _public_items(self):
        """NAV_ITEMS as an anonymous/non-admin caller should see them —
        admin_only tabs are filtered server-side (app.py's context
        processor, api/nav.py) since the page itself 403s for non-admins."""
        return [i for i in portal_nav.NAV_ITEMS if not i.get("admin_only")]

    def test_nav_endpoint_returns_items_and_use_cases(self):
        r = self.client.get("/api/v1/nav")
        self.assertEqual(r.status_code, 200)
        data = r.get_json()
        self.assertTrue(data["success"])
        self.assertEqual([i["label"] for i in data["items"]], EXPECTED_LABELS)
        self.assertEqual(data["items"], self._public_items())
        self.assertEqual(data["use_cases"], portal_nav.USE_CASES)
        self.assertEqual(data["manifest"], "/api/v1")

    def test_every_nav_api_base_is_a_live_endpoint(self):
        """Each tab's advertised API base must answer (GET base or a probe
        under it), so the nav API never advertises a dead surface."""
        probes = {"/api/v1/reports": "/api/v1/reports",
                  "/api/v1/analysis": "/api/v1/analysis/jobs"}  # POST-only group
        for item in portal_nav.NAV_ITEMS:
            for base in item["api"]:
                probe = probes.get(base, base)
                r = self.client.get(probe)
                # POST-only probe answers 405 (route exists); an admin_only base
                # correctly 401s anonymous instead of 200/405 (see test_admin.py).
                expect = (401,) if item.get("admin_only") else (200, 405)
                self.assertIn(r.status_code, expect, f"{item['key']}: {probe} -> {r.status_code}")

    def test_nav_items_are_well_formed(self):
        for item in portal_nav.NAV_ITEMS:
            self.assertTrue(item["key"])
            self.assertTrue(item["label"])
            self.assertTrue(item["path"].startswith("/"))
            self.assertTrue(item["api"], item["key"])
            for base in item["api"]:
                self.assertTrue(base.startswith("/api/v1/"), base)
        self.assertEqual(len({i["key"] for i in portal_nav.NAV_ITEMS}),
                         len(portal_nav.NAV_ITEMS))
        for uc in portal_nav.USE_CASES:
            self.assertTrue(uc["key"] and uc["name"] and uc["desc"])

    def test_portal_pages_render_nav_from_shared_data(self):
        for path in ("/broker", "/rules", "/"):
            html = self.client.get(path).get_data(as_text=True)
            for item in self._public_items():
                self.assertIn(f'href="{item["path"]}"', html, path)
                self.assertIn(item["label"], html, path)

    def test_index_topbar_renders_nav_and_use_cases(self):
        html = self.client.get("/reports").get_data(as_text=True)
        for item in self._public_items():
            self.assertIn(f'href="{item["path"]}"', html)
        for uc in portal_nav.USE_CASES:
            self.assertIn(f"fillUseCase('{uc['key']}')", html)
            self.assertIn(uc["desc"], html)

    def test_templates_have_no_hardcoded_tab_list(self):
        from pathlib import Path
        root = Path(tm_app.__file__).parent / "templates"
        for name in ("_portal_nav.html", "index.html"):
            src = (root / name).read_text(encoding="utf-8")
            self.assertIn("portal_nav_items", src, name)
            self.assertNotIn('<a href="/broker">SAST</a>', src, name)


if __name__ == "__main__":
    unittest.main()
