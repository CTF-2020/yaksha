"""Flat cross-report triage worklist API + page.

Routes:
  GET /api/v1/triage             filtered/sorted/paginated findings queue
                                 (?severity, ?family, ?methodology, ?verdict, ?ssvc_action,
                                  ?owner, ?q, ?sort, ?order, ?page, ?per_page, ?include_suppressed)
  GET /api/v1/triage/export.csv    the same filters, unpaginated, as a CSV download
  GET /api/v1/triage/export.sarif  the same filters, unpaginated, as a SARIF 2.1.0
                                    document (e.g. for a verdict-scoped upload to
                                    GitHub/GitLab code scanning)
  GET /triage                     the worklist UI page (separate un-prefixed page bp)

Owner-assignment CRUD lives in api/ownership.py, not here -- this module stays
read/query-only, same split reports.py (read) vs suppressions.py (write) uses.
"""
from __future__ import annotations

import json

from flask import Blueprint, Response, jsonify, render_template, request

import report_db
import sarif
import triage

bp = Blueprint("triage_api", __name__, url_prefix="/api/v1/triage")
page_bp = Blueprint("triage_page", __name__)


def _sort_order_from_request():
    """Shared ?sort/?order parsing for both the JSON queue and the CSV export
    -- returns (sort, order, error_response_or_None)."""
    order = request.args.get("order", "asc")
    if order not in ("asc", "desc"):
        order = "asc"
    sort = request.args.get("sort") or triage.DEFAULT_SORT
    if sort not in triage.SORT_KEYS:
        return None, None, (jsonify({"success": False,
                            "error": f"sort must be one of {sorted(triage.SORT_KEYS)}"}), 400)
    return sort, order, None


def _filters_from_request():
    return {
        "severity": request.args.get("severity") or None,
        "family": request.args.get("family") or None,
        "methodology": request.args.get("methodology") or None,
        "verdict": request.args.get("verdict") if "verdict" in request.args else None,
        "ssvc_action": request.args.get("ssvc_action") if "ssvc_action" in request.args else None,
        "owner": request.args.get("owner") if "owner" in request.args else None,
        "q": request.args.get("q") or None,
        "include_suppressed": request.args.get("include_suppressed") == "1",
    }


@bp.get("/methodologies")
def methodologies():
    return jsonify({"success": True, "methodologies": report_db.methodologies()})


@bp.get("")
def list_queue():
    try:
        page = int(request.args.get("page", 1))
        per_page = int(request.args.get("per_page", 50))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "page/per_page must be integers"}), 400

    sort, order, err = _sort_order_from_request()
    if err:
        return err

    result = triage.queue(sort=sort, order=order, page=page, per_page=per_page,
                          **_filters_from_request())
    result["success"] = True
    return jsonify(result)


@bp.get("/export.csv")
def export_csv():
    """The current filter set (same query params as the JSON queue, minus
    pagination) rendered as a CSV download -- for pulling a verdict-scoped
    finding list into a spreadsheet or GRC tool."""
    sort, order, err = _sort_order_from_request()
    if err:
        return err

    rows = triage.export_rows(sort=sort, order=order, **_filters_from_request())
    csv_data = triage.to_csv(rows)
    return Response(csv_data, mimetype="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="triage_findings.csv"'})


@bp.get("/export.sarif")
def export_sarif():
    """The current filter set (same query params as the JSON queue, minus
    pagination) rendered as SARIF 2.1.0 -- for pulling a verdict-scoped
    finding list into GitHub/GitLab code scanning or an IDE, as a single run
    spanning every matching report rather than one report at a time."""
    sort, order, err = _sort_order_from_request()
    if err:
        return err

    rows = triage.export_rows(sort=sort, order=order, **_filters_from_request())
    doc = sarif.to_sarif_rows(rows)
    return Response(json.dumps(doc, indent=2), mimetype="application/sarif+json",
                    headers={"Content-Disposition": 'attachment; filename="triage_findings.sarif"'})


@page_bp.get("/triage")
def triage_page():
    from app import _CSRF_TOKEN
    return render_template("triage.html", csrf_token=_CSRF_TOKEN)
