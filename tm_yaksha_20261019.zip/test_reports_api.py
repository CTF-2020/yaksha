"""Tests for the structured, HTML-safe reports API (/api/v1/reports/*).

Covers the pure normalization/sanitization layer and the Flask surface, with a
focus on the security property: untrusted finding content (a SAST snippet is repo
file content; an /import report is fully attacker-controlled) must come back
HTML-escaped from every structure endpoint, so a consumer cannot be XSS'd.

Run:  python -m unittest test_reports_api
"""
from __future__ import annotations

import unittest

import report_view


def _malicious_report() -> dict:
    payload = "<img src=x onerror=alert(1)>"
    return {
        # methodology must be non-sast: SAST reports are gated to /api/v1/sast
        # and would 404 on the general structure routes under test here.
        "id": "rpt_test", "title": f"Report {payload}", "methodology": "owasp",
        "overall_risk": "High", "analyzed_at": "2026-07-17T00:00:00Z",
        "summary": f"summary {payload}",
        "categories": [
            {"id": "PY-SQL-001", "name": f"SQL Injection {payload}", "risk": "High",
             "_source": "SAST", "cwe": "CWE-89", "owasp": "WEB-A03",
             "risk_score": 7, "remediation": f"fix {payload}",
             "affected_components": [f"services/x.py:42 {payload}"],
             "threats": [{"name": "services/x.py:42",
                          "description": f"cursor.execute({payload})",
                          "attack_vector": f"av {payload}"}]},
        ],
    }


class TestReportView(unittest.TestCase):
    def test_normalize_escapes_untrusted(self):
        s = report_view.normalize_structure(_malicious_report())
        blob = str(s)
        self.assertNotIn("<img", blob)          # no raw markup anywhere
        self.assertIn("&lt;img", blob)          # it is entity-encoded
        self.assertEqual(s["category_count"], 1)
        cat = s["categories"][0]
        self.assertEqual(cat["risk"], "High")
        self.assertEqual(cat["risk_score"], 7)
        self.assertEqual(cat["threat_count"], 1)

    def test_flat_findings_parse_path_line(self):
        findings = report_view.flat_findings(_malicious_report())
        self.assertEqual(len(findings), 1)
        f = findings[0]
        self.assertEqual(f["path"], "services/x.py")
        self.assertEqual(f["line"], 42)
        self.assertNotIn("<img", str(f))

    def test_extract_paths_unique_and_safe(self):
        paths = report_view.extract_paths(_malicious_report())
        self.assertTrue(paths)
        self.assertNotIn("<img", str(paths))

    def test_sanitize_report_deep_escapes(self):
        clean = report_view.sanitize_report(_malicious_report())
        self.assertNotIn("<img", str(clean))
        self.assertIn("&lt;img", str(clean))
        # structure/shape preserved (still one category, non-string types intact)
        self.assertEqual(len(clean["categories"]), 1)
        self.assertEqual(clean["categories"][0]["risk_score"], 7)

    def test_html_escape_covers_quote(self):
        self.assertEqual(report_view.html_escape("a'\"<>&"),
                         "a&#39;&quot;&lt;&gt;&amp;")


class TestReportsApiRoutes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.rid = tm_app._save_report(_malicious_report(), "Report <x>")

    @classmethod
    def tearDownClass(cls):
        cls.client.delete(f"/api/v1/reports/{cls.rid}",
                          headers={"X-CSRF-Token": cls.tm._CSRF_TOKEN})

    def test_structure_route(self):
        r = self.client.get(f"/api/v1/reports/{self.rid}/structure")
        self.assertEqual(r.status_code, 200)
        body = r.get_json()
        self.assertTrue(body["success"])
        self.assertEqual(body["structure"]["category_count"], 1)
        self.assertNotIn("<img", r.get_data(as_text=True))

    def test_findings_route(self):
        r = self.client.get(f"/api/v1/reports/{self.rid}/findings")
        self.assertEqual(r.status_code, 200)
        body = r.get_json()
        self.assertGreaterEqual(body["count"], 1)
        self.assertEqual(body["findings"][0]["line"], 42)

    def test_paths_route(self):
        r = self.client.get(f"/api/v1/reports/{self.rid}/paths")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.get_json()["paths"])

    def test_safe_route_escapes(self):
        r = self.client.get(f"/api/v1/reports/{self.rid}/safe")
        self.assertEqual(r.status_code, 200)
        self.assertNotIn("<img", r.get_data(as_text=True))

    def test_bad_id_rejected(self):
        r = self.client.get("/api/v1/reports/..%2fetc/structure")
        self.assertIn(r.status_code, (400, 404))

    def test_missing_report_404(self):
        r = self.client.get("/api/v1/reports/9999_deadbeef/structure")
        self.assertEqual(r.status_code, 404)

    def test_shared_route_valid_token(self):
        token = self.tm.report_db.get_report(self.rid)["share_token"]
        r = self.client.get(f"/api/v1/reports/{self.rid}/shared?token={token}")
        self.assertEqual(r.status_code, 200)
        body = r.get_json()
        self.assertTrue(body["success"])
        self.assertNotIn("<img", r.get_data(as_text=True))
        self.assertNotIn("share_token", body["report"])

    def test_shared_route_wrong_token(self):
        r = self.client.get(f"/api/v1/reports/{self.rid}/shared?token=wrong")
        self.assertEqual(r.status_code, 403)

    def test_shared_route_missing_token(self):
        r = self.client.get(f"/api/v1/reports/{self.rid}/shared")
        self.assertEqual(r.status_code, 403)

    def test_shared_route_bad_id(self):
        r = self.client.get("/api/v1/reports/..%2fetc/shared?token=x")
        self.assertIn(r.status_code, (400, 404))

    def test_shared_route_missing_report(self):
        r = self.client.get("/api/v1/reports/9999_deadbeef/shared?token=x")
        self.assertEqual(r.status_code, 404)

    def test_shared_route_bypasses_global_api_key(self):
        self.tm._TM_API_KEY = "master-secret"
        try:
            token = self.tm.report_db.get_report(self.rid)["share_token"]
            r = self.client.get(f"/api/v1/reports/{self.rid}/shared?token={token}")
            self.assertEqual(r.status_code, 200)
            # same report, no token/bearer at all -> still gated normally
            r2 = self.client.get(f"/api/v1/reports/{self.rid}")
            self.assertEqual(r2.status_code, 401)
        finally:
            self.tm._TM_API_KEY = ""


if __name__ == "__main__":
    unittest.main(verbosity=2)
