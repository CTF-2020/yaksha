"""Tests for the code-derived threat modeling engine.

Run:  python -m unittest test_codemodel   (stdlib only)

Covers the three layers: the AST extractor (entry points, controls, sinks,
secrets, stores), the cross-file join (call-graph sink reachability, Django URL
linking), and the threat derivation (auth-aware severity, family tagging) plus
the report mapper.
"""
from __future__ import annotations

import os
import tempfile
import unittest

from codemodel import business_impact, extractor, threats
from codemodel import python_extractor as px


FLASK_APP = '''
import os, sqlite3, requests
from flask import Flask, request
from flask_login import login_required
app = Flask(__name__)
DB_PASSWORD = "hunter2"
API_KEY = os.getenv("API_KEY")

@app.route("/public/search")
def search():
    q = request.args.get("q")
    sqlite3.connect("a.db").execute("SELECT * FROM u WHERE n='%s'" % q)
    return "ok"

@app.route("/admin/delete", methods=["POST"])
@login_required
def delete():
    fetch(request.args.get("url"))
    return "ok"

@app.route("/hook", methods=["POST"])
def hook():
    os.system("sh " + request.form["c"])
    return "ok"

def fetch(u):
    return requests.get(u)
'''

FASTAPI_APP = '''
from fastapi import FastAPI, Depends
app = FastAPI()

def get_current_user():
    ...

@app.get("/me")
def me(user=Depends(get_current_user)):
    return user

@app.post("/items")
def create(item):
    return item
'''


class TestExtractorUnit(unittest.TestCase):
    def test_flask_routes_and_controls(self):
        f = px.analyze_python_source(FLASK_APP, "app.py")
        self.assertIn("flask", f.frameworks)
        routes = {fn.route_path: fn for fn in f.functions.values() if fn.is_route}
        self.assertEqual(set(routes), {"/public/search", "/admin/delete", "/hook"})
        self.assertTrue(any(c.kind == "auth" for c in routes["/admin/delete"].controls))
        self.assertFalse(any(c.kind == "auth" for c in routes["/public/search"].controls))

    def test_sinks_and_taint(self):
        f = px.analyze_python_source(FLASK_APP, "app.py")
        hook = next(fn for fn in f.functions.values() if fn.route_path == "/hook")
        self.assertTrue(any(s.kind == "command" and s.tainted for s in hook.sinks))

    def test_secret_classification(self):
        f = px.analyze_python_source(FLASK_APP, "app.py")
        names = {s.name: s.managed for s in f.secrets}
        self.assertFalse(names.get("DB_PASSWORD"))   # hardcoded
        self.assertTrue(names.get("API_KEY"))         # from os.getenv

    def test_fastapi_depends_is_auth(self):
        f = px.analyze_python_source(FASTAPI_APP, "app.py")
        me = next(fn for fn in f.functions.values() if fn.route_path == "/me")
        self.assertTrue(any(c.kind == "auth" for c in me.controls))

    def test_request_object_not_external_call(self):
        # Flask's request.args.get must not be mistaken for an outbound HTTP call.
        f = px.analyze_python_source(FLASK_APP, "app.py")
        self.assertEqual([e for e in f.external_calls if e.kind == "http"], [])

    def test_self_method_call_recorded_in_call_graph(self):
        # Regression: the call-graph recorder used to only handle bare
        # ast.Name calls (`helper()`), so `self.run(...)` was invisible and
        # sink reachability through same-class method dispatch was missed.
        src = '''
class Handler:
    def do(self, x):
        self.run(x)

    def run(self, cmd):
        pass
'''
        f = px.analyze_python_source(src, "h.py")
        self.assertIn("run", f.functions["do"].calls)

    def test_cls_method_call_recorded_in_call_graph(self):
        src = '''
class Handler:
    @classmethod
    def do(cls, x):
        cls.run(x)

    @classmethod
    def run(cls, cmd):
        pass
'''
        f = px.analyze_python_source(src, "h.py")
        self.assertIn("run", f.functions["do"].calls)

    def test_import_map_resolves_aliases_and_from_imports(self):
        src = '''
import requests
import yaml as y
from flask_login import login_required
'''
        f = px.analyze_python_source(src, "app.py")
        self.assertEqual(f.import_map["requests"], "requests")
        self.assertEqual(f.import_map["y"], "yaml")
        self.assertEqual(f.import_map["login_required"], "flask_login")

    def test_dep_call_tracked_even_without_matching_sink_pattern(self):
        # yaml.safe_load isn't in the SINKS table (only bare "load"/"loads"
        # are) — this is exactly the gap dep-call tracking closes: a
        # vulnerable-dependency finding must be checkable for reachability
        # even when the call never matches a hardcoded dangerous-sink shape.
        src = '''
import yaml as y

def parse(raw):
    return y.safe_load(raw)
'''
        f = px.analyze_python_source(src, "app.py")
        parse = f.functions["parse"]
        self.assertEqual(parse.sinks, [])
        self.assertEqual(len(parse.dep_calls), 1)
        self.assertEqual(parse.dep_calls[0].root, "yaml")
        self.assertEqual(parse.dep_calls[0].name, "y.safe_load")

    def test_arbitrary_object_method_call_not_recorded(self):
        # Only self./cls. dispatch is recorded — an arbitrary object's method
        # call has no type info to safely resolve, so recording it would add
        # false call-graph edges (e.g. colliding with an unrelated same-named
        # method elsewhere) rather than real ones.
        src = '''
def handler(worker):
    worker.run("x")
'''
        f = px.analyze_python_source(src, "h.py")
        self.assertNotIn("run", f.functions["handler"].calls)


class TestModelJoin(unittest.TestCase):
    def _model(self):
        d = tempfile.mkdtemp(prefix="cm_test_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(FLASK_APP)
        return extractor.build_model(d)

    def test_entry_points_and_auth(self):
        m = self._model()
        st = m.stats()
        self.assertEqual(st["entry_points"], 3)
        self.assertEqual(st["authenticated_entry_points"], 1)

    def test_cross_function_sink_reachability(self):
        # /admin/delete -> fetch() -> requests.get(tainted) : SSRF one hop away.
        m = self._model()
        delete = next(e for e in m.entry_points if e.path == "/admin/delete")
        ssrf = [s for s in delete.reachable_sinks if s.family == "ssrf"]
        self.assertTrue(ssrf)
        self.assertEqual(ssrf[0].hops, 1)

    def test_trust_boundaries_inferred(self):
        m = self._model()
        kinds = {b.kind for b in m.trust_boundaries}
        self.assertIn("network", kinds)       # client <-> app
        self.assertIn("persistence", kinds)    # data store
        self.assertIn("privilege", kinds)      # os.system reachable

    def test_reachability_crosses_self_method_dispatch(self):
        # A route method that dispatches to a sink via self.<method>() must
        # be reported reachable, not just a route that calls a bare function.
        src = '''
import os
from flask import Flask, request
app = Flask(__name__)

class Hook:
    @app.route("/hook", methods=["POST"])
    def post(self):
        self._run(request.form["c"])
        return "ok"

    def _run(self, cmd):
        os.system(cmd)
'''
        d = tempfile.mkdtemp(prefix="cm_self_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(src)
        m = extractor.build_model(d)
        hook = next(e for e in m.entry_points if e.path == "/hook")
        self.assertTrue(any(s.family == "command-injection" for s in hook.reachable_sinks))

    def test_reachable_deps_crosses_call_graph(self):
        # /admin/delete -> fetch() -> requests.get(tainted): a reachable
        # dependency call one hop away, independent of it also being an SSRF
        # sink.
        m = self._model()
        delete = next(e for e in m.entry_points if e.path == "/admin/delete")
        reqs = [d for d in delete.reachable_deps if d.root == "requests"]
        self.assertTrue(reqs)
        self.assertEqual(reqs[0].hops, 1)

    def test_reachable_deps_includes_non_sink_calls(self):
        # A dependency call that doesn't match any Sink pattern (yaml.safe_load)
        # must still surface in reachable_deps, unlike reachable_sinks.
        src = '''
import yaml as y
from flask import Flask
app = Flask(__name__)

@app.route("/import", methods=["POST"])
def do_import():
    return str(y.safe_load("x"))
'''
        d = tempfile.mkdtemp(prefix="cm_dep_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(src)
        m = extractor.build_model(d)
        ep = next(e for e in m.entry_points if e.path == "/import")
        self.assertEqual(ep.reachable_sinks, [])
        self.assertTrue(any(dep.root == "yaml" for dep in ep.reachable_deps))

    def test_bom_prefixed_source_is_still_parsed(self):
        # A UTF-8 BOM (common in Windows-authored files) must not make the
        # extractor silently drop the file — its routes/sinks must still model.
        d = tempfile.mkdtemp(prefix="cm_bom_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8-sig") as fh:
            fh.write(FLASK_APP)                 # utf-8-sig writes a leading BOM
        m = extractor.build_model(d)
        self.assertEqual(m.parse_errors, [])
        self.assertEqual(m.stats()["entry_points"], 3)


class TestThreatDerivation(unittest.TestCase):
    def _cats(self):
        d = tempfile.mkdtemp(prefix="cm_test_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(FLASK_APP)
        return threats.derive(extractor.build_model(d))

    def test_unauth_command_injection_is_critical(self):
        cats = self._cats()
        cmd = next(c for c in cats if c["family"] == "command-injection")
        self.assertEqual(cmd["risk"], "Critical")   # unauth + tainted -> escalated
        self.assertEqual(cmd["cwe"], "CWE-78")
        self.assertEqual(cmd["_source"], "CODEMODEL")

    def test_hardcoded_secret_finding(self):
        cats = self._cats()
        self.assertTrue(any(c["family"] == "sensitive-data-exposure" for c in cats))

    def test_findings_carry_owasp_and_stride(self):
        cats = self._cats()
        sqli = next(c for c in cats if c["family"] == "sql-injection")
        self.assertEqual(sqli["owasp"], "WEB-A03")
        self.assertIn("Tampering", sqli["stride"])

    def test_unauth_tainted_sink_carries_reachability_facts(self):
        # /hook is unauthenticated, os.system() gets tainted input, in the
        # handler body — the exploitability engine needs all four facts.
        cats = self._cats()
        cmd = next(c for c in cats if c["family"] == "command-injection")
        r = cmd["reachability"]
        self.assertTrue(r["confirmed"])
        self.assertTrue(r["unauthenticated"])
        self.assertTrue(r["tainted"])
        self.assertEqual(r["min_hops"], 0)
        self.assertFalse(r["agent_tool"])

    def test_authenticated_sink_reachability_is_not_unauthenticated(self):
        # /admin/delete is @login_required and reaches fetch() one hop away.
        cats = self._cats()
        ssrf = next(c for c in cats if c["family"] == "ssrf")
        r = ssrf["reachability"]
        self.assertTrue(r["confirmed"])
        self.assertFalse(r["unauthenticated"])
        self.assertGreaterEqual(r["min_hops"], 1)


AGENT_APP = '''
import os
import openai
from langchain.tools import tool

client = openai.OpenAI()

@tool
def run_shell(cmd: str) -> str:
    """Run a shell command."""
    os.system(cmd)
    return "done"

@tool
def safe_lookup(key: str) -> str:
    validate(key)
    return key

@tool
def get_time() -> str:
    return "12:00"

def validate(k):
    ...

def ask_llm(prompt):
    return client.chat.completions.create(model="gpt-4",
                                           messages=[{"role": "user", "content": prompt}])

def call_agent(query):
    # must NOT be misread as os.system-style command execution (generic
    # ".run(" collision with subprocess.run)
    agent.run(query)
'''


class TestAgenticDetection(unittest.TestCase):
    def _model(self):
        d = tempfile.mkdtemp(prefix="cm_agent_")
        with open(os.path.join(d, "agent_app.py"), "w", encoding="utf-8") as fh:
            fh.write(AGENT_APP)
        return extractor.build_model(d)

    def test_tool_decorated_functions_become_agent_tool_entry_points(self):
        m = self._model()
        tool_eps = [e for e in m.entry_points if e.kind == "agent-tool"]
        self.assertEqual({e.path for e in tool_eps},
                         {"run_shell", "safe_lookup", "get_time"})
        self.assertTrue(all(not e.authenticated for e in tool_eps))

    def test_dangerous_sink_reachable_from_tool_is_tagged_llm06(self):
        m = self._model()
        cats = threats.derive(m)
        cmd = next(c for c in cats if c["family"] == "command-injection")
        self.assertEqual(cmd["risk"], "Critical")
        self.assertEqual(cmd.get("owasp_llm"), "LLM06")
        self.assertTrue(cmd.get("agentic"))

    def test_tool_without_sink_or_validation_flagged_excessive_agency(self):
        m = self._model()
        cats = threats.derive(m)
        agency = next(c for c in cats if c["family"] == "excessive-agency")
        comps = " ".join(agency["affected_components"])
        self.assertIn("get_time", comps)
        self.assertNotIn("safe_lookup", comps)   # has a validation control
        self.assertNotIn("run_shell", comps)     # already covered (higher severity) above

    def test_llm_call_recorded_as_external_call(self):
        m = self._model()
        self.assertTrue(any(c.kind == "llm" for c in m.external_calls))

    def test_llm_provider_trust_boundary_inferred(self):
        m = self._model()
        self.assertTrue(any(b.name == "Application ↔ LLM provider" for b in m.trust_boundaries))


class TestBusinessImpactClassifier(unittest.TestCase):
    """Unit tests for the keyword tier classifier itself (no model building)."""

    def test_critical_tier_payment_keyword(self):
        impact = business_impact.classify("/api/payments/charge", "charge.py")
        self.assertEqual(impact["tier"], "critical")
        self.assertEqual(impact["score"], 1.0)
        self.assertIn("payment", impact["reason"])

    def test_high_tier_user_keyword(self):
        impact = business_impact.classify("/api/users/export", "user_export.py")
        self.assertEqual(impact["tier"], "high")

    def test_medium_tier_order_keyword(self):
        impact = business_impact.classify("/api/orders/list", "orders.py")
        self.assertEqual(impact["tier"], "medium")

    def test_low_tier_logging_keyword(self):
        impact = business_impact.classify("/internal/healthcheck", "healthcheck.py")
        self.assertEqual(impact["tier"], "low")

    def test_no_match_returns_none(self):
        self.assertIsNone(business_impact.classify("/public/search", "search.py"))
        self.assertIsNone(business_impact.classify())

    def test_word_boundary_avoids_false_positive(self):
        # "orderly"/"cardigan" must not match "order"/"card" as substrings.
        self.assertIsNone(business_impact.classify("/api/orderly-queue"))
        self.assertIsNone(business_impact.classify("cardigan_store.py"))

    def test_highest_tier_wins_when_multiple_keywords_match(self):
        # "payment" (critical) and "user" (high) both appear -- critical wins.
        impact = business_impact.classify("/api/payment_user_export")
        self.assertEqual(impact["tier"], "critical")


class TestBusinessImpactGraphProximity(unittest.TestCase):
    """Unit tests for the call-graph proximity variant, nearest_match()."""

    def test_hop_zero_matches_classify_exactly(self):
        # A hop-0 candidate is exactly what classify() would find on that
        # same text -- nearest_match must be a strict superset, not a
        # different heuristic.
        direct = business_impact.classify("/api/payments/charge", "charge.py")
        proximity = business_impact.nearest_match(
            [("/api/payments/charge charge.py", 0)])
        self.assertEqual(proximity["tier"], direct["tier"])
        self.assertEqual(proximity["score"], direct["score"])
        self.assertEqual(proximity["hops"], 0)

    def test_indirect_hit_scores_lower_than_direct_hit_same_tier(self):
        direct = business_impact.nearest_match([("payments charge.py", 0)])
        indirect = business_impact.nearest_match([("payments charge.py", 2)])
        self.assertEqual(direct["tier"], indirect["tier"])
        self.assertLess(indirect["score"], direct["score"])
        self.assertIn("call graph", indirect["reason"])

    def test_worse_tier_wins_even_when_farther_away(self):
        # A CRITICAL hit 2 hops out beats a HIGH hit right at hop 0 -- tier
        # always dominates hop distance.
        result = business_impact.nearest_match([
            ("/api/users/export", 0),    # high, hop 0
            ("payment_helper.py", 2),    # critical, hop 2
        ])
        self.assertEqual(result["tier"], "critical")
        self.assertEqual(result["hops"], 2)

    def test_closest_hop_wins_within_same_tier(self):
        result = business_impact.nearest_match([
            ("payment_a.py", 2),
            ("payment_b.py", 1),
        ])
        self.assertEqual(result["hops"], 1)

    def test_no_candidates_or_no_match_returns_none(self):
        self.assertIsNone(business_impact.nearest_match([]))
        self.assertIsNone(business_impact.nearest_match(
            [("", 0), ("/public/search", 1)]))


PAYMENTS_APP = '''
import sqlite3
from flask import Flask, request
app = Flask(__name__)

@app.route("/api/payments/charge", methods=["POST"])
def charge():
    card = request.form["card"]
    sqlite3.connect("a.db").execute("SELECT * FROM cards WHERE n='%s'" % card)
    return "ok"
'''


class TestBusinessImpactInThreatDerivation(unittest.TestCase):
    def _cats(self, source):
        d = tempfile.mkdtemp(prefix="cm_impact_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(source)
        return threats.derive(extractor.build_model(d))

    def test_payments_route_tagged_critical_business_impact(self):
        cats = self._cats(PAYMENTS_APP)
        sqli = next(c for c in cats if c["family"] == "sql-injection")
        self.assertEqual(sqli["business_impact"]["tier"], "critical")
        self.assertGreater(sqli["business_impact"]["score"], 0.0)

    def test_route_without_keyword_carries_no_business_impact(self):
        # FLASK_APP's /public/search SQLi has no matching asset/route keyword,
        # so the field must be absent, not defaulted -- same convention as
        # "reachability" being absent (not "safe") when there is no evidence.
        cats = self._cats(FLASK_APP)
        sqli = next(c for c in cats if c["family"] == "sql-injection")
        self.assertNotIn("business_impact", sqli)

    def test_indirect_payment_touch_detected_via_call_graph_hop(self):
        # /api/v2/process names nothing sensitive itself, but one call hop
        # away it reaches charge_customer_card() -- a keyword-matching
        # helper the old name-only heuristic could never see, since it only
        # ever looked at the finding's own route/handler/file/sink text.
        src = '''
import sqlite3
from flask import Flask, request
app = Flask(__name__)

def charge_customer_card(card):
    sqlite3.connect("a.db").execute("SELECT * FROM cards WHERE n='%s'" % card)

@app.route("/api/v2/process", methods=["POST"])
def process():
    card = request.form["card"]
    charge_customer_card(card)
    return "ok"
'''
        cats = self._cats(src)
        sqli = next(c for c in cats if c["family"] == "sql-injection")
        impact = sqli["business_impact"]
        self.assertEqual(impact["tier"], "critical")
        self.assertEqual(impact["hops"], 1)
        self.assertIn("call graph", impact["reason"])
        # same tier as a direct hit, but discounted for being indirect
        self.assertLess(impact["score"], 1.0)

    def test_open_endpoint_impact_reaches_through_helper_call(self):
        # Section 2 (unauthenticated state-changing endpoint, no dangerous
        # sink of its own) must also pick up graph-proximity impact, not
        # just the sink-bearing section 1 path.
        src = '''
from flask import Flask, request
app = Flask(__name__)

def touch_billing_ledger():
    return True

@app.route("/api/v3/update", methods=["POST"])
def update():
    touch_billing_ledger()
    return "ok"
'''
        cats = self._cats(src)
        gap = next(c for c in cats if c["family"] == "broken-access-control")
        self.assertEqual(gap["business_impact"]["tier"], "critical")
        self.assertGreaterEqual(gap["business_impact"]["hops"], 1)

    def test_unvalidated_tool_impact_reaches_through_helper_call(self):
        # Section 6 (LLM tool with no validation/sink) must also pick up
        # graph-proximity impact via its own reachable_impact wiring.
        src = '''
from langchain.tools import tool

def access_user_wallet_balance():
    return 0

@tool
def check_balance() -> int:
    return access_user_wallet_balance()
'''
        d = tempfile.mkdtemp(prefix="cm_tool_impact_")
        with open(os.path.join(d, "agent_app.py"), "w", encoding="utf-8") as fh:
            fh.write(src)
        cats = threats.derive(extractor.build_model(d))
        agency = next(c for c in cats if c["family"] == "excessive-agency")
        self.assertEqual(agency["business_impact"]["tier"], "critical")
        self.assertGreaterEqual(agency["business_impact"]["hops"], 1)

    def test_worst_impact_wins_across_multiple_entry_points_in_a_family(self):
        # Two routes reach the same sql-injection family: one named
        # /public/search (no keyword), one named /api/payments/charge
        # (critical). The merged business_impact for the shared family
        # category must reflect the worst of the two, not just the first.
        src = FLASK_APP + '''
@app.route("/api/payments/charge", methods=["POST"])
def charge():
    q = request.form["q"]
    sqlite3.connect("a.db").execute("SELECT * FROM u WHERE n='%s'" % q)
    return "ok"
'''
        cats = self._cats(src)
        sqli = next(c for c in cats if c["family"] == "sql-injection")
        self.assertEqual(sqli["business_impact"]["tier"], "critical")

    def test_generic_dot_run_is_not_misread_as_command_injection(self):
        # agent.run(query) must not create a false-positive command-injection
        # sink the way subprocess.run(...) legitimately does.
        f = px.analyze_python_source(AGENT_APP, "agent_app.py")
        call_agent = f.functions["call_agent"]
        self.assertFalse(any(s.family == "command-injection" for s in call_agent.sinks))

    def test_subprocess_run_still_flagged(self):
        src = "import subprocess\ndef h(cmd):\n    subprocess.run(cmd, shell=True)\n"
        f = px.analyze_python_source(src, "h.py")
        h = f.functions["h"]
        self.assertTrue(any(s.family == "command-injection" for s in h.sinks))


class TestCorrelatorInterop(unittest.TestCase):
    def test_codemodel_findings_count_as_code_source(self):
        # A codemodel report should correlate as CODE and, with a design report,
        # produce a corroborated verdict rather than a blind spot.
        from correlator import engine
        from correlator.model import SourceKind, Verdict
        d = tempfile.mkdtemp(prefix="cm_test_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(FLASK_APP)
        cm_report = {"id": "cm", "title": "CM", "methodology": "codemodel",
                     "categories": threats.derive(extractor.build_model(d))}
        design = {"id": "tm", "title": "TM", "methodology": "owasp",
                  "categories": [{"id": "WEB-A03", "name": "Injection", "risk": "High",
                                  "affected_components": ["search"]}]}
        findings = engine.correlate([cm_report, design])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertIn(SourceKind.CODE, sqli.kinds)
        self.assertIn(SourceKind.DESIGN, sqli.kinds)
        self.assertEqual(sqli.verdict, Verdict.CORROBORATED)

    def test_sbom_finding_scored_via_real_codemodel_report_non_sink_call(self):
        # End-to-end: a real extracted+mapped codemodel report (not a hand
        # built fixture) whose only trace of `yaml` is a non-sink
        # `y.safe_load()` call must still let an SBOM pyyaml finding score as
        # reachable — the actual fix for the earlier sink-only limitation.
        from codemodel import service as cm_service
        from correlator import engine

        src = '''
import yaml as y
from flask import Flask
app = Flask(__name__)

@app.route("/import", methods=["POST"])
def do_import():
    return str(y.safe_load("x"))
'''
        d = tempfile.mkdtemp(prefix="cm_interop_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(src)
        cm_report = cm_service.analyze_path(d, {"id": "repo1", "name": "repo1"})

        sbom_report = {
            "id": "sbom1", "title": "SBOM Analysis — bom.json", "methodology": "SBOM",
            "categories": [{"id": "SBOM-HIGH", "name": "Vulnerable Components — High",
                            "risk": "High", "_source": "SBOM",
                            "affected_components": ["pyyaml@5.3.1"]}],
        }
        findings = engine.correlate([cm_report, sbom_report])
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertGreater(dep.exploitability, 0.0)
        self.assertIn("unauthenticated", dep.exploitability_reason.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
