"""Session/role helpers — the authorization layer app.py's login system
didn't have until now (see api/login.py's docstring: a session used to only
make the UI *feel* signed in). Role is read fresh from users_db on every
check rather than cached in the session, so revoking admin takes effect on
the very next request instead of surviving until the victim's session
expires — the extra SQLite read is negligible next to that.
"""
from __future__ import annotations

from functools import wraps
from urllib.parse import quote

from flask import jsonify, redirect, request, session

import users_db


def current_user_email() -> str | None:
    return session.get("user_email")


def current_user() -> dict | None:
    email = current_user_email()
    return users_db.get_user(email) if email else None


def is_admin() -> bool:
    user = current_user()
    return bool(user and user["role"] == "admin")


def admin_gate():
    """Return a Flask response if the current session isn't an authenticated
    admin, else None so the caller proceeds. Shared by the require_admin
    decorator (single views) and blueprint-wide `before_request` gating
    (api/admin.py, where every route needs the same check).

    No session at all: treated like the global login gate — redirect for a
    page request, 401 JSON for an API request. A valid session that isn't an
    admin gets 403 — never a redirect to /login, since logging in again
    can't grant a privilege the account doesn't have.
    """
    if not current_user_email():
        if request.path.startswith("/api/"):
            return jsonify({"success": False, "error": "Login required"}), 401
        return redirect(f"/login?next={quote(request.path, safe='')}")
    if not is_admin():
        return jsonify({"success": False, "error": "Admin privileges required"}), 403
    return None


def require_admin(view):
    """Decorator form of admin_gate for a single view function."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        resp = admin_gate()
        return resp if resp is not None else view(*args, **kwargs)
    return wrapped
