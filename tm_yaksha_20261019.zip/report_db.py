"""SQLite report store — the system of record for saved reports.

Each report's full JSON is stored in the ``reports.data`` column, so this file
is the primary, queryable database: get/save/delete/list all go through here.
A per-report ``~/.tm_reports/<id>.json`` file is still written as a best-effort
backup (human-readable, and a manual recovery path), but nothing reads from it
in normal operation any more — a stale or missing backup file is harmless.

This was a derived mirror before 2026-07-23 (JSON files were the authority);
:func:`backfill` still exists to import an existing JSON-only install's history
into the database once, on first boot after upgrading.

What a real database buys over a directory of JSON files:

  * **Trends** — severity counts per report over time, per methodology/target.
  * **Cross-scan queries** — "every SQL-injection finding across all scans",
    because each finding is classified to a canonical weakness *family* (the
    same taxonomy the correlator uses) on the way in.
  * **Unbounded, indexed history** — no 200-report scan cap to answer "list".
  * **No path-traversal surface** — a report is looked up by a parameterized
    SQL primary-key match, not a filesystem path built from the id.

Stdlib ``sqlite3`` only — no new dependency. Connection-per-call with WAL and a
busy timeout keeps it safe under the server's worker threads.
"""
from __future__ import annotations

import json
import re
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

DB_PATH = Path.home() / ".tm_reports" / "reports.db"

_SEVERITIES = ("Critical", "High", "Medium", "Low", "Info")
# The correlator's Verdict vocabulary (correlator/model.py), duplicated here
# rather than imported so this module stays independent of the correlator —
# same choice suppressions/model.py and control_register.py already made.
_VERDICTS = ("actively_exploited", "confirmed_exploitable", "corroborated",
            "design_gap", "blind_spot")
_FILE_LINE_RE = re.compile(r"^(?!\w+://)(.+?):(\d+)\b")
_PREFIX_RE = re.compile(r"^\[[^\]]+\]\s*(.+)$")

_init_lock = threading.Lock()


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    # Switching journal mode briefly needs an exclusive lock, so a concurrent
    # writer (another process/thread mid-commit) can make even this setup
    # pragma raise "database is locked" despite the busy_timeout below being
    # set right after — that pragma can't protect a statement that runs
    # before it. Retry the handful of times a transient lock needs to clear.
    for attempt in range(5):
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            break
        except sqlite3.OperationalError:
            if attempt == 4:
                raise
            time.sleep(0.1 * (attempt + 1))
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


_SCHEMA = """
CREATE TABLE IF NOT EXISTS reports (
    id            TEXT PRIMARY KEY,
    title         TEXT,
    methodology   TEXT,
    overall_risk  TEXT,
    analyzed_at   TEXT,
    created_at    REAL,
    target        TEXT,
    finding_count INTEGER DEFAULT 0,
    data          TEXT
);
CREATE TABLE IF NOT EXISTS findings (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id  TEXT NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    rule       TEXT,
    title      TEXT,
    family     TEXT,
    severity   TEXT,
    cwe        TEXT,
    owasp      TEXT,
    source     TEXT,
    locus      TEXT,
    path       TEXT,
    line       INTEGER,
    verdict    TEXT DEFAULT '',
    fingerprint TEXT DEFAULT '',
    ssvc_action TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_reports_method  ON reports(methodology);
CREATE INDEX IF NOT EXISTS ix_reports_created ON reports(created_at);
CREATE INDEX IF NOT EXISTS ix_reports_target  ON reports(target);
CREATE INDEX IF NOT EXISTS ix_findings_report ON findings(report_id);
CREATE INDEX IF NOT EXISTS ix_findings_family ON findings(family);
CREATE INDEX IF NOT EXISTS ix_findings_sev    ON findings(severity);
CREATE INDEX IF NOT EXISTS ix_findings_cwe    ON findings(cwe);
"""


def init() -> None:
    """Ensure the schema exists for the CURRENT DB_PATH. Cheap and idempotent —
    every statement is CREATE-IF-NOT-EXISTS, so this deliberately has no "already
    ran" shortcut to go stale: DB_PATH can change (tests do this; a background
    thread from an unrelated job can also outlive the tmp path it was pointed at
    and find the file gone), and the schema must always be ensured for whatever
    path is current at the moment of the actual read/write, not cached from an
    earlier call that may have been against a different path or a file that no
    longer exists on disk.
    """
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)
            # A database created before the `data` column existed (when this was
            # a derived mirror) needs it added in place — ALTER, not migrated by
            # executescript's CREATE TABLE IF NOT EXISTS.
            cols = {row["name"] for row in conn.execute("PRAGMA table_info(reports)")}
            if "data" not in cols:
                conn.execute("ALTER TABLE reports ADD COLUMN data TEXT")
            # Same idempotent add-once-and-index pattern for a database created
            # before the correlator's verdict was surfaced onto findings — the
            # index has to come after the column exists, so it lives here rather
            # than in _SCHEMA (which would fail on an old table on first run).
            fcols = {row["name"] for row in conn.execute("PRAGMA table_info(findings)")}
            if "verdict" not in fcols:
                conn.execute("ALTER TABLE findings ADD COLUMN verdict TEXT DEFAULT ''")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_findings_verdict ON findings(verdict)")
            # Same idempotent add-once-and-index pattern for a database created
            # before the triage worklist needed a stable, report-independent
            # finding identity for suppression matching (see suppressions.engine).
            if "fingerprint" not in fcols:
                conn.execute("ALTER TABLE findings ADD COLUMN fingerprint TEXT DEFAULT ''")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_findings_fingerprint ON findings(fingerprint)")
            # Same idempotent add-once-and-index pattern for a database created
            # before the SSVC triage action was surfaced onto correlated
            # findings (see correlator/mapper.py, ssvc.py) -- '' for every
            # finding that has never been through correlation, same
            # backward-compat convention as `verdict`.
            if "ssvc_action" not in fcols:
                conn.execute("ALTER TABLE findings ADD COLUMN ssvc_action TEXT DEFAULT ''")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_findings_ssvc ON findings(ssvc_action)")


# ── Derivation ────────────────────────────────────────────────────────────────
def _created_at(report_id: str) -> float:
    """Recover the unix time encoded in a ``<ts>_<seq>_<rand>`` report id."""
    try:
        return float(report_id.split("_", 1)[0])
    except (ValueError, IndexError):
        return 0.0


def _target(report: dict) -> str:
    """Best-effort scan target: repo/host/name, for per-target trends."""
    meta = report.get("scan_metadata") or {}
    for key in ("repo_name", "repo_id", "target", "host", "tool"):
        if meta.get(key):
            return str(meta[key])[:200]
    return str(report.get("title", ""))[:200]


def _split_path_line(locus: str):
    s = str(locus or "").strip()
    m = _PREFIX_RE.match(s)
    if m:
        s = m.group(1).strip()
    m = _FILE_LINE_RE.match(s)
    if m:
        return m.group(1).strip(), int(m.group(2))
    return s, None


def _category_loci(category: dict) -> list[str]:
    loci = [str(t["name"]) for t in category.get("threats", []) or []
            if isinstance(t, dict) and t.get("name")]
    if not loci:
        loci = [str(x) for x in (category.get("affected_components") or []) if x]
    return list(dict.fromkeys(loci)) or [""]


def _derive_findings(report: dict) -> list[tuple]:
    """One row per (category, locus), classified to a weakness family."""
    from correlator import taxonomy            # pure; lazy to keep import graph light
    from suppressions.engine import finding_fingerprint   # pure; lazy, same reason

    rows: list[tuple] = []
    for c in report.get("categories", []) or []:
        if not isinstance(c, dict):
            continue
        title = str(c.get("title") or c.get("name") or c.get("id") or "Finding")
        rule = str(c.get("id") or c.get("category") or "")
        severity = str(c.get("risk") or c.get("severity") or "Info").capitalize()
        if severity not in _SEVERITIES:
            severity = "Info"
        cwes = taxonomy.extract_cwes(str(c.get("cwe", "")),
                                     str(c.get("notes", "")), str(c.get("description", "")))
        owasp = taxonomy.extract_owasp(str(c.get("id", "")), str(c.get("owasp", "")),
                                       f"{title} {c.get('notes', '')}")
        family, _ = taxonomy.resolve_family(title, cwes, owasp,
                                            notes=str(c.get("notes", "")))
        source = str(c.get("_source") or report.get("methodology") or "")
        cwe_str = ", ".join(sorted(cwes, key=lambda x: int(x.split("-")[1]))) if cwes else ""
        # Only correlator-derived categories carry a verdict at all; every
        # other finding (plain SAST/manual/design-only) stores "" here, same
        # backward-compat rule the correlator's consumers already use elsewhere
        # (jira_client.min_verdict, suppressions.max_verdict).
        verdict = str(c.get("verdict") or "")
        # Only correlator-derived categories carry an SSVC action at all (see
        # correlator/mapper.py) -- same backward-compat "" for everything
        # else that `verdict` above already follows.
        ssvc_action = str(c.get("ssvc_action") or "")
        # Computed once per CATEGORY (all its loci folded in), not per row below
        # -- this must match suppressions.engine.finding_fingerprint exactly so
        # a "finding"-scope suppression (stored against the category-level
        # fingerprint) still matches every locus row derived from it.
        fingerprint = finding_fingerprint(c)
        for locus in _category_loci(c):
            path, line = _split_path_line(locus)
            rows.append((rule, title, family, severity, cwe_str, owasp,
                         source, locus, path, line, verdict, fingerprint, ssvc_action))
    return rows


# ── Write path — the primary save/delete for every report ──────────────────────
def upsert_report(report: dict) -> None:
    """Insert or replace one report (full data + derived findings). Requires an id.

    This is the authoritative write — a caller that needs the save to actually
    persist should NOT wrap this in try/except (unlike the best-effort JSON
    backup file, which may fail silently)."""
    rid = str(report.get("id") or "")
    if not rid:
        return
    init()
    rows = _derive_findings(report)
    overall = report.get("aggregate_risk") or report.get("overall_risk") or "?"
    blob = json.dumps(report, ensure_ascii=False)
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM findings WHERE report_id = ?", (rid,))
        conn.execute(
            "INSERT OR REPLACE INTO reports"
            "(id,title,methodology,overall_risk,analyzed_at,created_at,target,finding_count,data)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (rid, str(report.get("title", "")), str(report.get("methodology", "")),
             str(overall), str(report.get("analyzed_at", "")), _created_at(rid),
             _target(report), len(rows), blob))
        conn.executemany(
            "INSERT INTO findings"
            "(report_id,rule,title,family,severity,cwe,owasp,source,locus,path,line,verdict,fingerprint,ssvc_action)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            [(rid, *r) for r in rows])


def get_report(report_id: str) -> dict | None:
    """Fetch one full report by id, or None if it doesn't exist / is unreadable.

    A parameterized primary-key lookup — there is no filesystem path built from
    ``report_id`` here, so this has no path-traversal surface at all."""
    init()
    with closing(_connect()) as conn:
        row = conn.execute("SELECT data FROM reports WHERE id = ?", (report_id,)).fetchone()
    if row is None or not row["data"]:
        return None
    try:
        return json.loads(row["data"])
    except ValueError:
        return None


def all_reports(limit: int = 2000) -> list[dict]:
    """Full report blobs, newest first.

    For callers that need to inspect report CONTENT across many reports (e.g.
    the correlator deciding which reports carry weakness categories) — metadata
    alone (see :func:`list_reports`) isn't enough for that."""
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT data FROM reports ORDER BY created_at DESC, rowid DESC LIMIT ?",
            (max(1, min(limit, 5000)),)).fetchall()
    out = []
    for row in rows:
        if row["data"]:
            try:
                out.append(json.loads(row["data"]))
            except ValueError:
                continue
    return out


def delete_finding(fingerprint: str) -> dict:
    """Hard-delete every category across every report whose finding
    fingerprint matches, and re-persist each affected report.

    Unlike suppression (:mod:`suppressions.engine`), which tags a finding as
    muted at read time without touching stored data, this actually strips the
    category out of the report's own JSON. Every downstream reader (SAST view,
    correlator, triage, dashboard) reads from this same table, so the finding
    disappears everywhere at once rather than needing separate cleanup in each
    subsystem. Irreversible — there is no undo.
    """
    from suppressions.engine import finding_fingerprint
    init()
    fp = str(fingerprint or "").strip()
    affected_ids: list[str] = []
    findings_removed = 0
    if not fp:
        return {"reports_affected": 0, "report_ids": [], "findings_removed": 0}
    for report in all_reports(limit=5000):
        cats = report.get("categories") or []
        kept = [c for c in cats
                if not (isinstance(c, dict) and finding_fingerprint(c) == fp)]
        removed = len(cats) - len(kept)
        if removed:
            report["categories"] = kept
            upsert_report(report)
            affected_ids.append(str(report.get("id", "")))
            findings_removed += removed
    return {"reports_affected": len(affected_ids), "report_ids": affected_ids,
            "findings_removed": findings_removed}


def delete_report(report_id: str) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM reports WHERE id = ?", (report_id,))
        # findings cascade via the FK, but delete explicitly in case a legacy
        # row predates foreign_keys being on.
        conn.execute("DELETE FROM findings WHERE report_id = ?", (report_id,))


def delete_all() -> int:
    """Wipe every report and finding. Returns the number of reports removed —
    used by the admin flush action, which is why this exists as a single
    bulk statement rather than a loop of delete_report calls."""
    init()
    with closing(_connect()) as conn, conn:
        n = conn.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
        conn.execute("DELETE FROM findings")
        conn.execute("DELETE FROM reports")
    return n


def prune_to_limit(limit: int) -> list[str]:
    """Keep only the newest `limit` reports; return the ids of any deleted."""
    init()
    with closing(_connect()) as conn, conn:
        rows = conn.execute(
            "SELECT id FROM reports ORDER BY created_at DESC, rowid DESC LIMIT -1 OFFSET ?",
            (max(0, limit),)).fetchall()
        ids = [r["id"] for r in rows]
        if ids:
            conn.executemany("DELETE FROM reports WHERE id = ?", [(i,) for i in ids])
            conn.executemany("DELETE FROM findings WHERE report_id = ?", [(i,) for i in ids])
    return ids


def prune_to_limit_by_bucket(sast_limit: int, other_limit: int) -> list[str]:
    """Like :func:`prune_to_limit`, but SAST/DAST reports and everything else
    are pruned against their own limit instead of sharing one global pool.

    SAST scans are typically far more frequent than manually-created reviews
    (broker keeps its own job history independently, see
    broker.config.JOB_RETENTION); without this split, a burst of one report
    type evicts the other's history and leaves dangling job -> report links
    (e.g. a broker "open" link 404ing for a scan that's still listed).
    """
    init()
    with closing(_connect()) as conn, conn:
        ids: list[str] = []
        for where, limit in (
            ("methodology IN ('sast', 'dast')", sast_limit),
            ("(methodology NOT IN ('sast', 'dast') OR methodology IS NULL)", other_limit),
        ):
            rows = conn.execute(
                f"SELECT id FROM reports WHERE {where} "
                "ORDER BY created_at DESC, rowid DESC LIMIT -1 OFFSET ?",
                (max(0, limit),)).fetchall()
            ids.extend(r["id"] for r in rows)
        if ids:
            conn.executemany("DELETE FROM reports WHERE id = ?", [(i,) for i in ids])
            conn.executemany("DELETE FROM findings WHERE report_id = ?", [(i,) for i in ids])
    return ids


def report_count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute("SELECT COUNT(*) FROM reports").fetchone()[0]


def backfill(reports: list[dict]) -> int:
    """Import a batch of full report dicts (each with an ``id``). Returns count.

    Used once, on first boot after upgrading a JSON-only install, to bring
    existing ``~/.tm_reports/*.json`` history into the database."""
    n = 0
    for r in reports:
        if isinstance(r, dict) and r.get("id"):
            upsert_report(r)
            n += 1
    return n


# ── Query path (read-only endpoints) ──────────────────────────────────────────
def list_reports(limit: int = 50, methodology: str | None = None,
                 include_sast: bool = False) -> list[dict]:
    init()
    q = ("SELECT id,title,methodology,overall_risk,analyzed_at,created_at,"
         "target,finding_count FROM reports")
    where: list = []
    params: list = []
    if methodology:
        where.append("methodology = ?")
        params.append(methodology)
    if not include_sast:
        # SAST broker and DAST scanner scans are served only under their own
        # tabs (/api/v1/sast, /api/v1/dast) — see app.py.
        where.append("methodology NOT IN ('sast', 'dast')")
    if where:
        q += " WHERE " + " AND ".join(where)
    q += " ORDER BY created_at DESC, rowid DESC LIMIT ?"
    params.append(max(1, min(limit, 1000)))
    with closing(_connect()) as conn:
        return [dict(r) for r in conn.execute(q, params).fetchall()]


def trends(methodology: str | None = None, target: str | None = None,
           limit: int = 100, include_sast: bool = False) -> list[dict]:
    """Per-report severity time series, newest first.

    Each row is a saved report plus a breakdown of how many findings it carried
    at each severity — the shape a client charts as a risk trajectory.
    """
    init()
    q = ("SELECT r.id,r.title,r.methodology,r.target,r.overall_risk,"
         "r.analyzed_at,r.created_at,f.severity,COUNT(f.id) AS n "
         "FROM reports r LEFT JOIN findings f ON f.report_id = r.id")
    where, params = [], []
    if methodology:
        where.append("r.methodology = ?")
        params.append(methodology)
    if target:
        where.append("r.target = ?")
        params.append(target)
    if not include_sast:
        where.append("r.methodology NOT IN ('sast', 'dast')")
    if where:
        q += " WHERE " + " AND ".join(where)
    q += " GROUP BY r.id, f.severity ORDER BY r.created_at DESC, r.rowid DESC"
    with closing(_connect()) as conn:
        rows = conn.execute(q, params).fetchall()

    by_report: dict[str, dict] = {}
    order: list[str] = []
    for row in rows:
        rid = row["id"]
        if rid not in by_report:
            order.append(rid)
            by_report[rid] = {
                "id": rid, "title": row["title"], "methodology": row["methodology"],
                "target": row["target"], "overall_risk": row["overall_risk"],
                "analyzed_at": row["analyzed_at"], "created_at": row["created_at"],
                "severity_counts": {s: 0 for s in _SEVERITIES}, "total": 0,
            }
        sev = row["severity"]
        if sev in _SEVERITIES and row["n"]:
            by_report[rid]["severity_counts"][sev] = row["n"]
            by_report[rid]["total"] += row["n"]
    return [by_report[rid] for rid in order[:max(1, min(limit, 1000))]]


def verdict_trends(limit: int = 100) -> list[dict]:
    """Per-correlation-report verdict breakdown over time, newest first --
    the shape a client charts as "is our evidence base for known risks
    getting more or less actionable across successive scans".

    Restricted to methodology='correlation' reports: only a correlation run
    judges its findings' verdicts as a coherent set, so that report is the
    natural x-axis unit for this trend (a plain SAST/manual report's findings
    are either all unverdicted or a stray few carried over from an earlier
    correlation, neither of which charts as a meaningful point).
    """
    init()
    q = ("SELECT r.id,r.title,r.analyzed_at,r.created_at,"
         "f.verdict,COUNT(f.id) AS n "
         "FROM reports r LEFT JOIN findings f ON f.report_id = r.id "
         "WHERE r.methodology = 'correlation' "
         "GROUP BY r.id, f.verdict ORDER BY r.created_at DESC, r.rowid DESC")
    with closing(_connect()) as conn:
        rows = conn.execute(q).fetchall()

    by_report: dict[str, dict] = {}
    order: list[str] = []
    for row in rows:
        rid = row["id"]
        if rid not in by_report:
            order.append(rid)
            by_report[rid] = {
                "id": rid, "title": row["title"],
                "analyzed_at": row["analyzed_at"], "created_at": row["created_at"],
                "verdict_counts": {v: 0 for v in _VERDICTS}, "total": 0, "unverdicted": 0,
            }
        v, n = row["verdict"], row["n"] or 0
        if not n:
            continue
        if v in _VERDICTS:
            by_report[rid]["verdict_counts"][v] = n
            by_report[rid]["total"] += n
        else:
            by_report[rid]["unverdicted"] = n
    return [by_report[rid] for rid in order[:max(1, min(limit, 1000))]]


def search_findings(family: str | None = None, severity: str | None = None,
                    cwe: str | None = None, methodology: str | None = None,
                    verdict: str | None = None, ssvc_action: str | None = None,
                    text: str | None = None,
                    limit: int = 200, include_sast: bool = False) -> list[dict]:
    """Cross-scan finding search joined to the owning report.

    ``verdict`` matches the stored correlator verdict exactly (empty string
    means "not correlated" -- pass ``verdict=""`` explicitly to find those;
    the default ``None`` leaves verdict out of the filter entirely).
    ``ssvc_action`` follows the identical convention (see
    correlator/mapper.py's ssvc_action / ssvc.py).
    ``text`` is a substring match against the finding title or rule id.
    """
    init()
    q = ("SELECT f.id AS finding_id,f.report_id,f.rule,f.title,f.family,f.severity,f.cwe,"
         "f.owasp,f.source,f.locus,f.path,f.line,f.verdict,f.fingerprint,f.ssvc_action,"
         "r.title AS report_title,r.methodology,r.created_at "
         "FROM findings f JOIN reports r ON r.id = f.report_id")
    where, params = [], []
    if family:
        where.append("f.family = ?"); params.append(family)
    if severity:
        where.append("f.severity = ?"); params.append(severity)
    if cwe:
        where.append("f.cwe LIKE ?"); params.append(f"%{cwe}%")
    if methodology:
        where.append("r.methodology = ?"); params.append(methodology)
    if verdict is not None:
        where.append("f.verdict = ?"); params.append(verdict)
    if ssvc_action is not None:
        where.append("f.ssvc_action = ?"); params.append(ssvc_action)
    if text:
        where.append("(f.title LIKE ? OR f.rule LIKE ?)")
        params.append(f"%{text}%"); params.append(f"%{text}%")
    if not include_sast:
        where.append("r.methodology NOT IN ('sast', 'dast')")
    if where:
        q += " WHERE " + " AND ".join(where)
    q += " ORDER BY r.created_at DESC LIMIT ?"
    params.append(max(1, min(limit, 2000)))
    with closing(_connect()) as conn:
        return [dict(r) for r in conn.execute(q, params).fetchall()]


def family_summary(include_sast: bool = False) -> list[dict]:
    """Count of findings per weakness family across all reports, worst first."""
    init()
    q = ("SELECT f.family, COUNT(*) AS total, "
         "SUM(f.severity IN ('Critical','High')) AS high_plus, "
         "COUNT(DISTINCT f.report_id) AS reports "
         "FROM findings f JOIN reports r ON r.id = f.report_id"
         + ("" if include_sast else " WHERE r.methodology NOT IN ('sast', 'dast')")
         + " GROUP BY f.family ORDER BY high_plus DESC, total DESC")
    with closing(_connect()) as conn:
        return [dict(r) for r in conn.execute(q).fetchall()]


def methodologies() -> list[dict]:
    """Distinct report methodologies with finding counts, unfiltered -- the
    ground truth for a UI filter dropdown, since new methodology values get
    added by whichever analysis module writes them (codemodel, correlation,
    sast, dast, aibom, archdrift, attackpath, incident, ...) with no central
    registry to keep a hardcoded list in sync with."""
    init()
    q = ("SELECT r.methodology AS methodology, COUNT(*) AS total "
         "FROM findings f JOIN reports r ON r.id = f.report_id "
         "GROUP BY r.methodology ORDER BY total DESC")
    with closing(_connect()) as conn:
        return [dict(r) for r in conn.execute(q).fetchall() if r["methodology"]]
