"""Correlation (mediator) engine API + dashboard page.

Routes (CSRF + optional TM_API_KEY apply via the app's global before_request):
  GET    /api/v1/correlate            engine status
  GET    /api/v1/correlate/sources    list saved reports that can be correlated
  GET    /api/v1/correlate/trend      verdict-count time series across correlation runs
  GET    /api/v1/correlate/design-debt   design_gap backlog burn-down; ?window_days=
  GET    /api/v1/correlate/design-debt/agenda   per-finding design_gap worklist
                                       with a suggested next validation step
  GET    /api/v1/correlate/precision  the correlator's own reversal rate --
                                       how often a past escalation held up
  GET    /api/v1/correlate/reachable-dependencies   SBOM CVEs proven reachable in code
  POST   /api/v1/correlate/run        run correlation {report_ids?:[...], title?}
                                       -> saves a report, returns {report_id, ...}
  GET    /api/v1/correlate/alerts     verdict-escalation alerts (blind_spot ->
                                       confirmed_exploitable etc.); ?unacknowledged=1
  POST   /api/v1/correlate/alerts/<id>/acknowledge   dismiss one alert
  GET    /api/v1/correlate/sla        verdict aging vs. SLA window; ?status=breached
  POST   /api/v1/correlate/attack-paths      synthesize deterministic entry->sink paths
  POST   /api/v1/correlate/chain-reasoning   LLM multi-step attack-chain reasoning
  GET    /api/v1/correlate/<id>?token=...    public, token-gated view of one
                                       correlation report (no TM_API_KEY, no
                                       session) -- see public_correlate below

  GET    /correlate                    dashboard UI (separate, un-prefixed bp)

The engine only ever reads reports the app has already saved, so it introduces no
new ingress or filesystem reach beyond the existing report store.
"""
from __future__ import annotations

import secrets

from flask import Blueprint, jsonify, render_template, request

import app as tm_app
import attack_paths
import report_db
import report_view
import verdict_tracking
from codemodel import chain_reasoning
from correlator import service

bp = Blueprint("correlate_api", __name__, url_prefix="/api/v1/correlate")
page_bp = Blueprint("correlate_page", __name__)

_MAX_SOURCES = 50


@bp.get("")
def status():
    sources = service.list_correlatable()
    kinds = {"code": 0, "runtime": 0, "design": 0, "incident": 0}
    for s in sources:
        kinds[s["kind"]] = kinds.get(s["kind"], 0) + 1
    return jsonify({
        "success": True,
        "engine": "correlator",
        "sources_available": len(sources),
        "sources_by_kind": kinds,
        "ready": len(sources) >= 2,
        "verdicts": [
            "actively_exploited", "confirmed_exploitable", "corroborated",
            "design_gap", "blind_spot"],
    })


@bp.get("/sources")
def sources():
    return jsonify({"success": True, "sources": service.list_correlatable()})


@bp.get("/trend")
def trend():
    """Verdict-count time series across successive correlation runs, oldest
    first (chart-ready). Each point is one correlation report's verdict mix."""
    try:
        limit = int(request.args.get("limit", 24))
    except (TypeError, ValueError):
        limit = 24
    rows = report_db.verdict_trends(limit=limit)
    return jsonify({"success": True, "count": len(rows), "trend": list(reversed(rows))})


@bp.get("/reachable-dependencies")
def reachable_dependencies():
    """Vulnerable-dependency (SBOM) findings the code model proved reachable
    from a real entry point -- see correlator.service.list_reachable_dependencies."""
    try:
        limit = int(request.args.get("limit", 12))
    except (TypeError, ValueError):
        limit = 12
    return jsonify({"success": True, **service.list_reachable_dependencies(limit=limit)})


@bp.get("/design-debt")
def design_debt():
    """Design-debt burn-down: is the backlog of modeled-but-unproven findings
    (verdict == design_gap) shrinking or growing? See
    verdict_tracking.design_debt_summary for the open/opened/resolved math;
    ``burndown`` here is the same open-count-over-time series as /trend,
    trimmed to just the design_gap band so a client can chart it standalone."""
    try:
        window_days = float(request.args.get("window_days", 30))
    except (TypeError, ValueError):
        window_days = 30
    trend_rows = report_db.verdict_trends(limit=24)
    burndown = [{"id": r["id"], "title": r["title"], "analyzed_at": r["analyzed_at"],
                 "design_gap": r["verdict_counts"]["design_gap"]}
                for r in reversed(trend_rows)]
    return jsonify({
        "success": True,
        "summary": verdict_tracking.design_debt_summary(window_days=window_days),
        "burndown": burndown,
    })


@bp.get("/design-debt/agenda")
def design_debt_agenda():
    """Per-finding worklist for the open design_gap backlog, oldest first,
    each with a suggested next validation step -- see design_gap_agenda.py.
    ?limit= caps the returned items (the summary counts still cover every
    open item regardless of the cap)."""
    try:
        limit = int(request.args.get("limit", 100))
    except (TypeError, ValueError):
        limit = 100
    import design_gap_agenda
    return jsonify({"success": True, **design_gap_agenda.agenda(limit=limit)})


@bp.get("/precision")
def precision():
    """The correlator's own reversal rate -- of the times it raised a
    finding's confidence, how many of those escalations later got walked
    back? See correlator/self_quality.py."""
    from correlator import self_quality
    return jsonify({"success": True, **self_quality.summary()})


@bp.get("/alerts")
def alerts():
    """Verdict escalations detected across every correlation run so far --
    a finding whose verdict got strictly more actionable (e.g. blind_spot ->
    confirmed_exploitable) since the last time it was seen. ?unacknowledged=1
    to list only the ones nobody has dismissed yet."""
    try:
        limit = int(request.args.get("limit", 50))
    except (TypeError, ValueError):
        limit = 50
    unack_only = request.args.get("unacknowledged") in ("1", "true", "yes")
    items = verdict_tracking.list_alerts(limit=limit, unacknowledged_only=unack_only)
    return jsonify({
        "success": True,
        "count": len(items),
        "unacknowledged": verdict_tracking.unacknowledged_count(),
        "alerts": items,
    })


@bp.post("/alerts/<int:alert_id>/acknowledge")
def acknowledge_alert(alert_id: int):
    ok = verdict_tracking.acknowledge_alert(alert_id)
    if not ok:
        return jsonify({"success": False, "error": "Not found"}), 404
    return jsonify({"success": True, "acknowledged": alert_id})


@bp.get("/sla")
def sla():
    """How long every tracked finding has sat at its current verdict vs. that
    verdict's remediation window (confirmed_exploitable=3d, corroborated=7d,
    design_gap=30d, blind_spot=90d -- the same tiers control_register.py uses
    by severity, applied here by verdict rank instead). ?status=breached to
    filter to one or more statuses (comma-separated: breached,at_risk,ok)."""
    status_param = request.args.get("status", "")
    statuses = tuple(s.strip() for s in status_param.split(",") if s.strip())
    return jsonify({
        "success": True,
        "summary": verdict_tracking.sla_summary(),
        "findings": verdict_tracking.sla_status(statuses=statuses),
    })


@bp.post("/run")
def run():
    body = request.get_json(silent=True) or {}
    report_ids = body.get("report_ids") or None
    title = str(body.get("title", "")).strip()

    if report_ids is not None:
        if not isinstance(report_ids, list) or not all(isinstance(r, str) for r in report_ids):
            return jsonify({"success": False,
                            "error": "report_ids must be a list of strings"}), 400
        if len(report_ids) > _MAX_SOURCES:
            return jsonify({"success": False,
                            "error": f"too many reports (max {_MAX_SOURCES})"}), 400

    try:
        report = service.run(report_ids=report_ids, title=title)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400

    import app as tm_app  # lazy import to avoid a circular import at module load
    report_id = tm_app._save_report(report, report["title"])

    meta = report.get("scan_metadata", {})
    return jsonify({
        "success": True,
        "report_id": report_id,
        "title": report["title"],
        "overall_risk": report.get("overall_risk"),
        "findings_total": meta.get("findings_total", 0),
        "verdict_counts": meta.get("verdict_counts", {}),
        "actively_exploited": meta.get("actively_exploited", 0),
        "confirmed_exploitable": meta.get("confirmed_exploitable", 0),
        "blind_spots": meta.get("blind_spots", 0),
        "design_gaps": meta.get("design_gaps", 0),
        "summary": report.get("summary", ""),
    }), 201


@bp.post("/attack-paths")
def attack_paths_run():
    """Synthesize attack paths from a codemodel report + optional evidence.

    Body: {codemodel_report_id, evidence_report_ids?:[...], title?}. Chains each
    entry point to the tainted/confirmed sink it reaches, grades each with any
    DAST/SAST evidence, saves the result as a normal report, returns a summary.
    """
    body = request.get_json(silent=True) or {}
    cm_id = str(body.get("codemodel_report_id", "")).strip()
    if not cm_id:
        return jsonify({"success": False,
                        "error": "codemodel_report_id is required"}), 400
    evidence_ids = body.get("evidence_report_ids") or []
    if not isinstance(evidence_ids, list) or not all(isinstance(x, str) for x in evidence_ids):
        return jsonify({"success": False,
                        "error": "evidence_report_ids must be a list of strings"}), 400
    if len(evidence_ids) > _MAX_SOURCES:
        return jsonify({"success": False,
                        "error": f"too many evidence reports (max {_MAX_SOURCES})"}), 400

    cm_report = service.load_report(cm_id)
    if cm_report is None:
        return jsonify({"success": False,
                        "error": f"codemodel report not found: {cm_id}"}), 404
    if str(cm_report.get("methodology", "")).lower() != "codemodel":
        return jsonify({"success": False,
                        "error": "report is not a code-derived model "
                                 "(run /code-model first)"}), 400

    evidence = []
    for eid in evidence_ids:
        r = service.load_report(eid)
        if r is None:
            return jsonify({"success": False,
                            "error": f"evidence report not found: {eid}"}), 404
        evidence.append(r)

    paths = attack_paths.synthesize(cm_report, evidence)
    sources = [{"id": cm_id, "title": cm_report.get("title"), "role": "codemodel"}]
    sources += [{"id": r.get("id"), "title": r.get("title"), "role": "evidence"}
                for r in evidence]
    meta = {"report_title": str(body.get("title", "")).strip()
            or f"Attack Paths · {cm_report.get('title', cm_id)}"}
    report = attack_paths.to_report(paths, sources, meta)

    import app as tm_app
    report_id = tm_app._save_report(report, report["title"])
    smeta = report.get("scan_metadata", {})
    return jsonify({
        "success": True,
        "report_id": report_id,
        "title": report["title"],
        "overall_risk": report.get("overall_risk"),
        "paths_total": smeta.get("paths_total", 0),
        "confirmed": smeta.get("confirmed", 0),
        "high_confidence": smeta.get("high_confidence", 0),
        "summary": report.get("summary", ""),
    }), 201


@bp.post("/chain-reasoning")
def chain_reasoning_run():
    """Run LLM multi-step attack-chain reasoning over a saved codemodel report.

    Body: {codemodel_report_id, api_key?, title?}. Hands the code-derived facts
    (entry points, sinks, data stores, external calls, controls, trust
    boundaries) to an LLM and asks it to propose chains that cross two or more
    of those facts — the kind of thing single-hop reachability (codemodel) and
    deterministic path synthesis (attack-paths) can't see because no rule
    author anticipated the specific combination. Requires an Anthropic API key
    (request body or server-configured); there is no offline mode, since this
    is a generative reasoning step, not a rule lookup.
    """
    body = request.get_json(silent=True) or {}
    cm_id = str(body.get("codemodel_report_id", "")).strip()
    if not cm_id:
        return jsonify({"success": False,
                        "error": "codemodel_report_id is required"}), 400

    cm_report = service.load_report(cm_id)
    if cm_report is None:
        return jsonify({"success": False,
                        "error": f"codemodel report not found: {cm_id}"}), 404
    if str(cm_report.get("methodology", "")).lower() != "codemodel":
        return jsonify({"success": False,
                        "error": "report is not a code-derived model "
                                 "(run /code-model first)"}), 400

    import app as tm_app  # lazy import to avoid a circular import at module load
    api_key_supplied = "api_key" in body
    api_key = str(body.get("api_key", "")).strip()
    api_key = tm_app._env_api_key_if_omitted(api_key, api_key_supplied)
    if not api_key:
        return jsonify({"success": False,
                        "error": "chain reasoning requires an Anthropic API key "
                                 "(no offline mode — this is a generative "
                                 "reasoning step, not a rule engine)"}), 400

    chains = chain_reasoning.reason(cm_report, api_key)
    sources = [{"id": cm_id, "title": cm_report.get("title"), "role": "codemodel"}]
    meta = {"report_title": str(body.get("title", "")).strip()
            or f"Attack Chains · {cm_report.get('title', cm_id)}"}
    report = chain_reasoning.to_report(chains, sources, meta)

    report_id = tm_app._save_report(report, report["title"])
    smeta = report.get("scan_metadata", {})
    return jsonify({
        "success": True,
        "report_id": report_id,
        "title": report["title"],
        "overall_risk": report.get("overall_risk"),
        "chains_total": smeta.get("chains_total", 0),
        "severity_counts": smeta.get("severity_counts", {}),
        "summary": report.get("summary", ""),
    }), 201


@bp.get("/<report_id>")
@tm_app.limiter.limit("30 per minute")
def public_correlate(report_id: str):
    """Token-gated public view of one correlation report — no TM_API_KEY, no
    session.

    Same share-token mechanism as ``api/reports.py``'s ``report_shared``
    (``?token=`` must match the ``share_token`` minted for this report at
    save time), but namespaced under the correlator's own API surface and
    scoped to ``methodology == "correlation"`` only — passing a SAST/DAST/
    codemodel report id here 404s; use ``/api/v1/reports/<id>/shared`` for
    those. Meant for handing a correlation *result* (the mediator's verdicts,
    not a raw scan) to someone outside the app without the master API key or
    a login.

    Exempted from the global auth gate in ``app._auth_and_csrf`` by view
    identity (``request.endpoint``), not a path pattern — a pattern match on
    a bare ``/<id>`` segment directly under this blueprint's prefix would
    risk exempting a sibling route (``/sources``, ``/trend``, …) by accident;
    matching the specific view function this route dispatches to cannot.
    """
    if not tm_app._validate_report_id(report_id):
        return jsonify({"success": False, "error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None or str(report.get("methodology", "")).lower() != "correlation":
        return jsonify({"success": False, "error": "Report not found"}), 404
    expected = report.get("share_token", "")
    provided = request.args.get("token", "")
    if not expected or not secrets.compare_digest(provided, expected):
        return jsonify({"success": False, "error": "Invalid or missing token"}), 403
    safe = report_view.sanitize_report(report)
    safe.pop("share_token", None)
    return jsonify({"success": True, "report": safe})


@page_bp.get("/correlate")
def correlate_page():
    from app import _CSRF_TOKEN
    return render_template("correlate.html", csrf_token=_CSRF_TOKEN)
