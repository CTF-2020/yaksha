"""assetgraph — a persistent, accumulating graph of assets across every
codemodel scan: repos, entry points, data stores, and the external
services/trust boundaries they share. See assetgraph/service.py for the
reconciliation logic that keeps it "living" (edges go stale when a rescan no
longer observes them) rather than an append-only log.
"""
