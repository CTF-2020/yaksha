"""Map scan-engine findings to the Yaksha Guard TM report shape.

The TM report viewer renders `report.categories[]` where each category carries
a severity (`risk`), a title, a summary, `affected_components`, `threats[]`, and
`mitigations[]`. We group raw findings by rule so each weakness class becomes one
collapsible card, and each individual hit (file:line + snippet) becomes a threat
ticket inside it. This reuses the existing UI verbatim — no renderer changes.
"""
from __future__ import annotations

from . import config

# Engine severities -> a numeric risk score the UI shows as "/10".
_RISK_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}
_MAX_THREATS_PER_RULE = 50   # keep cards readable on noisy rules
_MAX_COMPONENTS = 25


def _sev(finding: dict) -> str:
    """Canonical severity for a finding; anything off-scale clamps to Info."""
    sev = finding.get("severity", "Info")
    return sev if sev in config.SEVERITY_ORDER else "Info"


def _highest_severity(findings: list[dict]) -> str:
    best = "Info"
    for f in findings:
        sev = _sev(f)
        if config.SEVERITY_ORDER[sev] < config.SEVERITY_ORDER[best]:
            best = sev
    return best


def _severity_counts(findings: list[dict]) -> dict:
    counts = {s: 0 for s in config.SEVERITIES}
    for f in findings:
        counts[_sev(f)] += 1
    return counts


def _threat_from_finding(f: dict) -> dict:
    loc = f"{f.get('file', '?')}:{f.get('line', '?')}"
    meta_bits = [b for b in (f.get("owasp"), f.get("cwe"),
                             "STRIDE " + "/".join(f.get("stride", []))
                             if f.get("stride") else "",
                             f.get("engine") and f"engine: {f['engine']}") if b]
    threat = {
        "name": loc,
        "description": f.get("snippet") or "(no code snippet captured)",
        "attack_vector": f.get("title", ""),
        "control_objective": " | ".join(meta_bits),
        "false_positive_guidance":
            "Confirm the flagged line is reachable with attacker-controlled input "
            "before remediating; regex matches can fire on safe or commented code.",
    }
    # The vulnerable code in context — the flagged line with surrounding source and
    # line numbers, so the finding shows *where and what*, not just a rule name.
    if f.get("code_context"):
        threat["code_context"] = f["code_context"]
    if f.get("line") is not None:
        threat["line"] = f["line"]
    # Reviewer analysis (broker/reviewer.py): verdict + evidence + suggested
    # fix. Its per-finding conclusion supersedes the generic FP boilerplate.
    if f.get("review"):
        threat["review"] = f["review"]
        if f["review"].get("summary"):
            threat["false_positive_guidance"] = f["review"]["summary"]
    return threat


def _category_from_group(rule_id: str, findings: list[dict]) -> dict:
    first = findings[0]
    severity = _highest_severity(findings)
    locations = [f"{f.get('file', '?')}:{f.get('line', '?')}" for f in findings]
    remediation = first.get("remediation", "") or "Review and remediate per secure-coding guidance."
    return {
        "id": rule_id,
        "category": first.get("domain", "SAST"),
        "name": first.get("title", rule_id),
        "title": first.get("title", rule_id),
        "risk": severity,
        "risk_score": _RISK_SCORE.get(severity, 1),
        "_source": "SAST",
        "ruleset": first.get("domain", "SAST"),
        "description": (
            f"{len(findings)} occurrence(s) of {first.get('title', rule_id)} "
            f"detected by static analysis ({rule_id})."
        ),
        "affected_components": locations[:_MAX_COMPONENTS],
        "mitigation": remediation,
        "remediation": remediation,
        "mitigations": [{"action": remediation, "priority": "Immediate"}],
        "threats": [_threat_from_finding(f) for f in findings[:_MAX_THREATS_PER_RULE]],
        "notes": (
            f"OWASP: {first.get('owasp', 'n/a')}  ·  CWE: {first.get('cwe', 'n/a')}  ·  "
            f"ISO 27001: {first.get('iso27001', 'n/a')}"
            + (f"  ·  engine: {first['engine']}" if first.get("engine") else "")
        ),
    }


def findings_to_report(findings: list[dict], repo: dict, meta: dict,
                       severity_threshold: str) -> dict:
    """Build a TM report dict ready for `_save_report`."""
    groups: dict[str, list[dict]] = {}
    for f in findings:
        groups.setdefault(f.get("id", "UNKNOWN"), []).append(f)

    # Order cards by worst severity then by volume.
    categories = sorted(
        (_category_from_group(rid, fs) for rid, fs in groups.items()),
        key=lambda c: (config.SEVERITY_ORDER.get(c["risk"], 99), -len(c["threats"])),
    )

    counts = _severity_counts(findings)
    overall = _highest_severity(findings) if findings else "Info"
    src = meta.get("commit") and f" @ {meta['commit']}" or ""
    branch = meta.get("branch", "")
    scope = f"{repo.get('name', repo.get('id', 'repo'))}{src}"
    if branch and branch != "(default)":
        scope += f" ({branch})"

    summary = (
        f"Static analysis of {scope} found {len(findings)} finding(s) at or above the "
        f"{severity_threshold} threshold across {len(groups)} rule(s): "
        + ", ".join(f"{counts[s]} {s}" for s in config.SEVERITIES if counts[s])
        + ("." if findings else "No findings at or above the threshold.")
    )

    # Surface engine-availability coverage gaps in the headline summary, not just
    # buried in scan_metadata.engines — a missing gosec on a Go repo should be as
    # visible as the finding counts, not something you only notice by reading the
    # raw per-engine JSON.
    coverage_note = next(
        (m for m in meta.get("engines", []) if m.get("engine") == "(coverage)"), None)
    if coverage_note:
        parts = []
        for g in coverage_note["gaps"]:
            cov = (f"still covered by {', '.join(g['still_covered_by'])}"
                  if g["still_covered_by"] else "no engine covered it this scan")
            parts.append(f"{g['language']} ({', '.join(g['missing_engines'])} "
                        f"unavailable, {cov})")
        summary += " ⚠ Coverage gap — " + "; ".join(parts) + "."

    # De-duplicated remediation backlog, worst severity first.
    seen, recommendations = set(), []
    for c in categories:
        rec = c["mitigation"]
        if rec and rec not in seen:
            seen.add(rec)
            recommendations.append(rec)

    return {
        "title": f"SAST · {repo.get('name', repo.get('id', 'repo'))}",
        "methodology": "sast",
        "methodology_label": "Static Application Security Testing",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "analyzed_at": config.now_iso(),
        "summary": summary,
        "categories": categories,
        "recommendations": recommendations,
        "scan_metadata": {
            "repo_id": repo.get("id"),
            "repo_name": repo.get("name"),
            "severity_threshold": severity_threshold,
            "findings_total": len(findings),
            "rules_triggered": len(groups),
            "severity_counts": counts,
            **meta,
        },
    }
