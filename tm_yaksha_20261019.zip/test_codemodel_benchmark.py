"""Regression floors for the code-derived threat-model engine's measured accuracy.

benchmark/codemodel_harness.py scores build_model against a labelled multi-language
corpus (Python/JS/TS/Go/Java). This turns that measurement into a CI gate: an
extractor change that starts missing routes, missing reachable sinks, or
mis-classifying auth drops below a floor and fails here.

Floors sit below the current measured numbers (all 100% as of 2026-07-18, 6 cases,
11 entry points) so the corpus can grow harder without a brittle exact assertion.
"""
from __future__ import annotations

import unittest

from benchmark import codemodel_harness as h


class TestCodemodelAccuracyFloors(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = h.evaluate()

    def test_entry_point_recall_floor(self):
        self.assertGreaterEqual(self.m["entry_points"]["recall"], 0.90,
                                self.m["cases_detail"])

    def test_entry_point_precision_floor(self):
        self.assertGreaterEqual(self.m["entry_points"]["precision"], 0.90,
                                self.m["cases_detail"])

    def test_sink_family_recall_floor(self):
        self.assertGreaterEqual(self.m["sink_families"]["recall"], 0.85,
                                self.m["cases_detail"])

    def test_sink_family_precision_floor(self):
        self.assertGreaterEqual(self.m["sink_families"]["precision"], 0.85,
                                self.m["cases_detail"])

    def test_auth_classification_floor(self):
        self.assertGreaterEqual(self.m["auth_accuracy"], 0.85, self.m["cases_detail"])

    def test_secret_management_floor(self):
        self.assertGreaterEqual(self.m["secret_accuracy"], 0.90, self.m["cases_detail"])

    def test_clean_design_not_falsely_tainted(self):
        # a bound-parameter query must never be reported as a tainted sink
        self.assertGreaterEqual(self.m["clean_untainted_rate"], 0.90,
                                self.m["cases_detail"])

    def test_every_language_covered(self):
        langs = {r["lang"] for r in self.m["cases_detail"]}
        self.assertEqual(langs, {"python", "javascript", "typescript", "go", "java"})

    def test_report_renders(self):
        self.assertIn("measured accuracy", h.format_report(self.m))


if __name__ == "__main__":
    unittest.main()
