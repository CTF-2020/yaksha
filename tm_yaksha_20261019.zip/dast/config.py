"""DAST configuration, state directory, and target-registry persistence.

Mirrors the SAST broker's config but for *dynamic* scanning: the unit of work is
a registered target URL (a running application), not a source repository. All
state lives under ~/.tm_dast, kept separate from ~/.tm_broker and ~/.tm_reports.

Shared primitives (severity ordering, slugs, atomic JSON writes, ISO time) are
reused from broker.config so the two scanners agree on the vocabulary the report
UI renders — DAST only adds the target registry and the engine's request budget.
"""
from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

import settings_db

# Reuse the broker's shared vocabulary/helpers verbatim so a DAST report and a
# SAST report speak the same severity language to the viewer.
from broker.config import (  # noqa: F401 - re-exported for callers
    SEVERITIES,
    SEVERITY_ORDER,
    checks_mode,
    github_full_name_from_url,
    is_valid_slug,
    now_iso,
    slugify,
    _read_json,
    _write_json,
)
from broker import config as _bcfg

# ── State directories ─────────────────────────────────────────────────────────
STATE_DIR = Path(os.environ.get("TM_DAST_DIR", str(Path.home() / ".tm_dast")))
TARGETS_PATH = STATE_DIR / "targets.json"
JOBS_PATH = STATE_DIR / "jobs.json"

STATE_DIR.mkdir(parents=True, exist_ok=True)

# ── Engine request budget / safety envelope ───────────────────────────────────
# Every knob is bounded so an authorized scan can never turn into a flood: a
# global request cap, a page-crawl cap, a per-request timeout, and a polite delay
# between requests to the same host.
USER_AGENT = os.environ.get(
    "TM_DAST_UA", "YakshaGuard-DAST/1.0 (+authorized security scan)")
MAX_PAGES = int(os.environ.get("TM_DAST_MAX_PAGES", "25"))       # crawl breadth
MAX_REQUESTS = int(os.environ.get("TM_DAST_MAX_REQUESTS", "300"))  # hard ceiling
REQUEST_TIMEOUT = int(os.environ.get("TM_DAST_TIMEOUT", "15"))    # per request, s
RATE_DELAY = float(os.environ.get("TM_DAST_RATE_DELAY", "0.3"))   # between reqs, s
MAX_BODY = int(os.environ.get("TM_DAST_MAX_BODY", "2000000"))     # bytes read/resp
# Overall wall-clock budget for one scan; enforced by engine.scan() and also
# sizes the SSE stream deadline.
SCAN_TIMEOUT = int(os.environ.get("TM_DAST_SCAN_TIMEOUT", "900"))
# Extra URLs the crawler may seed from robots.txt / sitemap.xml (bounded so the
# seed step can never balloon the request budget on a huge sitemap).
MAX_SEEDS = int(os.environ.get("TM_DAST_MAX_SEEDS", "40"))
# Distinct endpoints (path-deduped) the reflected-Origin CORS probe may test.
CORS_PROBE_CAP = int(os.environ.get("TM_DAST_CORS_PROBE_CAP", "15"))
# Bounded worker pool — mirrors broker.config.BROKER_WORKERS: a burst of scan
# requests/webhooks across many targets must not fan out into unlimited
# concurrent crawl threads, each holding sockets open for up to SCAN_TIMEOUT.
DAST_WORKERS = max(1, settings_db.resolve_int(
    "dast.workers", os.environ.get("TM_DAST_WORKERS"), 3))

# Active (input-injecting but non-destructive) checks on top of passive ones.
# "0"/"off"/"false" restricts a scan to passive header/cookie/transport analysis.
_ACTIVE = os.environ.get("TM_DAST_ACTIVE", "on").strip().lower()
ACTIVE_CHECKS = _ACTIVE not in ("0", "off", "false", "no")
# Injection probes (SQLi / path traversal / SSTI / command injection) layered on
# top of the reflection checks. All use benign marker/differential payloads (a
# lone quote, an arithmetic template marker, a read of /etc/passwd) — they never
# send a state-changing or destructive command. Off restricts active checks to
# reflected-XSS / open-redirect / CORS only.
_INJECTION = os.environ.get("TM_DAST_INJECTION", "on").strip().lower()
INJECTION_CHECKS = _INJECTION not in ("0", "off", "false", "no")

# Shared secret required to push a finished report into a remote server via the
# /api/v1/dast/import endpoint. Empty disables remote import (in-process only).
IMPORT_TOKEN = os.environ.get("TM_DAST_TOKEN", "")

# Retention for persisted job history.
JOB_RETENTION = int(os.environ.get("TM_DAST_JOB_RETENTION", "200"))

# ── GitHub / CI release-gate integration ──────────────────────────────────────
# DAST scans a *running* app, so its natural CI trigger is a successful
# deployment (GitHub `deployment_status` state=success), not a code push. These
# settings default to the broker's shared GitHub config so an org configures a
# token/secret once; TM_DAST_GITHUB_* overrides let DAST use its own if needed.
GITHUB_TOKEN = os.environ.get("TM_DAST_GITHUB_TOKEN", "") or _bcfg.GITHUB_TOKEN
GITHUB_WEBHOOK_SECRET = (os.environ.get("TM_DAST_GITHUB_WEBHOOK_SECRET", "")
                         or _bcfg.GITHUB_WEBHOOK_SECRET)
GITHUB_API_BASE = _bcfg.GITHUB_API_BASE
# Severity (inclusive) that fails the deployment gate. High by default.
GITHUB_FAIL_ON = os.environ.get("TM_DAST_FAIL_ON", "") or _bcfg.GITHUB_FAIL_ON
# Severity threshold a webhook-triggered scan runs at (Info = report everything).
GITHUB_SCAN_SEVERITY = os.environ.get("TM_DAST_GITHUB_SCAN_SEVERITY", "Info")
# Report-link base posted to GitHub; falls back to the request host when blank.
PUBLIC_URL = _bcfg.PUBLIC_URL

# Per-target fields that hold secrets and must never leave the server unredacted.
_TARGET_SECRET_KEYS = ("auth_header", "github_token", "webhook_secret")

_lock = threading.RLock()


# ── Target validation ─────────────────────────────────────────────────────────
def normalize_target_url(url: str) -> str:
    """Return a cleaned http(s) URL or '' if it is not a scannable web target."""
    url = (url or "").strip()
    if not url:
        return ""
    if "://" not in url:
        # No explicit scheme. Distinguish a bare host / host:port (which we
        # upgrade to http://) from an opaque non-web scheme like javascript: or
        # data:, which must be rejected outright — coercing those to http:// was
        # a real injection hole.
        head = url.split("/", 1)[0]
        if ":" in head:
            _scheme_like, _, rest = head.partition(":")
            if not rest.isdigit():            # not host:port -> a real scheme
                return ""
        url = "http://" + url
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return ""
    return url


def target_host(url: str) -> str:
    """Bare hostname (no port) of a target URL, lowercased."""
    return (urlparse(url).hostname or "").lower()


_HOST_RE = re.compile(r"^[a-z0-9.-]{1,253}$")


def parse_scope(scope: str, default_host: str) -> list[str]:
    """Comma/space separated host allowlist; falls back to the target's own host.

    The scope is the set of hostnames the crawler is permitted to touch. It
    defaults to the target host alone, so a scan can never wander off the
    authorized application (e.g. follow a link to a third-party CDN and probe it).
    """
    hosts = [h.strip().lower() for h in re.split(r"[,\s]+", scope or "") if h.strip()]
    hosts = [h for h in hosts if _HOST_RE.match(h)]
    if default_host and default_host not in hosts:
        hosts.append(default_host)
    return hosts


# ── Secret redaction (identical contract to the broker) ───────────────────────
def redact_target(target: dict) -> dict:
    """Copy of a target entry safe to return over the API.

    Secret-bearing fields collapse to a boolean '<key>_set' flag so the UI can
    show "configured" without ever shipping the value back to the browser.
    """
    clean = {k: v for k, v in target.items() if k not in _TARGET_SECRET_KEYS}
    for key in _TARGET_SECRET_KEYS:
        clean[f"{key}_set"] = bool(target.get(key))
    return clean


def find_target_for_github(full_name: str) -> dict | None:
    """Find the registered target a GitHub webhook (by owner/repo) belongs to.

    Matches an explicit `github_full_name` first, then derives owner/repo from an
    optional `repo_url` field (the target's source-repository URL, distinct from
    its scan `url`). Only *registered* targets match, so a webhook can never
    coerce a scan of an unregistered application — it only selects which
    already-authorized target's URL to scan.
    """
    if not full_name:
        return None
    wanted = full_name.strip().lower()
    for target in load_targets():
        explicit = (target.get("github_full_name") or "").strip().lower()
        if explicit and explicit == wanted:
            return target
        if github_full_name_from_url(target.get("repo_url", "")) == wanted:
            return target
    return None


# ── Target registry (atomic, lock-guarded — same pattern as broker.config) ─────
def load_targets() -> list[dict]:
    with _lock:
        targets = _read_json(TARGETS_PATH, [])
        return targets if isinstance(targets, list) else []


def save_targets(targets: list[dict]) -> None:
    with _lock:
        _write_json(TARGETS_PATH, targets)


def get_target(target_id: str) -> dict | None:
    return next((t for t in load_targets() if t.get("id") == target_id), None)


def upsert_target(entry: dict) -> dict:
    with _lock:
        targets = load_targets()
        targets = [t for t in targets if t.get("id") != entry["id"]]
        targets.insert(0, entry)
        save_targets(targets)
        return entry


def remove_target(target_id: str) -> bool:
    with _lock:
        targets = load_targets()
        kept = [t for t in targets if t.get("id") != target_id]
        if len(kept) == len(targets):
            return False
        save_targets(kept)
        return True


# ── Job history (persisted across restarts) ───────────────────────────────────
def load_jobs() -> list[dict]:
    with _lock:
        jobs = _read_json(JOBS_PATH, [])
        return jobs if isinstance(jobs, list) else []


def save_jobs(jobs: list[dict]) -> None:
    with _lock:
        _write_json(JOBS_PATH, jobs[:JOB_RETENTION])


def clear_job_history() -> int:
    """Wipe persisted job history; leaves the registered-targets list alone
    (that's registration config, not scan data). Returns the number removed.
    Callers holding an in-memory DastService must clear its ``_jobs`` dict
    themselves — this only touches persistence."""
    with _lock:
        n = len(load_jobs())
        _write_json(JOBS_PATH, [])
    return n
