"""assetgraph/engine.py — pure extraction: a codemodel report -> assets + edges.

Reuses codemodel's own bounded ``scan_metadata`` (the same structured facts
``guard``, ``chain_reasoning``, and the attack-path synthesizer all already
consume) rather than re-parsing anything — this module's only job is turning
those facts into graph nodes/edges with stable, scope-appropriate identity.
No timestamps or persistence here; :mod:`assetgraph.service` reconciles the
extracted snapshot against what is already stored.
"""
from __future__ import annotations

import hashlib

from .model import Asset, AssetEdge

CONTAINS, CROSSES = "contains", "crosses"


def _id(kind: str, *parts) -> str:
    raw = kind + "\x1f" + "\x1f".join(str(p).strip().lower() for p in parts)
    return "a_" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:16]


def _edge_id(from_id: str, relation: str, to_id: str) -> str:
    raw = f"{from_id}|{relation}|{to_id}"
    return "e_" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:16]


def extract(report: dict) -> tuple[list[Asset], list[AssetEdge]]:
    """Extract this codemodel report's current asset snapshot for its repo.

    The result is authoritative for exactly the one repo the report scanned —
    :mod:`assetgraph.service` uses that completeness to mark any previously
    known repo-scoped asset NOT present here as no longer current.
    """
    meta = report.get("scan_metadata") or {}
    repo_id = str(meta.get("repo_id") or report.get("id") or "")
    repo_name = str(meta.get("repo_name") or report.get("title") or repo_id)
    if not repo_id:
        return [], []

    repo_asset_id = _id("repo", repo_id)
    assets: dict[str, Asset] = {
        repo_asset_id: Asset(
            id=repo_asset_id, kind="repo", name=repo_name,
            attributes={"repo_id": repo_id,
                       "frameworks": sorted(meta.get("frameworks") or []),
                       "languages": sorted(meta.get("languages") or [])}),
    }
    edges: dict[str, AssetEdge] = {}

    def add_edge(from_id: str, relation: str, to_id: str) -> None:
        eid = _edge_id(from_id, relation, to_id)
        edges[eid] = AssetEdge(id=eid, from_id=from_id, to_id=to_id, relation=relation)

    for ep in meta.get("attack_surface") or []:
        locus = ep.get("path") or ep.get("handler") or ""
        aid = _id("entry_point", repo_id, ep.get("method", ""), locus)
        assets[aid] = Asset(
            id=aid, kind="entry_point",
            name=f"{ep.get('method', '')} {locus}".strip(),
            attributes={"framework": ep.get("framework", ""), "kind": ep.get("kind", ""),
                       "authenticated": bool(ep.get("authenticated")),
                       "file": ep.get("file", ""), "line": ep.get("line")})
        add_edge(repo_asset_id, CONTAINS, aid)

    for d in meta.get("data_stores") or []:
        aid = _id("data_store", repo_id, d.get("kind", ""), d.get("engine", ""))
        assets[aid] = Asset(
            id=aid, kind="data_store", name=f"{d.get('kind', '')}/{d.get('engine', '')}",
            attributes={"kind": d.get("kind", ""), "engine": d.get("engine", "")})
        add_edge(repo_asset_id, CONTAINS, aid)

    for c in meta.get("external_calls") or []:
        target = c.get("target", "")
        if not target:
            continue
        # Global identity (no repo_id): the same target called by two repos
        # should resolve to one shared node with two incoming edges, not two
        # unrelated nodes — that merge is the reason this module exists.
        aid = _id("external_service", c.get("kind", ""), target)
        assets[aid] = Asset(
            id=aid, kind="external_service", name=target,
            attributes={"kind": c.get("kind", ""), "target": target,
                       "encrypted": c.get("encrypted", True)})
        add_edge(repo_asset_id, CONTAINS, aid)

    for b in meta.get("trust_boundaries") or []:
        name = b.get("name", "")
        if not name:
            continue
        # Global identity, same reasoning as external_service: "which repos
        # cross the OS/privilege boundary" is a portfolio-wide question.
        aid = _id("trust_boundary", name, b.get("kind", ""))
        assets[aid] = Asset(
            id=aid, kind="trust_boundary", name=name,
            attributes={"boundary_kind": b.get("kind", "")})
        add_edge(repo_asset_id, CROSSES, aid)

    return list(assets.values()), list(edges.values())
