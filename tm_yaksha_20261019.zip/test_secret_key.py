"""Tests for persistent SECRET_KEY resolution (_load_or_create_secret_key).

The bug this guards against: a per-process random SECRET_KEY means every
gunicorn worker signs CSRF tokens with a different key, so POSTs fail with 403
for any request that lands on a worker other than the one that issued the
token. The fix persists one key at ~/.tm_secret_key (env var wins).
"""
from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import app as tm_app


class TestSecretKeyResolution(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        self.key_path = Path(self._td.name) / "secret_key"
        # Ensure the env var never leaks into these tests.
        patcher = mock.patch.dict(os.environ, {"TM_SECRET_KEY": ""})
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_env_var_wins_over_file(self):
        self.key_path.write_text("f" * 64, encoding="ascii")
        with mock.patch.dict(os.environ, {"TM_SECRET_KEY": "e" * 64}):
            self.assertEqual(
                tm_app._load_or_create_secret_key(self.key_path), "e" * 64)

    def test_key_created_then_reused(self):
        first = tm_app._load_or_create_secret_key(self.key_path)
        second = tm_app._load_or_create_secret_key(self.key_path)
        self.assertEqual(first, second)
        self.assertGreaterEqual(len(first), 64)  # token_hex(32)
        self.assertTrue(self.key_path.exists())

    def test_existing_valid_key_wins_over_generation(self):
        self.key_path.write_text("a" * 40, encoding="ascii")
        self.assertEqual(
            tm_app._load_or_create_secret_key(self.key_path), "a" * 40)

    def test_corrupt_short_file_is_replaced_persistently(self):
        # A truncated key file must be healed, not worked around with a
        # process-local key (which would silently resurrect the multi-worker
        # CSRF bug on every boot).
        self.key_path.write_text("short", encoding="ascii")
        first = tm_app._load_or_create_secret_key(self.key_path)
        self.assertGreaterEqual(len(first), 64)
        second = tm_app._load_or_create_secret_key(self.key_path)
        self.assertEqual(first, second)

    def test_non_ascii_garbage_file_is_replaced(self):
        self.key_path.write_bytes(b"\xff\xfe" + os.urandom(40))
        first = tm_app._load_or_create_secret_key(self.key_path)
        self.assertGreaterEqual(len(first), 64)
        self.assertEqual(
            first, tm_app._load_or_create_secret_key(self.key_path))

    def test_unwritable_path_falls_back_to_process_local_key(self):
        missing_dir = Path(self._td.name) / "no_such_dir" / "secret_key"
        key = tm_app._load_or_create_secret_key(missing_dir)
        self.assertGreaterEqual(len(key), 64)

    @unittest.skipIf(os.name == "nt", "POSIX permission bits only")
    def test_created_file_is_owner_only(self):
        tm_app._load_or_create_secret_key(self.key_path)
        mode = self.key_path.stat().st_mode & 0o777
        self.assertEqual(mode, 0o600)


if __name__ == "__main__":
    unittest.main()
