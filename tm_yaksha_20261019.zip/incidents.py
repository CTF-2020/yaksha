"""Production-incident ingestion for the correlation engine.

A SAST/DAST finding proves a weakness is theoretically reachable; a design
finding says it was anticipated. Neither says it actually happened. When a
WAF block, a SIEM alert, or an incident-response ticket confirms a specific
weakness was actually triggered/exploited in production, that is
qualitatively stronger evidence than either — not "this could be exploited"
but "this was".

This module turns that kind of record into the same TM report shape every
other scanner output uses (``methodology="incident"``, one category per
incident tagged ``_source="INCIDENT"``), so it flows through the normal
``_save_report`` pipeline (secret scrubbing, rule enrichment, verdict-
transition tracking) unchanged. The correlation engine (correlator/engine.py)
then recognizes ``_source="INCIDENT"`` as ``SourceKind.INCIDENT`` and assigns
the strongest possible verdict, ``Verdict.ACTIVELY_EXPLOITED`` — see
correlator/engine.py:_verdict.
"""
from __future__ import annotations

import time

# Where the incident was actually observed. Not exhaustive of every possible
# real-world tool, but broad enough to cover the common integration points
# without accepting an arbitrary free-text label that can't be reasoned about.
SOURCES = ("waf", "siem", "ids", "soc", "bug-bounty", "manual")
_SEVERITIES = ("Critical", "High", "Medium", "Low", "Info")


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _normalize_entry(entry, idx: int) -> dict:
    if not isinstance(entry, dict):
        raise ValueError(f"entry {idx}: must be an object")
    weakness = str(entry.get("weakness") or entry.get("family") or "").strip()
    if not weakness:
        raise ValueError(f"entry {idx}: 'weakness' is required")
    locus = str(entry.get("locus") or entry.get("affected_component") or "").strip()
    if not locus:
        raise ValueError(f"entry {idx}: 'locus' is required")
    source = str(entry.get("source") or "manual").strip().lower()
    if source not in SOURCES:
        raise ValueError(f"entry {idx}: source must be one of {', '.join(SOURCES)}")
    severity = str(entry.get("severity") or "High").strip().capitalize()
    if severity not in _SEVERITIES:
        severity = "High"
    return {
        "weakness": weakness,
        "locus": locus,
        "source": source,
        "severity": severity,
        "description": str(entry.get("description") or "").strip()[:2000],
        "detected_at": str(entry.get("detected_at") or "").strip() or _now_iso(),
        "cwe": str(entry.get("cwe") or "").strip(),
    }


def _category(idx: int, entry: dict) -> dict:
    note = (f"Observed in production via {entry['source'].upper()} on "
            f"{entry['detected_at']}."
            + (f" {entry['description']}" if entry["description"] else ""))
    return {
        "id": f"INC-{idx:03d}",
        "category": "Production incident",
        "name": entry["weakness"],
        "title": entry["weakness"],
        "risk": entry["severity"],
        "_source": "INCIDENT",
        "cwe": entry["cwe"],
        "affected_components": [entry["locus"]],
        "description": note,
        "notes": note,
        "mitigation": "Remediate and verify closed — this was observed actually "
                     "happening in production, not just theoretically reachable.",
        "incident_source": entry["source"],
        "detected_at": entry["detected_at"],
    }


def build_incident_report(entries, title: str = "") -> dict:
    """Build a TM report from one or more production-incident entries.

    Each entry: ``{weakness, locus, source?, severity?, description?,
    detected_at?, cwe?}`` — ``weakness`` and ``locus`` are required;
    ``source`` (default "manual") must be one of :data:`SOURCES`.

    Raises ``ValueError`` naming the first invalid entry — all-or-nothing,
    same convention as ``suppressions.store.add_suppression``.
    """
    if not isinstance(entries, list) or not entries:
        raise ValueError("entries must be a non-empty list")
    normalized = [_normalize_entry(e, i) for i, e in enumerate(entries)]
    categories = [_category(i + 1, e) for i, e in enumerate(normalized)]
    worst = min(categories, key=lambda c: _SEVERITIES.index(c["risk"]))["risk"]
    return {
        "title": title or f"Production Incident · {normalized[0]['weakness']}",
        "methodology": "incident",
        "methodology_label": "Production Incident",
        "overall_risk": worst,
        "aggregate_risk": worst,
        "analyzed_at": _now_iso(),
        "summary": f"{len(categories)} production incident(s) recorded: " + "; ".join(
            f"{e['weakness']} ({e['source']})" for e in normalized[:6]),
        "categories": categories,
        "recommendations": [
            "Treat every listed weakness as confirmed exploited, not theoretical — "
            "prioritize remediation over anything not yet observed in production.",
        ],
        "scan_metadata": {"engine": "incidents", "incident_count": len(categories)},
    }
