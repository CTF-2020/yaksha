"""AI-BOM module configuration and persistence.

State lives under ~/.tm_aibom (jobs history + generated BOM documents). The repo
registry is NOT duplicated here: AI-BOM scans the same registered repos as the
SAST broker (broker.config), so registering a repo once makes it visible to both
scanners. SQLite (aibom/db.py, ~/.tm_aibom/aibom.db) is the system of record;
every write here also mirrors to the legacy JSON files as a best-effort,
human-readable backup. This module stays the public surface every caller
uses — db.py is purely the persistence plumbing behind it.
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

import settings_db

STATE_DIR = Path(os.environ.get("TM_AIBOM_DIR", str(Path.home() / ".tm_aibom")))
JOBS_PATH = STATE_DIR / "jobs.json"
BOM_DIR = STATE_DIR / "boms"           # one CycloneDX document per finished job
LATEST_DIR = STATE_DIR / "latest"      # per-repo rollup summary for the org view

STATE_DIR.mkdir(parents=True, exist_ok=True)
BOM_DIR.mkdir(parents=True, exist_ok=True)
LATEST_DIR.mkdir(parents=True, exist_ok=True)

SCAN_TIMEOUT = settings_db.resolve_int(     # engine hard cap, seconds
    "aibom.scan_timeout", os.environ.get("TM_AIBOM_TIMEOUT"), 600)
JOB_RETENTION = settings_db.resolve_int(
    "aibom.job_retention", os.environ.get("TM_AIBOM_JOB_RETENTION"), 200)
MAX_FILE_BYTES = settings_db.resolve_int(
    "aibom.max_file_bytes", os.environ.get("TM_AIBOM_MAX_FILE_BYTES"), 1500000)
MAX_FILES = settings_db.resolve_int(
    "aibom.max_files", os.environ.get("TM_AIBOM_MAX_FILES"), 20000)

_lock = threading.RLock()

_JOB_ID_SAFE = None  # set lazily by is_safe_job_id


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def is_safe_job_id(job_id: str) -> bool:
    """Job ids are generated as aibom_<epoch>_<hex>; reject anything else so a
    job id from a URL can never traverse outside the BOM directory."""
    global _JOB_ID_SAFE
    if _JOB_ID_SAFE is None:
        import re
        _JOB_ID_SAFE = re.compile(r"^aibom_\d{6,}_[0-9a-f]{4,12}$")
    return bool(_JOB_ID_SAFE.match(job_id or ""))


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default
    except (OSError, ValueError):
        return default


def _write_json(path: Path, data) -> None:
    # Delegate to the shared store: fsync + retrying os.replace (rides out
    # Windows sharing violations) instead of a bare, un-synced rename.
    import report_store
    report_store.atomic_write_json(path, data)


def _backup(fn, *args) -> None:
    """Best-effort JSON mirror of a DB write. Never allowed to fail the save."""
    try:
        fn(*args)
    except Exception:  # pragma: no cover - defensive
        import logging
        logging.getLogger("aibom").warning("JSON backup write failed", exc_info=True)


# ── Job history ───────────────────────────────────────────────────────────────
# SQLite (aibom.db, see aibom/db.py) is the system of record; every write here
# also mirrors to the legacy jobs.json/boms/*.json/latest/*.json as a
# best-effort, human-readable backup.
def load_jobs() -> list[dict]:
    from . import db
    with _lock:
        return db.load_jobs()


def save_jobs(jobs: list[dict]) -> None:
    from . import db
    with _lock:
        trimmed = jobs[:JOB_RETENTION]
        db.save_jobs(trimmed)
        _backup(_write_json, JOBS_PATH, trimmed)


# ── BOM documents ─────────────────────────────────────────────────────────────
def save_bom(job_id: str, bom: dict) -> None:
    from . import db
    if not is_safe_job_id(job_id):
        raise ValueError(f"unsafe job id: {job_id!r}")
    with _lock:
        db.save_bom(job_id, bom)
        _backup(_write_json, BOM_DIR / f"{job_id}.json", bom)


def load_bom(job_id: str) -> dict | None:
    from . import db
    if not is_safe_job_id(job_id):
        return None
    with _lock:
        return db.load_bom(job_id)


# ── Per-repo latest rollup (feeds the org-wide inventory view) ────────────────
def save_latest(repo_id: str, summary: dict) -> None:
    from . import db
    # repo ids come from broker.config.slugify, but re-check defensively.
    from broker import config as broker_config
    if not broker_config.is_valid_slug(repo_id):
        raise ValueError(f"unsafe repo id: {repo_id!r}")
    with _lock:
        db.save_latest(repo_id, summary)
        _backup(_write_json, LATEST_DIR / f"{repo_id}.json", summary)


def load_inventory() -> list[dict]:
    """All per-repo rollups, newest scan first."""
    from . import db
    with _lock:
        return db.load_inventory()


def remove_latest(repo_id: str) -> None:
    from . import db
    from broker import config as broker_config
    if not broker_config.is_valid_slug(repo_id):
        return
    with _lock:
        db.remove_latest(repo_id)
        try:
            (LATEST_DIR / f"{repo_id}.json").unlink(missing_ok=True)
        except OSError:
            pass


def clear_all() -> int:
    """Wipe job history, generated BOM documents, and the per-repo latest
    rollup (DB plus their legacy JSON mirrors). Returns the number of jobs
    removed. Callers holding an in-memory AibomService must clear its
    ``_jobs`` dict themselves — this only touches persistence."""
    from . import db
    with _lock:
        n = db.clear_all()
        _backup(_write_json, JOBS_PATH, [])
        for d in (BOM_DIR, LATEST_DIR):
            for f in d.glob("*.json"):
                try:
                    f.unlink()
                except OSError:
                    pass
    return n
