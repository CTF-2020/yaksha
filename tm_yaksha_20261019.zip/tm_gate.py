#!/usr/bin/env python3
"""tm_gate.py — CI/CD pipeline gate for threat modeling.

Exits 0 (pass) or 1 (fail) based on finding severity thresholds.

Usage:
    python tm_gate.py --file arch.txt
    python tm_gate.py --file arch.txt --fail-on High
    python tm_gate.py --file arch.txt --fail-on Critical --rulesets web api cloud
    python tm_gate.py --file arch.txt --format json --out report.json
    echo "arch description" | python tm_gate.py --stdin

GitHub Actions example:
    - name: Threat Model Gate
      run: python tm_gate.py --file docs/architecture.md --fail-on High
"""
from __future__ import annotations
import argparse
import json
import sys
import os
from pathlib import Path

# Allow running from the tm/ directory
sys.path.insert(0, str(Path(__file__).parent))

from offline_rules import run_offline_review, detect_applicable_rulesets
import mitre_attack
import compliance_mappings

_SEV_RANK = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="TM Gate — offline threat model CI/CD gate",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--file",   "-f", metavar="PATH",  help="Architecture description file (txt/md/json)")
    src.add_argument("--stdin",  "-",  action="store_true", help="Read architecture from stdin")

    p.add_argument("--fail-on",  default="High",
                   choices=["Critical", "High", "Medium", "Low"],
                   help="Severity level that causes a non-zero exit (default: High)")
    p.add_argument("--rulesets", nargs="+",
                   choices=["web", "api", "ai", "mobile", "cloud"],
                   help="Force specific rulesets (default: auto-detect)")
    p.add_argument("--format",   default="text", choices=["text", "json", "github"],
                   help="Output format (text|json|github annotations)")
    p.add_argument("--out",      metavar="FILE", help="Write report to file instead of stdout")
    p.add_argument("--title",    default="Architecture",  help="Title for the threat model report")
    p.add_argument("--no-attack", action="store_true",   help="Skip MITRE ATT&CK enrichment")
    p.add_argument("--no-compliance", action="store_true", help="Skip compliance mapping enrichment")
    return p.parse_args()


def _run_gate(args: argparse.Namespace) -> tuple[dict, int]:
    # 1. Read input
    if args.stdin:
        arch_text = sys.stdin.read()
    else:
        path = Path(args.file)
        if not path.exists():
            print(f"[ERROR] File not found: {args.file}", file=sys.stderr)
            sys.exit(2)
        arch_text = path.read_text(encoding="utf-8", errors="replace")

    if not arch_text.strip():
        print("[ERROR] Architecture text is empty.", file=sys.stderr)
        sys.exit(2)

    # 2. Determine rulesets
    rulesets = args.rulesets or detect_applicable_rulesets(arch_text)

    # 3. Run offline review
    review = run_offline_review(arch_text, rulesets=rulesets)

    # 4. Build findings above threshold
    threshold_rank = _SEV_RANK.get(args.fail_on, 1)
    active = [
        f for f in review["findings"]
        if f["status"] in ("FAIL", "WARN") and _SEV_RANK.get(f["severity"], 4) <= threshold_rank
    ]

    # 5. Enrich with ATT&CK + compliance
    if not args.no_attack:
        mitre_attack.enrich_findings(active)
    if not args.no_compliance:
        compliance_mappings.enrich_findings = lambda f: f  # findings not category-enriched here

    # 6. Determine gate result
    has_failures = any(f["status"] == "FAIL" for f in active)
    worst_sev = min((f["severity"] for f in active), key=lambda s: _SEV_RANK.get(s, 4), default="None")
    gate_result = "FAIL" if has_failures else ("WARN" if active else "PASS")
    exit_code = 1 if has_failures else 0

    # 7. Build report
    sc = review["summary_counts"]
    report = {
        "title":           args.title,
        "gate_result":     gate_result,
        "exit_code":       exit_code,
        "fail_on":         args.fail_on,
        "worst_severity":  worst_sev,
        "overall_risk":    review["overall_risk"],
        "rulesets_applied": rulesets,
        "summary_counts":  sc,
        "active_findings": len(active),
        "top_findings": [
            {
                "id":         f["rule_id"],
                "severity":   f["severity"],
                "status":     f["status"],
                "question":   f["question"],
                "mitigations": f["mitigations"][:2],
                "attack_techniques": [t["id"] + " " + t["name"] for t in f.get("attack_techniques", [])],
            }
            for f in sorted(active, key=lambda x: _SEV_RANK.get(x["severity"], 4))[:10]
        ],
        "recommendations": review["recommendations"],
    }
    return report, exit_code


def _format_text(r: dict) -> str:
    icon = "✅" if r["gate_result"] == "PASS" else ("⚠️ " if r["gate_result"] == "WARN" else "❌")
    lines = [
        f"\n{'='*60}",
        f"  TM GATE — {r['title']}",
        f"{'='*60}",
        f"  Result    : {icon} {r['gate_result']}",
        f"  Fail-on   : {r['fail_on']}+",
        f"  Overall   : {r['overall_risk']}",
        f"  Rulesets  : {', '.join(r['rulesets_applied'])}",
        f"  Rules     : {r['summary_counts']['total']} evaluated  |  "
        f"FAIL:{r['summary_counts']['fail']}  WARN:{r['summary_counts']['warn']}  "
        f"PASS:{r['summary_counts']['pass']}",
        "",
    ]
    if r["top_findings"]:
        lines.append("  TOP FINDINGS:")
        for f in r["top_findings"]:
            lines.append(f"  [{f['severity']:8s}] {f['id']}  {f['status']}")
            lines.append(f"    → {f['question']}")
            if f["attack_techniques"]:
                lines.append(f"    ATT&CK: {', '.join(f['attack_techniques'][:3])}")
            if f["mitigations"]:
                lines.append(f"    Fix:    {f['mitigations'][0]}")
            lines.append("")
    if r["recommendations"]:
        lines.append("  RECOMMENDATIONS:")
        for rec in r["recommendations"][:5]:
            lines.append(f"    • {rec}")
    lines.append(f"\n  Exit code: {r['exit_code']}\n{'='*60}\n")
    return "\n".join(lines)


def _format_github(r: dict) -> str:
    """GitHub Actions annotation format."""
    lines = []
    for f in r["top_findings"]:
        level = "error" if f["status"] == "FAIL" else "warning"
        msg = f["question"].replace("\n", " ")
        lines.append(f"::{level} title=TM-{f['severity']}-{f['id']}::{msg}")
    if r["gate_result"] == "PASS":
        lines.append("::notice title=TM Gate::All checks passed ✅")
    return "\n".join(lines)


def main():
    args = _parse_args()
    report, exit_code = _run_gate(args)

    if args.format == "json":
        output = json.dumps(report, indent=2)
    elif args.format == "github":
        output = _format_github(report)
    else:
        output = _format_text(report)

    if args.out:
        Path(args.out).write_text(output, encoding="utf-8")
        print(f"Report written to {args.out}")
        _print_summary(report)
    else:
        print(output)

    sys.exit(exit_code)


def _print_summary(r: dict):
    icon = "✅" if r["gate_result"] == "PASS" else "❌"
    print(f"{icon} Gate: {r['gate_result']} | Risk: {r['overall_risk']} | "
          f"FAIL:{r['summary_counts']['fail']} WARN:{r['summary_counts']['warn']}")


if __name__ == "__main__":
    main()
