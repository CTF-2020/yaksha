"""broker/remediation.py — human-gated fix-PR proposals for SAST findings.

TM has never had a way to *act* on a finding beyond filing a ticket
(jira_client.py) or displaying a suggested rewrite (reviewer.py's
``review.suggestion``, display-only). This module is the first thing that
writes to a repo's git history, so it is deliberately narrow and two-step:

  1. :func:`propose_fix` — read-only. Looks up one finding's already-computed
     mechanical fix suggestion (``reviewer.py``'s ``_FIX_TABLE`` — no LLM, no
     free-form patch generation), confirms it lands on a line the diff
     against ``against`` actually *added* (:mod:`guard.diff`, so a stale
     finding in a file the change merely touched is never "fixed"), and
     returns a ready-to-review unified diff. No git write happens here.
  2. :func:`open_pr` — the only function in this module that mutates a repo.
     Takes the exact patch text a human already reviewed from step 1, applies
     it in a freshly prepared clone, commits, pushes, and opens a PR. Requires
     ``repo["remediation_enabled"]`` (opt-in, off by default) and reuses the
     same registry-scoped GitHub token ``broker/scanner.py`` already uses for
     cloning — never a token or ref sourced from an inbound webhook payload.
  3. :func:`queue` — read-only. Every fix-eligible finding (a mechanical
     suggestion exists, per :func:`propose_fix`'s own criterion) across every
     remediation-enabled repo's latest SAST scan, ranked so a human working
     the loop tackles the most actionable ones first instead of hand-typing
     (report_id, category_id, file, line) coordinates for whichever finding
     they happen to remember. See its docstring for how "most actionable" is
     decided and why a fingerprint join could not be used for it.

Explicitly NOT here: LLM-generated patches, auto-merge, or any trigger that
fires without an explicit human call to open_pr(). See the plan doc for why —
short version: every existing GitHub write in this codebase
(``broker/github.py``) is metadata/commentary only, and this is the first
code-mutating one, so it stays behind a human review step until that class of
action has a track record.
"""
from __future__ import annotations

import difflib
import re
import time
from pathlib import Path

import report_db
import suppressions
from guard import diff as guard_diff
from suppressions.model import VERDICT_RANK

from . import config, scanner
from .github import GitHubClient, is_valid_ref
from .scanner import prepare_workspace


class RemediationError(RuntimeError):
    """Raised for any propose/open-pr failure the API layer should surface cleanly."""


def find_threat(report: dict, category_id: str, file: str, line: int) -> dict | None:
    """Locate the one file:line hit a propose/open-pr call is addressing.

    TM has no standalone "finding id" — a hit is addressed by
    (report, category, file, line), matching how ``broker/mapper.py`` nests
    each scan hit as a ``threats[]`` entry inside its rule category.
    """
    for cat in report.get("categories", []):
        if cat.get("id") != category_id:
            continue
        for t in cat.get("threats", []):
            if t.get("line") == line and file and file in (t.get("name") or ""):
                return t
    return None


def _diff_against_branch(scan_root: str, base_branch: str) -> str:
    """Tree-to-tree diff of ``scan_root``'s current HEAD against ``base_branch``.

    Same technique ``broker/pr_tm.py::changed_files`` already uses for PR-scoped
    threat modeling: ``prepare_workspace`` shallow-clones (--depth 1), so there
    is no shared history for a merge-base diff. Fetching the base branch's tip
    (also depth 1 — only its tree is needed) repoints FETCH_HEAD at it, and a
    FETCH_HEAD..HEAD diff needs no common ancestor at all.
    """
    if not is_valid_ref(base_branch):
        raise scanner.ScanError(f"not a valid branch name: {base_branch!r}")
    scanner._run_git(["fetch", "--depth", "1", "--", "origin", base_branch], cwd=scan_root)
    return scanner._run_git(["diff", "FETCH_HEAD", "HEAD"], cwd=scan_root)


def propose_fix(repo: dict, report: dict, category_id: str, file: str, line: int,
                against: str) -> dict:
    """Read-only: return a reviewable patch for one finding, or why not.

    ``against`` is a branch name on the repo's ``origin`` remote (typically its
    default branch) — the finding is only "eligible" if its file:line was
    *added* by the diff between that branch and the currently scanned HEAD.

    Return shape: {"eligible": bool, "reason": str, ...}. "reason" is always
    present when eligible is False; "patch"/"note"/"kind" are present when True.
    No git write happens in this function.
    """
    threat = find_threat(report, category_id, file, line)
    if threat is None:
        return {"eligible": False, "reason": "finding not found in this report"}

    suggestion = (threat.get("review") or {}).get("suggestion") or {}
    fix_diff = suggestion.get("diff")
    if not fix_diff:
        return {"eligible": False,
                "reason": "no mechanical fix is available for this finding "
                          "(advice-only or no known rewrite pattern)"}

    scan_root, _meta = prepare_workspace(repo)
    scan_root = str(scan_root)
    try:
        diff_text = _diff_against_branch(scan_root, against)
    except scanner.ScanError as exc:
        return {"eligible": False,
                "reason": f"could not diff against {against!r}: {exc}"}

    added = guard_diff.parse_added_lines(diff_text)
    if line not in added.get(file, set()):
        return {"eligible": False,
                "reason": f"this finding is not on a line the diff against "
                          f"{against!r} added — remediation only proposes fixes for "
                          "code your own recent change introduced"}

    target = (Path(scan_root) / file)
    try:
        original = target.read_text(encoding="utf-8")
    except OSError as exc:
        return {"eligible": False, "reason": f"could not read {file}: {exc}"}
    original_lines = original.splitlines(keepends=True)
    if not (0 < line <= len(original_lines)):
        return {"eligible": False, "reason": f"line {line} is out of range for {file}"}

    old_text, new_text = fix_diff[0][1], fix_diff[1][1]
    current = original_lines[line - 1]
    if current.strip() != old_text.strip():
        return {"eligible": False,
                "reason": "the file has changed since this finding was scanned "
                          "(the flagged line no longer matches) — re-scan before proposing a fix"}

    indent = current[:len(current) - len(current.lstrip())]
    newline = "\n" if current.endswith("\n") else ""
    patched_lines = list(original_lines)
    patched_lines[line - 1] = f"{indent}{new_text}{newline}"

    patch = "".join(difflib.unified_diff(
        original_lines, patched_lines,
        fromfile=f"a/{file}", tofile=f"b/{file}", lineterm="\n"))

    return {
        "eligible": True,
        "file": file,
        "line": line,
        "patch": patch,
        "note": suggestion.get("note", ""),
        "kind": suggestion.get("kind", ""),
    }


def open_pr(repo: dict, patch: str, file: str, category_id: str, report_id: str,
           title: str | None = None, branch: str | None = None) -> dict:
    """The only git-write action in this module. Requires explicit opt-in.

    ``patch`` must be the exact text a human already reviewed from
    propose_fix's response — this function does not regenerate it, only
    (re-)validates that it still applies before writing anything.
    """
    if not repo.get("remediation_enabled"):
        raise RemediationError(
            f"remediation is not enabled for repo {repo.get('id')!r} "
            "(set remediation_enabled=true to opt in)")

    full_name = (repo.get("github_full_name") or "").strip() or \
        config.github_full_name_from_url(repo.get("url", ""))
    if not full_name:
        raise RemediationError("repo is not a recognized GitHub repository "
                               "(no github_full_name and URL is not github.com)")

    scan_root, _meta = prepare_workspace(repo)
    scan_root = str(scan_root)

    branch = branch or f"tm-remediation/{category_id.lower()}-{int(time.time())}"
    if not is_valid_ref(branch):
        raise RemediationError(f"not a valid branch name: {branch!r}")
    title = title or f"Fix: {category_id} in {file}"
    base_branch = (repo.get("branch") or "main").strip()

    patch_path = Path(scan_root) / f".tm-remediation-{int(time.time())}.patch"
    try:
        patch_path.write_text(patch, encoding="utf-8")
        try:
            scanner._run_git(["apply", "--check", str(patch_path)], cwd=scan_root)
            scanner._run_git(["apply", str(patch_path)], cwd=scan_root)
            scanner._run_git(["checkout", "-b", branch], cwd=scan_root)
            scanner._run_git(["add", "--", file], cwd=scan_root)
            scanner._run_git(["-c", "user.email=yaksha-guard@localhost",
                              "-c", "user.name=Yaksha Guard", "commit", "-m", title],
                             cwd=scan_root)
            scanner._run_git(["push", "origin", f"HEAD:refs/heads/{branch}"], cwd=scan_root)
        except scanner.ScanError as exc:
            raise RemediationError(f"could not apply/push the patch: {exc}") from exc
    finally:
        patch_path.unlink(missing_ok=True)

    token = repo.get("github_token") or config.GITHUB_TOKEN
    client = GitHubClient(token)
    body_md = (f"Automated fix proposed by Yaksha Guard remediation for finding "
              f"`{category_id}` ({file}) in report `{report_id}`.\n\n"
              "This PR was opened only after a human explicitly approved the "
              "proposed patch — see the linked report for the original finding.")
    try:
        pr = client.create_pull_request(full_name, title=title, head=branch,
                                        base=base_branch, body_md=body_md)
    except Exception as exc:
        raise RemediationError(f"branch {branch!r} was pushed but opening the PR "
                               f"failed: {exc}") from exc

    pr_number = pr.get("number")
    if pr_number:
        try:
            client.upsert_pr_comment(
                full_name, pr_number,
                f"Opened by Yaksha Guard remediation · finding `{category_id}` "
                f"({file}) · report `{report_id}`.")
        except Exception:
            pass  # best-effort, matches the rest of broker/github.py's comment posting

    return {
        "success": True,
        "pr_url": pr.get("html_url", ""),
        "pr_number": pr_number,
        "branch": branch,
    }


# "[Static (code)] path:line" -> "path:line" — correlator/mapper.py's
# _threat_from_observation prefixes every re-emitted threat's locus with its
# evidence kind; the raw SAST finding's own threat name never carries that
# prefix, so this is needed on the correlation side only.
_LOCUS_PREFIX_RE = re.compile(r"^\[[^\]]+\]\s*(.+)$")


def _clean_locus(locus: str) -> str:
    m = _LOCUS_PREFIX_RE.match(str(locus or "").strip())
    return (m.group(1) if m else str(locus or "")).strip()


def _verdict_index(reports: list[dict], supps) -> dict[str, dict[str, str]]:
    """sast_report_id -> {"file:line": most_actionable_verdict}, built once
    from every live correlation report so :func:`queue` doesn't re-scan the
    whole report store per finding.

    Deliberately NOT a fingerprint join: the correlator always mints each
    cluster a synthetic category id (CORR-NNN) and a taxonomy-canonical
    family, neither of which matches a raw SAST category's own rule id / raw
    title-derived family — verified empirically, the two hash completely
    differently even for "the same" finding. The only identity a correlation
    report actually preserves from its SAST source is the ORIGINAL locus
    (file:line), re-emitted verbatim (just prefixed) inside each cluster's
    threats — see correlator/mapper.py's ``_threat_from_observation``. So
    identity here is (source SAST report id, exact locus), not a fingerprint.
    """
    index: dict[str, dict[str, str]] = {}
    for r in reports:
        if str(r.get("methodology", "")).lower() != "correlation":
            continue
        meta = r.get("scan_metadata") or {}
        sources = {s.get("id") for s in (meta.get("source_reports") or [])
                  if isinstance(s, dict) and s.get("id")}
        if not sources:
            continue
        annotated = suppressions.annotate_report(r, supps)
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            verdict = cat.get("verdict")
            if not verdict:
                continue
            for t in cat.get("threats") or []:
                if not isinstance(t, dict):
                    continue
                locus = _clean_locus(t.get("name"))
                if not locus:
                    continue
                for sid in sources:
                    bucket = index.setdefault(sid, {})
                    prev = bucket.get(locus)
                    if prev is None or VERDICT_RANK.get(verdict, 99) < VERDICT_RANK.get(prev, 99):
                        bucket[locus] = verdict
    return index


def queue(repo_id: str | None = None, limit: int = 100) -> list[dict]:
    """Fix-PR-eligible findings across every remediation-enabled repo (or
    just ``repo_id``, if given), verdict-first: an actively_exploited or
    confirmed_exploitable finding with a mechanical fix available leads the
    queue; a finding that was never correlated (no verdict at all) sinks to
    the back, ranked only by severity among itself — the same "nothing
    proven yet is not automatically worse than a proven exploit" ordering
    fleet.py already applies to repo posture.

    Read-only and best-effort: never opens a workspace clone, diffs, or
    writes anything. A queue entry only means "a mechanical fix suggestion
    exists here and this finding isn't suppressed" — :func:`propose_fix`
    still re-validates real eligibility (the line is still one the diff
    against the target branch added, the file hasn't changed since) at the
    moment a human actually acts on an entry.
    """
    repos = [config.get_repo(repo_id)] if repo_id else config.load_repos()
    repos = [r for r in repos if r and r.get("remediation_enabled")]
    if not repos:
        return []

    all_reports = report_db.all_reports(limit=2000)
    supps = suppressions.load_suppressions()
    verdict_index = _verdict_index(all_reports, supps)
    reports_by_id = {r.get("id"): r for r in all_reports}

    from correlator.model import SEVERITY_ORDER   # lazy: keeps import graph light

    items = []
    for repo in repos:
        sast_report_id = (repo.get("last_scan") or {}).get("report_id")
        report = reports_by_id.get(sast_report_id) if sast_report_id else None
        if report is None:
            continue
        annotated = suppressions.annotate_report(report, supps)
        verdicts_for_report = verdict_index.get(sast_report_id, {})
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            for t in cat.get("threats") or []:
                if not isinstance(t, dict):
                    continue
                suggestion = (t.get("review") or {}).get("suggestion") or {}
                if not suggestion.get("diff"):
                    continue   # no mechanical fix -- not fix-eligible
                locus = _clean_locus(t.get("name"))
                file, sep, line_s = locus.rpartition(":")
                if not sep:
                    continue
                try:
                    line = int(line_s)
                except ValueError:
                    continue
                items.append({
                    "repo_id": repo.get("id"), "repo_name": repo.get("name") or repo.get("id"),
                    "report_id": sast_report_id, "category_id": cat.get("id"),
                    "title": cat.get("name") or cat.get("title") or cat.get("id") or "Finding",
                    "severity": cat.get("risk") or cat.get("severity") or "Info",
                    "file": file, "line": line,
                    "verdict": verdicts_for_report.get(locus, ""),
                    "fix_kind": suggestion.get("kind", ""),
                    "fix_note": suggestion.get("note", ""),
                })

    items.sort(key=lambda it: (
        VERDICT_RANK.get(it["verdict"], len(VERDICT_RANK)),
        SEVERITY_ORDER.get(it["severity"], 99),
    ))
    return items[:max(1, min(limit, 500))]
