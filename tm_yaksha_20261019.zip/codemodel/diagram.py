"""Render a SystemModel as a canonical STRIDE data-flow threat model (Mermaid).

Unlike diagram_generator.py (which asks an LLM to guess a diagram from prose),
this is fully deterministic and offline: it draws exactly the design facts the
extractor found, arranged the way a threat modeler reads a DFD — the attack
surface, the trust boundaries, and above all the *flows that cross those
boundaries*, which is where threats live.

What it draws, and why each part is a threat-model primitive:

  * External actor and every entry point (attack surface). Entry points are
    risk-heat coloured by the worst dangerous operation they can reach and by
    whether they are authenticated — an unauthenticated entry that reaches a
    tainted sink is the loudest node on the canvas.
  * The *dangerous operations* each entry point can actually reach
    (``reachable_sinks``): SQL/command/eval/path/… sinks drawn in their own
    zone, with the real attack path from entry point to sink as an edge.
  * STRIDE annotations on trust-boundary-crossing flows, derived from the
    weakness family (never guessed): e.g. a tainted SQL flow is Tampering,
    a cleartext external call is Information Disclosure + Tampering.
  * Data stores, external services (cleartext flagged), and hardcoded secrets.
  * Trust boundaries as subgraph zones; a legend; a one-line threat summary.

Edge semantics are encoded with Mermaid ``linkStyle`` so the diagram reads at
a glance: exploitable (tainted) paths are thick red, other boundary crossings
are dashed amber, authenticated ingress is green, internal flows are plain.

Output is a Mermaid ``flowchart LR`` string with balanced ``subgraph`` / ``end``
blocks; every label is quote- and syntax-safe, and ASCII-only so report and PDF
export never choke on it.
"""
from __future__ import annotations

import re

_MAX_ENTRY = 24          # keep the diagram legible on large apps
_MAX_STORE = 16
_MAX_EXTERNAL = 16
_MAX_SINK = 20           # dangerous-operation nodes
_MAX_SECRET = 8

# Short human labels for sink kinds the extractor emits.
_SINK_LABEL = {
    "sql": "SQL query", "command": "OS command", "code-eval": "code eval",
    "deserialize": "deserialize", "path": "file path", "ssrf": "server-side request",
    "template": "template render", "redirect": "open redirect", "ldap": "LDAP query",
    "xpath": "XPath query",
}

# Weakness family -> STRIDE categories (mirrors codemodel.threats._FAMILY_META,
# inlined so the diagram never imports the threat engine at draw time).
_FAMILY_STRIDE = {
    "sql-injection": ["Tampering"],
    "command-injection": ["Tampering", "Elevation of Privilege"],
    "code-injection": ["Tampering", "Elevation of Privilege"],
    "deserialization": ["Tampering", "Elevation of Privilege"],
    "template-injection": ["Tampering"],
    "ssrf": ["Information Disclosure", "Spoofing"],
    "path-traversal": ["Information Disclosure"],
    "open-redirect": ["Spoofing"],
    "broken-access-control": ["Elevation of Privilege"],
    "sensitive-data-exposure": ["Information Disclosure"],
    "crypto-failure": ["Information Disclosure"],
    "security-misconfig": ["Information Disclosure"],
}
_FAMILY_SEVERITY = {
    "command-injection": "Critical", "code-injection": "Critical",
    "deserialization": "Critical", "template-injection": "High", "ssrf": "High",
    "sql-injection": "High", "path-traversal": "Medium", "open-redirect": "Medium",
}
_STRIDE_INITIAL = {
    "Spoofing": "S", "Tampering": "T", "Repudiation": "R",
    "Information Disclosure": "I", "Denial of Service": "D",
    "Elevation of Privilege": "E",
}
_SEV_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
_SEV_CLASS = {"Critical": "sevCrit", "High": "sevHigh", "Medium": "sevMed"}


def _slug(prefix: str, seen: dict, raw: str) -> str:
    """Stable, unique, Mermaid-safe node id for a label."""
    base = prefix + (re.sub(r"[^A-Za-z0-9]+", "", raw) or "x")[:24]
    node = base
    i = 1
    while seen.get(node) not in (None, raw):
        i += 1
        node = f"{base}_{i}"
    seen[node] = raw
    return node


def _lbl(text: str, limit: int = 40) -> str:
    """Quote-safe Mermaid label."""
    clean = re.sub(r"\s+", " ", str(text or "")).replace('"', "'").strip()
    # Mermaid treats these as syntax inside labels; neutralise them.
    clean = clean.replace("[", "(").replace("]", ")").replace("{", "(").replace("}", ")")
    clean = clean.replace("|", "/")
    return clean[:limit] or "?"


def _sink_key(s) -> str:
    return f"{s.kind}:{s.file}:{s.line}:{getattr(s, 'name', '')}"


def _stride_tag(family: str) -> str:
    """Compact STRIDE initials for a weakness family, e.g. 'T,E'."""
    cats = _FAMILY_STRIDE.get(family or "", [])
    return ",".join(_STRIDE_INITIAL[c] for c in cats if c in _STRIDE_INITIAL)


def _basename(path: str) -> str:
    return (path or "").replace("\\", "/").split("/")[-1]


def _entry_risk_class(ep) -> str:
    """Risk-heat class for an entry point from its reachable sinks + auth."""
    sinks = getattr(ep, "reachable_sinks", None) or []
    tainted = [s for s in sinks if getattr(s, "tainted", False)]
    if tainted:
        worst = min((_FAMILY_SEVERITY.get(s.family, "Medium") for s in tainted),
                    key=lambda s: _SEV_ORDER[s])
        if not ep.authenticated and _SEV_ORDER[worst] > 0:      # bump one tier
            worst = ["Critical", "High", "Medium"][max(0, _SEV_ORDER[worst] - 1)]
        return _SEV_CLASS.get(worst, "sevMed")
    if sinks or not ep.authenticated:
        return "warnbox"                                        # exposed surface
    return "safe"


def to_mermaid_dfd(model, title: str = "") -> str:
    seen: dict = {}
    node_lines: list[str] = []
    edges: list[dict] = []            # {src, dst, label, bucket}

    node_lines.append('  Actor(["External Actor / Internet"]):::actor')

    node_class: dict = {}             # node id -> css class for a final class stmt

    # ── Entry points (attack surface) inside an application trust boundary ──────
    entry_nodes: list[tuple] = []     # (nid, ep)
    for ep in model.entry_points[:_MAX_ENTRY]:
        nid = _slug("E_", seen, ep.locus or ep.handler)
        method = (ep.method or "").strip()
        label = _lbl(f"{method} {ep.path}".strip() or ep.handler)
        entry_nodes.append((nid, ep))
        node_class[nid] = _entry_risk_class(ep)
        node_lines.append(f'    {nid}["{label}"]')

    # Threat summary for the boundary title.
    n_unauth = sum(1 for _, ep in entry_nodes if not ep.authenticated)
    exploit_pairs = set()
    for nid, ep in entry_nodes:
        for s in (getattr(ep, "reachable_sinks", None) or []):
            if getattr(s, "tainted", False):
                exploit_pairs.add((nid, _sink_key(s)))
    n_exploit = len(exploit_pairs)

    app_name = _lbl(title or "Application", 30)
    summary = []
    if n_exploit:
        summary.append(f"{n_exploit} exploitable path(s)")
    if n_unauth:
        summary.append(f"{n_unauth} unauth entry(s)")
    app_title = app_name + (" - " + ", ".join(summary) if summary else "") + " (trust boundary)"
    if entry_nodes:
        node_lines.insert(1, f'  subgraph APP["{app_title}"]')
        node_lines.append("  end")
    else:
        node_lines.append(f'  APP["{app_name}: no HTTP entry points detected"]')

    # ── Dangerous operations (reachable sinks) — the heart of the threat view ──
    sink_id: dict = {}
    edges_entry_sink: list = []       # (entry_nid, sink_nid, sink)
    ranked: list = []
    for nid, ep in entry_nodes:
        for s in (getattr(ep, "reachable_sinks", None) or []):
            ranked.append((0 if getattr(s, "tainted", False) else 1, nid, s))
    ranked.sort(key=lambda t: t[0])

    if ranked:
        node_lines.append('  subgraph SINKS["Dangerous operations (reachable sinks)"]')
        for _, nid, s in ranked:
            key = _sink_key(s)
            if key not in sink_id and len(sink_id) < _MAX_SINK:
                snid = _slug("S_", seen, key)
                kind = _SINK_LABEL.get(s.kind, s.kind or "sink")
                loc = f"{_basename(s.file)}:{s.line}" if s.file else ""
                node_lines.append(f'    {snid}[/"{_lbl(kind + (f" @ {loc}" if loc else ""), 40)}"/]')
                sink_id[key] = snid
                if getattr(s, "tainted", False):
                    sev = _FAMILY_SEVERITY.get(s.family, "High")
                    node_class[snid] = _SEV_CLASS.get(sev, "sevHigh")
                else:
                    node_class[snid] = "warnbox"
            if key in sink_id:
                edges_entry_sink.append((nid, sink_id[key], s))
        node_lines.append("  end")

    # ── Data stores ────────────────────────────────────────────────────────────
    store_nodes: list[str] = []
    if model.data_stores:
        node_lines.append('  subgraph DATA["Persistence (trust boundary)"]')
        for ds in model.data_stores[:_MAX_STORE]:
            nid = _slug("D_", seen, f"{ds.kind}:{ds.engine}")
            if nid in store_nodes:
                continue
            node_lines.append(f'    {nid}[("{_lbl(ds.engine or ds.kind, 24)}")]:::store')
            store_nodes.append(nid)
        node_lines.append("  end")

    # ── External services ──────────────────────────────────────────────────────
    ext_nodes: list[tuple] = []       # (nid, encrypted)
    if model.external_calls:
        node_lines.append('  subgraph EXT["External services (trust boundary)"]')
        seen_ext = set()
        for ec in model.external_calls[:_MAX_EXTERNAL]:
            nid = _slug("X_", seen, f"{ec.kind}:{ec.target}")
            if nid in seen_ext:
                continue
            seen_ext.add(nid)
            suffix = "" if ec.encrypted else " [cleartext]"
            node_lines.append(f'    {nid}["{_lbl(ec.target or ec.kind, 30)}{suffix}"]')
            node_class[nid] = "extnode" if ec.encrypted else "warnbox"
            ext_nodes.append((nid, ec.encrypted))
        node_lines.append("  end")

    # ── Secrets ─────────────────────────────────────────────────────────────────
    hardcoded = [s for s in getattr(model, "secrets", []) if not getattr(s, "managed", True)]
    if hardcoded:
        node_lines.append('  subgraph SECRETS["Hardcoded secrets"]')
        for sec in hardcoded[:_MAX_SECRET]:
            nid = _slug("K_", seen, f"{sec.name}:{sec.file}:{sec.line}")
            loc = f"{_basename(sec.file)}:{sec.line}" if sec.file else ""
            node_lines.append(f'    {nid}>"{_lbl(sec.name + (f" @ {loc}" if loc else ""), 34)}"]:::warnbox')
        node_lines.append("  end")

    # ── Edges (collected with a bucket that maps to a linkStyle) ────────────────
    if entry_nodes:
        for nid, ep in entry_nodes:
            if ep.authenticated:
                edges.append({"src": "Actor", "dst": nid, "label": "authenticated", "bucket": "auth"})
            else:
                edges.append({"src": "Actor", "dst": nid, "label": "S,E unauth", "bucket": "xdanger"})
        drawn = set()
        for enid, snid, s in edges_entry_sink:
            if (enid, snid) in drawn:
                continue
            drawn.add((enid, snid))
            if getattr(s, "tainted", False):
                tag = _stride_tag(s.family) or "T"
                cwe = (getattr(s, "cwe", "") or "").strip()
                lab = f"{tag} {cwe}".strip()
                edges.append({"src": enid, "dst": snid, "label": lab, "bucket": "attack"})
            else:
                edges.append({"src": enid, "dst": snid, "label": "", "bucket": "flow"})
        # Persistence + externals connect on the path (from a sink when present).
        anchor = next(iter(sink_id.values())) if sink_id else (entry_nodes[0][0])
        primary = entry_nodes[0][0]
        for sid in store_nodes:
            edges.append({"src": anchor, "dst": sid, "label": "T,I", "bucket": "xflow"})
        for xid, enc in ext_nodes:
            if enc:
                edges.append({"src": primary, "dst": xid, "label": "", "bucket": "flow"})
            else:
                edges.append({"src": primary, "dst": xid, "label": "I,T cleartext", "bucket": "xdanger"})
    else:
        for sid in store_nodes:
            edges.append({"src": "APP", "dst": sid, "label": "", "bucket": "flow"})
        for xid, _enc in ext_nodes:
            edges.append({"src": "APP", "dst": xid, "label": "", "bucket": "flow"})

    # ── Assemble ────────────────────────────────────────────────────────────────
    init = ("%%{init: {'flowchart': {'curve':'basis','nodeSpacing':45,"
            "'rankSpacing':70,'padding':10,'useMaxWidth':true}}}%%")
    out = [init, "flowchart LR"]
    out += node_lines

    # Emit edges, recording each edge's global index for linkStyle targeting.
    bucket_idx: dict = {"attack": [], "xdanger": [], "xflow": [], "auth": [], "flow": []}
    idx = 0
    for e in edges:
        if e["label"]:
            out.append(f'  {e["src"]} -->|{e["label"]}| {e["dst"]}')
        else:
            out.append(f'  {e["src"]} --> {e["dst"]}')
        bucket_idx[e["bucket"]].append(idx)
        idx += 1

    # Node risk classes.
    out.append("  classDef sevCrit fill:#7f1d1d,stroke:#ef4444,color:#fee2e2,stroke-width:2px")
    out.append("  classDef sevHigh fill:#7c2d12,stroke:#f97316,color:#ffedd5,stroke-width:2px")
    out.append("  classDef sevMed fill:#78350f,stroke:#f59e0b,color:#fef3c7")
    out.append("  classDef warnbox fill:#422006,stroke:#a16207,color:#fef9c3")
    out.append("  classDef safe fill:#064e3b,stroke:#10b981,color:#d1fae5")
    out.append("  classDef store fill:#0c4a6e,stroke:#0ea5e9,color:#e0f2fe")
    out.append("  classDef extnode fill:#1e293b,stroke:#64748b,color:#e2e8f0")
    out.append("  classDef actor fill:#1e1b4b,stroke:#818cf8,color:#e0e7ff")
    out.append("  classDef legendbox fill:#111827,stroke:#374151,color:#9ca3af")

    for nid, cls in node_class.items():
        out.append(f"  class {nid} {cls}")

    # Edge styling by bucket (linkStyle takes comma-separated global indices).
    def _ls(indices, style):
        if indices:
            out.append(f"  linkStyle {','.join(map(str, indices))} {style}")
    _ls(bucket_idx["attack"], "stroke:#ef4444,stroke-width:3px,color:#fecaca")
    _ls(bucket_idx["xdanger"], "stroke:#ef4444,stroke-width:2px,stroke-dasharray:5 4,color:#fecaca")
    _ls(bucket_idx["xflow"], "stroke:#f59e0b,stroke-width:2px,stroke-dasharray:4 4,color:#fde68a")
    _ls(bucket_idx["auth"], "stroke:#10b981,stroke-width:1.5px,color:#a7f3d0")

    # Legend (unconnected nodes stack compactly; excluded from linkStyle above).
    out.append('  subgraph LEGEND["Legend"]')
    out.append("    direction TB")
    out.append('    LG1["Unauth / exploitable entry"]:::sevCrit')
    out.append('    LG2[/"Dangerous operation (sink)"/]:::sevHigh')
    out.append('    LG3["Reachable / exposed"]:::warnbox')
    out.append('    LG4["Authenticated / safe"]:::safe')
    out.append('    LG5[("Data store")]:::store')
    out.append("  end")

    return "\n".join(out)
