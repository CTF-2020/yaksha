"""Contract tests for the versioned API surface."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import app as tm_app
import report_db


def _isolate_report_store(tmp_path, monkeypatch):
    monkeypatch.setattr(tm_app, "REPORTS_DIR", tmp_path)
    monkeypatch.setattr(report_db, "DB_PATH", tmp_path / "reports.db")


def test_api_v1_manifest_lists_separate_feature_apis():
    client = tm_app.app.test_client()

    response = client.get("/api/v1")

    assert response.status_code == 200
    body = response.get_json()
    assert body["success"] is True
    assert "analysis" in body["apis"]
    assert body["apis"]["analysis"]["create_review"] == "/api/v1/analysis/reviews"
    assert body["apis"]["reports"]["list"] == "/api/v1/reports"
    assert body["apis"]["controls"]["get"] == "/api/v1/reports/{report_id}/controls"
    assert body["apis"]["patterns"]["list"] == "/api/v1/patterns"
    assert body["apis"]["sast"]["repos"] == "/api/v1/sast/repos"
    assert body["apis"]["sast"]["remediation_propose"] == \
        "/api/v1/sast/repos/{repo_id}/remediation/propose"
    assert body["apis"]["sast"]["remediation_open_pr"] == \
        "/api/v1/sast/repos/{repo_id}/remediation/open-pr"
    assert body["apis"]["correlation"]["run"] == "/api/v1/correlate/run"
    assert body["apis"]["code_model"]["analyze"] == "/api/v1/code-model/analyze"
    assert body["apis"]["aibom"]["inventory"] == "/api/v1/aibom/inventory"
    assert body["apis"]["dashboard"]["overview"] == "/api/v1/dashboard"
    assert body["apis"]["nav"]["get"] == "/api/v1/nav"
    assert body["apis"]["reports"]["export_sarif"] == "/api/v1/reports/{report_id}/export/sarif"
    assert body["legacy_api_supported"] is True


def test_api_v1_routes_are_registered_by_feature_blueprints():
    routes = {rule.rule: rule.endpoint for rule in tm_app.app.url_map.iter_rules()}

    assert routes["/api/v1/analysis/reviews"].startswith("analysis_api.")
    assert routes["/api/v1/diagrams/architecture"].startswith("diagrams_api.")
    assert routes["/api/v1/reports"].startswith("reports_api.")
    assert routes["/api/v1/sbom/analyze"].startswith("sbom_api.")
    assert routes["/api/v1/reports/<report_id>/controls"].startswith("controls_api.")
    assert routes["/api/v1/pqc/assess"].startswith("pqc_api.")
    assert routes["/api/v1/patterns"].startswith("patterns_api.")
    assert routes["/api/v1/lookups/attack/<category>"].startswith("lookups_api.")
    assert routes["/api/v1/sast/repos/<repo_id>/remediation/propose"].startswith("sast_api.")
    assert routes["/api/v1/sast/repos/<repo_id>/remediation/open-pr"].startswith("sast_api.")


def test_api_v1_analysis_review_alias_persists_report(tmp_path, monkeypatch):
    _isolate_report_store(tmp_path, monkeypatch)

    def fake_analyze(api_key, architecture_text, **kwargs):
        return {
            "title": kwargs.get("title", "Test"),
            "methodology": "test",
            "summary": "ok",
            "overall_risk": "Low",
            "categories": [],
            "recommendations": [],
            "analyzed_at": "2026-05-21T00:00:00",
            "architecture_seen": architecture_text,
        }

    monkeypatch.setattr(tm_app.analyzer, "analyze", fake_analyze)
    client = tm_app.app.test_client()
    token = client.get("/api/csrf-token").get_json()["token"]

    response = client.post(
        "/api/v1/analysis/reviews",
        json={
            "api_key": "",
            "title": "V1 Review",
            "methodology": ["owasp_api", "owasp_llm"],
            "architecture": "React client, API gateway, LLM RAG service, PostgreSQL.",
        },
        headers={"X-CSRF-Token": token},
    )

    assert response.status_code == 200
    body = response.get_json()
    assert body["success"] is True
    report_id = body["id"]
    saved = report_db.get_report(report_id)
    assert saved["title"] == "V1 Review"
    assert saved["architecture_seen"].startswith("React client")
    # Best-effort JSON backup is still written alongside the primary DB save.
    backup = json.loads((tmp_path / f"{report_id}.json").read_text(encoding="utf-8"))
    assert backup["title"] == "V1 Review"


def test_api_v1_controls_alias_returns_register(tmp_path, monkeypatch):
    _isolate_report_store(tmp_path, monkeypatch)
    report_id = "1779016409_deadbeef"
    report_db.upsert_report({
        "id": report_id,
        "title": "Controls V1",
        "methodology": "test",
        "categories": [
            {
                "id": "API-API1",
                "name": "Broken Object Level Authorization",
                "risk": "High",
                "affected_components": ["Orders API"],
                "threats": [{"attack_vector": "Attacker changes object IDs."}],
                "mitigations": [{"action": "Enforce object-level authorization checks", "priority": "Immediate"}],
            }
        ],
    })

    client = tm_app.app.test_client()
    response = client.get(f"/api/v1/reports/{report_id}/controls")

    assert response.status_code == 200
    body = response.get_json()
    assert body["success"] is True
    assert body["control_count"] == 1
    assert body["controls"][0]["source_finding"] == "API-API1 - Broken Object Level Authorization"


def test_api_v1_patterns_returns_full_offline_catalog():
    client = tm_app.app.test_client()

    response = client.get("/api/v1/patterns/api")

    assert response.status_code == 200
    body = response.get_json()
    assert body["success"] is True
    assert body["ruleset"] == "api"
    assert body["total"] >= 40
    first = body["patterns"][0]
    for key in ("description", "attack_vector", "impact", "control_objective", "validation_steps"):
        assert first[key], key


def test_api_v1_pattern_detail_by_rule_id():
    client = tm_app.app.test_client()

    response = client.get("/api/v1/patterns/ai/AI-LLM01-01")

    assert response.status_code == 200
    body = response.get_json()
    assert body["success"] is True
    assert body["pattern"]["pattern_name"] == "Prompt Injection"
    assert body["pattern"]["pattern_quality"]["level"] == "industrial_offline"


# ── Rate limiting on scan-triggering endpoints ─────────────────────────────────
# These endpoints are unauthenticated by default (only the optional TM_API_KEY
# gate protects them) and each triggers real work (a scan, a pipeline run, a
# git write) — without a rate limit, one caller can exhaust broker/DAST
# workers or hammer an external LLM/GitHub API through them.
_RATE_LIMITED_ENDPOINTS = [
    "sast_api.scan_repo",
    "sast_api.run_pipeline",
    "sast_api.propose_remediation",
    "sast_api.open_remediation_pr",
    # dast_api.scan_target omitted: DAST is soft-disabled, its blueprint isn't
    # registered (api/__init__.py), so the endpoint doesn't exist to check.
    "aibom_api.scan_repo",
    "codemodel_api.analyze",
    "codemodel_api.drift",
    "design_review_api.jira_webhook",
]


def test_scan_triggering_endpoints_carry_a_rate_limit():
    for endpoint in _RATE_LIMITED_ENDPOINTS:
        view_func = tm_app.app.view_functions[endpoint]
        marker = getattr(view_func, "__wrapper-limiter-instance", None)
        assert marker is not None, f"{endpoint} has no rate limit applied"


def test_open_pr_endpoint_returns_429_once_its_limit_is_exceeded():
    tm_app.limiter.storage.reset()
    client = tm_app.app.test_client()
    csrf = tm_app._CSRF_TOKEN
    body = {"patch": "x", "file": "a.py", "category_id": "C1", "report_id": "r1"}

    responses = [
        client.post("/api/v1/sast/repos/no-such-repo/remediation/open-pr",
                    json=body, headers={"X-CSRF-Token": csrf})
        for _ in range(6)   # the route is limited to 5/minute
    ]
    statuses = [r.status_code for r in responses]
    assert 404 in statuses            # repo lookup runs fine while under the limit
    assert 429 in statuses            # the 6th request is throttled
    assert statuses[-1] == 429        # and it's specifically the last one that trips it
