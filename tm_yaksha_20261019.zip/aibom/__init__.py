"""AI-BOM: AI bill of materials + LLM usage inventory scanner for Yaksha Guard."""
from __future__ import annotations

from .service import get_service  # noqa: F401
