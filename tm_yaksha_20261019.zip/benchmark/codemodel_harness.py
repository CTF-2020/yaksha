"""Measured-accuracy harness for the code-derived threat-model engine.

Scores :func:`codemodel.extractor.build_model` against the labelled
:mod:`benchmark.codemodel_corpus` on four axes an operator actually relies on:

  * **entry points** — did we recover the real attack surface? (precision/recall
    over (METHOD, path) pairs; a hallucinated route hurts precision, a missed
    route hurts recall);
  * **sink families** — of the entry points found, did the right dangerous
    weakness families come back as reachable? (precision/recall over
    (entry, family) pairs);
  * **auth classification** — is each entry point's ``authenticated`` flag right?
    (accuracy over found entry points — the axis that decides whether a finding
    is rated Critical/unauthenticated or not);
  * **secret management** — hardcoded vs env-sourced counts match the label.

Everything is built in a real temp directory through the public ``build_model``
path, so the harness exercises the walker, per-language extractors and the
cross-file join exactly as production does. Pure/offline/deterministic — safe to
gate on.
"""
from __future__ import annotations

import os
import shutil
import tempfile

from codemodel import extractor

from . import codemodel_corpus as corpus


def _build(case: dict):
    root = tempfile.mkdtemp(prefix="cm_bench_")
    try:
        for rel, src in case["files"].items():
            path = os.path.join(root, rel)
            os.makedirs(os.path.dirname(path) or root, exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(src)
        return extractor.build_model(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def _pr(tp: int, fp: int, fn: int) -> dict:
    precision = round(tp / (tp + fp), 4) if (tp + fp) else 1.0
    recall = round(tp / (tp + fn), 4) if (tp + fn) else 1.0
    f1 = round(2 * precision * recall / (precision + recall), 4) \
        if (precision + recall) else 0.0
    return {"tp": tp, "fp": fp, "fn": fn,
            "precision": precision, "recall": recall, "f1": f1}


def evaluate() -> dict:
    ep_tp = ep_fp = ep_fn = 0
    sink_tp = sink_fp = sink_fn = 0
    auth_correct = auth_total = 0
    secret_cases = secret_ok = 0
    untainted_ok = untainted_total = 0
    case_rows: list[dict] = []

    for case in corpus.CASES:
        model = _build(case)
        found = {(e.method, e.path): e for e in model.entry_points}
        found_keys = set(found)
        expect_keys = set(case["entry_points"])

        row = {"name": case["name"], "lang": case["lang"]}

        # entry points
        row["missing_eps"] = sorted(expect_keys - found_keys)
        row["extra_eps"] = sorted(found_keys - expect_keys)
        ep_tp += len(expect_keys & found_keys)
        ep_fp += len(found_keys - expect_keys)
        ep_fn += len(expect_keys - found_keys)

        # auth classification (only over entry points we actually found)
        expect_authed = set(case.get("authed", set()))
        for key in expect_keys & found_keys:
            auth_total += 1
            got = found[key].authenticated
            want = key in expect_authed
            if got == want:
                auth_correct += 1
            else:
                row.setdefault("auth_wrong", []).append(
                    {"ep": key, "got": got, "want": want})

        # sink families reachable per entry point
        want_sinks = case.get("sink_families", {})
        for key in expect_keys & found_keys:
            got_fams = {s.family for s in found[key].reachable_sinks}
            wanted = set(want_sinks.get(key, set()))
            sink_tp += len(wanted & got_fams)
            sink_fn += len(wanted - got_fams)
            # only families the case labelled anywhere are scored for precision,
            # so an unrelated low-severity family a case didn't enumerate on an
            # entry point it DID enumerate is not a phantom FP
            labelled = {f for fams in want_sinks.values() for f in fams}
            sink_fp += len((got_fams - wanted) & labelled)
            missing = wanted - got_fams
            if missing:
                row.setdefault("missing_sinks", []).append(
                    {"ep": key, "families": sorted(missing)})

        # clean-design: reachable sinks must be present but UNtainted
        if case.get("clean_untainted"):
            for key in expect_keys & found_keys:
                for s in found[key].reachable_sinks:
                    untainted_total += 1
                    if not s.tainted:
                        untainted_ok += 1
                    else:
                        row.setdefault("false_taint", []).append(
                            {"ep": key, "sink": s.name})

        # secrets
        if "hardcoded_secrets" in case or "managed_secrets" in case:
            secret_cases += 1
            hard = sum(1 for s in model.secrets if not s.managed)
            managed = sum(1 for s in model.secrets if s.managed)
            ok = True
            if "hardcoded_secrets" in case and hard != case["hardcoded_secrets"]:
                ok = False
                row["hardcoded_got"] = hard
            if "managed_secrets" in case and managed != case["managed_secrets"]:
                ok = False
                row["managed_got"] = managed
            secret_ok += 1 if ok else 0

        case_rows.append(row)

    return {
        "cases": len(corpus.CASES),
        "entry_points": _pr(ep_tp, ep_fp, ep_fn),
        "sink_families": _pr(sink_tp, sink_fp, sink_fn),
        "auth_accuracy": round(auth_correct / auth_total, 4) if auth_total else 1.0,
        "auth_n": auth_total,
        "secret_accuracy": round(secret_ok / secret_cases, 4) if secret_cases else 1.0,
        "secret_n": secret_cases,
        "clean_untainted_rate": round(untainted_ok / untainted_total, 4)
        if untainted_total else 1.0,
        "clean_untainted_n": untainted_total,
        "cases_detail": case_rows,
    }


def format_report(m: dict) -> str:
    ep, sk = m["entry_points"], m["sink_families"]
    lines = [
        "Code-derived threat-model engine — measured accuracy",
        "=" * 52,
        f"corpus cases : {m['cases']}  (Python + JS/TS + Go + Java)",
        "",
        f"entry points   P={ep['precision']:.0%} R={ep['recall']:.0%} "
        f"F1={ep['f1']:.0%}  (TP={ep['tp']} FP={ep['fp']} FN={ep['fn']})",
        f"sink families  P={sk['precision']:.0%} R={sk['recall']:.0%} "
        f"F1={sk['f1']:.0%}  (TP={sk['tp']} FP={sk['fp']} FN={sk['fn']})",
        f"auth flag acc  {m['auth_accuracy']:.0%}  (n={m['auth_n']})",
        f"secret mgmt    {m['secret_accuracy']:.0%}  (n={m['secret_n']} cases)",
        f"clean untaint  {m['clean_untainted_rate']:.0%}  "
        f"(n={m['clean_untainted_n']} sinks must read untainted)",
        "",
    ]
    for row in m["cases_detail"]:
        problems = []
        if row.get("missing_eps"):
            problems.append(f"missing routes {row['missing_eps']}")
        if row.get("extra_eps"):
            problems.append(f"phantom routes {row['extra_eps']}")
        if row.get("auth_wrong"):
            problems.append(f"auth {row['auth_wrong']}")
        if row.get("missing_sinks"):
            problems.append(f"missing sinks {row['missing_sinks']}")
        if row.get("false_taint"):
            problems.append(f"false taint {row['false_taint']}")
        if "hardcoded_got" in row:
            problems.append(f"hardcoded={row['hardcoded_got']}")
        if "managed_got" in row:
            problems.append(f"managed={row['managed_got']}")
        status = "ok" if not problems else "; ".join(problems)
        lines.append(f"  {row['lang']:<11} {row['name']:<12} {status}")
    return "\n".join(lines)


def main() -> None:
    print(format_report(evaluate()))


if __name__ == "__main__":
    main()
