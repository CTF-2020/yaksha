"""Executive correlation summary (exec_summary.py): a narrative rollup built
directly on dashboard.service.build(), so these tests seed the same stores
test_dashboard.py does and assert the prose states the right numbers -- not
exact strings, since the wording is deliberately verbose/human-readable.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import exec_summary
import ownership
import report_db
import verdict_tracking
from suppressions import db as supp_db
from suppressions import store as supp_store


def _cat(name, risk, cwe="", loci=None, verdict=None, family=None):
    cat = {"id": name, "name": name, "title": name, "risk": risk, "cwe": cwe,
           "_source": "TM", "threats": [{"name": l} for l in (loci or [])],
           "affected_components": loci or []}
    if verdict:
        cat["verdict"] = verdict
    if family:
        cat["family"] = family
    return cat


def _report(rid, methodology, cats, title="R"):
    return {"id": rid, "title": title, "methodology": methodology,
            "overall_risk": cats[0]["risk"] if cats else "Info",
            "analyzed_at": "2026-08-02T00:00:00Z", "categories": cats}


class ExecSummaryTests(unittest.TestCase):
    def setUp(self):
        self._op = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self._ovp = verdict_tracking.DB_PATH
        self._oop = ownership.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        supp_db.init()
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdict_history.db"
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"

    def _restore(self):
        report_db.DB_PATH = self._op
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp
        verdict_tracking.DB_PATH = self._ovp
        ownership.DB_PATH = self._oop

    # ---- empty state ---------------------------------------------------

    def test_no_reports_yet(self):
        result = exec_summary.build()
        self.assertIn("No security data yet", result["headline"])
        posture = next(s for s in result["sections"] if s["key"] == "posture")
        self.assertIn("No reports have been analyzed", posture["text"])

    # ---- posture ---------------------------------------------------------

    def test_posture_states_severity_breakdown(self):
        report_db.upsert_report(_report("1_1_a", "codemodel",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"]),
             _cat("XSS", "High", "CWE-79", ["v.py:2"])]))
        result = exec_summary.build()
        posture = next(s for s in result["sections"] if s["key"] == "posture")
        self.assertIn("2 findings", posture["text"])
        self.assertIn("2 are Critical or High", posture["text"])
        self.assertIn("1 Critical", posture["text"])
        self.assertIn("1 High", posture["text"])

    def test_headline_reflects_critical_high_when_nothing_correlated(self):
        report_db.upsert_report(_report("1_1_a", "codemodel",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"])]))
        result = exec_summary.build()
        self.assertIn("1 Critical/High finding open", result["headline"])
        self.assertIn("none yet confirmed exploitable", result["headline"])

    def test_clean_posture_headline(self):
        report_db.upsert_report(_report("1_1_a", "codemodel",
            [_cat("Info finding", "Low", "CWE-1", ["a.py:1"])]))
        result = exec_summary.build()
        self.assertIn("No Critical or High severity findings open", result["headline"])

    # ---- validation / correlation ------------------------------------------

    def test_actively_exploited_dominates_headline(self):
        report_db.upsert_report(_report("1_1_a", "correlation",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"], verdict="actively_exploited"),
             _cat("XSS", "High", "CWE-79", ["v.py:2"], verdict="confirmed_exploitable")]))
        result = exec_summary.build()
        self.assertIn("1 actively-exploited weakness", result["headline"])
        validation = next(s for s in result["sections"] if s["key"] == "validation")
        self.assertIn("actively exploited", validation["text"])
        self.assertIn("confirmed exploitable", validation["text"])

    def test_blind_spot_calls_out_model_gap(self):
        report_db.upsert_report(_report("1_1_a", "correlation",
            [_cat("SSRF", "Medium", "CWE-918", ["net.py:1"], verdict="blind_spot")]))
        result = exec_summary.build()
        validation = next(s for s in result["sections"] if s["key"] == "validation")
        self.assertIn("1 is blind spot", validation["text"])
        self.assertIn("the model itself needs updating", validation["text"])

    def test_uncorrelated_findings_counted_separately(self):
        report_db.upsert_report(_report("1_1_a", "codemodel",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"])]))   # no verdict
        result = exec_summary.build()
        validation = next(s for s in result["sections"] if s["key"] == "validation")
        self.assertIn("0 findings have been cross-tool correlated", validation["text"])
        self.assertIn("1 more has not yet been correlated", validation["text"])

    def test_no_categories_at_all_shows_empty_correlation_state(self):
        # Distinct from the above: zero categories in every viewer-visible
        # report (as opposed to one category that just lacks a verdict).
        report_db.upsert_report(_report("1_1_a", "codemodel", []))
        result = exec_summary.build()
        validation = next(s for s in result["sections"] if s["key"] == "validation")
        self.assertIn("No findings have gone through cross-tool correlation yet", validation["text"])

    # ---- remediation / SLA --------------------------------------------------

    def test_sla_breach_surfaces_in_headline_and_remediation_section(self):
        report_db.upsert_report(_report("1_1_a", "correlation",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"], verdict="corroborated")]))
        # Force the SLA clock far into the past so it reads as breached.
        import time
        long_ago = time.time() - 30 * 86400.0
        report = report_db.get_report("1_1_a")
        verdict_tracking.record_transitions(report, now=long_ago)
        result = exec_summary.build()
        remediation = next(s for s in result["sections"] if s["key"] == "remediation")
        self.assertIn("past its verdict's remediation SLA window", remediation["text"])

    def test_all_within_sla_window(self):
        report_db.upsert_report(_report("1_1_a", "correlation",
            [_cat("SSRF", "Medium", "CWE-918", ["net.py:1"], verdict="blind_spot")]))
        verdict_tracking.record_transitions(report_db.get_report("1_1_a"))
        result = exec_summary.build()
        remediation = next(s for s in result["sections"] if s["key"] == "remediation")
        self.assertIn("within their remediation window", remediation["text"])

    # ---- coverage --------------------------------------------------------

    def test_coverage_states_methodology_mix(self):
        report_db.upsert_report(_report("1_1_a", "codemodel", [_cat("SQLi", "Critical", loci=["a.py:1"])]))
        report_db.upsert_report(_report("1_2_b", "correlation", [_cat("XSS", "High", loci=["b.py:1"])]))
        result = exec_summary.build()
        coverage = next(s for s in result["sections"] if s["key"] == "coverage")
        self.assertIn("codemodel", coverage["text"])
        self.assertIn("correlation", coverage["text"])

    # ---- accountability ----------------------------------------------------

    def test_accountability_no_correlated_findings_yet(self):
        report_db.upsert_report(_report("1_1_a", "codemodel",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"])]))   # no verdict
        result = exec_summary.build()
        acct = next(s for s in result["sections"] if s["key"] == "accountability")
        self.assertIn("No correlated findings yet to assign", acct["text"])

    def test_accountability_states_owner_coverage(self):
        from suppressions.engine import finding_fingerprint
        cat = _cat("SQLi", "Critical", "CWE-89", ["db.py:10"], verdict="confirmed_exploitable")
        report_db.upsert_report(_report("1_1_a", "correlation", [cat]))
        ownership.assign(finding_fingerprint(cat), "alice")
        result = exec_summary.build()
        acct = next(s for s in result["sections"] if s["key"] == "accountability")
        self.assertIn("1 of 1 correlated finding", acct["text"])
        self.assertIn("100", acct["text"])

    def test_accountability_calls_out_unowned_urgent_findings(self):
        report_db.upsert_report(_report("1_1_a", "correlation",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"], verdict="actively_exploited")]))
        result = exec_summary.build()
        acct = next(s for s in result["sections"] if s["key"] == "accountability")
        self.assertIn("no owner yet", acct["text"])

    def test_accountability_states_risk_acceptance_count(self):
        from suppressions import store as supp_store2
        report_db.upsert_report(_report("1_1_a", "correlation",
            [_cat("XSS", "High", "CWE-79", ["v.py:1"], verdict="design_gap")]))
        supp_store2.add_suppression({
            "scope": "rule", "match": "XSS", "reason": "accepted", "author": "carol",
            "state": "false_positive"})
        result = exec_summary.build()
        acct = next(s for s in result["sections"] if s["key"] == "accountability")
        self.assertIn("1 finding is under an active risk-acceptance decision", acct["text"])
        self.assertIn("false positive", acct["text"])

    # ---- consistency with the dashboard itself ------------------------------

    def test_as_of_matches_dashboard_totals(self):
        report_db.upsert_report(_report("1_1_a", "codemodel",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10", "db.py:20"])]))
        from dashboard import service as dashboard_service
        dash = dashboard_service.build()
        result = exec_summary.build()
        self.assertEqual(result["as_of"]["reports"], dash["threat_model"]["reports"])
        self.assertEqual(result["as_of"]["findings"], dash["threat_model"]["findings"])


class ExecSummaryApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._op = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self._ovp = verdict_tracking.DB_PATH
        self._oop = ownership.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        supp_db.init()
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdict_history.db"
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"
        report_db.upsert_report(_report("1_1_a", "codemodel",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"])]))

    def _restore(self):
        report_db.DB_PATH = self._op
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp
        verdict_tracking.DB_PATH = self._ovp
        ownership.DB_PATH = self._oop

    def test_endpoint_returns_headline_and_sections(self):
        d = self.client.get("/api/v1/exec-summary").get_json()
        self.assertTrue(d["success"])
        self.assertTrue(d["headline"])
        keys = {s["key"] for s in d["sections"]}
        self.assertEqual(keys, {"posture", "validation", "remediation", "coverage", "accountability"})

    def test_dashboard_page_renders_exec_summary_card(self):
        html = self.client.get("/").get_data(as_text=True)
        self.assertIn("Executive Correlation Summary", html)
        self.assertIn("loadExecSummary", html)

    def test_old_nested_route_no_longer_exists(self):
        # Moved to the top-level /api/v1/exec-summary -- the old nested path
        # under /dashboard must not silently keep working as a stale alias.
        resp = self.client.get("/api/v1/dashboard/exec-summary")
        self.assertEqual(resp.status_code, 404)


if __name__ == "__main__":
    unittest.main()
