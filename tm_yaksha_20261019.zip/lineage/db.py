"""SQLite store for threat lineage — persists ThreatLineage identity + its
event timeline across every sync, independent of any single report's lifetime.

Stdlib ``sqlite3`` only, mirroring :mod:`suppressions.db` / :mod:`report_db`'s
pattern: connection-per-call with WAL + a busy timeout, and an idempotent
:func:`init` so ``DB_PATH`` can be repointed by tests without any
"already initialized" staleness.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import closing
from pathlib import Path

from .model import LineageEvent, ThreatLineage

DB_PATH = Path.home() / ".tm_lineage.db"

_init_lock = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS lineage_threats (
    id                      TEXT PRIMARY KEY,
    family                  TEXT NOT NULL,
    family_title            TEXT NOT NULL DEFAULT '',
    status                  TEXT NOT NULL,
    founding_locus          TEXT NOT NULL DEFAULT '[]',
    kinds_seen              TEXT NOT NULL DEFAULT '[]',
    first_seen_at           TEXT NOT NULL DEFAULT '',
    first_seen_report_id    TEXT NOT NULL DEFAULT '',
    first_seen_report_title TEXT NOT NULL DEFAULT '',
    first_seen_kind         TEXT NOT NULL DEFAULT '',
    updated_at              TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_lineage_family ON lineage_threats(family);
CREATE INDEX IF NOT EXISTS ix_lineage_status ON lineage_threats(status);

CREATE TABLE IF NOT EXISTS lineage_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    threat_id     TEXT NOT NULL REFERENCES lineage_threats(id),
    at            TEXT NOT NULL,
    report_id     TEXT NOT NULL DEFAULT '',
    report_title  TEXT NOT NULL DEFAULT '',
    kind          TEXT NOT NULL DEFAULT '',
    methodology   TEXT NOT NULL DEFAULT '',
    severity      TEXT NOT NULL DEFAULT '',
    title         TEXT NOT NULL DEFAULT '',
    locus_label   TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_lineage_events_threat ON lineage_events(threat_id);
CREATE INDEX IF NOT EXISTS ix_lineage_events_report ON lineage_events(report_id);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    """Ensure the schema exists for the CURRENT DB_PATH. Cheap and idempotent."""
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)


def _row_to_threat(row: sqlite3.Row) -> ThreatLineage:
    return ThreatLineage(
        id=row["id"], family=row["family"], family_title=row["family_title"],
        status=row["status"], founding_locus=json.loads(row["founding_locus"]),
        kinds_seen=json.loads(row["kinds_seen"]),
        first_seen_at=row["first_seen_at"],
        first_seen_report_id=row["first_seen_report_id"],
        first_seen_report_title=row["first_seen_report_title"],
        first_seen_kind=row["first_seen_kind"],
        updated_at=row["updated_at"],
    )


def get(threat_id: str) -> ThreatLineage | None:
    init()
    with closing(_connect()) as conn:
        row = conn.execute("SELECT * FROM lineage_threats WHERE id = ?",
                           (threat_id,)).fetchone()
    return _row_to_threat(row) if row else None


def all_threats(status: str | None = None, family: str | None = None) -> list[ThreatLineage]:
    init()
    q = "SELECT * FROM lineage_threats"
    clauses, params = [], []
    if status:
        clauses.append("status = ?")
        params.append(status)
    if family:
        clauses.append("family = ?")
        params.append(family)
    if clauses:
        q += " WHERE " + " AND ".join(clauses)
    q += " ORDER BY updated_at DESC"
    with closing(_connect()) as conn:
        rows = conn.execute(q, params).fetchall()
    return [_row_to_threat(r) for r in rows]


def upsert_threat(t: ThreatLineage) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT INTO lineage_threats"
            "(id,family,family_title,status,founding_locus,kinds_seen,first_seen_at,"
            " first_seen_report_id,first_seen_report_title,first_seen_kind,updated_at)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?)"
            " ON CONFLICT(id) DO UPDATE SET"
            "   status=excluded.status, kinds_seen=excluded.kinds_seen,"
            "   updated_at=excluded.updated_at",
            (t.id, t.family, t.family_title, t.status, json.dumps(t.founding_locus),
             json.dumps(t.kinds_seen), t.first_seen_at, t.first_seen_report_id,
             t.first_seen_report_title, t.first_seen_kind, t.updated_at))


def add_event(threat_id: str, ev: LineageEvent) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT INTO lineage_events"
            "(threat_id,at,report_id,report_title,kind,methodology,severity,title,locus_label)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (threat_id, ev.at, ev.report_id, ev.report_title, ev.kind, ev.methodology,
             ev.severity, ev.title, ev.locus_label))


def events_for(threat_id: str) -> list[LineageEvent]:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT * FROM lineage_events WHERE threat_id = ? ORDER BY at, id",
            (threat_id,)).fetchall()
    return [LineageEvent(at=r["at"], report_id=r["report_id"], report_title=r["report_title"],
                         kind=r["kind"], methodology=r["methodology"], severity=r["severity"],
                         title=r["title"], locus_label=r["locus_label"]) for r in rows]


def event_count(threat_id: str) -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute("SELECT COUNT(*) FROM lineage_events WHERE threat_id = ?",
                            (threat_id,)).fetchone()[0]


def count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute("SELECT COUNT(*) FROM lineage_threats").fetchone()[0]
