"""Tests for DastService._validate_attack_paths — the automatic post-scan
wiring that makes attack-path validation "continuous" rather than something
someone has to remember to trigger.

validate.validate itself is mocked here so these tests isolate the plumbing
(does a scan job record a validation_report_id, does a validation failure
stay non-fatal to the job) from the matching logic, which
test_dast_validate.py already covers against real attack_paths behavior.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from dast import config, service


class TestValidateAttackPathsWiring(unittest.TestCase):
    def setUp(self):
        self._orig_state = config.STATE_DIR
        self._orig_targets = config.TARGETS_PATH
        self._orig_jobs = config.JOBS_PATH
        self._td = tempfile.TemporaryDirectory()
        config.STATE_DIR = Path(self._td.name)
        config.TARGETS_PATH = config.STATE_DIR / "targets.json"
        config.JOBS_PATH = config.STATE_DIR / "jobs.json"

        self.svc = service.DastService()
        self.job_id = "dast_test_job"
        self.svc._jobs[self.job_id] = {
            "id": self.job_id, "status": "running", "log": [],
            "validation_report_id": None,
        }

    def tearDown(self):
        config.STATE_DIR = self._orig_state
        config.TARGETS_PATH = self._orig_targets
        config.JOBS_PATH = self._orig_jobs
        self._td.cleanup()

    def test_validated_report_is_saved_and_recorded_on_the_job(self):
        fake_report = {"title": "Attack Paths (validated) · x", "methodology": "attackpath",
                       "scan_metadata": {"confirmed": 2, "paths_total": 3}}
        with patch("dast.service.validate.validate", return_value=fake_report), \
             patch.object(service.DastService, "_save_report", return_value="ap_report_1"):
            self.svc._validate_attack_paths(self.job_id, {"name": "t"}, {"id": "dast_r1"})

        self.assertEqual(self.svc._jobs[self.job_id]["validation_report_id"], "ap_report_1")

    def test_no_matching_repo_is_a_silent_no_op(self):
        with patch("dast.service.validate.validate", return_value=None), \
             patch.object(service.DastService, "_save_report") as mock_save:
            self.svc._validate_attack_paths(self.job_id, {"name": "t"}, {"id": "dast_r1"})

        mock_save.assert_not_called()
        self.assertIsNone(self.svc._jobs[self.job_id]["validation_report_id"])

    def test_validation_error_does_not_raise_or_fail_the_job(self):
        with patch("dast.service.validate.validate", side_effect=RuntimeError("boom")):
            # Must not raise — a validation bug must never take down the scan job.
            self.svc._validate_attack_paths(self.job_id, {"name": "t"}, {"id": "dast_r1"})

        self.assertIsNone(self.svc._jobs[self.job_id]["validation_report_id"])
        self.assertEqual(self.svc._jobs[self.job_id]["status"], "running")
        self.assertTrue(any("raised" in line for line in self.svc._jobs[self.job_id]["log"]))


if __name__ == "__main__":
    unittest.main()
