"""Post-quantum cryptography API routes."""
from __future__ import annotations

from flask import Blueprint

import app as tm_app


bp = Blueprint("pqc_api", __name__, url_prefix="/api/v1")


@bp.post("/pqc/assess")
@tm_app.limiter.limit("30 per minute")
def assess_pqc():
    """Assess architecture text or uploaded files for PQC migration risk."""
    return tm_app._assess_pqc_impl()


@bp.get("/reports/<report_id>/pqc")
def report_pqc(report_id: str):
    """Assess and persist PQC findings for an existing report."""
    return tm_app._report_pqc_impl(report_id)
