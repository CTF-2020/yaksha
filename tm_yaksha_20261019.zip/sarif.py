"""Convert a Yaksha Guard report into SARIF 2.1.0.

SARIF (Static Analysis Results Interchange Format) is the OASIS standard that
GitHub and GitLab code-scanning, Azure DevOps and most IDEs consume natively, so
emitting it turns every report — SAST, DAST, code-model, correlation or a
threat model — into findings that appear inline on a pull request without any
bespoke integration.

The converter is schema-faithful for the fields those consumers require:
``tool.driver.rules`` with ``defaultConfiguration.level`` and a numeric
``security-severity`` (GitHub sorts/filters on it), ``results`` with a
``level``, a ``message``, at least one ``location`` (physical when we can parse a
``file:line``, logical otherwise) and stable ``partialFingerprints`` so a finding
is not re-alerted on every scan.

When a finding carries a correlator verdict (actively_exploited /
confirmed_exploitable / corroborated / design_gap / blind_spot), it rides
along in the SARIF property bag two ways: as ``result.properties.verdict``
(the raw value, for a consumer that wants to key off it programmatically)
and as a ``verdict/<value>`` entry in the rule's ``properties.tags`` (so it
is also filterable/facetable in GitHub/GitLab's own tag-based code-scanning
UI, the same way ``security``/CWE/OWASP tags already are) — a plain
uncorrelated finding has no verdict, so neither is emitted for it.
"""
from __future__ import annotations

import hashlib
import re

_SCHEMA = "https://json.schemastore.org/sarif-2.1.0.json"
_TOOL_URI = "https://owasp.org/www-project-threat-modeling/"

# SARIF level per severity, and GitHub's 0-10 security-severity band.
_LEVEL = {"Critical": "error", "High": "error", "Medium": "warning",
          "Low": "note", "Info": "note"}
_SECURITY_SEVERITY = {"Critical": "9.5", "High": "8.0", "Medium": "5.5",
                      "Low": "3.0", "Info": "1.0"}

# "path/to/file.py:42" or "path:42" — capture (uri, line). Excludes URLs (http:).
_FILE_LINE_RE = re.compile(r"^(?!\w+://)(.+?):(\d+)\b")
_CWE_RE = re.compile(r"CWE[-_ ]?(\d+)", re.I)


def _norm_severity(value: str) -> str:
    v = (value or "Info").strip().capitalize()
    return v if v in _LEVEL else "Info"


def _rule_id(category: dict) -> str:
    rid = str(category.get("id") or category.get("category") or category.get("name") or "finding")
    return re.sub(r"\s+", "-", rid.strip()) or "finding"


def _cwes(category: dict) -> list[str]:
    blob = " ".join(str(category.get(k, "")) for k in ("cwe", "notes", "description"))
    return sorted({f"CWE-{int(m.group(1))}" for m in _CWE_RE.finditer(blob)})


def _tags(category: dict) -> list[str]:
    tags = ["security"]
    if category.get("owasp"):
        tags.append(str(category["owasp"]))
    tags.extend(_cwes(category))
    stride = category.get("stride")
    if isinstance(stride, (list, tuple)):
        tags.extend(f"STRIDE/{s}" for s in stride)
    if category.get("verdict"):
        tags.append(f"verdict/{category['verdict']}")
    src = category.get("_source")
    if src:
        tags.append(f"source/{src}")
    return list(dict.fromkeys(tags))


def _location(locus: str) -> dict:
    """A SARIF location: physical when we can parse file:line, else logical."""
    locus = (locus or "").strip()
    m = _FILE_LINE_RE.match(locus)
    if m:
        uri = m.group(1).strip().replace("\\", "/")
        return {"physicalLocation": {
            "artifactLocation": {"uri": uri},
            "region": {"startLine": max(1, int(m.group(2)))}}}
    # No file:line (a URL, a component name, an endpoint) -> logical location so
    # the finding still carries a target without a fabricated file/line.
    return {"logicalLocations": [{"fullyQualifiedName": locus or "(unspecified)",
                                  "kind": "resource"}]}


def _fingerprint(rule_id: str, locus: str) -> str:
    return hashlib.sha256(f"{rule_id}::{locus}".encode("utf-8")).hexdigest()[:16]


def _threat_loci(category: dict) -> list[str]:
    """Ordered, de-duplicated location strings for a category's results."""
    loci = []
    for t in category.get("threats", []) or []:
        if isinstance(t, dict) and t.get("name"):
            loci.append(str(t["name"]))
    if not loci:
        loci = [str(c) for c in (category.get("affected_components") or []) if c]
    return list(dict.fromkeys(loci)) or ["(no specific location)"]


def _clean_locus(locus: str) -> str:
    # Threat names may be prefixed like "[Static (code)] path:line" — keep the tail.
    m = re.match(r"^\[[^\]]+\]\s*(.+)$", locus)
    return (m.group(1) if m else locus).strip()


def _row_rule_id(row: dict) -> str:
    rid = str(row.get("rule") or row.get("title") or "finding")
    return re.sub(r"\s+", "-", rid.strip()) or "finding"


def _row_cwes(row: dict) -> list[str]:
    return sorted({f"CWE-{int(m.group(1))}" for m in _CWE_RE.finditer(str(row.get("cwe") or ""))})


def _row_tags(row: dict) -> list[str]:
    tags = ["security"]
    if row.get("owasp"):
        tags.append(str(row["owasp"]))
    tags.extend(_row_cwes(row))
    if row.get("verdict"):
        tags.append(f"verdict/{row['verdict']}")
    if row.get("source"):
        tags.append(f"source/{row['source']}")
    return list(dict.fromkeys(tags))


def to_sarif_rows(rows: list[dict], *, run_id: str = "triage-export") -> dict:
    """Build one SARIF 2.1.0 document from flat finding rows (the
    triage.py / report_db.search_findings row shape) instead of one report's
    categories -- so a filtered (e.g. verdict-scoped), cross-report slice of
    the triage queue exports as a single SARIF run for code-scanning upload,
    rather than only a whole single report at a time (see to_sarif above).
    """
    rules, results = [], []
    seen_rules: dict[str, int] = {}

    for row in rows:
        rid = _row_rule_id(row)
        severity = _norm_severity(row.get("severity"))
        if rid not in seen_rules:
            seen_rules[rid] = len(rules)
            rules.append({
                "id": rid,
                "name": re.sub(r"\W+", "", str(row.get("title") or rid).title())[:120] or rid,
                "shortDescription": {"text": str(row.get("title") or rid)[:200]},
                "fullDescription": {"text": str(row.get("title") or rid)[:1000]},
                "defaultConfiguration": {"level": _LEVEL[severity]},
                "help": {"text": "See remediation guidance."},
                "properties": {
                    "tags": _row_tags(row),
                    "security-severity": _SECURITY_SEVERITY[severity],
                    "problem.severity": _LEVEL[severity],
                },
            })

        clean = _clean_locus(str(row.get("locus") or row.get("path") or ""))
        results.append({
            "ruleId": rid,
            "ruleIndex": seen_rules[rid],
            "level": _LEVEL[severity],
            "message": {"text": f"{row.get('title') or rid}: {clean}"},
            "locations": [_location(clean)],
            "partialFingerprints": {"yakshaGuard/v1": _fingerprint(rid, clean)},
            "properties": {
                "severity": severity,
                "owasp": row.get("owasp", ""),
                "cwe": ", ".join(_row_cwes(row)),
                "verdict": row.get("verdict", ""),
                "source": row.get("source", ""),
                "owner": row.get("owner", ""),
                "reportId": row.get("report_id", ""),
                "reportTitle": row.get("report_title", ""),
            },
        })

    return {
        "$schema": _SCHEMA,
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {
                "name": "Yaksha Guard",
                "informationUri": _TOOL_URI,
                "version": "1.0",
                "rules": rules,
            }},
            "automationDetails": {"id": f"yaksha-guard/{run_id}"},
            "columnKind": "utf16CodeUnits",
            "results": results,
        }],
    }


def to_sarif(report: dict) -> dict:
    categories = [c for c in report.get("categories", []) if isinstance(c, dict)]
    rules, results = [], []
    seen_rules = {}

    for cat in categories:
        rid = _rule_id(cat)
        severity = _norm_severity(cat.get("risk") or cat.get("severity"))
        if rid not in seen_rules:
            seen_rules[rid] = len(rules)
            help_text = str(cat.get("remediation") or cat.get("mitigation") or "")
            rules.append({
                "id": rid,
                "name": re.sub(r"\W+", "", str(cat.get("name") or rid).title())[:120] or rid,
                "shortDescription": {"text": str(cat.get("name") or rid)[:200]},
                "fullDescription": {"text": str(cat.get("description") or cat.get("name") or rid)[:1000]},
                "defaultConfiguration": {"level": _LEVEL[severity]},
                "help": {"text": help_text or "See remediation guidance."},
                "properties": {
                    "tags": _tags(cat),
                    "security-severity": _SECURITY_SEVERITY[severity],
                    "problem.severity": _LEVEL[severity],
                },
            })

        for locus in _threat_loci(cat):
            clean = _clean_locus(locus)
            results.append({
                "ruleId": rid,
                "ruleIndex": seen_rules[rid],
                "level": _LEVEL[severity],
                "message": {"text": f"{cat.get('name') or rid}: {clean}"},
                "locations": [_location(clean)],
                "partialFingerprints": {"yakshaGuard/v1": _fingerprint(rid, clean)},
                "properties": {
                    "severity": severity,
                    "owasp": cat.get("owasp", ""),
                    "cwe": ", ".join(_cwes(cat)),
                    "verdict": cat.get("verdict", ""),
                    "source": cat.get("_source", ""),
                },
            })

    return {
        "$schema": _SCHEMA,
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {
                "name": "Yaksha Guard",
                "informationUri": _TOOL_URI,
                "version": str(report.get("methodology_label") or report.get("methodology") or "1.0"),
                "rules": rules,
            }},
            "automationDetails": {"id": f"yaksha-guard/{report.get('methodology', 'report')}/"
                                        f"{report.get('id', '')}"},
            "columnKind": "utf16CodeUnits",
            "results": results,
        }],
    }
