"""tests/test_offline_rules.py — pytest suite for offline_rules.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from offline_rules import ALL_RULES, _check_rule, detect_applicable_rulesets, run_offline_review
from _rules_api import API_RULES
from _rules_ai import AI_RULES
from _rules_web import WEB_RULES


def _rule(rule_id: str) -> dict:
    for rule in WEB_RULES + API_RULES + AI_RULES:
        if rule["id"] == rule_id:
            return rule
    raise AssertionError(f"Unknown rule id: {rule_id}")


# ── _check_rule ───────────────────────────────────────────────────────────────

SAMPLE_RULE = {
    "id": "TEST-01",
    "category": "API1",
    "question": "Does every endpoint verify object-level authorization?",
    "rationale": "BOLA is the most common API vuln.",
    "severity": "Critical",
    "patterns_to_check": ["api", "endpoint", "user_id"],
    "mitigations": ["Verify ownership on every request"],
    "references": [],
}


def test_check_rule_pass_when_no_patterns_match():
    result = _check_rule("We use a monolithic desktop application with no network.", SAMPLE_RULE)
    assert result["status"] == "PASS"
    assert result["triggered_patterns"] == []


def test_check_rule_warn_when_patterns_match():
    result = _check_rule("REST api with endpoint that accepts user_id parameter.", SAMPLE_RULE)
    assert result["status"] in ("WARN", "FAIL")
    assert "api" in result["triggered_patterns"]


def test_check_rule_uses_token_boundaries():
    rule = dict(
        SAMPLE_RULE,
        id="TEST-ORM",
        patterns_to_check=["orm"],
        severity="High",
    )
    result = _check_rule("Static marketing website with a contact form.", rule)
    assert result["status"] == "PASS"
    assert result["triggered_patterns"] == []


def test_check_rule_ignores_single_broad_signal():
    result = _check_rule("A product API is exposed behind the gateway.", SAMPLE_RULE)
    assert result["status"] == "PASS"
    assert result["triggered_patterns"] == ["api"]


def test_check_rule_fails_on_explicit_insecure_evidence():
    result = _check_rule("REST API endpoint accepts user_id and has no authorization.", SAMPLE_RULE)
    assert result["status"] == "FAIL"
    assert result["effective_risk"] == "Critical"


def test_warn_only_review_does_not_become_critical_overall():
    result = run_offline_review(
        "React frontend calls a REST API with PostgreSQL and JWT auth.",
        rulesets=["web", "api"],
    )
    assert result["overall_risk"] != "Critical"


def test_positive_api_controls_suppress_corresponding_review_findings():
    arch = (
        "React SPA frontend behind API Gateway uses OAuth2/OIDC login. "
        "JWT access tokens are short-lived with refresh token rotation and immediate revocation. "
        "JWT validation checks issuer, audience, algorithm, expiry, iss, aud, exp and nbf. "
        "API credentials are never stored in frontend code; secret scanning runs in CI."
    )

    for rule_id in ("API-API2-01", "API-API2-02", "API-API2-04"):
        result = _check_rule(arch, _rule(rule_id))
        assert result["status"] == "PASS", result
        assert result["control_evidence"], result


def test_positive_web_controls_suppress_corresponding_review_findings():
    arch = (
        "React SPA frontend uses a strict CORS allowlist for trusted origins. "
        "All PostgreSQL access uses parameterized SQL through SQLAlchemy ORM with no string concatenation. "
        "Centralized audit logging records authentication success, failure, logout, IP address, and timestamp."
    )

    for rule_id in ("WEB-A01-04", "WEB-A03-01", "WEB-A09-01"):
        result = _check_rule(arch, _rule(rule_id))
        assert result["status"] == "PASS", result
        assert result["control_evidence"], result


def test_positive_llm_controls_suppress_corresponding_review_findings():
    arch = (
        "RAG uses Pinecone vector database. Retrieved documents are prompt-injection scanned "
        "and sanitized before entering LLM context. LLM output is HTML escaped with DOMPurify "
        "and CSP. Tool calls are allowlisted, least privilege scoped, and require human approval "
        "for write actions."
    )

    for rule_id in ("AI-LLM01-02", "AI-LLM02-01", "AI-LLM07-01", "AI-LLM08-01"):
        result = _check_rule(arch, _rule(rule_id))
        assert result["status"] == "PASS", result
        assert result["control_evidence"], result


def test_secure_api_stack_does_not_flag_generic_component_words_as_risks():
    arch = (
        "React frontend calls FastAPI REST API endpoints through API Gateway. "
        "OAuth2/OIDC login uses short-lived JWT access tokens, refresh token rotation, "
        "JWT validation for issuer audience algorithm and expiry. RBAC authorization checks "
        "are enforced on tenant resources. Strict CORS allowlist, HSTS/TLS 1.3, Pydantic "
        "server-side input validation, parameterized SQL through SQLAlchemy ORM, PostgreSQL "
        "encrypted at rest, private S3 bucket with block public access and signed URLs, "
        "WAF rate limiting, centralized audit logging and SIEM alerts."
    )

    noisy_rule_ids = (
        "WEB-A01-03",
        "WEB-A04-02",
        "WEB-A05-04",
        "WEB-A07-03",
        "API-API2-04",
        "API-API5-02",
    )
    for rule_id in noisy_rule_ids:
        result = _check_rule(arch, _rule(rule_id))
        assert result["status"] == "PASS", result


def test_secure_llm_controls_suppress_direct_prompt_and_data_leak_findings():
    arch = (
        "RAG assistant uses OpenAI LLM API with Pinecone vector database. User prompts "
        "are schema validated, content filtered, and kept separate from system instructions. "
        "Retrieved documents are prompt-injection scanned, provenance tracked, tenant scoped, "
        "sanitized before entering LLM context, and ingested only from approved origins through "
        "an authenticated ingestion service. LLM output is HTML escaped with DOMPurify and CSP "
        "before rendering. Tool calls are allowlisted, least privilege scoped, read-only by "
        "default, and write actions require human approval. PII is redacted before model calls "
        "and logs are centralized with anomaly detection. Token rate limits and quotas protect "
        "inference endpoints."
    )

    for rule_id in ("AI-LLM01-01", "AI-LLM03-04", "AI-LLM06-04", "AI-LLM10-01", "AI-LLM10-02"):
        result = _check_rule(arch, _rule(rule_id))
        assert result["status"] == "PASS", result


def test_generic_llm_terms_do_not_trigger_unrelated_ai_review_controls():
    arch = "Backend service calls the OpenAI LLM API and renders sanitized LLM output in React."

    for rule_id in ("AI-LLM06-03", "AI-LLM09-03", "AI-LLM10-03"):
        result = _check_rule(arch, _rule(rule_id))
        assert result["status"] == "PASS", result


def test_secure_llm_rag_review_stays_below_high():
    result = run_offline_review(
        (
            "RAG assistant uses OpenAI LLM API with Pinecone vector database. User prompts "
            "are schema validated, content filtered, and kept separate from system instructions. "
            "Retrieved documents are prompt-injection scanned, provenance tracked, tenant scoped, "
            "sanitized before entering LLM context, and ingested only from approved origins through "
            "an authenticated ingestion service. LLM output is HTML escaped with DOMPurify and CSP "
            "before rendering. Tool calls are allowlisted, least privilege scoped, read-only by "
            "default, and write actions require human approval. PII is redacted before model calls "
            "and logs are centralized with anomaly detection. Token rate limits and quotas protect "
            "inference endpoints."
        ),
        rulesets=["ai"],
    )

    assert result["overall_risk"] in ("Medium", "Low")


def test_llm_rules_do_not_trigger_without_ai_context():
    arch = "React SPA frontend calls a REST API with PostgreSQL, JWT auth, and strict CORS allowlist."
    result = _check_rule(arch, _rule("AI-LLM02-01"))
    assert result["status"] == "PASS"
    assert result["match_confidence"] == "not_applicable"


def test_llm_attack_vector_atlas_loaded_from_offline_checklist():
    atlas_rules = [rule for rule in AI_RULES if rule["id"].startswith("AI-LLM-ATLAS-")]
    checklist = Path(__file__).parent.parent / "data" / "llm-attack-vector-checklist.md"

    assert checklist.exists()
    assert len(atlas_rules) >= 428
    assert _rule("AI-LLM-ATLAS-001")["attack_vector"] == "Direct prompt injection"
    dns_rule = _rule("AI-LLM-ATLAS-135")
    assert dns_rule["source_attack_vector_id"] == "LLM-135"
    assert "DNS rebinding" in dns_rule["attack_vector"]
    assert "browser tool" in dns_rule["patterns_to_check"]
    assert _rule("AI-LLM-ATLAS-428")["attack_vector"] == "MCP request forgery"


def test_llm_attack_vector_atlas_is_ai_gated():
    arch = "React SPA frontend calls a REST API with PostgreSQL, JWT auth, and strict CORS allowlist."

    result = _check_rule(arch, _rule("AI-LLM-ATLAS-001"), "ai")

    assert result["status"] == "PASS"
    assert result["match_confidence"] == "not_applicable"


def test_llm_browser_tool_dns_rebinding_vector_triggers_specific_review():
    arch = (
        "LLM agent has a browser tool and URL fetch capability. DNS rebinding can steer "
        "browsing fetches from a public host to internal services."
    )

    result = _check_rule(arch, _rule("AI-LLM-ATLAS-135"), "ai")

    assert result["status"] in ("WARN", "FAIL")
    assert "dns rebinding" in result["triggered_patterns"]
    assert "browser tool" in result["triggered_patterns"]
    assert result["pattern_name"] == "DNS rebinding through browsing tools"
    assert result["attack_vector"].startswith("DNS rebinding through browsing tools:")
    assert result["pattern_quality"]["level"] == "industrial_offline"


def test_llm_atlas_specific_rules_ignore_generic_llm_tool_mentions():
    arch = "LLM assistant uses sanitized prompts, allowlisted tool calls, and human approval for write actions."

    result = _check_rule(arch, _rule("AI-LLM-ATLAS-135"), "ai")

    assert result["status"] == "PASS"
    assert result["triggered_patterns"] == []


def test_check_rule_includes_standard_fields():
    result = _check_rule("no match here", SAMPLE_RULE)
    assert "rule_id" in result
    assert "question" in result
    assert "severity" in result
    assert "mitigations" in result


def test_check_rule_includes_industrial_pattern_context():
    result = _check_rule(
        "REST API endpoint accepts user_id and has no authorization.",
        _rule("API-API1-01"),
        "api",
    )

    for key in (
        "pattern_name",
        "pattern_family",
        "description",
        "attack_vector",
        "impact",
        "control_objective",
        "false_positive_guidance",
    ):
        assert result[key], f"Missing enriched field: {key}"
    assert len(result["validation_steps"]) >= 3
    assert len(result["recommended_tests"]) >= 2
    assert len(result["evidence_to_collect"]) >= 3
    assert result["pattern_quality"]["level"] == "industrial_offline"


def test_all_offline_patterns_have_full_context():
    for ruleset, rules in ALL_RULES.items():
        for rule in rules:
            result = _check_rule("baseline architecture text", rule, ruleset)
            assert result["description"], rule["id"]
            assert result["attack_vector"], rule["id"]
            assert result["impact"], rule["id"]
            assert result["control_objective"], rule["id"]
            assert result["validation_steps"], rule["id"]
            assert result["recommended_tests"], rule["id"]
            assert result["implementation_guidance"], rule["id"]
            assert result["pattern_quality"]["gates"]["offline_ready"] is True


def test_check_rule_adds_owasp_api_reference():
    result = _check_rule("has api endpoint and user_id", SAMPLE_RULE)
    assert "owasp_reference" in result
    assert result["owasp_reference"]["id"].startswith("API1")


def test_check_rule_no_owasp_ref_for_unknown_category():
    rule = dict(SAMPLE_RULE, id="TEST-02", category="UNKNOWN99")
    result = _check_rule("api endpoint", rule)
    assert "owasp_reference" not in result


# ── detect_applicable_rulesets ────────────────────────────────────────────────

def test_detect_includes_web_for_web_application():
    rulesets = detect_applicable_rulesets("A basic CRUD web application.")
    assert "web" in rulesets


def test_detect_adds_api_for_api_architecture():
    rulesets = detect_applicable_rulesets("A REST API with JWT auth and order endpoints.")
    assert "api" in rulesets


def test_detect_does_not_add_api_for_static_site():
    rulesets = detect_applicable_rulesets("A static marketing website with CDN and contact form.")
    assert "api" not in rulesets


def test_detect_adds_ai_for_llm_architecture():
    arch = "Uses OpenAI GPT-4 API with LangChain agents and a vector store."
    rulesets = detect_applicable_rulesets(arch)
    assert "ai" in rulesets


def test_detect_no_ai_for_non_ai_architecture():
    arch = "PostgreSQL database behind a Django REST API with JWT auth."
    rulesets = detect_applicable_rulesets(arch)
    assert "ai" not in rulesets


# ── run_offline_review ────────────────────────────────────────────────────────

def test_run_returns_required_keys():
    result = run_offline_review("A simple web app with login form.")
    for key in ("methodology", "rulesets_applied", "findings", "overall_risk", "recommendations"):
        assert key in result, f"Missing key: {key}"


def test_run_findings_have_status():
    result = run_offline_review("REST API with endpoint and auth.")
    for f in result["findings"]:
        assert f["status"] in ("PASS", "WARN", "FAIL"), f"Bad status: {f}"


def test_run_explicit_rulesets():
    result = run_offline_review("REST API endpoint", rulesets=["api"])
    assert result["rulesets_applied"] == ["api"]
    assert all(f["ruleset"] == "api" for f in result["findings"])


def test_run_overall_risk_is_valid():
    result = run_offline_review("basic web app")
    assert result["overall_risk"] in ("Critical", "High", "Medium", "Low")


def test_run_summary_counts_consistent():
    result = run_offline_review("web app with api endpoint")
    counts = result["summary_counts"]
    assert counts["fail"] + counts["warn"] + counts["pass"] == counts["total"]
    assert counts["total"] == len(result["findings"])
