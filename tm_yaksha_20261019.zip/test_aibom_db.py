"""Tests for the SQLite AI-BOM store (aibom/db.py).

Isolates onto a temp DB, styled like test_report_db.py's TestReportDbModule.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from aibom import db


class TestAibomDb(unittest.TestCase):
    def setUp(self):
        self._orig_path = db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        db.DB_PATH = Path(self._td.name) / "aibom.db"
        db.init()

    def _restore(self):
        db.DB_PATH = self._orig_path

    def test_save_jobs_replaces_full_list(self):
        db.save_jobs([{"id": "j1", "repo_id": "r1", "started_at": "2026-01-01T00:00:00Z"}])
        db.save_jobs([{"id": "j2", "repo_id": "r1", "started_at": "2026-01-02T00:00:00Z"}])
        self.assertEqual([j["id"] for j in db.load_jobs()], ["j2"])
        self.assertEqual(db.job_count(), 1)

    def test_bom_roundtrip(self):
        self.assertIsNone(db.load_bom("aibom_1_aa"))
        db.save_bom("aibom_1_aa", {"bomFormat": "CycloneDX", "components": []})
        self.assertEqual(db.load_bom("aibom_1_aa")["bomFormat"], "CycloneDX")
        # save_bom replaces
        db.save_bom("aibom_1_aa", {"bomFormat": "CycloneDX", "components": [1]})
        self.assertEqual(db.load_bom("aibom_1_aa")["components"], [1])

    def test_latest_roundtrip_newest_first(self):
        db.save_latest("r1", {"repo_id": "r1", "scanned_at": "2026-01-01T00:00:00Z"})
        db.save_latest("r2", {"repo_id": "r2", "scanned_at": "2026-01-02T00:00:00Z"})
        inv = db.load_inventory()
        self.assertEqual([e["repo_id"] for e in inv], ["r2", "r1"])

    def test_remove_latest(self):
        db.save_latest("r1", {"repo_id": "r1", "scanned_at": "2026-01-01T00:00:00Z"})
        db.remove_latest("r1")
        self.assertEqual(db.load_inventory(), [])

    def test_backfill(self):
        n = db.backfill(
            jobs=[{"id": "j1", "repo_id": "r1", "started_at": "2026-01-01T00:00:00Z"}],
            boms={"aibom_1_aa": {"bomFormat": "CycloneDX"}},
            latest=[{"repo_id": "r1", "scanned_at": "2026-01-01T00:00:00Z"}])
        self.assertEqual(n, 3)
        self.assertEqual(db.job_count(), 1)
        self.assertIsNotNone(db.load_bom("aibom_1_aa"))
        self.assertEqual(len(db.load_inventory()), 1)

    def test_clear_all_wipes_jobs_boms_and_latest(self):
        db.save_jobs([{"id": "j1", "repo_id": "r1", "started_at": "2026-01-01T00:00:00Z"}])
        db.save_bom("aibom_1_aa", {"bomFormat": "CycloneDX"})
        db.save_latest("r1", {"repo_id": "r1", "scanned_at": "2026-01-01T00:00:00Z"})
        self.assertEqual(db.clear_all(), 1)
        self.assertEqual(db.load_jobs(), [])
        self.assertIsNone(db.load_bom("aibom_1_aa"))
        self.assertEqual(db.load_inventory(), [])


if __name__ == "__main__":
    unittest.main()
