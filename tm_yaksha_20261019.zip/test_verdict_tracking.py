"""Tests for verdict_tracking.py — escalation detection across re-correlations.

Isolates onto a temp DB, like test_suppressions.py's TestStore. Covers the
identity (fingerprint reuse), the escalation-vs-de-escalation distinction, the
first-seen-never-alerts rule, and the API + app-save wiring.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

import verdict_tracking
from suppressions import finding_fingerprint


def _cat(cid="WEB-A03-01", family="sql-injection", name="SQL Injection",
         verdict="blind_spot", loci=None):
    return {"id": cid, "name": name, "family": family, "risk": "High",
            "verdict": verdict,
            "affected_components": loci if loci is not None else ["app.py:7"]}


def _report(rid, cats, title="R"):
    return {"id": rid, "title": title, "categories": cats}


class TestVerdictTracking(unittest.TestCase):
    def setUp(self):
        self._orig = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        verdict_tracking.DB_PATH = self._orig

    def test_first_sighting_never_alerts(self):
        alerts = verdict_tracking.record_transitions(
            _report("r1", [_cat(verdict="blind_spot")]))
        self.assertEqual(alerts, [])

    def test_blind_spot_to_confirmed_exploitable_alerts(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        alerts = verdict_tracking.record_transitions(
            _report("r2", [_cat(verdict="confirmed_exploitable")]))
        self.assertEqual(len(alerts), 1)
        a = alerts[0]
        self.assertEqual(a["from_verdict"], "blind_spot")
        self.assertEqual(a["to_verdict"], "confirmed_exploitable")
        self.assertEqual(a["report_id"], "r2")
        self.assertEqual(a["family"], "sql-injection")

    def test_deescalation_updates_history_but_does_not_alert(self):
        verdict_tracking.record_transitions(
            _report("r1", [_cat(verdict="confirmed_exploitable")]))
        alerts = verdict_tracking.record_transitions(
            _report("r2", [_cat(verdict="design_gap")]))
        self.assertEqual(alerts, [])
        # history reflects the de-escalation even though no alert fired
        alerts2 = verdict_tracking.record_transitions(
            _report("r3", [_cat(verdict="confirmed_exploitable")]))
        self.assertEqual(len(alerts2), 1)   # re-escalating from the now-lower design_gap

    def test_same_verdict_again_is_a_no_op(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        alerts = verdict_tracking.record_transitions(_report("r2", [_cat(verdict="blind_spot")]))
        self.assertEqual(alerts, [])
        self.assertEqual(verdict_tracking.list_alerts(), [])

    def test_findings_without_a_verdict_are_ignored(self):
        cat = _cat()
        del cat["verdict"]
        alerts = verdict_tracking.record_transitions(_report("r1", [cat]))
        self.assertEqual(alerts, [])
        self.assertEqual(verdict_tracking.list_alerts(), [])

    def test_identity_reuses_suppressions_fingerprint(self):
        cat = _cat(verdict="blind_spot")
        verdict_tracking.record_transitions(_report("r1", [cat]))
        # a different report id, same underlying finding (same fingerprint) —
        # must still be recognized as "the same finding" for escalation purposes.
        self.assertNotEqual(finding_fingerprint(cat), "")
        alerts = verdict_tracking.record_transitions(
            _report("r2", [_cat(verdict="confirmed_exploitable")]))
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0]["fingerprint"], finding_fingerprint(cat))

    def test_different_finding_does_not_cross_contaminate(self):
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="WEB-A03-01", verdict="blind_spot")]))
        # a different rule id -> different fingerprint -> first sighting, no alert
        alerts = verdict_tracking.record_transitions(
            _report("r2", [_cat(cid="WEB-A07-01", verdict="confirmed_exploitable")]))
        self.assertEqual(alerts, [])

    def test_list_alerts_and_unacknowledged_count(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        verdict_tracking.record_transitions(_report("r2", [_cat(verdict="confirmed_exploitable")]))
        items = verdict_tracking.list_alerts()
        self.assertEqual(len(items), 1)
        self.assertEqual(verdict_tracking.unacknowledged_count(), 1)

    def test_acknowledge_removes_from_unacknowledged_count(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        alerts = verdict_tracking.record_transitions(
            _report("r2", [_cat(verdict="confirmed_exploitable")]))
        alert_id = verdict_tracking.list_alerts()[0]["id"]
        self.assertTrue(verdict_tracking.acknowledge_alert(alert_id))
        self.assertEqual(verdict_tracking.unacknowledged_count(), 0)
        self.assertEqual(verdict_tracking.list_alerts(unacknowledged_only=True), [])
        self.assertEqual(len(verdict_tracking.list_alerts()), 1)   # still in the full log

    def test_acknowledge_unknown_id_returns_false(self):
        self.assertFalse(verdict_tracking.acknowledge_alert(999999))

    def test_delete_all_wipes_history_and_alerts(self):
        verdict_tracking.record_transitions(_report("r1", [_cat(verdict="blind_spot")]))
        verdict_tracking.record_transitions(_report("r2", [_cat(verdict="confirmed_exploitable")]))
        n = verdict_tracking.delete_all()
        self.assertEqual(n, 1)
        self.assertEqual(verdict_tracking.list_alerts(), [])
        # history wiped too -> next sighting is "first" again, no alert
        alerts = verdict_tracking.record_transitions(
            _report("r3", [_cat(verdict="confirmed_exploitable")]))
        self.assertEqual(alerts, [])


class TestVerdictSla(unittest.TestCase):
    DAY = 86400.0

    def setUp(self):
        self._orig = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        verdict_tracking.DB_PATH = self._orig

    def test_fresh_finding_is_on_track(self):
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(verdict="confirmed_exploitable")]), now=t0)
        rows = verdict_tracking.sla_status(now=t0 + 1 * self.DAY)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["status"], "ok")
        self.assertEqual(rows[0]["sla_days"], 3)

    def test_confirmed_exploitable_breaches_after_3_days(self):
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(verdict="confirmed_exploitable")]), now=t0)
        rows = verdict_tracking.sla_status(now=t0 + 4 * self.DAY)
        self.assertEqual(rows[0]["status"], "breached")
        self.assertAlmostEqual(rows[0]["remaining_days"], -1.0, places=1)

    def test_at_risk_is_the_last_20_percent_of_the_window(self):
        t0 = 1_000_000.0
        # design_gap SLA is 30 days; 25 days in is 5 remaining (< 20% of 30 = 6)
        verdict_tracking.record_transitions(
            _report("r1", [_cat(verdict="design_gap")]), now=t0)
        rows = verdict_tracking.sla_status(now=t0 + 25 * self.DAY)
        self.assertEqual(rows[0]["status"], "at_risk")

    def test_verdict_change_resets_the_sla_clock(self):
        t0 = 1_000_000.0
        # blind_spot for a long time (90d SLA) then escalates to
        # confirmed_exploitable (3d SLA) -- the clock must restart, not carry
        # over the old accumulated age, or a genuinely fresh escalation would
        # show as already breached the instant it's detected.
        verdict_tracking.record_transitions(
            _report("r1", [_cat(verdict="blind_spot")]), now=t0)
        verdict_tracking.record_transitions(
            _report("r2", [_cat(verdict="confirmed_exploitable")]), now=t0 + 60 * self.DAY)
        rows = verdict_tracking.sla_status(now=t0 + 60 * self.DAY + 1 * self.DAY)
        self.assertEqual(rows[0]["status"], "ok")
        self.assertAlmostEqual(rows[0]["age_days"], 1.0, places=1)

    def test_unchanged_verdict_keeps_accumulating_age(self):
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(verdict="blind_spot")]), now=t0)
        # re-seen with the SAME verdict on a later scan -- age must keep
        # counting from the original verdict_since, not reset to this scan.
        verdict_tracking.record_transitions(
            _report("r2", [_cat(verdict="blind_spot")]), now=t0 + 10 * self.DAY)
        rows = verdict_tracking.sla_status(now=t0 + 10 * self.DAY)
        self.assertAlmostEqual(rows[0]["age_days"], 10.0, places=1)

    def test_status_filter(self):
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="A", verdict="confirmed_exploitable")]), now=t0)
        verdict_tracking.record_transitions(
            _report("r2", [_cat(cid="B", verdict="blind_spot")]), now=t0)
        breached_only = verdict_tracking.sla_status(now=t0 + 10 * self.DAY, statuses=("breached",))
        self.assertEqual(len(breached_only), 1)
        self.assertEqual(breached_only[0]["verdict"], "confirmed_exploitable")

    def test_summary_counts_and_worst_list(self):
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="A", verdict="confirmed_exploitable")]), now=t0)
        verdict_tracking.record_transitions(
            _report("r2", [_cat(cid="B", verdict="blind_spot")]), now=t0)
        summary = verdict_tracking.sla_summary(now=t0 + 10 * self.DAY)
        self.assertEqual(summary["tracked"], 2)
        self.assertEqual(summary["counts"]["breached"], 1)
        self.assertEqual(summary["counts"]["ok"], 1)
        self.assertEqual(summary["by_verdict"]["confirmed_exploitable"]["breached"], 1)
        self.assertEqual(len(summary["worst"]), 1)
        self.assertEqual(summary["worst"][0]["verdict"], "confirmed_exploitable")

    def test_old_database_without_verdict_since_migrates_and_backfills(self):
        import sqlite3
        conn = sqlite3.connect(str(verdict_tracking.DB_PATH))
        conn.executescript("""
            DROP TABLE IF EXISTS verdict_history;
            CREATE TABLE verdict_history (
                fingerprint TEXT PRIMARY KEY, family TEXT, rule TEXT, title TEXT,
                verdict TEXT NOT NULL, report_id TEXT, report_title TEXT,
                first_seen REAL, updated_at REAL
            );
        """)
        t0 = 1_000_000.0
        conn.execute(
            "INSERT INTO verdict_history VALUES (?,?,?,?,?,?,?,?,?)",
            ("fp1", "sql-injection", "R1", "SQLi", "confirmed_exploitable",
             "r1", "R", t0, t0))
        conn.commit()
        conn.close()

        verdict_tracking.init()   # must migrate + backfill, not raise
        rows = verdict_tracking.sla_status(now=t0 + 1 * self.DAY)
        self.assertEqual(len(rows), 1)
        self.assertAlmostEqual(rows[0]["age_days"], 1.0, places=1)   # backfilled from first_seen


class TestDesignDebt(unittest.TestCase):
    DAY = 86400.0

    def setUp(self):
        self._orig = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

    def _restore(self):
        verdict_tracking.DB_PATH = self._orig

    def test_empty_store_reports_zero_debt(self):
        s = verdict_tracking.design_debt_summary()
        self.assertEqual(s["open"], 0)
        self.assertEqual(s["oldest_days"], 0.0)
        self.assertEqual(s["net_recent"], 0)

    def test_open_count_and_oldest_age(self):
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="A", verdict="design_gap")]), now=t0)
        verdict_tracking.record_transitions(
            _report("r2", [_cat(cid="B", verdict="design_gap")]), now=t0 + 5 * self.DAY)
        s = verdict_tracking.design_debt_summary(now=t0 + 20 * self.DAY)
        self.assertEqual(s["open"], 2)
        self.assertAlmostEqual(s["oldest_days"], 20.0, places=1)   # the older of the two

    def test_confirmed_or_blind_spot_are_not_open_debt(self):
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="A", verdict="confirmed_exploitable"),
                           _cat(cid="B", verdict="blind_spot"),
                           _cat(cid="C", verdict="design_gap")]), now=t0)
        s = verdict_tracking.design_debt_summary(now=t0)
        self.assertEqual(s["open"], 1)

    def test_opened_recent_counts_findings_new_to_design_gap(self):
        t0 = 1_000_000.0
        # opened long ago -> outside the 30d window
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="OLD", verdict="design_gap")]), now=t0)
        # opened inside the window
        verdict_tracking.record_transitions(
            _report("r2", [_cat(cid="NEW", verdict="design_gap")]), now=t0 + 40 * self.DAY)
        s = verdict_tracking.design_debt_summary(now=t0 + 45 * self.DAY, window_days=30)
        self.assertEqual(s["opened_recent"], 1)   # only NEW, OLD is >30d old

    def test_resolved_recent_counts_escalations_out_of_design_gap(self):
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="A", verdict="design_gap")]), now=t0)
        # escalates to confirmed_exploitable inside the window -> resolved
        verdict_tracking.record_transitions(
            _report("r2", [_cat(cid="A", verdict="confirmed_exploitable")]), now=t0 + 5 * self.DAY)
        s = verdict_tracking.design_debt_summary(now=t0 + 10 * self.DAY, window_days=30)
        self.assertEqual(s["resolved_recent"], 1)
        self.assertEqual(s["open"], 0)   # no longer design_gap at all

    def test_design_gap_to_blind_spot_does_not_count_as_resolved(self):
        # blind_spot ranks LESS actionable than design_gap -- not an
        # escalation, so it must not count as debt "resolved".
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="A", verdict="design_gap")]), now=t0)
        verdict_tracking.record_transitions(
            _report("r2", [_cat(cid="A", verdict="blind_spot")]), now=t0 + 5 * self.DAY)
        s = verdict_tracking.design_debt_summary(now=t0 + 10 * self.DAY, window_days=30)
        self.assertEqual(s["resolved_recent"], 0)

    def test_net_recent_is_opened_minus_resolved(self):
        # Non-overlapping scenario, deliberately: A and C both opened BEFORE
        # the window (so neither counts as "opened_recent" even though A is
        # still open and C resolves inside the window); B opens INSIDE the
        # window and stays open. opened_recent only counts findings that are
        # both currently open AND new within the window -- a finding that
        # both entered and fully resolved inside the same window shows up in
        # resolved_recent only, not opened_recent (see the dedicated
        # opened/resolved tests for each half in isolation).
        t0 = 1_000_000.0
        verdict_tracking.record_transitions(
            _report("r1", [_cat(cid="A", verdict="design_gap"),
                           _cat(cid="C", verdict="design_gap")]), now=t0)
        verdict_tracking.record_transitions(
            _report("r2", [_cat(cid="B", verdict="design_gap")]), now=t0 + 35 * self.DAY)
        verdict_tracking.record_transitions(
            _report("r3", [_cat(cid="C", verdict="confirmed_exploitable")]), now=t0 + 38 * self.DAY)

        s = verdict_tracking.design_debt_summary(now=t0 + 40 * self.DAY, window_days=30)
        self.assertEqual(s["open"], 2)          # A (still open, old) and B (still open, new)
        self.assertEqual(s["opened_recent"], 1)   # only B -- A predates the window
        self.assertEqual(s["resolved_recent"], 1)   # C
        self.assertEqual(s["net_recent"], 0)   # 1 - 1


class TestVerdictTrackingApi(unittest.TestCase):
    def setUp(self):
        self._orig = verdict_tracking.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdicts.db"
        verdict_tracking.init()

        import app as tm_app
        self.tm_app = tm_app
        self.client = tm_app.app.test_client()

    def _restore(self):
        verdict_tracking.DB_PATH = self._orig

    def _token(self):
        return self.client.get("/api/csrf-token").get_json()["token"]

    def test_save_report_records_transitions(self):
        rid1 = self.tm_app._save_report(_report("ignored", [_cat(verdict="blind_spot")]), "R1")
        try:
            rid2 = self.tm_app._save_report(
                _report("ignored", [_cat(verdict="confirmed_exploitable")]), "R2")
            try:
                self.assertEqual(verdict_tracking.unacknowledged_count(), 1)
            finally:
                self.tm_app.report_db.delete_report(rid2)
                self._unlink(rid2)
        finally:
            self.tm_app.report_db.delete_report(rid1)
            self._unlink(rid1)

    def _unlink(self, rid):
        import os
        try:
            os.unlink(self.tm_app.REPORTS_DIR / f"{rid}.json")
        except OSError:
            pass

    def test_alerts_endpoint_and_acknowledge(self):
        rid1 = self.tm_app._save_report(_report("ignored", [_cat(verdict="blind_spot")]), "R1")
        rid2 = self.tm_app._save_report(
            _report("ignored", [_cat(verdict="confirmed_exploitable")]), "R2")
        try:
            token = self._token()
            r = self.client.get("/api/v1/correlate/alerts")
            d = r.get_json()
            self.assertTrue(d["success"])
            self.assertEqual(d["unacknowledged"], 1)
            self.assertEqual(len(d["alerts"]), 1)
            alert_id = d["alerts"][0]["id"]

            ack = self.client.post(f"/api/v1/correlate/alerts/{alert_id}/acknowledge",
                                   headers={"X-CSRF-Token": token})
            self.assertEqual(ack.status_code, 200)

            r2 = self.client.get("/api/v1/correlate/alerts?unacknowledged=1").get_json()
            self.assertEqual(r2["count"], 0)
        finally:
            self.tm_app.report_db.delete_report(rid1)
            self._unlink(rid1)
            self.tm_app.report_db.delete_report(rid2)
            self._unlink(rid2)

    def test_sla_endpoint(self):
        rid = self.tm_app._save_report(
            _report("ignored", [_cat(verdict="confirmed_exploitable")]), "R1")
        try:
            d = self.client.get("/api/v1/correlate/sla").get_json()
            self.assertTrue(d["success"])
            self.assertEqual(d["summary"]["tracked"], 1)
            self.assertEqual(len(d["findings"]), 1)
            self.assertEqual(d["findings"][0]["verdict"], "confirmed_exploitable")

            filtered = self.client.get("/api/v1/correlate/sla?status=breached").get_json()
            self.assertEqual(filtered["findings"], [])   # freshly recorded -> not breached yet
        finally:
            self.tm_app.report_db.delete_report(rid)
            self._unlink(rid)

    def test_design_debt_endpoint(self):
        report = {"id": "ignored", "title": "R1", "methodology": "correlation",
                  "categories": [_cat(verdict="design_gap")]}
        rid = self.tm_app._save_report(report, "R1")
        try:
            d = self.client.get("/api/v1/correlate/design-debt").get_json()
            self.assertTrue(d["success"])
            self.assertEqual(d["summary"]["open"], 1)
            point = next((p for p in d["burndown"] if p["id"] == rid), None)
            self.assertIsNotNone(point)
            self.assertEqual(point["design_gap"], 1)

            windowed = self.client.get(
                "/api/v1/correlate/design-debt?window_days=1").get_json()
            self.assertEqual(windowed["summary"]["window_days"], 1)
        finally:
            self.tm_app.report_db.delete_report(rid)
            self._unlink(rid)

    def test_reachable_dependencies_endpoint(self):
        report = {"id": "ignored", "title": "R1", "methodology": "correlation",
                  "categories": [{"id": "CORR-001", "name": "Vulnerable Components",
                                  "risk": "Critical", "_source": "CORRELATION",
                                  "dependency_reachability": {
                                      "pyyaml": {"unauthenticated": True, "tainted": True,
                                                 "min_hops": 0, "agent_tool": False}}}]}
        rid = self.tm_app._save_report(report, "R1")
        try:
            d = self.client.get("/api/v1/correlate/reachable-dependencies").get_json()
            self.assertTrue(d["success"])
            self.assertEqual(d["count"], 1)
            self.assertEqual(d["items"][0]["component"], "pyyaml")
            self.assertEqual(d["items"][0]["report_id"], rid)
        finally:
            self.tm_app.report_db.delete_report(rid)
            self._unlink(rid)

    def test_acknowledge_missing_alert_404s(self):
        token = self._token()
        r = self.client.post("/api/v1/correlate/alerts/999999/acknowledge",
                             headers={"X-CSRF-Token": token})
        self.assertEqual(r.status_code, 404)


if __name__ == "__main__":
    unittest.main()
