"""owasp_api_2023.py — OWASP API Security Top 10 (2023) checklist data."""
from __future__ import annotations

OWASP_API_2023: list[dict] = [
    {
        "id": "API1:2023", "name": "Broken Object Level Authorization (BOLA)", "stride": ["E", "I"],
        "items": [
            "Numeric/sequential resource IDs enabling enumeration (/orders/1234 → /orders/1235)",
            "No server-side check that requesting user owns the resource",
            "Object ID swapped in URL, body, or header to access another user's data",
            "Bulk endpoints return all records without filtering by authenticated user",
        ],
        "test": "Change resource ID to another user's. Does the server return it?",
        "mitigation": "Ownership check on every request; UUIDv4 for IDs; ASVS V4",
    },
    {
        "id": "API2:2023", "name": "Broken Authentication", "stride": ["S"],
        "items": [
            "API keys in query parameters (logged in proxies and server logs)",
            "API keys never expire or have no rotation mechanism",
            "JWT: weak HMAC secret; alg:none accepted; no exp check; no token invalidation on logout",
            "Refresh tokens never expire or not rotated on use",
            "HTTP Basic Auth over non-TLS connection",
        ],
        "test": "Try expired tokens, alg:none JWTs, and replayed refresh tokens.",
        "mitigation": "Short-lived JWTs (15 min); rotating refresh tokens; Authorization header only; ASVS V2/V3",
    },
    {
        "id": "API3:2023", "name": "Broken Object Property Level Authorization", "stride": ["I", "E"],
        "items": [
            "Excessive data exposure — API returns full object including hidden fields (passwordHash, adminNotes)",
            "Mass assignment — API accepts privileged fields in request body (role:admin, isVerified:true)",
            "Client-side filtering used instead of server-side field projection",
        ],
        "test": "POST request body with 'role':'admin'. Does the server silently apply it?",
        "mitigation": "Explicit allowlist of readable/writable fields per role; DTOs not raw model binding; ASVS V4.2",
    },
    {
        "id": "API4:2023", "name": "Unrestricted Resource Consumption", "stride": ["D"],
        "items": [
            "No rate limiting on any endpoint",
            "No per-user or per-IP request quotas",
            "No pagination — single request returns millions of records",
            "GraphQL: no query depth limit, no complexity limit, no alias limit",
            "No maximum request body size limit",
            "File upload with no size or type restriction",
            "Long-running operations with no timeout or concurrency cap",
        ],
        "mitigation": "Token-bucket rate limiting; server-enforced pagination; GraphQL complexity limits; ASVS V13.4",
    },
    {
        "id": "API5:2023", "name": "Broken Function Level Authorization", "stride": ["E"],
        "items": [
            "Admin endpoints (/api/admin/*) accessible by regular user tokens",
            "HTTP method not validated — DELETE allowed where only GET intended",
            "Different API versions have inconsistent auth rules (v1 stricter than v2)",
            "Undocumented endpoints discoverable in JS bundles with weaker controls",
        ],
        "test": "Call admin endpoint with regular user JWT. Does server reject?",
        "mitigation": "Centralised auth middleware applied to all routes; deny by default; ASVS V4.1",
    },
    {
        "id": "API6:2023", "name": "Unrestricted Access to Sensitive Business Flows", "stride": ["D", "T"],
        "items": [
            "Coupon/promo codes usable unlimited times per account",
            "Bulk account registration automatable (no CAPTCHA, no velocity check)",
            "Ticket/reservation hold-without-purchase locks inventory",
            "buy endpoint callable directly without checkout (price manipulation)",
            "Voting/rating endpoint spammable in automated loop",
            "Password reset flow usable to enumerate valid email addresses",
        ],
        "mitigation": "Business logic rate limits; device fingerprinting; CAPTCHA on sensitive flows; ASVS V11",
    },
    {
        "id": "API7:2023", "name": "Server Side Request Forgery (SSRF)", "stride": ["I", "E"],
        "items": [
            "URL parameter fetched by server without allowlist",
            "Webhook URL registration accepts internal IP ranges (RFC1918: 10.x, 172.16.x, 192.168.x)",
            "Import-from-URL or fetch-preview features fetch arbitrary hosts",
            "API gateway routes to backend URL derived from user input",
            "IMDSv1 enabled on cloud instances (exposes IAM credentials via SSRF to 169.254.169.254)",
        ],
        "mitigation": "Outbound URL allowlist; block RFC1918 ranges; IMDSv2 required; ASVS V10.3",
    },
    {
        "id": "API8:2023", "name": "Security Misconfiguration", "stride": ["I"],
        "items": [
            "Swagger/OpenAPI spec publicly accessible (exposes full attack surface)",
            "CORS wildcard on endpoints returning user data",
            "API returns different data based on debug headers",
            "Deprecated API versions (/v1/) still active alongside current version",
            "Default credentials left unchanged on API management platforms",
        ],
        "mitigation": "Remove public API docs in prod; strict CORS; deprecate old versions; apply A02:2025 controls",
    },
    {
        "id": "API9:2023", "name": "Improper Inventory Management", "stride": ["I"],
        "items": [
            "Shadow APIs — undocumented endpoints exposed (discoverable in JS bundles, mobile apps)",
            "Deprecated API versions active with no sunset date",
            "No API gateway — backend services directly internet-accessible",
            "Microservices expose internal APIs to peer services without authentication",
            "Third-party integrations undocumented — unknown data flows",
        ],
        "mitigation": "API gateway for all external traffic; API registry; automated endpoint discovery in CI; sunset policy",
    },
    {
        "id": "API10:2023", "name": "Unsafe Consumption of APIs", "stride": ["T", "I"],
        "items": [
            "Third-party API responses trusted without schema validation",
            "Redirects from third parties followed blindly",
            "Third-party data written to DB or rendered to users without sanitization",
            "Third-party API keys not rotated when vendor relationship ends",
        ],
        "mitigation": "Schema validation on all external responses; sanitize before storing; treat external data as untrusted",
    },
]
