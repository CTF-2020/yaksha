"""Tests for the flat, sortable, cross-report triage worklist (triage.py).

Isolated onto temp SQLite stores for both report_db and suppressions -- writing
through the real ones would pollute ~/.tm_reports / ~/.tm_suppressions.db (see
report_db's own test isolation pattern in test_report_db.py).
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

import ownership
import report_db
import triage
from suppressions import db as supp_db
from suppressions import store as supp_store


def _report(rid, methodology, cats, title="R"):
    return {"id": rid, "title": title, "methodology": methodology,
            "overall_risk": cats[0]["risk"] if cats else "Info",
            "analyzed_at": "2026-08-02T00:00:00Z", "categories": cats}


def _cat(cid, name, risk, family=None, cwe="", loci=None, verdict=None, ssvc_action=None):
    cat = {"id": cid, "name": name, "title": name, "risk": risk, "cwe": cwe,
           "threats": [{"name": l} for l in (loci or [])],
           "affected_components": loci or []}
    if family:
        cat["family"] = family
    if verdict:
        cat["verdict"] = verdict
    if ssvc_action:
        cat["ssvc_action"] = ssvc_action
    return cat


class TriageQueueTests(unittest.TestCase):
    def setUp(self):
        self._orig_report_db_path = report_db.DB_PATH
        self._orig_supp_db_path = supp_db.DB_PATH
        self._orig_backup_path = supp_store._BACKUP_PATH
        self._orig_ownership_path = ownership.DB_PATH
        self.addCleanup(self._restore)

        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"
        report_db.init()

    def _restore(self):
        report_db.DB_PATH = self._orig_report_db_path
        supp_db.DB_PATH = self._orig_supp_db_path
        supp_store._BACKUP_PATH = self._orig_backup_path
        ownership.DB_PATH = self._orig_ownership_path

    def _seed(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQL Injection", "Critical", family="sql-injection",
                  cwe="CWE-89", loci=["a.py:1"], verdict="confirmed_exploitable",
                  ssvc_action="act"),
             _cat("R2", "Weak Hash", "Low", family="weak-crypto",
                  cwe="CWE-328", loci=["b.py:2"])]))
        report_db.upsert_report(_report(
            "200_1_bb", "sast",
            [_cat("R3", "XSS", "High", family="xss", cwe="CWE-79",
                  loci=["c.py:3"])]))

    # ---- basic shape / cross-tool inclusion ----------------------------

    def test_queue_includes_sast_by_default(self):
        self._seed()
        result = triage.queue()
        methods = {f["methodology"] for f in result["findings"]}
        self.assertIn("sast", methods)
        self.assertIn("codemodel", methods)

    def test_default_sort_is_severity_worst_first(self):
        self._seed()
        result = triage.queue()
        sevs = [f["severity"] for f in result["findings"]]
        self.assertEqual(sevs, sorted(sevs, key=lambda s: triage._SEV_RANK[s]))
        self.assertEqual(sevs[0], "Critical")

    def test_sort_by_verdict_desc(self):
        self._seed()
        result = triage.queue(sort="verdict", order="desc")
        # blind_spot / unverdicted rank last ascending, so desc puts them first
        self.assertEqual(result["findings"][0]["verdict"], "")

    def test_sort_by_ssvc_action_ascending_puts_act_first(self):
        self._seed()
        result = triage.queue(sort="ssvc_action", order="asc")
        self.assertEqual(result["findings"][0]["ssvc_action"], "act")

    def test_sort_by_ssvc_action_desc_puts_unscored_first(self):
        self._seed()
        result = triage.queue(sort="ssvc_action", order="desc")
        self.assertEqual(result["findings"][0]["ssvc_action"], "")

    def test_filter_by_ssvc_action(self):
        self._seed()
        result = triage.queue(ssvc_action="act")
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["findings"][0]["family"], "sql-injection")

    def test_filter_by_ssvc_action_empty_means_unscored(self):
        self._seed()
        result = triage.queue(ssvc_action="")
        self.assertEqual(result["total"], 2)   # weak-crypto + xss, never correlated

    # ---- filters ---------------------------------------------------------

    def test_filter_by_severity(self):
        self._seed()
        result = triage.queue(severity="Critical")
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["findings"][0]["family"], "sql-injection")

    def test_filter_by_family(self):
        self._seed()
        result = triage.queue(family="xss")
        self.assertEqual(result["total"], 1)

    def test_filter_by_methodology(self):
        self._seed()
        result = triage.queue(methodology="sast")
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["findings"][0]["family"], "xss")

    def test_filter_by_verdict_empty_means_uncorrelated(self):
        self._seed()
        result = triage.queue(verdict="")
        titles = {f["title"] for f in result["findings"]}
        self.assertIn("Weak Hash", titles)
        self.assertNotIn("SQL Injection", titles)

    def test_free_text_search(self):
        self._seed()
        result = triage.queue(q="Weak Hash")
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["findings"][0]["title"], "Weak Hash")

    # ---- pagination --------------------------------------------------------

    def test_pagination_math(self):
        self._seed()
        page1 = triage.queue(per_page=2, page=1)
        self.assertEqual(page1["total"], 3)
        self.assertEqual(page1["pages"], 2)
        self.assertEqual(len(page1["findings"]), 2)
        page2 = triage.queue(per_page=2, page=2)
        self.assertEqual(len(page2["findings"]), 1)

    def test_page_beyond_range_clamps_to_last_page(self):
        self._seed()
        result = triage.queue(per_page=2, page=99)
        self.assertEqual(result["page"], 2)

    # ---- suppression -------------------------------------------------------

    def test_suppressed_finding_scope_hidden_by_default(self):
        self._seed()
        cat = _cat("R1", "SQL Injection", "Critical", family="sql-injection",
                   cwe="CWE-89", loci=["a.py:1"], verdict="confirmed_exploitable")
        from suppressions.engine import finding_fingerprint
        fp = finding_fingerprint(cat)
        supp_store.add_suppression({"scope": "finding", "match": fp,
                                    "reason": "accepted risk", "author": "tester"})
        result = triage.queue()
        families = {f["family"] for f in result["findings"]}
        self.assertNotIn("sql-injection", families)
        self.assertEqual(result["total"], 2)

    def test_suppressed_finding_shown_when_included(self):
        self._seed()
        cat = _cat("R1", "SQL Injection", "Critical", family="sql-injection",
                   cwe="CWE-89", loci=["a.py:1"], verdict="confirmed_exploitable")
        from suppressions.engine import finding_fingerprint
        fp = finding_fingerprint(cat)
        supp_store.add_suppression({"scope": "finding", "match": fp,
                                    "reason": "accepted risk", "author": "tester"})
        result = triage.queue(include_suppressed=True)
        self.assertEqual(result["total"], 3)
        hit = next(f for f in result["findings"] if f["family"] == "sql-injection")
        self.assertTrue(hit["suppressed"])

    def test_finding_scope_suppression_covers_every_locus_of_a_multiloci_category(self):
        # The whole point of storing the category-level fingerprint on every
        # derived row (report_db._derive_findings) instead of a per-locus one:
        # a "finding"-scope suppression must mute ALL loci, not just one.
        report_db.upsert_report(_report(
            "300_1_cc", "codemodel",
            [_cat("R9", "Command Injection", "High", family="command-injection",
                  cwe="CWE-78", loci=["x.py:1", "y.py:2", "z.py:3"])]))
        cat = _cat("R9", "Command Injection", "High", family="command-injection",
                   cwe="CWE-78", loci=["x.py:1", "y.py:2", "z.py:3"])
        from suppressions.engine import finding_fingerprint
        fp = finding_fingerprint(cat)
        supp_store.add_suppression({"scope": "finding", "match": fp,
                                    "reason": "false positive", "author": "tester"})
        result = triage.queue(family="command-injection")
        self.assertEqual(result["total"], 0)

    def test_family_scope_suppression_with_max_verdict_gate(self):
        # A family-scope suppression capped at max_verdict="design_gap" must not
        # mute a confirmed_exploitable finding of that family (suppressions.model
        # docstring's own example).
        report_db.upsert_report(_report(
            "400_1_dd", "correlation",
            [_cat("R5", "SSRF", "Critical", family="ssrf", cwe="CWE-918",
                  loci=["net.py:1"], verdict="confirmed_exploitable")]))
        supp_store.add_suppression({"scope": "family", "match": "ssrf",
                                    "max_verdict": "design_gap",
                                    "reason": "known noisy family", "author": "tester"})
        result = triage.queue(family="ssrf")
        self.assertEqual(result["total"], 1)   # NOT suppressed -- rank too high

    # ---- owner assignment ---------------------------------------------------

    def test_finding_carries_no_owner_by_default(self):
        self._seed()
        result = triage.queue()
        self.assertTrue(all(f["owner"] == "" and f["owner_source"] == "" for f in result["findings"]))

    def test_bucket_default_owner_applied(self):
        self._seed()
        ownership.set_default("confirmed_exploitable", "appsec-oncall")
        result = triage.queue(family="sql-injection")
        self.assertEqual(result["findings"][0]["owner"], "appsec-oncall")
        self.assertEqual(result["findings"][0]["owner_source"], "default")

    def test_per_finding_override_beats_bucket_default(self):
        self._seed()
        ownership.set_default("confirmed_exploitable", "appsec-oncall")
        cat = _cat("R1", "SQL Injection", "Critical", family="sql-injection",
                   cwe="CWE-89", loci=["a.py:1"], verdict="confirmed_exploitable")
        from suppressions.engine import finding_fingerprint
        fp = finding_fingerprint(cat)
        ownership.assign(fp, "alice", assigned_by="bob")
        result = triage.queue(family="sql-injection")
        self.assertEqual(result["findings"][0]["owner"], "alice")
        self.assertEqual(result["findings"][0]["owner_source"], "override")

    def test_filter_by_owner(self):
        self._seed()
        cat = _cat("R1", "SQL Injection", "Critical", family="sql-injection",
                   cwe="CWE-89", loci=["a.py:1"], verdict="confirmed_exploitable")
        from suppressions.engine import finding_fingerprint
        fp = finding_fingerprint(cat)
        ownership.assign(fp, "alice")
        result = triage.queue(owner="alice")
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["findings"][0]["family"], "sql-injection")

    def test_filter_by_owner_empty_means_unassigned(self):
        self._seed()
        cat = _cat("R1", "SQL Injection", "Critical", family="sql-injection",
                   cwe="CWE-89", loci=["a.py:1"], verdict="confirmed_exploitable")
        from suppressions.engine import finding_fingerprint
        fp = finding_fingerprint(cat)
        ownership.assign(fp, "alice")
        result = triage.queue(owner="")
        families = {f["family"] for f in result["findings"]}
        self.assertNotIn("sql-injection", families)
        self.assertEqual(result["total"], 2)

    def test_sort_by_owner(self):
        self._seed()
        cat = _cat("R1", "SQL Injection", "Critical", family="sql-injection",
                   cwe="CWE-89", loci=["a.py:1"], verdict="confirmed_exploitable")
        from suppressions.engine import finding_fingerprint
        fp = finding_fingerprint(cat)
        ownership.assign(fp, "alice")
        result = triage.queue(sort="owner", order="asc")
        # assigned findings sort before unassigned regardless of name
        self.assertEqual(result["findings"][0]["owner"], "alice")

    def test_expired_suppression_no_longer_applies(self):
        self._seed()
        cat = _cat("R1", "SQL Injection", "Critical", family="sql-injection",
                   cwe="CWE-89", loci=["a.py:1"], verdict="confirmed_exploitable")
        from suppressions.engine import finding_fingerprint
        fp = finding_fingerprint(cat)
        supp_store.add_suppression({"scope": "finding", "match": fp,
                                    "reason": "temp", "author": "tester",
                                    "expires_at": 1.0})   # long expired
        result = triage.queue()
        families = {f["family"] for f in result["findings"]}
        self.assertIn("sql-injection", families)


class TriageAPITests(unittest.TestCase):
    """Endpoint wiring: routes registered, params parsed, page renders."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.tm_app = tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orig_report_db_path = report_db.DB_PATH
        self._orig_supp_db_path = supp_db.DB_PATH
        self._orig_backup_path = supp_store._BACKUP_PATH
        self._orig_ownership_path = ownership.DB_PATH
        self.addCleanup(self._restore)

        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"
        report_db.init()
        report_db.upsert_report(_report(
            "500_1_ee", "codemodel",
            [_cat("R1", "SQL Injection", "Critical", family="sql-injection",
                  cwe="CWE-89", loci=["a.py:1"])]))

    def _restore(self):
        report_db.DB_PATH = self._orig_report_db_path
        supp_db.DB_PATH = self._orig_supp_db_path
        supp_store._BACKUP_PATH = self._orig_backup_path
        ownership.DB_PATH = self._orig_ownership_path

    def test_triage_page_renders(self):
        resp = self.client.get("/triage")
        self.assertEqual(resp.status_code, 200)
        self.assertIn(b"Triage Queue", resp.data)

    def test_triage_api_returns_seeded_finding(self):
        d = self.client.get("/api/v1/triage").get_json()
        self.assertTrue(d["success"])
        families = {f["family"] for f in d["findings"]}
        self.assertIn("sql-injection", families)

    def test_triage_api_rejects_bad_sort(self):
        resp = self.client.get("/api/v1/triage?sort=not-a-column")
        self.assertEqual(resp.status_code, 400)

    def test_triage_api_rejects_non_integer_page(self):
        resp = self.client.get("/api/v1/triage?page=abc")
        self.assertEqual(resp.status_code, 400)

    def test_methodologies_endpoint(self):
        d = self.client.get("/api/v1/triage/methodologies").get_json()
        self.assertTrue(d["success"])
        names = {m["methodology"] for m in d["methodologies"]}
        self.assertIn("codemodel", names)

    def test_export_sarif_returns_valid_document(self):
        resp = self.client.get("/api/v1/triage/export.sarif")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.mimetype, "application/sarif+json")
        doc = resp.get_json()
        self.assertEqual(doc["version"], "2.1.0")
        rule_ids = {r["id"] for r in doc["runs"][0]["tool"]["driver"]["rules"]}
        self.assertIn("R1", rule_ids)

    def test_export_sarif_respects_verdict_filter(self):
        report_db.upsert_report(_report(
            "500_2_ff", "correlation",
            [_cat("R2", "SSRF", "Medium", family="ssrf", cwe="CWE-918",
                  loci=["net.py:1"], verdict="confirmed_exploitable")]))
        resp = self.client.get("/api/v1/triage/export.sarif?verdict=confirmed_exploitable")
        doc = resp.get_json()
        rule_ids = {r["id"] for r in doc["runs"][0]["tool"]["driver"]["rules"]}
        self.assertEqual(rule_ids, {"R2"})

    def test_export_sarif_rejects_bad_sort(self):
        resp = self.client.get("/api/v1/triage/export.sarif?sort=not-a-column")
        self.assertEqual(resp.status_code, 400)

    def test_nav_lists_triage(self):
        d = self.client.get("/api/v1/nav").get_json()
        keys = {i["key"] for i in d["items"]}
        self.assertIn("triage", keys)


if __name__ == "__main__":
    unittest.main()
