"""mitre_attack.py — MITRE ATT&CK Enterprise technique mappings for threat findings."""
from __future__ import annotations

# ── Technique registry ─────────────────────────────────────────────────────────
# id → {name, tactic, url}
TECHNIQUES: dict[str, dict] = {
    "T1040":  {"name": "Network Sniffing",                          "tactic": "Credential Access",      "url": "https://attack.mitre.org/techniques/T1040/"},
    "T1046":  {"name": "Network Service Discovery",                 "tactic": "Discovery",              "url": "https://attack.mitre.org/techniques/T1046/"},
    "T1059":  {"name": "Command and Scripting Interpreter",         "tactic": "Execution",              "url": "https://attack.mitre.org/techniques/T1059/"},
    "T1070":  {"name": "Indicator Removal",                         "tactic": "Defense Evasion",        "url": "https://attack.mitre.org/techniques/T1070/"},
    "T1078":  {"name": "Valid Accounts",                            "tactic": "Initial Access",         "url": "https://attack.mitre.org/techniques/T1078/"},
    "T1087":  {"name": "Account Discovery",                         "tactic": "Discovery",              "url": "https://attack.mitre.org/techniques/T1087/"},
    "T1090":  {"name": "Proxy",                                     "tactic": "Command and Control",    "url": "https://attack.mitre.org/techniques/T1090/"},
    "T1098":  {"name": "Account Manipulation",                      "tactic": "Persistence",            "url": "https://attack.mitre.org/techniques/T1098/"},
    "T1110":  {"name": "Brute Force",                               "tactic": "Credential Access",      "url": "https://attack.mitre.org/techniques/T1110/"},
    "T1133":  {"name": "External Remote Services",                  "tactic": "Initial Access",         "url": "https://attack.mitre.org/techniques/T1133/"},
    "T1134":  {"name": "Access Token Manipulation",                 "tactic": "Privilege Escalation",   "url": "https://attack.mitre.org/techniques/T1134/"},
    "T1190":  {"name": "Exploit Public-Facing Application",         "tactic": "Initial Access",         "url": "https://attack.mitre.org/techniques/T1190/"},
    "T1195":  {"name": "Supply Chain Compromise",                   "tactic": "Initial Access",         "url": "https://attack.mitre.org/techniques/T1195/"},
    "T1213":  {"name": "Data from Information Repositories",        "tactic": "Collection",             "url": "https://attack.mitre.org/techniques/T1213/"},
    "T1486":  {"name": "Data Encrypted for Impact",                 "tactic": "Impact",                 "url": "https://attack.mitre.org/techniques/T1486/"},
    "T1491":  {"name": "Defacement",                                "tactic": "Impact",                 "url": "https://attack.mitre.org/techniques/T1491/"},
    "T1498":  {"name": "Network Denial of Service",                 "tactic": "Impact",                 "url": "https://attack.mitre.org/techniques/T1498/"},
    "T1499":  {"name": "Endpoint Denial of Service",                "tactic": "Impact",                 "url": "https://attack.mitre.org/techniques/T1499/"},
    "T1525":  {"name": "Implant Internal Image",                    "tactic": "Persistence",            "url": "https://attack.mitre.org/techniques/T1525/"},
    "T1530":  {"name": "Data from Cloud Storage",                   "tactic": "Collection",             "url": "https://attack.mitre.org/techniques/T1530/"},
    "T1539":  {"name": "Steal Web Session Cookie",                  "tactic": "Credential Access",      "url": "https://attack.mitre.org/techniques/T1539/"},
    "T1548":  {"name": "Abuse Elevation Control Mechanism",         "tactic": "Privilege Escalation",   "url": "https://attack.mitre.org/techniques/T1548/"},
    "T1552":  {"name": "Unsecured Credentials",                     "tactic": "Credential Access",      "url": "https://attack.mitre.org/techniques/T1552/"},
    "T1553":  {"name": "Subvert Trust Controls",                    "tactic": "Defense Evasion",        "url": "https://attack.mitre.org/techniques/T1553/"},
    "T1556":  {"name": "Modify Authentication Process",             "tactic": "Credential Access",      "url": "https://attack.mitre.org/techniques/T1556/"},
    "T1557":  {"name": "Adversary-in-the-Middle",                   "tactic": "Credential Access",      "url": "https://attack.mitre.org/techniques/T1557/"},
    "T1562":  {"name": "Impair Defenses",                           "tactic": "Defense Evasion",        "url": "https://attack.mitre.org/techniques/T1562/"},
    "T1565":  {"name": "Data Manipulation",                         "tactic": "Impact",                 "url": "https://attack.mitre.org/techniques/T1565/"},
    "T1580":  {"name": "Cloud Infrastructure Discovery",            "tactic": "Discovery",              "url": "https://attack.mitre.org/techniques/T1580/"},
    "T1592":  {"name": "Gather Victim Host Information",            "tactic": "Reconnaissance",         "url": "https://attack.mitre.org/techniques/T1592/"},
    "T1601":  {"name": "Modify System Image",                       "tactic": "Defense Evasion",        "url": "https://attack.mitre.org/techniques/T1601/"},
    "T1610":  {"name": "Deploy Container",                          "tactic": "Defense Evasion",        "url": "https://attack.mitre.org/techniques/T1610/"},
    "T1611":  {"name": "Escape to Host",                            "tactic": "Privilege Escalation",   "url": "https://attack.mitre.org/techniques/T1611/"},
    "T1613":  {"name": "Container and Resource Discovery",          "tactic": "Discovery",              "url": "https://attack.mitre.org/techniques/T1613/"},
    "T1649":  {"name": "Steal or Forge Authentication Certificates","tactic": "Credential Access",      "url": "https://attack.mitre.org/techniques/T1649/"},
}

# ── STRIDE → ATT&CK ────────────────────────────────────────────────────────────
STRIDE_ATTACK: dict[str, list[str]] = {
    "S": ["T1078", "T1539", "T1557", "T1110", "T1649"],     # Spoofing
    "T": ["T1565", "T1491", "T1059", "T1190"],               # Tampering
    "R": ["T1070", "T1562"],                                  # Repudiation
    "I": ["T1552", "T1213", "T1040", "T1530"],               # Information Disclosure
    "D": ["T1499", "T1498"],                                  # Denial of Service
    "E": ["T1548", "T1134", "T1098", "T1078"],               # Elevation of Privilege
}

# ── OWASP Web 2021 → ATT&CK ────────────────────────────────────────────────────
OWASP_WEB_ATTACK: dict[str, list[str]] = {
    "A01": ["T1078", "T1087", "T1548", "T1134"],  # Broken Access Control
    "A02": ["T1040", "T1557", "T1552", "T1486"],  # Cryptographic Failures
    "A03": ["T1190", "T1059", "T1565"],            # Injection
    "A04": ["T1499", "T1110"],                     # Insecure Design
    "A05": ["T1133", "T1580", "T1046"],            # Security Misconfiguration
    "A06": ["T1195", "T1553"],                     # Vulnerable Components / Supply Chain
    "A07": ["T1110", "T1078", "T1539", "T1556"],  # Auth Failures
    "A08": ["T1195", "T1553", "T1601"],            # Software & Data Integrity
    "A09": ["T1562", "T1070"],                     # Logging Failures
    "A10": ["T1090", "T1592", "T1580"],            # SSRF
}

# ── OWASP API 2023 → ATT&CK ────────────────────────────────────────────────────
OWASP_API_ATTACK: dict[str, list[str]] = {
    "API1": ["T1087", "T1213", "T1078"],           # BOLA
    "API2": ["T1110", "T1539", "T1552", "T1078"], # Broken Auth
    "API3": ["T1213", "T1552"],                    # Object Property Auth
    "API4": ["T1499", "T1498"],                    # Resource Consumption
    "API5": ["T1548", "T1078"],                    # Function Level Auth
    "API6": ["T1499"],                             # Sensitive Business Flows
    "API7": ["T1090", "T1592", "T1580"],           # SSRF
    "API8": ["T1133", "T1046"],                    # Misconfiguration
    "API9": ["T1087", "T1046"],                    # Improper Inventory
    "API10": ["T1195", "T1565"],                   # Unsafe API Consumption
}

# ── OWASP LLM 2025 → ATT&CK ────────────────────────────────────────────────────
OWASP_LLM_ATTACK: dict[str, list[str]] = {
    "LLM01": ["T1059", "T1190", "T1565"],          # Prompt Injection → Command Execution
    "LLM02": ["T1059", "T1190", "T1491"],          # Insecure Output Handling
    "LLM03": ["T1195", "T1565"],                   # Training Data Poisoning
    "LLM04": ["T1499", "T1498"],                   # Model DoS
    "LLM05": ["T1195", "T1553", "T1525"],          # Supply Chain
    "LLM06": ["T1552", "T1213"],                   # Sensitive Info Disclosure
    "LLM07": ["T1548", "T1059", "T1098"],          # Insecure Plugin Design
    "LLM08": ["T1059", "T1098", "T1548"],          # Excessive Agency
    "LLM09": ["T1565"],                            # Overreliance
    "LLM10": ["T1213", "T1195"],                   # Model Theft
}

# ── Cloud (CSA) → ATT&CK ───────────────────────────────────────────────────────
OWASP_CLOUD_ATTACK: dict[str, list[str]] = {
    "CSA01": ["T1580", "T1530", "T1133"],          # Misconfiguration
    "CSA02": ["T1078", "T1552", "T1098"],          # IAM Failures
    "CSA03": ["T1552", "T1078", "T1090"],          # Insecure Interfaces
    "CSA04": ["T1580", "T1046"],                   # Inadequate Strategy
    "CSA05": ["T1195", "T1525"],                   # Third-Party Resources
    "CSA06": ["T1195", "T1552"],                   # Insecure Dev
    "CSA07": ["T1499", "T1498"],                   # DoS
    "CSA08": ["T1530", "T1213"],                   # Data Exfiltration
    "CSA09": ["T1610", "T1611", "T1613"],          # Serverless / Container Risks
    "CSA10": ["T1070", "T1562"],                   # IR Gaps
    "CSA11": ["T1530", "T1486"],                   # Insufficient Encryption
}

# ── Mobile → ATT&CK ────────────────────────────────────────────────────────────
OWASP_MOBILE_ATTACK: dict[str, list[str]] = {
    "M1":  ["T1552", "T1078"],                     # Improper Credential Usage
    "M2":  ["T1195"],                              # Supply Chain
    "M3":  ["T1557", "T1078"],                     # Insecure Auth
    "M4":  ["T1059", "T1190"],                     # Input Validation
    "M5":  ["T1040", "T1557"],                     # Insecure Communication
    "M6":  ["T1213"],                              # Privacy Controls
    "M7":  ["T1553"],                              # Binary Protections
    "M8":  ["T1133"],                              # Misconfiguration
    "M9":  ["T1552", "T1213"],                     # Data Storage
    "M10": ["T1552"],                              # Insufficient Crypto
    "K01": ["T1611", "T1548"],                     # K8s Workload Config
    "K03": ["T1548", "T1098"],                     # K8s RBAC
    "K07": ["T1046", "T1090"],                     # K8s Network Segmentation
    "K08": ["T1552"],                              # K8s Secrets
}

# ── Master lookup ──────────────────────────────────────────────────────────────
_ALL_MAPS: dict[str, dict[str, list[str]]] = {
    "web":    OWASP_WEB_ATTACK,
    "api":    OWASP_API_ATTACK,
    "llm":    OWASP_LLM_ATTACK,
    "cloud":  OWASP_CLOUD_ATTACK,
    "mobile": OWASP_MOBILE_ATTACK,
    "stride": STRIDE_ATTACK,
}


def _normalize_ruleset(ruleset: str) -> str:
    hint = (ruleset or "").lower().strip()
    if "llm" in hint or "ai" in hint:
        return "llm"
    if "api" in hint:
        return "api"
    if "cloud" in hint or "csa" in hint:
        return "cloud"
    if "mobile" in hint or "kubernetes" in hint or "k8s" in hint:
        return "mobile"
    if "stride" in hint:
        return "stride"
    if "web" in hint or "owasp" in hint:
        return "web"
    return hint


def _normalize_category(category: str, ruleset: str = "") -> tuple[str, str]:
    # Category ids coming straight from the OWASP_* tables (owasp.py,
    # offline_patterns.py's _framework_report) carry a display suffix like
    # "A01:2021" — strip it so the lookup hits the bare-key ATT&CK tables.
    cat = category.upper().strip().split(":", 1)[0]
    hint = _normalize_ruleset(ruleset)

    if cat.startswith("STRIDE-"):
        tail = cat.removeprefix("STRIDE-").split("-", 1)[0]
        if tail in STRIDE_ATTACK:
            return tail, "stride"
    if cat.startswith("AI-LLM"):
        return cat.removeprefix("AI-"), "llm"
    if cat.startswith("LLM-"):
        return cat.removeprefix("LLM-"), "llm"
    if cat.startswith("API-API"):
        return cat.removeprefix("API-"), "api"
    if cat.startswith("WEB-A"):
        return cat.removeprefix("WEB-"), "web"
    if cat.startswith("CLOUD-CSA"):
        return cat.removeprefix("CLOUD-"), "cloud"
    if cat.startswith("MOBILE-"):
        return cat.removeprefix("MOBILE-"), "mobile"

    if not hint:
        if cat.startswith("LLM"):   hint = "llm"
        elif cat.startswith("API"): hint = "api"
        elif cat.startswith("CSA"): hint = "cloud"
        elif cat.startswith("M") and not cat.startswith("MI"): hint = "mobile"
        elif cat.startswith("K"):   hint = "mobile"
        elif cat in ("S","T","R","I","D","E"): hint = "stride"
        else:                       hint = "web"

    return cat, hint


def _dedupe_techniques(techniques: list[dict]) -> list[dict]:
    seen: set[str] = set()
    result: list[dict] = []
    for technique in techniques:
        tid = technique.get("id", "")
        if not tid or tid in seen:
            continue
        seen.add(tid)
        result.append(technique)
    return result


def get_techniques(category: str, ruleset: str = "") -> list[dict]:
    """
    Return list of ATT&CK technique dicts for a given category ID.
    category: e.g. "A01", "API3", "LLM01", "S", "T"
    ruleset: hint ("web","api","llm","cloud","mobile","stride") to pick the right map
    """
    cat, ruleset = _normalize_category(category, ruleset)

    ids = _ALL_MAPS.get(ruleset, {}).get(cat, [])
    return [
        {"id": tid, **TECHNIQUES[tid]}
        for tid in ids
        if tid in TECHNIQUES
    ]


def enrich_findings(findings: list[dict]) -> list[dict]:
    """Add attack_techniques list to each finding dict (in-place)."""
    for f in findings:
        cat = f.get("category", "")
        ruleset = f.get("ruleset", "")
        f["attack_techniques"] = get_techniques(cat, ruleset)
    return findings


def enrich_categories(categories: list[dict]) -> list[dict]:
    """Add attack_techniques to analyzer output category dicts (in-place)."""
    for c in categories:
        cat_id = c.get("id", "")
        ruleset = c.get("ruleset", "") or c.get("source_method", "") or c.get("methodology", "")
        techniques = get_techniques(cat_id, ruleset)
        text = " ".join([
            str(c.get("id", "")),
            str(c.get("name", "")),
            str(c.get("description", "")),
            str(c.get("notes", "")),
            " ".join(
                " ".join(str(t.get(field, "")) for field in ("name", "description", "attack_vector", "impact"))
                for t in c.get("threats", [])
                if isinstance(t, dict)
            ),
        ]).lower()
        contextual_categories: list[tuple[str, str]] = []
        if any(term in text for term in ("prompt injection", "context tampering", "jailbreak")):
            contextual_categories.append(("LLM01", "llm"))
        if any(term in text for term in ("context leakage", "system prompt", "sensitive information", "data exfiltration")):
            contextual_categories.append(("LLM06", "llm"))
        if any(term in text for term in ("model denial", "token exhaustion", "agent loop")):
            contextual_categories.append(("LLM04", "llm"))
        if any(term in text for term in ("tool abuse", "plugin", "excessive agency", "unsafe agent")):
            contextual_categories.append(("LLM08", "llm"))

        for contextual_id, contextual_ruleset in contextual_categories:
            techniques.extend(get_techniques(contextual_id, contextual_ruleset))
        c["attack_techniques"] = _dedupe_techniques(techniques)
    return categories
