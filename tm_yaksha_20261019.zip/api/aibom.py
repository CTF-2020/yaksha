"""AI-BOM API + dashboard page.

Routes (CSRF + optional TM_API_KEY apply via the app's global before_request):
  GET  /api/v1/aibom                      scanner status / signature-catalog info
  GET  /api/v1/aibom/repos               registered repos (shared with the SAST broker)
  POST /api/v1/aibom/repos/<id>/scan     trigger an inventory scan -> {job_id}
  GET  /api/v1/aibom/jobs                list scan jobs
  GET  /api/v1/aibom/jobs/<id>           poll one job
  GET  /api/v1/aibom/jobs/<id>/events    SSE progress stream
  GET  /api/v1/aibom/jobs/<id>/bom       download the CycloneDX 1.6 AI-BOM document
  GET  /api/v1/aibom/inventory           org-wide rollup (latest scan per repo)

  GET  /aibom                             dashboard UI (separate, un-prefixed bp)

Scans only ever run against repos already registered with the SAST broker, so
the AI-BOM page can never coerce the server into reading an arbitrary path.
"""
from __future__ import annotations

import json
import time

from flask import Blueprint, Response, jsonify, render_template, request

import app as tm_app
from aibom import config, get_service
from aibom import signatures as sig
from broker import config as broker_config

bp = Blueprint("aibom_api", __name__, url_prefix="/api/v1/aibom")
page_bp = Blueprint("aibom_page", __name__)


@bp.get("")
def status():
    return jsonify({
        "success": True,
        "engine": "builtin",
        "engine_available": True,
        "repos": len(broker_config.load_repos()),
        "signatures": {
            "py_packages": len(sig.PY_PACKAGES),
            "npm_packages": len(sig.NPM_PACKAGES) + len(sig.NPM_PREFIXES),
            "go_modules": len(sig.GO_MODULES),
            "endpoints": len(sig.ENDPOINTS),
            "env_keys": len(sig.ENV_KEYS),
            "key_formats": len(sig.KEY_PATTERNS),
            "risk_rules": len(sig.RULES),
        },
        "budget": {
            "scan_timeout": config.SCAN_TIMEOUT,
            "max_files": config.MAX_FILES,
            "max_file_bytes": config.MAX_FILE_BYTES,
        },
    })


# ── Repos (read-only view of the broker registry) ─────────────────────────────
@bp.get("/repos")
def list_repos():
    repos = [broker_config.redact_repo(r) for r in broker_config.load_repos()]
    return jsonify({"success": True, "repos": repos,
                    "register_at": "/broker"})


@bp.post("/repos/<repo_id>/scan")
@tm_app.limiter.limit("10 per minute")
def scan_repo(repo_id: str):
    if not broker_config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "invalid repo id"}), 400
    repo = broker_config.get_repo(repo_id)
    if not repo:
        return jsonify({"success": False,
                        "error": "repo not found — register it on /broker"}), 404
    job_id = get_service().submit_scan(repo)
    return jsonify({"success": True, "job_id": job_id}), 202


# ── Jobs ──────────────────────────────────────────────────────────────────────
@bp.get("/jobs")
def list_jobs():
    return jsonify({"success": True, "jobs": get_service().list_jobs()})


@bp.get("/jobs/<job_id>")
def get_job(job_id: str):
    job = get_service().get_job(job_id)
    if not job:
        return jsonify({"success": False, "error": "job not found"}), 404
    return jsonify({"success": True, "job": job})


@bp.get("/jobs/<job_id>/events")
def job_events(job_id: str):
    service = get_service()
    if not service.get_job(job_id):
        return jsonify({"success": False, "error": "job not found"}), 404

    def stream():
        deadline = time.time() + config.SCAN_TIMEOUT + 30
        last = None
        while time.time() < deadline:
            job = service.get_job(job_id)
            if not job:
                break
            snapshot = json.dumps({"status": job["status"], "progress": job.get("progress"),
                                   "report_id": job.get("report_id"),
                                   "bom_available": job.get("bom_available"),
                                   "stats": job.get("stats"),
                                   "error": job.get("error"), "log": job.get("log", [])})
            if snapshot != last:
                yield f"data: {snapshot}\n\n"
                last = snapshot
            if job["status"] in ("done", "error"):
                break
            time.sleep(1)
        yield "event: end\ndata: {}\n\n"

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@bp.get("/jobs/<job_id>/bom")
def download_bom(job_id: str):
    if not config.is_safe_job_id(job_id):
        return jsonify({"success": False, "error": "invalid job id"}), 400
    bom = config.load_bom(job_id)
    if bom is None:
        return jsonify({"success": False, "error": "no BOM for this job"}), 404
    payload = json.dumps(bom, indent=2)
    return Response(payload, mimetype="application/json", headers={
        "Content-Disposition": f'attachment; filename="aibom_{job_id}.cdx.json"'})


# ── Org-wide inventory ────────────────────────────────────────────────────────
@bp.get("/inventory")
def org_inventory():
    entries = config.load_inventory()
    providers: dict[str, int] = {}
    models: set[str] = set()
    flag_totals = {"provider_apis": 0, "local_models": 0, "rag": 0,
                   "agents": 0, "mcp": 0}
    for e in entries:
        for p in e.get("providers", []):
            providers[p] = providers.get(p, 0) + 1
        models.update(e.get("models", []))
        for k in flag_totals:
            if e.get("flags", {}).get(k):
                flag_totals[k] += 1
    return jsonify({
        "success": True,
        "repos": entries,
        "totals": {
            "repos_scanned": len(entries),
            "repos_with_ai": sum(1 for e in entries if e.get("ai_detected")),
            "providers": dict(sorted(providers.items(), key=lambda kv: -kv[1])),
            "distinct_models": sorted(models),
            "flags": flag_totals,
        },
    })


# ── Dashboard page ────────────────────────────────────────────────────────────
@page_bp.get("/aibom")
def aibom_page():
    from app import _CSRF_TOKEN
    return render_template("aibom.html", csrf_token=_CSRF_TOKEN)
