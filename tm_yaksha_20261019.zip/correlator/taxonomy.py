"""Cross-tool weakness taxonomy and locus normalization.

Three analyzers describe the same bug three different ways: a SAST engine calls
it ``CWE-89``, a DAST engine calls it ``SQL Injection`` at ``/search?q=``, and the
threat model calls it ``WEB-A03 Injection``. To correlate them we resolve every
finding to a single **weakness family** — a canonical class keyed by the CWEs,
OWASP categories and keywords that all denote the same underlying flaw — and to a
set of **locus tokens** describing where it lives (a file, a URL, a component).

Resolution is deliberately layered and conservative: an explicit CWE match beats
an OWASP-category match beats a keyword match, and anything unresolved becomes its
own singleton family rather than being force-merged into a wrong bucket.
"""
from __future__ import annotations

import re

# ── Weakness families ─────────────────────────────────────────────────────────
# Each family lists the CWE ids, OWASP category ids and title keywords that map
# to it. Keywords are matched as whole-ish substrings against a lowered blob of
# the finding's title/name/notes. Order matters only for readability; matching
# uses the most specific signal available (CWE first).
_FAMILIES: list[dict] = [
    {"slug": "sql-injection", "title": "SQL Injection",
     "cwes": {"CWE-89"}, "owasp": {"WEB-A03", "API-API8"},
     "keywords": ["sql injection", "sqli", "sql statement"], "stride": ("Tampering",)},
    {"slug": "command-injection", "title": "OS Command Injection",
     "cwes": {"CWE-77", "CWE-78"}, "owasp": {"WEB-A03"},
     "keywords": ["command injection", "os command", "shell command", "shell=true", "subprocess"],
     "stride": ("Tampering", "Elevation of Privilege")},
    {"slug": "code-injection", "title": "Code Injection / eval",
     "cwes": {"CWE-94", "CWE-95"}, "owasp": {"WEB-A03"},
     "keywords": ["code injection", "eval(", "exec(", "arbitrary code"],
     "stride": ("Tampering", "Elevation of Privilege")},
    {"slug": "template-injection", "title": "Server-Side Template Injection",
     "cwes": {"CWE-1336"}, "owasp": {"WEB-A03"},
     "keywords": ["template injection", "ssti"], "stride": ("Tampering",)},
    {"slug": "xss", "title": "Cross-Site Scripting (XSS)",
     "cwes": {"CWE-79", "CWE-80"}, "owasp": {"WEB-A03"},
     "keywords": ["xss", "cross-site scripting", "cross site scripting",
                  "reflected script", "stored script", "html injection"],
     "stride": ("Tampering",)},
    {"slug": "path-traversal", "title": "Path Traversal",
     "cwes": {"CWE-22", "CWE-23", "CWE-36"}, "owasp": {"WEB-A01"},
     "keywords": ["path traversal", "directory traversal", "local file inclusion", "lfi", "../"],
     "stride": ("Information Disclosure",)},
    {"slug": "ssrf", "title": "Server-Side Request Forgery (SSRF)",
     "cwes": {"CWE-918"}, "owasp": {"WEB-A10", "API-API7"},
     "keywords": ["ssrf", "server-side request forgery", "server side request forgery"],
     "stride": ("Information Disclosure", "Spoofing")},
    {"slug": "open-redirect", "title": "Open Redirect",
     "cwes": {"CWE-601"}, "owasp": {"WEB-A01"},
     "keywords": ["open redirect", "unvalidated redirect"], "stride": ("Spoofing",)},
    {"slug": "deserialization", "title": "Insecure Deserialization",
     "cwes": {"CWE-502"}, "owasp": {"WEB-A08"},
     "keywords": ["deserial", "pickle", "yaml.load", "unmarshal", "objectinputstream"],
     "stride": ("Tampering", "Elevation of Privilege")},
    {"slug": "xxe", "title": "XML External Entity (XXE)",
     "cwes": {"CWE-611"}, "owasp": {"WEB-A05"},
     "keywords": ["xxe", "xml external entity", "external entity"],
     "stride": ("Information Disclosure",)},
    {"slug": "ldap-injection", "title": "LDAP Injection",
     "cwes": {"CWE-90"}, "owasp": {"WEB-A03"},
     "keywords": ["ldap injection"], "stride": ("Tampering",)},
    {"slug": "xpath-injection", "title": "XPath Injection",
     "cwes": {"CWE-643"}, "owasp": {"WEB-A03"},
     "keywords": ["xpath injection"], "stride": ("Tampering",)},
    {"slug": "broken-access-control", "title": "Broken Access Control / IDOR",
     "cwes": {"CWE-284", "CWE-285", "CWE-639", "CWE-862", "CWE-863", "CWE-306"},
     "owasp": {"WEB-A01", "API-API1", "API-API5", "API-API3"},
     "keywords": ["access control", "idor", "insecure direct object", "authorization",
                  "privilege escalation", "missing function level", "forced browsing"],
     "stride": ("Elevation of Privilege",)},
    {"slug": "broken-auth", "title": "Broken Authentication",
     "cwes": {"CWE-287", "CWE-798", "CWE-522", "CWE-384"},
     "owasp": {"WEB-A07", "API-API2"},
     "keywords": ["authentication", "hardcoded credential", "hard-coded credential",
                  "weak password", "session fixation", "credential stuffing", "brute force"],
     "stride": ("Spoofing",)},
    {"slug": "crypto-failure", "title": "Cryptographic Failure",
     "cwes": {"CWE-327", "CWE-328", "CWE-326", "CWE-330", "CWE-338", "CWE-916"},
     "owasp": {"WEB-A02"},
     "keywords": ["weak crypto", "weak hash", "md5", "sha1", "insecure random",
                  "cleartext", "ecb mode", "broken cipher", "cryptographic failure"],
     "stride": ("Information Disclosure",)},
    {"slug": "sensitive-data-exposure", "title": "Sensitive Data Exposure",
     "cwes": {"CWE-200", "CWE-201", "CWE-209", "CWE-312", "CWE-532", "CWE-538"},
     "owasp": {"WEB-A02", "API-API3"},
     "keywords": ["sensitive data", "information disclosure", "secret in log",
                  "secret leak", "data exposure", "verbose error", "stack trace"],
     "stride": ("Information Disclosure",)},
    {"slug": "security-misconfig", "title": "Security Misconfiguration",
     "cwes": {"CWE-16", "CWE-756", "CWE-1032", "CWE-942"},
     "owasp": {"WEB-A05", "API-API8"},
     "keywords": ["misconfiguration", "security header", "missing header",
                  "cors", "debug enabled", "directory listing", "default credential",
                  "csp", "hsts", "cookie flag", "x-frame"],
     "stride": ("Information Disclosure",)},
    {"slug": "vulnerable-components", "title": "Vulnerable / Outdated Components",
     "cwes": {"CWE-1104", "CWE-937", "CWE-1035"}, "owasp": {"WEB-A06"},
     "keywords": ["outdated", "vulnerable dependency", "vulnerable component",
                  "known cve", "end of life", "unpatched"],
     "stride": ("Tampering",)},
    {"slug": "integrity-failure", "title": "Software & Data Integrity Failure",
     "cwes": {"CWE-345", "CWE-353", "CWE-494", "CWE-829"}, "owasp": {"WEB-A08"},
     "keywords": ["integrity", "unsigned", "insecure update", "untrusted source"],
     "stride": ("Tampering",)},
    {"slug": "csrf", "title": "Cross-Site Request Forgery (CSRF)",
     "cwes": {"CWE-352"}, "owasp": {"WEB-A01"},
     "keywords": ["csrf", "cross-site request forgery", "cross site request forgery"],
     "stride": ("Spoofing",)},
    {"slug": "logging-monitoring", "title": "Logging & Monitoring Failure",
     "cwes": {"CWE-778", "CWE-223"}, "owasp": {"WEB-A09"},
     "keywords": ["insufficient logging", "logging failure", "logging and monitoring",
                  "monitoring failure", "no audit", "missing monitoring"],
     "stride": ("Repudiation",)},
    {"slug": "prompt-injection", "title": "LLM Prompt Injection",
     "cwes": {"CWE-1427"}, "owasp": {"AI-LLM01", "LLM-LLM01"},
     "keywords": ["prompt injection", "jailbreak", "system prompt leak"],
     "stride": ("Tampering",)},
    {"slug": "insecure-output", "title": "LLM Insecure Output Handling",
     "cwes": set(), "owasp": {"AI-LLM02", "LLM-LLM02"},
     "keywords": ["insecure output handling"], "stride": ("Tampering",)},
    {"slug": "excessive-agency", "title": "LLM Excessive Agency",
     "cwes": set(), "owasp": {"AI-LLM08", "LLM-LLM06"},
     "keywords": ["excessive agency", "excessive permission"],
     "stride": ("Elevation of Privilege",)},
]

_FAMILY_BY_SLUG = {f["slug"]: f for f in _FAMILIES}
# OWASP category -> concrete family slugs living under it, in declaration order.
# A category is an umbrella (A03 "Injection" spans SQLi, command, XSS, …); we never
# collapse it to one arbitrary child — the engine corroborates it against all of
# them. Kept as a list (not a first-wins index) precisely so nothing is dropped.
_OWASP_CATEGORY_FAMILIES: dict[str, list[str]] = {}
for _f in _FAMILIES:
    for _o in _f["owasp"]:
        _OWASP_CATEGORY_FAMILIES.setdefault(_o, []).append(_f["slug"])

_CWE_RE = re.compile(r"CWE[-_ ]?(\d+)", re.I)
# Match "A03", "A3:2021", "A3-2017" but not a bare "A3" in prose (see extract_owasp).
_OWASP_WEB_RE = re.compile(r"\bA(\d{1,2})(:\d{4}|-\d{4})?\b", re.I)
_OWASP_ID_RE = re.compile(r"\b((?:WEB|API|LLM|AI|MOB|K8S)[-_][A-Z0-9]+)\b", re.I)

_STOPWORDS = {
    "api", "www", "src", "app", "com", "net", "org", "http", "https", "index",
    "main", "the", "and", "for", "with", "src", "lib", "core", "test", "tests",
    "get", "post", "put", "page", "pages", "html", "json", "php", "aspx", "jsp",
    "controller", "service", "services", "handler", "handlers", "route", "routes",
    "endpoint", "server", "client", "public", "static", "assets", "default",
}
_EXT_RE = re.compile(r"\.[a-z0-9]{1,5}$", re.I)
_TOKEN_RE = re.compile(r"[a-z0-9]+")


# ── CWE / OWASP extraction ────────────────────────────────────────────────────
def extract_cwes(*blobs: str) -> frozenset:
    """Pull every ``CWE-<n>`` reference out of arbitrary text fields."""
    found = set()
    for blob in blobs:
        if not blob:
            continue
        for m in _CWE_RE.finditer(str(blob)):
            found.add(f"CWE-{int(m.group(1))}")
    return frozenset(found)


def extract_owasp(category_id: str, *blobs: str) -> str:
    """Best-effort canonical OWASP id for a category.

    Prefers an explicit ``WEB-/API-/LLM-`` style id (the shape the design
    methodologies emit), then falls back to a bare ``A0x`` web reference.
    """
    cid = (category_id or "").strip().upper()
    m = _OWASP_ID_RE.match(cid) or _OWASP_ID_RE.search(cid)
    if m:
        return _canon_owasp(m.group(1).upper())
    for blob in (category_id, *blobs):
        if not blob:
            continue
        m = _OWASP_ID_RE.search(str(blob).upper())
        if m:
            return _canon_owasp(m.group(1).upper())
    for blob in (category_id, *blobs):
        if not blob:
            continue
        for m in _OWASP_WEB_RE.finditer(str(blob)):
            num, suffix = m.group(1), m.group(2)
            # Trust only an explicit "A03" (two-digit id) or a year-qualified
            # "A3:2021"; a bare "A3" in free text is too noisy to treat as an id.
            if suffix or len(num) == 2:
                return f"WEB-A{int(num):02d}"
    return ""


def _canon_owasp(raw: str) -> str:
    """Normalize id spellings (WEB_A03 -> WEB-A03, A3 -> A03)."""
    raw = raw.replace("_", "-")
    m = re.match(r"(WEB|API|LLM|AI|MOB|K8S)-([A-Z]*?)(\d+)$", raw)
    if not m:
        return raw
    fam, alpha, num = m.groups()
    if fam == "WEB":
        return f"WEB-A{int(num):02d}"
    return f"{fam}-{alpha}{num}" if alpha else f"{fam}-{num}"


# ── Family resolution ─────────────────────────────────────────────────────────
def resolve_family(title: str, cwes: frozenset, owasp: str,
                   notes: str = "") -> tuple[str, str]:
    """Resolve a finding to (family_slug, family_title).

    Layered precedence: an explicit CWE (most specific), then a concrete keyword
    in the title/notes, then the OWASP *category* as an umbrella bucket, then a
    slugged title. CWE and keyword matching both walk ``_FAMILIES`` in declaration
    order, so the result is deterministic regardless of set-iteration order — a
    finding may carry several CWEs, and the first family in declaration order that
    shares one wins on every run (hash-seed independent).

    An OWASP-only finding stays an ``owasp:<id>`` category bucket rather than being
    forced into one arbitrary child family: a category like A03 spans many concrete
    weaknesses, so the engine corroborates it against every child that has evidence
    instead of guessing a single one here.
    """
    blob = f"{title} {notes}".lower()

    for fam in _FAMILIES:
        if cwes & fam["cwes"]:
            return fam["slug"], fam["title"]

    for fam in _FAMILIES:
        for kw in fam["keywords"]:
            if kw in blob:
                return fam["slug"], fam["title"]

    # Cluster on the OWASP category (umbrella) if we have one, else on a slugged
    # title so identical unknown findings from two tools still line up.
    if owasp:
        return f"owasp:{owasp}", (title.strip() or owasp)
    slug = re.sub(r"[^a-z0-9]+", "-", (title or "finding").lower()).strip("-") or "finding"
    return f"title:{slug}", (title or "Security Finding")


def families_for_owasp(owasp: str) -> list[str]:
    """Concrete family slugs that live under an OWASP category id (umbrella)."""
    return list(_OWASP_CATEGORY_FAMILIES.get(owasp, ()))


def family_stride(slug: str) -> tuple:
    fam = _FAMILY_BY_SLUG.get(slug)
    return tuple(fam["stride"]) if fam else ()


# ── Locus normalization ───────────────────────────────────────────────────────
def locus_tokens(*locations: str) -> frozenset:
    """Reduce file paths, URLs and component names to comparable word tokens.

    ``search/users_controller.py:42`` and ``/api/users/search?q=`` both yield
    ``{"users", "search"}`` so a static hit and a runtime hit at the same feature
    line up even though their raw location strings share no substring.
    """
    tokens = set()
    for loc in locations:
        if not loc:
            continue
        text = str(loc)
        # drop a trailing :line, query string is kept (param names are signal)
        text = re.sub(r":\d+$", "", text)
        text = text.replace("?", " ").replace("&", " ").replace("=", " ")
        for part in re.split(r"[\s/\\]+", text):
            part = _EXT_RE.sub("", part)
            for tok in _TOKEN_RE.findall(part.lower()):
                if len(tok) >= 3 and tok not in _STOPWORDS and not tok.isdigit():
                    tokens.add(tok)
    return frozenset(tokens)


def locus_related(a: frozenset, b: frozenset, threshold: float = 0.34) -> bool:
    """True when two loci plausibly describe the same place.

    Empty tokens on either side means "location unknown" (common for design-level
    findings), so we defer that decision to the family match and return True.
    """
    if not a or not b:
        return True
    inter = a & b
    if not inter:
        return False
    union = a | b
    jaccard = len(inter) / len(union)
    # A single strong shared token (e.g. a feature name) is enough; otherwise
    # require meaningful overlap.
    return jaccard >= threshold or len(inter) >= 2
