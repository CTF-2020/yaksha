"""Python interface for the local system-design skill bundle.

The module reads the generated skill files in this directory and exposes a small
API plus a CLI for browsing, searching, and planning study from the README.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import textwrap
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Sequence


HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9+.-]*")
SKIP_TOPICS = {"system design", "table of contents"}


@dataclass(frozen=True)
class MarkdownSection:
    """A markdown heading and the content that belongs to it."""

    title: str
    level: int
    body: str
    line_start: int
    line_end: int


@dataclass(frozen=True)
class SearchResult:
    title: str
    score: int
    line_start: int
    snippet: str


@dataclass(frozen=True)
class StudyDay:
    label: str
    topics: list[str]


@dataclass(frozen=True)
class Flashcard:
    term: str
    prompt: str
    answer: str


@dataclass(frozen=True)
class QuizQuestion:
    question: str
    answer: str
    source: str


class SystemDesignSkill:
    """Load and query the system-design skill generated from the repository."""

    def __init__(
        self,
        root: Path,
        metadata: dict[str, str],
        readme_text: str,
        issues_text: str = "",
        file_structure_text: str = "",
    ) -> None:
        self.root = root
        self.metadata = metadata
        self.readme_text = readme_text
        self.issues_text = issues_text
        self.file_structure_text = file_structure_text
        self._sections = parse_markdown_sections(readme_text)

    @classmethod
    def from_directory(cls, directory: str | Path) -> "SystemDesignSkill":
        root = Path(directory).resolve()
        if not root.exists():
            raise FileNotFoundError(f"Skill directory does not exist: {root}")

        skill_text = read_text(root / "SKILL.md")
        readme_text = read_text(root / "README.md")
        issues_text = read_text(root / "issues.md", required=False)
        file_structure_text = read_text(root / "file_structure.md", required=False)
        return cls(
            root=root,
            metadata=parse_frontmatter(skill_text),
            readme_text=readme_text,
            issues_text=issues_text,
            file_structure_text=file_structure_text,
        )

    @property
    def title(self) -> str:
        for section in self._sections:
            if section.level == 1:
                return section.title
        return self.metadata.get("name", self.root.name)

    def list_topics(self) -> list[str]:
        topics = []
        for section in self._sections:
            normalized = normalize_title(section.title)
            if section.level == 1 and normalized not in SKIP_TOPICS:
                topics.append(section.title)
        return topics

    def get_topic(self, title: str) -> MarkdownSection:
        normalized = normalize_title(title)
        for section in self._sections:
            if normalize_title(section.title) == normalized:
                return section
        suggestions = suggest_titles(title, [section.title for section in self._sections])
        hint = f" Did you mean: {', '.join(suggestions)}?" if suggestions else ""
        raise LookupError(f"Topic not found: {title}.{hint}")

    def search(self, query: str, limit: int = 5) -> list[SearchResult]:
        query_words = tokenize(query)
        if not query_words:
            return []

        results = []
        for section in self._sections:
            score = score_section(section, query_words)
            if score > 0:
                results.append(
                    SearchResult(
                        title=section.title,
                        score=score,
                        line_start=section.line_start,
                        snippet=make_snippet(section.body, query_words),
                    )
                )

        results.sort(key=lambda result: (-result.score, result.line_start, result.title))
        return results[: max(limit, 0)]

    def study_plan(self, days: int = 7, focus: str = "all") -> list[StudyDay]:
        if days < 1:
            raise ValueError("days must be at least 1")

        topics = topics_for_focus(self.list_topics(), focus)
        if not topics:
            topics = self.list_topics()
        chunks = chunk_evenly(topics, days)
        return [StudyDay(label=f"Day {index + 1}", topics=chunk) for index, chunk in enumerate(chunks)]

    def summarize_topic(self, title: str, sentences: int = 3) -> str:
        if sentences < 1:
            raise ValueError("sentences must be at least 1")

        section = self.get_topic(title)
        summary = first_sentences(markdown_to_text(section.body), sentences)
        if summary:
            return summary

        child_summaries = [
            first_sentences(markdown_to_text(child.body), 1)
            for child in self._subsections(section)
            if child.body.strip()
        ]
        return " ".join(part for part in child_summaries[:sentences] if part)

    def topic_outline(self, title: str) -> list[dict[str, int | str]]:
        section = self.get_topic(title)
        return [
            {
                "title": child.title,
                "level": child.level,
                "line_start": child.line_start,
                "line_end": child.line_end,
            }
            for child in self._subsections(section)
        ]

    def flashcards(self, title: str, limit: int = 10) -> list[Flashcard]:
        if limit < 1:
            return []

        section = self.get_topic(title)
        source_sections = self._subsections(section) or [section]
        cards = []
        for child in source_sections:
            answer = first_sentences(markdown_to_text(child.body), 2)
            if not answer:
                continue
            cards.append(
                Flashcard(
                    term=child.title,
                    prompt=f"What should you know about {child.title}?",
                    answer=answer,
                )
            )
            if len(cards) >= limit:
                break
        return cards

    def quiz(self, title: str, count: int = 5) -> list[QuizQuestion]:
        if count < 1:
            return []

        cards = self.flashcards(title, limit=count)
        return [
            QuizQuestion(
                question=f"How would you explain {card.term} in system design?",
                answer=card.answer,
                source=card.term,
            )
            for card in cards
        ]

    def issues(self) -> list[dict[str, str]]:
        issue_re = re.compile(r"^###\s+#(?P<number>\d+):\s+(?P<title>.+)$")
        labels_re = re.compile(r"^\*\*Labels:\*\*\s+(?P<labels>.*?)\s+\|")
        status = "unknown"
        issues: list[dict[str, str]] = []

        for line in self.issues_text.splitlines():
            if line.startswith("## Open Issues"):
                status = "open"
                continue
            if line.startswith("## Recently Closed Issues"):
                status = "closed"
                continue
            match = issue_re.match(line)
            if match:
                issues.append(
                    {
                        "number": match.group("number"),
                        "title": match.group("title"),
                        "status": status,
                        "labels": "",
                    }
                )
                continue
            label_match = labels_re.match(line)
            if label_match and issues:
                issues[-1]["labels"] = label_match.group("labels")

        return issues

    def file_structure(self, limit: int | None = None) -> list[str]:
        lines = []
        in_code_block = False
        for line in self.file_structure_text.splitlines():
            if line.strip() == "```":
                in_code_block = not in_code_block
                continue
            if in_code_block and line.strip():
                lines.append(line)
        return lines[:limit] if limit else lines

    def _subsections(self, section: MarkdownSection) -> list[MarkdownSection]:
        return [
            child
            for child in self._sections
            if child.level > section.level
            and child.line_start > section.line_start
            and child.line_end <= section.line_end
        ]

    def to_dict(self) -> dict[str, object]:
        return {
            "metadata": self.metadata,
            "title": self.title,
            "topics": self.list_topics(),
            "issues": self.issues(),
            "file_structure": self.file_structure(),
        }


def read_text(path: Path, required: bool = True) -> str:
    if not path.exists():
        if required:
            raise FileNotFoundError(f"Required skill file is missing: {path}")
        return ""
    return path.read_text(encoding="utf-8-sig", errors="replace")


def parse_frontmatter(text: str) -> dict[str, str]:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}

    metadata: dict[str, str] = {}
    for line in lines[1:]:
        if line.strip() == "---":
            break
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        metadata[key.strip()] = value.strip()
    return metadata


def parse_markdown_sections(text: str) -> list[MarkdownSection]:
    lines = text.splitlines()
    headings: list[tuple[int, int, str]] = []
    for index, line in enumerate(lines):
        match = HEADING_RE.match(line)
        if match:
            headings.append((index, len(match.group(1)), match.group(2).strip()))

    sections = []
    for position, (start_index, level, title) in enumerate(headings):
        end_index = len(lines)
        for next_start, next_level, _ in headings[position + 1 :]:
            if next_level <= level:
                end_index = next_start
                break

        body_lines = lines[start_index + 1 : end_index]
        sections.append(
            MarkdownSection(
                title=title,
                level=level,
                body="\n".join(body_lines).strip(),
                line_start=start_index + 1,
                line_end=end_index,
            )
        )
    return sections


def normalize_title(title: str) -> str:
    return re.sub(r"\s+", " ", title.casefold().strip())


def tokenize(text: str) -> list[str]:
    return [word.casefold() for word in WORD_RE.findall(text)]


def score_section(section: MarkdownSection, query_words: Sequence[str]) -> int:
    title_words = tokenize(section.title)
    body_words = tokenize(section.body)
    title_counts = {word: title_words.count(word) for word in query_words}
    body_counts = {word: body_words.count(word) for word in query_words}

    score = 0
    for word in query_words:
        score += title_counts[word] * 8
        score += min(body_counts[word], 8)

    phrase = " ".join(query_words)
    if phrase and phrase in normalize_title(section.title):
        score += 20
    if phrase and phrase in normalize_title(section.body):
        score += 10
    if section.level == 1:
        score += 2
    return score


def make_snippet(body: str, query_words: Sequence[str], width: int = 220) -> str:
    compact = re.sub(r"\s+", " ", body).strip()
    if not compact:
        return ""

    lower = compact.casefold()
    first_hit = min((lower.find(word) for word in query_words if lower.find(word) >= 0), default=0)
    start = max(first_hit - width // 3, 0)
    snippet = compact[start : start + width]
    if start > 0:
        snippet = "..." + snippet.lstrip()
    if start + width < len(compact):
        snippet = snippet.rstrip() + "..."
    return snippet


def markdown_to_text(markdown: str) -> str:
    text = re.sub(r"```.*?```", " ", markdown, flags=re.DOTALL)
    text = re.sub(r"!\[[^\]]*]\([^)]*\)", " ", text)
    text = re.sub(r"\[([^\]]+)]\([^)]*\)", r"\1", text)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"[*_>#|]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def first_sentences(text: str, count: int) -> str:
    if not text:
        return ""

    parts = re.split(r"(?<=[.!?])\s+", text)
    selected = [part.strip() for part in parts if part.strip()][:count]
    return " ".join(selected)


def suggest_titles(query: str, titles: Iterable[str], limit: int = 3) -> list[str]:
    query_words = set(tokenize(query))
    scored = []
    for title in titles:
        title_words = set(tokenize(title))
        overlap = len(query_words & title_words)
        if overlap:
            scored.append((overlap, title))
    scored.sort(key=lambda item: (-item[0], item[1]))
    return [title for _, title in scored[:limit]]


def topics_for_focus(topics: list[str], focus: str) -> list[str]:
    focus_map = {
        "foundations": {
            "What is system design?",
            "IP",
            "OSI Model",
            "TCP and UDP",
            "Domain Name System (DNS)",
            "Load Balancing",
            "Clustering",
            "Caching",
            "Content Delivery Network (CDN)",
            "Proxy",
            "Availability",
            "Scalability",
            "Storage",
        },
        "database": {
            "Databases and DBMS",
            "SQL databases",
            "NoSQL databases",
            "SQL vs NoSQL databases",
            "Database Replication",
            "Indexes",
            "Normalization and Denormalization",
            "ACID and BASE consistency models",
            "CAP theorem",
            "PACELC Theorem",
            "Transactions",
            "Distributed Transactions",
            "Sharding",
            "Consistent Hashing",
            "Database Federation",
        },
        "architecture": {
            "N-tier architecture",
            "Message Brokers",
            "Message Queues",
            "Publish-Subscribe",
            "Enterprise Service Bus (ESB)",
            "Monoliths and Microservices",
            "Event-Driven Architecture (EDA)",
            "Event Sourcing",
            "Command and Query Responsibility Segregation (CQRS)",
            "API Gateway",
            "REST, GraphQL, gRPC",
            "Long polling, WebSockets, Server-Sent Events (SSE)",
        },
        "reliability": {
            "Geohashing and Quadtrees",
            "Circuit breaker",
            "Rate Limiting",
            "Service Discovery",
            "SLA, SLO, SLI",
            "Disaster recovery",
            "Virtual Machines (VMs) and Containers",
            "OAuth 2.0 and OpenID Connect (OIDC)",
            "Single Sign-On (SSO)",
            "SSL, TLS, mTLS",
        },
        "interview": {
            "System Design Interviews",
            "URL Shortener",
            "WhatsApp",
            "Twitter",
            "Netflix",
            "Uber",
        },
    }
    if focus == "all":
        return topics
    wanted = focus_map.get(focus)
    if wanted is None:
        raise ValueError(f"unknown focus '{focus}'. Choose one of: all, {', '.join(sorted(focus_map))}")
    return [topic for topic in topics if topic in wanted]


def chunk_evenly(items: Sequence[str], chunk_count: int) -> list[list[str]]:
    chunks: list[list[str]] = []
    total = len(items)
    for index in range(chunk_count):
        start = round(index * total / chunk_count)
        end = round((index + 1) * total / chunk_count)
        chunks.append(list(items[start:end]))
    return chunks


def print_json(data: object) -> None:
    print(json.dumps(data, indent=2, ensure_ascii=False))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Browse and query the local system-design skill bundle.",
    )
    parser.add_argument(
        "--skill-dir",
        default=Path(__file__).resolve().parent,
        type=Path,
        help="Path to the skill directory. Defaults to this script's directory.",
    )
    parser.add_argument("--version", action="version", version="system-design-skill 1.0")

    subparsers = parser.add_subparsers(dest="command", required=True)

    info = subparsers.add_parser("info", help="Show repository and skill metadata.")
    info.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    topics = subparsers.add_parser("topics", help="List top-level README topics.")
    topics.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    show = subparsers.add_parser("show", help="Show one markdown topic.")
    show.add_argument("topic", help="Topic title, for example 'Caching'.")
    show.add_argument("--plain", action="store_true", help="Print the body without the heading.")

    summary = subparsers.add_parser("summary", help="Print a short summary for one topic.")
    summary.add_argument("topic", help="Topic title, for example 'Caching'.")
    summary.add_argument("-n", "--sentences", type=int, default=3, help="Number of sentences to print.")
    summary.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    outline = subparsers.add_parser("outline", help="List subheadings inside one topic.")
    outline.add_argument("topic", help="Topic title, for example 'Caching'.")
    outline.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    search = subparsers.add_parser("search", help="Search topics by keyword or phrase.")
    search.add_argument("query", help="Search query.")
    search.add_argument("-n", "--limit", type=int, default=5, help="Maximum results to print.")
    search.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    plan = subparsers.add_parser("plan", help="Generate a study plan from the indexed topics.")
    plan.add_argument("--days", type=int, default=7, help="Number of study days.")
    plan.add_argument(
        "--focus",
        default="all",
        choices=["all", "foundations", "database", "architecture", "reliability", "interview"],
        help="Topic group to prioritize.",
    )
    plan.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    flashcards = subparsers.add_parser("flashcards", help="Generate study flashcards for one topic.")
    flashcards.add_argument("topic", help="Topic title, for example 'Caching'.")
    flashcards.add_argument("-n", "--limit", type=int, default=10, help="Maximum cards to print.")
    flashcards.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    quiz = subparsers.add_parser("quiz", help="Generate quiz questions for one topic.")
    quiz.add_argument("topic", help="Topic title, for example 'Caching'.")
    quiz.add_argument("-n", "--count", type=int, default=5, help="Maximum questions to print.")
    quiz.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    issues = subparsers.add_parser("issues", help="List GitHub issues captured with the skill.")
    issues.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    tree = subparsers.add_parser("tree", help="Show captured repository file structure.")
    tree.add_argument("-n", "--limit", type=int, default=None, help="Maximum lines to print.")

    export = subparsers.add_parser("export-json", help="Export an index of this skill to JSON.")
    export.add_argument("path", type=Path, help="Output JSON path.")

    return parser


def run_command(args: argparse.Namespace) -> int:
    try:
        skill = SystemDesignSkill.from_directory(args.skill_dir)

        if args.command == "info":
            data = skill.to_dict()
            if args.json:
                print_json(data)
            else:
                print(f"{data['title']}")
                print(f"Skill: {skill.metadata.get('name', skill.root.name)}")
                print(f"Description: {skill.metadata.get('description', 'No description')}")
                print(f"Root: {skill.root}")
                print(f"Topics: {len(data['topics'])}")
                print(f"Issues: {len(data['issues'])}")
            return 0

        if args.command == "topics":
            topic_list = skill.list_topics()
            if args.json:
                print_json(topic_list)
            else:
                for topic in topic_list:
                    print(topic)
            return 0

        if args.command == "show":
            section = skill.get_topic(args.topic)
            if not args.plain:
                print(f"{'#' * section.level} {section.title}\n")
            print(section.body)
            return 0

        if args.command == "summary":
            summary = skill.summarize_topic(args.topic, sentences=args.sentences)
            if args.json:
                print_json({"topic": args.topic, "summary": summary})
            else:
                print(summary)
            return 0

        if args.command == "outline":
            outline = skill.topic_outline(args.topic)
            if args.json:
                print_json(outline)
            else:
                for item in outline:
                    indent = "  " * max(int(item["level"]) - 2, 0)
                    print(f"{indent}- {item['title']} (line {item['line_start']})")
            return 0

        if args.command == "search":
            matches = skill.search(args.query, limit=args.limit)
            if args.json:
                print_json([asdict(match) for match in matches])
            else:
                for match in matches:
                    print(f"{match.title}  score={match.score}  line={match.line_start}")
                    if match.snippet:
                        print(textwrap.indent(textwrap.fill(match.snippet, width=88), "  "))
            return 0

        if args.command == "plan":
            study_plan = skill.study_plan(days=args.days, focus=args.focus)
            if args.json:
                print_json([asdict(day) for day in study_plan])
            else:
                for day in study_plan:
                    print(f"{day.label}:")
                    for topic in day.topics:
                        print(f"  - {topic}")
            return 0

        if args.command == "flashcards":
            cards = skill.flashcards(args.topic, limit=args.limit)
            if args.json:
                print_json([asdict(card) for card in cards])
            else:
                for index, card in enumerate(cards, start=1):
                    print(f"{index}. {card.term}")
                    print(f"   Q: {card.prompt}")
                    print(f"   A: {card.answer}")
            return 0

        if args.command == "quiz":
            questions = skill.quiz(args.topic, count=args.count)
            if args.json:
                print_json([asdict(question) for question in questions])
            else:
                for index, question in enumerate(questions, start=1):
                    print(f"{index}. {question.question}")
                    print(f"   Answer: {question.answer}")
            return 0

        if args.command == "issues":
            issues = skill.issues()
            if args.json:
                print_json(issues)
            else:
                for issue in issues:
                    labels = f" [{issue['labels']}]" if issue["labels"] else ""
                    print(f"#{issue['number']} {issue['status']}: {issue['title']}{labels}")
            return 0

        if args.command == "tree":
            for line in skill.file_structure(limit=args.limit):
                print(line)
            return 0

        if args.command == "export-json":
            args.path.write_text(json.dumps(skill.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
            print(f"Wrote {args.path}")
            return 0

    except (FileNotFoundError, LookupError, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2

    print(f"error: unknown command {args.command}", file=sys.stderr)
    return 2


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return run_command(args)


if __name__ == "__main__":
    raise SystemExit(main())
