"""Persistence for suppressions.

SQLite (:mod:`suppressions.db`) is the system of record — see that module's
docstring for why. Every write here also mirrors to a single JSON list at
``~/.tm_suppressions.json`` (this module's own historical format) as a
best-effort, human-readable backup: nothing reads that file back in normal
operation, so a failure writing it must never fail the save itself.
"""
from __future__ import annotations

import logging
from pathlib import Path

import report_store

from . import db
from .model import Suppression

log = logging.getLogger("suppressions")

_BACKUP_PATH = Path.home() / ".tm_suppressions.json"


def _write_backup() -> None:
    try:
        report_store.atomic_write_json(
            _BACKUP_PATH, [s.to_dict() for s in db.all_suppressions()])
    except Exception:  # pragma: no cover - best-effort only
        log.warning("suppressions JSON backup write failed", exc_info=True)


def load_suppressions() -> list[Suppression]:
    """All stored suppressions."""
    return db.all_suppressions()


def save_suppressions(suppressions: list[Suppression]) -> None:
    """Replace the full set (used by callers that already hold the list)."""
    for supp in suppressions:
        db.upsert(supp)
    _write_backup()


def list_suppressions(now: float | None = None) -> list[dict]:
    """Public view of all suppressions, each tagged with an ``expired`` flag."""
    return [s.public_dict(now) for s in db.all_suppressions()]


def add_suppression(data: dict) -> Suppression:
    """Validate and persist a new suppression; returns the stored record.

    De-duplicates: an existing non-expired suppression with the same
    (scope, match, report_id) is replaced rather than duplicated, so re-accepting
    the same finding updates the reason/author/expiry instead of stacking.
    """
    supp = Suppression.from_dict(data)          # raises ValueError on bad input
    db.upsert(supp)
    _write_backup()
    return supp


def delete_suppression(supp_id: str) -> bool:
    """Remove a suppression by id; returns True if one was removed."""
    removed = db.delete(supp_id)
    if removed:
        _write_backup()
    return removed


def prune_expired(now: float | None = None) -> int:
    """Delete expired suppressions; returns how many were removed."""
    removed = db.prune_expired(now)
    if removed:
        _write_backup()
    return removed


def delete_all() -> int:
    """Wipe every suppression (DB and its JSON backup); returns how many
    were removed. Used by the admin flush action."""
    removed = db.delete_all()
    _write_backup()
    return removed
