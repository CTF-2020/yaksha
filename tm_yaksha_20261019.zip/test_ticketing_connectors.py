"""Tests for the Linear ticket connector and Confluence report-page publisher
in jira_client.py.

Mocks jira_client._http (no real HTTP calls), same spirit as
test_jira_webhook.py's mocking of the Jira comment-back path.
"""
from __future__ import annotations

import unittest
from unittest import mock

import jira_client


def _report(risk="High", verdict=None):
    cat = {"id": "SQLI-1", "name": "SQL Injection", "risk": risk,
           "description": "Unparameterized query.",
           "threats": [{"name": "search", "description": "cursor.execute(f\"...{q}\")"}],
           "mitigations": [{"action": "Use parameterized queries.", "priority": "Immediate"}]}
    if verdict:
        cat["verdict"] = verdict
    return {
        "id": "r1", "title": "Threat Model · shop-api",
        "summary": "1 finding.",
        "categories": [cat],
    }


class LinearConnectorTests(unittest.TestCase):
    def _cfg(self):
        return jira_client.TicketConfig(
            provider="linear", linear_api_key="lin_api_key", linear_team_id="team-123")

    def test_dry_run_makes_no_http_call(self):
        with mock.patch.object(jira_client, "_http") as http:
            tickets = jira_client.create_tickets_from_report(
                _report(), self._cfg(), min_severity="High", dry_run=True)
        http.assert_not_called()
        self.assertEqual(tickets[0].status, "dry_run")
        self.assertEqual(tickets[0].provider, "linear")

    def test_creates_issue_via_graphql_mutation(self):
        fake_resp = {"data": {"issueCreate": {"success": True,
                     "issue": {"identifier": "ENG-42", "url": "https://linear.app/x/issue/ENG-42"}}}}
        with mock.patch.object(jira_client, "_http", return_value=fake_resp) as http:
            tickets = jira_client.create_tickets_from_report(
                _report(), self._cfg(), min_severity="High", dry_run=False)

        self.assertEqual(len(tickets), 1)
        ticket = tickets[0]
        self.assertEqual(ticket.provider, "linear")
        self.assertEqual(ticket.ticket_id, "ENG-42")
        self.assertEqual(ticket.url, "https://linear.app/x/issue/ENG-42")

        method, url, headers, body = http.call_args[0]
        self.assertEqual(method, "POST")
        self.assertEqual(url, "https://api.linear.app/graphql")
        self.assertEqual(headers["Authorization"], "lin_api_key")   # raw key, no "Bearer"
        self.assertNotIn("Basic", headers["Authorization"])
        self.assertIn("issueCreate", body["query"])
        self.assertEqual(body["variables"]["input"]["teamId"], "team-123")

    def test_min_severity_filters_findings(self):
        report = _report(risk="Low")
        with mock.patch.object(jira_client, "_http") as http:
            tickets = jira_client.create_tickets_from_report(
                report, self._cfg(), min_severity="High", dry_run=False)
        http.assert_not_called()
        self.assertEqual(tickets, [])

    def test_min_verdict_filters_less_actionable_findings(self):
        report = _report(risk="High", verdict="blind_spot")
        with mock.patch.object(jira_client, "_http") as http:
            tickets = jira_client.create_tickets_from_report(
                report, self._cfg(), min_severity="High",
                min_verdict="corroborated", dry_run=False)
        http.assert_not_called()
        self.assertEqual(tickets, [])

    def test_min_verdict_allows_matching_or_more_actionable_verdict(self):
        report = _report(risk="High", verdict="confirmed_exploitable")
        fake_resp = {"data": {"issueCreate": {"success": True,
                     "issue": {"identifier": "ENG-1", "url": "https://linear.app/x/issue/ENG-1"}}}}
        with mock.patch.object(jira_client, "_http", return_value=fake_resp) as http:
            tickets = jira_client.create_tickets_from_report(
                report, self._cfg(), min_severity="High",
                min_verdict="corroborated", dry_run=False)
        http.assert_called_once()
        self.assertEqual(tickets[0].ticket_id, "ENG-1")

    def test_min_verdict_ignored_for_findings_without_a_verdict(self):
        # A plain SAST/manual report has no "verdict" field at all — setting
        # min_verdict must not silently ticket nothing for it; only findings
        # that actually carry a verdict get filtered by it.
        report = _report(risk="High")  # no verdict param passed
        fake_resp = {"data": {"issueCreate": {"success": True,
                     "issue": {"identifier": "ENG-2", "url": "https://linear.app/x/issue/ENG-2"}}}}
        with mock.patch.object(jira_client, "_http", return_value=fake_resp) as http:
            tickets = jira_client.create_tickets_from_report(
                report, self._cfg(), min_severity="High",
                min_verdict="confirmed_exploitable", dry_run=False)
        http.assert_called_once()
        self.assertEqual(tickets[0].ticket_id, "ENG-2")

    def test_finding_description_includes_verdict_when_present(self):
        desc = jira_client._finding_description(
            {"id": "SQLI-1", "name": "SQL Injection", "risk": "High",
             "verdict": "confirmed_exploitable"})
        self.assertIn("Verdict:   Confirmed exploitable", desc)

    def test_graphql_error_response_becomes_error_ticket(self):
        with mock.patch.object(jira_client, "_http",
                               return_value={"errors": [{"message": "invalid teamId"}]}):
            tickets = jira_client.create_tickets_from_report(
                _report(), self._cfg(), min_severity="High", dry_run=False)
        self.assertEqual(tickets[0].status, "error")
        self.assertIn("invalid teamId", tickets[0].error)


class JiraConnectorTests(unittest.TestCase):
    def _cfg(self):
        return jira_client.TicketConfig(
            provider="jira", jira_url="https://x.atlassian.net", jira_email="a@b.com",
            jira_token="tok", jira_project_key="SEC")

    def test_creates_issue_via_rest_v3(self):
        fake_resp = {"key": "SEC-42"}
        with mock.patch.object(jira_client, "_http", return_value=fake_resp) as http:
            tickets = jira_client.create_tickets_from_report(
                _report(), self._cfg(), min_severity="High", dry_run=False)

        self.assertEqual(len(tickets), 1)
        ticket = tickets[0]
        self.assertEqual(ticket.ticket_id, "SEC-42")
        self.assertEqual(ticket.url, "https://x.atlassian.net/browse/SEC-42")

        method, url, headers, body = http.call_args[0]
        self.assertEqual(method, "POST")
        self.assertEqual(url, "https://x.atlassian.net/rest/api/3/issue")
        self.assertEqual(body["fields"]["project"]["key"], "SEC")

    def test_multiline_finding_description_uses_hardbreaks(self):
        # _finding_description joins several sections with '\n' (Rule/Severity/
        # Category header, THREATS, MITIGATIONS) — the ticket description must
        # preserve those line breaks via ADF hardBreaks, not a single run-on
        # text node.
        with mock.patch.object(jira_client, "_http", return_value={"key": "SEC-1"}) as http:
            jira_client.create_tickets_from_report(
                _report(), self._cfg(), min_severity="High", dry_run=False)
        body = http.call_args[0][3]
        desc_content = body["fields"]["description"]["content"][0]["content"]
        hard_breaks = [n for n in desc_content if n["type"] == "hardBreak"]
        self.assertTrue(hard_breaks, "expected line breaks in a multi-line description")
        texts = [n["text"] for n in desc_content if n["type"] == "text"]
        self.assertTrue(any("THREATS" in t for t in texts))
        self.assertTrue(any("MITIGATIONS" in t for t in texts))


class ConfluenceConnectorTests(unittest.TestCase):
    def _cfg(self):
        return jira_client.TicketConfig(
            provider="confluence", confluence_base_url="https://myorg.atlassian.net",
            confluence_email="bot@myorg.com", confluence_api_token="tok",
            confluence_space_key="SEC")

    def test_publishes_one_page_regardless_of_severity(self):
        fake_resp = {"id": "98765", "_links": {"webui": "/spaces/SEC/pages/98765"}}
        with mock.patch.object(jira_client, "_http", return_value=fake_resp) as http:
            page = jira_client.publish_report_page(_report(risk="Low"), self._cfg())

        self.assertEqual(page.provider, "confluence")
        self.assertEqual(page.ticket_id, "98765")
        self.assertEqual(page.url, "https://myorg.atlassian.net/spaces/SEC/pages/98765")

        method, url, headers, body = http.call_args[0]
        self.assertEqual(method, "POST")
        self.assertEqual(url, "https://myorg.atlassian.net/wiki/rest/api/content")
        self.assertTrue(headers["Authorization"].startswith("Basic "))
        self.assertEqual(body["space"]["key"], "SEC")
        self.assertIn("SQL Injection", body["body"]["storage"]["value"])

    def test_uses_basic_auth_same_mechanism_as_jira(self):
        import base64
        with mock.patch.object(jira_client, "_http", return_value={"id": "1"}) as http:
            jira_client.publish_report_page(_report(), self._cfg())
        headers = http.call_args[0][2]
        creds = base64.b64decode(headers["Authorization"].split(" ", 1)[1]).decode()
        self.assertEqual(creds, "bot@myorg.com:tok")


if __name__ == "__main__":
    unittest.main(verbosity=2)
