"""engine.py — YAML-based threat modeling engine.

Provides two modes:
  batch_review(architecture_text, title) -> dict  — headless, used by analyzer.py
  interactive_review()                            — CLI walkthrough
"""
from __future__ import annotations
import json
import os
import re
from datetime import datetime
from pathlib import Path

import yaml

from risk_signals import RISK_SIGNALS as _RISK_SIGNALS

_YAML_PATH = Path(__file__).parent / "rule.yaml"

_SEV_RANK = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}

# Keywords extracted from each vector name used for relevance matching
def _keywords(text: str) -> list[str]:
    text = re.sub(r'[()/*\[\]]', ' ', text.lower())
    return [w for w in text.split() if len(w) > 3]


class ThreatModelingEngine:
    def __init__(self, yaml_path: str | None = None):
        self.yaml_path = yaml_path or str(_YAML_PATH)
        self.docs: list[dict] = []
        self.stride: dict = {}
        self.findings: list[dict] = []
        self.review_context: dict = {}
        self._load()

    def _load(self) -> None:
        if not os.path.exists(self.yaml_path):
            raise FileNotFoundError(f"YAML not found: {self.yaml_path}")
        raw = Path(self.yaml_path).read_text(encoding="utf-8", errors="replace")
        self.docs = [d for d in yaml.safe_load_all(raw) if d]
        for doc in self.docs:
            self.stride.update(doc.get("stride_mapping_and_mitigations", {}))

    # ── public data accessors ─────────────────────────────────────────────────

    def get_all_categories(self) -> list[str]:
        cats: list[str] = []
        for doc in self.docs:
            cats.extend(doc.get("attack_vectors", {}).keys())
        return cats

    def get_vectors_by_category(self, category: str) -> list[dict]:
        for doc in self.docs:
            if category in doc.get("attack_vectors", {}):
                return doc["attack_vectors"][category]
        return []

    def get_stride_mitigations(self, stride_type: str) -> list[str]:
        entry = self.stride.get(stride_type.lower(), {})
        return entry.get("mitigations", [])

    def get_threat_actors(self) -> list[dict]:
        for doc in self.docs:
            actors = doc.get("threat_modeling_process", {}) \
                        .get("step_3_adversary_modeling", {}) \
                        .get("threat_actors", [])
            if actors:
                return actors
        return []

    # ── batch (headless) review ───────────────────────────────────────────────

    def batch_review(self, architecture_text: str, title: str = "Untitled") -> dict:
        """
        Evaluate all YAML vectors against architecture_text without user input.
        Returns a dict compatible with the analyzer output schema.
        """
        text_lower = architecture_text.lower()
        has_risk_signal = any(sig in text_lower for sig in _RISK_SIGNALS)

        categories_out: list[dict] = []
        all_findings: list[dict] = []

        for cat_name in self.get_all_categories():
            vectors = self.get_vectors_by_category(cat_name)
            cat_findings: list[dict] = []

            for vec in vectors:
                vector_name = vec.get("vector", "")
                threat_types = vec.get("threat_type", [])
                question = vec.get("review_question", "")
                mitigations_raw = vec.get("mitigations", [])
                owasp_id = vec.get("owasp_id", "")
                description = vec.get("description", "")

                # Relevance: any keyword from the vector name appears in arch text
                kws = _keywords(vector_name)
                matched = [k for k in kws if k in text_lower]

                if not matched:
                    continue  # vector not applicable to this architecture

                # Severity: escalate to Critical if risk signal + dangerous threat type
                dangerous_types = {"Elevation of Privilege", "Tampering", "Spoofing"}
                if has_risk_signal and any(t in dangerous_types for t in threat_types):
                    severity = "Critical"
                elif any(t in dangerous_types for t in threat_types):
                    severity = "High"
                else:
                    severity = "Medium"

                # Collect STRIDE mitigations
                stride_mits: list[str] = []
                for tt in threat_types:
                    stride_mits.extend(self.get_stride_mitigations(tt))
                stride_mits = list(dict.fromkeys(stride_mits))  # deduplicate, preserve order

                all_mits = list(mitigations_raw) + [m for m in stride_mits if m not in mitigations_raw]

                finding = {
                    "vector": vector_name,
                    "owasp_id": owasp_id,
                    "category": cat_name,
                    "threat_types": threat_types,
                    "severity": severity,
                    "review_question": question,
                    "description": description,
                    "matched_keywords": matched,
                    "mitigations": all_mits[:6],
                }
                cat_findings.append(finding)
                all_findings.append(finding)

            if not cat_findings:
                continue

            worst = min(cat_findings, key=lambda f: _SEV_RANK.get(f["severity"], 4))
            sev_score = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3}

            categories_out.append({
                "id": cat_name.upper(),
                "name": cat_name.replace("_", " ").title(),
                "risk": worst["severity"],
                "risk_score": sev_score.get(worst["severity"], 5),
                "affected_components": list({k for f in cat_findings for k in f["matched_keywords"][:3]}),
                "threats": [
                    {
                        "name": f["vector"],
                        "description": f["description"] or f["review_question"],
                        "attack_vector": f"Matched patterns: {', '.join(f['matched_keywords'][:5])}",
                        "impact": ", ".join(f["threat_types"]),
                    }
                    for f in cat_findings[:4]
                ],
                "mitigations": [
                    {
                        "action": m,
                        "priority": "Immediate" if worst["severity"] in ("Critical", "High") else "Short-term",
                    }
                    for f in cat_findings[:2] for m in f["mitigations"][:3]
                ][:6],
                "notes": f"{len(cat_findings)} vector(s) applicable. Worst: {worst['severity']}.",
            })

        # Overall risk
        if not all_findings:
            overall_risk = "Low"
        else:
            crit = sum(1 for f in all_findings if f["severity"] == "Critical")
            high = sum(1 for f in all_findings if f["severity"] == "High")
            if crit >= 3 or (crit > 0 and has_risk_signal):
                overall_risk = "Critical"
            elif crit > 0 or high >= 5:
                overall_risk = "High"
            elif high > 0:
                overall_risk = "Medium"
            else:
                overall_risk = "Low"

        top5 = sorted(all_findings, key=lambda f: _SEV_RANK.get(f["severity"], 4))[:5]
        recommendations = [
            f"[{f['severity']}] {f['review_question']}" for f in top5
        ]

        # Threat actor context from YAML
        actors = self.get_threat_actors()
        actor_summary = ", ".join(
            f"{a['name']} ({a['capability']} capability)" for a in actors[:3]
        ) if actors else ""

        summary = (
            f"YAML framework review identified {len(all_findings)} applicable threat vectors "
            f"across {len(categories_out)} categories. Overall risk: {overall_risk}."
        )
        if actor_summary:
            summary += f" Relevant threat actors: {actor_summary}."

        return {
            "title": title,
            "methodology": "YAML Framework Review",
            "summary": summary,
            "overall_risk": overall_risk,
            "categories": categories_out,
            "recommendations": recommendations,
            "total_vectors_evaluated": sum(len(self.get_vectors_by_category(c)) for c in self.get_all_categories()),
            "vectors_applicable": len(all_findings),
            "risk_signals_detected": has_risk_signal,
        }

    # ── interactive CLI ───────────────────────────────────────────────────────

    def interactive_review(self, target_categories: list[str] | None = None) -> None:
        print("\n" + "=" * 60)
        print("THREAT MODELING & ARCHITECTURE REVIEW")
        print("=" * 60)

        scope = input("\n[1] System name/description: ")
        assets = input("[2] Critical assets (crown jewels): ")
        self.review_context = {"scope": scope, "assets": assets, "date": datetime.now().isoformat()}

        available = self.get_all_categories()
        if target_categories:
            to_review = [c for c in available if c in target_categories]
        else:
            for idx, cat in enumerate(available, 1):
                print(f"  {idx}. {cat}")
            print(f"  {len(available)+1}. ALL")
            choice = input(f"\nCategories (comma-separated, or {len(available)+1} for all): ")
            indices = [int(x.strip()) for x in choice.split(",")]
            to_review = available if (len(available) + 1) in indices else [
                available[i - 1] for i in indices if 0 < i <= len(available)
            ]

        for cat in to_review:
            print(f"\n--- {cat.upper()} ---")
            for vec in self.get_vectors_by_category(cat):
                vname = vec.get("vector", "?")
                ttypes = vec.get("threat_type", [])
                question = vec.get("review_question", "Implemented?")
                print(f"\n  Vector : {vname}")
                print(f"  STRIDE : {', '.join(ttypes)}")
                print(f"  Review : {question}")
                ans = input("  Implemented? (y/n/skip): ").lower().strip()
                if ans == "n":
                    mits: list[str] = list(vec.get("mitigations", []))
                    for tt in ttypes:
                        mits.extend(self.get_stride_mitigations(tt))
                    self.findings.append({
                        "category": cat,
                        "vector": vname,
                        "threat_types": ttypes,
                        "status": "VULNERABLE",
                        "recommended_mitigations": list(dict.fromkeys(mits)),
                    })

    def generate_report(self, output_format: str = "text") -> None:
        if not self.findings:
            print("No vulnerabilities identified.")
            return
        print("\n" + "=" * 60 + "\nTHREAT MODEL REPORT\n" + "=" * 60)
        print(f"System : {self.review_context.get('scope')}")
        print(f"Assets : {self.review_context.get('assets')}")
        print(f"Date   : {self.review_context.get('date')}")
        print(f"Total  : {len(self.findings)} finding(s)\n" + "-" * 60)
        for i, f in enumerate(self.findings, 1):
            print(f"\n#{i}: {f['vector']}")
            print(f"  Category : {f['category']}")
            print(f"  STRIDE   : {', '.join(f['threat_types'])}")
            print("  Mitigations:")
            for m in f["recommended_mitigations"]:
                print(f"    - {m}")
        if output_format == "json":
            out = {"context": self.review_context, "findings": self.findings}
            with open("threat_model_report.json", "w") as fh:
                json.dump(out, fh, indent=2)
            print("\nSaved to threat_model_report.json")


if __name__ == "__main__":
    engine = ThreatModelingEngine()
    engine.interactive_review()
    engine.generate_report()
