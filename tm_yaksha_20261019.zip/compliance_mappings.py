"""compliance_mappings.py — Control cross-reference: OWASP → PCI DSS 4.0, HIPAA, GDPR, SOC 2, NIST 800-53."""
from __future__ import annotations

# ── Schema ─────────────────────────────────────────────────────────────────────
# Each entry: list of {framework, control_id, control_name, requirement}
# ── OWASP Web 2021 mappings ────────────────────────────────────────────────────
OWASP_WEB_COMPLIANCE: dict[str, list[dict]] = {
    "A01": [
        {"framework": "PCI DSS 4.0", "control_id": "7.2",    "control_name": "Access Control Systems",           "requirement": "Implement access control system for system components"},
        {"framework": "PCI DSS 4.0", "control_id": "8.6",    "control_name": "Application Access Controls",      "requirement": "All user accounts authenticated before access to system components"},
        {"framework": "HIPAA",       "control_id": "164.312(a)(1)", "control_name": "Access Control",            "requirement": "Implement technical policies restricting access to ePHI"},
        {"framework": "GDPR",        "control_id": "Art. 25", "control_name": "Data Protection by Design",       "requirement": "Implement appropriate technical measures by design"},
        {"framework": "SOC 2",       "control_id": "CC6.1",   "control_name": "Logical and Physical Access",     "requirement": "Restrict logical access to information assets"},
        {"framework": "NIST 800-53", "control_id": "AC-3",    "control_name": "Access Enforcement",              "requirement": "Enforce approved authorizations for access to systems"},
    ],
    "A02": [
        {"framework": "PCI DSS 4.0", "control_id": "3.5",    "control_name": "Strong Cryptography",             "requirement": "Use strong cryptography to safeguard PAN during transmission"},
        {"framework": "PCI DSS 4.0", "control_id": "4.2",    "control_name": "Encrypted Transmission",          "requirement": "Strong cryptography used during transmission over public networks"},
        {"framework": "HIPAA",       "control_id": "164.312(a)(2)(iv)", "control_name": "Encryption",           "requirement": "Implement mechanism to encrypt and decrypt ePHI"},
        {"framework": "HIPAA",       "control_id": "164.312(e)(2)(ii)", "control_name": "Encryption in Transit","requirement": "Implement security measures to guard against unauthorized access to ePHI in transit"},
        {"framework": "GDPR",        "control_id": "Art. 32(a)", "control_name": "Encryption",                  "requirement": "Encryption of personal data as appropriate technical measure"},
        {"framework": "SOC 2",       "control_id": "CC6.7",   "control_name": "Encryption at Rest/Transit",     "requirement": "Protect sensitive information during transmission and storage"},
        {"framework": "NIST 800-53", "control_id": "SC-28",   "control_name": "Protection of Information at Rest","requirement": "Protect confidentiality and integrity of information at rest"},
        {"framework": "NIST 800-53", "control_id": "SC-8",    "control_name": "Transmission Confidentiality",   "requirement": "Implement cryptographic mechanisms to protect information in transit"},
    ],
    "A03": [
        {"framework": "PCI DSS 4.0", "control_id": "6.2",    "control_name": "Secure Development",              "requirement": "Bespoke and custom software developed securely"},
        {"framework": "PCI DSS 4.0", "control_id": "6.2.4",  "control_name": "Injection Prevention",            "requirement": "Software engineering techniques prevent injection attacks"},
        {"framework": "SOC 2",       "control_id": "CC8.1",   "control_name": "Change Management",              "requirement": "Entity implements change management processes"},
        {"framework": "NIST 800-53", "control_id": "SI-10",   "control_name": "Information Input Validation",   "requirement": "Check information input for accuracy, completeness, validity"},
    ],
    "A04": [
        {"framework": "PCI DSS 4.0", "control_id": "6.3",    "control_name": "Security Vulnerabilities",        "requirement": "Security vulnerabilities are identified and addressed"},
        {"framework": "NIST 800-53", "control_id": "SA-8",    "control_name": "Security and Privacy Engineering","requirement": "Apply security engineering principles in the specification and design"},
        {"framework": "GDPR",        "control_id": "Art. 25", "control_name": "Data Protection by Default",      "requirement": "Implement appropriate technical measures by default"},
    ],
    "A05": [
        {"framework": "PCI DSS 4.0", "control_id": "2.2",    "control_name": "Secure Configuration",            "requirement": "System components configured and managed securely"},
        {"framework": "PCI DSS 4.0", "control_id": "2.2.1",  "control_name": "Configuration Standards",         "requirement": "Configuration standards are developed, implemented and managed"},
        {"framework": "HIPAA",       "control_id": "164.312(b)",    "control_name": "Audit Controls",            "requirement": "Implement hardware, software to record and examine activity"},
        {"framework": "SOC 2",       "control_id": "CC7.1",   "control_name": "System Monitoring",              "requirement": "Detect and monitor threats and vulnerabilities"},
        {"framework": "NIST 800-53", "control_id": "CM-6",    "control_name": "Configuration Settings",         "requirement": "Establish and document configuration settings for information technology"},
    ],
    "A06": [
        {"framework": "PCI DSS 4.0", "control_id": "6.3.3",  "control_name": "Security Patches",                "requirement": "All software is protected from known vulnerabilities by installing security patches"},
        {"framework": "SOC 2",       "control_id": "CC7.1",   "control_name": "Vulnerability Management",       "requirement": "Evaluate and address vulnerabilities"},
        {"framework": "NIST 800-53", "control_id": "RA-5",    "control_name": "Vulnerability Monitoring",       "requirement": "Monitor and scan for vulnerabilities in systems and applications"},
        {"framework": "NIST 800-53", "control_id": "SI-2",    "control_name": "Flaw Remediation",               "requirement": "Identify, report, and correct information system flaws"},
    ],
    "A07": [
        {"framework": "PCI DSS 4.0", "control_id": "8.3",    "control_name": "User Authentication",             "requirement": "All individual non-consumer user accounts and administrators authenticated"},
        {"framework": "PCI DSS 4.0", "control_id": "8.4",    "control_name": "MFA",                             "requirement": "Multi-factor authentication implemented for all access"},
        {"framework": "HIPAA",       "control_id": "164.312(d)", "control_name": "Person or Entity Authentication","requirement": "Implement procedures to verify that a person is the one claimed"},
        {"framework": "SOC 2",       "control_id": "CC6.1",   "control_name": "Authentication",                 "requirement": "Logical access to information assets is managed"},
        {"framework": "NIST 800-53", "control_id": "IA-2",    "control_name": "Identification and Authentication","requirement": "Uniquely identify and authenticate organizational users"},
        {"framework": "NIST 800-53", "control_id": "IA-5",    "control_name": "Authenticator Management",       "requirement": "Manage information system authenticators"},
    ],
    "A08": [
        {"framework": "PCI DSS 4.0", "control_id": "6.4",    "control_name": "Public-Facing Web Apps",          "requirement": "Public-facing web applications protected against attacks"},
        {"framework": "SOC 2",       "control_id": "CC8.1",   "control_name": "Change Management",              "requirement": "Changes to infrastructure, data, and software are authorized"},
        {"framework": "NIST 800-53", "control_id": "SI-7",    "control_name": "Software, Firmware, Information Integrity","requirement": "Employ integrity verification tools to detect unauthorized changes"},
    ],
    "A09": [
        {"framework": "PCI DSS 4.0", "control_id": "10.2",   "control_name": "Audit Logs",                      "requirement": "Audit logs capture user activities, exceptions, and security events"},
        {"framework": "PCI DSS 4.0", "control_id": "10.5",   "control_name": "Log Retention",                   "requirement": "Retain audit log history for at least 12 months"},
        {"framework": "HIPAA",       "control_id": "164.312(b)", "control_name": "Audit Controls",              "requirement": "Hardware, software, and procedural mechanisms to record and examine access activity"},
        {"framework": "GDPR",        "control_id": "Art. 32(d)", "control_name": "Testing and Evaluating",      "requirement": "Process for regularly testing, assessing and evaluating security"},
        {"framework": "SOC 2",       "control_id": "CC7.2",   "control_name": "Security Monitoring",            "requirement": "Monitor system components for anomalies"},
        {"framework": "NIST 800-53", "control_id": "AU-2",    "control_name": "Event Logging",                  "requirement": "Identify types of events requiring logging"},
        {"framework": "NIST 800-53", "control_id": "AU-6",    "control_name": "Audit Record Review",            "requirement": "Review and analyze system audit records"},
    ],
    "A10": [
        {"framework": "PCI DSS 4.0", "control_id": "1.3",    "control_name": "Network Access Controls",         "requirement": "Network access to and from the cardholder data environment is restricted"},
        {"framework": "NIST 800-53", "control_id": "SC-7",    "control_name": "Boundary Protection",            "requirement": "Monitor and control communications at external boundaries"},
        {"framework": "SOC 2",       "control_id": "CC6.6",   "control_name": "Logical Access Security",        "requirement": "Logical access security measures to protect against threats"},
    ],
}

# ── OWASP API 2023 mappings ────────────────────────────────────────────────────
OWASP_API_COMPLIANCE: dict[str, list[dict]] = {
    "API1": [
        {"framework": "PCI DSS 4.0", "control_id": "7.2",    "control_name": "Access Control",                  "requirement": "Access control systems to restrict access based on business need"},
        {"framework": "NIST 800-53", "control_id": "AC-3",    "control_name": "Access Enforcement",             "requirement": "Enforce approved authorizations for access"},
    ],
    "API2": [
        {"framework": "PCI DSS 4.0", "control_id": "8.2",    "control_name": "User Identification",             "requirement": "All users are assigned a unique user ID before allowing access"},
        {"framework": "NIST 800-53", "control_id": "IA-2",    "control_name": "Identification and Authentication","requirement": "Uniquely identify and authenticate users"},
    ],
    "API3": [
        {"framework": "GDPR",        "control_id": "Art. 5(1)(c)", "control_name": "Data Minimisation",         "requirement": "Personal data adequate, relevant and limited to what is necessary"},
        {"framework": "NIST 800-53", "control_id": "AC-3",    "control_name": "Access Enforcement",             "requirement": "Enforce authorizations for read and write access"},
    ],
    "API4": [
        {"framework": "PCI DSS 4.0", "control_id": "6.4",    "control_name": "Web Application Security",        "requirement": "Automated technical solutions to protect web-facing applications"},
        {"framework": "NIST 800-53", "control_id": "SC-5",    "control_name": "Denial of Service Protection",   "requirement": "Protect against denial of service attacks"},
    ],
    "API5": [
        {"framework": "PCI DSS 4.0", "control_id": "7.2",    "control_name": "Access Control",                  "requirement": "Restrict access to system components based on need-to-know"},
        {"framework": "NIST 800-53", "control_id": "AC-6",    "control_name": "Least Privilege",                "requirement": "Use the principle of least privilege"},
    ],
    "API7": [
        {"framework": "PCI DSS 4.0", "control_id": "1.3",    "control_name": "Network Controls",                "requirement": "Network access controls in place"},
        {"framework": "NIST 800-53", "control_id": "SC-7",    "control_name": "Boundary Protection",            "requirement": "Monitor communications at external boundaries"},
    ],
    "API8": [
        {"framework": "PCI DSS 4.0", "control_id": "2.2",    "control_name": "Secure Configuration",            "requirement": "System components configured and managed securely"},
        {"framework": "NIST 800-53", "control_id": "CM-6",    "control_name": "Configuration Settings",         "requirement": "Establish configuration settings"},
    ],
}

# ── OWASP LLM 2025 mappings ────────────────────────────────────────────────────
OWASP_LLM_COMPLIANCE: dict[str, list[dict]] = {
    "LLM01": [
        {"framework": "NIST AI RMF",  "control_id": "GOVERN 1.1", "control_name": "AI Risk Management", "requirement": "Establish policies for AI risk management"},
        {"framework": "NIST 800-53",  "control_id": "SI-10",       "control_name": "Input Validation",  "requirement": "Check information input for accuracy and validity"},
        {"framework": "EU AI Act",    "control_id": "Art. 9",      "control_name": "Risk Management",   "requirement": "Establish and implement risk management system for high-risk AI"},
    ],
    "LLM02": [
        {"framework": "NIST 800-53",  "control_id": "SI-10",       "control_name": "Input Validation",  "requirement": "Information input validation"},
        {"framework": "OWASP ASVS",   "control_id": "V5.3",        "control_name": "Output Encoding",   "requirement": "Output encoding and injection prevention"},
    ],
    "LLM06": [
        {"framework": "GDPR",         "control_id": "Art. 32",     "control_name": "Security of Processing","requirement": "Implement appropriate technical measures for data security"},
        {"framework": "NIST AI RMF",  "control_id": "MAP 1.6",     "control_name": "Privacy Risk",      "requirement": "Map AI risks including privacy risks"},
        {"framework": "HIPAA",        "control_id": "164.312(a)(2)(ii)", "control_name": "Information Access", "requirement": "Implement procedures for creating, changing, and safeguarding passwords"},
    ],
    "LLM08": [
        {"framework": "NIST AI RMF",  "control_id": "MANAGE 1.3", "control_name": "AI Risk Management", "requirement": "Implement risk response plans"},
        {"framework": "EU AI Act",    "control_id": "Art. 14",     "control_name": "Human Oversight",    "requirement": "High-risk AI systems allow effective oversight by humans"},
    ],
}

# ── Cloud (CSA) mappings ────────────────────────────────────────────────────────
OWASP_CLOUD_COMPLIANCE: dict[str, list[dict]] = {
    "CSA01": [
        {"framework": "PCI DSS 4.0", "control_id": "2.2",    "control_name": "Secure Configuration",            "requirement": "System components configured and managed securely"},
        {"framework": "SOC 2",       "control_id": "CC7.1",   "control_name": "Threat Detection",               "requirement": "Identify and monitor for threats"},
        {"framework": "NIST 800-53", "control_id": "CM-2",    "control_name": "Baseline Configuration",         "requirement": "Develop and document baseline configurations"},
    ],
    "CSA02": [
        {"framework": "PCI DSS 4.0", "control_id": "8.2",    "control_name": "User Identification",             "requirement": "All users assigned unique IDs"},
        {"framework": "SOC 2",       "control_id": "CC6.1",   "control_name": "Logical Access",                 "requirement": "Logical access controls to protect information assets"},
        {"framework": "NIST 800-53", "control_id": "AC-2",    "control_name": "Account Management",             "requirement": "Manage information system accounts"},
        {"framework": "NIST 800-53", "control_id": "IA-5",    "control_name": "Authenticator Management",       "requirement": "Manage information system authenticators"},
    ],
    "CSA11": [
        {"framework": "PCI DSS 4.0", "control_id": "3.5",    "control_name": "Strong Cryptography",             "requirement": "Use strong cryptography to safeguard stored data"},
        {"framework": "HIPAA",       "control_id": "164.312(a)(2)(iv)", "control_name": "Encryption",           "requirement": "Implement mechanism to encrypt and decrypt ePHI"},
        {"framework": "NIST 800-53", "control_id": "SC-28",   "control_name": "Protection of Information at Rest","requirement": "Protect confidentiality and integrity of information at rest"},
    ],
}

# ── Master lookup ──────────────────────────────────────────────────────────────
_ALL_MAPS: dict[str, dict[str, list[dict]]] = {
    "web":    OWASP_WEB_COMPLIANCE,
    "api":    OWASP_API_COMPLIANCE,
    "llm":    OWASP_LLM_COMPLIANCE,
    "cloud":  OWASP_CLOUD_COMPLIANCE,
}

_FRAMEWORK_ORDER = ["PCI DSS 4.0", "HIPAA", "GDPR", "SOC 2", "NIST 800-53", "NIST AI RMF", "EU AI Act", "OWASP ASVS"]


def get_controls(category: str, ruleset: str = "") -> list[dict]:
    """Return compliance controls for an OWASP category ID."""
    # Category ids coming straight from the OWASP_* tables (owasp.py,
    # offline_patterns.py's _framework_report) carry a display suffix like
    # "A01:2021" — strip it so the lookup hits the bare-key control tables.
    cat = category.upper().strip().split(":", 1)[0]
    if not ruleset:
        if cat.startswith("LLM"):   ruleset = "llm"
        elif cat.startswith("API"): ruleset = "api"
        elif cat.startswith("CSA"): ruleset = "cloud"
        else:                       ruleset = "web"
    return _ALL_MAPS.get(ruleset, {}).get(cat, [])


def get_frameworks_for_finding(category: str, ruleset: str = "") -> list[str]:
    """Return unique framework names applicable to this finding."""
    return list(dict.fromkeys(c["framework"] for c in get_controls(category, ruleset)))


def enrich_categories(categories: list[dict]) -> list[dict]:
    """Add compliance_controls list to each category dict (in-place)."""
    for c in categories:
        cat_id = c.get("id", "")
        c["compliance_controls"] = get_controls(cat_id)
        c["compliance_frameworks"] = get_frameworks_for_finding(cat_id)
    return categories


def compliance_summary(categories: list[dict]) -> dict[str, list[str]]:
    """
    Given a list of category findings, return a dict mapping framework → [failing control IDs].
    Useful for generating a compliance gap report.
    """
    gaps: dict[str, list[str]] = {}
    for cat in categories:
        if cat.get("risk") in ("Critical", "High", "Medium"):
            for ctrl in cat.get("compliance_controls", []):
                fw = ctrl["framework"]
                cid = ctrl["control_id"]
                gaps.setdefault(fw, [])
                if cid not in gaps[fw]:
                    gaps[fw].append(cid)
    return {fw: gaps[fw] for fw in _FRAMEWORK_ORDER if fw in gaps}


# ── Verdict-weighted impact ──────────────────────────────────────────────────
# compliance_summary() above treats every failing control the same way --
# Critical/High/Medium, present or not. That flattens a control the threat
# model merely modeled (design_gap, never proven) and one a production
# incident just confirmed (actively_exploited) into the same red chip, which
# is exactly backwards for an auditor or CISO deciding what to fix first.
# This mirrors control_register.py's _verdict_adjusted_priority -- same
# escalation policy (actively_exploited > confirmed_exploitable bump the
# tier; corroborated/design_gap/blind_spot and unverdicted findings are left
# at their severity-derived baseline) -- applied to framework controls
# instead of the internal control register.
_IMPACT_TIERS = ["Critical", "High", "Medium", "Low"]          # most- to least-urgent
_VERDICT_IMPACT_BUMP = {"actively_exploited": 2, "confirmed_exploitable": 1}


def _verdict_adjusted_impact(base_severity: str, verdict) -> str:
    base = base_severity if base_severity in _IMPACT_TIERS else "Low"
    bump = _VERDICT_IMPACT_BUMP.get(verdict, 0)
    if not bump:
        return base
    idx = _IMPACT_TIERS.index(base)
    return _IMPACT_TIERS[max(0, idx - bump)]


def weighted_compliance_summary(categories: list[dict]) -> dict[str, list[dict]]:
    """Framework -> failing controls ranked by verdict-adjusted impact, worst
    first, instead of compliance_summary()'s flat list of control ids.

    Each entry carries the control's ``impact`` (severity, escalated by the
    worst verdict among the findings that trigger it), the ``verdict`` and
    ``finding`` responsible for that impact, and how many findings hit this
    control at all -- so "this control is failing because of an actively
    exploited SQLi" reads differently from "this control is failing because
    of three modeled-but-unproven gaps", even though compliance_summary()
    would report both as one identical red chip.
    """
    by_control: dict[tuple[str, str], dict] = {}
    for cat in categories:
        risk = cat.get("risk")
        if risk not in ("Critical", "High", "Medium"):
            continue
        verdict = cat.get("verdict") or ""
        impact = _verdict_adjusted_impact(risk, verdict)
        title = str(cat.get("title") or cat.get("name") or cat.get("id") or "Finding")
        for ctrl in cat.get("compliance_controls") or []:
            fw, cid = ctrl["framework"], ctrl["control_id"]
            key = (fw, cid)
            entry = by_control.get(key)
            if entry is None:
                entry = by_control[key] = {
                    "framework": fw, "control_id": cid,
                    "control_name": ctrl.get("control_name", ""),
                    "impact": impact, "verdict": verdict, "finding": title,
                    "finding_count": 0,
                }
            if _IMPACT_TIERS.index(impact) < _IMPACT_TIERS.index(entry["impact"]):
                entry["impact"] = impact
                entry["verdict"] = verdict
                entry["finding"] = title
            entry["finding_count"] += 1

    out: dict[str, list[dict]] = {}
    for (fw, _cid), entry in by_control.items():
        out.setdefault(fw, []).append(entry)
    for fw in out:
        out[fw].sort(key=lambda e: (_IMPACT_TIERS.index(e["impact"]), -e["finding_count"], e["control_id"]))
    return {fw: out[fw] for fw in _FRAMEWORK_ORDER if fw in out}
