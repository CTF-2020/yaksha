"""lineage/service.py — orchestration: load a report, sync it against the
persistent lineage registry, report what changed.

Mirrors :mod:`correlator.service`'s shape: a leaf module that reads/writes the
same ``report_db`` store the rest of the app uses, with no dependency on
``app.py``, so the API layer stays a thin wrapper around this.
"""
from __future__ import annotations

import re

import report_db

from . import db, engine
from .model import ThreatLineage

_REPORT_ID_RE = re.compile(r'^[A-Za-z0-9_-]{8,80}$')


def _load_report(report_id: str) -> dict | None:
    if not _REPORT_ID_RE.match(report_id):
        return None
    return report_db.get_report(report_id)


def sync(report_id: str) -> dict:
    """Sync one saved report's findings into the lineage registry.

    Returns a summary: how many lineage entries were newly created vs. already
    existed and gained a new event, plus how many *became* "realized" as a
    direct result of this sync — a design prediction meeting its first code or
    runtime evidence, which is the event this whole package exists to surface.
    """
    report = _load_report(report_id)
    if report is None:
        raise ValueError(f"report not found: {report_id}")

    # Every family touched by this report is a plausible match target, so pull
    # the full registry for those families rather than the whole table — cheap
    # for any realistic number of tracked families, and keeps sync() from
    # scaling with total lineage size.
    from correlator.engine import observe_report
    observations = observe_report(report)
    families = {o.family for o in observations if o.locus_tokens}
    existing: list[ThreatLineage] = []
    for fam in families:
        existing.extend(db.all_threats(family=fam))
    existing_ids = {t.id for t in existing}

    touched, events = engine.sync_observations(observations, existing)

    created = [t for t in touched if t.id not in existing_ids]
    updated = [t for t in touched if t.id in existing_ids]
    realized_now = [t for t in updated if t.status == "realized"]

    seen_ids: set[str] = set()
    for t in touched:
        if t.id in seen_ids:
            continue
        seen_ids.add(t.id)
        db.upsert_threat(t)
    for threat_id, ev in events:
        db.add_event(threat_id, ev)

    return {
        "report_id": report_id,
        "observations_considered": len(observations),
        "threats_touched": len(seen_ids),
        "threats_created": len(created),
        "threats_updated": len(updated),
        "realized_this_sync": [
            {"id": t.id, "family": t.family, "family_title": t.family_title}
            for t in realized_now
        ],
    }


def _threat_to_dict(t: ThreatLineage, with_events: bool = False) -> dict:
    out = {
        "id": t.id, "family": t.family, "family_title": t.family_title,
        "status": t.status, "founding_locus": t.founding_locus,
        "kinds_seen": t.kinds_seen,
        "first_seen_at": t.first_seen_at,
        "first_seen_report_id": t.first_seen_report_id,
        "first_seen_report_title": t.first_seen_report_title,
        "first_seen_kind": t.first_seen_kind,
        "updated_at": t.updated_at,
        "event_count": db.event_count(t.id),
    }
    if with_events:
        out["events"] = [
            {"at": e.at, "report_id": e.report_id, "report_title": e.report_title,
             "kind": e.kind, "methodology": e.methodology, "severity": e.severity,
             "title": e.title, "locus_label": e.locus_label}
            for e in db.events_for(t.id)
        ]
    return out


def list_threats(status: str | None = None, family: str | None = None) -> list[dict]:
    return [_threat_to_dict(t) for t in db.all_threats(status=status, family=family)]


def get_threat(threat_id: str) -> dict | None:
    t = db.get(threat_id)
    if t is None:
        return None
    return _threat_to_dict(t, with_events=True)


def status() -> dict:
    threats = db.all_threats()
    counts = {"predicted": 0, "realized": 0, "confirmed": 0, "blind_spot": 0}
    for t in threats:
        counts[t.status] = counts.get(t.status, 0) + 1
    return {
        "engine": "lineage",
        "threats_tracked": len(threats),
        "status_counts": counts,
    }
