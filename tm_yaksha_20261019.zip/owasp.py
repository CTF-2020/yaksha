"""owasp.py -- OWASP Top 10 2021 definitions module."""
from __future__ import annotations

OWASP_TOP10: dict[str, dict] = {
    "A01": {
        "id": "A01:2021",
        "name": "Broken Access Control",
        "description": (
            "Access control enforces policy so users cannot act outside their intended permissions. "
            "Failures typically lead to unauthorized information disclosure, modification, or destruction of data."
        ),
        "common_examples": [
            "Bypassing access control checks by modifying the URL, application state, or API requests",
            "Permitting viewing or editing another user's account by providing its unique identifier (IDOR)",
            "Accessing APIs without proper access controls for POST, PUT, and DELETE operations",
        ],
        "mitigations": [
            "Deny by default except for public resources and enforce record-level ownership checks",
            "Implement server-side access control mechanisms that cannot be bypassed by the client",
            "Log access control failures and alert administrators on repeated violations",
        ],
    },
    "A02": {
        "id": "A02:2021",
        "name": "Cryptographic Failures",
        "description": (
            "Failures related to cryptography that often lead to exposure of sensitive data. "
            "This includes use of weak algorithms, improper key management, and transmitting data in cleartext."
        ),
        "common_examples": [
            "Transmitting sensitive data in cleartext over HTTP, SMTP, or FTP protocols",
            "Using deprecated or weak cryptographic algorithms such as MD5 or SHA1 for password hashing",
            "Storing passwords in plaintext or using reversible encryption instead of adaptive hashing",
        ],
        "mitigations": [
            "Classify data processed or stored and apply controls according to sensitivity requirements",
            "Encrypt all sensitive data at rest and in transit using strong, current algorithms (AES-256, TLS 1.2+)",
            "Use proper key management with rotation policies and never store keys alongside encrypted data",
        ],
    },
    "A03": {
        "id": "A03:2021",
        "name": "Injection",
        "description": (
            "Injection flaws occur when untrusted data is sent to an interpreter as part of a command or query. "
            "An attacker's hostile data can trick the interpreter into executing unintended commands or accessing unauthorized data."
        ),
        "common_examples": [
            "SQL injection via unsanitized user input concatenated directly into database queries",
            "OS command injection through application parameters passed to system shell calls",
            "LDAP or XPath injection through unvalidated input used in directory or XML queries",
        ],
        "mitigations": [
            "Use parameterized queries or prepared statements for all database interactions",
            "Validate and sanitize all user-supplied input using server-side allowlist validation",
            "Use LIMIT and other SQL controls to prevent mass disclosure in case of injection",
        ],
    },
    "A04": {
        "id": "A04:2021",
        "name": "Insecure Design",
        "description": (
            "Insecure design refers to weaknesses in the architecture and design of an application. "
            "Unlike implementation bugs, these are flaws in the fundamental design that cannot be fixed by perfect code alone."
        ),
        "common_examples": [
            "Missing rate limiting on sensitive operations like password reset or payment flows",
            "Business logic that trusts client-side validation without server-side enforcement",
            "Credential recovery flows that reveal whether an account exists through different responses",
        ],
        "mitigations": [
            "Establish a secure development lifecycle with threat modeling at the design phase",
            "Use secure design patterns and reference architectures for common scenarios",
            "Implement rate limiting, resource quotas, and abuse-case testing in the design",
        ],
    },
    "A05": {
        "id": "A05:2021",
        "name": "Security Misconfiguration",
        "description": (
            "Security misconfiguration is the most commonly seen vulnerability category in real-world systems. "
            "It includes missing security hardening, improperly configured permissions, unnecessary features enabled, and default credentials."
        ),
        "common_examples": [
            "Default credentials left unchanged on application servers, databases, or admin panels",
            "Unnecessary features enabled such as debug endpoints, directory listing, or sample applications",
            "Overly permissive cloud storage bucket policies or CORS configurations",
        ],
        "mitigations": [
            "Implement a repeatable hardening process with automated configuration verification",
            "Remove or do not install unused features, frameworks, and documentation",
            "Regularly review and update security configurations across all environments",
        ],
    },
    "A06": {
        "id": "A06:2021",
        "name": "Vulnerable and Outdated Components",
        "description": (
            "Applications using components with known vulnerabilities may undermine defenses and enable attacks. "
            "This includes libraries, frameworks, and other software modules running with the same privileges as the application."
        ),
        "common_examples": [
            "Running an outdated web framework with publicly disclosed remote code execution vulnerabilities",
            "Using unmaintained open-source libraries that no longer receive security patches",
            "Failing to track component versions and not subscribing to security advisories",
        ],
        "mitigations": [
            "Maintain an inventory of all component versions and continuously monitor for vulnerabilities (SCA)",
            "Remove unused dependencies and only obtain components from official sources over secure links",
            "Establish a patch management process to update components within a defined SLA",
        ],
    },
    "A07": {
        "id": "A07:2021",
        "name": "Identification and Authentication Failures",
        "description": (
            "Confirmation of the user's identity and session management are critical to protect against authentication attacks. "
            "Weaknesses allow attackers to compromise passwords, keys, or session tokens to assume other users' identities."
        ),
        "common_examples": [
            "Permitting brute force or credential stuffing attacks due to missing rate limiting",
            "Allowing weak or well-known passwords such as 'password1' or 'admin123'",
            "Using plain text or weakly hashed passwords and missing multi-factor authentication",
        ],
        "mitigations": [
            "Implement multi-factor authentication to prevent automated credential stuffing and brute force",
            "Enforce strong password policies and check new passwords against known-breached password lists",
            "Use secure session management with server-side session IDs that are invalidated after logout",
        ],
    },
    "A08": {
        "id": "A08:2021",
        "name": "Software and Data Integrity Failures",
        "description": (
            "Software and data integrity failures relate to code and infrastructure that does not protect against integrity violations. "
            "This includes insecure CI/CD pipelines, auto-update mechanisms without verification, and deserialization of untrusted data."
        ),
        "common_examples": [
            "Applications relying on plugins or libraries from untrusted CDNs or repositories without integrity checks",
            "Insecure CI/CD pipelines that allow unauthorized code changes to reach production",
            "Deserializing untrusted data without validation, enabling remote code execution",
        ],
        "mitigations": [
            "Use digital signatures or similar mechanisms to verify software and data integrity",
            "Ensure CI/CD pipelines have proper access controls, segregation, and code review processes",
            "Do not send serialized objects to untrusted clients and enforce strict type constraints on deserialization",
        ],
    },
    "A09": {
        "id": "A09:2021",
        "name": "Security Logging and Monitoring Failures",
        "description": (
            "Insufficient logging, detection, monitoring, and active response allows attackers to go undetected. "
            "Without proper logging and monitoring, breaches cannot be detected and incidents cannot be responded to effectively."
        ),
        "common_examples": [
            "Login failures, access control violations, and input validation failures are not logged",
            "Logs are only stored locally and not aggregated into a centralized monitoring system",
            "Alerting thresholds and response escalation processes are absent or ineffective",
        ],
        "mitigations": [
            "Log all authentication events, access control failures, and server-side input validation failures",
            "Ensure logs are generated in a format easily consumed by centralized log management (SIEM) solutions",
            "Establish effective monitoring and alerting so suspicious activities are detected and responded to quickly",
        ],
    },
    "A10": {
        "id": "A10:2021",
        "name": "Server-Side Request Forgery (SSRF)",
        "description": (
            "SSRF flaws occur when a web application fetches a remote resource without validating the user-supplied URL. "
            "This allows attackers to coerce the application to send crafted requests to internal services, bypassing firewalls and ACLs."
        ),
        "common_examples": [
            "Fetching data from user-supplied URLs that can target internal metadata services (e.g., cloud 169.254.169.254)",
            "Scanning internal ports or services by abusing application URL-fetching functionality",
            "Accessing internal APIs or admin interfaces through the server's trusted network position",
        ],
        "mitigations": [
            "Validate and sanitize all user-supplied URLs against an allowlist of permitted domains and IP ranges",
            "Disable HTTP redirections and enforce URL schema, port, and destination with a positive allowlist",
            "Segment remote resource access into separate networks and deny by default all non-essential internal traffic",
        ],
    },
}
