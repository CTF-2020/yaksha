"""Attack-path synthesis — turn "three tools agree" into an exploit chain.

The correlator says *whether* sources agree on a weakness. This goes one step
further and says *how it is reached*: it chains each externally-reachable entry
point (from the code-derived model) to the tainted, security-sensitive sink it
can reach, then grades that chain with any runtime (DAST) or static (SAST)
evidence pointing at the same weakness.

Input is saved reports only — a codemodel report (which now carries a structured
``scan_metadata.attack_surface`` of entry points and their reachable sinks) plus
zero or more evidence reports (DAST/SAST/correlation). Output is a ranked list of
:class:`AttackPath`, renderable as a normal TM report so it opens in the viewer
and exports to SARIF like everything else.

Pure: dicts in, dataclasses out. Matching against evidence reuses the
correlator's weakness taxonomy and locus normalization, so a DAST hit at
``/upload`` lines up with a code sink at ``handlers/upload.py:42``.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field

from correlator import engine, taxonomy
from correlator.model import SourceKind

# Typical worst-case severity per weakness family, used when no scan evidence
# supplies one. Escalated to at least High when a chain is runtime-confirmed.
_FAMILY_SEVERITY = {
    "command-injection": "Critical", "code-injection": "Critical",
    "sql-injection": "Critical", "deserialization": "Critical",
    "ssrf": "High", "path-traversal": "High", "xxe": "High",
    "template-injection": "High", "broken-access-control": "High",
    "broken-auth": "High", "ldap-injection": "High", "xpath-injection": "High",
    "xss": "Medium", "open-redirect": "Medium", "csrf": "Medium",
    "sensitive-data-exposure": "Medium", "crypto-failure": "Medium",
}
_SEV_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
_SEV_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}


@dataclass
class Step:
    role: str        # entry | boundary | flow | sink
    label: str
    detail: str = ""
    locus: str = ""


@dataclass
class AttackPath:
    family: str
    family_title: str
    cwe: str
    severity: str
    entry_locus: str
    sink_locus: str
    authenticated: bool
    tainted: bool
    hops: int
    runtime_confirmed: bool
    static_corroborated: bool
    confidence: float
    verdict: str                 # confirmed | high-confidence | candidate
    narrative: str
    steps: list = field(default_factory=list)
    evidence_reports: list = field(default_factory=list)

    @property
    def priority(self) -> float:
        return round(_SEV_SCORE.get(self.severity, 1) + self.confidence
                     + (1.0 if self.runtime_confirmed else 0.0), 3)


def _worse(a: str, b: str) -> str:
    return a if _SEV_ORDER.get(a, 9) <= _SEV_ORDER.get(b, 9) else b


def _family_severity(family: str) -> str:
    return _FAMILY_SEVERITY.get(family, "Medium")


def _index_evidence(evidence_reports: list[dict]):
    """(runtime, code) observation lists keyed for family+locus matching."""
    runtime, code = [], []
    for report in evidence_reports or []:
        for obs in engine.observe_report(report):
            if obs.kind is SourceKind.RUNTIME:
                runtime.append((report.get("id", ""), obs))
            elif obs.kind is SourceKind.CODE:
                code.append((report.get("id", ""), obs))
    return runtime, code


def _match(observations, family: str, tokens) -> list[str]:
    """Report ids of observations of this family whose locus relates to tokens."""
    hits = []
    for rid, obs in observations:
        if obs.family == family and taxonomy.locus_related(tokens, obs.locus_tokens):
            hits.append(rid)
    return list(dict.fromkeys(hits))


def _narrative(ep: dict, sink: dict, family_title: str, cwe: str,
               runtime_confirmed: bool, tainted: bool) -> str:
    auth = "Authenticated" if ep.get("authenticated") else "Unauthenticated"
    entry = f"{ep.get('method', '*')} {ep.get('path', ep.get('handler', '?'))}".strip()
    reach = "directly" if not sink.get("hops") else f"via {sink['hops']} call hop(s)"
    tail = (" Runtime scanning confirmed the sink is reachable with a crafted "
            "request." if runtime_confirmed else
            (" A data-flow trace shows attacker-controlled input reaching the sink."
             if tainted else " The sink is reachable but taint was not confirmed."))
    return (f"{auth} entry point {entry} reaches {sink.get('name', 'a sink')} "
            f"({family_title}, {cwe or 'no CWE'}) at "
            f"{sink.get('file', '?')}:{sink.get('line', '?')} {reach}.{tail}")


def _build_steps(ep: dict, sink: dict, family_title: str) -> list[Step]:
    controls = ", ".join(c.get("mechanism", "") for c in ep.get("controls", [])) or "none observed"
    steps = [Step(
        role="entry",
        label=f"{'🔒 auth' if ep.get('authenticated') else '🔓 unauth'} "
              f"{ep.get('method', '*')} {ep.get('path', '')}".strip(),
        detail=f"handler {ep.get('handler', '?')} · controls: {controls}",
        locus=f"{ep.get('file', '?')}:{ep.get('line', '?')}")]
    kind = sink.get("kind", "")
    boundary = {"sql": "→ database", "command": "→ operating system",
                "code-eval": "→ interpreter", "ssrf": "→ external network",
                "path": "→ filesystem", "deserialize": "→ object graph",
                "template": "→ template engine", "redirect": "→ user browser"}.get(kind)
    if boundary:
        steps.append(Step(role="boundary", label=f"crosses trust boundary {boundary}",
                          detail=f"sink kind: {kind}"))
    if sink.get("hops"):
        steps.append(Step(role="flow",
                          label=f"data flows through {sink['hops']} helper call(s)",
                          detail="tainted" if sink.get("tainted") else "reachability only"))
    steps.append(Step(role="sink", label=f"{family_title}: {sink.get('name', 'sink')}",
                     detail=sink.get("cwe", ""),
                     locus=f"{sink.get('file', '?')}:{sink.get('line', '?')}"))
    return steps


def synthesize(codemodel_report: dict,
               evidence_reports: list[dict] | None = None) -> list[AttackPath]:
    """Chain each entry point to the exploitable sinks it reaches, grade each.

    A sink is a path candidate when it is tainted (attacker-controlled input
    reaches it) OR runtime evidence confirms the same weakness at that entry —
    reachability without taint and without corroboration is dropped, so a path
    always carries at least one concrete exploitability signal.
    """
    surface = ((codemodel_report.get("scan_metadata") or {}).get("attack_surface")
               or [])
    runtime_obs, code_obs = _index_evidence(evidence_reports or [])
    paths: list[AttackPath] = []

    for ep in surface:
        entry_tokens = taxonomy.locus_tokens(
            f"{ep.get('method', '')} {ep.get('path', '')}", ep.get("handler", ""))
        for sink in ep.get("sinks", []):
            family = sink.get("family") or "unknown"
            fam = taxonomy._FAMILY_BY_SLUG.get(family)
            family_title = fam["title"] if fam else (family.replace("-", " ").title())
            sink_tokens = taxonomy.locus_tokens(
                f"{sink.get('file', '')}:{sink.get('line', '')}", sink.get("name", ""))

            runtime_hits = _match(runtime_obs, family, entry_tokens | sink_tokens)
            static_hits = _match(code_obs, family, sink_tokens)
            tainted = bool(sink.get("tainted"))

            # Require a concrete exploitability signal.
            if not tainted and not runtime_hits:
                continue

            severity = _family_severity(family)
            if runtime_hits:                       # proven reachable at runtime
                severity = _worse(severity, "High")

            conf = 0.55 if tainted else 0.30
            if not ep.get("authenticated"):
                conf += 0.15
            if not any(c.get("kind") == "validation" for c in ep.get("controls", [])):
                conf += 0.05
            if runtime_hits:
                conf += 0.25
            if static_hits:
                conf += 0.10
            conf = round(min(1.0, conf), 3)

            verdict = ("confirmed" if runtime_hits else
                       "high-confidence" if (tainted and not ep.get("authenticated"))
                       else "candidate")

            paths.append(AttackPath(
                family=family, family_title=family_title, cwe=sink.get("cwe", ""),
                severity=severity, entry_locus=ep.get("path", ep.get("handler", "?")),
                sink_locus=f"{sink.get('file', '?')}:{sink.get('line', '?')}",
                authenticated=bool(ep.get("authenticated")), tainted=tainted,
                hops=int(sink.get("hops", 0) or 0),
                runtime_confirmed=bool(runtime_hits),
                static_corroborated=bool(static_hits),
                confidence=conf, verdict=verdict,
                narrative=_narrative(ep, sink, family_title, sink.get("cwe", ""),
                                     bool(runtime_hits), tainted),
                steps=_build_steps(ep, sink, family_title),
                evidence_reports=list(dict.fromkeys(runtime_hits + static_hits))))

    paths.sort(key=lambda p: (-p.priority, p.family, p.sink_locus))
    return paths


# ── Report rendering ──────────────────────────────────────────────────────────
def _path_category(p: AttackPath) -> dict:
    threats = [{
        "name": f"[{s.role}] {s.label}",
        "description": s.detail,
        "attack_vector": s.locus,
        "control_objective": "",
    } for s in p.steps]
    verdict_label = {"confirmed": "Confirmed exploit chain",
                     "high-confidence": "High-confidence path",
                     "candidate": "Candidate path"}.get(p.verdict, p.verdict)
    return {
        # Python's builtin hash() is randomized per-process (PYTHONHASHSEED),
        # so the same finding got a different id on every run — breaking
        # suppression fingerprints and cross-scan diffing. hashlib is stable
        # across processes/platforms.
        "id": f"AP-{p.family}-{hashlib.sha1(p.sink_locus.encode('utf-8', 'replace')).hexdigest()[:8]}",
        "category": "Attack Path",
        "name": f"{p.family_title}: {p.entry_locus} → {p.sink_locus}",
        "title": f"{p.family_title}: {p.entry_locus} → {p.sink_locus}",
        "risk": p.severity,
        "risk_score": _SEV_SCORE.get(p.severity, 1),
        "_source": "ATTACKPATH",
        "ruleset": "AttackPath",
        "cwe": p.cwe,
        "verdict": verdict_label,
        "confidence": p.confidence,
        "description": p.narrative,
        "affected_components": [p.entry_locus, p.sink_locus],
        "mitigation": ("Break the chain at the earliest point: add authentication/"
                       "authorization on the entry point, validate and encode the "
                       "tainted input, and use a safe API at the sink."),
        "remediation": "Break the chain: gate the entry, sanitize the flow, "
                       "harden the sink.",
        "mitigations": [{"action": "Gate the entry point, sanitize the flow, "
                         "and use a safe sink API.", "priority": "Immediate"}],
        "threats": threats,
        "notes": (f"verdict: {verdict_label} · confidence: {p.confidence} · "
                  f"{'runtime-confirmed' if p.runtime_confirmed else 'no runtime proof'} · "
                  f"{'tainted' if p.tainted else 'reachable'} · hops: {p.hops}"),
    }


def to_report(paths: list[AttackPath], sources: list[dict], meta: dict) -> dict:
    categories = [_path_category(p) for p in paths]
    overall = "Info"
    for p in paths:
        overall = _worse(overall, p.severity)
    confirmed = sum(1 for p in paths if p.verdict == "confirmed")
    high_conf = sum(1 for p in paths if p.verdict == "high-confidence")
    counts = {s: sum(1 for p in paths if p.severity == s)
              for s in ("Critical", "High", "Medium", "Low", "Info")}

    summary = (
        f"Synthesized {len(paths)} attack path(s) from the code-derived model"
        + (f" cross-referenced with {len(sources) - 1} evidence report(s)"
           if len(sources) > 1 else "")
        + f": {confirmed} runtime-confirmed, {high_conf} high-confidence. "
        + ", ".join(f"{counts[s]} {s}" for s in ("Critical", "High", "Medium")
                    if counts[s]) + "."
    ) if paths else "No exploitable attack paths synthesized (no tainted or " \
                    "runtime-confirmed sink reachable from an entry point)."

    return {
        "title": meta.get("report_title") or "Attack Paths",
        "methodology": "attackpath",
        "methodology_label": "Attack-Path Synthesis",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "summary": summary,
        "categories": categories,
        "recommendations": [
            "Prioritize runtime-confirmed chains — they are proven end to end.",
            "Prefer fixing at the entry point (authn/authz) to neutralize many "
            "downstream sinks at once.",
        ],
        "scan_metadata": {
            "engine": "attackpath",
            "sources": sources,
            "paths_total": len(paths),
            "confirmed": confirmed,
            "high_confidence": high_conf,
            "severity_counts": counts,
        },
    }
