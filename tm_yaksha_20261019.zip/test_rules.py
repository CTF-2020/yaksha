"""Rule catalog tests (stdlib unittest).

Run from the tm project root:
    python -m unittest test_rules

Exercises the catalog query layer directly and the API/page blueprints through
the Flask test client.
"""
from __future__ import annotations

import unittest
from unittest import mock

import rules_catalog


class CatalogTests(unittest.TestCase):
    def setUp(self):
        rules_catalog.reload()

    def test_catalog_loads_rules(self):
        rules = rules_catalog.all_rules()
        self.assertGreater(len(rules), 2400, "expected semgrep + gitlab MIT catalogs")

    def test_notice_is_metadata_only(self):
        n = rules_catalog.notice()
        self.assertEqual(n.get("vendored"), "metadata_only")
        rulesets = {s["ruleset"] for s in n.get("sources", [])}
        self.assertIn("semgrep-community", rulesets)
        self.assertIn("gitlab-sast-rules", rulesets)

    def test_multi_source_and_licenses(self):
        rules = rules_catalog.all_rules()
        rulesets = {r["ruleset"] for r in rules}
        self.assertEqual(rulesets, {"semgrep-community", "gitlab-sast-rules"})
        # the gitlab set we ingested is the permissive MIT tree only
        gl = [r for r in rules if r["ruleset"] == "gitlab-sast-rules"]
        self.assertTrue(gl)
        self.assertTrue(all(r["license"] == "MIT" for r in gl),
                        "only MIT-licensed gitlab rules should be ingested")
        # hard red line: no proprietary / enterprise-edition content in either set
        for r in rules:
            self.assertNotIn("enterprise edition", (r.get("license") or "").lower())

    def test_ruleset_facet_and_filter(self):
        f = rules_catalog.facets()
        self.assertIn("ruleset", f)
        vals = {i["value"] for i in f["ruleset"]}
        self.assertIn("gitlab-sast-rules", vals)
        r = rules_catalog.query(ruleset="gitlab-sast-rules")
        self.assertGreater(r["total"], 0)
        for x in r["rules"]:
            self.assertEqual(x["ruleset"], "gitlab-sast-rules")

    def test_rules_have_no_pattern_bodies(self):
        # reference-safe guarantee: no detection logic vendored
        for r in rules_catalog.all_rules()[:500]:
            for banned in ("patterns", "pattern", "pattern-either", "pattern-inside"):
                self.assertNotIn(banned, r, f"{r.get('id')} leaks {banned}")

    def test_every_rule_has_a_source_link(self):
        ok = ("https://github.com/semgrep/semgrep-rules",
              "https://gitlab.com/gitlab-org/security-products/sast-rules")
        for r in rules_catalog.all_rules():
            self.assertTrue(r.get("source", "").startswith(ok), r.get("source"))

    def test_query_pagination(self):
        r = rules_catalog.query(per_page=10, page=1)
        self.assertEqual(len(r["rules"]), 10)
        self.assertEqual(r["per_page"], 10)
        self.assertGreater(r["pages"], 1)
        p2 = rules_catalog.query(per_page=10, page=2)
        self.assertNotEqual(r["rules"][0]["key"], p2["rules"][0]["key"])

    def test_query_per_page_capped(self):
        r = rules_catalog.query(per_page=99999)
        self.assertLessEqual(r["per_page"], 200)

    def test_search_filter(self):
        r = rules_catalog.query(q="sql injection")
        self.assertGreater(r["total"], 0)
        self.assertTrue(all("_hay" not in x for x in r["rules"]), "internal fields must not leak")

    def test_facet_and_severity_filter(self):
        f = rules_catalog.facets()
        self.assertIn("language", f)
        self.assertIn("sev_label", f)
        langs = [i["value"] for i in f["language"]]
        self.assertIn("python", langs)
        r = rules_catalog.query(language="python", severity="High")
        for x in r["rules"]:
            self.assertEqual(x["language"], "python")
            self.assertEqual(x["sev_label"], "High")

    def test_cwe_filter(self):
        r = rules_catalog.query(cwe="89")
        self.assertGreater(r["total"], 0)
        for x in r["rules"]:
            self.assertTrue(any("89" in c for c in x["cwe"]))

    def test_related_matches_by_cwe(self):
        refs = rules_catalog.related(["CWE-89"])
        self.assertTrue(refs)
        for r in refs:
            self.assertIn("CWE-89", r["cwe"])
            self.assertTrue(r["name"])
            self.assertTrue(r["ruleset"])

    def test_related_empty_for_no_cwe(self):
        self.assertEqual(rules_catalog.related([]), [])
        self.assertEqual(rules_catalog.related(None), [])

    def test_related_empty_for_unknown_cwe(self):
        self.assertEqual(rules_catalog.related(["CWE-999999"]), [])

    def test_related_respects_limit_and_dedupes_by_name(self):
        refs = rules_catalog.related(["CWE-89"], limit=2)
        self.assertLessEqual(len(refs), 2)
        names = [r["name"] for r in refs]
        self.assertEqual(len(names), len(set(names)))

    def test_related_case_insensitive_and_bare_string(self):
        # a finding's own `cwe` field is often a bare string, not a list
        lower = rules_catalog.related(["cwe-89"])
        upper = rules_catalog.related(["CWE-89"])
        self.assertEqual({r["id"] for r in lower}, {r["id"] for r in upper})

    def test_get_by_id_and_key(self):
        first = rules_catalog.all_rules()[0]
        got = rules_catalog.get(first["key"])
        self.assertIsNotNone(got)
        self.assertEqual(got["key"], first["key"])
        self.assertIsNone(rules_catalog.get("does-not-exist-xyz"))


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app
        app.app.config["TESTING"] = True
        cls.client = app.app.test_client()

    def test_list_endpoint(self):
        r = self.client.get("/api/v1/rules?per_page=5")
        self.assertEqual(r.status_code, 200)
        d = r.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(len(d["rules"]), 5)

    def test_facets_endpoint(self):
        d = self.client.get("/api/v1/rules/facets").get_json()
        self.assertTrue(d["success"])
        self.assertIn("language", d["facets"])
        self.assertEqual(d["notice"]["vendored"], "metadata_only")

    def test_stats_endpoint(self):
        d = self.client.get("/api/v1/rules/stats").get_json()
        self.assertTrue(d["success"])
        self.assertGreater(d["total"], 2400)
        self.assertGreater(d["security"], 1000)
        self.assertIn("gitlab-sast-rules", d["by_ruleset"])
        self.assertIn("semgrep-community", d["by_ruleset"])

    def test_single_rule_and_404(self):
        first = self.client.get("/api/v1/rules?per_page=1").get_json()["rules"][0]
        ok = self.client.get("/api/v1/rules/" + first["key"])
        self.assertEqual(ok.status_code, 200)
        self.assertTrue(ok.get_json()["success"])
        missing = self.client.get("/api/v1/rules/nope-not-real")
        self.assertEqual(missing.status_code, 404)

    def test_bad_pagination_400(self):
        r = self.client.get("/api/v1/rules?page=abc")
        self.assertEqual(r.status_code, 400)

    def test_dashboard_page_renders(self):
        r = self.client.get("/rules")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"Rule Catalog", r.data)


class FindingEnrichmentTests(unittest.TestCase):
    """A SAST/Codemodel/DAST finding saved through _save_report gets citations
    into the rule catalog attached automatically — see app._enrich_with_rule_
    references, called from _save_report."""

    @classmethod
    def setUpClass(cls):
        import app
        app.app.config["TESTING"] = True
        cls.app = app
        cls.client = app.app.test_client()

    def test_category_with_known_cwe_gets_rule_references(self):
        report = {"overall_risk": "High", "categories": [
            {"id": "SAST-1", "name": "SQL Injection", "risk": "High",
             "_source": "SAST", "cwe": "CWE-89",
             "affected_components": ["app.py:1"]},
        ]}
        rid = self.app._save_report(report, "Enrichment test")
        saved = self.app.report_db.get_report(rid)
        refs = saved["categories"][0].get("rule_references")
        self.assertTrue(refs)
        self.assertTrue(any("CWE-89" in r["cwe"] for r in refs))

    def test_category_with_unknown_cwe_gets_no_fabricated_references(self):
        report = {"overall_risk": "Low", "categories": [
            {"id": "X-1", "name": "Made Up Weakness", "risk": "Low",
             "cwe": "CWE-999999", "affected_components": []},
        ]}
        rid = self.app._save_report(report, "No match test")
        saved = self.app.report_db.get_report(rid)
        self.assertNotIn("rule_references", saved["categories"][0])

    def test_category_without_cwe_is_untouched(self):
        report = {"overall_risk": "Info", "categories": [
            {"id": "SBOM-HIGH", "name": "Vulnerable Components — High",
             "risk": "High", "_source": "SBOM", "affected_components": ["pyyaml@5.3.1"]},
        ]}
        rid = self.app._save_report(report, "No CWE test")
        saved = self.app.report_db.get_report(rid)
        self.assertNotIn("rule_references", saved["categories"][0])

    def test_prefilled_rule_reference_is_not_overwritten(self):
        report = {"overall_risk": "High", "categories": [
            {"id": "SAST-1", "cwe": "CWE-89", "affected_components": [],
             "rule_references": [{"id": "custom", "name": "already set"}]},
        ]}
        rid = self.app._save_report(report, "Preset test")
        saved = self.app.report_db.get_report(rid)
        self.assertEqual(saved["categories"][0]["rule_references"],
                         [{"id": "custom", "name": "already set"}])

    def test_matched_rule_with_risk_rating_metadata_gets_aggregated(self):
        # Mocked rather than relying on which real catalog rules happen to
        # carry populated confidence/likelihood/impact in the current
        # snapshot (fragile -- see AggregateRuleRiskRatingTests for the pure
        # aggregation-logic tests); this only checks the save-path wiring.
        fake_refs = [{"id": "r1", "name": "Hard-coded creds", "ruleset": "x",
                      "language": "python", "cwe": ["CWE-798"],
                      "confidence": "HIGH", "likelihood": "HIGH", "impact": "MEDIUM"}]
        report = {"overall_risk": "High", "categories": [
            {"id": "SAST-1", "name": "Hard-coded Credentials", "risk": "High",
             "_source": "SAST", "cwe": "CWE-798", "affected_components": ["app.py:1"]},
        ]}
        with mock.patch.object(self.app.rules_catalog, "related",
                               return_value=fake_refs):
            rid = self.app._save_report(report, "Risk rating test")
        saved = self.app.report_db.get_report(rid)
        rating = saved["categories"][0].get("rule_risk_rating")
        self.assertEqual(rating, {"confidence": "HIGH", "likelihood": "HIGH",
                                  "impact": "MEDIUM", "matched_rules": 1})

    def test_category_with_no_risk_rating_metadata_gets_no_fact(self):
        fake_refs = [{"id": "r1", "name": "SQLi", "ruleset": "x", "language": "python",
                      "cwe": ["CWE-89"], "confidence": "", "likelihood": "", "impact": ""}]
        report = {"overall_risk": "High", "categories": [
            {"id": "SAST-1", "name": "SQL Injection", "risk": "High",
             "_source": "SAST", "cwe": "CWE-89", "affected_components": ["app.py:1"]},
        ]}
        with mock.patch.object(self.app.rules_catalog, "related",
                               return_value=fake_refs):
            rid = self.app._save_report(report, "No rating test")
        saved = self.app.report_db.get_report(rid)
        self.assertTrue(saved["categories"][0].get("rule_references"))
        self.assertNotIn("rule_risk_rating", saved["categories"][0])


class AggregateRuleRiskRatingTests(unittest.TestCase):
    """Pure unit tests for app._aggregate_rule_risk_rating against synthetic
    refs, independent of what the real catalog snapshot happens to contain."""

    def setUp(self):
        import app
        self.agg = app._aggregate_rule_risk_rating

    def test_takes_the_worst_rating_per_dimension_independently(self):
        refs = [
            {"confidence": "LOW", "likelihood": "HIGH", "impact": "MEDIUM"},
            {"confidence": "HIGH", "likelihood": "LOW", "impact": "LOW"},
        ]
        rating = self.agg(refs)
        self.assertEqual(rating["confidence"], "HIGH")
        self.assertEqual(rating["likelihood"], "HIGH")
        self.assertEqual(rating["impact"], "MEDIUM")
        self.assertEqual(rating["matched_rules"], 2)

    def test_none_when_nothing_rated(self):
        refs = [{"confidence": "", "likelihood": "", "impact": ""}]
        self.assertIsNone(self.agg(refs))

    def test_none_for_empty_refs(self):
        self.assertIsNone(self.agg([]))

    def test_case_insensitive_and_unknown_values_ignored(self):
        refs = [{"confidence": "high", "likelihood": "not-a-real-rating", "impact": ""}]
        rating = self.agg(refs)
        self.assertEqual(rating["confidence"], "HIGH")
        self.assertEqual(rating["likelihood"], "")   # unrecognized value scores 0, never wins


if __name__ == "__main__":
    unittest.main()
