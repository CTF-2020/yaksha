"""Broker configuration, state directories, and registry persistence.

All broker state lives under ~/.tm_broker (separate from ~/.tm_reports so the
reporting layer stays the single source of truth for findings). SQLite
(broker/db.py, ~/.tm_broker/broker.db) is the system of record; every write
here also mirrors to the legacy JSON files as a best-effort, human-readable
backup, serialized through a module lock. This module stays the public
surface every caller uses (service.py, github.py, the API layer) — db.py is
purely the persistence plumbing behind it.
"""
from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
from pathlib import Path

import settings_db

# ── State directories ─────────────────────────────────────────────────────────
STATE_DIR = Path(os.environ.get("TM_BROKER_DIR", str(Path.home() / ".tm_broker")))
WORKSPACE_DIR = Path(os.environ.get("TM_BROKER_WORKSPACE", str(STATE_DIR / "workspaces")))
REPOS_PATH = STATE_DIR / "repos.json"
JOBS_PATH = STATE_DIR / "jobs.json"
BASELINE_DIR = STATE_DIR / "baselines"
SHA_CACHE_PATH = STATE_DIR / "sha_cache.json"

STATE_DIR.mkdir(parents=True, exist_ok=True)
WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
BASELINE_DIR.mkdir(parents=True, exist_ok=True)


# ── Scan engine settings ──────────────────────────────────────────────────────
# Default to the bundled Security Architecture Review scanner. Both the engine
# and its rule catalog are overridable so the broker can drive any JSON-emitting
# scanner with the same { "findings": [...] } contract.
_DEFAULT_SCANNER = (
    Path.home() / "Projects-2026-06" / "security-architecture-review"
    / "security-architecture-review-skill" / "scripts" / "scan.py"
)
SCANNER_PATH = Path(os.environ.get("TM_BROKER_SCANNER", str(_DEFAULT_SCANNER)))
SCANNER_RULES = settings_db.resolve_str(
    "broker.scanner_rules", os.environ.get("TM_BROKER_RULES"), "")  # empty -> engine's own default
SCANNER_PYTHON = os.environ.get("TM_BROKER_PYTHON", sys.executable)
SCAN_TIMEOUT = settings_db.resolve_int(
    "broker.scan_timeout", os.environ.get("TM_BROKER_TIMEOUT"), 900)  # seconds
CLONE_TIMEOUT = settings_db.resolve_int(
    "broker.clone_timeout", os.environ.get("TM_BROKER_CLONE_TIMEOUT"), 600)
# Bound scanner stdout so a pathological repo can't OOM the host on json.loads,
# and cap the number of findings we retain from a single scan.
MAX_SCAN_OUTPUT = settings_db.resolve_int(
    "broker.max_scan_output_bytes", os.environ.get("TM_BROKER_MAX_OUTPUT_BYTES"), 32 * 1024 * 1024)
MAX_FINDINGS = settings_db.resolve_int(
    "broker.max_findings", os.environ.get("TM_BROKER_MAX_FINDINGS"), 5000)

# ── External multi-language engines ───────────────────────────────────────────
# Off-the-shelf open-source SAST engines (Opengrep, Gosec, njsscan, Bandit) run
# alongside the built-in scanner when their binary is on PATH and the repo
# contains sources in a language they cover. "auto" (default) runs every
# available+applicable engine; "off" disables them; a comma list (e.g.
# "opengrep,gosec") restricts to those ids.
EXTERNAL_ENGINES = settings_db.resolve_str(
    "broker.external_engines", os.environ.get("TM_BROKER_EXTERNAL_ENGINES"), "auto").strip().lower()
# Per-engine subprocess timeout (each external engine gets its own budget so one
# slow tool cannot eat the whole scan window).
ENGINE_TIMEOUT = settings_db.resolve_int(
    "broker.engine_timeout", os.environ.get("TM_BROKER_ENGINE_TIMEOUT"), 600)
# How many external engines may run concurrently. Engines are independent
# subprocesses that spend almost all their time off-CPU (the child does the
# work), so a small pool turns the total scan time from the *sum* of engine
# runtimes into roughly the *slowest* engine's runtime. Bounded so a burst of
# concurrent scan jobs (each already on the broker worker pool) can't fork an
# unbounded number of engine subprocesses.
ENGINE_PARALLELISM = max(1, settings_db.resolve_int(
    "broker.engine_parallelism", os.environ.get("TM_BROKER_ENGINE_PARALLELISM"), 4))

# Ruleset passed to opengrep/semgrep --config. "auto" pulls the community
# ruleset from the registry over the network; point TM_BROKER_OPENGREP_RULES at
# a local rules dir/file for an air-gapped scan. `broker/rules/opengrep` ships a
# small offline starter pack — set the env var to that path (or drop rules in
# and the resolver will prefer it) to keep private repos fully on-network.
OPENGREP_RULES = settings_db.resolve_str(
    "broker.opengrep_rules", os.environ.get("TM_BROKER_OPENGREP_RULES"), "").strip()
BUNDLED_OPENGREP_RULES = Path(__file__).resolve().parent / "rules" / "opengrep"


def _dir_has_rules(path: Path) -> bool:
    try:
        return path.is_dir() and any(
            p.suffix.lower() in (".yml", ".yaml") for p in path.iterdir())
    except OSError:
        return False


# Bare "--config auto" pulls the *entire* community registry regardless of what
# languages the target repo actually contains — a JS-only repo still gets
# Python/Django/Ruby/etc. rule packs loaded, and framework-specific rules like
# django-no-csrf-token pattern-match on generic `{% %}` template tag syntax
# that Swig/Nunjucks/Jinja2 all share, so they fire on non-Django templates too.
# When we know the target's languages (a real scan, not just a status query),
# request only the packs for languages actually present so irrelevant rule
# families never load in the first place.
_LANG_TO_REGISTRY_PACK = {
    "js": "p/javascript", "ts": "p/typescript", "py": "p/python",
    "java": "p/java", "go": "p/golang", "php": "p/php", "ruby": "p/ruby",
    "csharp": "p/csharp", "kotlin": "p/kotlin", "scala": "p/scala",
    "c": "p/c", "cpp": "p/cpp",
}


def resolve_opengrep_config(langs: set | None = None) -> list[str]:
    """The `--config` value(s) for opengrep/semgrep (one `--config` per entry).

    Resolution order (first wins): an explicit ``TM_BROKER_OPENGREP_RULES``
    override; the bundled offline starter pack if it actually contains rule
    files; a registry pack per language actually detected in the scan target
    (when `langs` is given and maps to at least one known pack); otherwise
    ``["auto"]`` (the full registry, network) — the original behaviour, kept
    as the fallback so passing no `langs` (e.g. a generic status query, or an
    unrecognized language) never regresses coverage.
    """
    if OPENGREP_RULES:
        return [OPENGREP_RULES]
    if _dir_has_rules(BUNDLED_OPENGREP_RULES):
        return [str(BUNDLED_OPENGREP_RULES)]
    if langs:
        packs = sorted({_LANG_TO_REGISTRY_PACK[l] for l in langs if l in _LANG_TO_REGISTRY_PACK})
        if packs:
            return packs
    return ["auto"]


def opengrep_rules_are_local(langs: set | None = None) -> bool:
    """True when opengrep will read rules from disk (no registry/network call)."""
    cfgs = resolve_opengrep_config(langs)
    return all(c != "auto" and not c.startswith(("p/", "r/", "http://", "https://"))
               for c in cfgs)

# ── Concurrency ───────────────────────────────────────────────────────────────
# Scans run on a bounded worker pool so a burst of webhooks can't fan out into
# unlimited threads (each forking git + a scan subprocess).
BROKER_WORKERS = max(1, settings_db.resolve_int(
    "broker.workers", os.environ.get("TM_BROKER_WORKERS"), 3))

# ── Clone policy ──────────────────────────────────────────────────────────────
# file:// (local-path read) and plain http (cleartext) clones are off by default;
# an optional host allowlist further constrains which git hosts may be cloned.
ALLOW_FILE_SCHEME = settings_db.resolve_bool(
    "broker.allow_file_scheme", os.environ.get("TM_BROKER_ALLOW_FILE"), False)
ALLOW_HTTP_SCHEME = settings_db.resolve_bool(
    "broker.allow_http_scheme", os.environ.get("TM_BROKER_ALLOW_HTTP"), False)
ALLOWED_GIT_HOSTS = settings_db.resolve_set(
    "broker.allowed_git_hosts", os.environ.get("TM_BROKER_ALLOWED_HOSTS"))

# ── Workspace retention ───────────────────────────────────────────────────────
WORKSPACE_TTL_DAYS = settings_db.resolve_int(
    "broker.workspace_ttl_days", os.environ.get("TM_BROKER_WORKSPACE_TTL_DAYS"), 30)

# ── PR delta gating ───────────────────────────────────────────────────────────
# When on, a PR's gate/annotations act on findings NEW versus the base branch
# baseline, not the whole backlog. Baselines are captured on pushes.
BASELINE_ENABLED = settings_db.resolve_bool(
    "broker.baseline_enabled", os.environ.get("TM_BROKER_BASELINE"), True)

# ── Scheduled scans ───────────────────────────────────────────────────────────
# Opt-in periodic re-scan of repos carrying a `scan_interval_hours`. Off by
# default so nothing scans without an explicit trigger.
SCHEDULE_ENABLED = settings_db.resolve_bool(
    "broker.schedule_enabled", os.environ.get("TM_BROKER_SCHEDULE"), False)
SCHEDULE_TICK_SECONDS = max(60, settings_db.resolve_int(
    "broker.schedule_tick_seconds", os.environ.get("TM_BROKER_SCHEDULE_TICK"), 300))

# Shared secret required to push a finished report into a remote server via the
# /api/v1/sast/import endpoint. Empty disables remote import (in-process only).
IMPORT_TOKEN = settings_db.resolve_str(
    "broker.import_token", os.environ.get("TM_BROKER_TOKEN"), "")

# Retention for persisted job history.
JOB_RETENTION = settings_db.resolve_int(
    "broker.job_retention", os.environ.get("TM_BROKER_JOB_RETENTION"), 200)

# ── GitHub integration ────────────────────────────────────────────────────────
# Fallback token / webhook secret used when a repo has none of its own. Per-repo
# values (stored in the registry) always win. The token needs repo:status and
# pull-request comment scope; for private repos it is also used to clone.
GITHUB_TOKEN = settings_db.resolve_str(
    "broker.github_token",
    os.environ.get("TM_GITHUB_TOKEN") or os.environ.get("GITHUB_TOKEN"), "")
GITHUB_WEBHOOK_SECRET = settings_db.resolve_str(
    "broker.github_webhook_secret", os.environ.get("TM_GITHUB_WEBHOOK_SECRET"), "")
GITHUB_API_BASE = settings_db.resolve_str(
    "broker.github_api_base", os.environ.get("TM_GITHUB_API_BASE"), "https://api.github.com")
# Severity (inclusive) that fails the PR gate / commit status. High by default.
GITHUB_FAIL_ON = settings_db.resolve_str(
    "broker.github_fail_on", os.environ.get("TM_GITHUB_FAIL_ON"), "High")
# Severity threshold a webhook-triggered scan runs at.
GITHUB_SCAN_SEVERITY = settings_db.resolve_str(
    "broker.github_scan_severity", os.environ.get("TM_GITHUB_SCAN_SEVERITY"), "Low")
# How PR results are reported back:
#   "auto"  (default) — post a rich Check Run with inline file/line annotations;
#                       transparently fall back to a commit Status if the token
#                       can't write checks (a classic PAT gets 403 — only a
#                       GitHub App installation token has checks:write).
#   "1"/"on"/"true"   — force the Checks API (no status fallback).
#   "0"/"off"/"false" — force the legacy commit Status only (no annotations).
GITHUB_USE_CHECKS = settings_db.resolve_str(
    "broker.github_use_checks", os.environ.get("TM_GITHUB_USE_CHECKS"), "auto").strip().lower()
# Inline annotations are capped per check run (GitHub itself accepts 50 per API
# call; we batch but stop here so a noisy scan can't fan out into endless PATCHes).
GITHUB_MAX_ANNOTATIONS = settings_db.resolve_int(
    "broker.github_max_annotations", os.environ.get("TM_GITHUB_MAX_ANNOTATIONS"), 200)
# Also upload findings as SARIF to GitHub code scanning (Security tab), which
# tracks fixed/reopened state natively. Needs a token with security_events scope.
GITHUB_UPLOAD_SARIF = settings_db.resolve_bool(
    "broker.github_upload_sarif", os.environ.get("TM_GITHUB_UPLOAD_SARIF"), False)
# Public base URL of this server, used to build the report link posted to PRs.
# Falls back to the request's own host when blank.
PUBLIC_URL = settings_db.resolve_str(
    "broker.public_url", os.environ.get("TM_PUBLIC_URL"), "")
# Per-repo fields that hold secrets and must never leave the server unredacted.
_REPO_SECRET_KEYS = ("github_token", "webhook_secret")

SEVERITIES = ("Critical", "High", "Medium", "Low", "Info")
SEVERITY_ORDER = {s: i for i, s in enumerate(SEVERITIES)}
# Map a finding severity to a GitHub check-annotation level. GitHub only has
# three: failure (red), warning (yellow), notice (grey).
ANNOTATION_LEVEL = {
    "Critical": "failure", "High": "failure",
    "Medium": "warning",
    "Low": "notice", "Info": "notice",
}


def checks_mode() -> str:
    """Resolve TM_GITHUB_USE_CHECKS to one of: 'auto' | 'force' | 'off'."""
    value = GITHUB_USE_CHECKS
    if value in ("0", "off", "false", "no"):
        return "off"
    if value in ("1", "on", "true", "yes"):
        return "force"
    return "auto"

_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{1,48}$")
_lock = threading.RLock()


# ── Helpers ───────────────────────────────────────────────────────────────────
def slugify(name: str) -> str:
    """Derive a filesystem/URL-safe repo id from a display name."""
    slug = re.sub(r"[^a-z0-9]+", "-", (name or "").strip().lower()).strip("-")
    return slug[:48] or f"repo-{int(time.time())}"


def is_valid_slug(slug: str) -> bool:
    return bool(_SLUG_RE.match(slug or ""))


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


_GH_URL_RE = re.compile(
    r"github\.com[:/]+(?P<owner>[A-Za-z0-9._-]+)/(?P<repo>[A-Za-z0-9._-]+?)(?:\.git)?/?$")


def github_full_name_from_url(url: str) -> str | None:
    """Extract a canonical lowercase 'owner/repo' from a GitHub clone URL.

    Handles https, ssh, and scp-like git@github.com:owner/repo.git forms. Returns
    None for anything that is not a github.com URL (self-hosted is matched only by
    an explicit github_full_name on the repo entry).
    """
    m = _GH_URL_RE.search((url or "").strip())
    return f"{m['owner']}/{m['repo']}".lower() if m else None


def redact_repo(repo: dict) -> dict:
    """Copy of a repo entry safe to return over the API.

    Secret-bearing fields become a boolean '<key>_set' flag so the UI can show
    "configured" without ever shipping the value.
    """
    clean = {k: v for k, v in repo.items() if k not in _REPO_SECRET_KEYS}
    for key in _REPO_SECRET_KEYS:
        clean[f"{key}_set"] = bool(repo.get(key))
    return clean


def find_repo_for_github(full_name: str) -> dict | None:
    """Find the registered repo a GitHub webhook (by owner/repo) belongs to.

    Matches an explicit `github_full_name` first, then falls back to deriving
    owner/repo from each repo's clone URL. Comparison is case-insensitive. Only
    *registered* repos match, preserving the "no arbitrary path/URL" guarantee.
    """
    if not full_name:
        return None
    target = full_name.strip().lower()
    for repo in load_repos():
        explicit = (repo.get("github_full_name") or "").strip().lower()
        if explicit and explicit == target:
            return repo
        if github_full_name_from_url(repo.get("url", "")) == target:
            return repo
    return None


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default
    except (OSError, ValueError):
        return default


def _write_json(path: Path, data) -> None:
    """Atomic write: a partial/failed write never replaces a good file.

    Delegates to the shared store so every JSON write gets fsync + a retrying
    os.replace (rides out Windows sharing violations) from one place.
    """
    import report_store
    report_store.atomic_write_json(path, data)


def _backup(fn, *args) -> None:
    """Best-effort JSON mirror of a DB write. Never allowed to fail the save."""
    try:
        fn(*args)
    except Exception:  # pragma: no cover - defensive
        import logging
        logging.getLogger("broker").warning("JSON backup write failed", exc_info=True)


# ── Repo registry ─────────────────────────────────────────────────────────────
# SQLite (broker.db, see broker/db.py) is the system of record; every write
# here also mirrors to the legacy repos.json/jobs.json/baseline files/
# sha_cache.json as a best-effort, human-readable backup.
def load_repos() -> list[dict]:
    from . import db
    with _lock:
        return db.load_repos()


def save_repos(repos: list[dict]) -> None:
    from . import db
    with _lock:
        db.save_repos(repos)
        _backup(_write_json, REPOS_PATH, repos)


def get_repo(repo_id: str) -> dict | None:
    return next((r for r in load_repos() if r.get("id") == repo_id), None)


def upsert_repo(entry: dict) -> dict:
    from . import db
    with _lock:
        db.upsert_repo(entry)
        _backup(_write_json, REPOS_PATH, db.load_repos())
        return entry


def remove_repo(repo_id: str) -> bool:
    from . import db
    with _lock:
        removed = db.remove_repo(repo_id)
        if removed:
            _backup(_write_json, REPOS_PATH, db.load_repos())
        return removed


# ── Job history (persisted across restarts) ───────────────────────────────────
def load_jobs() -> list[dict]:
    from . import db
    with _lock:
        return db.load_jobs()


def save_jobs(jobs: list[dict]) -> None:
    from . import db
    with _lock:
        trimmed = jobs[:JOB_RETENTION]
        db.save_jobs(trimmed)
        _backup(_write_json, JOBS_PATH, trimmed)


def clear_job_history() -> int:
    """Wipe job history, PR-delta baselines, and the scanned-SHA cache (both
    the DB and their legacy JSON mirrors); leaves the repo registry alone.
    Returns the number of jobs removed. Callers that also hold an in-memory
    BrokerService must clear its ``_jobs`` dict themselves — this only
    touches persistence."""
    from . import db
    with _lock:
        n = db.clear_history()
        _backup(_write_json, JOBS_PATH, [])
        _backup(_write_json, SHA_CACHE_PATH, {})
        for f in BASELINE_DIR.glob("*.json"):
            try:
                f.unlink()
            except OSError:
                pass
    return n


# ── Baselines (per repo + branch fingerprint sets) ────────────────────────────
def _baseline_path(repo_id: str, branch: str) -> Path:
    key = re.sub(r"[^a-z0-9]+", "-", f"{repo_id}__{branch}".lower()).strip("-") or "baseline"
    return BASELINE_DIR / f"{key[:120]}.json"


def load_baseline(repo_id: str, branch: str) -> set:
    from . import db
    with _lock:
        return db.load_baseline(repo_id, branch)


def save_baseline(repo_id: str, branch: str, fingerprints: set) -> None:
    from . import db
    with _lock:
        db.save_baseline(repo_id, branch, fingerprints)
        _backup(_write_json, _baseline_path(repo_id, branch), sorted(fingerprints))


# ── Scanned-SHA cache (repo_id + sha -> report_id) ────────────────────────────
def sha_cache_get(repo_id: str, sha: str) -> str | None:
    from . import db
    if not repo_id or not sha:
        return None
    with _lock:
        return db.sha_cache_get(repo_id, sha)


def sha_cache_put(repo_id: str, sha: str, report_id: str) -> None:
    from . import db
    if not (repo_id and sha and report_id):
        return
    with _lock:
        db.sha_cache_put(repo_id, sha, report_id)
        # Legacy backup file is capped the same way the old in-process cache
        # was, using the DB's own bounded set as the source of truth.
        cache = _read_json(SHA_CACHE_PATH, {})
        if not isinstance(cache, dict):
            cache = {}
        cache[f"{repo_id}:{sha}"] = report_id
        if len(cache) > 2000:
            cache = dict(list(cache.items())[-2000:])
        _backup(_write_json, SHA_CACHE_PATH, cache)


# ── Workspace retention ───────────────────────────────────────────────────────
def prune_stale_workspaces(max_age_days: int | None = None) -> list[str]:
    """Remove clone workspaces untouched for longer than the TTL. Returns ids.

    A workspace for a still-registered repo is kept regardless of age (it is the
    warm clone the next scan refreshes); only orphaned/idle trees are swept.
    """
    import shutil
    import time as _time
    ttl = (WORKSPACE_TTL_DAYS if max_age_days is None else max_age_days)
    if ttl <= 0 or not WORKSPACE_DIR.exists():
        return []
    live = {r.get("id") for r in load_repos()}
    cutoff = _time.time() - ttl * 86400
    removed = []
    for child in WORKSPACE_DIR.iterdir():
        if not child.is_dir() or child.name in live:
            continue
        try:
            if child.stat().st_mtime < cutoff:
                shutil.rmtree(child, ignore_errors=True)
                removed.append(child.name)
        except OSError:
            continue
    return removed
