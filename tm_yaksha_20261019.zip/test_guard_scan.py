"""Tests for guard.scan — diff-scoped codemodel findings.

The key property under test: a finding is only reported when its *own*
file:line (the sink call, not the enclosing route's def line) was added by
the diff — pre-existing debt elsewhere in a touched file must never block.
"""
from __future__ import annotations

import os
import tempfile
import unittest

from guard import scan as guard_scan

FLASK_APP = '''
import os, sqlite3
from flask import Flask, request
app = Flask(__name__)

@app.route("/public/search")
def search():
    q = request.args.get("q")
    sqlite3.connect("a.db").execute("SELECT * FROM u WHERE n='%s'" % q)
    return "ok"

@app.route("/hook", methods=["POST"])
def hook():
    os.system("sh " + request.form["c"])
    return "ok"

SECRET_KEY = "hardcoded-super-secret-value"
'''


def _write_fixture(src=FLASK_APP):
    d = tempfile.mkdtemp(prefix="guard_scan_test_")
    path = os.path.join(d, "app.py")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(src)
    return d, path


class TestScanDiff(unittest.TestCase):
    def setUp(self):
        self.repo, self.path = _write_fixture()

    def test_sink_line_marked_added_is_reported(self):
        # The os.system(...) call is on its own real source line — find it precisely.
        line = next(i + 1 for i, l in enumerate(FLASK_APP.splitlines())
                    if "os.system" in l)
        added = {"app.py": {line}}
        findings = guard_scan.scan_diff(self.repo, added)
        self.assertTrue(any(f.family == "command-injection" for f in findings))
        hit = next(f for f in findings if f.family == "command-injection")
        self.assertEqual(hit.line, line)
        self.assertEqual(hit.severity, "Critical")   # unauth + tainted command-injection

    def test_sink_not_in_added_lines_is_not_reported(self):
        # Simulate touching the file elsewhere (e.g. a docstring tweak) without
        # touching the vulnerable line — pre-existing debt must not surface.
        added = {"app.py": {1}}   # line 1 is blank/import, not the sink
        findings = guard_scan.scan_diff(self.repo, added)
        self.assertEqual(findings, [])

    def test_entry_point_def_line_alone_does_not_falsely_ground_a_sink_finding(self):
        """Regression: an earlier design used the entry point's def line as the
        finding's locus. Editing an *existing* route to add a new dangerous line
        without touching its def line must still be caught — via the sink's own
        line, not the handler's.
        """
        hook_def_line = next(i + 1 for i, l in enumerate(FLASK_APP.splitlines())
                             if "def hook" in l)
        sink_line = next(i + 1 for i, l in enumerate(FLASK_APP.splitlines())
                         if "os.system" in l)
        self.assertNotEqual(hook_def_line, sink_line)
        # Only the sink line was added; the def line was untouched.
        added = {"app.py": {sink_line}}
        findings = guard_scan.scan_diff(self.repo, added)
        self.assertTrue(any(f.line == sink_line for f in findings))

    def test_unrelated_file_in_added_lines_finds_nothing(self):
        added = {"other.py": {1, 2, 3}}
        findings = guard_scan.scan_diff(self.repo, added)
        self.assertEqual(findings, [])

    def test_hardcoded_secret_reported_only_when_its_own_line_added(self):
        secret_line = next(i + 1 for i, l in enumerate(FLASK_APP.splitlines())
                           if "SECRET_KEY" in l)
        added = {"app.py": {secret_line}}
        findings = guard_scan.scan_diff(self.repo, added)
        self.assertTrue(any(f.family == "sensitive-data-exposure" for f in findings))

        added_elsewhere = {"app.py": {1}}
        findings2 = guard_scan.scan_diff(self.repo, added_elsewhere)
        self.assertFalse(any(f.family == "sensitive-data-exposure" for f in findings2))

    def test_empty_added_lines_map_finds_nothing(self):
        findings = guard_scan.scan_diff(self.repo, {})
        self.assertEqual(findings, [])

    def test_new_unauthenticated_endpoint_reaching_a_preexisting_sink_is_still_flagged(self):
        """Regression: the auth-gap fallback used to gate on
        `not ep.reachable_sinks`, so a brand-new unauthenticated POST route
        that calls into an already-existing helper's dangerous sink got no
        finding at all — the sink loop correctly skipped the sink (its line
        wasn't touched by this diff), and the fallback wrongly assumed
        "has reachable sinks" meant "already covered".
        """
        src = (
            'import os\n'
            'from flask import Flask, request\n'
            'app = Flask(__name__)\n'
            '\n'
            'def run_shell(cmd):\n'          # line 5 — pre-existing, NOT in diff
            '    os.system(cmd)\n'           # line 6 — pre-existing sink, NOT in diff
            '\n'
            '@app.route("/new-hook", methods=["POST"])\n'   # line 8 — new
            'def new_hook():\n'                              # line 9 — new
            '    run_shell(request.form["c"])\n'             # line 10 — new
            '    return "ok"\n'
        )
        repo, _ = _write_fixture(src)
        # Only the new route's own lines were added; the sink/helper predate this diff.
        added = {"app.py": {8, 9, 10}}
        findings = guard_scan.scan_diff(repo, added)
        self.assertTrue(
            any(f.family == "broken-access-control" and f.line == 9 for f in findings),
            f"expected an unauthenticated-endpoint finding on the new route's def line, got: {findings}",
        )
        # And the pre-existing sink itself must NOT be reported (out of diff scope).
        self.assertFalse(any(f.family == "command-injection" for f in findings))

    def test_findings_sorted_worst_severity_first(self):
        q_line = next(i + 1 for i, l in enumerate(FLASK_APP.splitlines())
                     if "execute" in l)
        os_line = next(i + 1 for i, l in enumerate(FLASK_APP.splitlines())
                      if "os.system" in l)
        added = {"app.py": {q_line, os_line}}
        findings = guard_scan.scan_diff(self.repo, added)
        self.assertGreaterEqual(len(findings), 2)
        severities = [f.severity for f in findings]
        order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
        self.assertEqual(severities, sorted(severities, key=lambda s: order[s]))


if __name__ == "__main__":
    unittest.main()
