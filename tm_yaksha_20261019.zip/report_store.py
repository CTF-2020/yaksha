"""Crash-safe, corruption-tolerant persistence for the report store.

Every write is atomic (write a sibling temp file, flush+fsync, then ``os.replace``
onto the target) so a crash or a concurrent reader never sees a half-written
file — the previous complete version survives instead. The report index, which
gates the orphan-prune that deletes report files, additionally keeps a rotating
set of backups and is validated on read, so a single corrupt write can never
cascade into mass data loss (the failure mode that motivated this module).

Path-agnostic and Flask-free so it can be unit-tested against a temp directory.
"""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path

# On Windows os.replace raises PermissionError (WinError 5) when another handle
# briefly holds the target — antivirus, the search indexer, or a concurrent
# reader. The rename is still the right atomic primitive; it just needs a few
# retries to ride out that transient sharing violation instead of turning a
# routine save into a hard failure (the class of bug behind the past data loss).
_REPLACE_RETRIES = 10
_REPLACE_BACKOFF = 0.05   # seconds, grows linearly per attempt


def atomic_replace(src, dst) -> None:
    """os.replace(src, dst) with bounded retries for Windows sharing violations."""
    last: OSError | None = None
    for attempt in range(_REPLACE_RETRIES):
        try:
            os.replace(src, dst)
            return
        except PermissionError as exc:   # WinError 5 / 32 — target momentarily locked
            last = exc
            time.sleep(_REPLACE_BACKOFF * (attempt + 1))
    # Exhausted retries: raise the real error so the caller can surface it.
    raise last if last is not None else OSError(f"could not replace {dst}")


def atomic_write_text(path, text: str, encoding: str = "utf-8") -> None:
    """Write ``text`` to ``path`` atomically (temp file + fsync + os.replace)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding=encoding, newline="") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        atomic_replace(tmp, path)   # atomic on POSIX and Windows for same-volume paths
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def atomic_write_json(path, obj) -> None:
    atomic_write_text(path, json.dumps(obj, indent=2))


def read_json(path, default=None):
    """Read JSON tolerantly (BOM-safe); return ``default`` on any failure."""
    path = Path(path)
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return default


# ── Index-specific durability ────────────────────────────────────────────────
_BACKUP_KEEP = 5


def _backup_paths(index_path: Path):
    return [index_path.with_suffix(index_path.suffix + f".bak{i}")
            for i in range(1, _BACKUP_KEEP + 1)]


def rotate_index_backup(index_path) -> None:
    """Rotate ``_index.json`` -> ``.bak1`` (newest) .. ``.bakN`` before overwrite.

    Only a *valid, non-empty* current index is promoted to a backup, so a good
    snapshot is never overwritten by a corrupt or empty one.
    """
    index_path = Path(index_path)
    current = read_json(index_path, default=None)
    if not isinstance(current, list) or not current:
        return
    baks = _backup_paths(index_path)
    for older, newer in zip(reversed(baks[1:]), reversed(baks[:-1])):
        if newer.exists():
            try:
                atomic_replace(newer, older)
            except OSError:
                pass
    try:
        atomic_write_text(baks[0], json.dumps(current, indent=2))
    except OSError:
        pass


def newest_valid_backup(index_path):
    """Return the parsed contents of the newest non-empty valid backup, or None."""
    for bak in _backup_paths(Path(index_path)):
        data = read_json(bak, default=None)
        if isinstance(data, list) and data:
            return data
    return None


def save_index(index_path, entries: list) -> None:
    """Persist the index atomically, keeping a rotating backup of the prior good one."""
    rotate_index_backup(index_path)
    atomic_write_json(index_path, entries)


def load_index(index_path) -> list:
    """Load the index, self-healing from a backup if the primary is corrupt.

    A missing file is a legitimate empty index (returns ``[]``); a *present but
    unparseable* file is corruption, so we fall back to the newest valid backup
    rather than reporting empty — because an empty index would authorize the
    orphan-prune to delete every report file.
    """
    index_path = Path(index_path)
    if not index_path.exists():
        return []
    data = read_json(index_path, default=None)
    if isinstance(data, list):
        return data
    recovered = newest_valid_backup(index_path)
    return recovered if recovered is not None else []
