"""Broker orchestration: bounded worker pool, report persistence, delta gating.

Scans are submitted to a bounded pool of worker threads (not one thread per
request) so a burst of webhooks can't fan out into unlimited git+scan
subprocesses. Each job is mirrored to ~/.tm_broker/jobs.json so history survives
a restart, and the finished report is saved through the host app's own
`_save_report`, which is what makes it appear in the existing report list/viewer.

Extras layered on the base scan/report flow:
  * a per-(repo, sha) cache so the same commit isn't re-scanned (push + PR
    synchronize commonly arrive together);
  * PR *delta* gating — a pull request is gated on findings NEW versus the base
    branch baseline, captured on pushes, not the whole backlog;
  * a metrics view and an opt-in scheduler for periodic re-scans;
  * on manual scans, an auto-built code-derived architecture model (entry
    points, trust boundaries, data stores) over the same checkout, so the
    Visualiser's Architecture map has real data by default instead of
    requiring a separate trip through the Code Model page.
"""
from __future__ import annotations

import queue
import threading
import time
import traceback
from pathlib import Path

from . import config, delta, engines, github, mapper, pr_tm, reviewer, scanner


class BrokerService:
    def __init__(self) -> None:
        self._jobs: dict[str, dict] = {}
        self._lock = threading.RLock()
        # Per-repo locks serialize workspace access: two scans of the same repo
        # would otherwise run `git fetch`/`reset --hard` in the same clone dir
        # concurrently and race on index.lock / corrupt the checkout.
        self._repo_locks: dict[str, threading.Lock] = {}
        self._repo_locks_guard = threading.Lock()
        # Bounded worker pool. Started lazily on first submit so merely
        # constructing the service (e.g. in a unit test) spawns no threads.
        self._queue: "queue.Queue[tuple]" = queue.Queue()
        self._workers: list[threading.Thread] = []
        self._workers_started = False
        self._scheduler_started = False
        # Monotonic counter so job ids stay unique even for many scans in the
        # same second (token_hex(3) alone collides under bursts — birthday bound).
        self._id_seq = 0
        # Warm the in-memory view from persisted history so the dashboard isn't
        # blank after a restart.
        for job in config.load_jobs():
            self._jobs[job["id"]] = job

    # ── Worker pool ───────────────────────────────────────────────────────────
    def _ensure_workers(self) -> None:
        with self._lock:
            if self._workers_started:
                return
            self._workers_started = True
            for i in range(config.BROKER_WORKERS):
                t = threading.Thread(target=self._worker_loop, name=f"broker-worker-{i}",
                                     daemon=True)
                t.start()
                self._workers.append(t)

    def _worker_loop(self) -> None:
        while True:
            job_id, repo, severity, ref, gh_ctx = self._queue.get()
            try:
                self._run(job_id, repo, severity, ref, gh_ctx)
            except Exception:  # a worker must never die on a job failure
                import logging
                logging.getLogger("broker").error("worker crashed\n%s",
                                                   traceback.format_exc())
            finally:
                self._queue.task_done()

    # ── Job bookkeeping ───────────────────────────────────────────────────────
    def _new_job_id(self) -> str:
        import secrets
        with self._lock:
            self._id_seq += 1
            seq = self._id_seq
        # timestamp + in-process counter (no intra-process collision) + random
        # (covers a restart landing in the same second): globally unique per scan.
        return f"scan_{int(time.time())}_{seq}_{secrets.token_hex(4)}"

    def _repo_lock(self, repo_id: str) -> threading.Lock:
        """Return the (lazily created) workspace lock for one repo id."""
        with self._repo_locks_guard:
            lock = self._repo_locks.get(repo_id)
            if lock is None:
                lock = threading.Lock()
                self._repo_locks[repo_id] = lock
            return lock

    def _persist(self) -> None:
        with self._lock:
            ordered = sorted(self._jobs.values(),
                             key=lambda j: j.get("started_at", ""), reverse=True)
            config.save_jobs(ordered)

    def reset_job_history(self) -> int:
        """Admin flush: drop every job from memory and persistence (baselines,
        sha cache) so the dashboard reflects empty state immediately, without
        waiting for a process restart to pick up the on-disk clear."""
        with self._lock:
            n = len(self._jobs)
            self._jobs.clear()
        config.clear_job_history()
        return n

    def delete_job(self, job_id: str) -> bool:
        """Remove one job from history (memory + persistence). Safe to call on
        a queued/running job -- its worker only ever looks the id back up
        through ``_update``/``_log``, which are no-ops once it's gone; the
        report it may already have produced is untouched, a separate delete."""
        with self._lock:
            existed = self._jobs.pop(job_id, None) is not None
        if existed:
            self._persist()
        return existed

    def _update(self, job_id: str, **fields) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return
            job.update(fields)
        self._persist()

    def _log(self, job_id: str, message: str) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is not None:
                job.setdefault("log", []).append(f"{config.now_iso()}  {message}")
                job["log"] = job["log"][-50:]
                job["progress"] = message

    # ── Public API ────────────────────────────────────────────────────────────
    def list_jobs(self, limit: int = 100) -> list[dict]:
        with self._lock:
            jobs = sorted(self._jobs.values(),
                          key=lambda j: j.get("started_at", ""), reverse=True)
        return [self._public_view(j) for j in jobs[:limit]]

    def get_job(self, job_id: str) -> dict | None:
        with self._lock:
            job = self._jobs.get(job_id)
            return self._public_view(job) if job else None

    @staticmethod
    def _public_view(job: dict) -> dict:
        # Everything is already JSON-safe; copy so callers can't mutate state.
        return dict(job)

    def _find_inflight(self, repo_id, kind, sha, pr_number) -> str | None:
        """Return the id of an already queued/running scan for the same event.

        GitHub delivers webhooks at-least-once, so a redelivery (same repo + event
        kind + commit + PR number) would otherwise launch a second concurrent scan
        and post a duplicate gate signal. The key deliberately includes kind and
        PR number so a push and a pull_request for the *same* sha stay distinct —
        they do different work (baseline capture vs PR gating).
        """
        with self._lock:
            for job in self._jobs.values():
                if (job.get("repo_id") == repo_id
                        and job.get("status") in ("queued", "running")
                        and job.get("trigger") == kind
                        and job.get("commit") == sha
                        and job.get("pr_number") == pr_number):
                    return job["id"]
        return None

    def submit_scan(self, repo: dict, severity: str = "Low",
                    ref: str | None = None, gh_ctx: dict | None = None) -> str:
        if severity not in config.SEVERITY_ORDER:
            severity = "Low"
        gh = gh_ctx or {}
        # The inflight check and the job insertion must be one atomic critical
        # section — self._lock is an RLock, so _find_inflight's own internal
        # `with self._lock` nests safely here. Checking and inserting under two
        # separate acquisitions left a window where two concurrent submits (e.g.
        # a redelivered GitHub webhook handled by two worker threads) could both
        # see "nothing inflight" and both enqueue a duplicate scan.
        with self._lock:
            existing = self._find_inflight(repo.get("id"), gh.get("kind", "manual"),
                                           gh.get("sha"), gh.get("number"))
            if existing:
                return existing
            job_id = self._new_job_id()
            job = {
                "id": job_id,
                "repo_id": repo.get("id"),
                "repo_name": repo.get("name"),
                "severity": severity,
                "status": "queued",
                "progress": "Queued",
                "started_at": config.now_iso(),
                "finished_at": None,
                "report_id": None,
                "stats": None,
                "error": None,
                "log": [],
                # GitHub context (no secrets) so the dashboard can show the trigger.
                "trigger": (gh_ctx or {}).get("kind", "manual"),
                "pr_number": (gh_ctx or {}).get("number"),
                "commit": (gh_ctx or {}).get("sha"),
            }
            self._jobs[job_id] = job
        self._ensure_workers()
        self._persist()
        self._queue.put((job_id, repo, severity, ref, gh_ctx))
        return job_id

    # ── Worker body ───────────────────────────────────────────────────────────
    def _run(self, job_id: str, repo: dict, severity: str,
             ref: str | None = None, gh_ctx: dict | None = None) -> None:
        report = report_id = None
        findings: list[dict] = []
        scan_root = None
        try:
            self._update(job_id, status="running")

            # Skip re-scanning a commit already scanned (push + PR often coincide).
            sha = (gh_ctx or {}).get("sha")
            cached = config.sha_cache_get(repo.get("id") or "", sha)
            if cached and self._reuse_cached(job_id, repo, gh_ctx, cached):
                return

            # Serialize workspace prep + scan per repo so concurrent jobs for the
            # same clone can't corrupt each other's git working tree.
            lock = self._repo_lock(repo.get("id") or "")
            if not lock.acquire(blocking=False):
                self._log(job_id, "Waiting: another scan of this repo is in progress")
                lock.acquire()
            try:
                self._log(job_id, "Preparing workspace")
                scan_root, meta = scanner.prepare_workspace(
                    repo, progress=lambda m: self._log(job_id, m), ref=ref)

                self._log(job_id, "Running scan engine")
                findings = scanner.run_scan(scan_root, severity)

                # Multi-language pass: external open-source engines (Opengrep,
                # Gosec, njsscan, Bandit) that are installed and match the
                # repo's languages. Their findings join the same stream, so
                # delta gating and GitHub annotations cover them too.
                ext_findings, ext_meta = engines.run_engines(
                    scan_root, severity, progress=lambda m: self._log(job_id, m))
                findings, _ = engines.merge_with_builtin(
                    findings, ext_findings, emit=lambda m: self._log(job_id, m))
                if ext_meta:
                    meta = {**meta, "engines": ext_meta}

                # Reviewer pass: judge each finding in its enclosing function —
                # local taint flow, exploitability verdict, suggested fix diff —
                # so the report reads like a PR review, not a grep dump. Runs
                # while the workspace lock still guarantees the checkout the
                # findings refer to. Best-effort: never fails the scan.
                try:
                    n_rev = reviewer.review_findings(scan_root, findings)
                    if n_rev:
                        self._log(job_id, f"Reviewed {n_rev} finding(s) in code context")
                except Exception as exc:
                    self._log(job_id, f"Review pass skipped: {exc}")

                # PR-scoped threat model over just the changed files — a
                # design-level verdict for the PR without a full-repo pass.
                # Best-effort: a failure here never fails the scan job.
                if (gh_ctx or {}).get("kind") == "pull_request" and pr_tm.enabled(repo):
                    try:
                        self._log(job_id, "Building PR threat model (changed files only)")
                        tm_info = pr_tm.run(scan_root, repo, gh_ctx, self._save_report,
                                            log=lambda m: self._log(job_id, m))
                        if tm_info:
                            self._update(job_id, tm_report_id=tm_info["report_id"])
                            self._log(job_id, f"PR threat model saved: {tm_info['report_id']}"
                                              f" ({tm_info['files']} changed file(s))")
                    except Exception as exc:
                        self._log(job_id, f"PR threat model skipped: {exc}")

                # Code-derived architecture model over the same checkout —
                # entry points, trust boundaries, data stores, reachable
                # sinks. Manual scans only: this is for the person about to
                # open the report, not every push/PR webhook, so it can't
                # add cost or report-history noise to unattended CI runs.
                # Reuses scan_root (no second clone). Best-effort, same as
                # the PR threat model above: never fails the scan job.
                if not gh_ctx:
                    try:
                        self._log(job_id, "Building code-derived architecture model")
                        from codemodel import service as codemodel_service
                        cm_report = codemodel_service.analyze_path(str(scan_root), repo, meta)
                        cm_report_id = self._save_report(cm_report)
                        self._update(job_id, codemodel_report_id=cm_report_id)
                        self._log(job_id, f"Code model saved: {cm_report_id}")
                    except Exception as exc:
                        self._log(job_id, f"Code model skipped: {exc}")
            finally:
                lock.release()
            self._log(job_id, f"Scan complete: {len(findings)} finding(s)")

            report = mapper.findings_to_report(findings, repo, meta, severity)
            report_id = self._save_report(report)
            self._log(job_id, f"Report saved: {report_id}")
            if sha:
                config.sha_cache_put(repo.get("id") or "", sha, report_id)

            gate_findings, delta_info = self._apply_delta(job_id, repo, ref, gh_ctx, findings)

            stats = report["scan_metadata"]
            self._update(
                job_id, status="done", finished_at=config.now_iso(),
                report_id=report_id, progress="Done",
                delta=delta_info,
                stats={
                    "findings_total": stats["findings_total"],
                    "rules_triggered": stats["rules_triggered"],
                    "severity_counts": stats["severity_counts"],
                    "overall_risk": report["overall_risk"],
                    "new_findings": None if delta_info is None else delta_info["new"],
                },
            )
            self._record_last_scan(repo["id"], report_id, report["overall_risk"],
                                   stats["findings_total"])
            self._report_to_github(job_id, repo, gh_ctx, report, report_id, None,
                                   findings=findings, scan_root=scan_root,
                                   gate_findings=gate_findings, delta=delta_info)
        except Exception as exc:  # surface any failure to the dashboard
            self._log(job_id, f"ERROR: {exc}")
            self._update(job_id, status="error", finished_at=config.now_iso(),
                         progress="Failed", error=str(exc))
            self._report_to_github(job_id, repo, gh_ctx, None, None, str(exc))
            import logging
            logging.getLogger("broker").error("scan job %s failed\n%s",
                                               job_id, traceback.format_exc())

    def _reuse_cached(self, job_id: str, repo: dict, gh_ctx: dict | None,
                      report_id: str) -> bool:
        """Reuse a prior report for an already-scanned SHA. Returns True on hit."""
        report = self._load_saved_report(report_id)
        if not report:
            return False  # cache entry is stale; fall through to a fresh scan
        self._log(job_id, f"Commit already scanned — reusing report {report_id}")
        stats = report.get("scan_metadata", {})
        self._update(
            job_id, status="done", finished_at=config.now_iso(),
            report_id=report_id, progress="Done (cached)",
            stats={
                "findings_total": stats.get("findings_total", 0),
                "rules_triggered": stats.get("rules_triggered", 0),
                "severity_counts": stats.get("severity_counts", {}),
                "overall_risk": report.get("overall_risk", "Info"),
                "cached": True,
            })
        self._record_last_scan(repo.get("id"), report_id,
                               report.get("overall_risk", "Info"),
                               stats.get("findings_total", 0))
        # Post the (annotation-free) verdict for this commit/PR context.
        self._report_to_github(job_id, repo, gh_ctx, report, report_id, None)
        return True

    def _apply_delta(self, job_id: str, repo: dict, ref: str | None,
                     gh_ctx: dict | None, findings: list[dict]):
        """Capture/consult the base-branch baseline for PR delta gating.

        On a push, record the branch's baseline fingerprints. On a pull request,
        split findings into new-vs-known against the base branch baseline and
        return the new ones as what the gate should act on.
        """
        if not (config.BASELINE_ENABLED and gh_ctx):
            return findings, None
        kind = gh_ctx.get("kind")
        if kind == "push":
            branch = _branch_from_ref(ref) or "(default)"
            fps = delta.fingerprints(findings)
            config.save_baseline(repo["id"], branch, fps)
            if not repo.get("branch") or repo.get("branch") == branch:
                config.save_baseline(repo["id"], "(default)", fps)
            self._log(job_id, f"Baseline updated for {branch} ({len(fps)} fingerprint(s))")
            return findings, None
        if kind == "pull_request":
            # Prefer the PR's real target branch (from the webhook) over the
            # repo's configured default, so the diff is against the right baseline.
            base = gh_ctx.get("base_branch") or repo.get("branch") or "(default)"
            baseline = config.load_baseline(repo["id"], base)
            if not baseline:
                return findings, None
            new, known = delta.partition_new(findings, baseline)
            self._log(job_id, f"Delta vs {base}: {len(new)} new, {len(known)} pre-existing")
            return new, {"new": len(new), "known": len(known), "base": base}
        return findings, None

    def _report_to_github(self, job_id: str, repo: dict, gh_ctx: dict | None,
                          report: dict | None, report_id: str | None,
                          error: str | None, findings=None, scan_root=None,
                          gate_findings=None, delta=None) -> None:
        """Post status/comment/SARIF back to GitHub for a webhook-triggered scan."""
        if not gh_ctx or gh_ctx.get("kind") not in ("push", "pull_request"):
            return
        try:
            github.report_to_pr(repo, gh_ctx, report, report_id, error,
                                findings=findings, scan_root=scan_root,
                                gate_findings=gate_findings, delta=delta,
                                log=lambda m: self._log(job_id, m))
            self._persist()
        except Exception as exc:  # never let reporting fail the job
            self._log(job_id, f"GitHub reporting raised: {exc}")

    @staticmethod
    def _save_report(report: dict) -> str:
        """Persist via the host app so the report joins the existing UI list."""
        import app as tm_app  # imported lazily to avoid a circular import at load
        return tm_app._save_report(report, report["title"])

    @staticmethod
    def _load_saved_report(report_id: str) -> dict | None:
        import json
        path = Path.home() / ".tm_reports" / f"{report_id}.json"
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def _record_last_scan(self, repo_id: str, report_id: str,
                          risk: str, findings: int) -> None:
        repo = config.get_repo(repo_id)
        if not repo:
            return
        repo["last_scan"] = {
            "report_id": report_id, "risk": risk,
            "findings": findings, "at": config.now_iso(),
        }
        config.upsert_repo(repo)

    # ── Metrics ───────────────────────────────────────────────────────────────
    def metrics(self) -> dict:
        """Per-repo scan counts and a recent findings/risk trend (newest first)."""
        per_repo: dict = {}
        total_scans = 0
        for j in self.list_jobs(limit=1000):
            if j.get("status") != "done" or not j.get("stats"):
                continue
            total_scans += 1
            rid = j.get("repo_id")
            st = j["stats"]
            d = per_repo.setdefault(rid, {
                "repo_id": rid, "repo_name": j.get("repo_name"),
                "scans": 0, "last_findings": None, "last_risk": None, "trend": []})
            d["scans"] += 1
            if len(d["trend"]) < 20:
                d["trend"].append({
                    "at": j.get("finished_at"),
                    "findings": st.get("findings_total"),
                    "risk": st.get("overall_risk"),
                    "new": st.get("new_findings"),
                })
        for d in per_repo.values():
            if d["trend"]:                       # list_jobs is newest-first
                d["last_findings"] = d["trend"][0]["findings"]
                d["last_risk"] = d["trend"][0]["risk"]
        return {"repos": list(per_repo.values()), "total_scans": total_scans}

    # ── Scheduled scans (opt-in) ──────────────────────────────────────────────
    @staticmethod
    def due_repos(repos: list[dict], now_epoch: float) -> list[dict]:
        """Repos whose `scan_interval_hours` has elapsed since their last scan."""
        import calendar
        due = []
        for r in repos:
            interval = r.get("scan_interval_hours")
            if not interval:
                continue
            last = (r.get("last_scan") or {}).get("at")
            if not last:
                due.append(r)
                continue
            try:
                t = calendar.timegm(time.strptime(last, "%Y-%m-%dT%H:%M:%SZ"))
            except (ValueError, TypeError):
                due.append(r)
                continue
            if now_epoch - t >= float(interval) * 3600:
                due.append(r)
        return due

    def tick_scheduler(self) -> list[str]:
        """Enqueue any repos due for a scheduled scan; return the job ids."""
        jobs = []
        for repo in self.due_repos(config.load_repos(), time.time()):
            if repo.get("enabled", True):
                jobs.append(self.submit_scan(repo, config.GITHUB_SCAN_SEVERITY))
        return jobs

    def start_scheduler(self) -> None:
        if not config.SCHEDULE_ENABLED:
            return
        with self._lock:
            if self._scheduler_started:
                return
            self._scheduler_started = True

        def loop():
            while True:
                time.sleep(config.SCHEDULE_TICK_SECONDS)
                try:
                    self.tick_scheduler()
                except Exception:  # a bad tick must not kill the scheduler
                    import logging
                    logging.getLogger("broker").error("scheduler tick failed\n%s",
                                                       traceback.format_exc())

        threading.Thread(target=loop, name="broker-scheduler", daemon=True).start()

    # ── Remote-push path (standalone broker -> server) ────────────────────────
    def import_report(self, report: dict) -> str:
        """Save a finished report produced by an out-of-process broker."""
        if not isinstance(report.get("categories"), list):
            raise ValueError("report must include a categories list")
        report.setdefault("methodology", "sast")
        report.setdefault("methodology_label", "Static Application Security Testing")
        report.setdefault("analyzed_at", config.now_iso())
        report["title"] = report.get("title") or "SAST · imported"
        return self._save_report(report)


def _branch_from_ref(ref: str | None) -> str | None:
    """Branch name from a `refs/heads/<branch>` push ref, else None."""
    if ref and ref.startswith("refs/heads/"):
        return ref.split("/", 2)[-1]
    return None


_service: BrokerService | None = None
_service_lock = threading.Lock()


def get_service() -> BrokerService:
    global _service
    with _service_lock:
        if _service is None:
            _service = BrokerService()
            _service.start_scheduler()
    return _service
