"""One-button pipeline: SAST + code-model then correlation.

Prepares a registered repo's working tree once, runs the static analyzers over
it, saves each report, then runs the correlation engine across them — so a single call yields the cross-source
verdict the correlator was built for (confirmed-exploitable / corroborated /
design-gap / blind-spot) instead of four reports a human has to reconcile.

Synchronous by design: it is an internal, operator-triggered action over a repo
that is usually local. The static phase runs under the broker's per-repo
workspace lock so it never races a concurrent scan of the same repo.
"""
from __future__ import annotations


def run(repo: dict, severity: str = "Low", ref: str | None = None,
        progress=lambda m: None) -> dict:
    """Run the full pipeline for a repo dict and return the report ids + steps."""
    import app as tm_app
    import codemodel
    import correlator
    from broker import engines
    from broker import mapper as sast_mapper
    from broker import scanner, service

    report_ids: list[str] = []
    steps: list[dict] = []

    # Static phase shares one prepared workspace; serialize it against any live
    # broker scan of the same repo via the shared per-repo lock.
    lock = service.get_service()._repo_lock(repo.get("id") or "")
    with lock:
        progress("Preparing workspace")
        scan_root, meta = scanner.prepare_workspace(
            repo, progress=progress, ref=ref)

        progress("Running SAST")
        findings = scanner.run_scan(scan_root, severity)
        ext_findings, ext_meta = engines.run_engines(scan_root, severity,
                                                     progress=progress)
        findings, _ = engines.merge_with_builtin(findings, ext_findings, emit=progress)
        if ext_meta:
            meta = {**meta, "engines": ext_meta}
        try:                                    # reviewer pass — same as broker scans
            from broker import reviewer
            reviewer.review_findings(scan_root, findings)
        except Exception:
            pass
        sast_report = sast_mapper.findings_to_report(findings, repo, meta, severity)
        sid = tm_app._save_report(sast_report, sast_report["title"])
        report_ids.append(sid)
        steps.append({"stage": "sast", "report_id": sid, "findings": len(findings)})

        progress("Running code model")
        cm_report = codemodel.service.analyze_path(str(scan_root), repo, {"source": meta})
        cid = tm_app._save_report(cm_report, cm_report["title"])
        report_ids.append(cid)
        steps.append({"stage": "codemodel", "report_id": cid,
                      "findings": len(cm_report.get("categories", []))})

    progress("Correlating")
    corr = correlator.service.run(
        report_ids, title=f"Pipeline · {repo.get('name', repo.get('id', 'repo'))}")
    corr_id = tm_app._save_report(corr, corr["title"])
    steps.append({"stage": "correlation", "report_id": corr_id,
                  "clusters": len(corr.get("categories", []))})

    return {
        "repo_id": repo.get("id"),
        "reports": report_ids,
        "correlation_report_id": corr_id,
        "steps": steps,
    }
