"""guard/scan.py — diff-scoped code security scan for the pre-merge gate.

Reuses ``codemodel`` (pure Python, no external binary — guaranteed available
wherever TM itself runs, unlike the SAST broker's external engines which
depend on Opengrep/Gosec/njsscan/Bandit being on PATH) to find reachable
dangerous sinks, hardcoded secrets, and access-control gaps. The model is
built over the *whole* repo — sink reachability needs real call-graph
context — but every finding is then filtered down to the file:line the diff
actually added, via :mod:`guard.diff`. That filter is what turns a full
codemodel scan into a *gate*: it blocks the vulnerability a change is
introducing, not pre-existing debt in a file the change happens to touch.

Findings are built directly from :class:`codemodel.model.SystemModel` (the
sink's own file:line), not from ``codemodel.threats.derive()``'s report
categories — those report the *entry point's* file:line for a reachable-sink
finding, which is the route's ``def`` line, not the dangerous call's line. A
diff that adds a new line inside an already-existing route would be invisible
under that locus, silently passing the gate. Sink-level loci don't have that
blind spot.

Known limitation: this only sees additions. Removing an existing auth check
or validation call shows up as a ``-`` line, which carries no new-side line
number, so a diff that *deletes* a control is not caught here — that needs a
before/after structural diff (the same shape as ``arch_drift``), which is a
larger feature than a fast pre-commit gate should take on.
"""
from __future__ import annotations

from dataclasses import dataclass

from codemodel import extractor
from codemodel.threats import _FAMILY_TITLE, _REMEDIATION, _SINK_SEVERITY

_SEV_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
_STATE_CHANGING = {"POST", "PUT", "PATCH", "DELETE"}


@dataclass
class GuardFinding:
    severity: str
    family: str
    title: str
    file: str
    line: int
    description: str
    cwe: str
    remediation: str


def _sink_severity(family: str, tainted: bool, unauthenticated: bool) -> str:
    base = _SINK_SEVERITY.get(family, "Medium")
    if tainted and base == "Medium":
        base = "High"
    if unauthenticated:
        base = "Critical" if base == "High" else base
        if base == "Medium":
            base = "High"
    return base


def _title(family: str) -> str:
    return _FAMILY_TITLE.get(family, family.replace("-", " ").title())


def scan_diff(repo_root: str, added_lines: dict[str, set[int]]) -> list[GuardFinding]:
    """Findings from ``repo_root`` whose file:line was added by this diff."""
    model = extractor.build_model(repo_root)
    findings: list[GuardFinding] = []

    for ep in model.entry_points:
        ep_sink_finding = False
        for s in ep.reachable_sinks:
            if s.line not in added_lines.get(s.file, ()):
                continue
            ep_sink_finding = True
            severity = _sink_severity(s.family, s.tainted, not ep.authenticated)
            reach = ("invokable by the LLM/agent runtime with no observed argument "
                     "constraint" if ep.kind == "agent-tool" else
                     "reachable without authentication" if not ep.authenticated
                     else "reachable behind an auth control")
            findings.append(GuardFinding(
                severity=severity, family=s.family, title=_title(s.family),
                file=s.file, line=s.line,
                description=f"{ep.locus} reaches {s.family} sink '{s.name}' - {reach}"
                            + (" with an attacker-controlled argument." if s.tainted else "."),
                cwe=s.cwe,
                remediation=_REMEDIATION.get(s.family, "Review and remediate this sink."),
            ))

        # Fires whenever no sink-level finding was actually emitted for this
        # endpoint above — either because it has no reachable sinks at all, or
        # because its reachable sinks are pre-existing code the diff didn't
        # touch (so the loop above correctly skipped them). Gating on
        # `not ep.reachable_sinks` instead would miss a brand-new
        # unauthenticated endpoint that calls into an already-reviewed sink.
        if (not ep_sink_finding and not ep.authenticated
                and ep.line in added_lines.get(ep.file, ())
                and (ep.method in _STATE_CHANGING or ep.method == "*")):
            findings.append(GuardFinding(
                severity="High", family="broken-access-control",
                title="Unauthenticated state-changing endpoint",
                file=ep.file, line=ep.line,
                description=f"'{ep.handler}' ({ep.locus}) has no observable authentication "
                            "or authorization control.",
                cwe="", remediation="Enforce authentication and authorization on this endpoint.",
            ))

    for secret in model.secrets:
        if secret.managed or secret.line not in added_lines.get(secret.file, ()):
            continue
        findings.append(GuardFinding(
            severity="High", family="sensitive-data-exposure", title="Hardcoded secret",
            file=secret.file, line=secret.line,
            description=f"Secret '{secret.name}' appears hardcoded in source/config.",
            cwe="CWE-798",
            remediation="Move secrets to a secret manager / environment; rotate exposed ones.",
        ))

    findings.sort(key=lambda f: (_SEV_ORDER.get(f.severity, 9), f.file, f.line))
    return findings
