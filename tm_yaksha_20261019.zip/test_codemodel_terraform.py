"""Tests for codemodel/terraform_extractor.py.

Run:  python -m unittest test_codemodel_terraform   (stdlib only)
"""
from __future__ import annotations

import os
import tempfile
import unittest

from codemodel import extractor, terraform_extractor as tf, threats
from codemodel.model import SystemModel


def _misconfigs(source: str, rel: str = "main.tf") -> list:
    model = SystemModel()
    tf.extract(source, rel, model)
    return [c for c in model.controls if c.kind == "cloud-misconfig"]


class S3BucketTests(unittest.TestCase):
    def test_public_acl_flagged(self):
        src = '''
resource "aws_s3_bucket" "logs" {
  bucket = "my-logs"
  acl    = "public-read"
}
'''
        misconfigs = _misconfigs(src)
        self.assertEqual(len(misconfigs), 2)  # public ACL + missing encryption
        self.assertTrue(any("public ACL" in c.mechanism for c in misconfigs))

    def test_private_acl_not_flagged(self):
        src = '''
resource "aws_s3_bucket" "logs" {
  bucket = "my-logs"
  acl    = "private"
}
'''
        misconfigs = _misconfigs(src)
        self.assertFalse(any("public ACL" in c.mechanism for c in misconfigs))

    def test_missing_encryption_flagged(self):
        src = '''
resource "aws_s3_bucket" "logs" {
  bucket = "my-logs"
}
'''
        misconfigs = _misconfigs(src)
        self.assertTrue(any("no server-side encryption" in c.mechanism for c in misconfigs))

    def test_encryption_resource_in_same_file_clears_the_flag(self):
        src = '''
resource "aws_s3_bucket" "logs" {
  bucket = "my-logs"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "logs" {
  bucket = aws_s3_bucket.logs.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}
'''
        misconfigs = _misconfigs(src)
        self.assertFalse(any("no server-side encryption" in c.mechanism for c in misconfigs))

    def test_bucket_registered_as_data_store(self):
        model = SystemModel()
        tf.extract('resource "aws_s3_bucket" "logs" { bucket = "my-logs" }', "main.tf", model)
        self.assertTrue(any(d.kind == "object-storage" and d.engine == "s3"
                             for d in model.data_stores))


class SecurityGroupTests(unittest.TestCase):
    def test_open_ingress_in_security_group_flagged(self):
        src = '''
resource "aws_security_group" "web" {
  name = "web"
  ingress {
    from_port   = 0
    to_port     = 65535
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
'''
        misconfigs = _misconfigs(src)
        self.assertTrue(any("allows ingress from 0.0.0.0/0" in c.mechanism for c in misconfigs))

    def test_scoped_ingress_not_flagged(self):
        src = '''
resource "aws_security_group" "web" {
  name = "web"
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }
}
'''
        self.assertEqual(_misconfigs(src), [])

    def test_security_group_rule_open_ingress_flagged(self):
        src = '''
resource "aws_security_group_rule" "allow_all_in" {
  type        = "ingress"
  from_port   = 0
  to_port     = 0
  protocol    = "-1"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.web.id
}
'''
        misconfigs = _misconfigs(src)
        self.assertTrue(any("allows ingress" in c.mechanism for c in misconfigs))

    def test_security_group_rule_open_egress_not_flagged_as_ingress(self):
        src = '''
resource "aws_security_group_rule" "allow_all_out" {
  type        = "egress"
  from_port   = 0
  to_port     = 0
  protocol    = "-1"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.web.id
}
'''
        self.assertEqual(_misconfigs(src), [])


class IamPolicyTests(unittest.TestCase):
    def test_wildcard_action_flagged(self):
        src = '''
resource "aws_iam_policy" "admin" {
  name = "admin"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "*"
      Resource = "arn:aws:s3:::my-bucket/*"
    }]
  })
}
'''
        misconfigs = _misconfigs(src)
        self.assertTrue(any("wildcard" in c.mechanism for c in misconfigs))

    def test_scoped_policy_not_flagged(self):
        src = '''
resource "aws_iam_policy" "reader" {
  name = "reader"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "s3:GetObject"
      Resource = "arn:aws:s3:::my-bucket/*"
    }]
  })
}
'''
        self.assertEqual(_misconfigs(src), [])


class ProviderCredentialTests(unittest.TestCase):
    def test_hardcoded_credentials_flagged_as_secret(self):
        src = '''
provider "aws" {
  region     = "us-east-1"
  access_key = "AKIAIOSFODNN7EXAMPLE"
  secret_key = "wJalrXUtnFEMIK7MDENGbPxRfiCYEXAMPLEKEY"
}
'''
        model = SystemModel()
        tf.extract(src, "provider.tf", model)
        names = {s.name for s in model.secrets}
        self.assertIn("aws provider access_key", names)
        self.assertIn("aws provider secret_key", names)
        self.assertTrue(all(not s.managed for s in model.secrets))

    def test_variable_reference_not_flagged_as_hardcoded(self):
        src = '''
provider "aws" {
  region     = "us-east-1"
  access_key = var.aws_access_key
  secret_key = "${var.aws_secret_key}"
}
'''
        model = SystemModel()
        tf.extract(src, "provider.tf", model)
        self.assertEqual(model.secrets, [])


class PublicDatabaseTests(unittest.TestCase):
    def test_publicly_accessible_rds_flagged(self):
        src = '''
resource "aws_db_instance" "primary" {
  engine             = "postgres"
  publicly_accessible = true
}
'''
        misconfigs = _misconfigs(src)
        self.assertTrue(any("publicly accessible" in c.mechanism for c in misconfigs))
        model = SystemModel()
        tf.extract(src, "main.tf", model)
        self.assertTrue(any(d.kind == "sql" and d.engine == "rds" for d in model.data_stores))

    def test_non_public_rds_not_flagged(self):
        src = '''
resource "aws_db_instance" "primary" {
  engine             = "postgres"
  publicly_accessible = false
}
'''
        self.assertEqual(_misconfigs(src), [])


class NonResourceFileTests(unittest.TestCase):
    def test_variables_only_file_is_a_no_op(self):
        src = '''
variable "region" {
  type    = string
  default = "us-east-1"
}
'''
        model = SystemModel()
        tf.extract(src, "variables.tf", model)
        self.assertEqual(model.controls, [])
        self.assertEqual(model.data_stores, [])
        self.assertEqual(model.secrets, [])


class ThreatDerivationIntegrationTests(unittest.TestCase):
    def _cats(self, source: str, filename: str = "main.tf"):
        d = tempfile.mkdtemp(prefix="cm_tf_")
        with open(os.path.join(d, filename), "w", encoding="utf-8") as fh:
            fh.write(source)
        return threats.derive(extractor.build_model(d))

    def test_public_bucket_surfaces_as_security_misconfig_family(self):
        src = '''
resource "aws_s3_bucket" "logs" {
  bucket = "my-logs"
  acl    = "public-read"
}
'''
        cats = self._cats(src)
        misconfig = next(c for c in cats if c["family"] == "security-misconfig"
                          and "Terraform" in c["name"])
        self.assertEqual(misconfig["_source"], "CODEMODEL")
        self.assertIn("public ACL", " ".join(misconfig["affected_components"]))

    def test_hardcoded_provider_credentials_surface_as_existing_secrets_section(self):
        # No new threats.py logic needed for this one -- the existing "hardcoded
        # secrets" section (fed by model.secrets) already covers it.
        src = '''
provider "aws" {
  access_key = "AKIAIOSFODNN7EXAMPLE"
  secret_key = "wJalrXUtnFEMIK7MDENGbPxRfiCYEXAMPLEKEY"
}
'''
        cats = self._cats(src)
        self.assertTrue(any(c["family"] == "sensitive-data-exposure" for c in cats))

    def test_clean_terraform_file_produces_no_findings(self):
        src = '''
resource "aws_s3_bucket" "logs" {
  bucket = "my-logs"
  acl    = "private"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "logs" {
  bucket = aws_s3_bucket.logs.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}
'''
        cats = self._cats(src)
        self.assertEqual(cats, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
