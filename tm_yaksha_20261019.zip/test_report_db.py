"""Tests for the SQLite report read-model (report_db) + its query endpoints.

The pure-module tests isolate onto a temp DB; the API tests exercise the live
app path (save -> mirror -> trend/finding queries) against the real store and
assert only that what they just saved is queryable, so they are order- and
data-independent.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import report_db


def _report(rid, methodology, cats, title="R", target_meta=None):
    r = {"id": rid, "title": title, "methodology": methodology,
         "overall_risk": cats[0]["risk"] if cats else "Info",
         "analyzed_at": "2026-07-17T00:00:00Z", "categories": cats}
    if target_meta:
        r["scan_metadata"] = target_meta
    return r


def _cat(cid, name, risk, cwe="", owasp="", loci=None, verdict=None, ssvc_action=None):
    cat = {"id": cid, "name": name, "title": name, "risk": risk,
           "cwe": cwe, "owasp": owasp, "_source": "SAST",
           "threats": [{"name": l} for l in (loci or [])],
           "affected_components": loci or []}
    if verdict:
        cat["verdict"] = verdict
    if ssvc_action:
        cat["ssvc_action"] = ssvc_action
    return cat


class TestReportDbModule(unittest.TestCase):
    def setUp(self):
        # Isolate onto a temp DB, and restore the real global afterwards so the
        # live-app API tests (and any later suite) keep using the real store.
        # No need to reset any "already initialized" flag — init() tracks
        # initialization per-path now, so a fresh temp path is always new.
        self._orig_path = report_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()

    def _restore(self):
        report_db.DB_PATH = self._orig_path

    def test_upsert_and_count(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel", [_cat("R1", "SQL Injection", "Critical",
                                       cwe="CWE-89", loci=["db.py:10"])]))
        self.assertEqual(report_db.report_count(), 1)

    def test_findings_classified_to_family(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel", [_cat("R1", "SQL Injection", "High",
                                       cwe="CWE-89", loci=["db.py:10", "db.py:20"])]))
        rows = report_db.search_findings(family="sql-injection")
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["family"], "sql-injection")
        self.assertEqual(rows[0]["cwe"], "CWE-89")
        self.assertEqual({r["line"] for r in rows}, {10, 20})

    def test_delete_all_wipes_reports_and_findings(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel", [_cat("R1", "SQL Injection", "High", cwe="CWE-89")]))
        report_db.upsert_report(_report("100_1_bb", "sast", []))
        self.assertEqual(report_db.delete_all(), 2)
        self.assertEqual(report_db.report_count(), 0)
        self.assertEqual(report_db.search_findings(family="sql-injection"), [])

    def test_delete_all_is_safe_with_no_reports(self):
        self.assertEqual(report_db.delete_all(), 0)

    def test_upsert_replaces_findings_not_duplicates(self):
        rep = _report("100_1_aa", "codemodel",
                      [_cat("R1", "SQL Injection", "High", cwe="CWE-89",
                            loci=["db.py:10"])])
        report_db.upsert_report(rep)
        report_db.upsert_report(rep)   # same id again
        self.assertEqual(report_db.report_count(), 1)
        self.assertEqual(len(report_db.search_findings(family="sql-injection")), 1)

    def test_delete_cascades_findings(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel", [_cat("R1", "XSS", "Medium", cwe="CWE-79",
                                       loci=["view.py:5"])]))
        report_db.delete_report("100_1_aa")
        self.assertEqual(report_db.report_count(), 0)
        self.assertEqual(report_db.search_findings(), [])

    def test_search_by_severity_and_cwe(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQL Injection", "Critical", cwe="CWE-89", loci=["a.py:1"]),
             _cat("R2", "Weak Hash", "Low", cwe="CWE-328", loci=["b.py:2"])]))
        self.assertEqual(len(report_db.search_findings(severity="Critical")), 1)
        self.assertEqual(len(report_db.search_findings(cwe="328")), 1)

    def test_verdict_is_stored_and_searchable(self):
        report_db.upsert_report(_report(
            "100_1_aa", "correlation",
            [_cat("R1", "SQL Injection", "Critical", cwe="CWE-89", loci=["a.py:1"],
                  verdict="confirmed_exploitable"),
             _cat("R2", "SSRF", "Medium", cwe="CWE-918", loci=["b.py:2"],
                  verdict="design_gap")]))
        confirmed = report_db.search_findings(verdict="confirmed_exploitable")
        self.assertEqual(len(confirmed), 1)
        self.assertEqual(confirmed[0]["family"], "sql-injection")
        self.assertEqual(confirmed[0]["verdict"], "confirmed_exploitable")
        self.assertEqual(len(report_db.search_findings(verdict="design_gap")), 1)
        self.assertEqual(report_db.search_findings(verdict="blind_spot"), [])

    def test_ssvc_action_is_stored_and_searchable(self):
        report_db.upsert_report(_report(
            "100_1_aa", "correlation",
            [_cat("R1", "SQL Injection", "Critical", cwe="CWE-89", loci=["a.py:1"],
                  verdict="confirmed_exploitable", ssvc_action="act"),
             _cat("R2", "SSRF", "Medium", cwe="CWE-918", loci=["b.py:2"],
                  verdict="design_gap", ssvc_action="track")]))
        acted = report_db.search_findings(ssvc_action="act")
        self.assertEqual(len(acted), 1)
        self.assertEqual(acted[0]["family"], "sql-injection")
        self.assertEqual(acted[0]["ssvc_action"], "act")
        self.assertEqual(len(report_db.search_findings(ssvc_action="track")), 1)
        self.assertEqual(report_db.search_findings(ssvc_action="attend"), [])

    def test_finding_without_ssvc_action_stores_empty_string_not_null(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQL Injection", "High", cwe="CWE-89", loci=["a.py:1"])]))
        rows = report_db.search_findings(family="sql-injection")
        self.assertEqual(rows[0]["ssvc_action"], "")
        self.assertEqual(len(report_db.search_findings(ssvc_action="")), 1)
        self.assertEqual(len(report_db.search_findings(ssvc_action=None)), 1)

    def test_finding_without_verdict_stores_empty_string_not_null(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQL Injection", "High", cwe="CWE-89", loci=["a.py:1"])]))
        rows = report_db.search_findings(family="sql-injection")
        self.assertEqual(rows[0]["verdict"], "")
        # explicit verdict="" filter finds the never-correlated finding
        self.assertEqual(len(report_db.search_findings(verdict="")), 1)
        # verdict=None (the default) leaves the filter off entirely
        self.assertEqual(len(report_db.search_findings(verdict=None)), 1)

    def test_verdict_survives_upsert_replace(self):
        rep = _report("100_1_aa", "correlation",
                      [_cat("R1", "SQLi", "Critical", cwe="CWE-89", loci=["a.py:1"],
                            verdict="confirmed_exploitable")])
        report_db.upsert_report(rep)
        report_db.upsert_report(rep)   # re-save, same id
        self.assertEqual(len(report_db.search_findings(verdict="confirmed_exploitable")), 1)

    def test_old_database_without_verdict_column_migrates_cleanly(self):
        # Simulate a pre-existing install: a findings table with the old
        # column set, created before verdict existed.
        import sqlite3
        conn = sqlite3.connect(str(report_db.DB_PATH))
        conn.executescript("""
            DROP TABLE IF EXISTS findings;
            CREATE TABLE findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                report_id TEXT NOT NULL,
                rule TEXT, title TEXT, family TEXT, severity TEXT,
                cwe TEXT, owasp TEXT, source TEXT, locus TEXT, path TEXT, line INTEGER
            );
        """)
        conn.commit()
        conn.close()

        report_db.init()   # must migrate in place, not raise
        report_db.upsert_report(_report(
            "100_1_aa", "correlation",
            [_cat("R1", "SQLi", "Critical", cwe="CWE-89", loci=["a.py:1"],
                  verdict="confirmed_exploitable")]))
        rows = report_db.search_findings(verdict="confirmed_exploitable")
        self.assertEqual(len(rows), 1)

    def test_fingerprint_stored_and_stable_across_loci(self):
        # The finding-scope suppression story depends on every locus row
        # derived from ONE category sharing that category's fingerprint (all
        # loci folded in), not a per-locus one -- see suppressions.matches_row.
        from suppressions.engine import finding_fingerprint
        cat = _cat("R1", "SQL Injection", "High", cwe="CWE-89",
                   loci=["db.py:10", "db.py:20"])
        report_db.upsert_report(_report("100_1_aa", "codemodel", [cat]))
        rows = report_db.search_findings(family="sql-injection")
        self.assertEqual(len(rows), 2)
        expected_fp = finding_fingerprint(cat)
        self.assertEqual(rows[0]["fingerprint"], expected_fp)
        self.assertEqual(rows[1]["fingerprint"], expected_fp)

    def test_old_database_without_fingerprint_column_migrates_cleanly(self):
        import sqlite3
        conn = sqlite3.connect(str(report_db.DB_PATH))
        conn.executescript("""
            DROP TABLE IF EXISTS findings;
            CREATE TABLE findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                report_id TEXT NOT NULL,
                rule TEXT, title TEXT, family TEXT, severity TEXT,
                cwe TEXT, owasp TEXT, source TEXT, locus TEXT, path TEXT, line INTEGER,
                verdict TEXT DEFAULT ''
            );
        """)
        conn.commit()
        conn.close()

        report_db.init()   # must migrate in place, not raise
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQLi", "Critical", cwe="CWE-89", loci=["a.py:1"])]))
        rows = report_db.search_findings(family="sql-injection")
        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["fingerprint"])

    def test_old_database_without_ssvc_action_column_migrates_cleanly(self):
        import sqlite3
        conn = sqlite3.connect(str(report_db.DB_PATH))
        conn.executescript("""
            DROP TABLE IF EXISTS findings;
            CREATE TABLE findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                report_id TEXT NOT NULL,
                rule TEXT, title TEXT, family TEXT, severity TEXT,
                cwe TEXT, owasp TEXT, source TEXT, locus TEXT, path TEXT, line INTEGER,
                verdict TEXT DEFAULT '', fingerprint TEXT DEFAULT ''
            );
        """)
        conn.commit()
        conn.close()

        report_db.init()   # must migrate in place, not raise
        report_db.upsert_report(_report(
            "100_1_aa", "correlation",
            [_cat("R1", "SQLi", "Critical", cwe="CWE-89", loci=["a.py:1"], ssvc_action="act")]))
        rows = report_db.search_findings(family="sql-injection")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["ssvc_action"], "act")

    def test_methodologies_lists_every_distinct_value_unfiltered(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel", [_cat("R1", "SQLi", "High", loci=["a.py:1"])]))
        report_db.upsert_report(_report(
            "200_1_bb", "sast", [_cat("R2", "XSS", "Medium", loci=["b.py:2"])]))
        methods = {m["methodology"]: m["total"] for m in report_db.methodologies()}
        self.assertEqual(methods.get("codemodel"), 1)
        self.assertEqual(methods.get("sast"), 1)

    def test_search_findings_text_filter(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQL Injection", "Critical", cwe="CWE-89", loci=["a.py:1"]),
             _cat("R2", "Weak Hash", "Low", cwe="CWE-328", loci=["b.py:2"])]))
        rows = report_db.search_findings(text="Weak")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["title"], "Weak Hash")

    def test_trends_severity_counts(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQL Injection", "Critical", cwe="CWE-89", loci=["a.py:1"]),
             _cat("R2", "XSS", "High", cwe="CWE-79", loci=["b.py:2", "c.py:3"])]))
        report_db.upsert_report(_report(
            "200_1_bb", "offline",
            [_cat("R3", "Open Redirect", "Medium", cwe="CWE-601", loci=["/go?u="])]))
        rows = report_db.trends()
        self.assertEqual(len(rows), 2)
        # Newest first: created_at 200 > 100.
        self.assertEqual(rows[0]["id"], "200_1_bb")
        first = next(r for r in rows if r["id"] == "100_1_aa")
        self.assertEqual(first["severity_counts"]["Critical"], 1)
        self.assertEqual(first["severity_counts"]["High"], 2)
        self.assertEqual(first["total"], 3)

    def test_trends_methodology_filter(self):
        report_db.upsert_report(_report("100_1_aa", "codemodel",
                                        [_cat("R1", "SQLi", "High", cwe="CWE-89",
                                              loci=["a.py:1"])]))
        report_db.upsert_report(_report("200_1_bb", "offline",
                                        [_cat("R2", "XSS", "High", cwe="CWE-79",
                                              loci=["/x"])]))
        self.assertEqual([r["id"] for r in report_db.trends(methodology="offline")],
                         ["200_1_bb"])

    def test_verdict_trends_grouped_per_correlation_report(self):
        report_db.upsert_report(_report(
            "100_1_aa", "correlation",
            [_cat("R1", "SQL Injection", "Critical", cwe="CWE-89", loci=["a.py:1"],
                  verdict="confirmed_exploitable"),
             _cat("R2", "SSRF", "Medium", cwe="CWE-918", loci=["b.py:2"],
                  verdict="blind_spot")]))
        report_db.upsert_report(_report(
            "200_1_bb", "correlation",
            [_cat("R3", "XSS", "High", cwe="CWE-79", loci=["c.py:3"],
                  verdict="corroborated")]))
        rows = report_db.verdict_trends()
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["id"], "200_1_bb")   # newest first
        first = next(r for r in rows if r["id"] == "100_1_aa")
        self.assertEqual(first["verdict_counts"]["confirmed_exploitable"], 1)
        self.assertEqual(first["verdict_counts"]["blind_spot"], 1)
        self.assertEqual(first["total"], 2)

    def test_verdict_trends_excludes_non_correlation_reports(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQLi", "High", cwe="CWE-89", loci=["a.py:1"])]))
        self.assertEqual(report_db.verdict_trends(), [])

    def test_verdict_trends_tracks_unverdicted_separately(self):
        report_db.upsert_report(_report(
            "100_1_aa", "correlation",
            [_cat("R1", "SQLi", "High", cwe="CWE-89", loci=["a.py:1"]),   # no verdict
             _cat("R2", "SSRF", "Medium", cwe="CWE-918", loci=["b.py:2"],
                  verdict="design_gap")]))
        rows = report_db.verdict_trends()
        self.assertEqual(rows[0]["unverdicted"], 1)
        self.assertEqual(rows[0]["verdict_counts"]["design_gap"], 1)
        self.assertEqual(rows[0]["total"], 1)   # unverdicted not counted in total

    def test_target_extracted_from_scan_metadata(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQLi", "High", cwe="CWE-89", loci=["a.py:1"])],
            target_meta={"repo_name": "acme/widgets"}))
        rows = report_db.trends(target="acme/widgets")
        self.assertEqual(len(rows), 1)

    def test_family_summary(self):
        report_db.upsert_report(_report(
            "100_1_aa", "codemodel",
            [_cat("R1", "SQL Injection", "Critical", cwe="CWE-89",
                  loci=["a.py:1", "a.py:2"]),
             _cat("R2", "Weak Hash", "Low", cwe="CWE-328", loci=["b.py:2"])]))
        summary = {r["family"]: r for r in report_db.family_summary()}
        self.assertEqual(summary["sql-injection"]["total"], 2)
        self.assertEqual(summary["sql-injection"]["high_plus"], 2)
        # Worst (high_plus) family sorts first.
        self.assertEqual(report_db.family_summary()[0]["family"], "sql-injection")

    def test_backfill_is_idempotent(self):
        reps = [_report("100_1_aa", "codemodel",
                        [_cat("R1", "SQLi", "High", cwe="CWE-89", loci=["a.py:1"])])]
        self.assertEqual(report_db.backfill(reps), 1)
        report_db.backfill(reps)   # again
        self.assertEqual(report_db.report_count(), 1)


class TestReportDbApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        # Save a distinctive report through the real app path so it mirrors.
        report = _report(
            "x", "codemodel",
            [_cat("DBTEST-RULE", "Command Injection", "Critical",
                  cwe="CWE-78", loci=["dbtest/run.py:7"])],
            title="report_db api fixture")
        cls.rid = tm_app._save_report(report, report["title"])

    @classmethod
    def tearDownClass(cls):
        cls.client.delete(f"/api/v1/reports/{cls.rid}",
                          headers={"X-CSRF-Token": cls.csrf})

    def test_trends_endpoint_lists_saved_report(self):
        d = self.client.get("/api/v1/reports/trends?methodology=codemodel").get_json()
        self.assertTrue(d["success"])
        ids = [t["id"] for t in d["trends"]]
        self.assertIn(self.rid, ids)
        row = next(t for t in d["trends"] if t["id"] == self.rid)
        self.assertEqual(row["severity_counts"]["Critical"], 1)

    def test_findings_search_endpoint(self):
        d = self.client.get(
            "/api/v1/reports/findings/search?family=command-injection").get_json()
        self.assertTrue(d["success"])
        loci = [f["locus"] for f in d["findings"]]
        self.assertIn("dbtest/run.py:7", loci)

    def test_findings_search_endpoint_filters_by_verdict(self):
        # The fixture report has no verdict at all -> stored as "".
        d = self.client.get(
            "/api/v1/reports/findings/search?family=command-injection&verdict=").get_json()
        self.assertTrue(d["success"])
        loci = [f["locus"] for f in d["findings"]]
        self.assertIn("dbtest/run.py:7", loci)

        d2 = self.client.get(
            "/api/v1/reports/findings/search?family=command-injection"
            "&verdict=confirmed_exploitable").get_json()
        self.assertEqual(d2["findings"], [])

    def test_families_endpoint(self):
        d = self.client.get("/api/v1/reports/families").get_json()
        self.assertTrue(d["success"])
        fams = {f["family"] for f in d["families"]}
        self.assertIn("command-injection", fams)

    def test_verdict_trend_endpoint(self):
        report = _report(
            "y", "correlation",
            [_cat("VTREND-RULE", "SQL Injection", "Critical", cwe="CWE-89",
                  loci=["vtrend/db.py:1"], verdict="confirmed_exploitable")],
            title="verdict trend api fixture")
        report["id"] = "vtrend_fixture_1"
        report_db.upsert_report(report)
        try:
            d = self.client.get("/api/v1/correlate/trend").get_json()
            self.assertTrue(d["success"])
            point = next((p for p in d["trend"] if p["id"] == "vtrend_fixture_1"), None)
            self.assertIsNotNone(point)
            self.assertEqual(point["verdict_counts"]["confirmed_exploitable"], 1)
        finally:
            report_db.delete_report("vtrend_fixture_1")


if __name__ == "__main__":
    unittest.main()
