"""Offline pattern catalog API routes."""
from __future__ import annotations

from flask import Blueprint, jsonify

from offline_pattern_enrichment import list_enriched_patterns
from offline_rules import ALL_RULES


bp = Blueprint("patterns_api", __name__, url_prefix="/api/v1/patterns")


@bp.get("")
def list_patterns():
    """List every offline pattern with full analyst context."""
    patterns = list_enriched_patterns(ALL_RULES)
    counts = {name: len(rules) for name, rules in ALL_RULES.items()}
    return jsonify({
        "success": True,
        "rulesets": counts,
        "total": len(patterns),
        "patterns": patterns,
    })


@bp.get("/<ruleset>")
def list_patterns_for_ruleset(ruleset: str):
    """List enriched offline patterns for one ruleset."""
    if ruleset not in ALL_RULES:
        return jsonify({
            "success": False,
            "error": f"Unknown ruleset: {ruleset}",
            "available_rulesets": sorted(ALL_RULES),
        }), 404
    patterns = list_enriched_patterns(ALL_RULES, ruleset)
    return jsonify({
        "success": True,
        "ruleset": ruleset,
        "total": len(patterns),
        "patterns": patterns,
    })


@bp.get("/<ruleset>/<rule_id>")
def get_pattern(ruleset: str, rule_id: str):
    """Fetch one enriched offline pattern."""
    if ruleset not in ALL_RULES:
        return jsonify({
            "success": False,
            "error": f"Unknown ruleset: {ruleset}",
            "available_rulesets": sorted(ALL_RULES),
        }), 404
    for pattern in list_enriched_patterns(ALL_RULES, ruleset):
        if str(pattern.get("id", "")).lower() == rule_id.lower():
            return jsonify({"success": True, "pattern": pattern})
    return jsonify({
        "success": False,
        "error": f"Unknown pattern: {rule_id}",
    }), 404
