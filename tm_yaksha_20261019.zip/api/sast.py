"""SAST broker API + dashboard page.

Routes (CSRF + optional TM_API_KEY apply via the app's global before_request):
  GET    /api/v1/sast                      broker status / engine info
  GET    /api/v1/sast/repos               list registered repos
  POST   /api/v1/sast/repos               register a repo {name,url,branch?}
  DELETE /api/v1/sast/repos/<id>          remove a repo
  POST   /api/v1/sast/repos/<id>/scan     trigger a scan {severity?} -> {job_id}
  POST   /api/v1/sast/repos/<id>/remediation/propose   check + return a fix patch (read-only)
  POST   /api/v1/sast/repos/<id>/remediation/open-pr   open a PR from an approved patch
  GET    /api/v1/sast/remediation/queue   fix-eligible findings across every
                                       remediation-enabled repo, verdict-first
                                       (?repo_id=, ?limit=)
  GET    /api/v1/sast/jobs                list scan jobs
  GET    /api/v1/sast/jobs/<id>           poll one job
  GET    /api/v1/sast/jobs/<id>/events    SSE progress stream
  GET    /api/v1/sast/reports             list SAST scan reports
  GET    /api/v1/sast/reports/<id>        fetch one SAST report
  DELETE /api/v1/sast/reports/<id>        delete a SAST report
  GET    /api/v1/sast/reports/<id>/export/sarif   SARIF 2.1.0 export
  POST   /api/v1/sast/import              push a finished report (X-Broker-Token)
  POST   /api/v1/sast/webhook            GitHub webhook (X-Hub-Signature-256)

  GET    /broker                          dashboard UI (separate, un-prefixed bp)

Scans only ever run against *registered* repos picked by id, so a dashboard user
can never coerce the server into reading an arbitrary filesystem path. The webhook
endpoint is exempt from the app's CSRF/API-key guard (see app.py) and authenticates
instead with a per-repo (or global) HMAC signature.
"""
from __future__ import annotations

import json
import secrets
import time

from flask import Blueprint, Response, jsonify, render_template, request

import app as tm_app
from broker import config, engines, get_service, github
from broker.scanner import ScanError, looks_like_git_url, validate_remote

bp = Blueprint("sast_api", __name__, url_prefix="/api/v1/sast")
page_bp = Blueprint("broker_page", __name__)


@bp.get("")
def status():
    return jsonify({
        "success": True,
        "engine": str(config.SCANNER_PATH),
        "engine_available": config.SCANNER_PATH.exists(),
        "rules": config.SCANNER_RULES or "(engine default)",
        "external_engines": engines.available_engines(),
        "severities": list(config.SEVERITIES),
        "repos": len(config.load_repos()),
        "remote_import_enabled": bool(config.IMPORT_TOKEN),
        "workers": config.BROKER_WORKERS,
        "baseline_gating": config.BASELINE_ENABLED,
        "scheduler": config.SCHEDULE_ENABLED,
        "github": {
            "webhook_url": request.host_url.rstrip("/") + "/api/v1/sast/webhook",
            "global_secret_set": bool(config.GITHUB_WEBHOOK_SECRET),
            "global_token_set": bool(config.GITHUB_TOKEN),
            "fail_on": config.GITHUB_FAIL_ON,
            "scan_severity": config.GITHUB_SCAN_SEVERITY,
            "checks_mode": config.checks_mode(),
        },
    })


# ── Repo registry ─────────────────────────────────────────────────────────────
@bp.get("/repos")
def list_repos():
    repos = [config.redact_repo(r) for r in config.load_repos()]
    return jsonify({"success": True, "repos": repos})


@bp.post("/repos")
def add_repo():
    body = request.get_json(silent=True) or {}
    name = str(body.get("name", "")).strip()
    url = str(body.get("url", "")).strip()
    branch = str(body.get("branch", "")).strip()
    if not name or not url:
        return jsonify({"success": False, "error": "name and url are required"}), 400
    if len(url) > 500 or len(name) > 120:
        return jsonify({"success": False, "error": "name or url too long"}), 400

    # Optional GitHub wiring.
    github_token = str(body.get("github_token", "")).strip()
    webhook_secret = str(body.get("webhook_secret", "")).strip()
    fail_on = str(body.get("fail_on", "")).strip()
    if fail_on and fail_on not in config.SEVERITY_ORDER:
        return jsonify({"success": False, "error": "invalid fail_on severity"}), 400
    github_full_name = (str(body.get("github_full_name", "")).strip().lower()
                        or config.github_full_name_from_url(url) or "")

    # Optional scheduled re-scan interval (hours). 0/blank disables scheduling.
    scan_interval_hours = None
    raw_interval = body.get("scan_interval_hours")
    if raw_interval not in (None, "", 0, "0"):
        try:
            scan_interval_hours = int(raw_interval)
        except (TypeError, ValueError):
            return jsonify({"success": False, "error": "scan_interval_hours must be a number"}), 400
        if scan_interval_hours <= 0 or scan_interval_hours > 24 * 365:
            return jsonify({"success": False, "error": "scan_interval_hours out of range"}), 400

    repo_id = config.slugify(name)
    if not config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "could not derive a valid repo id"}), 400

    # Re-registering the same repo without re-supplying a secret keeps the stored
    # one (the dashboard never receives secrets back, only "<key>_set" flags).
    existing = config.get_repo(repo_id) or {}
    github_token = github_token or existing.get("github_token", "")
    webhook_secret = webhook_secret or existing.get("webhook_secret", "")
    # Explicit opt-in, off by default; a re-register that doesn't mention this
    # field must not silently flip an already-enabled repo back off.
    remediation_enabled = bool(body.get(
        "remediation_enabled", existing.get("remediation_enabled", False)))

    entry = {
        "id": repo_id,
        "name": name,
        "url": url,
        "branch": branch,
        "kind": "git" if looks_like_git_url(url) else "local",
        "enabled": True,
        "added_at": config.now_iso(),
        "last_scan": existing.get("last_scan"),
        "github_full_name": github_full_name,
        "fail_on": fail_on,
        "scan_interval_hours": (scan_interval_hours
                                if scan_interval_hours is not None
                                else existing.get("scan_interval_hours")),
        # Explicit opt-in for broker/remediation.py's fix-PR flow (off by
        # default). Not secret-bearing — no redaction needed.
        "remediation_enabled": remediation_enabled,
        # Secret-bearing — redacted on every read-back via config.redact_repo.
        "github_token": github_token,
        "webhook_secret": webhook_secret,
    }
    # Pre-flight when the caller asks for it (the dashboard does by default):
    # confirm the remote is reachable with these credentials and the branch
    # exists BEFORE saving, so a bad URL/token/branch fails here — visibly —
    # instead of as a failed job at first scan. `git ls-remote` only; no clone.
    if body.get("validate") and entry["kind"] == "git":
        err = validate_remote(url, entry["github_token"], branch)
        if err:
            return jsonify({"success": False,
                            "error": f"repo validation failed: {err}"}), 400

    config.upsert_repo(entry)
    return jsonify({"success": True, "repo": config.redact_repo(entry)}), 201


@bp.delete("/repos/<repo_id>")
def delete_repo(repo_id: str):
    if not config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "invalid repo id"}), 400
    return (jsonify({"success": True}) if config.remove_repo(repo_id)
            else (jsonify({"success": False, "error": "repo not found"}), 404))


# ── Scans / jobs ──────────────────────────────────────────────────────────────
@bp.post("/repos/<repo_id>/scan")
@tm_app.limiter.limit("10 per minute")
def scan_repo(repo_id: str):
    if not config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "invalid repo id"}), 400
    repo = config.get_repo(repo_id)
    if not repo:
        return jsonify({"success": False, "error": "repo not found"}), 404
    body = request.get_json(silent=True) or {}
    severity = str(body.get("severity", "Low"))
    job_id = get_service().submit_scan(repo, severity)
    return jsonify({"success": True, "job_id": job_id}), 202


@bp.get("/jobs")
def list_jobs():
    return jsonify({"success": True, "jobs": get_service().list_jobs()})


@bp.delete("/jobs/<job_id>")
def delete_job(job_id: str):
    """Remove one job from scan history. Does not touch the report it may
    have produced -- that's a separate delete (DELETE /api/v1/reports/<id>)."""
    return (jsonify({"success": True, "deleted": job_id}) if get_service().delete_job(job_id)
            else (jsonify({"success": False, "error": "job not found"}), 404))


@bp.get("/metrics")
def metrics():
    return jsonify({"success": True, **get_service().metrics()})


@bp.post("/repos/<repo_id>/pipeline")
@tm_app.limiter.limit("5 per minute")
def run_pipeline(repo_id: str):
    """Run SAST + code-model then correlation for a repo.

    Synchronous: returns the saved report ids and the correlation verdict report.
    Body: {severity?}.
    """
    if not config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "invalid repo id"}), 400
    repo = config.get_repo(repo_id)
    if not repo:
        return jsonify({"success": False, "error": "repo not found"}), 404
    body = request.get_json(silent=True) or {}
    severity = str(body.get("severity", "Low"))
    if severity not in config.SEVERITY_ORDER:
        severity = "Low"

    from broker import pipeline
    try:
        result = pipeline.run(repo, severity=severity)
    except ScanError as exc:  # expected failure (bad remote, engine error, timeout)
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify({"success": True, **result}), 201


@bp.post("/repos/<repo_id>/remediation/propose")
@tm_app.limiter.limit("10 per minute")
def propose_remediation(repo_id: str):
    """Read-only: check whether a finding is fix-eligible and return the patch.

    Body: {report_id, category_id, file, line, against}. ``against`` is a
    branch name on the repo's origin remote (typically its default branch) —
    the finding is only eligible if it sits on a line the diff between that
    branch and the currently scanned HEAD actually added. No git write.
    """
    if not config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "invalid repo id"}), 400
    repo = config.get_repo(repo_id)
    if not repo:
        return jsonify({"success": False, "error": "repo not found"}), 404

    body = request.get_json(silent=True) or {}
    report_id = str(body.get("report_id", "")).strip()
    category_id = str(body.get("category_id", "")).strip()
    file = str(body.get("file", "")).strip()
    against = str(body.get("against", "")).strip() or (repo.get("branch") or "main")
    try:
        line = int(body.get("line"))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "line must be an integer"}), 400
    if not (report_id and category_id and file):
        return jsonify({"success": False,
                        "error": "report_id, category_id, and file are required"}), 400

    import report_db
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"success": False, "error": "report not found"}), 404

    from broker import remediation
    try:
        result = remediation.propose_fix(repo, report, category_id, file, line, against)
    except remediation.RemediationError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify({"success": True, **result})


@bp.post("/repos/<repo_id>/remediation/open-pr")
@tm_app.limiter.limit("5 per minute")
def open_remediation_pr(repo_id: str):
    """The only endpoint in TM that writes to a repo's git history.

    Human-triggered only: takes the exact patch text the caller already
    reviewed from /remediation/propose and opens a PR from it. Requires the
    repo to have remediation_enabled=true (set at registration).

    Body: {patch, file, category_id, report_id, title?, branch?}.
    """
    if not config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "invalid repo id"}), 400
    repo = config.get_repo(repo_id)
    if not repo:
        return jsonify({"success": False, "error": "repo not found"}), 404

    body = request.get_json(silent=True) or {}
    patch = body.get("patch", "")
    file = str(body.get("file", "")).strip()
    category_id = str(body.get("category_id", "")).strip()
    report_id = str(body.get("report_id", "")).strip()
    title = body.get("title") or None
    branch = body.get("branch") or None
    if not (patch and file and category_id and report_id):
        return jsonify({"success": False,
                        "error": "patch, file, category_id, and report_id are required"}), 400

    from broker import remediation
    try:
        result = remediation.open_pr(repo, patch, file, category_id, report_id,
                                     title=title, branch=branch)
    except remediation.RemediationError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify(result), 201


@bp.get("/remediation/queue")
def remediation_queue():
    """Fix-eligible findings across every remediation-enabled repo's latest
    SAST scan, ranked verdict-first (see broker.remediation.queue for the
    ranking + why a fingerprint join isn't what links a SAST finding to its
    correlated verdict). ?repo_id= scopes to one repo; ?limit= caps the
    result (default 100)."""
    repo_id = request.args.get("repo_id") or None
    if repo_id and not config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "invalid repo id"}), 400
    try:
        limit = int(request.args.get("limit", 100))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "limit must be an integer"}), 400

    from broker import remediation
    items = remediation.queue(repo_id=repo_id, limit=limit)
    return jsonify({"success": True, "count": len(items), "queue": items})


@bp.get("/jobs/<job_id>")
def get_job(job_id: str):
    job = get_service().get_job(job_id)
    if not job:
        return jsonify({"success": False, "error": "job not found"}), 404
    return jsonify({"success": True, "job": job})


@bp.get("/jobs/<job_id>/events")
def job_events(job_id: str):
    """Server-sent events: emit job state until it reaches a terminal status."""
    service = get_service()
    if not service.get_job(job_id):
        return jsonify({"success": False, "error": "job not found"}), 404

    def stream():
        deadline = time.time() + config.SCAN_TIMEOUT + 30
        last = None
        while time.time() < deadline:
            job = service.get_job(job_id)
            if not job:
                break
            snapshot = json.dumps({"status": job["status"], "progress": job.get("progress"),
                                   "report_id": job.get("report_id"), "stats": job.get("stats"),
                                   "error": job.get("error"), "log": job.get("log", [])})
            if snapshot != last:
                yield f"data: {snapshot}\n\n"
                last = snapshot
            if job["status"] in ("done", "error"):
                break
            time.sleep(1)
        yield "event: end\ndata: {}\n\n"

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ── SAST reports ──────────────────────────────────────────────────────────────
# Broker scan reports are hidden from the general report API (/api/reports*) so
# repo findings never show up in the shared threat-model viewer list; this
# blueprint is their only serving surface.

def _load_sast_report(report_id: str):
    """Return the report dict when report_id names a SAST report, else None."""
    import app as tm_app
    if not tm_app._validate_report_id(report_id):
        return None
    report = tm_app.report_db.get_report(report_id)
    if not isinstance(report, dict) or not tm_app._is_sast_methodology(report.get("methodology")):
        return None
    return report


@bp.get("/reports")
def list_reports():
    import app as tm_app
    entries = tm_app.report_db.list_reports(limit=50, methodology="sast", include_sast=True)
    return jsonify({"success": True, "reports": entries})


@bp.get("/reports/<report_id>")
def get_report(report_id: str):
    report = _load_sast_report(report_id)
    if report is None:
        return jsonify({"success": False, "error": "SAST report not found"}), 404
    return jsonify({"success": True, "report": report})


@bp.delete("/reports/<report_id>")
def delete_report(report_id: str):
    import app as tm_app
    report = _load_sast_report(report_id)
    if report is None:
        return jsonify({"success": False, "error": "SAST report not found"}), 404
    tm_app.report_db.delete_report(report_id)
    try:
        (tm_app.REPORTS_DIR / f"{report_id}.json").unlink(missing_ok=True)
    except OSError:
        pass
    return jsonify({"success": True})


@bp.get("/reports/<report_id>/export/sarif")
def export_report_sarif(report_id: str):
    import re

    import sarif
    report = _load_sast_report(report_id)
    if report is None:
        return jsonify({"success": False, "error": "SAST report not found"}), 404
    doc = sarif.to_sarif(report)
    safe_title = re.sub(r"[^a-z0-9_-]+", "_",
                        str(report.get("title") or "report").lower()).strip("_")
    filename = f"tm_{(safe_title or 'report')[:80]}.sarif"
    return Response(
        json.dumps(doc, indent=2), mimetype="application/sarif+json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ── Remote push from a standalone broker ──────────────────────────────────────
@bp.post("/import")
def import_report():
    if not config.IMPORT_TOKEN:
        return jsonify({"success": False, "error": "remote import disabled "
                        "(set TM_BROKER_TOKEN)"}), 403
    provided = request.headers.get("X-Broker-Token", "")
    if not secrets.compare_digest(provided, config.IMPORT_TOKEN):
        return jsonify({"success": False, "error": "invalid broker token"}), 401
    report = request.get_json(silent=True) or {}
    try:
        report_id = get_service().import_report(report)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify({"success": True, "id": report_id}), 201


# ── GitHub webhook ────────────────────────────────────────────────────────────
@bp.post("/webhook")
def github_webhook():
    """Receive a GitHub push / pull_request event and trigger a scan.

    Auth is the HMAC in `X-Hub-Signature-256` (this route is exempt from the
    app's CSRF + API-key guard). We resolve the event to a *registered* repo,
    verify the signature against that repo's secret (falling back to the global
    secret), and queue a scan whose result is posted back to the commit/PR.
    """
    body = request.get_data() or b""           # raw bytes, for the HMAC
    event = request.headers.get("X-GitHub-Event", "")
    sig = request.headers.get("X-Hub-Signature-256", "")

    try:
        payload = json.loads(body.decode("utf-8") or "{}")
    except ValueError:
        return jsonify({"success": False, "error": "invalid JSON payload"}), 400

    parsed = github.parse_webhook(event, payload)

    # ping needs a valid signature too, but no repo match / scan.
    secret = config.GITHUB_WEBHOOK_SECRET
    repo = config.find_repo_for_github(parsed.get("full_name", ""))
    if repo and repo.get("webhook_secret"):
        secret = repo["webhook_secret"]
    if not secret:
        return jsonify({"success": False, "error": "no webhook secret configured"}), 403
    if not github.verify_signature(secret, body, sig):
        return jsonify({"success": False, "error": "invalid signature"}), 401

    if parsed["kind"] == "ping":
        return jsonify({"success": True, "pong": True})
    if parsed["kind"] == "ignored":
        return jsonify({"success": True, "ignored": True, "reason": parsed.get("reason")})
    if not repo:
        return jsonify({"success": False,
                        "error": f"no registered repo for {parsed.get('full_name')}"}), 404

    gh_ctx = {
        "kind": parsed["kind"],
        "full_name": parsed["full_name"],
        "sha": parsed["sha"],
        "ref": parsed["ref"],
        "number": parsed.get("number"),
        "base_branch": parsed.get("base_branch"),
        "public_url": config.PUBLIC_URL or request.host_url.rstrip("/"),
    }
    job_id = get_service().submit_scan(
        repo, config.GITHUB_SCAN_SEVERITY, ref=parsed["ref"], gh_ctx=gh_ctx)
    return jsonify({"success": True, "job_id": job_id, "kind": parsed["kind"],
                    "repo_id": repo["id"], "sha": parsed["sha"],
                    "pr": parsed.get("number")}), 202


# ── Dashboard page ────────────────────────────────────────────────────────────
@page_bp.get("/broker")
def broker_page():
    from app import _CSRF_TOKEN
    return render_template("broker.html", csrf_token=_CSRF_TOKEN)


# ── Integrations page ─────────────────────────────────────────────────────────
@page_bp.get("/integrations")
def integrations_page():
    """GitHub integration hub — webhook setup, global config, and the roster of
    GitHub-connected repos. Read-only: it reads /api/v1/sast (status) + /repos
    (both already redact secrets to `<key>_set` booleans)."""
    from app import _CSRF_TOKEN
    return render_template("integrations.html", csrf_token=_CSRF_TOKEN)
