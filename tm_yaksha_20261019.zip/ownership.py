"""Owner assignment for the triage queue.

The triage worklist (triage.py) already ranks findings by verdict bucket
(actively_exploited first, blind_spot last) but had nowhere to record *who*
is supposed to act on a bucket, or on one specific finding, until now. Two
layers, narrowest wins:

  1. Per-finding override, keyed by the same report-independent fingerprint
     suppressions/verdict_tracking already use (rule id + weakness family +
     CWE + line-insensitive locus) -- survives rescans/small edits, like a
     suppression does.
  2. Per-verdict-bucket default (route actively-exploited/confirmed-exploitable
     to on-call, design gaps to the threat-model owner, etc). One owner string
     per value in suppressions.model.VERDICTS, plus "" for never-correlated
     findings.

A finding with neither gets no owner (never guessed or defaulted to
"unassigned" -- an empty owner is meaningfully different from an assigned one
in the UI/CSV export).

Stdlib sqlite3 only, same connection-per-call + WAL pattern as report_db.py /
suppressions/db.py / verdict_tracking.py.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

from suppressions.model import VERDICTS

DB_PATH = Path.home() / ".tm_ownership.db"

_init_lock = threading.Lock()

# Bucket keys a default owner may be set for: every real verdict plus "" for
# findings the correlator has never touched.
DEFAULT_BUCKETS = (*VERDICTS, "")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS owner_defaults (
    verdict     TEXT PRIMARY KEY,
    owner       TEXT NOT NULL,
    updated_at  REAL
);
CREATE TABLE IF NOT EXISTS owner_assignments (
    fingerprint  TEXT PRIMARY KEY,
    owner        TEXT NOT NULL,
    assigned_by  TEXT DEFAULT '',
    assigned_at  REAL,
    note         TEXT DEFAULT ''
);
"""

# SQLite's default compiled-in limit on bound parameters (SQLITE_MAX_VARIABLE_NUMBER)
# is 999 on most builds; chunk bulk IN-clause lookups well under that.
_CHUNK = 400


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)


# ── Bucket defaults ──────────────────────────────────────────────────────────
def set_default(verdict: str, owner: str) -> None:
    """Set (or, with owner="", clear) the default owner for a verdict bucket.

    Raises ValueError for a verdict outside DEFAULT_BUCKETS rather than
    silently creating an unreachable row -- the triage UI's verdict filter is
    a fixed set, so an unrecognized bucket here is always a caller bug.
    """
    if verdict not in DEFAULT_BUCKETS:
        raise ValueError(f"verdict must be one of {DEFAULT_BUCKETS!r}")
    owner = owner.strip()
    init()
    with closing(_connect()) as conn, conn:
        if owner:
            conn.execute(
                "INSERT INTO owner_defaults(verdict,owner,updated_at) VALUES (?,?,?) "
                "ON CONFLICT(verdict) DO UPDATE SET owner=excluded.owner, updated_at=excluded.updated_at",
                (verdict, owner, time.time()))
        else:
            conn.execute("DELETE FROM owner_defaults WHERE verdict = ?", (verdict,))


def get_defaults() -> dict[str, str]:
    """Every bucket's default owner, always keyed for all of DEFAULT_BUCKETS
    (unset buckets come back as "") -- callers never need a .get() fallback."""
    init()
    with closing(_connect()) as conn:
        rows = conn.execute("SELECT verdict, owner FROM owner_defaults").fetchall()
    stored = {r["verdict"]: r["owner"] for r in rows}
    return {bucket: stored.get(bucket, "") for bucket in DEFAULT_BUCKETS}


# ── Per-finding overrides ────────────────────────────────────────────────────
def assign(fingerprint: str, owner: str, assigned_by: str = "", note: str = "") -> dict | None:
    """Set the per-finding owner override; owner="" clears it (falls back to
    the bucket default). Returns the stored record, or None if cleared."""
    fingerprint = fingerprint.strip()
    if not fingerprint:
        raise ValueError("fingerprint is required")
    owner = owner.strip()
    init()
    with closing(_connect()) as conn, conn:
        if owner:
            at = time.time()
            conn.execute(
                "INSERT INTO owner_assignments(fingerprint,owner,assigned_by,assigned_at,note) "
                "VALUES (?,?,?,?,?) ON CONFLICT(fingerprint) DO UPDATE SET "
                "owner=excluded.owner, assigned_by=excluded.assigned_by, "
                "assigned_at=excluded.assigned_at, note=excluded.note",
                (fingerprint, owner, assigned_by.strip(), at, note.strip()))
            return {"fingerprint": fingerprint, "owner": owner,
                    "assigned_by": assigned_by.strip(), "assigned_at": at, "note": note.strip()}
        conn.execute("DELETE FROM owner_assignments WHERE fingerprint = ?", (fingerprint,))
        return None


def clear_assignment(fingerprint: str) -> bool:
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute("DELETE FROM owner_assignments WHERE fingerprint = ?",
                           (fingerprint.strip(),))
        return cur.rowcount > 0


def list_assignments() -> list[dict]:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT * FROM owner_assignments ORDER BY assigned_at DESC").fetchall()
    return [dict(r) for r in rows]


def _overrides_map(fingerprints: list[str]) -> dict[str, dict]:
    """Bulk fingerprint -> assignment row lookup, chunked under SQLite's bound
    parameter limit -- the triage queue can hand this hundreds of rows at once."""
    uniq = [fp for fp in {f for f in fingerprints if f}]
    if not uniq:
        return {}
    init()
    out: dict[str, dict] = {}
    with closing(_connect()) as conn:
        for i in range(0, len(uniq), _CHUNK):
            chunk = uniq[i:i + _CHUNK]
            placeholders = ",".join("?" * len(chunk))
            rows = conn.execute(
                f"SELECT * FROM owner_assignments WHERE fingerprint IN ({placeholders})",
                chunk).fetchall()
            for r in rows:
                out[r["fingerprint"]] = dict(r)
    return out


# ── Resolution ────────────────────────────────────────────────────────────────
def resolve_owner(fingerprint: str, verdict: str) -> dict:
    """Owner + provenance for one finding: per-finding override wins, else the
    verdict bucket's default, else unassigned."""
    overrides = _overrides_map([fingerprint])
    defaults = get_defaults()
    return _resolve_one(fingerprint, verdict, overrides, defaults)


def _resolve_one(fingerprint: str, verdict: str, overrides: dict, defaults: dict) -> dict:
    hit = overrides.get(fingerprint)
    if hit:
        return {"owner": hit["owner"], "source": "override", "note": hit.get("note") or ""}
    default_owner = defaults.get(verdict or "", "")
    if default_owner:
        return {"owner": default_owner, "source": "default", "note": ""}
    return {"owner": "", "source": "", "note": ""}


def annotate_rows(rows: list[dict]) -> list[dict]:
    """Tag each finding row (report_db.search_findings shape, already carrying
    ``fingerprint``/``verdict``) with ``owner``/``owner_source`` in place --
    same in-place-mutation convention triage.py already uses for
    ``suppressed`` on these freshly-built row dicts. Two bulk queries total
    regardless of row count, not one per row."""
    fingerprints = [r.get("fingerprint") or "" for r in rows]
    overrides = _overrides_map(fingerprints)
    defaults = get_defaults()
    for row in rows:
        resolved = _resolve_one(row.get("fingerprint") or "", row.get("verdict") or "",
                                overrides, defaults)
        row["owner"] = resolved["owner"]
        row["owner_source"] = resolved["source"]
    return rows


def delete_all() -> int:
    """Wipe every default and override. Used by the admin flush action."""
    init()
    with closing(_connect()) as conn, conn:
        n = (conn.execute("SELECT COUNT(*) FROM owner_defaults").fetchone()[0]
             + conn.execute("SELECT COUNT(*) FROM owner_assignments").fetchone()[0])
        conn.execute("DELETE FROM owner_defaults")
        conn.execute("DELETE FROM owner_assignments")
    return n
