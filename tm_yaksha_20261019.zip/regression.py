"""regression.py — persists verdict-based canary/regression cases across scans
and re-runs them, closing the loop canary.py leaves open: canary.py builds a
one-shot replay script/JSON for whoever is looking at a report right now, but
nothing remembers a case exists once that request ends, and nothing ever
fires it again to see whether a previously-proven finding has crept back in.

Every proven-verdict finding (canary.PROVEN_VERDICTS) with a replayable HTTP
locus (canary.qualifying_threats) gets a persisted case, upserted every time
a report carrying that finding is saved (app.py's _save_report, the same
best-effort hook verdict_tracking.record_transitions already uses). A case's
identity is sha1(fingerprint|url|param): the same finding can generate more
than one replayable case (one per parameter), so the report-level finding
fingerprint alone isn't a unique key here -- (fingerprint, url, param) is.

Re-running a case replays the exact request in-process (dast.engine.Fetcher)
and evaluates it with canary.evaluate_response -- the same pass/fail/skip
rule the downloadable bash script encodes, so a browser-triggered re-run and
a CI `bash canary.sh` run can never disagree about the same case.

A regression alert fires only on a genuine flip: the *previous* run's status
was "pass" (evidence gone -- looked fixed) and this run's is "fail" (evidence
is back). A case's first-ever run, a "skip" in either direction, or two
fails in a row is not a regression -- there is nothing to regress *from* yet
in the first two cases, and nothing changed in the third.

Two SQLite tables (plus an append-only run log), stdlib only, same
connection-per-call + WAL pattern as verdict_tracking.py/report_db.py.
"""
from __future__ import annotations

import hashlib
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

import canary
from suppressions import finding_fingerprint

DB_PATH = Path.home() / ".tm_regression.db"

_init_lock = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS regression_cases (
    case_id       TEXT PRIMARY KEY,
    fingerprint   TEXT NOT NULL,
    rule_id       TEXT,
    title         TEXT,
    url           TEXT,
    param         TEXT,
    evidence      TEXT,
    verdict       TEXT,
    report_id     TEXT,
    report_title  TEXT,
    created_at    REAL,
    updated_at    REAL,
    last_run_at   REAL,
    last_status   TEXT NOT NULL DEFAULT 'never_run'
);
CREATE INDEX IF NOT EXISTS ix_regcases_fp ON regression_cases(fingerprint);
CREATE INDEX IF NOT EXISTS ix_regcases_report ON regression_cases(report_id);
CREATE TABLE IF NOT EXISTS regression_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     TEXT NOT NULL,
    at          REAL,
    status      TEXT NOT NULL,
    detail      TEXT,
    http_status INTEGER
);
CREATE INDEX IF NOT EXISTS ix_regruns_case ON regression_runs(case_id, at);
CREATE TABLE IF NOT EXISTS regression_alerts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id      TEXT NOT NULL,
    fingerprint  TEXT,
    title        TEXT,
    url          TEXT,
    at           REAL,
    acknowledged INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_regalerts_at  ON regression_alerts(at);
CREATE INDEX IF NOT EXISTS ix_regalerts_ack ON regression_alerts(acknowledged);
"""

_STATUSES = ("never_run", "pass", "fail", "error", "skip")


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)


def _case_id(fingerprint: str, url: str, param: str) -> str:
    return hashlib.sha1(f"{fingerprint}|{url}|{param}".encode("utf-8")).hexdigest()[:16]


def sync_from_report(report: dict, verdicts: tuple[str, ...] = canary.PROVEN_VERDICTS,
                     now: float | None = None) -> list[dict]:
    """Upsert a regression case for every qualifying finding in ``report``.

    Existing cases keep their run history (created_at/last_run_at/
    last_status); only the descriptive fields (title/evidence/verdict/report
    pointer) refresh, so re-scanning the same target doesn't reset a case's
    pass/fail track record.
    """
    at = now if now is not None else time.time()
    init()
    synced: list[dict] = []
    with closing(_connect()) as conn, conn:
        for cat in report.get("categories") or []:
            if not isinstance(cat, dict) or (cat.get("verdict") or "") not in verdicts:
                continue
            fp = finding_fingerprint(cat)
            for threat, url, param in canary.qualifying_threats(cat):
                case = canary.generate_case(cat, threat, url, param)
                cid = _case_id(fp, url, param)
                prev = conn.execute(
                    "SELECT created_at, last_run_at, last_status FROM regression_cases "
                    "WHERE case_id = ?", (cid,)).fetchone()
                created_at = prev["created_at"] if prev else at
                last_run_at = prev["last_run_at"] if prev else None
                last_status = prev["last_status"] if prev else "never_run"
                conn.execute(
                    "INSERT OR REPLACE INTO regression_cases"
                    "(case_id,fingerprint,rule_id,title,url,param,evidence,verdict,"
                    "report_id,report_title,created_at,updated_at,last_run_at,last_status)"
                    " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (cid, fp, case["rule_id"], case["title"], url, param, case["evidence"],
                     case["verdict"], report.get("id"), report.get("title"),
                     created_at, at, last_run_at, last_status))
                row = conn.execute(
                    "SELECT * FROM regression_cases WHERE case_id = ?", (cid,)).fetchone()
                synced.append(dict(row))
    return synced


def list_cases(*, status: str | None = None, report_id: str | None = None,
               q: str | None = None, limit: int = 500) -> list[dict]:
    init()
    query = "SELECT * FROM regression_cases WHERE 1=1"
    params: list = []
    if status:
        query += " AND last_status = ?"
        params.append(status)
    if report_id:
        query += " AND report_id = ?"
        params.append(report_id)
    if q:
        like = f"%{q}%"
        query += " AND (title LIKE ? OR url LIKE ? OR rule_id LIKE ?)"
        params.extend([like, like, like])
    query += " ORDER BY updated_at DESC LIMIT ?"
    params.append(max(1, min(limit, 2000)))
    with closing(_connect()) as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def get_case(case_id: str) -> dict | None:
    init()
    with closing(_connect()) as conn:
        row = conn.execute(
            "SELECT * FROM regression_cases WHERE case_id = ?", (case_id,)).fetchone()
    return dict(row) if row else None


def case_history(case_id: str, limit: int = 50) -> list[dict]:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT * FROM regression_runs WHERE case_id = ? ORDER BY at DESC, id DESC LIMIT ?",
            (case_id, max(1, min(limit, 500)))).fetchall()
    return [dict(r) for r in rows]


def run_case(case_id: str, *, fetcher=None, now: float | None = None) -> dict:
    """Replay one persisted case's request in-process and record the result.

    Raises ``KeyError`` if the case doesn't exist. A fresh, single-request
    ``dast.engine.Fetcher`` is used by default (budget=1) -- pass one in to
    share rate-limiting/budget across a bulk :func:`run_all` call.
    """
    at = now if now is not None else time.time()
    init()
    with closing(_connect()) as conn:
        row = conn.execute(
            "SELECT * FROM regression_cases WHERE case_id = ?", (case_id,)).fetchone()
    if row is None:
        raise KeyError(case_id)

    if fetcher is None:
        from dast.engine import Fetcher
        fetcher = Fetcher(budget=1, timeout=15, delay=0)
    resp = fetcher.get(row["url"])
    if not resp.ok:
        status = "error"
        detail = resp.error or f"HTTP {resp.status}"
        http_status = resp.status
    else:
        status, detail = canary.evaluate_response(
            row["rule_id"], row["evidence"], resp.headers, resp.body)
        http_status = resp.status

    regressed = row["last_status"] == "pass" and status == "fail"

    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT INTO regression_runs(case_id,at,status,detail,http_status) "
            "VALUES (?,?,?,?,?)",
            (case_id, at, status, detail, http_status))
        conn.execute(
            "UPDATE regression_cases SET last_run_at = ?, last_status = ?, updated_at = ? "
            "WHERE case_id = ?", (at, status, at, case_id))
        if regressed:
            conn.execute(
                "INSERT INTO regression_alerts"
                "(case_id,fingerprint,title,url,at,acknowledged) VALUES (?,?,?,?,?,0)",
                (case_id, row["fingerprint"], row["title"], row["url"], at))

    return {"case_id": case_id, "status": status, "detail": detail,
            "http_status": http_status, "regressed": regressed, "at": at}


def run_all(case_ids: list[str] | None = None, *, fetcher=None,
           now: float | None = None) -> list[dict]:
    """Re-run every persisted case (or just ``case_ids`` if given)."""
    init()
    if case_ids is None:
        with closing(_connect()) as conn:
            case_ids = [r["case_id"] for r in
                       conn.execute("SELECT case_id FROM regression_cases").fetchall()]
    return [run_case(cid, fetcher=fetcher, now=now) for cid in case_ids]


def list_alerts(limit: int = 50, unacknowledged_only: bool = False) -> list[dict]:
    init()
    q = "SELECT * FROM regression_alerts"
    if unacknowledged_only:
        q += " WHERE acknowledged = 0"
    q += " ORDER BY at DESC, id DESC LIMIT ?"
    with closing(_connect()) as conn:
        rows = conn.execute(q, (max(1, min(limit, 1000)),)).fetchall()
    return [dict(r) for r in rows]


def acknowledge_alert(alert_id: int) -> bool:
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute(
            "UPDATE regression_alerts SET acknowledged = 1 WHERE id = ?", (alert_id,))
        return cur.rowcount > 0


def unacknowledged_count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM regression_alerts WHERE acknowledged = 0").fetchone()[0]


def summary() -> dict:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT last_status, COUNT(*) c FROM regression_cases GROUP BY last_status").fetchall()
    counts = {s: 0 for s in _STATUSES}
    for r in rows:
        counts[r["last_status"]] = r["c"]
    return {"total": sum(counts.values()), "by_status": counts,
            "unacknowledged_alerts": unacknowledged_count()}


def delete_all() -> int:
    """Wipe all persisted cases, run history, and alerts. Used by the admin
    flush action."""
    init()
    with closing(_connect()) as conn, conn:
        n = conn.execute("SELECT COUNT(*) FROM regression_cases").fetchone()[0]
        conn.execute("DELETE FROM regression_alerts")
        conn.execute("DELETE FROM regression_runs")
        conn.execute("DELETE FROM regression_cases")
    return n
