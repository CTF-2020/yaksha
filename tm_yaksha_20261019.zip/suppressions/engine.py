"""Finding fingerprints and the read-time application of suppressions.

The fingerprint is the crux: it must identify "the same finding" across re-scans
(which change the report id) and across small code edits (which change line
numbers), yet stay specific enough that accepting one finding does not silently
mute a different one. It is therefore built from:

  * the **rule / category id** (``WEB-A03-01``, ``CM-001``, a SAST rule id …) — the
    kind of weakness the tool flagged;
  * the **weakness family** and **CWE** — a method-agnostic identity so a design
    finding and its code counterpart hash the same way;
  * a **file-level locus** — the affected file path(s) with line numbers stripped,
    so editing around a sink does not resurrect an accepted risk, while moving it
    to a different file does (which is a genuinely different finding).

Application is pure and read-time: :func:`annotate_report` returns a shallow copy
with each suppressed category tagged (``suppressed``, ``suppression``) and the
report's severity posture recomputed to exclude suppressed findings — the raw
stored report is never mutated.
"""
from __future__ import annotations

import hashlib
import re

from .model import VERDICT_RANK, Suppression

_SEVS = ("Critical", "High", "Medium", "Low", "Info")

# "path/to/file.py:42" or "path:42:7" -> strip the :line[:col] tail. Also strips a
# trailing "(a.py:7)" style parenthetical the codemodel uses in component strings.
_LINE_TAIL = re.compile(r":\d+(?::\d+)?\b")
_PAREN_FILE = re.compile(r"\(([^():]+):\d+\)")


def _norm_locus_token(text: str) -> str:
    """Normalize one locus string to a stable, line-insensitive form."""
    text = str(text or "").strip().lower().replace("\\", "/")
    # pull a "(file:line)" parenthetical up to just the file
    text = _PAREN_FILE.sub(lambda m: m.group(1), text)
    text = _LINE_TAIL.sub("", text)
    return text.strip()


def _loci(category: dict) -> list[str]:
    """All file/component loci a category points at, normalized & de-duped."""
    out: list[str] = []
    for comp in category.get("affected_components") or []:
        tok = _norm_locus_token(comp)
        if tok:
            out.append(tok)
    for threat in category.get("threats") or []:
        if isinstance(threat, dict) and threat.get("name"):
            tok = _norm_locus_token(threat["name"])
            if tok:
                out.append(tok)
    # order-independent identity
    return sorted(dict.fromkeys(out))


def _rule_id(category: dict) -> str:
    return str(category.get("id") or category.get("category") or "").strip().lower()


def _family(category: dict) -> str:
    fam = str(category.get("family") or "").strip().lower()
    if fam:
        return fam
    # fall back to a slug of the name so non-codemodel findings still group
    name = str(category.get("name") or category.get("title") or "").strip().lower()
    return re.sub(r"[^a-z0-9]+", "-", name).strip("-")


def _cwe(category: dict) -> str:
    return str(category.get("cwe") or "").strip().upper()


def finding_fingerprint(category: dict) -> str:
    """A report-independent, line-insensitive identity for one finding."""
    parts = [_rule_id(category), _family(category), _cwe(category), "|".join(_loci(category))]
    raw = "\x1f".join(parts)
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:16]


def _matches_core(supp: Suppression, *, rule_id: str, family: str, fingerprint: str,
                   verdict: str, report_id: str, now: float | None) -> bool:
    if supp.is_expired(now):
        return False
    if supp.report_id and report_id and supp.report_id != report_id:
        return False
    if supp.max_verdict:
        # only a finding that actually carries a verdict (i.e. went through
        # the correlator) can be gated by this; plain SAST/manual findings
        # are unaffected, same backward-compat rule as jira_client.min_verdict.
        if verdict in VERDICT_RANK and VERDICT_RANK[verdict] < VERDICT_RANK[supp.max_verdict]:
            return False
    m = supp.match.strip().lower()
    if supp.scope == "finding":
        return fingerprint == supp.match.strip()
    if supp.scope == "family":
        return family.strip().lower() == m
    if supp.scope == "rule":
        return rule_id.strip().lower() == m
    return False


def matches(supp: Suppression, category: dict, report_id: str = "",
            now: float | None = None) -> bool:
    """Does ``supp`` apply to ``category`` in report ``report_id`` right now?"""
    return _matches_core(
        supp, rule_id=_rule_id(category), family=_family(category),
        fingerprint=finding_fingerprint(category), verdict=str(category.get("verdict") or ""),
        report_id=report_id, now=now)


def matches_row(supp: Suppression, row: dict, now: float | None = None) -> bool:
    """Same identity check as :func:`matches`, against a flat SQL row (as returned
    by ``report_db.search_findings``) instead of a report category dict.

    The triage worklist reads the ``findings`` table directly rather than full
    report JSON, so it needs suppression matching without reconstructing a
    category — ``row['fingerprint']`` is the same value :func:`finding_fingerprint`
    would compute from the original category (report_db stores it at write time),
    so this is exact, not an approximation limited to single-locus findings.
    """
    return _matches_core(
        supp, rule_id=str(row.get("rule") or ""), family=str(row.get("family") or ""),
        fingerprint=str(row.get("fingerprint") or ""), verdict=str(row.get("verdict") or ""),
        report_id=str(row.get("report_id") or ""), now=now)


def active_suppressions(supps, now: float | None = None) -> list:
    """The subset of suppressions that are not expired."""
    return [s for s in supps if not s.is_expired(now)]


def _sev_of(category: dict) -> str:
    sev = str(category.get("risk") or category.get("severity") or "Info").capitalize()
    return sev if sev in _SEVS else "Info"


def annotate_report(report: dict, supps, now: float | None = None) -> dict:
    """Return a shallow copy of ``report`` with suppressions applied.

    Each matching category gains ``suppressed=True`` and a ``suppression`` block
    (id, scope, state, reason, author, expiry). Adds a top-level
    ``suppression_summary`` with active vs suppressed severity counts, and
    recomputes ``severity_counts`` / ``active_severity_counts`` so downstream
    posture reflects only live findings. The stored report is not mutated.
    """
    report_id = str(report.get("id", ""))
    categories = report.get("categories") or []
    new_cats = []
    active_sev = {s: 0 for s in _SEVS}
    suppressed_sev = {s: 0 for s in _SEVS}
    suppressed_n = 0

    for cat in categories:
        if not isinstance(cat, dict):
            new_cats.append(cat)
            continue
        cat = dict(cat)
        sev = _sev_of(cat)
        hit = next((s for s in supps if matches(s, cat, report_id, now)), None)
        if hit is not None:
            cat["suppressed"] = True
            cat["suppression"] = {
                "id": hit.id, "scope": hit.scope, "state": hit.state,
                "reason": hit.reason, "author": hit.author,
                "expires_at": hit.expires_at, "max_verdict": hit.max_verdict,
            }
            suppressed_sev[sev] += 1
            suppressed_n += 1
        else:
            cat["suppressed"] = False
            active_sev[sev] += 1
        # always carry the fingerprint so a UI can offer "suppress this"
        cat["fingerprint"] = finding_fingerprint(cat)
        new_cats.append(cat)

    out = dict(report)
    out["categories"] = new_cats
    out["active_severity_counts"] = active_sev
    out["suppressed_severity_counts"] = suppressed_sev
    out["suppression_summary"] = {
        "total_findings": sum(1 for c in categories if isinstance(c, dict)),
        "suppressed": suppressed_n,
        "active": sum(active_sev.values()),
        "active_critical_high": active_sev["Critical"] + active_sev["High"],
        "suppressed_critical_high": suppressed_sev["Critical"] + suppressed_sev["High"],
    }
    return out
