"""Tests for correlator/service.py's report loading.

Run:  python -m unittest test_correlator_service   (stdlib only)

Regression coverage for report_id validation: service._load_report must reject
anything that doesn't match the app-wide report id shape before ever handing
the id to report_db, the same way every other report loader in the app does.
Reports are now looked up via a parameterized SQL primary-key match (no
filesystem path built from report_id at all), so there is no traversal target
to construct here any more — the id-shape check is defense in depth, not the
only thing preventing a traversal.
"""
from __future__ import annotations

import unittest
from unittest import mock

from correlator import service
from suppressions.model import Suppression


def _sast_dast_reports():
    # Loci deliberately share tokens ("search"/"users") so the SAST and DAST
    # SQLi observations cluster into one finding — same locus-overlap rule
    # the correlator uses everywhere else (see test_correlator.py fixtures).
    sast = {"id": "r_sast", "title": "SAST", "methodology": "sast", "categories": [
        {"id": "SQLI-1", "name": "SQL Injection", "risk": "High", "_source": "SAST",
         "cwe": "CWE-89", "affected_components": ["services/search_users.py:42"]},
        {"id": "CMD-1", "name": "OS Command Injection", "risk": "High", "_source": "SAST",
         "cwe": "CWE-78", "affected_components": ["services/run_backup.py:11"]},
    ]}
    dast = {"id": "r_dast", "title": "DAST", "methodology": "dast", "categories": [
        {"id": "DAST-SQLI", "name": "SQL Injection", "risk": "High", "_source": "DAST",
         "cwe": "CWE-89", "affected_components": ["https://shop.test/api/users/search?q="]},
    ]}
    return sast, dast


class SuppressedFindingsTests(unittest.TestCase):
    """An accepted-risk/false-positive decision must not inflate correlation
    output — see correlator/service.py's _drop_suppressed, wired into both
    list_correlatable() and run()."""

    def test_list_correlatable_drops_suppressed_category_from_count(self):
        sast, dast = _sast_dast_reports()
        supp = Suppression(scope="rule", match="SQLI-1", reason="accepted", author="carol")
        with mock.patch.object(service.report_db, "all_reports", return_value=[sast, dast]), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[supp]):
            out = service.list_correlatable()
        by_id = {o["id"]: o for o in out}
        self.assertEqual(by_id["r_sast"]["categories"], 1)   # CMD-1 only
        self.assertEqual(by_id["r_dast"]["categories"], 1)

    def test_fully_suppressed_report_disappears_from_list_correlatable(self):
        sast, dast = _sast_dast_reports()
        supps = [Suppression(scope="rule", match="SQLI-1", reason="a", author="c"),
                 Suppression(scope="rule", match="CMD-1", reason="a", author="c")]
        with mock.patch.object(service.report_db, "all_reports", return_value=[sast, dast]), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=supps):
            out = service.list_correlatable()
        self.assertEqual([o["id"] for o in out], ["r_dast"])

    def test_run_excludes_suppressed_category_from_correlation(self):
        # Without suppression, SAST+DAST SQLi agreement would be
        # confirmed-exploitable. Suppressing the SAST side must drop it back
        # to a DAST-only blind spot instead of silently keeping the escalated
        # verdict.
        sast, dast = _sast_dast_reports()
        supp = Suppression(scope="rule", match="SQLI-1", reason="accepted", author="carol")
        loaded = {"r_sast": sast, "r_dast": dast}
        with mock.patch.object(service, "_load_report", side_effect=loaded.get), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[supp]):
            report = service.run(["r_sast", "r_dast"])
        sqli = next(c for c in report["categories"] if c["name"] == "SQL Injection")
        self.assertEqual(sqli["verdict"], "blind_spot")

    def test_run_unaffected_when_nothing_is_suppressed(self):
        sast, dast = _sast_dast_reports()
        loaded = {"r_sast": sast, "r_dast": dast}
        with mock.patch.object(service, "_load_report", side_effect=loaded.get), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[]):
            report = service.run(["r_sast", "r_dast"])
        sqli = next(c for c in report["categories"] if c["name"] == "SQL Injection")
        self.assertEqual(sqli["verdict"], "confirmed_exploitable")

    def test_run_raises_when_suppression_leaves_fewer_than_two_reports(self):
        sast, dast = _sast_dast_reports()
        # suppress every category in BOTH reports -> nothing left to correlate
        supps = [Suppression(scope="rule", match="SQLI-1", reason="a", author="c"),
                 Suppression(scope="rule", match="CMD-1", reason="a", author="c"),
                 Suppression(scope="rule", match="DAST-SQLI", reason="a", author="c")]
        loaded = {"r_sast": sast, "r_dast": dast}
        with mock.patch.object(service, "_load_report", side_effect=loaded.get), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=supps):
            with self.assertRaises(ValueError):
                service.run(["r_sast", "r_dast"])


class ListCorrelatableTests(unittest.TestCase):
    """SBOM reports must be selectable as correlation inputs (they carry real
    dependency-CVE evidence); AI-BOM inventory and correlation-output reports
    stay excluded — see correlator/engine.py's SBOM reachability wiring."""

    def test_sbom_report_is_included_as_code_kind(self):
        reports = [{
            "id": "r1", "title": "SBOM Analysis — bom.json", "methodology": "SBOM",
            "categories": [{"id": "SBOM-HIGH", "_source": "SBOM",
                            "affected_components": ["pyyaml@5.3.1"]}],
        }]
        with mock.patch.object(service.report_db, "all_reports", return_value=reports):
            out = service.list_correlatable()
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["kind"], "code")

    def test_aibom_and_correlation_reports_stay_excluded(self):
        reports = [
            {"id": "r1", "methodology": "aibom",
             "categories": [{"id": "AIBOM-INVENTORY"}]},
            {"id": "r2", "methodology": "correlation",
             "categories": [{"id": "C1"}]},
        ]
        with mock.patch.object(service.report_db, "all_reports", return_value=reports):
            out = service.list_correlatable()
        self.assertEqual(out, [])


def _correlation_report_with_reachable_dep(component="pyyaml", tainted=True,
                                            unauthenticated=True, min_hops=0,
                                            risk="High", extra_cats=None):
    cat = {"id": "CORR-001", "name": "Vulnerable Components", "risk": risk,
           "_source": "CORRELATION",
           "dependency_reachability": {
               component: {"unauthenticated": unauthenticated, "tainted": tainted,
                            "min_hops": min_hops, "agent_tool": False},
           }}
    return {"id": "corr_1", "title": "Correlation run", "methodology": "correlation",
            "categories": [cat] + (extra_cats or [])}


class ListReachableDependenciesTests(unittest.TestCase):
    """correlator.service.list_reachable_dependencies -- the SCA/dependency
    CVE-reachability rollup surfaced on the dashboard + /api/v1/correlate/
    reachable-dependencies."""

    def test_lists_the_reachable_component(self):
        rep = _correlation_report_with_reachable_dep()
        with mock.patch.object(service.report_db, "all_reports", return_value=[rep]), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[]):
            out = service.list_reachable_dependencies()
        self.assertEqual(out["count"], 1)
        self.assertEqual(out["items"][0]["component"], "pyyaml")
        self.assertEqual(out["items"][0]["report_id"], "corr_1")
        self.assertTrue(out["items"][0]["unauthenticated"])
        self.assertTrue(out["items"][0]["tainted"])

    def test_non_correlation_reports_are_ignored(self):
        rep = _correlation_report_with_reachable_dep()
        rep["methodology"] = "sbom"   # the raw source, not a correlation output
        with mock.patch.object(service.report_db, "all_reports", return_value=[rep]), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[]):
            out = service.list_reachable_dependencies()
        self.assertEqual(out, {"count": 0, "items": []})

    def test_categories_without_dependency_reachability_are_skipped(self):
        rep = {"id": "corr_2", "title": "Correlation run", "methodology": "correlation",
               "categories": [{"id": "CORR-001", "name": "SQL Injection", "risk": "High",
                              "_source": "CORRELATION"}]}
        with mock.patch.object(service.report_db, "all_reports", return_value=[rep]), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[]):
            out = service.list_reachable_dependencies()
        self.assertEqual(out, {"count": 0, "items": []})

    def test_suppressed_finding_is_excluded(self):
        rep = _correlation_report_with_reachable_dep()
        supp = Suppression(scope="rule", match="CORR-001", reason="accepted", author="dana")
        with mock.patch.object(service.report_db, "all_reports", return_value=[rep]), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[supp]):
            out = service.list_reachable_dependencies()
        self.assertEqual(out["count"], 0)

    def test_sorted_worst_first_unauthenticated_and_tainted_before_hops(self):
        safe_ish = _correlation_report_with_reachable_dep(
            component="django", tainted=False, unauthenticated=False, min_hops=3, risk="Low")
        safe_ish["id"] = "corr_low"
        worst = _correlation_report_with_reachable_dep(
            component="pyyaml", tainted=True, unauthenticated=True, min_hops=0, risk="Critical")
        worst["id"] = "corr_high"
        with mock.patch.object(service.report_db, "all_reports",
                               return_value=[safe_ish, worst]), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[]):
            out = service.list_reachable_dependencies()
        self.assertEqual(out["items"][0]["component"], "pyyaml")
        self.assertEqual(out["items"][1]["component"], "django")

    def test_limit_is_respected(self):
        reports = []
        for i in range(5):
            r = _correlation_report_with_reachable_dep(component=f"pkg{i}")
            r["id"] = f"corr_{i}"
            reports.append(r)
        with mock.patch.object(service.report_db, "all_reports", return_value=reports), \
             mock.patch.object(service.suppressions, "load_suppressions", return_value=[]):
            out = service.list_reachable_dependencies(limit=2)
        self.assertEqual(out["count"], 5)          # true total
        self.assertEqual(len(out["items"]), 2)     # capped list


class ReportIdValidationTests(unittest.TestCase):
    """Every case here mocks report_db.get_report to return a hit unconditionally,
    so a pass can only come from the id-shape validation running BEFORE the
    lookup — not from the id simply not existing in the database."""

    def test_traversal_report_id_is_rejected_even_when_the_lookup_would_hit(self):
        with mock.patch.object(service.report_db, "get_report",
                                return_value={"leaked": True}):
            self.assertIsNone(service._load_report("../../../../etc/passwd"))
            self.assertIsNone(service._load_report("..\\..\\windows\\win.ini"))

    def test_report_id_with_path_separators_is_rejected(self):
        with mock.patch.object(service.report_db, "get_report",
                                return_value={"leaked": True}):
            self.assertIsNone(service._load_report("a/b"))

    def test_valid_report_id_still_loads(self):
        with mock.patch.object(service.report_db, "get_report",
                                return_value={"id": "abc12345"}) as m:
            self.assertEqual(service._load_report("abc12345"), {"id": "abc12345"})
            m.assert_called_once_with("abc12345")

    def test_too_short_report_id_is_rejected(self):
        with mock.patch.object(service.report_db, "get_report",
                                return_value={"leaked": True}):
            self.assertIsNone(service._load_report("short"))

    def test_missing_report_returns_none(self):
        with mock.patch.object(service.report_db, "get_report", return_value=None):
            self.assertIsNone(service._load_report("abc12345"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
