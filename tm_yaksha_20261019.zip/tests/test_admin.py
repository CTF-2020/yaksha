"""Tests for admin gating (auth.py) and the flush-everything action (api/admin.py).

Every store the flush touches gets repointed to a temp directory before any
test runs, and every service singleton (broker/dast/aibom) is reset to None
so get_service() rebuilds against the isolated paths instead of reusing a
process-wide instance that may have already loaded the real ~/.tm_* stores.
This module has hit exactly this failure mode before (see project memory:
tests wiping real ~/.tm_broker / ~/.tm_reports data) — the isolation here is
deliberately paranoid because a flush test is the single most destructive
thing this suite could accidentally do for real.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import app as tm_app
import auth
import ownership
import regression
import report_db
import settings_db
import users_db
import verdict_tracking
from suppressions import db as supp_db
from broker import config as broker_config, db as broker_db, service as broker_service
from dast import config as dast_config, service as dast_service
from aibom import config as aibom_config, db as aibom_db, service as aibom_service


class _IsolatedStoresMixin:
    """Repoints every store the flush action can touch onto one temp dir."""

    def setUp(self):
        super().setUp()
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        root = Path(self._td.name)

        self._patch(report_db, "DB_PATH", root / "reports.db")
        self._patch(tm_app, "REPORTS_DIR", root / "tm_reports")
        (root / "tm_reports").mkdir(exist_ok=True)
        self._patch(users_db, "DB_PATH", root / "auth.db")
        self._patch(settings_db, "DB_PATH", root / "settings.db")
        self._patch(supp_db, "DB_PATH", root / "suppressions.db")
        self._patch(ownership, "DB_PATH", root / "ownership.db")
        self._patch(verdict_tracking, "DB_PATH", root / "verdict_history.db")
        self._patch(regression, "DB_PATH", root / "regression.db")

        broker_dir = root / "tm_broker"
        self._patch(broker_config, "STATE_DIR", broker_dir)
        self._patch(broker_config, "JOBS_PATH", broker_dir / "jobs.json")
        self._patch(broker_config, "BASELINE_DIR", broker_dir / "baselines")
        self._patch(broker_config, "SHA_CACHE_PATH", broker_dir / "sha_cache.json")
        self._patch(broker_db, "DB_PATH", broker_dir / "broker.db")
        (broker_dir / "baselines").mkdir(parents=True, exist_ok=True)

        dast_dir = root / "tm_dast"
        self._patch(dast_config, "STATE_DIR", dast_dir)
        self._patch(dast_config, "JOBS_PATH", dast_dir / "jobs.json")
        dast_dir.mkdir(parents=True, exist_ok=True)

        aibom_dir = root / "tm_aibom"
        self._patch(aibom_config, "STATE_DIR", aibom_dir)
        self._patch(aibom_config, "JOBS_PATH", aibom_dir / "jobs.json")
        self._patch(aibom_config, "BOM_DIR", aibom_dir / "boms")
        self._patch(aibom_config, "LATEST_DIR", aibom_dir / "latest")
        self._patch(aibom_db, "DB_PATH", aibom_dir / "aibom.db")
        (aibom_dir / "boms").mkdir(parents=True, exist_ok=True)
        (aibom_dir / "latest").mkdir(parents=True, exist_ok=True)

        # Force every scan-service singleton to rebuild against the isolated
        # paths above instead of whatever it already loaded from the real
        # state directories earlier in this test process.
        self._patch(broker_service, "_service", None)
        self._patch(dast_service, "_service", None)
        self._patch(aibom_service, "_service", None)

        for mod in (report_db, users_db, settings_db, supp_db, broker_db, aibom_db):
            mod.init()

    def _patch(self, module, attr, value):
        orig = getattr(module, attr)
        setattr(module, attr, value)
        self.addCleanup(setattr, module, attr, orig)


class TestAuthGate(_IsolatedStoresMixin, unittest.TestCase):
    def setUp(self):
        super().setUp()
        self.client = tm_app.app.test_client()

    def _login_as(self, email: str):
        with self.client.session_transaction() as sess:
            sess["user_email"] = email

    def test_anonymous_get_admin_page_redirects_to_login(self):
        resp = self.client.get("/admin")
        self.assertEqual(resp.status_code, 302)
        self.assertIn("/login", resp.headers["Location"])

    def test_anonymous_api_call_returns_401(self):
        resp = self.client.get("/api/v1/admin/users")
        self.assertEqual(resp.status_code, 401)

    def test_logged_in_non_admin_gets_403(self):
        users_db.create_user("user@example.com", "correcthorsebattery", role="user")
        self._login_as("user@example.com")
        resp = self.client.get("/api/v1/admin/users")
        self.assertEqual(resp.status_code, 403)

    def test_logged_in_admin_can_list_users(self):
        users_db.create_user("admin@example.com", "correcthorsebattery", role="admin")
        self._login_as("admin@example.com")
        resp = self.client.get("/api/v1/admin/users")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_json()["users"][0]["email"], "admin@example.com")

    def test_role_change_takes_effect_without_relogin(self):
        """auth.is_admin() reads users_db fresh every request, not a cached
        session value — revoking mid-session must bite on the very next
        request, unlike the general login gate which only checks presence."""
        users_db.create_user("flip@example.com", "correcthorsebattery", role="admin")
        self._login_as("flip@example.com")
        self.assertEqual(self.client.get("/api/v1/admin/users").status_code, 200)
        users_db.set_role("flip@example.com", "user")
        self.assertEqual(self.client.get("/api/v1/admin/users").status_code, 403)


class TestUserManagement(_IsolatedStoresMixin, unittest.TestCase):
    def setUp(self):
        super().setUp()
        self.client = tm_app.app.test_client()
        users_db.create_user("admin@example.com", "correcthorsebattery", role="admin")
        with self.client.session_transaction() as sess:
            sess["user_email"] = "admin@example.com"
        self.csrf = self.client.get("/api/csrf-token").get_json()["token"]

    def _post(self, path, body):
        return self.client.post(path, json=body, headers={"X-CSRF-Token": self.csrf})

    def _delete(self, path):
        return self.client.delete(path, headers={"X-CSRF-Token": self.csrf})

    def test_create_user(self):
        resp = self._post("/api/v1/admin/users",
                          {"email": "new@example.com", "password": "correcthorsebattery"})
        self.assertEqual(resp.status_code, 201)
        self.assertTrue(users_db.get_user("new@example.com"))

    def test_cannot_demote_self(self):
        resp = self._post("/api/v1/admin/users/admin@example.com/role", {"role": "user"})
        self.assertEqual(resp.status_code, 400)
        self.assertTrue(users_db.is_admin("admin@example.com"))

    def test_cannot_delete_self(self):
        resp = self._delete("/api/v1/admin/users/admin@example.com")
        self.assertEqual(resp.status_code, 400)
        self.assertTrue(users_db.get_user("admin@example.com"))

    def test_cannot_demote_last_admin_even_by_another_admin(self):
        users_db.create_user("second@example.com", "correcthorsebattery", role="admin")
        with self.client.session_transaction() as sess:
            sess["user_email"] = "second@example.com"
        resp = self._post("/api/v1/admin/users/admin@example.com/role", {"role": "user"})
        # second@ is still an admin here (2 admins exist), so demoting admin@
        # is allowed and leaves second@ as the sole admin.
        self.assertEqual(resp.status_code, 200)
        # Now only one admin remains; demoting it must be refused.
        resp2 = self._post("/api/v1/admin/users/second@example.com/role", {"role": "user"})
        self.assertEqual(resp2.status_code, 400)

    def test_delete_other_admin_when_multiple_exist(self):
        users_db.create_user("second@example.com", "correcthorsebattery", role="admin")
        resp = self._delete("/api/v1/admin/users/second@example.com")
        self.assertEqual(resp.status_code, 200)
        self.assertIsNone(users_db.get_user("second@example.com"))


class TestFlush(_IsolatedStoresMixin, unittest.TestCase):
    def setUp(self):
        super().setUp()
        self.client = tm_app.app.test_client()
        users_db.create_user("admin@example.com", "correcthorsebattery", role="admin")
        with self.client.session_transaction() as sess:
            sess["user_email"] = "admin@example.com"
        self.csrf = self.client.get("/api/csrf-token").get_json()["token"]

    def _flush(self, confirm="FLUSH"):
        return self.client.post("/api/v1/admin/flush", json={"confirm": confirm},
                                headers={"X-CSRF-Token": self.csrf})

    def _seed_data(self):
        report_db.upsert_report({"id": "r1", "methodology": "sast",
                                 "overall_risk": "Low", "categories": []})
        settings_db.set_value("broker.workers", "5")
        settings_db.set_value("app.require_login", "true")
        from suppressions.model import Suppression
        supp_db.upsert(Suppression(scope="rule", match="X", reason="r", author="a"))

    def test_flush_requires_exact_confirm_phrase(self):
        self._seed_data()
        resp = self._flush(confirm="please")
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(report_db.report_count(), 1)  # nothing was touched

    def test_flush_wipes_reports_settings_and_suppressions(self):
        self._seed_data()
        resp = self._flush()
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(report_db.report_count(), 0)
        self.assertIsNone(settings_db.get_value("broker.workers"))
        self.assertEqual(supp_db.count(), 0)

    def test_flush_preserves_require_login_setting(self):
        self._seed_data()
        self._flush()
        self.assertEqual(settings_db.get_value("app.require_login"), "true")

    def test_flush_does_not_touch_user_accounts(self):
        self._seed_data()
        self._flush()
        self.assertIsNotNone(users_db.get_user("admin@example.com"))
        self.assertEqual(users_db.user_count(), 1)

    def test_flush_clears_broker_job_history_but_not_repo_registry(self):
        broker_db.upsert_repo({"id": "repo1", "name": "repo1"})
        broker_config.save_jobs([{"id": "j1", "repo_id": "repo1",
                                  "started_at": "2026-01-01T00:00:00Z"}])
        self._flush()
        self.assertEqual(broker_config.load_jobs(), [])
        self.assertEqual(broker_db.repo_count(), 1)

    def test_flush_response_reports_per_store_counts(self):
        self._seed_data()
        resp = self._flush()
        cleared = resp.get_json()["cleared"]
        self.assertEqual(cleared["reports"], 1)
        self.assertEqual(cleared["suppressions"], 1)
        self.assertGreaterEqual(cleared["settings"], 1)

    def test_non_admin_cannot_flush(self):
        users_db.create_user("user@example.com", "correcthorsebattery", role="user")
        with self.client.session_transaction() as sess:
            sess["user_email"] = "user@example.com"
        self._seed_data()
        resp = self._flush()
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(report_db.report_count(), 1)


def _finding(component: str) -> dict:
    """Same rule/family/cwe, different line -> same fingerprint (matches how
    a re-scan or a second report can carry "the same" finding)."""
    return {"id": "SAST-001", "family": "injection", "cwe": "CWE-89",
            "risk": "High", "affected_components": [component]}


class TestDeleteFinding(_IsolatedStoresMixin, unittest.TestCase):
    def setUp(self):
        super().setUp()
        self.client = tm_app.app.test_client()
        users_db.create_user("admin@example.com", "correcthorsebattery", role="admin")
        with self.client.session_transaction() as sess:
            sess["user_email"] = "admin@example.com"
        self.csrf = self.client.get("/api/csrf-token").get_json()["token"]
        from suppressions.engine import finding_fingerprint
        self.fp = finding_fingerprint(_finding("app/db.py:42"))
        report_db.upsert_report({
            "id": "r1", "methodology": "sast", "overall_risk": "High",
            "categories": [_finding("app/db.py:42"),
                           {"id": "OTHER-1", "family": "xss", "cwe": "CWE-79",
                            "risk": "Low", "affected_components": ["app/view.py:9"]}],
        })
        report_db.upsert_report({
            "id": "r2", "methodology": "sast", "overall_risk": "High",
            "categories": [_finding("app/db.py:99")],  # same finding, different line/report
        })

    def _delete(self, fp, confirm="DELETE"):
        return self.client.post(f"/api/v1/admin/findings/{fp}/delete", json={"confirm": confirm},
                                headers={"X-CSRF-Token": self.csrf})

    def test_requires_exact_confirm_phrase(self):
        resp = self._delete(self.fp, confirm="please")
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(report_db.get_report("r1")["categories"]), 2)

    def test_removes_every_occurrence_across_reports_but_leaves_others(self):
        resp = self._delete(self.fp)
        self.assertEqual(resp.status_code, 200)
        body = resp.get_json()
        self.assertEqual(body["findings_removed"], 2)
        self.assertEqual(sorted(body["report_ids"]), ["r1", "r2"])
        r1 = report_db.get_report("r1")
        self.assertEqual([c["id"] for c in r1["categories"]], ["OTHER-1"])
        r2 = report_db.get_report("r2")
        self.assertEqual(r2["categories"], [])

    def test_unknown_fingerprint_returns_404(self):
        resp = self._delete("0" * 16)
        self.assertEqual(resp.status_code, 404)

    def test_non_admin_cannot_delete_finding(self):
        users_db.create_user("user@example.com", "correcthorsebattery", role="user")
        with self.client.session_transaction() as sess:
            sess["user_email"] = "user@example.com"
        resp = self._delete(self.fp)
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(len(report_db.get_report("r1")["categories"]), 2)


if __name__ == "__main__":
    unittest.main()
