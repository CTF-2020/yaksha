"""AI-BOM orchestration: job queue, background worker, report + BOM persistence.

Mirrors broker.service / dast.service: a scan runs on a daemon thread so the
triggering request returns immediately with a job id; the UI polls /jobs/<id>
or streams events. Jobs persist to ~/.tm_aibom/jobs.json.

Repos are the SAST broker's registered repos (broker.config) and the working
tree comes from broker.scanner.prepare_workspace — register a repo once on the
/broker page and every scanner (SAST, AI-BOM) can reach it. Each finished scan
produces three artifacts: a TM report (existing viewer), a CycloneDX 1.6 AI-BOM
document (downloadable), and a per-repo rollup for the org-wide inventory view.
"""
from __future__ import annotations

import threading
import traceback
from pathlib import Path

from broker import scanner as broker_scanner

from . import config, engine, mapper


class AibomService:
    def __init__(self) -> None:
        self._jobs: dict[str, dict] = {}
        self._lock = threading.RLock()
        for job in config.load_jobs():
            self._jobs[job["id"]] = job

    # ── Job bookkeeping ───────────────────────────────────────────────────────
    def _new_job_id(self) -> str:
        import secrets
        import time
        return f"aibom_{int(time.time())}_{secrets.token_hex(3)}"

    def _persist(self) -> None:
        with self._lock:
            ordered = sorted(self._jobs.values(),
                             key=lambda j: j.get("started_at", ""), reverse=True)
            config.save_jobs(ordered)

    def reset_all(self) -> int:
        """Admin flush: drop every job, BOM document, and inventory rollup
        from memory and persistence immediately, without a restart."""
        with self._lock:
            n = len(self._jobs)
            self._jobs.clear()
        config.clear_all()
        return n

    def _update(self, job_id: str, **fields) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return
            job.update(fields)
        self._persist()

    def _log(self, job_id: str, message: str) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is not None:
                job.setdefault("log", []).append(f"{config.now_iso()}  {message}")
                job["log"] = job["log"][-50:]
                job["progress"] = message

    # ── Public API ────────────────────────────────────────────────────────────
    def list_jobs(self, limit: int = 100) -> list[dict]:
        with self._lock:
            jobs = sorted(self._jobs.values(),
                          key=lambda j: j.get("started_at", ""), reverse=True)
        return [dict(j) for j in jobs[:limit]]

    def get_job(self, job_id: str) -> dict | None:
        with self._lock:
            job = self._jobs.get(job_id)
            return dict(job) if job else None

    def submit_scan(self, repo: dict) -> str:
        # Collapse a re-submit while the same repo is already scanning.
        with self._lock:
            for job in self._jobs.values():
                if (job.get("repo_id") == repo.get("id")
                        and job.get("status") in ("queued", "running")):
                    return job["id"]
        job_id = self._new_job_id()
        job = {
            "id": job_id,
            "repo_id": repo.get("id"),
            "repo_name": repo.get("name"),
            "status": "queued",
            "progress": "Queued",
            "started_at": config.now_iso(),
            "finished_at": None,
            "report_id": None,
            "bom_available": False,
            "stats": None,
            "error": None,
            "log": [],
        }
        with self._lock:
            self._jobs[job_id] = job
        self._persist()
        threading.Thread(target=self._run, args=(job_id, repo),
                         name=f"aibom-{job_id}", daemon=True).start()
        return job_id

    # ── Worker ────────────────────────────────────────────────────────────────
    def _run(self, job_id: str, repo: dict) -> None:
        try:
            self._update(job_id, status="running")
            self._log(job_id, "Preparing workspace")
            scan_root, meta = broker_scanner.prepare_workspace(
                repo, progress=lambda m: self._log(job_id, m))

            self._log(job_id, "Building AI inventory")
            result = engine.scan(Path(scan_root),
                                 progress=lambda m: self._log(job_id, m))
            stats = result["stats"]
            self._log(job_id, f"Inventory complete: {stats['components_total']} "
                              f"component(s), {len(result['findings'])} finding(s)")

            report = mapper.result_to_report(result, repo, meta)
            report_id = self._save_report(report)
            self._log(job_id, f"Report saved: {report_id}")

            bom = mapper.to_cyclonedx(result, repo, meta)
            config.save_bom(job_id, bom)
            config.save_latest(repo["id"],
                               mapper.to_rollup(result, repo, meta, job_id, report_id))

            counts = report["scan_metadata"]["severity_counts"]
            self._update(
                job_id, status="done", finished_at=config.now_iso(),
                report_id=report_id, bom_available=True, progress="Done",
                stats={
                    "findings_total": len(result["findings"]),
                    "components_total": stats["components_total"],
                    "providers": stats["providers"],
                    "models_total": len(stats["models"]),
                    "flags": stats["flags"],
                    "ai_detected": stats["ai_detected"],
                    "severity_counts": counts,
                    "overall_risk": report["overall_risk"],
                },
            )
        except Exception as exc:  # surface any failure to the dashboard
            self._log(job_id, f"ERROR: {exc}")
            self._update(job_id, status="error", finished_at=config.now_iso(),
                         progress="Failed", error=str(exc))
            import logging
            logging.getLogger("aibom").error("aibom job %s failed\n%s",
                                             job_id, traceback.format_exc())

    @staticmethod
    def _save_report(report: dict) -> str:
        """Persist via the host app so the report joins the existing UI list."""
        import app as tm_app  # lazy to avoid a circular import at load
        return tm_app._save_report(report, report["title"])


_service: AibomService | None = None
_service_lock = threading.Lock()


def get_service() -> AibomService:
    global _service
    with _service_lock:
        if _service is None:
            _service = AibomService()
    return _service
