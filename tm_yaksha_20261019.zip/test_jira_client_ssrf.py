"""Regression tests for jira_client._assert_safe_url — the SSRF guard on the
Jira/Azure/Confluence outbound calls. jira_url/azure_org/confluence_base_url
all come straight from the request body (app.py's _create_tickets_impl /
_publish_confluence_page_impl), so this is the one place that stands between
a caller and an internal-network fetch + full finding-text exfiltration.

socket.getaddrinfo is mocked throughout so these tests never depend on real
DNS/network access and are deterministic in CI.
"""
from __future__ import annotations

import socket
import unittest
from unittest import mock

import jira_client


def _fake_addrinfo(ip: str):
    return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, 443))]


class AssertSafeUrlTests(unittest.TestCase):
    def test_rejects_non_https_scheme(self):
        with self.assertRaises(jira_client.UnsafeURLError):
            jira_client._assert_safe_url("http://example.com/rest/api/3/issue")

    def test_rejects_url_with_no_host(self):
        with self.assertRaises(jira_client.UnsafeURLError):
            jira_client._assert_safe_url("https:///rest/api/3/issue")

    def test_rejects_loopback_address(self):
        with mock.patch.object(socket, "getaddrinfo",
                               return_value=_fake_addrinfo("127.0.0.1")):
            with self.assertRaises(jira_client.UnsafeURLError):
                jira_client._assert_safe_url("https://internal.example/issue")

    def test_rejects_private_rfc1918_address(self):
        with mock.patch.object(socket, "getaddrinfo",
                               return_value=_fake_addrinfo("10.1.2.3")):
            with self.assertRaises(jira_client.UnsafeURLError):
                jira_client._assert_safe_url("https://internal.example/issue")

    def test_rejects_link_local_metadata_address(self):
        # 169.254.169.254 is the AWS/GCP/Azure cloud-metadata address.
        with mock.patch.object(socket, "getaddrinfo",
                               return_value=_fake_addrinfo("169.254.169.254")):
            with self.assertRaises(jira_client.UnsafeURLError):
                jira_client._assert_safe_url("https://metadata.internal/issue")

    def test_rejects_unresolvable_host(self):
        with mock.patch.object(socket, "getaddrinfo",
                               side_effect=socket.gaierror("nope")):
            with self.assertRaises(jira_client.UnsafeURLError):
                jira_client._assert_safe_url("https://does-not-resolve.invalid/issue")

    def test_allows_public_https_address(self):
        with mock.patch.object(socket, "getaddrinfo",
                               return_value=_fake_addrinfo("8.8.8.8")):
            jira_client._assert_safe_url("https://myorg.atlassian.net/rest/api/3/issue")
            # No exception raised == pass.

    def test_http_helper_calls_the_guard_before_urlopen(self):
        # Wire-level check: _http (the single choke point for every outbound
        # call in this module) must invoke the guard, not just the unit above.
        with mock.patch.object(jira_client, "_assert_safe_url",
                               side_effect=jira_client.UnsafeURLError("blocked")) as guard, \
             mock.patch("urllib.request.urlopen") as urlopen:
            with self.assertRaises(jira_client.UnsafeURLError):
                jira_client._http("POST", "https://evil.example/x", {})
        guard.assert_called_once_with("https://evil.example/x")
        urlopen.assert_not_called()


if __name__ == "__main__":
    unittest.main()
