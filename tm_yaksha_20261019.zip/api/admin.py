"""Admin-only user management + the "flush everything" data reset.

Every route in `bp` and `page_bp` requires an authenticated admin session
(auth.admin_gate, applied blueprint-wide via before_request) — this is the
one part of the app where _REQUIRE_LOGIN being off is not an option; the
gate here is unconditional regardless of the app.require_login setting.

Routes:
  GET    /admin                          the user-management + danger-zone page
  GET    /api/v1/admin/users             list every account (no password hashes)
  POST   /api/v1/admin/users             create one {email, password, role?}
  POST   /api/v1/admin/users/<email>/role   change role {role: "user"|"admin"}
  DELETE /api/v1/admin/users/<email>     remove an account
  POST   /api/v1/admin/flush             wipe every data store except accounts;
                                          requires {"confirm": "FLUSH"} in the body
  POST   /api/v1/admin/findings/<fp>/delete   hard-delete one finding (by its
                                          suppressions.engine.finding_fingerprint)
                                          from every report that carries it --
                                          gone from SAST, correlation, triage,
                                          everywhere at once, not just muted;
                                          requires {"confirm": "DELETE"} in the body

Self-lockout guards: an admin can't demote or delete themselves, and the
last remaining admin can't be demoted or deleted by anyone — either would
leave the instance with `require_login` on and no admin able to sign in and
fix it (a self-inflicted lockout with no CLI-free recovery from the browser
side; users_db.py's `promote`/`demote` commands still work from a terminal,
but the whole point of this page is not to need one).
"""
from __future__ import annotations

import logging

from flask import Blueprint, jsonify, render_template, request

import auth
import users_db

log = logging.getLogger("admin")

bp = Blueprint("admin_api", __name__, url_prefix="/api/v1/admin")
page_bp = Blueprint("admin_page", __name__)

_FLUSH_CONFIRM_PHRASE = "FLUSH"
_DELETE_FINDING_CONFIRM_PHRASE = "DELETE"
# app.* keys a flush must never silently erase: wiping the row that stores
# these would revert them to their (looser) hardcoded defaults on the next
# restart, which is a security regression disguised as a data-hygiene action.
_PRESERVED_SETTINGS = frozenset({
    "app.require_login", "app.api_key", "app.frame_options", "app.disable_csp",
})


@bp.before_request
@page_bp.before_request
def _gate():
    return auth.admin_gate()


@page_bp.get("/admin")
def admin_page():
    from app import _CSRF_TOKEN
    return render_template("admin.html", csrf_token=_CSRF_TOKEN,
                           users=users_db.list_users())


@bp.get("/users")
def list_users():
    return jsonify({"success": True, "users": users_db.list_users()})


@bp.post("/users")
def create_user():
    body = request.get_json(silent=True) or {}
    email = str(body.get("email") or "").strip()
    password = str(body.get("password") or "")
    role = str(body.get("role") or "user").strip()
    try:
        user = users_db.create_user(email, password, role=role)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    return jsonify({"success": True, "user": user}), 201


@bp.post("/users/<email>/role")
def set_role(email: str):
    body = request.get_json(silent=True) or {}
    role = str(body.get("role") or "").strip()
    is_self = auth.current_user_email() and \
        auth.current_user_email().strip().lower() == email.strip().lower()
    if role != "admin" and users_db.is_admin(email) and users_db.admin_count() <= 1:
        return jsonify({"success": False,
                        "error": "cannot demote the last remaining admin"}), 400
    if role != "admin" and is_self:
        return jsonify({"success": False,
                        "error": "cannot demote your own account"}), 400
    try:
        ok = users_db.set_role(email, role)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    if not ok:
        return jsonify({"success": False, "error": "no such user"}), 404
    return jsonify({"success": True})


@bp.delete("/users/<email>")
def delete_user(email: str):
    is_self = auth.current_user_email() and \
        auth.current_user_email().strip().lower() == email.strip().lower()
    if is_self:
        return jsonify({"success": False, "error": "cannot delete your own account"}), 400
    if users_db.is_admin(email) and users_db.admin_count() <= 1:
        return jsonify({"success": False,
                        "error": "cannot delete the last remaining admin"}), 400
    removed = users_db.delete_user(email)
    if not removed:
        return jsonify({"success": False, "error": "no such user"}), 404
    return jsonify({"success": True, "deleted": email})


def _flush_everything() -> dict:
    """Wipe every data store except user accounts. Deliberately irreversible
    — there is no backup step; the confirm-phrase and the admin gate are the
    only safety nets. Returns a per-store count of what was removed."""
    import report_db
    import settings_db
    import ownership
    import regression
    import verdict_tracking
    from suppressions import store as supp_store
    from broker.service import get_service as get_broker_service
    from dast.service import get_service as get_dast_service
    from aibom.service import get_service as get_aibom_service

    return {
        "reports": report_db.delete_all(),
        "broker_jobs": get_broker_service().reset_job_history(),
        "dast_jobs": get_dast_service().reset_job_history(),
        "aibom_jobs": get_aibom_service().reset_all(),
        "suppressions": supp_store.delete_all(),
        "owners": ownership.delete_all(),
        "verdict_history": verdict_tracking.delete_all(),
        "regression_cases": regression.delete_all(),
        "settings": settings_db.clear_all(preserve=_PRESERVED_SETTINGS),
    }


@bp.post("/flush")
def flush_everything():
    body = request.get_json(silent=True) or {}
    if str(body.get("confirm") or "").strip() != _FLUSH_CONFIRM_PHRASE:
        return jsonify({
            "success": False,
            "error": f'confirmation required: send {{"confirm": "{_FLUSH_CONFIRM_PHRASE}"}}',
        }), 400
    summary = _flush_everything()
    log.warning("admin %s flushed all data stores: %s", auth.current_user_email(), summary)
    return jsonify({"success": True, "cleared": summary})


@bp.post("/findings/<fingerprint>/delete")
def delete_finding(fingerprint: str):
    body = request.get_json(silent=True) or {}
    if str(body.get("confirm") or "").strip() != _DELETE_FINDING_CONFIRM_PHRASE:
        return jsonify({
            "success": False,
            "error": f'confirmation required: send {{"confirm": "{_DELETE_FINDING_CONFIRM_PHRASE}"}}',
        }), 400

    import report_db
    result = report_db.delete_finding(fingerprint)
    if not result["reports_affected"]:
        return jsonify({"success": False, "error": "no finding with that fingerprint found"}), 404

    # Best-effort refresh of each affected report's JSON backup file so it
    # doesn't silently drift from the SQLite row that now lacks the finding
    # -- same non-fatal pattern app._save_report uses for the initial write.
    try:
        from app import REPORTS_DIR
        import report_store
        for rid in result["report_ids"]:
            updated = report_db.get_report(rid)
            if updated:
                report_store.atomic_write_json(REPORTS_DIR / f"{rid}.json", updated)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("JSON backup refresh failed after deleting finding %s: %s", fingerprint, exc)

    log.warning("admin %s hard-deleted finding %s: %s", auth.current_user_email(), fingerprint, result)
    return jsonify({"success": True, **result})


@bp.get("/epss-kev/status")
def epss_kev_status():
    """Freshness of the cached EPSS/CISA-KEV data the correlator's
    exploitability scoring reads (see epss_kev.py) — a filesystem-only read,
    never a live fetch."""
    import epss_kev
    return jsonify({"success": True, **epss_kev.cache_status()})


@bp.post("/epss-kev/refresh")
def epss_kev_refresh():
    """Pull the current CISA KEV catalog in full, plus EPSS scores for every
    CVE id TM's own SBOM detectors can emit (epss_kev.known_cves) union any
    CVE ids named in already-saved reports -- so a stale/never-fetched cache
    doesn't quietly leave every correlation run's real-world-exploitation
    signal at 0. The only network call this app makes on an admin action
    rather than a background job; kept explicit/on-demand rather than
    automatic so an air-gapped install never has correlation depend on it.
    """
    import epss_kev
    import report_db
    from correlator import engine as correlator_engine

    cves = set(epss_kev.known_cves())
    for report in report_db.all_reports(limit=2000):
        for obs in correlator_engine.observe_report(report):
            cves.update(obs.cves)

    result = epss_kev.refresh_all(cves)
    log.info("admin %s refreshed EPSS/KEV cache: %s", auth.current_user_email(), result)
    return jsonify({"success": not (result["kev_error"] and result["epss_error"]), **result})
