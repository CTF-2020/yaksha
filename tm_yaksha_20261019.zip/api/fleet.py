"""Fleet-wide correlation posture across every registered SAST repo / DAST
target -- see fleet.py for how a correlation report gets attributed back to
the repo/target it covers.

Routes:
  GET /api/v1/fleet/summary   totals + coverage + worst-repos-first rollup
  GET /api/v1/fleet/repos     one row per registered repo/target
"""
from __future__ import annotations

from flask import Blueprint, jsonify

import fleet

bp = Blueprint("fleet_api", __name__, url_prefix="/api/v1/fleet")


@bp.get("/summary")
def summary():
    return jsonify({"success": True, **fleet.summary()})


@bp.get("/repos")
def repos():
    rows = fleet.repo_posture()
    return jsonify({"success": True, "count": len(rows), "repos": rows})
