"""Local system design knowledge bundle."""

