"""sbom_parser.py — CycloneDX / SPDX SBOM parser with vulnerability pattern matching."""
from __future__ import annotations
import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

# ── Known vulnerable version patterns ─────────────────────────────────────────
# Format: {package_name: [(vuln_id, affected_version_regex, description, severity, cve)]}
KNOWN_VULNS: dict[str, list[tuple]] = {
    # (vuln_id, version_prefix_pattern, description, severity, cve)
    # Patterns match the START of the version string for simplicity and accuracy
    "log4j":          [("LOG4SHELL",   r"^2\.(0|1[0-4])\.",  "Remote code execution via JNDI lookup",          "Critical", "CVE-2021-44228")],
    "log4j-core":     [("LOG4SHELL",   r"^2\.(0|1[0-4])\.",  "Remote code execution via JNDI lookup",          "Critical", "CVE-2021-44228")],
    "spring-core":    [("SPRING4SHELL",r"^5\.[23]\.",         "Remote code execution via data binding",         "Critical", "CVE-2022-22965")],
    "spring-web":     [("SPRING4SHELL",r"^5\.[23]\.",         "Remote code execution via data binding",         "Critical", "CVE-2022-22965")],
    "openssl":        [("HEARTBLEED",  r"^1\.0\.[01][^0-9]",  "Memory disclosure via Heartbleed",               "Critical", "CVE-2014-0160")],
    "struts2":        [("S2-045",      r"^2\.[23]\.",          "Remote code execution via Content-Type header",  "Critical", "CVE-2017-5638")],
    "jackson-databind":[("DESER",      r"^2\.(9|1[01])\.",    "Unsafe deserialization enabling RCE",            "High",     "CVE-2020-35728")],
    "pyyaml":         [("YAML-EXEC",   r"^[0-5]\.",           "Code execution via unsafe yaml.load()",          "High",     "CVE-2017-18342")],
    "pillow":         [("PIL-EXEC",    r"^[0-8]\.",           "Multiple arbitrary code execution vulnerabilities","High",    "CVE-2022-22817")],
    "requests":       [("CERT-VERIFY", r"^2\.2[0-7]\.",       "Proxy-Authorization header leaked on redirect",   "Medium",   "CVE-2023-32681")],
    "urllib3":        [("CRLF-INJECT", r"^1\.(2[0-5]|[0-9])\.", "CRLF injection in request line",              "Medium",   "CVE-2020-26137")],
    "cryptography":   [("PADDING-ORA", r"^(0|1|2|3[0-9])\.", "Padding oracle in symmetric decryption",         "High",     "CVE-2023-23931")],
    "paramiko":       [("AUTH-BYPASS", r"^(1\.|2\.[0-3]\.)",  "Authentication bypass vulnerability",            "Critical", "CVE-2018-1000805")],
    "werkzeug":       [("PATH-TRAV",   r"^[01]\.",            "Path traversal in debug mode",                   "High",     "CVE-2023-25577")],
    "flask":          [("DEBUG-RCE",   r"^0\.",               "Debug mode RCE in very old versions",            "High",     "CVE-2019-1010083")],
    "django":         [("SQL-INJECT",  r"^(3\.[012]|2\.)",    "SQL injection in annotate/alias queryset",       "High",     "CVE-2022-34265")],
    "express":        [("OPEN-REDIR",  r"^4\.[0-9]\.",        "Open redirect in res.redirect()",                "Medium",   "CVE-2022-24999")],
    "lodash":         [("PROTO-POLL",  r"^4\.1[0-6]\.",       "Prototype pollution enabling code injection",    "High",     "CVE-2020-8203")],
    "moment":         [("REDOS",       r"^2\.(1[0-9]|2[0-8])\.", "ReDoS in date string parsing",               "High",     "CVE-2022-31129")],
    "axios":          [("SSRF",        r"^0\.(1[0-9]|2[0-6])\.", "SSRF via DNS rebinding",                      "Medium",   "CVE-2023-45857")],
    "minimist":       [("PROTO-POLL",  r"^0\.",               "Prototype pollution enabling arbitrary code",    "Critical", "CVE-2021-44906")],
    "node-fetch":     [("OPEN-REDIR",  r"^2\.[0-5]\.",        "Open redirect vulnerability",                    "Medium",   "CVE-2022-0235")],
    "tar":            [("PATH-TRAV",   r"^[0-5]\.",           "Path traversal when extracting archives",        "High",     "CVE-2021-37713")],
    "semver":         [("REDOS",       r"^[567]\.",           "Regular expression denial of service",           "High",     "CVE-2022-25883")],
    "xmldom":         [("XXE",         r"^0\.[0-6]\.",        "XML External Entity injection",                  "High",     "CVE-2022-37616")],
    "serialize-javascript":[("XSS",   r"^[0-3]\.",           "XSS via serialized HTML in JSON output",         "High",     "CVE-2020-7660")],
    "netty":          [("HTTP-SPLIT",  r"^4\.1\.(4[0-9]|[0-3][0-9])\.", "HTTP request smuggling",              "High",     "CVE-2021-21295")],
    "shiro":          [("AUTH-BYPASS", r"^1\.(2\.[0-5]|[01]\.)", "Authentication bypass via padding oracle",   "Critical", "CVE-2016-4437")],
    "fastjson":       [("DESER-RCE",   r"^1\.2\.(2[0-9]|3[0-9]|4[0-7])\.", "Remote code execution via deserialization", "Critical", "CVE-2022-25845")],
}

# ── Data classes ───────────────────────────────────────────────────────────────

@dataclass
class SBOMComponent:
    name: str
    version: str
    type: str = "library"
    purl: str = ""
    license: str = ""
    supplier: str = ""


@dataclass
class SBOMVulnFinding:
    component: str
    version: str
    vuln_id: str
    cve: str
    description: str
    severity: str
    recommendation: str = "Update to a patched version and verify the fix applies to your usage"


@dataclass
class SBOMReport:
    format: str
    tool: str
    components: list[SBOMComponent] = field(default_factory=list)
    vulnerabilities: list[SBOMVulnFinding] = field(default_factory=list)
    eol_components: list[dict] = field(default_factory=list)
    unpinned_components: list[str] = field(default_factory=list)
    overall_risk: str = "Low"
    summary: str = ""


# ── CycloneDX parser ───────────────────────────────────────────────────────────

_CDX_NS = {
    "cdx14": "http://cyclonedx.org/schema/bom/1.4",
    "cdx15": "http://cyclonedx.org/schema/bom/1.5",
    "cdx16": "http://cyclonedx.org/schema/bom/1.6",
}


def _parse_cyclonedx_json(data: dict) -> list[SBOMComponent]:
    components = []
    for comp in data.get("components", []):
        components.append(SBOMComponent(
            name=comp.get("name", ""),
            version=comp.get("version", ""),
            type=comp.get("type", "library"),
            purl=comp.get("purl", ""),
            license=_extract_cdx_license(comp),
            supplier=comp.get("supplier", {}).get("name", "") if isinstance(comp.get("supplier"), dict) else "",
        ))
    return components


def _extract_cdx_license(comp: dict) -> str:
    licenses = comp.get("licenses", [])
    if not licenses:
        return ""
    first = licenses[0]
    if isinstance(first, dict):
        lic = first.get("license", {})
        return lic.get("id", lic.get("name", ""))
    return str(first)


def _parse_cyclonedx_xml(content: str) -> list[SBOMComponent]:
    try:
        root = ET.fromstring(content)
    except ET.ParseError as e:
        raise ValueError(f"Invalid CycloneDX XML: {e}")

    ns = root.tag.split("}")[0].lstrip("{") if "}" in root.tag else ""
    prefix = f"{{{ns}}}" if ns else ""

    components = []
    for comp in root.iter(f"{prefix}component"):
        name_el    = comp.find(f"{prefix}name")
        version_el = comp.find(f"{prefix}version")
        purl_el    = comp.find(f"{prefix}purl")
        name       = name_el.text.strip() if name_el is not None and name_el.text else ""
        version    = version_el.text.strip() if version_el is not None and version_el.text else ""
        purl       = purl_el.text.strip() if purl_el is not None and purl_el.text else ""
        if name:
            components.append(SBOMComponent(name=name, version=version, purl=purl))
    return components


# ── SPDX parser ────────────────────────────────────────────────────────────────

def _parse_spdx_json(data: dict) -> list[SBOMComponent]:
    components = []
    for pkg in data.get("packages", []):
        name    = pkg.get("name", "")
        version = pkg.get("versionInfo", "")
        purl    = next(
            (r["referenceLocator"] for r in pkg.get("externalRefs", [])
             if r.get("referenceType") == "purl"),
            "",
        )
        if name:
            components.append(SBOMComponent(name=name, version=version, purl=purl))
    return components


def _parse_spdx_text(content: str) -> list[SBOMComponent]:
    components = []
    current: dict = {}
    for line in content.splitlines():
        if line.startswith("PackageName:"):
            if current.get("name"):
                components.append(SBOMComponent(
                    name=current["name"], version=current.get("version",""), purl=current.get("purl","")))
            current = {"name": line.split(":", 1)[1].strip()}
        elif line.startswith("PackageVersion:"):
            current["version"] = line.split(":", 1)[1].strip()
        elif line.startswith("ExternalRef:") and "purl" in line.lower():
            current["purl"] = line.split()[-1]
    if current.get("name"):
        components.append(SBOMComponent(
            name=current["name"], version=current.get("version",""), purl=current.get("purl","")))
    return components


# ── Vulnerability scanner ──────────────────────────────────────────────────────

def _scan_components(components: list[SBOMComponent]) -> list[SBOMVulnFinding]:
    findings = []
    seen: set[tuple] = set()  # deduplicate (component, version, cve)
    for comp in components:
        name_lower = comp.name.lower().replace("_", "-")
        for pattern_name, vulns in KNOWN_VULNS.items():
            # Require exact match or that the pattern is an exact name boundary match
            if name_lower != pattern_name and not (
                name_lower.endswith(f"-{pattern_name}") or
                name_lower.startswith(f"{pattern_name}-") or
                name_lower == pattern_name
            ):
                continue
            for vuln_id, ver_regex, description, severity, cve in vulns:
                if comp.version and re.search(ver_regex, comp.version):
                    key = (comp.name, comp.version, cve)
                    if key in seen:
                        continue
                    seen.add(key)
                    findings.append(SBOMVulnFinding(
                        component=comp.name,
                        version=comp.version,
                        vuln_id=vuln_id,
                        cve=cve,
                        description=description,
                        severity=severity,
                    ))
    return findings


def _find_unpinned(components: list[SBOMComponent]) -> list[str]:
    unpinned = []
    for comp in components:
        v = comp.version.strip()
        if not v or v in ("", "latest", "LATEST", "*", "any"):
            unpinned.append(comp.name)
        elif re.match(r"^[\^~><=]", v):
            unpinned.append(f"{comp.name}@{v} (range — not pinned)")
    return unpinned


def _overall_risk(vulns: list[SBOMVulnFinding]) -> str:
    sevs = {v.severity for v in vulns}
    if "Critical" in sevs: return "Critical"
    if "High" in sevs:     return "High"
    if "Medium" in sevs:   return "Medium"
    if "Low" in sevs:      return "Low"
    return "None"


# ── Public API ─────────────────────────────────────────────────────────────────

def parse_sbom(content: str, filename: str = "") -> SBOMReport:
    """
    Parse a CycloneDX (JSON/XML) or SPDX (JSON/text) SBOM and return vulnerability findings.
    """
    fname = filename.lower()
    components: list[SBOMComponent] = []
    fmt = "unknown"
    tool = ""

    if fname.endswith(".json") or (not fname.endswith(".xml") and content.lstrip().startswith("{")):
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON SBOM: {e}")

        if "bomFormat" in data and data.get("bomFormat", "").lower() == "cyclonedx":
            fmt = "CycloneDX JSON"
            tool = data.get("metadata", {}).get("tools", [{}])[0].get("name", "") if data.get("metadata", {}).get("tools") else ""
            components = _parse_cyclonedx_json(data)
        elif "spdxVersion" in data or "packages" in data:
            fmt = "SPDX JSON"
            components = _parse_spdx_json(data)
        else:
            raise ValueError("JSON file is not a recognized SBOM format (expected CycloneDX or SPDX)")

    elif fname.endswith(".xml") or content.lstrip().startswith("<"):
        fmt = "CycloneDX XML"
        components = _parse_cyclonedx_xml(content)

    elif content.startswith("SPDXVersion:") or "PackageName:" in content:
        fmt = "SPDX Text"
        components = _parse_spdx_text(content)

    else:
        raise ValueError("Unrecognized SBOM format. Supported: CycloneDX JSON/XML, SPDX JSON/text")

    vulns       = _scan_components(components)
    unpinned    = _find_unpinned(components)
    risk        = _overall_risk(vulns)
    crit_count  = sum(1 for v in vulns if v.severity == "Critical")
    high_count  = sum(1 for v in vulns if v.severity == "High")

    summary = (
        f"{fmt} SBOM parsed: {len(components)} components, "
        f"{len(vulns)} known vulnerabilities found "
        f"(Critical: {crit_count}, High: {high_count}). "
        f"{len(unpinned)} unpinned components. Overall risk: {risk}."
    )

    return SBOMReport(
        format=fmt,
        tool=tool,
        components=components,
        vulnerabilities=vulns,
        unpinned_components=unpinned,
        overall_risk=risk,
        summary=summary,
    )


def sbom_to_categories(report: SBOMReport) -> list[dict]:
    """Convert SBOMReport into the analyzer 'categories' format for UI rendering."""
    if not report.vulnerabilities:
        return []

    from collections import defaultdict
    by_sev: dict[str, list] = defaultdict(list)
    for v in report.vulnerabilities:
        by_sev[v.severity].append(v)

    categories = []
    for sev in ("Critical", "High", "Medium", "Low"):
        group = by_sev.get(sev, [])
        if not group:
            continue
        categories.append({
            "id":    f"SBOM-{sev.upper()}",
            "name":  f"Vulnerable Components — {sev}",
            "risk":  sev,
            "risk_score": {"Critical": 9, "High": 7, "Medium": 5, "Low": 3}.get(sev, 5),
            "_source": "SBOM",
            "affected_components": [f"{v.component}@{v.version}" for v in group],
            "threats": [
                {
                    "name":          f"{v.vuln_id} in {v.component}@{v.version}",
                    "description":   v.description,
                    "attack_vector": f"Exploiting known vulnerability {v.cve}",
                    "impact":        sev,
                }
                for v in group[:4]
            ],
            "mitigations": [
                {"action": f"Update {v.component} from {v.version} to a patched version ({v.cve})", "priority": "Immediate" if sev in ("Critical","High") else "Short-term"}
                for v in group[:4]
            ],
            "notes": f"{len(group)} component(s) with {sev} vulnerabilities. OWASP A06 / Supply Chain risk.",
        })
    return categories
