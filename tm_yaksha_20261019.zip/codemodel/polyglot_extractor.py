"""Regex/structure-based extraction for JS/TS, Go and Java sources.

The Python path parses a real AST; no such parser ships in the stdlib for these
languages, so this module recovers the same *design facts* (entry points, sinks,
controls, stores, secrets) with a middle road between "grep" and "a parser":

  1. a comment/string-aware **masker** produces a copy of the source where every
     comment and string body is blanked (offsets preserved) and every string
     literal is recorded — so code patterns never match inside strings/comments,
     while route paths are still read from the recorded literals;
  2. a **brace matcher** over the masked text turns function/method headers into
     line-accurate body spans, so each sink is attributed to the function that
     contains it and inline route closures get their own synthetic span;
  3. per-language **signature tables** (routes, sinks, auth markers, stores,
     secret hints) drive the actual matching.

Output re-uses :class:`python_extractor.FileFacts`/`FunctionInfo`, so the
cross-file join in :mod:`codemodel.extractor` (call-graph sink reachability,
entry-point assembly) works on these languages unchanged. Confidence is
deliberately capped at MEDIUM for anything inferred without an AST.
"""
from __future__ import annotations

import bisect
import re

from .model import HIGH, LOW, MEDIUM, Control, DataStore, ExternalCall, Secret, Sink
from .python_extractor import FileFacts, FunctionInfo

_MAX_CALLS_PER_FN = 200
_KEYWORDS = {
    "if", "for", "while", "switch", "catch", "return", "new", "else", "do",
    "try", "throw", "typeof", "delete", "in", "of", "await", "async", "case",
    "function", "class", "super", "this", "void", "instanceof", "yield",
    "defer", "go", "select", "range", "make", "map", "chan", "func", "len",
    "append", "copy", "panic", "recover", "synchronized", "assert",
}


# ── masking ───────────────────────────────────────────────────────────────────
class Masked:
    """Source with comments/strings blanked; literals recorded with offsets."""

    def __init__(self, source: str, lang: str):
        self.source = source
        self.text, self.strings = _mask(source, lang)
        self.line_starts = [0]
        for i, ch in enumerate(source):
            if ch == "\n":
                self.line_starts.append(i + 1)

    def line_of(self, offset: int) -> int:
        return bisect.bisect_right(self.line_starts, offset)

    def string_in(self, start: int, end: int) -> str:
        """First recorded string literal beginning inside [start, end)."""
        for s, _e, val in self.strings:
            if start <= s < end:
                return val
        return ""

    def strings_in(self, start: int, end: int) -> list:
        return [val for s, _e, val in self.strings if start <= s < end]


def _mask(source: str, lang: str) -> tuple[str, list]:
    """Blank comments and string bodies; keep newlines and offsets stable.

    JS template literals keep their ``${...}`` interpolation UNmasked (that is
    code — taint tokens like ``req.query`` live there); Go raw strings and Java
    text blocks are handled; unterminated literals mask to end of line only for
    single-line kinds, end of file for multi-line kinds (fail-quiet).
    """
    out = list(source)
    strings: list = []
    i, n = 0, len(source)
    js_like = lang in ("javascript", "typescript")

    def blank(a: int, b: int):
        for k in range(a, b):
            if out[k] != "\n":
                out[k] = " "

    while i < n:
        ch = source[i]
        nxt = source[i + 1] if i + 1 < n else ""
        if ch == "/" and nxt == "/":
            j = source.find("\n", i)
            j = n if j < 0 else j
            blank(i, j)
            i = j
        elif ch == "/" and nxt == "*":
            j = source.find("*/", i + 2)
            j = n if j < 0 else j + 2
            blank(i, j)
            i = j
        elif lang == "java" and source.startswith('"""', i):
            j = source.find('"""', i + 3)
            j = n if j < 0 else j + 3
            strings.append((i, j, source[i + 3:max(i + 3, j - 3)]))
            blank(i, j)
            i = j
        elif ch == "`" and (js_like or lang == "go"):
            if js_like:
                i = _mask_js_template(source, out, strings, i)
            else:  # Go raw string: no escapes, runs to next backtick
                j = source.find("`", i + 1)
                j = n if j < 0 else j + 1
                strings.append((i, j, source[i + 1:max(i + 1, j - 1)]))
                blank(i, j)
                i = j
        elif ch in "\"'":
            start = i
            i += 1
            while i < n and source[i] != ch and source[i] != "\n":
                i += 2 if source[i] == "\\" else 1
            end = min(i + 1, n)
            strings.append((start, end, source[start + 1:i]))
            blank(start, end)
            i = end
        else:
            i += 1
    return "".join(out), strings


def _mask_js_template(source: str, out: list, strings: list, start: int) -> int:
    """Mask a JS template literal but leave ``${...}`` interpolation as code."""
    n = len(source)
    i = start + 1
    parts: list[str] = []
    seg_start = i
    while i < n:
        ch = source[i]
        if ch == "\\":
            i += 2
            continue
        if ch == "`":
            for k in range(seg_start, i):
                if out[k] != "\n":
                    out[k] = " "
            parts.append(source[seg_start:i])
            strings.append((start, i + 1, "".join(parts)))
            out[start] = " "
            out[i] = " "
            return i + 1
        if ch == "$" and i + 1 < n and source[i + 1] == "{":
            for k in range(seg_start, i):
                if out[k] != "\n":
                    out[k] = " "
            parts.append(source[seg_start:i])
            depth = 0
            j = i + 1
            while j < n:
                if source[j] == "{":
                    depth += 1
                elif source[j] == "}":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            parts.append("${…}")
            i = j + 1
            seg_start = i
            continue
        i += 1
    # unterminated: blank to EOF
    for k in range(seg_start, n):
        if out[k] != "\n":
            out[k] = " "
    strings.append((start, n, "".join(parts)))
    return n


def _match_bracket(text: str, open_idx: int) -> int:
    """Index of the bracket closing text[open_idx], or -1."""
    pairs = {"(": ")", "{": "}", "[": "]"}
    close = pairs.get(text[open_idx])
    if not close:
        return -1
    depth = 0
    for i in range(open_idx, len(text)):
        c = text[i]
        if c == text[open_idx]:
            depth += 1
        elif c == close:
            depth -= 1
            if depth == 0:
                return i
    return -1


# ── function spans ────────────────────────────────────────────────────────────
class _Span:
    __slots__ = ("name", "params", "header", "body_start", "body_end", "fn")

    def __init__(self, name, params, header, body_start, body_end, fn):
        self.name, self.params = name, params
        self.header, self.body_start, self.body_end = header, body_start, body_end
        self.fn = fn


_FN_HEADERS = {
    "javascript": [
        re.compile(r"\bfunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)", re.S),
        re.compile(r"\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*"
                   r"(?:async\s+)?(?:function\b[^({]*\(([^)]*)\)"
                   r"|\(([^)]*)\)\s*=>|([A-Za-z_$][\w$]*)\s*=>)", re.S),
        # class/object methods (NestJS controllers, exports = { handler(){} });
        # tolerates a TS return-type annotation between ) and {
        re.compile(r"^[ \t]*(?:public\s+|private\s+|protected\s+)?(?:async\s+)?"
                   r"([A-Za-z_$][\w$]*)\s*\(([^)]*)\)\s*(?::[^={;]*)?\{",
                   re.S | re.M),
    ],
    "go": [
        re.compile(r"\bfunc\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)\s*\(([^)]*)\)", re.S),
    ],
    "java": [
        re.compile(r"(?:public|protected|private|static|final|synchronized|abstract)"
                   r"[\w<>\[\],.\s]*?\s([A-Za-z_]\w*)\s*\(([^)]*)\)"
                   r"\s*(?:throws\s+[\w.,\s]+?)?\s*\{", re.S),
    ],
}
_FN_HEADERS["typescript"] = _FN_HEADERS["javascript"]


def _param_names(raw: str) -> set:
    names = set()
    for part in raw.split(","):
        part = part.split("=")[0].strip()
        # strip Go/TS/Java type portions: keep the identifier token(s)
        toks = re.findall(r"[A-Za-z_$][\w$]*", part)
        if not toks:
            continue
        # Go & Java write `name Type` / `Type name`; JS/TS write `name: Type`.
        # Taking every identifier over-approximates, which for taint checking
        # only risks marking tainted a little too eagerly on generic names —
        # so drop obvious type names (capitalised) unless it's the only token.
        kept = [t for t in toks if not t[0].isupper()] or toks[:1]
        names.update(kept)
    return names


def _find_spans(m: Masked, lang: str) -> list:
    spans: list[_Span] = []
    seen_bodies = set()
    for rx in _FN_HEADERS[lang]:
        for match in rx.finditer(m.text):
            name = match.group(1)
            if not name or name in _KEYWORDS:
                continue
            brace = m.text.find("{", match.end() - 1)
            if brace < 0:
                continue
            # between header and body brace: whitespace, an arrow, or a
            # TS/Java return-type annotation — anything else is not a function
            gap = m.text[match.end():brace].strip()
            if gap not in ("", "=>") and not gap.startswith(":") \
                    and not gap.startswith("throws"):
                continue
            end = _match_bracket(m.text, brace)
            if end < 0 or brace in seen_bodies:
                continue
            seen_bodies.add(brace)
            params = ""
            for g in (2, 3, 4):
                if match.lastindex and match.lastindex >= g and match.group(g):
                    params = match.group(g)
                    break
            fn = FunctionInfo(name, m.line_of(match.start()))
            fn.params = _param_names(params)
            spans.append(_Span(name, fn.params, match.start(), brace, end, fn))
    spans.sort(key=lambda s: (s.body_start, -s.body_end))
    return spans


def _innermost(spans: list, offset: int):
    best = None
    for s in spans:
        if s.body_start <= offset <= s.body_end:
            if best is None or (s.body_end - s.body_start) < (best.body_end - best.body_start):
                best = s
    return best


def _next_span_after(spans: list, offset: int):
    best = None
    for s in spans:
        if s.header >= offset and (best is None or s.header < best.header):
            best = s
    return best


# ── signature tables ──────────────────────────────────────────────────────────
# (regex, kind, family, cwe, requires-substring-in-source-or-None)
_SINKS = {
    "javascript": [
        (re.compile(r"\beval\s*\("), "code-eval", "code-injection", "CWE-94", None),
        (re.compile(r"\bnew\s+Function\s*\("), "code-eval", "code-injection", "CWE-94", None),
        (re.compile(r"\bvm\.(?:runInContext|runInNewContext|runInThisContext)\s*\("),
         "code-eval", "code-injection", "CWE-94", None),
        (re.compile(r"\b(?:execSync|execFileSync|spawnSync)\s*\("),
         "command", "command-injection", "CWE-78", None),
        (re.compile(r"\b(?:exec|execFile|spawn)\s*\("),
         "command", "command-injection", "CWE-78", "child_process"),
        (re.compile(r"\.(?:query|raw)\s*\("), "sql", "sql-injection", "CWE-89", None),
        (re.compile(r"\$where\b"), "sql", "sql-injection", "CWE-89", None),
        (re.compile(r"\bunserialize\s*\(|\.unserialize\s*\("),
         "deserialize", "deserialization", "CWE-502", None),
        (re.compile(r"\byaml\.load\s*\("), "deserialize", "deserialization", "CWE-502", None),
        (re.compile(r"\.(?:sendFile|createReadStream|readFile|readFileSync|"
                    r"writeFile|writeFileSync)\s*\("),
         "path", "path-traversal", "CWE-22", None),
        (re.compile(r"\.redirect\s*\("), "redirect", "open-redirect", "CWE-601", None),
        (re.compile(r"\brender_template_string\s*\("),  # parity, rare in JS
         "template", "template-injection", "CWE-1336", None),
    ],
    "go": [
        (re.compile(r"\bexec\.Command(?:Context)?\s*\("),
         "command", "command-injection", "CWE-78", None),
        # receiver must not be a request/context object: gin's c.Query() is a
        # query-param getter and r.URL.Query() parses the query string
        (re.compile(r"\b(?!(?:c|ctx|req|r|w|URL|url)\.)[A-Za-z_]\w*"
                    r"\.(?:Query|QueryRow|QueryContext|QueryRowContext|Exec"
                    r"|ExecContext|Raw)\s*\("), "sql", "sql-injection", "CWE-89", None),
        (re.compile(r"\btemplate\.(?:HTML|JS|URL)\s*\("),
         "template", "template-injection", "CWE-1336", None),
        (re.compile(r"\bgob\.NewDecoder\s*\("), "deserialize", "deserialization",
         "CWE-502", None),
        (re.compile(r"\b(?:os\.Open|os\.ReadFile|os\.Create|ioutil\.ReadFile"
                    r"|os\.OpenFile)\s*\("), "path", "path-traversal", "CWE-22", None),
        (re.compile(r"\bhttp\.Redirect\s*\("), "redirect", "open-redirect", "CWE-601", None),
    ],
    "java": [
        (re.compile(r"Runtime\s*\.\s*getRuntime\s*\(\s*\)\s*\.\s*exec\s*\("),
         "command", "command-injection", "CWE-78", None),
        (re.compile(r"\bnew\s+ProcessBuilder\s*\("),
         "command", "command-injection", "CWE-78", None),
        (re.compile(r"\.(?:executeQuery|executeUpdate|execute|addBatch)\s*\("),
         "sql", "sql-injection", "CWE-89", "Statement"),
        (re.compile(r"\.(?:createQuery|createNativeQuery|createSQLQuery)\s*\("),
         "sql", "sql-injection", "CWE-89", None),
        (re.compile(r"\bnew\s+ObjectInputStream\s*\(|\.readObject\s*\("),
         "deserialize", "deserialization", "CWE-502", None),
        (re.compile(r"\.eval\s*\("), "code-eval", "code-injection", "CWE-94",
         "ScriptEngine"),
        (re.compile(r"\bnew\s+File(?:InputStream|OutputStream|Reader|Writer)?\s*\("
                    r"|\bPaths\s*\.\s*get\s*\("), "path", "path-traversal", "CWE-22", None),
        (re.compile(r"\.sendRedirect\s*\("), "redirect", "open-redirect", "CWE-601", None),
    ],
}
_SINKS["typescript"] = _SINKS["javascript"]

_TAINT_GATED = {"path", "ssrf", "redirect"}

# request-input tokens per language — a sink argument containing one is tainted
_TAINT = {
    "javascript": re.compile(
        r"\breq\s*\.\s*(?:query|params|body|headers|cookies|url|param)\b"
        r"|\bctx\s*\.\s*(?:query|params|request)\b|\brequest\s*\.\s*(?:query|body|params)\b"),
    "go": re.compile(
        r"\br\s*\.\s*(?:URL|FormValue|Form|PostForm|Body|Header|Cookie)\b"
        r"|\bc\s*\.\s*(?:Param|Query|PostForm|FormValue|QueryParam|GetHeader|BindJSON)\b"
        r"|\bmux\s*\.\s*Vars\b|\bchi\s*\.\s*URLParam\b|\breq\s*\.\s*(?:URL|FormValue|Form)\b"),
    "java": re.compile(
        r"\b(?:request|req|httpServletRequest)\s*\.\s*get(?:Parameter|Header|"
        r"QueryString|PathInfo|Cookies|InputStream|Reader)\b"),
}
_TAINT["typescript"] = _TAINT["javascript"]

# http clients: tainted arg => SSRF sink, otherwise an outbound ExternalCall
_HTTP_CLIENT = {
    "javascript": re.compile(
        r"\b(?:axios|got|superagent)\s*[.(]|\bfetch\s*\(|\bhttps?\.(?:get|request)\s*\("),
    "go": re.compile(r"\bhttp\.(?:Get|Post|PostForm|Head)\s*\("
                     r"|\bclient\.(?:Get|Post|Do)\s*\("),
    "java": re.compile(r"\brestTemplate\.\w+\s*\(|\bWebClient\b|\bHttpClient\b"
                       r"|\bnew\s+URL\s*\("),
}
_HTTP_CLIENT["typescript"] = _HTTP_CLIENT["javascript"]

# receivers that are HTTP clients, never route registrars
_JS_CLIENT_ROOTS = {"axios", "http", "https", "got", "superagent", "fetch",
                    "request", "_", "$"}

# Agent/LLM tool registration: MCP TS SDK `server.tool("name", ..., handler)`,
# also used loosely by other agent frameworks with the same `.tool(` shape.
# Gated on a plausible receiver name or an AI-framework import hint so an
# unrelated `.tool(` call elsewhere isn't mistaken for one (parity with the
# HTTP client receiver gate above).
_JS_AGENT_TOOL = re.compile(r"\b([A-Za-z_$][\w$]*)\.tool\s*\(")
_JS_TOOL_RECEIVERS = {"server", "mcp", "tool", "agent", "toolserver"}
_AI_FRAMEWORK_HINT = {"mcp", "langchain", "langgraph", "openai", "anthropic", "crewai"}

# Direct LLM invocation (chat/completion/generate) — an outbound trust-boundary
# crossing to a third-party model provider.
_LLM_CALL_CHAIN = re.compile(
    r"\.(?:chat\s*\.\s*completions\s*\.\s*create|completions\s*\.\s*create|"
    r"messages\s*\.\s*create|generateContent)\s*\(")

_AUTH_MARKER = re.compile(
    r"authenticat|requireauth|require_auth|isauth|ensureauth|ensurelogged|verifytoken"
    r"|verify_token|checkauth|check_auth|jwtcheck|checkjwt|requiresignin|requirelogin"
    r"|loginrequired|authorize[dr]?\b|authguard|apikeyauth|passport\.|authmiddleware"
    r"|auth_middleware|requirerole|hasrole|mustauth|tokenrequired|withauth"
    r"|requireadmin|adminonly|admin_only", re.I)

_VALIDATION_MARKER = re.compile(
    r"\b(?:validate|validationresult|celebrate|checkschema|joi\.|zod\.|"
    r"\.parse(?:async)?\s*\(|binding\.validator|validator\.new|@valid\b|@validated\b)",
    re.I)

# import/require token -> (kind, engine) data stores
_STORES = {
    "javascript": {
        "pg": ("sql", "postgres"), "mysql": ("sql", "mysql"), "mysql2": ("sql", "mysql"),
        "sqlite3": ("sql", "sqlite"), "better-sqlite3": ("sql", "sqlite"),
        "mongodb": ("nosql", "mongo"), "mongoose": ("nosql", "mongo"),
        "redis": ("cache", "redis"), "ioredis": ("cache", "redis"),
        "knex": ("sql", "sql"), "sequelize": ("sql", "sql"), "typeorm": ("sql", "sql"),
        "prisma": ("sql", "sql"), "@prisma/client": ("sql", "sql"),
        "aws-sdk": ("object-storage", "aws"), "@aws-sdk/client-s3": ("object-storage", "aws"),
        "elasticsearch": ("nosql", "elasticsearch"),
        "@elastic/elasticsearch": ("nosql", "elasticsearch"),
        "cassandra-driver": ("nosql", "cassandra"),
    },
    "go": {
        "lib/pq": ("sql", "postgres"), "jackc/pgx": ("sql", "postgres"),
        "go-sql-driver/mysql": ("sql", "mysql"), "mattn/go-sqlite3": ("sql", "sqlite"),
        "database/sql": ("sql", "sql"), "gorm.io": ("sql", "sql"),
        "mongo-driver": ("nosql", "mongo"), "go-redis": ("cache", "redis"),
        "gomodule/redigo": ("cache", "redis"), "aws/aws-sdk-go": ("object-storage", "aws"),
        "elastic/go-elasticsearch": ("nosql", "elasticsearch"),
    },
    "java": {
        "java.sql": ("sql", "sql"), "javax.sql": ("sql", "sql"),
        "org.postgresql": ("sql", "postgres"), "com.mysql": ("sql", "mysql"),
        "org.sqlite": ("sql", "sqlite"),
        "javax.persistence": ("sql", "sql"), "jakarta.persistence": ("sql", "sql"),
        "org.hibernate": ("sql", "sql"), "org.springframework.jdbc": ("sql", "sql"),
        "com.mongodb": ("nosql", "mongo"), "org.mongodb": ("nosql", "mongo"),
        "redis.clients": ("cache", "redis"), "io.lettuce": ("cache", "redis"),
        "com.amazonaws": ("object-storage", "aws"),
        "software.amazon.awssdk": ("object-storage", "aws"),
        "org.elasticsearch": ("nosql", "elasticsearch"),
    },
}
_STORES["typescript"] = _STORES["javascript"]

_QUEUES = {
    "javascript": {"kafkajs": "kafka", "amqplib": "rabbitmq", "bull": "redis-queue",
                   "bullmq": "redis-queue", "nats": "nats"},
    "go": {"segmentio/kafka-go": "kafka", "Shopify/sarama": "kafka", "IBM/sarama": "kafka",
           "rabbitmq/amqp091-go": "rabbitmq", "streadway/amqp": "rabbitmq",
           "nats-io": "nats"},
    "java": {"org.apache.kafka": "kafka", "com.rabbitmq": "rabbitmq",
             "org.springframework.kafka": "kafka", "org.springframework.amqp": "rabbitmq",
             "io.nats": "nats"},
}
_QUEUES["typescript"] = _QUEUES["javascript"]

_FRAMEWORKS = {
    "javascript": {"express": "express", "koa": "koa", "fastify": "fastify",
                   "@nestjs/common": "nestjs", "@nestjs/core": "nestjs",
                   "@hapi/hapi": "hapi", "next": "nextjs",
                   "@modelcontextprotocol/sdk": "mcp", "langchain": "langchain",
                   "@langchain/core": "langchain", "@langchain/langgraph": "langgraph",
                   "openai": "openai", "@anthropic-ai/sdk": "anthropic",
                   "crewai": "crewai", "ai": "vercel-ai"},
    "go": {"gin-gonic/gin": "gin", "labstack/echo": "echo", "go-chi/chi": "chi",
           "gorilla/mux": "gorilla", "gofiber/fiber": "fiber", "net/http": "net/http",
           "tmc/langchaingo": "langchain", "sashabaranov/go-openai": "openai"},
    "java": {"org.springframework": "spring", "javax.ws.rs": "jax-rs",
             "jakarta.ws.rs": "jax-rs", "io.micronaut": "micronaut",
             "dev.langchain4j": "langchain4j", "com.theokanning.openai": "openai"},
}
_FRAMEWORKS["typescript"] = _FRAMEWORKS["javascript"]

# Agent/LLM SDK import tokens matched here are also recognised by the
# Python-side extractor.signatures tables (same canonical names) so the
# cross-language trust-boundary inference in extractor.py works uniformly.

_SECRET_HINT = (r"(?:password|passwd|secret|token|api_?key|access_?key|private_?key"
                r"|credential|client_?secret|auth_?token|session_?key)")
_SECRET_ASSIGN = {
    "javascript": re.compile(
        r"\b(?:const|let|var)\s+(\w*" + _SECRET_HINT + r"\w*)\s*=\s*", re.I),
    "go": re.compile(r"\b(\w*" + _SECRET_HINT + r"\w*)\s*:?=\s*", re.I),
    "java": re.compile(
        r"\b(?:String|char\[\]|final|static|private|public|protected|\s)+"
        r"(\w*" + _SECRET_HINT + r"\w*)\s*=\s*", re.I),
}
_SECRET_ASSIGN["typescript"] = _SECRET_ASSIGN["javascript"]

_ENV_READER = {
    "javascript": re.compile(r"process\.env|import\.meta\.env"),
    "go": re.compile(r"os\.Getenv|os\.LookupEnv|viper\.Get"),
    "java": re.compile(r"System\.getenv|System\.getProperty|@Value\s*\("),
}
_ENV_READER["typescript"] = _ENV_READER["javascript"]

_PLACEHOLDERS = {"", "changeme", "your-secret", "xxx", "todo", "placeholder", "..."}


# ── imports / stores / frameworks ─────────────────────────────────────────────
_JS_IMPORT = re.compile(r"\b(?:require\s*\(|import\s*\(|from\s*)\s*$")


def _imports_of(m: Masked, lang: str) -> list:
    """Imported module strings/idents with the line each first appears on."""
    found: list = []
    if lang in ("javascript", "typescript"):
        rx = re.compile(r"\b(?:require\s*\(|import\s*\(|\bfrom\s+)")
        for match in rx.finditer(m.text):
            val = m.string_in(match.end(), match.end() + 80)
            if val:
                found.append((val, m.line_of(match.start())))
    elif lang == "go":
        for match in re.finditer(r"\bimport\b", m.text):
            paren = m.text.find("(", match.end())
            semi_line_end = m.text.find("\n", match.end())
            if paren >= 0 and (semi_line_end < 0 or paren < semi_line_end):
                close = _match_bracket(m.text, paren)
                close = close if close > 0 else paren + 1
                for s, _e, val in m.strings:
                    if paren < s < close:
                        found.append((val, m.line_of(s)))
            else:
                val = m.string_in(match.end(), semi_line_end if semi_line_end > 0 else len(m.text))
                if val:
                    found.append((val, m.line_of(match.start())))
    elif lang == "java":
        for match in re.finditer(r"^\s*import\s+(?:static\s+)?([\w.]+)", m.text, re.M):
            found.append((match.group(1), m.line_of(match.start())))
    return found


def _note_imports(m: Masked, lang: str, facts: FileFacts):
    stores, queues, fws = _STORES[lang], _QUEUES[lang], _FRAMEWORKS[lang]
    for mod, line in _imports_of(m, lang):
        probe = mod.lower()
        for token, (kind, engine) in stores.items():
            if token in probe:
                facts.data_stores.append(DataStore(kind, engine, facts.rel_path, line))
                break
        for token, broker_name in queues.items():
            if token.lower() in probe:
                facts.external_calls.append(
                    ExternalCall("queue", broker_name, facts.rel_path, line))
                break
        for token, fw in fws.items():
            t = token.lower()
            # Go import paths embed the framework mid-path (github.com/gin-gonic/gin)
            if probe == t or probe.startswith(t + "/") or probe.startswith(t + ".") \
                    or ("/" in t and t in probe):
                facts.frameworks.add(fw)
                break


# ── routes ────────────────────────────────────────────────────────────────────
_JS_ROUTE = re.compile(
    r"\b([A-Za-z_$][\w$]*)\.(get|post|put|patch|delete|all|use)\s*\(")
_GO_ROUTE = re.compile(
    r"\b(?:http\.(HandleFunc|Handle)|([A-Za-z_]\w*)\."
    r"(GET|POST|PUT|PATCH|DELETE|Any|Get|Post|Put|Patch|Delete|HandleFunc|Handle))\s*\(")
_GO_METHODS_CHAIN = re.compile(r"\.\s*Methods\s*\(")
_GO_USE = re.compile(r"\b[A-Za-z_]\w*\.Use\s*\(")

_IDENT = re.compile(r"\b([A-Za-z_$][\w$]*)\b")


def _call_args_span(m: Masked, open_paren: int) -> tuple:
    close = _match_bracket(m.text, open_paren)
    if close < 0:
        close = min(len(m.text), open_paren + 2000)
    return open_paren + 1, close


def _handler_of(m: Masked, spans: list, facts: FileFacts, args_text: str,
                a: int, b: int, path: str):
    """Resolve the handler for a route call: a trailing identifier reference, or
    a synthetic span for an inline closure."""
    handler_kw = re.search(r"=>|\bfunction\b|\bfunc\b", args_text)
    if handler_kw:
        line = m.line_of(a)
        name = f"<route:{path}:{line}>"
        fn = FunctionInfo(name, line)
        # Search for the handler's own opening brace AFTER the =>/function/func keyword,
        # not from the start of the whole argument list — a leading non-function argument
        # (e.g. a schema/options object literal before the handler) has its own '{' that
        # would otherwise be matched first, truncating the handler body to that object.
        brace = m.text.find("{", a + handler_kw.end())
        end = _match_bracket(m.text, brace) if 0 <= brace < b else -1
        spans.append(_Span(name, set(), a, a, end if end > 0 else b, fn))
        facts.functions[name] = fn
        return fn
    idents = [i for i in _IDENT.findall(args_text) if i not in _KEYWORDS]
    if idents:
        # last bare identifier is conventionally the handler; strip receivers
        return idents[-1].split(".")[-1]
    return ""


def _js_routes(m: Masked, facts: FileFacts, spans: list):
    fw = next((f for f in ("express", "koa", "fastify", "hapi")
               if f in facts.frameworks), "")
    for match in _JS_ROUTE.finditer(m.text):
        recv, verb = match.group(1), match.group(2)
        if recv in _JS_CLIENT_ROOTS:
            continue
        a, b = _call_args_span(m, m.text.find("(", match.end() - 1))
        args_text = m.text[a:b]
        first_str = m.string_in(a - 1, b)
        if verb == "use":
            lowered = args_text.lower()
            if _AUTH_MARKER.search(args_text):
                facts.global_controls.append(
                    Control("auth", "middleware (use)", "global", facts.rel_path,
                            m.line_of(match.start())))
            for token, kind in (("helmet", "headers"), ("cors", "headers"),
                                ("csurf", "csrf"), ("csrf", "csrf"),
                                ("ratelimit", "rate-limit"), ("rate_limit", "rate-limit"),
                                ("limiter", "rate-limit")):
                if token in lowered:
                    facts.global_controls.append(
                        Control(kind, token, "global", facts.rel_path,
                                m.line_of(match.start())))
            continue
        if not first_str.startswith("/"):
            continue
        if not (fw or recv in ("app", "router", "routes", "server", "api")):
            continue
        fn = _route_fn(m, facts, spans, args_text, a, b, first_str, match.start())
        _mark_route(fn, verb.upper() if verb != "all" else "*", first_str,
                    fw or "express", m, match.start(), args_text)


def _js_agent_tools(m: Masked, facts: FileFacts, spans: list):
    ai_hint = bool(facts.frameworks & _AI_FRAMEWORK_HINT)
    for match in _JS_AGENT_TOOL.finditer(m.text):
        recv = match.group(1)
        if recv in _JS_CLIENT_ROOTS:
            continue
        if not (ai_hint or recv.lower() in _JS_TOOL_RECEIVERS):
            continue
        a, b = _call_args_span(m, m.text.find("(", match.end() - 1))
        args_text = m.text[a:b]
        first_str = m.string_in(a - 1, b)
        fn = _route_fn(m, facts, spans, args_text, a, b,
                       first_str or f"tool:{m.line_of(match.start())}", match.start())
        fn.is_agent_tool = True
        fn.tool_name = first_str or fn.name


def _go_routes(m: Masked, facts: FileFacts, spans: list):
    fw = next((f for f in ("gin", "echo", "chi", "gorilla", "fiber")
               if f in facts.frameworks), "net/http")
    for match in _GO_ROUTE.finditer(m.text):
        verb = (match.group(1) or match.group(3) or "").upper()
        a, b = _call_args_span(m, m.text.find("(", match.end() - 1))
        args_text = m.text[a:b]
        first_str = m.string_in(a - 1, b)
        if not first_str.startswith("/"):
            continue
        method = verb if verb in ("GET", "POST", "PUT", "PATCH", "DELETE") else "*"
        chain = m.text[b:b + 40]
        mm = _GO_METHODS_CHAIN.match(chain) or _GO_METHODS_CHAIN.search(chain[:20])
        if mm:
            ca, cb = _call_args_span(m, m.text.find("(", b + mm.start()))
            mstr = m.string_in(ca - 1, cb)
            if mstr:
                method = mstr.upper()
        fn = _route_fn(m, facts, spans, args_text, a, b, first_str, match.start())
        _mark_route(fn, method, first_str, fw, m, match.start(), args_text)
    for match in _GO_USE.finditer(m.text):
        a, b = _call_args_span(m, m.text.find("(", match.end() - 1))
        if _AUTH_MARKER.search(m.text[a:b]):
            facts.global_controls.append(
                Control("auth", "router middleware", "global", facts.rel_path,
                        m.line_of(match.start())))


def _span_fn(spans: list, name: str):
    for s in spans:
        if s.name == name:
            return s.fn
    return None


def _route_fn(m: Masked, facts: FileFacts, spans: list, args_text: str,
              a: int, b: int, path: str, at: int) -> FunctionInfo:
    """The FunctionInfo a route registration binds to.

    Inline closure -> synthetic span carrying the body's sinks directly.
    Locally-defined named handler -> that function.
    Foreign named handler -> a uniquely-named stub whose ``calls`` edge lets the
    cross-file join reach the real definition (a same-named stub would shadow it
    in the global function map).
    """
    handler = _handler_of(m, spans, facts, args_text, a, b, path)
    if isinstance(handler, FunctionInfo):
        return handler
    local = facts.functions.get(handler) or _span_fn(spans, handler)
    if local is not None:
        return local
    stub = FunctionInfo(f"<route:{path}:{m.line_of(at)}>", m.line_of(at))
    if handler:
        stub.calls.add(handler)
    facts.functions[stub.name] = stub
    return stub


def _mark_route(fn: FunctionInfo, method: str, path: str, framework: str,
                m: Masked, at: int, args_text: str):
    fn.is_route = True
    fn.route_method = method or "*"
    fn.route_path = path
    fn.framework = framework
    if _AUTH_MARKER.search(args_text):
        fn.controls.append(Control("auth", "route middleware", "entrypoint",
                                   line=m.line_of(at)))


# ── annotation routes (Java Spring / JAX-RS, NestJS) ──────────────────────────
_CLASS_RX = re.compile(r"\bclass\s+([A-Za-z_]\w*)")
_ANN_SPRING = re.compile(
    r"@(Get|Post|Put|Patch|Delete|Request)Mapping\b|@(GET|POST|PUT|PATCH|DELETE)\b")
_ANN_NEST = re.compile(r"@(Get|Post|Put|Patch|Delete|All|Head|Options)\s*\(")
_ANN_AUTH = re.compile(
    r"@(PreAuthorize|Secured|RolesAllowed|DenyAll|UseGuards|Authorized|PermitAll)\b")
_ANN_CLASS_PREFIX = re.compile(r"@(?:RequestMapping|Controller|Path)\s*\(")


def _class_spans(m: Masked) -> list:
    out = []
    for match in _CLASS_RX.finditer(m.text):
        brace = m.text.find("{", match.end())
        if brace < 0:
            continue
        end = _match_bracket(m.text, brace)
        if end > 0:
            out.append((match.start(), brace, end))
    return out


def _annotation_routes(m: Masked, facts: FileFacts, spans: list, lang: str):
    """Spring `@GetMapping`, JAX-RS `@GET`+`@Path`, Nest `@Get` — annotation
    binds to the next function span; class-level prefix/guards apply within
    the class body."""
    ann_rx = _ANN_NEST if lang in ("javascript", "typescript") else _ANN_SPRING
    fw = ("nestjs" if lang in ("javascript", "typescript")
          else ("spring" if "spring" in facts.frameworks else
                ("jax-rs" if "jax-rs" in facts.frameworks else "spring")))
    classes = _class_spans(m)

    def class_ctx(offset):
        prefix, guarded = "", False
        for cstart, cbrace, cend in classes:
            if cbrace <= offset <= cend:
                # look back a few hundred chars before the class for annotations
                back = max(0, cstart - 400)
                seg = m.text[back:cstart]
                pm = _ANN_CLASS_PREFIX.search(seg)
                if pm:
                    pa = back + pm.end() - 1
                    _a, pb = _call_args_span(m, pa)
                    prefix = m.string_in(pa, pb) or ""
                if _ANN_AUTH.search(seg):
                    guarded = True
        return prefix, guarded

    for match in ann_rx.finditer(m.text):
        target = _next_span_after(spans, match.end())
        if target is None or target.header - match.end() > 500:
            continue
        # a `class` keyword between annotation and next function span means this
        # is a class-level annotation (prefix/guard), handled by class_ctx below
        if re.search(r"\bclass\b", m.text[match.end():target.header]):
            continue
        verb = (match.group(1) or match.group(2) or "").upper()
        verb = {"REQUEST": "*", "ALL": "*"}.get(verb, verb or "*")
        path = ""
        paren = m.text.find("(", match.end() - 1)
        # only a paren immediately after the annotation carries its path —
        # a later one is the method's own parameter list
        if 0 <= paren < target.header and paren - match.end() <= 3:
            _a, pb = _call_args_span(m, paren)
            path = m.string_in(paren, pb)
        prefix, class_guarded = class_ctx(target.header)
        full = (prefix.rstrip("/") + "/" + path.lstrip("/")).rstrip("/") or "/"
        if not full.startswith("/"):
            full = "/" + full
        fn = target.fn
        fn.is_route = True
        fn.route_method = verb
        fn.route_path = full
        fn.framework = fw
        # auth annotations sit between the previous member's body and this
        # method's header — never look back past the previous span's close,
        # or a guard on the sibling above would leak onto this route
        prev_end = max((s.body_end for s in spans
                        if s.body_end < match.start()), default=0)
        seg = m.text[max(prev_end, match.start() - 300):target.header]
        if class_guarded or _ANN_AUTH.search(seg):
            fn.controls.append(Control("auth", "guard annotation", "entrypoint",
                                       line=fn.lineno))
        if fw == "nestjs":
            facts.frameworks.add("nestjs")

    # method-security annotations on non-route methods still count as controls
    if lang == "java" and re.search(r"@EnableWebSecurity\b|SecurityFilterChain\b", m.text):
        facts.global_controls.append(
            Control("auth", "spring-security", "global", facts.rel_path, 1))


# ── sinks / calls / secrets ───────────────────────────────────────────────────
def _collect_sinks(m: Masked, facts: FileFacts, spans: list, lang: str):
    taint_rx = _TAINT[lang]

    def module_fn():
        return facts.functions.setdefault("<module>", FunctionInfo("<module>", 1))

    def owner_of(offset):
        span = _innermost(spans, offset)
        return span.fn if span else module_fn()

    def arg_ctx(match):
        paren = m.text.find("(", match.end() - 1)
        if paren < 0 or paren - match.end() > 3:
            paren = match.end() - 1 if m.text[match.end() - 1:match.end()] == "(" else -1
        if paren < 0:
            return "", match.start(), match.end()
        a, b = _call_args_span(m, paren)
        return m.text[a:b], a, b

    def is_tainted(args_text, owner):
        if taint_rx.search(args_text):
            return True
        words = set(_IDENT.findall(args_text))
        return bool(owner.params & words)

    for rx, kind, family, cwe, requires in _SINKS[lang]:
        if requires and requires not in m.source:
            continue
        for match in rx.finditer(m.text):
            owner = owner_of(match.start())
            args_text, a, b = arg_ctx(match)
            tainted = is_tainted(args_text, owner)
            if kind in _TAINT_GATED and not tainted:
                continue
            name = m.source[match.start():match.end()].split("(")[0].strip() \
                or m.text[match.start():match.end()]
            owner.sinks.append(Sink(
                kind=kind, family=family, cwe=cwe, name=name,
                file=facts.rel_path, line=m.line_of(match.start()),
                tainted=tainted, confidence=MEDIUM if tainted else LOW))

    # http clients: SSRF when tainted, otherwise an outbound call
    for match in _HTTP_CLIENT[lang].finditer(m.text):
        owner = owner_of(match.start())
        args_text, a, b = arg_ctx(match)
        if is_tainted(args_text, owner):
            owner.sinks.append(Sink(
                kind="ssrf", family="ssrf", cwe="CWE-918",
                name=m.text[match.start():match.end()].split("(")[0].strip() or "http-client",
                file=facts.rel_path, line=m.line_of(match.start()),
                tainted=True, confidence=MEDIUM))
        else:
            cleartext = any(v.startswith("http://")
                            for v in m.strings_in(a, b))
            facts.external_calls.append(ExternalCall(
                "http", "http-client", facts.rel_path, m.line_of(match.start()),
                encrypted=not cleartext))

    # direct LLM invocation — trust-boundary crossing to a model provider
    if lang in ("javascript", "typescript"):
        for match in _LLM_CALL_CHAIN.finditer(m.text):
            facts.external_calls.append(ExternalCall(
                "llm", "llm-provider", facts.rel_path, m.line_of(match.start())))

    # validation evidence inside handler bodies
    for match in _VALIDATION_MARKER.finditer(m.text):
        span = _innermost(spans, match.start())
        if span:
            span.fn.controls.append(Control(
                "validation", "validation call", "entrypoint",
                line=m.line_of(match.start())))


def _collect_calls(m: Masked, spans: list):
    for s in spans:
        body = m.text[s.body_start:s.body_end]
        count = 0
        for cm in re.finditer(r"\b([A-Za-z_]\w*)\s*\(", body):
            name = cm.group(1)
            if name in _KEYWORDS or name == s.name:
                continue
            s.fn.calls.add(name)
            count += 1
            if count >= _MAX_CALLS_PER_FN:
                break


def _collect_secrets(m: Masked, facts: FileFacts, lang: str):
    env_rx = _ENV_READER[lang]
    for match in _SECRET_ASSIGN[lang].finditer(m.text):
        name = match.group(1)
        line_end = m.text.find("\n", match.end())
        line_end = len(m.text) if line_end < 0 else line_end
        rhs_code = m.text[match.end():line_end]
        # the trailing \s* of the assign regex swallows the blanked-out literal,
        # so search for the recorded string from the match start, not its end
        value = m.string_in(match.start(), line_end)
        managed = bool(env_rx.search(rhs_code)) or bool(env_rx.search(
            m.source[match.end():line_end]))
        if managed:
            facts.secrets.append(Secret(name, facts.rel_path,
                                        m.line_of(match.start()), managed=True))
        elif value and value.strip().lower() not in _PLACEHOLDERS \
                and not value.startswith("${"):
            facts.secrets.append(Secret(name, facts.rel_path,
                                        m.line_of(match.start()), managed=False))


# ── public entry ──────────────────────────────────────────────────────────────
def analyze_source(source: str, rel_path: str, lang: str) -> FileFacts:
    """Extract design facts from one JS/TS/Go/Java source file."""
    facts = FileFacts(rel_path)
    m = Masked(source, lang)
    spans = _find_spans(m, lang)
    for s in spans:
        facts.functions.setdefault(s.name, s.fn)
    _note_imports(m, lang, facts)
    if lang in ("javascript", "typescript"):
        _js_routes(m, facts, spans)
        _js_agent_tools(m, facts, spans)
        if "@nestjs" in source or "nestjs" in facts.frameworks:
            _annotation_routes(m, facts, spans, lang)
    elif lang == "go":
        _go_routes(m, facts, spans)
    elif lang == "java":
        _annotation_routes(m, facts, spans, lang)
    _collect_sinks(m, facts, spans, lang)
    _collect_calls(m, spans)
    _collect_secrets(m, facts, lang)
    return facts
