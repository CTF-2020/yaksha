"""Correlation (mediator) engine for Yaksha Guard.

Sits between the threat-model tool and the code/runtime scanners and reconciles
their findings: it normalizes static (SAST), dynamic (DAST) and design
(threat-model) findings to one weakness taxonomy, clusters the ones that describe
the same flaw, and adjudicates each cluster into an actionable verdict —
confirmed-exploitable, corroborated, design-gap or blind-spot.

Public surface:
  * ``engine.correlate(reports) -> list[CorrelatedFinding]`` — the pure core.
  * ``service.run(report_ids) -> report_dict`` — load/correlate/shape.
  * ``service.list_correlatable() -> list[dict]`` — pickable source reports.
"""
from __future__ import annotations

from . import engine, mapper, service, taxonomy  # noqa: F401
from .model import CorrelatedFinding, Observation, SourceKind, Verdict  # noqa: F401

__all__ = [
    "engine", "mapper", "service", "taxonomy",
    "CorrelatedFinding", "Observation", "SourceKind", "Verdict",
]
