"""owasp_cloud.py -- OWASP Cloud-Native Application Security Top 10 definitions."""
from __future__ import annotations

OWASP_CLOUD_TOP10: dict[str, dict] = {
    "C01": {
        "id": "C01",
        "name": "Insecure Cloud, Container, or Orchestration Configuration",
        "description": (
            "Misconfigured cloud services, containers, or orchestration platforms (e.g. Kubernetes) "
            "expose resources to unauthorized access, data leakage, or takeover."
        ),
        "common_examples": [
            "Publicly accessible S3 buckets or Azure Blob Storage containers",
            "Kubernetes API server exposed without authentication",
            "Default security groups allowing unrestricted inbound traffic",
            "Container images running as root with unnecessary capabilities",
        ],
        "mitigations": [
            "Apply IaC security scanning (tfsec, Checkov) on every PR",
            "Enable cloud-provider security posture management (AWS Security Hub, Azure Defender)",
            "Enforce least-privilege security groups and network policies",
            "Use read-only root filesystems and drop all Linux capabilities in containers",
        ],
    },
    "C02": {
        "id": "C02",
        "name": "Injection Flaws (Host OS, Container, Serverless)",
        "description": (
            "Untrusted data passed to cloud functions, containers, or host OS commands "
            "enabling command injection, SSRF, or environment variable manipulation."
        ),
        "common_examples": [
            "Lambda functions passing user input directly to shell commands",
            "SSRF through cloud metadata endpoint (169.254.169.254)",
            "Container escape via privileged mode + writable host paths",
            "Environment variable injection in serverless runtimes",
        ],
        "mitigations": [
            "Disable IMDSv1; enforce IMDSv2 with hop-limit=1 on all EC2/ECS",
            "Block metadata endpoint access at network policy level",
            "Never pass user input to exec/shell calls in serverless functions",
            "Audit container runtime profiles with Falco or AppArmor",
        ],
    },
    "C03": {
        "id": "C03",
        "name": "Improper Authentication & Authorization",
        "description": (
            "Weak or missing authentication on cloud APIs, management consoles, or "
            "inter-service calls enabling privilege escalation or account takeover."
        ),
        "common_examples": [
            "Service accounts with wildcard (*) permissions",
            "Management console accessible without MFA",
            "Workload identity not used — long-lived static API keys instead",
            "Cross-account role trust policies that are too permissive",
        ],
        "mitigations": [
            "Enforce MFA on all human IAM accounts; block console login without MFA via SCP",
            "Use workload identity / IRSA instead of static access keys",
            "Audit and rotate all static credentials; use Secrets Manager",
            "Restrict AssumeRole to specific principal ARNs and add condition keys",
        ],
    },
    "C04": {
        "id": "C04",
        "name": "CI/CD Pipeline & Software Supply Chain Flaws",
        "description": (
            "Compromised CI/CD pipelines, unverified dependencies, or insecure build "
            "environments enabling supply chain attacks or backdoor injection."
        ),
        "common_examples": [
            "CI runner with excessive cloud IAM permissions used for build jobs",
            "Third-party GitHub Actions pinned to mutable branch tags",
            "Base images pulled from Docker Hub without digest pinning",
            "Secrets stored as plaintext CI environment variables",
        ],
        "mitigations": [
            "Pin all external Actions to full commit SHA; audit with Dependabot",
            "Grant CI runners minimum IAM permissions using OIDC federation (no static keys)",
            "Sign and verify container images with Cosign/Notary",
            "Store secrets in a vault; inject at runtime, never in env vars",
        ],
    },
    "C05": {
        "id": "C05",
        "name": "Insecure Secret Management",
        "description": (
            "Secrets (API keys, DB credentials, certificates) embedded in code, "
            "container images, or passed as plaintext environment variables."
        ),
        "common_examples": [
            "AWS credentials committed to Git history",
            "Database passwords in Kubernetes ConfigMaps (not Secrets)",
            "Secrets baked into container layers accessible via docker history",
            "Unencrypted parameter store values readable by any role",
        ],
        "mitigations": [
            "Use AWS Secrets Manager / HashiCorp Vault with automatic rotation",
            "Scan all commits with git-secrets or truffleHog in pre-commit hooks",
            "Enable envelope encryption for Kubernetes Secrets using KMS",
            "Grant secret read permissions only to specific task roles, not all workloads",
        ],
    },
    "C06": {
        "id": "C06",
        "name": "Over-Permissioned Resources or Inadequate Permission Management",
        "description": (
            "Cloud IAM roles, service principals, or resource policies granting broader "
            "permissions than required, violating least-privilege."
        ),
        "common_examples": [
            "Lambda execution role with AdministratorAccess",
            "EC2 instance profile allowing s3:* on all buckets",
            "Kubernetes RBAC ClusterRoleBinding granting cluster-admin to service accounts",
            "Resource-based policies with Principal: '*'",
        ],
        "mitigations": [
            "Run IAM Access Analyzer to detect over-permissioned policies",
            "Use permission boundaries on all IAM roles created by automation",
            "Right-size permissions using AWS IAM Access Advisor (last-accessed data)",
            "Enforce SCPs banning AdministratorAccess outside break-glass accounts",
        ],
    },
    "C07": {
        "id": "C07",
        "name": "Inadequate Computing Resource Quota Limits",
        "description": (
            "Absence of resource quotas and rate limits enabling cryptomining abuse, "
            "denial-of-wallet attacks, or runaway workloads."
        ),
        "common_examples": [
            "No Lambda concurrency limits enabling runaway cost from a single bug",
            "Kubernetes namespaces without ResourceQuota or LimitRange",
            "API Gateway missing usage plans allowing unlimited invocations",
            "Auto-scaling without cost anomaly alerts",
        ],
        "mitigations": [
            "Set reserved concurrency and maximum scaling limits on all Lambda functions",
            "Apply Kubernetes ResourceQuota and LimitRange to every namespace",
            "Enable AWS Cost Anomaly Detection with SNS alerts",
            "Apply API Gateway usage plans and throttling to all stages",
        ],
    },
    "C08": {
        "id": "C08",
        "name": "Data Exposure & Inadequate Data Security",
        "description": (
            "Sensitive data stored or transmitted without encryption, improper data "
            "classification, or excessive data retention in cloud storage."
        ),
        "common_examples": [
            "S3 buckets with server-side encryption disabled",
            "RDS snapshots shared publicly or copied to unencrypted storage",
            "CloudFront serving sensitive content without signed URLs",
            "Logs containing PII or credentials retained indefinitely",
        ],
        "mitigations": [
            "Enable default SSE-KMS encryption on all S3 buckets and RDS instances",
            "Use S3 Macie to discover and classify sensitive data",
            "Apply lifecycle policies to automatically expire log data per retention policy",
            "Block all public S3 access at the account level via S3 Block Public Access",
        ],
    },
    "C09": {
        "id": "C09",
        "name": "Inadequate Security Observability Capabilities",
        "description": (
            "Insufficient logging, monitoring, or alerting preventing detection of "
            "attacks, misconfigurations, or data breaches in cloud environments."
        ),
        "common_examples": [
            "CloudTrail disabled or logging to an unprotected bucket",
            "No GuardDuty / Defender for Cloud threat detection enabled",
            "VPC Flow Logs disabled for critical subnets",
            "No alerting on IAM policy changes or root account usage",
        ],
        "mitigations": [
            "Enable CloudTrail with log file validation in all regions; protect bucket with MFA delete",
            "Enable GuardDuty, Security Hub, and Config in all accounts and regions",
            "Enable VPC Flow Logs and export to centralized SIEM",
            "Alert on CloudWatch metrics for root login, MFA disable, and policy changes",
        ],
    },
    "C10": {
        "id": "C10",
        "name": "Inadequate Incident Response Capability",
        "description": (
            "No cloud-specific incident response playbooks, forensic readiness, "
            "or breach containment procedures for cloud environments."
        ),
        "common_examples": [
            "No runbook for compromised IAM credential containment",
            "CloudTrail logs unavailable at time of incident (deleted or inaccessible)",
            "No VPC isolation capability to quarantine compromised workloads",
            "No tested backup/restore procedure for critical data stores",
        ],
        "mitigations": [
            "Maintain and test cloud IR playbooks covering credential compromise, data breach, cryptomining",
            "Pre-create quarantine security groups to isolate compromised instances immediately",
            "Use AWS Systems Manager for forensic evidence collection without SSH access",
            "Test backup restore quarterly; verify RTO/RPO for all Tier-1 services",
        ],
    },
}
