"""Tests for the user credential store (users_db.py).

Isolates onto a temp DB, styled like test_report_db.py's TestReportDbModule.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import users_db


class TestUsersDb(unittest.TestCase):
    def setUp(self):
        self._orig_path = users_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        users_db.DB_PATH = Path(self._td.name) / "auth.db"
        users_db.init()

    def _restore(self):
        users_db.DB_PATH = self._orig_path

    def test_create_and_verify(self):
        users_db.create_user("Admin@Example.com", "correcthorsebattery")
        self.assertIsNotNone(users_db.verify_user("admin@example.com", "correcthorsebattery"))
        self.assertIsNone(users_db.verify_user("admin@example.com", "wrongpassword"))
        self.assertIsNone(users_db.verify_user("nobody@example.com", "anything123"))

    def test_email_case_insensitive_unique(self):
        users_db.create_user("admin@example.com", "correcthorsebattery")
        with self.assertRaises(ValueError):
            users_db.create_user("ADMIN@example.com", "anotherpassword1")

    def test_rejects_short_password(self):
        with self.assertRaises(ValueError):
            users_db.create_user("a@b.com", "short")

    def test_rejects_bad_email(self):
        with self.assertRaises(ValueError):
            users_db.create_user("not-an-email", "correcthorsebattery")

    def test_password_never_returned(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        for u in users_db.list_users():
            self.assertNotIn("password_hash", u)
        u = users_db.get_user("a@b.com")
        self.assertNotIn("password_hash", u)

    def test_last_login_at_updates_on_verify(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        before = users_db.get_user("a@b.com")["last_login_at"]
        self.assertIsNone(before)
        users_db.verify_user("a@b.com", "correcthorsebattery")
        after = users_db.get_user("a@b.com")["last_login_at"]
        self.assertIsNotNone(after)

    def test_delete_user(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        self.assertTrue(users_db.delete_user("a@b.com"))
        self.assertFalse(users_db.delete_user("a@b.com"))
        self.assertEqual(users_db.user_count(), 0)

    def test_password_stored_hashed_not_plaintext(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        import sqlite3
        from contextlib import closing
        with closing(sqlite3.connect(str(users_db.DB_PATH))) as conn:
            row = conn.execute("SELECT password_hash FROM users").fetchone()
        self.assertNotIn("correcthorsebattery", row[0])

    def test_default_role_is_user(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        self.assertEqual(users_db.get_user("a@b.com")["role"], "user")
        self.assertFalse(users_db.is_admin("a@b.com"))

    def test_create_user_with_admin_role(self):
        users_db.create_user("a@b.com", "correcthorsebattery", role="admin")
        self.assertTrue(users_db.is_admin("a@b.com"))
        self.assertEqual(users_db.admin_count(), 1)

    def test_create_user_rejects_unknown_role(self):
        with self.assertRaises(ValueError):
            users_db.create_user("a@b.com", "correcthorsebattery", role="superuser")

    def test_set_role_promotes_and_demotes(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        self.assertTrue(users_db.set_role("a@b.com", "admin"))
        self.assertTrue(users_db.is_admin("a@b.com"))
        self.assertTrue(users_db.set_role("a@b.com", "user"))
        self.assertFalse(users_db.is_admin("a@b.com"))

    def test_set_role_unknown_user_returns_false(self):
        self.assertFalse(users_db.set_role("nobody@example.com", "admin"))

    def test_set_role_rejects_unknown_role(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        with self.assertRaises(ValueError):
            users_db.set_role("a@b.com", "superuser")

    def test_set_password_changes_credentials(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        self.assertTrue(users_db.set_password("a@b.com", "newpassword123"))
        self.assertIsNone(users_db.verify_user("a@b.com", "correcthorsebattery"))
        self.assertIsNotNone(users_db.verify_user("a@b.com", "newpassword123"))

    def test_set_password_rejects_short_password(self):
        users_db.create_user("a@b.com", "correcthorsebattery")
        with self.assertRaises(ValueError):
            users_db.set_password("a@b.com", "short")

    def test_set_password_unknown_user_returns_false(self):
        self.assertFalse(users_db.set_password("nobody@example.com", "correcthorsebattery"))

    def test_role_survives_a_schema_without_the_column(self):
        """A DB created before the role column existed must migrate in place,
        not lose its rows or crash, the first time init() runs against it."""
        import sqlite3
        from contextlib import closing
        with closing(sqlite3.connect(str(users_db.DB_PATH))) as conn, conn:
            conn.execute("DROP TABLE IF EXISTS users")
            conn.execute("""CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                created_at REAL,
                last_login_at REAL
            )""")
            conn.execute(
                "INSERT INTO users(email,password_hash,created_at) VALUES (?,?,?)",
                ("legacy@example.com", "hash", 0))
        users_db.init()
        user = users_db.get_user("legacy@example.com")
        self.assertIsNotNone(user)
        self.assertEqual(user["role"], "user")


if __name__ == "__main__":
    unittest.main()
