"""Tests for architecture drift detection (arch_drift) + the drift API.

Unit tests drive precise declared/actual pairs; the integration test runs the
real codemodel extractor on a Flask fixture and diffs it against a minimal
diagram, so the code facts come from the actual engine.
"""
from __future__ import annotations

import io
import os
import tempfile
import unittest
from unittest import mock

import arch_drift
from codemodel import extractor, mapper, threats


DRAWIO = '''<mxGraphModel><root>
  <mxCell id="0"/>
  <mxCell id="1" value="User Browser" style="shape=actor" vertex="1"/>
  <mxCell id="2" value="API Service" style="rounded=1" vertex="1"/>
  <mxCell id="3" value="Auth Gateway" style="rounded=1" vertex="1"/>
  <mxCell id="e1" value="HTTPS" edge="1" source="1" target="2"/>
</root></mxGraphModel>'''


def _cm_report(meta_over):
    base = {"data_stores": [], "external_calls": [], "attack_surface": [],
            "code_controls": []}
    base.update(meta_over)
    return {"id": "cm", "methodology": "codemodel", "title": "CM",
            "scan_metadata": base}


class TestDeclaredParsing(unittest.TestCase):
    def test_drawio_nodes_and_kinds(self):
        d = arch_drift.declared_from_drawio(DRAWIO)
        labels = {n["label"] for n in d.nodes}
        self.assertEqual(labels, {"User Browser", "API Service", "Auth Gateway"})
        self.assertTrue(d.has_kind("security"))     # Auth Gateway
        self.assertTrue(d.has_kind("client"))       # User Browser

    def test_drawio_invalid_xml_raises(self):
        with self.assertRaises(ValueError):
            arch_drift.declared_from_drawio("<not-xml")

    def test_declared_from_report_uses_components(self):
        report = {"architecture_text": "Postgres database\nStripe payments",
                  "categories": [{"affected_components": ["users service"]}]}
        d = arch_drift.declared_from_report(report)
        self.assertIn("postgres", d.all_tokens)
        self.assertIn("stripe", d.all_tokens)
        self.assertIn("users", d.all_tokens)


class TestDiff(unittest.TestCase):
    def setUp(self):
        self.declared = arch_drift.declared_from_drawio(DRAWIO)

    def test_undeclared_datastore(self):
        cm = _cm_report({"data_stores": [
            {"kind": "sql", "engine": "postgres", "file": "db.py", "line": 3}]})
        kinds = {f.kind for f in arch_drift.diff(cm, self.declared)}
        self.assertIn("undeclared-datastore", kinds)

    def test_declared_datastore_is_not_drift(self):
        declared = arch_drift.declared_from_drawio(
            DRAWIO.replace("API Service", "Postgres Database"))
        cm = _cm_report({"data_stores": [
            {"kind": "sql", "engine": "postgres", "file": "db.py", "line": 3}]})
        kinds = {f.kind for f in arch_drift.diff(cm, declared)}
        self.assertNotIn("undeclared-datastore", kinds)

    def test_undeclared_named_external_but_not_generic(self):
        cm = _cm_report({"external_calls": [
            {"kind": "http", "target": "stripe", "file": "pay.py", "line": 9,
             "encrypted": True},
            {"kind": "http", "target": "requests", "file": "x.py", "line": 1,
             "encrypted": True}]})   # generic -> ignored
        findings = arch_drift.diff(cm, self.declared)
        ext = [f for f in findings if f.kind == "undeclared-external"]
        self.assertEqual(len(ext), 1)
        self.assertIn("stripe", ext[0].title)

    def test_cleartext_external_call(self):
        cm = _cm_report({"external_calls": [
            {"kind": "http", "target": "legacy-host", "file": "x.py", "line": 1,
             "encrypted": False}]})
        kinds = {f.kind for f in arch_drift.diff(cm, self.declared)}
        self.assertIn("cleartext-external", kinds)

    def test_undeclared_entrypoint(self):
        cm = _cm_report({"attack_surface": [
            {"method": "POST", "path": "/internal/purge", "handler": "purge",
             "file": "adm.py", "line": 2, "authenticated": False, "sinks": []}]})
        eps = [f for f in arch_drift.diff(cm, self.declared)
               if f.kind == "undeclared-entrypoint"]
        self.assertEqual(len(eps), 1)
        self.assertEqual(eps[0].severity, "Medium")   # unauth -> Medium

    def test_missing_security_control_when_unauth_entrypoints_exist(self):
        # Diagram declares an Auth Gateway, but code has an unauth entry point.
        cm = _cm_report({"attack_surface": [
            {"method": "GET", "path": "/api/service", "handler": "svc",
             "file": "a.py", "line": 1, "authenticated": False, "sinks": []}]})
        kinds = {f.kind for f in arch_drift.diff(cm, self.declared)}
        self.assertIn("missing-security-control", kinds)
        mc = next(f for f in arch_drift.diff(cm, self.declared)
                  if f.kind == "missing-security-control")
        self.assertEqual(mc.severity, "High")

    def test_no_drift_is_empty(self):
        # Everything the code shows is declared, all authed, encrypted.
        declared = arch_drift.declared_from_report(
            {"architecture_text": "postgres\nstripe\npurge endpoint"})
        cm = _cm_report({
            "data_stores": [{"kind": "sql", "engine": "postgres", "file": "d.py", "line": 1}],
            "external_calls": [{"kind": "http", "target": "stripe", "file": "p.py",
                                "line": 1, "encrypted": True}],
            "attack_surface": [{"method": "POST", "path": "/purge", "handler": "purge",
                                "file": "a.py", "line": 1, "authenticated": True,
                                "sinks": []}]})
        self.assertEqual(arch_drift.diff(cm, declared), [])


class TestToReport(unittest.TestCase):
    def test_report_shape(self):
        cm = _cm_report({"data_stores": [
            {"kind": "sql", "engine": "postgres", "file": "db.py", "line": 3}]})
        declared = arch_drift.declared_from_drawio(DRAWIO)
        report = arch_drift.to_report(arch_drift.diff(cm, declared),
                                      [{"id": "cm"}], {})
        self.assertEqual(report["methodology"], "archdrift")
        self.assertEqual(report["categories"][0]["_source"], "ARCHDRIFT")
        self.assertEqual(report["overall_risk"], "Medium")

    def test_category_id_is_stable_across_processes_not_builtin_hash(self):
        # Regression: the id used Python's builtin hash(), which is
        # randomized per-process (PYTHONHASHSEED) — the same finding got a
        # different id every run, breaking suppression fingerprints and
        # cross-scan diffing. Spawn a fresh interpreter (its own random hash
        # seed) and confirm the id it computes matches this process's.
        import subprocess
        import sys
        cm = _cm_report({"data_stores": [
            {"kind": "sql", "engine": "postgres", "file": "db.py", "line": 3}]})
        declared = arch_drift.declared_from_drawio(DRAWIO)
        report = arch_drift.to_report(arch_drift.diff(cm, declared), [{"id": "cm"}], {})
        this_process_id = report["categories"][0]["id"]

        script = (
            "import sys; sys.path.insert(0, %r)\n"
            "import arch_drift\n"
            "from test_arch_drift import _cm_report, DRAWIO\n"
            "cm = _cm_report({'data_stores': [\n"
            "    {'kind': 'sql', 'engine': 'postgres', 'file': 'db.py', 'line': 3}]})\n"
            "declared = arch_drift.declared_from_drawio(DRAWIO)\n"
            "report = arch_drift.to_report(arch_drift.diff(cm, declared), [{'id': 'cm'}], {})\n"
            "print(report['categories'][0]['id'])\n"
        ) % os.path.dirname(os.path.abspath(__file__))
        out = subprocess.run(
            [sys.executable, "-c", script],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            capture_output=True, text=True, timeout=30,
            env={**os.environ, "PYTHONHASHSEED": "random"},
        )
        self.assertEqual(out.returncode, 0, out.stderr)
        other_process_id = out.stdout.strip()
        self.assertEqual(this_process_id, other_process_id)


FLASK_APP = '''
import os, sqlite3, requests
from flask import Flask, request
app = Flask(__name__)

@app.route("/hook", methods=["POST"])
def hook():
    sqlite3.connect("a.db").execute("SELECT 1")
    requests.get("http://legacy.internal/report")
    return "ok"
'''


class TestEndToEnd(unittest.TestCase):
    def test_real_codemodel_vs_thin_diagram_finds_drift(self):
        d = tempfile.mkdtemp(prefix="drift_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(FLASK_APP)
        model = extractor.build_model(d)
        cm = mapper.build_report(model, threats.derive(model),
                                 {"id": "r", "name": "fixture"}, {})
        # Diagram shows only a browser + service, nothing about sqlite/legacy host.
        declared = arch_drift.declared_from_drawio(DRAWIO)
        findings = arch_drift.diff(cm, declared)
        kinds = {f.kind for f in findings}
        # sqlite store is undeclared; the /hook endpoint is undeclared+unauth.
        self.assertIn("undeclared-datastore", kinds)
        self.assertIn("undeclared-entrypoint", kinds)


class TestDriftApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        cls._saved = []
        d = tempfile.mkdtemp(prefix="drift_api_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(FLASK_APP)
        model = extractor.build_model(d)
        cm = mapper.build_report(model, threats.derive(model),
                                 {"id": "r", "name": "fixture"}, {})
        cls.cm_id = tm_app._save_report(cm, "drift api CM")
        cls._saved.append(cls.cm_id)

    @classmethod
    def tearDownClass(cls):
        for rid in cls._saved:
            cls.client.delete(f"/api/v1/reports/{rid}",
                              headers={"X-CSRF-Token": cls.csrf})

    def test_drift_with_drawio_upload(self):
        data = {"codemodel_report_id": self.cm_id,
                "file": (io.BytesIO(DRAWIO.encode("utf-8")), "arch.drawio")}
        r = self.client.post("/api/v1/code-model/drift", data=data,
                             content_type="multipart/form-data",
                             headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        j = r.get_json()
        self.assertGreaterEqual(j["drift_total"], 1)
        self._saved.append(j["report_id"])

    def test_missing_codemodel_id_rejected(self):
        r = self.client.post("/api/v1/code-model/drift", json={},
                             headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 400)

    def test_no_declared_source_rejected(self):
        r = self.client.post("/api/v1/code-model/drift",
                             json={"codemodel_report_id": self.cm_id},
                             headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 400)


class TestAnalyzeApiErrorHandling(unittest.TestCase):
    """POST /api/v1/code-model/analyze must only convert *expected* failures
    (ScanError: bad remote, clone failure) into a clean 400 — a real bug
    anywhere in the code-model engine must still surface as a logged 500,
    not get silently repackaged as a client error.
    """

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN

    def setUp(self):
        d = tempfile.mkdtemp(prefix="cm_api_err_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(FLASK_APP)
        r = self.client.post("/api/v1/sast/repos",
                             json={"name": "cm-api-err-repo", "url": d},
                             headers={"X-CSRF-Token": self.csrf})
        self.repo_id = r.get_json()["repo"]["id"]
        self.addCleanup(
            lambda: self.client.delete(f"/api/v1/sast/repos/{self.repo_id}",
                                       headers={"X-CSRF-Token": self.csrf}))

    def _analyze(self):
        return self.client.post("/api/v1/code-model/analyze",
                                json={"repo_id": self.repo_id},
                                headers={"X-CSRF-Token": self.csrf})

    def test_scan_error_from_analyze_repo_becomes_a_clean_400(self):
        from broker.scanner import ScanError
        from codemodel import service
        with mock.patch.object(service, "analyze_repo",
                               side_effect=ScanError("git host not in allowlist")):
            r = self._analyze()
        self.assertEqual(r.status_code, 400)
        self.assertIn("allowlist", r.get_json()["error"])

    def test_unexpected_bug_in_analyze_repo_is_not_masked_as_a_400(self):
        # Regression: a bare `except Exception` used to swallow *any*
        # failure from service.analyze_repo() — a real bug (e.g. a KeyError
        # from an extractor/mapper regression) was reported as a 400 client
        # error instead of surfacing as a logged 500.
        from codemodel import service
        with mock.patch.object(service, "analyze_repo", side_effect=KeyError("boom")):
            r = self._analyze()
        self.assertEqual(r.status_code, 500)


if __name__ == "__main__":
    unittest.main()
