"""Tests for assetgraph.engine — pure extraction of assets/edges from a
codemodel report's scan_metadata.
"""
from __future__ import annotations

import unittest

from assetgraph import engine


def _codemodel_report(repo_id="repo-a", repo_name="Repo A", target="payments-api.internal"):
    return {
        "id": "r1", "title": repo_name, "methodology": "codemodel",
        "scan_metadata": {
            "repo_id": repo_id, "repo_name": repo_name,
            "frameworks": ["flask"], "languages": ["python"],
            "attack_surface": [
                {"method": "POST", "path": "/upload", "handler": "upload",
                 "file": "h.py", "line": 3, "framework": "flask",
                 "authenticated": False, "kind": "http", "controls": [], "sinks": []},
            ],
            "data_stores": [{"kind": "sql", "engine": "postgres", "file": "db.py", "line": 1}],
            "external_calls": [{"kind": "http", "target": target, "file": "c.py",
                                "line": 5, "encrypted": True}],
            "trust_boundaries": [{"name": "Client ↔ Application", "kind": "network",
                                  "description": "d"}],
        },
    }


class TestExtract(unittest.TestCase):
    def test_extract_produces_repo_and_child_assets(self):
        assets, edges = engine.extract(_codemodel_report())
        kinds = sorted(a.kind for a in assets)
        self.assertEqual(kinds, ["data_store", "entry_point", "external_service",
                                 "repo", "trust_boundary"])

    def test_repo_asset_is_first_and_carries_frameworks(self):
        assets, _ = engine.extract(_codemodel_report())
        repo = assets[0]
        self.assertEqual(repo.kind, "repo")
        self.assertEqual(repo.attributes["frameworks"], ["flask"])

    def test_edges_all_originate_from_repo_node(self):
        assets, edges = engine.extract(_codemodel_report())
        repo_id = assets[0].id
        self.assertTrue(edges)
        self.assertTrue(all(e.from_id == repo_id for e in edges))

    def test_entry_point_edge_relation_is_contains(self):
        _, edges = engine.extract(_codemodel_report())
        ep_edges = [e for e in edges if e.relation == "contains"]
        self.assertTrue(ep_edges)

    def test_trust_boundary_edge_relation_is_crosses(self):
        _, edges = engine.extract(_codemodel_report())
        tb_edges = [e for e in edges if e.relation == "crosses"]
        self.assertEqual(len(tb_edges), 1)

    def test_entry_point_identity_includes_repo_id(self):
        assets_a, _ = engine.extract(_codemodel_report(repo_id="repo-a"))
        assets_b, _ = engine.extract(_codemodel_report(repo_id="repo-b"))
        ep_a = next(a for a in assets_a if a.kind == "entry_point")
        ep_b = next(a for a in assets_b if a.kind == "entry_point")
        self.assertNotEqual(ep_a.id, ep_b.id)

    def test_external_service_identity_is_repo_independent(self):
        """The whole point of a graph: the same external target called by two
        different repos must resolve to the SAME node."""
        assets_a, _ = engine.extract(_codemodel_report(repo_id="repo-a"))
        assets_b, _ = engine.extract(_codemodel_report(repo_id="repo-b"))
        ext_a = next(a for a in assets_a if a.kind == "external_service")
        ext_b = next(a for a in assets_b if a.kind == "external_service")
        self.assertEqual(ext_a.id, ext_b.id)

    def test_trust_boundary_identity_is_repo_independent(self):
        assets_a, _ = engine.extract(_codemodel_report(repo_id="repo-a"))
        assets_b, _ = engine.extract(_codemodel_report(repo_id="repo-b"))
        tb_a = next(a for a in assets_a if a.kind == "trust_boundary")
        tb_b = next(a for a in assets_b if a.kind == "trust_boundary")
        self.assertEqual(tb_a.id, tb_b.id)

    def test_different_external_target_is_a_different_node(self):
        assets_a, _ = engine.extract(_codemodel_report(target="service-a.internal"))
        assets_b, _ = engine.extract(_codemodel_report(target="service-b.internal"))
        ext_a = next(a for a in assets_a if a.kind == "external_service")
        ext_b = next(a for a in assets_b if a.kind == "external_service")
        self.assertNotEqual(ext_a.id, ext_b.id)

    def test_no_repo_id_anywhere_yields_nothing(self):
        report = {"id": "", "methodology": "codemodel", "scan_metadata": {}}
        assets, edges = engine.extract(report)
        self.assertEqual(assets, [])
        self.assertEqual(edges, [])

    def test_falls_back_to_report_id_when_scan_metadata_lacks_repo_id(self):
        report = {"id": "r1", "methodology": "codemodel", "scan_metadata": {}}
        assets, edges = engine.extract(report)
        self.assertEqual(len(assets), 1)
        self.assertEqual(assets[0].kind, "repo")
        self.assertEqual(edges, [])

    def test_extraction_is_deterministic(self):
        r = _codemodel_report()
        a1, e1 = engine.extract(r)
        a2, e2 = engine.extract(r)
        self.assertEqual({a.id for a in a1}, {a.id for a in a2})
        self.assertEqual({e.id for e in e1}, {e.id for e in e2})


if __name__ == "__main__":
    unittest.main()
