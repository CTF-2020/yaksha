"""app.py — TM: OWASP Threat Model Tool — Flask backend."""
from __future__ import annotations
import itertools
import json
import logging
import os
import re
import secrets
import sys
import threading
import time
import traceback
import uuid
from html import escape as html_escape
from pathlib import Path
from urllib.parse import quote

from flask import (
    Flask, Response, jsonify, redirect, render_template, request as req, session,
    stream_with_context,
)
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

import analyzer
import drawio_parser
import mitre_attack
import compliance_mappings
import sbom_parser
import jira_client
import control_register
import pqc_assessment
import report_store
import report_db
import rules_catalog
import settings_db
import suppressions
import regression
import verdict_tracking

sys.modules.setdefault("app", sys.modules[__name__])

log = logging.getLogger(__name__)
logging.getLogger("werkzeug").setLevel(logging.WARNING)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
    handlers=[logging.StreamHandler()],
)

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

REPORTS_DIR = Path.home() / ".tm_reports"
REPORTS_DIR.mkdir(exist_ok=True)

# Retention: keep only the newest N reports in the database so it cannot grow
# without bound; pruned on each save (see _prune_reports_to_limit).
_RETENTION_LIMIT = 200

# Secrets that must never be written to a persisted report, regardless of how the
# analysis dict was assembled. Belt-and-suspenders for "the secret never persists".
_SECRET_KEYS = ("api_key", "apiKey", "anthropic_api_key", "ANTHROPIC_API_KEY",
                "jira_token", "azure_token", "linear_api_key", "confluence_api_token",
                "secret", "password")


def _scrub_secrets(report: dict) -> dict:
    """Remove any credential-bearing keys from a report before it is written."""
    for key in _SECRET_KEYS:
        report.pop(key, None)
    return report

def _load_or_create_secret_key(key_path: Path | None = None) -> str:
    """Resolve the Flask SECRET_KEY: TM_SECRET_KEY env var wins, else a key
    persisted at ~/.tm_secret_key (created on first boot, owner-only perms).

    A random per-process key looks harmless with a single-process server, but
    the documented production commands run gunicorn with multiple workers —
    each worker would sign CSRF tokens with a different key, so most POSTs
    would 403 depending on which worker handled them. O_EXCL + read-back keeps
    concurrent first-boot workers converging on one key.
    """
    env = os.environ.get("TM_SECRET_KEY", "").strip()
    if env:
        return env
    path = key_path or (Path.home() / ".tm_secret_key")

    def _read_valid() -> str | None:
        try:
            existing = path.read_text(encoding="ascii").strip()
            return existing if len(existing) >= 32 else None
        except (OSError, UnicodeDecodeError):
            return None

    key = _read_valid()
    if key:
        return key
    key = secrets.token_hex(32)
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="ascii") as fh:
            fh.write(key)
        return key
    except FileExistsError:
        # Another worker won the create race — give its write a moment to land.
        for delay in (0.05, 0.1, 0.2):
            time.sleep(delay)
            existing = _read_valid()
            if existing:
                return existing
        # File exists but never became valid (corrupt/truncated): replace it
        # atomically so it cannot wedge every future boot into random keys.
        try:
            tmp = str(path) + ".tmp"
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="ascii") as fh:
                fh.write(key)
            report_store.atomic_replace(tmp, path)
            return key
        except OSError:
            pass
    except OSError:
        pass
    # Unwritable home (read-only container without a volume): fall back to a
    # process-local key. Single-process servers still work; multi-worker
    # deployments must set TM_SECRET_KEY explicitly.
    log.warning("Could not persist secret key at %s — using a process-local "
                "key. Set TM_SECRET_KEY for multi-worker deployments.", path)
    return key


app = Flask(__name__)
app.config["SECRET_KEY"] = _load_or_create_secret_key()
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB max upload


@app.template_filter("epoch")
def _format_epoch(value):
    """Render a Unix-epoch (seconds) timestamp as a readable UTC date/time."""
    if not value:
        return "—"
    try:
        return time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(float(value)))
    except (TypeError, ValueError):
        return "—"


import portal_nav


@app.context_processor
def _inject_portal_nav():
    """Every template renders its navbar from portal_nav.py (also served at
    /api/v1/nav) so the tab list exists in exactly one place."""
    import auth
    is_admin = auth.is_admin()
    nav_items = [i for i in portal_nav.NAV_ITEMS if not i.get("admin_only") or is_admin]
    return {
        "portal_nav_items": nav_items,
        "portal_use_cases": portal_nav.USE_CASES,
        "current_user_email": session.get("user_email"),
        "current_user_is_admin": is_admin,
    }

try:
    from flask_compress import Compress
    Compress(app)
except ImportError:
    pass

limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=[],
    storage_uri="memory://",
)

# In-memory job store for SSE progress streaming
_jobs: dict[str, dict] = {}
_jobs_lock = threading.Lock()
_JOB_TTL = 3600  # seconds before an uncollected job is pruned


def _prune_stale_jobs():
    """Background thread: remove jobs older than _JOB_TTL seconds."""
    while True:
        time.sleep(300)
        cutoff = time.monotonic() - _JOB_TTL
        with _jobs_lock:
            stale = [jid for jid, j in _jobs.items() if j.get("created_at", 0) < cutoff]
            for jid in stale:
                _jobs.pop(jid, None)
        if stale:
            log.debug("Pruned %d stale jobs", len(stale))


threading.Thread(target=_prune_stale_jobs, daemon=True, name="job-pruner").start()

# Optional server-side API key guard (set TM_API_KEY env var, or
# `python settings_db.py set app.api_key <key>`, to enable)
_TM_API_KEY: str = settings_db.resolve_str("app.api_key", os.environ.get("TM_API_KEY"), "")

# Resolved once at import, not per-request: these two fire on every HTTP
# response via _prod_headers below, so re-querying settings_db per request
# would add a SQLite read to every response. A change via the DB (like a
# changed env var today) takes effect on the next process restart.
_FRAME_OPTIONS: str = settings_db.resolve_str(
    "app.frame_options", os.environ.get("TM_FRAME_OPTIONS"), "DENY").strip()
_DISABLE_CSP: bool = settings_db.resolve_bool(
    "app.disable_csp", os.environ.get("TM_DISABLE_CSP"), False)

# Session-login page gate — OFF by default. A login system that exists but
# gates nothing (see api/login.py) is a false sense of security; but flipping
# it on unconditionally would lock out every existing local/personal install
# the moment it upgrades. Opt in with TM_REQUIRE_LOGIN=1 (or
# `python settings_db.py set app.require_login true`) once real accounts and
# credentials are in place.
_REQUIRE_LOGIN: bool = settings_db.resolve_bool(
    "app.require_login", os.environ.get("TM_REQUIRE_LOGIN"), False)

# Paths reachable with no session at all, even when the gate is on.
_LOGIN_EXEMPT_PATHS = {"/login", "/logout", "/health", "/api/csrf-token"}
_LOGIN_EXEMPT_PREFIXES = ("/static/",)


def _login_exempt(path: str) -> bool:
    return path in _LOGIN_EXEMPT_PATHS or path.startswith(_LOGIN_EXEMPT_PREFIXES)

# ── CSRF (session-bound via itsdangerous) ─────────────────────────────────────

from itsdangerous import URLSafeSerializer as _USS

_csrf_signer = _USS(app.config["SECRET_KEY"], salt="csrf")
_CSRF_TOKEN: str = _csrf_signer.dumps("csrf-token")


@app.after_request
def _prod_headers(response):
    rid = req.headers.get("X-Request-ID", secrets.token_hex(8))
    response.headers["X-Request-ID"]          = rid
    response.headers["X-Content-Type-Options"] = "nosniff"
    # Clickjacking: DENY unless overridden (no TM page frames another).
    # Set TM_FRAME_OPTIONS=off (or app.frame_options=off) to suppress the header.
    if _FRAME_OPTIONS and _FRAME_OPTIONS.lower() not in ("off", "none", "0"):
        response.headers["X-Frame-Options"] = _FRAME_OPTIONS
    response.headers["X-XSS-Protection"]       = "1; mode=block"
    response.headers["Referrer-Policy"]        = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"]     = "geolocation=(), camera=(), microphone=()"
    if req.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    elif (response.mimetype or "") == "text/html":
        # Dashboard pages must revalidate so UI updates ship without a hard refresh.
        response.headers["Cache-Control"] = "no-cache"
    # CSP ships ON by default (TM_DISABLE_CSP=1, or app.disable_csp, turns it
    # off). The allowlist covers every external origin the templates load:
    # mermaid from jsdelivr, Google fonts CSS + woff2. 'unsafe-inline' for
    # scripts is a transitional concession to the inline onclick= handlers
    # across the templates — the policy still pins which ORIGINS may execute;
    # dropping unsafe-inline requires migrating ~65 inline handlers to
    # addEventListener first.
    if not _DISABLE_CSP:
        csp = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' cdn.jsdelivr.net fonts.googleapis.com; "
            "style-src 'self' 'unsafe-inline' fonts.googleapis.com fonts.gstatic.com; "
            "font-src fonts.gstatic.com data:; "
            "img-src 'self' data:; "
            "object-src 'none'; "
            "base-uri 'self'; "
            "frame-ancestors 'none'; "
            "connect-src 'self';"
        )
        response.headers["Content-Security-Policy"] = csp
    return response


@app.before_request
def _auth_and_csrf():
    # GitHub webhooks authenticate with a per-repo HMAC (X-Hub-Signature-256);
    # the Jira design-review webhook authenticates with a shared secret
    # (header or query param — Jira has no native request-signing). Neither
    # uses the CSRF token or the TM_API_KEY bearer that browsers/clients send.
    # Exempt those paths; each route verifies its own auth.
    if req.path in ("/api/v1/sast/webhook",
                    "/api/v1/design-review/webhook"):
        return
    # Per-report share links authenticate with their own token (see
    # api/reports.py::report_shared), not the global TM_API_KEY — that's the
    # whole point of handing one report to someone without the master key.
    if req.path.startswith("/api/v1/reports/") and req.path.endswith("/shared"):
        return
    # Same for the correlator's own public share route (api/correlate.py::
    # public_correlate) -- matched by view identity, not a path pattern, so
    # it can never accidentally exempt a sibling /api/v1/correlate/* route
    # the way a bare-segment path match on "/<id>" would risk doing.
    if req.endpoint == "correlate_api.public_correlate":
        return

    # Optional API key guard — only active when TM_API_KEY is set
    api_key_ok = False
    if _TM_API_KEY and req.path.startswith("/api/"):
        bearer = req.headers.get("Authorization", "")
        provided = bearer.removeprefix("Bearer ").strip() or req.headers.get("X-API-Key", "")
        if not secrets.compare_digest(provided, _TM_API_KEY):
            return jsonify({"success": False, "error": "Unauthorized"}), 401
        api_key_ok = True

    # Session-login gate (opt-in — see _REQUIRE_LOGIN above). A valid
    # TM_API_KEY bearer already proved machine identity for this request, so
    # it satisfies this too; a browser with no session needs the human login.
    if _REQUIRE_LOGIN and not api_key_ok and not _login_exempt(req.path) \
            and not session.get("user_email"):
        if req.path.startswith("/api/"):
            return jsonify({"success": False, "error": "Login required"}), 401
        return redirect(f"/login?next={quote(req.path, safe='')}")

    if req.method in ("GET", "HEAD", "OPTIONS"):
        return
    # CSRF check — skip for the CSRF token endpoint itself
    if req.path == "/api/csrf-token":
        return
    client_token = req.headers.get("X-CSRF-Token", "") or req.form.get("csrf_token", "")
    try:
        _csrf_signer.loads(client_token, salt="csrf")
    except Exception:
        return jsonify({"success": False, "error": "CSRF token invalid"}), 403


@app.errorhandler(404)
def _not_found(e):
    if req.path.startswith("/api/"):
        return jsonify({"success": False, "error": "Not found", "code": 404}), 404
    return jsonify({"success": False, "error": "Not found"}), 404

@app.errorhandler(429)
def _rate_limited(e):
    return jsonify({"success": False, "error": "Rate limit exceeded — please retry after a moment", "code": 429}), 429

@app.errorhandler(413)
def _too_large(e):
    return jsonify({"success": False, "error": "Request payload too large (max 16MB)", "code": 413}), 413

@app.errorhandler(Exception)
def _err(e):
    code = getattr(e, "code", 500)
    if not isinstance(code, int):
        code = 500
    if code >= 500:
        log.error(traceback.format_exc())
    return jsonify({"success": False, "error": str(e)}), code


# ── Report retention ──────────────────────────────────────────────────────────

def _prune_reports_to_limit() -> None:
    """Keep only the newest _RETENTION_LIMIT reports in each bucket.

    report_db is the system of record, so this is a direct DB prune (not an
    index-driven filesystem sweep); any JSON backup files for pruned ids are
    best-effort removed too, purely for disk hygiene.

    SAST/DAST reports get their own retention pool sized to broker's job
    history (JOB_RETENTION) rather than sharing _RETENTION_LIMIT with every
    other report type — otherwise a burst of design reviews (or anything
    else) evicts SAST reports whose broker job entries are still listed,
    leaving the "open" link in the Scan jobs table 404.
    """
    try:
        from broker.config import JOB_RETENTION
        sast_limit = max(_RETENTION_LIMIT, JOB_RETENTION)
    except Exception:
        sast_limit = _RETENTION_LIMIT
    try:
        for report_id in report_db.prune_to_limit_by_bucket(sast_limit, _RETENTION_LIMIT):
            try:
                (REPORTS_DIR / f"{report_id}.json").unlink(missing_ok=True)
            except OSError:
                pass
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("report retention prune failed: %s", exc)


def _backfill_report_db() -> None:
    """One-time migration of a pre-2026-07-23 JSON-only install into the database.

    Runs on boot only when the database is empty (fresh install, or an
    upgrade from before report_db was the system of record). Never touches or
    deletes the JSON files — purely additive.
    """
    try:
        report_db.init()
        if report_db.report_count() > 0:
            return
        loaded = []
        for p in sorted(REPORTS_DIR.glob("*.json"), reverse=True):
            if p.name.startswith("_"):
                continue
            d = report_store.read_json(p, default=None)
            if isinstance(d, dict):
                d.setdefault("id", p.stem)
                loaded.append(d)
        if loaded:
            n = report_db.backfill(loaded)
            log.info("report_db migrated %d report(s) from a pre-existing JSON store", n)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("report_db migration skipped: %s", exc)


def _backfill_suppressions_db() -> None:
    """One-time migration of a pre-2026-07-25 ~/.tm_suppressions.json install
    into SQLite. Runs on boot only when the database is empty. Never touches
    or deletes the JSON file — purely additive."""
    try:
        from suppressions import db as supp_db
        from suppressions.model import Suppression
        supp_db.init()
        if supp_db.count() > 0:
            return
        raw = report_store.read_json(Path.home() / ".tm_suppressions.json", default=[])
        if not isinstance(raw, list) or not raw:
            return
        loaded = []
        for item in raw:
            if isinstance(item, dict):
                try:
                    loaded.append(Suppression.from_dict(item))
                except ValueError:
                    continue
        if loaded:
            n = supp_db.backfill(loaded)
            log.info("suppressions db migrated %d record(s) from a pre-existing JSON store", n)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("suppressions db migration skipped: %s", exc)


def _backfill_broker_db() -> None:
    """One-time migration of a pre-2026-07-25 ~/.tm_broker JSON install into
    SQLite. Runs on boot only when the database is empty. Never touches or
    deletes the JSON files — purely additive.

    Baselines are NOT backfilled: their filenames are a lossy slug of
    `repo_id__branch` (non-alnum runs collapse to a single '-'), so the
    original key can't be recovered reliably. This is low-cost to skip —
    broker/service.py recaptures a baseline fresh on the next push, so the
    only effect is one broader PR-delta report right after upgrading."""
    try:
        from broker import config as broker_config
        from broker import db as broker_db
        broker_db.init()
        if broker_db.repo_count() > 0:
            return
        repos = report_store.read_json(broker_config.REPOS_PATH, default=[])
        jobs = report_store.read_json(broker_config.JOBS_PATH, default=[])
        sha_cache = report_store.read_json(broker_config.SHA_CACHE_PATH, default={})
        n = broker_db.backfill(
            repos if isinstance(repos, list) else [],
            jobs if isinstance(jobs, list) else [],
            [], sha_cache if isinstance(sha_cache, dict) else {})
        if n:
            log.info("broker db migrated %d record(s) from a pre-existing JSON store", n)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("broker db migration skipped: %s", exc)


def _backfill_aibom_db() -> None:
    """One-time migration of a pre-2026-07-25 ~/.tm_aibom JSON install into
    SQLite. Runs on boot only when the database is empty. Never touches or
    deletes the JSON files — purely additive."""
    try:
        from aibom import config as aibom_config
        from aibom import db as aibom_db
        aibom_db.init()
        if aibom_db.job_count() > 0:
            return
        jobs = report_store.read_json(aibom_config.JOBS_PATH, default=[])
        boms = {}
        if aibom_config.BOM_DIR.exists():
            for p in aibom_config.BOM_DIR.glob("*.json"):
                data = report_store.read_json(p, default=None)
                if isinstance(data, dict):
                    boms[p.stem] = data
        latest = []
        if aibom_config.LATEST_DIR.exists():
            for p in aibom_config.LATEST_DIR.glob("*.json"):
                data = report_store.read_json(p, default=None)
                if isinstance(data, dict):
                    data.setdefault("repo_id", p.stem)
                    latest.append(data)
        n = aibom_db.backfill(jobs if isinstance(jobs, list) else [], boms, latest)
        if n:
            log.info("aibom db migrated %d record(s) from a pre-existing JSON store", n)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("aibom db migration skipped: %s", exc)


def _bootstrap_admin_user() -> None:
    """Create the first admin account from env vars on first boot — same
    env-var-driven convention as _load_or_create_secret_key. If no account
    exists and the env vars aren't set, log so an operator knows to run
    `python users_db.py add <email> <password>`."""
    try:
        import users_db
        users_db.init()
        if users_db.user_count() > 0:
            return
        email = os.environ.get("TM_ADMIN_EMAIL", "").strip()
        password = os.environ.get("TM_ADMIN_PASSWORD", "")
        if email and password:
            users_db.create_user(email, password, role="admin")
            log.info("created initial admin user %s from TM_ADMIN_EMAIL/TM_ADMIN_PASSWORD", email)
        else:
            log.warning("no users exist yet — set TM_ADMIN_EMAIL/TM_ADMIN_PASSWORD or run "
                        "`python users_db.py add <email> <password>` to provision one")
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("admin user bootstrap skipped: %s", exc)


def _init_llm_usage_db() -> None:
    """Ensure the Claude API token-usage/cost ledger's schema exists. No
    backfill — the feature didn't exist before this, so there's no prior
    store to migrate (see llm_usage_db.py)."""
    try:
        import llm_usage_db
        llm_usage_db.init()
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("llm usage db init skipped: %s", exc)


_backfill_report_db()
_backfill_suppressions_db()
_backfill_broker_db()
_backfill_aibom_db()
_bootstrap_admin_user()
_init_llm_usage_db()


# ── Report ID validation ──────────────────────────────────────────────────────

_REPORT_ID_RE = re.compile(r'^[A-Za-z0-9_-]{8,80}$')


def _validate_report_id(report_id: str) -> bool:
    return bool(_REPORT_ID_RE.match(report_id))


def _is_sast_methodology(methodology) -> bool:
    """SAST broker reports are served only under /api/v1/sast, never the
    general report API — a dashboard viewer must not see repo scan findings."""
    if isinstance(methodology, list):
        return any(str(m).strip().lower() == "sast" for m in methodology)
    return str(methodology or "").strip().lower() == "sast"


def _methodology_from_form(default: str = "owasp"):
    values = [m.strip() for m in req.form.getlist("methodology") if m.strip()]
    if not values:
        value = req.form.get("methodology", default)
        values = [value.strip()] if isinstance(value, str) and value.strip() else [default]
    return values if len(values) > 1 else values[0]


def _methodology_from_json(body: dict, default: str = "owasp"):
    value = body.get("methodology", default)
    if isinstance(value, list):
        values = [str(v).strip() for v in value if str(v).strip()]
        return values if len(values) > 1 else (values[0] if values else default)
    return str(value).strip() or default


def _fallback_without_api_key(methodology):
    if analyzer.is_offline_capable_methodology(methodology):
        return methodology
    return analyzer.offline_fallback_methodologies(methodology)


def _env_api_key_if_omitted(api_key: str, key_was_supplied: bool) -> str:
    """Use server env key only when the request omits api_key entirely.

    The UI intentionally sends an empty api_key when the user wants offline mode.
    """
    if api_key or key_was_supplied:
        return api_key
    return settings_db.resolve_str("app.anthropic_api_key", os.environ.get("ANTHROPIC_API_KEY"), "")


def _uploaded_files() -> list:
    return [file for key in ("file", "files") for file in req.files.getlist(key)]


def _github_system_model(github_url: str, branch: str = ""):
    """Clone a git repo once and return (model, label) from its code.

    Only real git URLs are accepted — never a filesystem path. prepare_workspace
    would happily treat a non-URL as a local directory, so the looks_like_git_url
    gate below is what keeps this public endpoint from gaining arbitrary
    filesystem reach. file:// and cleartext http are additionally refused by the
    broker's clone policy unless explicitly enabled.
    """
    from broker import config as broker_config
    from broker import scanner as broker_scanner

    url = (github_url or "").strip()
    if len(url) > 500:
        raise ValueError("Repository URL too long.")
    if not broker_scanner.looks_like_git_url(url):
        raise ValueError("Not a recognized git repository URL.")

    repo = {
        "id": "tm-" + broker_config.slugify(url),
        "name": url,
        "url": url,
        "branch": (branch or "").strip()[:120],
        "kind": "git",
    }
    try:
        scan_root, meta = broker_scanner.prepare_workspace(repo)
    except broker_scanner.ScanError as exc:
        raise ValueError(str(exc))

    from codemodel import extractor
    model = extractor.build_model(str(scan_root))
    label = url + (f" @ {meta['commit']}" if meta.get("commit") else "")
    return model, label


def _architecture_from_github(github_url: str, branch: str = "") -> str:
    """Derive a threat-model architecture description from a repo's code."""
    from codemodel import describe
    model, label = _github_system_model(github_url, branch)
    return describe.describe_model(model, label)


def _github_arch_and_diagram(github_url: str, branch: str = "") -> tuple[str, str]:
    """Clone once; return (architecture description, code-derived DFD Mermaid).

    The diagram is deterministic and offline — it draws the extracted attack
    surface, trust boundaries, and cleartext/unauthenticated risks, so a repo
    threat model gets a real data-flow diagram even with no API key.
    """
    from codemodel import describe, diagram
    model, label = _github_system_model(github_url, branch)
    return describe.describe_model(model, label), diagram.to_mermaid_dfd(model, label)


def _merge_github_architecture(arch: str, derived: str) -> str:
    """Append a repo-derived architecture section to the typed/uploaded text."""
    section = ("Code-derived architecture from repository (IN SCOPE FOR THREAT "
               "MODEL):\n" + derived)
    return f"{arch}\n\n{section}" if arch else section


def _attach_codemodel_diagram(report: dict, diagram_code) -> None:
    """Surface the code-derived DFD in the report's diagrams map (UI renders it).

    No-op when there is no diagram (non-repo analysis). The 'codemodel' key is
    labelled in the report viewer; it appears alongside any LLM-generated
    diagrams and works with no API key.
    """
    if not diagram_code or not isinstance(report, dict):
        return
    diagrams = report.get("diagrams")
    if not isinstance(diagrams, dict):
        diagrams = {}
        report["diagrams"] = diagrams
    diagrams["codemodel"] = diagram_code


def _architecture_from_uploads(typed_arch: str, files) -> str:
    """Return architecture text plus supporting documents as threat-model scope."""
    arch = (typed_arch or "").strip()
    usable_files = [file for file in files if file and (file.filename or "").strip()]
    if not usable_files:
        return arch

    sections = []
    if arch:
        sections.append(f"Primary architecture description (in scope for threat model):\n{arch}")

    for index, file in enumerate(usable_files, start=1):
        filename = file.filename or f"uploaded-file-{index}"
        content = file.read().decode("utf-8", errors="replace").strip()
        if filename.lower().endswith((".drawio", ".xml")):
            file_arch = drawio_parser.parse_drawio(content).strip()
        else:
            file_arch = content
        if file_arch:
            sections.append(
                f"Supporting document {index} ({filename}) - IN SCOPE FOR THREAT MODEL:\n{file_arch}"
            )

    return "\n\n".join(sections).strip()


# ── UI ────────────────────────────────────────────────────────────────────────

@app.route("/health")
def health():
    from offline_rules import ALL_RULES
    total_rules = sum(len(v) for v in ALL_RULES.values())
    return jsonify({
        "status": "ok",
        "version": "2.0.0",
        "rulesets": len(ALL_RULES),
        "rules": total_rules,
        "methodologies": len(analyzer.METHODOLOGY_OPTIONS),
        "reports_dir": str(REPORTS_DIR),
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    })


@app.route("/reports")
def index():
    return render_template("index.html", csrf_token=_CSRF_TOKEN)


@app.route("/api/csrf-token")
def csrf_token():
    return jsonify({"token": _CSRF_TOKEN})


_report_id_counter = itertools.count(1)  # atomic in CPython; unique within a run


_RISK_RATING_SCORE = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}


def _aggregate_rule_risk_rating(refs: list[dict]) -> dict | None:
    """Worst (most alarming) confidence/likelihood/impact across every
    matched catalog rule, independently per dimension -- "does ANY well-known
    rule for this weakness class call it high-confidence/high-likelihood/
    high-impact" is the strongest form of external corroboration available,
    stronger than averaging it away. None when no matched rule carries any of
    the three fields (about 30% of the catalog doesn't)."""
    def worst(field: str) -> str:
        best = ""
        for r in refs:
            val = str(r.get(field, "")).upper()
            if _RISK_RATING_SCORE.get(val, 0) > _RISK_RATING_SCORE.get(best, 0):
                best = val
        return best

    rating = {"confidence": worst("confidence"), "likelihood": worst("likelihood"),
              "impact": worst("impact"), "matched_rules": len(refs)}
    if not (rating["confidence"] or rating["likelihood"] or rating["impact"]):
        return None
    return rating


def _enrich_with_rule_references(report: dict) -> None:
    """Attach rule-catalog citations to categories carrying a CWE.

    So a generated SAST/Codemodel/DAST finding isn't an isolated claim — it's
    checkable against the same weakness pattern in the 2,400+-rule reference
    catalog browsable at /rules (see rules_catalog.py). Purely additive: a
    category with no CWE, or no catalog match, is left untouched.

    Also aggregates the matched rules' confidence/likelihood/impact metadata
    into ``rule_risk_rating`` (see _aggregate_rule_risk_rating) — the
    correlator folds this into its confidence score alongside multi-source
    corroboration (correlator/engine.py:_confidence).
    """
    for cat in report.get("categories") or []:
        if not isinstance(cat, dict) or cat.get("rule_references"):
            continue
        cwe = cat.get("cwe")
        cwes = [cwe] if isinstance(cwe, str) else (cwe if isinstance(cwe, list) else [])
        refs = rules_catalog.related(cwes)
        if refs:
            cat["rule_references"] = refs
            rating = _aggregate_rule_risk_rating(refs)
            if rating:
                cat["rule_risk_rating"] = rating


def _save_report(report: dict, title: str, architecture_text: str = "") -> str:
    # timestamp + monotonic counter + random -> unique even for many reports in
    # the same second (e.g. the pipeline saving SAST+codemodel+correlation).
    report_id = f"{int(time.time())}_{next(_report_id_counter)}_{secrets.token_hex(4)}"
    report["id"] = report_id
    report["title"] = title
    # Per-report share token: lets this one report be fetched externally (a
    # link handed to a client/stakeholder) without the global TM_API_KEY or a
    # login session. High-entropy and unrelated to the report id, which is
    # guessable-ish (timestamp + small counter + 4 random bytes).
    report["share_token"] = secrets.token_urlsafe(32)
    if architecture_text and not report.get("architecture_text"):
        report["architecture_text"] = architecture_text
    _enrich_with_rule_references(report)
    _scrub_secrets(report)
    # SQLite is the system of record — this must succeed, so it is NOT wrapped
    # in try/except like the JSON backup below.
    report_db.upsert_report(report)
    _prune_reports_to_limit()
    # Best-effort human-readable backup file; nothing reads it back in normal
    # operation, so a failure here must never fail the save itself.
    try:
        report_store.atomic_write_json(REPORTS_DIR / f"{report_id}.json", report)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("JSON backup write failed for %s: %s", report_id, exc)
    # Verdict-escalation detection is diagnostic, not load-bearing -- a store
    # failure here must never fail the save itself.
    try:
        for alert in verdict_tracking.record_transitions(report):
            log.warning(
                "verdict escalation: %s (%s) went %s -> %s in report %s",
                alert["title"], alert["family"], alert["from_verdict"],
                alert["to_verdict"], report_id)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("verdict transition tracking failed for %s: %s", report_id, exc)
    # Verdict-based canary/regression case generation is likewise
    # diagnostic/best-effort -- persisting replayable cases must never fail
    # the save itself.
    try:
        regression.sync_from_report(report)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("regression case sync failed for %s: %s", report_id, exc)
    return report_id


_FINDING_TITLES = {
    "AI-LLM01": "Prompt Injection",
    "AI-LLM02": "Insecure Output Handling",
    "AI-LLM03": "Training Data and Model Poisoning",
    "AI-LLM04": "Model Denial of Service",
    "AI-LLM05": "Supply Chain Vulnerabilities",
    "AI-LLM06": "Sensitive Information Disclosure",
    "AI-LLM07": "Insecure Plugin and Tool Design",
    "AI-LLM08": "Excessive Agency",
    "AI-LLM09": "Overreliance",
    "AI-LLM10": "Model Theft",
    "API-API1": "Broken Object Level Authorization",
    "API-API2": "Broken Authentication",
    "API-API3": "Broken Object Property Level Authorization",
    "API-API4": "Unrestricted Resource Consumption",
    "API-API5": "Broken Function Level Authorization",
    "API-API6": "Unrestricted Access to Sensitive Business Flows",
    "API-API7": "Server Side Request Forgery",
    "API-API8": "Security Misconfiguration",
    "API-API9": "Improper Inventory Management",
    "API-API10": "Unsafe Consumption of APIs",
    "WEB-A01": "Broken Access Control",
    "WEB-A02": "Cryptographic Failures",
    "WEB-A03": "Injection",
    "WEB-A04": "Insecure Design",
    "WEB-A05": "Security Misconfiguration",
    "WEB-A06": "Vulnerable and Outdated Components",
    "WEB-A07": "Identification and Authentication Failures",
    "WEB-A08": "Software and Data Integrity Failures",
    "WEB-A09": "Security Logging and Monitoring Failures",
    "WEB-A10": "Server-Side Request Forgery",
}


def _finding_title(category: dict) -> str:
    finding_id = str(category.get("id") or category.get("category") or "").strip()
    name = str(category.get("name") or category.get("title") or "").strip()
    if name and name != finding_id and not re.fullmatch(r"[A-Z]+-[A-Z0-9_]+", name):
        return name
    if finding_id in _FINDING_TITLES:
        return _FINDING_TITLES[finding_id]
    label = re.sub(r"^[A-Z]+-", "", finding_id or name).replace("_", " ").replace("-", " ").strip()
    return label.title() if label else "Security Finding"


def _finding_summary(category: dict) -> str:
    threats = category.get("threats") or []
    first_threat = next((t for t in threats if isinstance(t, dict) and (t.get("description") or t.get("name"))), {})
    return str(
        category.get("description")
        or category.get("framework_description")
        or first_threat.get("description")
        or first_threat.get("name")
        or category.get("notes")
        or ""
    )


_ATTACK_VECTOR_DETAILS = {
    "AI-LLM01": {
        "title": "Prompt injection through user input, RAG content, or tool output",
        "path": [
            "Attacker submits hostile instructions through chat, uploaded documents, retrieved RAG content, web fetches, tool output, or agent-to-agent messages.",
            "Those instructions are mixed into the model context without strict separation from trusted system/developer instructions.",
            "The model may disclose protected context, call tools incorrectly, bypass guardrails, or perform actions outside the intended policy.",
        ],
        "verify": [
            "Check every untrusted text source entering the prompt: user message, document ingestion, vector retrieval, web fetch, plugin/tool output, and agent messages.",
            "Confirm retrieved documents are treated as quoted data with provenance, not as instructions.",
            "Confirm high-impact actions require server-side authorization and explicit approval instead of relying on model obedience.",
        ],
    },
    "AI-LLM02": {
        "title": "Unsafe model output passed into browser, SQL, shell, code, or downstream tools",
        "path": [
            "Attacker manipulates the model into producing unsafe HTML, SQL, shell commands, file paths, URLs, or tool parameters.",
            "Application code trusts that output and renders or executes it without validation.",
        ],
        "verify": [
            "Inspect every sink that consumes model output and enforce schemas, allowlists, escaping, parameterization, and sandboxing.",
        ],
    },
    "AI-LLM03": {
        "title": "Poisoned training data, RAG documents, or vector-store entries influence model behavior",
        "path": [
            "Attacker gets malicious content into ingestion, fine-tuning, or vector-store write paths.",
            "Retrieval or training promotes poisoned content into future model context.",
        ],
        "verify": [
            "Review vector database write access, document provenance, tenant isolation, ingestion scanning, and retrieval anomaly monitoring.",
        ],
    },
    "API-API1": {
        "title": "Broken object-level authorization through ID or object reference manipulation",
        "path": [
            "Attacker changes object IDs, tenant IDs, file keys, or record identifiers in API calls.",
            "The API checks authentication but fails to verify ownership of the requested object.",
        ],
        "verify": [
            "Check every endpoint accepting IDs, object keys, tenant IDs, and bulk object lists for server-side per-object authorization.",
        ],
    },
}


def _attack_vector_html(category: dict) -> str:
    finding_id = str(category.get("id") or category.get("category") or "").strip()
    detail = _ATTACK_VECTOR_DETAILS.get(finding_id)
    threats = category.get("threats") or []
    vectors = [
        str(t.get("attack_vector"))
        for t in threats
        if isinstance(t, dict) and t.get("attack_vector")
    ]
    if not detail and not vectors:
        return ""
    title = html_escape(detail["title"] if detail else vectors[0])
    path_items = detail["path"] if detail else [f"Detected vector signal: {v}" for v in vectors]
    verify_items = detail.get("verify", []) if detail else []
    path_html = "".join(f"<li>{html_escape(str(item))}</li>" for item in path_items)
    verify_html = "".join(f"<li>{html_escape(str(item))}</li>" for item in verify_items)
    extra = f"<h4>What to verify</h4><ul>{verify_html}</ul>" if verify_html else ""
    return f"<div class=\"attack\"><h4>Attack Vector</h4><p>{title}</p><ul>{path_html}</ul>{extra}</div>"


def _render_plain_report(report: dict, report_id: str, status_code: int = 200):
    # Apply risk-acceptance decisions at render time: suppressed findings stay
    # visible (audit) but are marked and drop out of the active risk pill.
    try:
        report = suppressions.annotate_report(report, suppressions.load_suppressions())
    except Exception:  # pragma: no cover - display must never fail on suppression
        pass
    summ = report.get("suppression_summary") or {}
    active_ch = summ.get("active_critical_high")
    risk = html_escape(str(report.get("aggregate_risk") or report.get("overall_risk") or "Info"))
    title = html_escape(str(report.get("title") or "Security Review"))
    methodology = html_escape(str(report.get("methodology_label") or report.get("methodology") or "Security review"))
    summary = html_escape(str(report.get("summary") or "Review complete."))
    categories = report.get("categories") or []
    recommendations = report.get("recommendations") or []

    def _card(c):
        suppressed = bool(c.get("suppressed"))
        sup = c.get("suppression") or {}
        badge = ""
        cls = ""
        if suppressed:
            cls = " class=\"suppressed\""
            badge = ("<div class=\"supbadge\">Risk accepted · {} · by {}</div>".format(
                html_escape(str(sup.get("state", "")).replace("_", " ")),
                html_escape(str(sup.get("author", "")))))
        return ("<article{}><strong>{}</strong><span>{}</span>{}<h3>{}</h3>"
                "<p>{}</p>{}<small>{}</small></article>").format(
            cls,
            html_escape(str(c.get("id") or c.get("category") or "Risk")),
            html_escape(str(c.get("risk") or c.get("severity") or "Info")),
            badge,
            html_escape(_finding_title(c)),
            html_escape(_finding_summary(c)),
            _attack_vector_html(c),
            html_escape(str(c.get("mitigation") or c.get("remediation") or "")),
        )

    category_html = "".join(_card(c) for c in categories[:60])
    supp_note = ""
    if summ.get("suppressed"):
        supp_note = ("<div class=\"meta\">{} finding(s) suppressed (risk accepted / "
                     "false-positive); {} active, {} active Critical+High.</div>").format(
            summ.get("suppressed"), summ.get("active"), active_ch)
    rec_html = "".join(f"<li>{html_escape(str(r))}</li>" for r in recommendations[:30])
    body = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title}</title>
  <style>
    :root {{ color-scheme: dark; --bg:#050b14; --surface:#080f1e; --surface2:#0c1628; --border:#1a2d4a; --text:#e2e8f0; --muted:#7a90b0; --primary:#00c4a7; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; background:var(--bg); color:var(--text); font-family:Segoe UI, Arial, sans-serif; }}
    main {{ max-width:980px; margin:0 auto; padding:24px; }}
    a {{ color:var(--primary); text-decoration:none; }}
    .top {{ display:flex; justify-content:space-between; gap:16px; align-items:center; margin-bottom:20px; }}
    .pill {{ border:1px solid var(--border); background:var(--surface2); border-radius:999px; padding:6px 12px; color:var(--primary); font-size:12px; font-weight:700; }}
    h1 {{ margin:0 0 6px; font-size:24px; line-height:1.2; }}
    .meta {{ color:var(--muted); font-size:13px; margin-bottom:16px; }}
    .summary {{ border:1px solid var(--border); border-left:3px solid var(--primary); background:var(--surface); border-radius:8px; padding:14px; line-height:1.6; margin-bottom:18px; }}
    .grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:10px; }}
    article {{ border:1px solid var(--border); background:var(--surface); border-radius:8px; padding:12px; }}
    article strong {{ display:inline-block; color:var(--primary); margin-right:8px; font-size:12px; }}
    article span {{ color:#f97316; font-size:12px; font-weight:700; }}
    article h3 {{ margin:8px 0 6px; font-size:15px; line-height:1.3; }}
    article p {{ color:var(--text); line-height:1.5; margin:8px 0; font-size:13px; }}
    article small {{ color:var(--muted); line-height:1.5; }}
    .attack {{ margin:10px 0; padding:10px 12px; border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.08); border-radius:8px; }}
    .attack h4 {{ margin:0 0 6px; color:#ef4444; font-size:11px; text-transform:uppercase; letter-spacing:.06em; }}
    .attack p {{ margin:0 0 8px; color:var(--text); }}
    .attack ul {{ margin:0; padding-left:18px; }}
    .attack li {{ margin:5px 0; color:var(--muted); font-size:12px; }}
    ol {{ border:1px solid var(--border); border-radius:8px; background:var(--surface); padding:16px 16px 16px 34px; }}
    li {{ margin:8px 0; line-height:1.5; color:var(--muted); }}
    article.suppressed {{ opacity:.55; border-style:dashed; }}
    .supbadge {{ display:inline-block; margin-left:8px; padding:2px 8px; border-radius:999px; font-size:11px; font-weight:700; color:#a3b3cc; border:1px solid var(--border); background:var(--surface2); }}
  </style>
</head>
<body>
  <main>
    <div class="top"><a href="/">Back to review composer</a><span class="pill">{risk} Risk</span></div>
    <h1>{title}</h1>
    <div class="meta">{methodology} · Report ID {html_escape(report_id)}</div>
    {supp_note}
    <section class="summary">{summary}</section>
    <h2>Findings</h2>
    <section class="grid">{category_html or "<article><p>No findings returned.</p></article>"}</section>
    <h2>Recommendations</h2>
    <ol>{rec_html or "<li>No recommendations returned.</li>"}</ol>
  </main>
</body>
</html>"""
    return Response(body, status=status_code, mimetype="text/html")


@app.route("/review/html", methods=["POST"])
@limiter.limit("10 per minute")
def review_html():
    api_key_supplied = "api_key" in req.form
    api_key = req.form.get("api_key", "").strip()
    title = req.form.get("title", "Security Review").strip() or "Security Review"
    arch = req.form.get("architecture", "").strip()
    methodology = _methodology_from_form()
    gen_diags = req.form.get("generate_diagrams", "false").lower() in ("true", "on", "1", "yes")
    files = _uploaded_files()
    if files:
        try:
            arch = _architecture_from_uploads(arch, files)
        except ValueError as exc:
            return _render_plain_report({"title": title, "overall_risk": "Info", "summary": f"Invalid draw.io file: {exc}"}, "not-saved", 400)

    api_key = _env_api_key_if_omitted(api_key, api_key_supplied)
    if not api_key:
        methodology = _fallback_without_api_key(methodology)
    if not arch:
        return _render_plain_report({"title": title, "overall_risk": "Info", "summary": "Architecture document is empty."}, "not-saved", 400)
    if len(arch) > 60_000:
        return _render_plain_report({"title": title, "overall_risk": "Info", "summary": "Architecture text too large (max 60,000 chars)."}, "not-saved", 400)

    report = analyzer.analyze(
        api_key,
        arch,
        title=title,
        methodology=analyzer.normalize_methodologies(methodology),
        generate_diagrams=gen_diags,
    )
    report_id = _save_report(report, title, arch)
    return _render_plain_report(report, report_id)


# ── Analyze ───────────────────────────────────────────────────────────────────

def _analyze_route_impl():
    """
    Accepts JSON body or multipart form with optional file upload.
    Returns {success, report, id} after analysis completes.
    """
    if req.content_type and "multipart" in req.content_type:
        api_key_supplied = "api_key" in req.form
        api_key    = req.form.get("api_key", "").strip()
        title      = req.form.get("title", "Threat Model").strip()
        arch       = req.form.get("architecture", "").strip()
        methodology = _methodology_from_form()
        gen_diags  = req.form.get("generate_diagrams", "false").lower() == "true"
        github_url = req.form.get("github_url", "").strip()
        github_branch = req.form.get("github_branch", "").strip()
        files      = _uploaded_files()
        if files:
            try:
                arch = _architecture_from_uploads(arch, files)
            except ValueError as e:
                return jsonify({"success": False, "error": f"Invalid draw.io file: {e}"}), 400
    else:
        body       = req.get_json(force=True) or {}
        api_key_supplied = "api_key" in body
        api_key    = body.get("api_key", "").strip()
        title      = body.get("title", "Threat Model").strip()
        arch       = body.get("architecture", "").strip()
        methodology = _methodology_from_json(body)
        gen_diags  = bool(body.get("generate_diagrams", False))
        github_url = str(body.get("github_url", "")).strip()
        github_branch = str(body.get("github_branch", "")).strip()

    github_diagram = None
    if github_url:
        try:
            derived, github_diagram = _github_arch_and_diagram(github_url, github_branch)
        except ValueError as e:
            return jsonify({"success": False, "error": f"GitHub repository: {e}"}), 400
        arch = _merge_github_architecture(arch, derived)

    api_key = _env_api_key_if_omitted(api_key, api_key_supplied)
    if not api_key:
        methodology = _fallback_without_api_key(methodology)

    if not arch:
        return jsonify({"success": False, "error": "Architecture document is empty."}), 400
    if len(arch) > 60_000:
        return jsonify({"success": False, "error": "Architecture text too large (max 60,000 chars)."}), 400

    methodology = analyzer.normalize_methodologies(methodology)

    title = title or "Threat Model"
    log.info("Analysis request: title='%s' methodology='%s' arch_len=%d", title, methodology, len(arch))

    report = analyzer.analyze(api_key, arch, title=title, methodology=methodology, generate_diagrams=gen_diags)
    _attach_codemodel_diagram(report, github_diagram)

    log.info("Analysis complete: title='%s' elapsed_ms=%s", title, report.get("total_elapsed_ms", "?"))

    report_id = _save_report(report, title, arch)

    return jsonify({"success": True, "report": report, "id": report_id})


@app.route("/api/analyze", methods=["POST"])
@limiter.limit("10 per minute")
def analyze_route():
    return _analyze_route_impl()


def _architecture_diagram_route_impl():
    """Generate a standalone Mermaid architecture diagram from user input."""
    if req.content_type and "multipart" in req.content_type:
        api_key_supplied = "api_key" in req.form
        api_key = req.form.get("api_key", "").strip()
        title = req.form.get("title", "Architecture Diagram").strip()
        arch = req.form.get("architecture", "").strip()
        files = _uploaded_files()
        if files:
            try:
                arch = _architecture_from_uploads(arch, files)
            except ValueError as e:
                return jsonify({"success": False, "error": f"Invalid draw.io file: {e}"}), 400
    else:
        body = req.get_json(force=True) or {}
        api_key_supplied = "api_key" in body
        api_key = body.get("api_key", "").strip()
        title = body.get("title", "Architecture Diagram").strip()
        arch = body.get("architecture", "").strip()

    api_key = _env_api_key_if_omitted(api_key, api_key_supplied)
    if not arch:
        return jsonify({"success": False, "error": "Architecture document is empty."}), 400
    if len(arch) > 60_000:
        return jsonify({"success": False, "error": "Architecture text too large (max 60,000 chars)."}), 400

    import diagram_generator
    title = title or "Architecture Diagram"
    diagram = diagram_generator.generate_architecture_diagram(api_key, arch, title)
    return jsonify({
        "success": True,
        "title": title,
        "diagram": diagram,
        "diagrams": {"architecture": diagram},
    })


@app.route("/api/diagram/architecture", methods=["POST"])
@limiter.limit("20 per minute")
def architecture_diagram_route():
    return _architecture_diagram_route_impl()


# ── Streaming analyze (SSE) ───────────────────────────────────────────────────

def _analyze_stream_impl():
    """
    Same inputs as /api/analyze but returns an SSE stream of progress events
    followed by a final 'result' event containing the full JSON report.

    Client usage:
      POST /api/analyze/stream  → get job_id
      GET  /api/analyze/stream/<job_id> → EventSource stream
    """
    if req.content_type and "multipart" in req.content_type:
        api_key_supplied = "api_key" in req.form
        api_key    = req.form.get("api_key", "").strip()
        title      = req.form.get("title", "Threat Model").strip()
        arch       = req.form.get("architecture", "").strip()
        methodology = _methodology_from_form()
        gen_diags  = req.form.get("generate_diagrams", "false").lower() == "true"
        github_url = req.form.get("github_url", "").strip()
        github_branch = req.form.get("github_branch", "").strip()
        files      = _uploaded_files()
        if files:
            try:
                arch = _architecture_from_uploads(arch, files)
            except ValueError as e:
                return jsonify({"success": False, "error": f"Invalid draw.io file: {e}"}), 400
    else:
        body       = req.get_json(force=True) or {}
        api_key_supplied = "api_key" in body
        api_key    = body.get("api_key", "").strip()
        title      = body.get("title", "Threat Model").strip()
        arch       = body.get("architecture", "").strip()
        methodology = _methodology_from_json(body)
        gen_diags  = bool(body.get("generate_diagrams", False))
        github_url = str(body.get("github_url", "")).strip()
        github_branch = str(body.get("github_branch", "")).strip()

    github_diagram = None
    if github_url:
        try:
            derived, github_diagram = _github_arch_and_diagram(github_url, github_branch)
        except ValueError as e:
            return jsonify({"success": False, "error": f"GitHub repository: {e}"}), 400
        arch = _merge_github_architecture(arch, derived)

    api_key = _env_api_key_if_omitted(api_key, api_key_supplied)
    if not api_key:
        methodology = _fallback_without_api_key(methodology)

    if not arch:
        return jsonify({"success": False, "error": "Architecture document is empty."}), 400
    if len(arch) > 60_000:
        return jsonify({"success": False, "error": "Architecture text too large (max 60,000 chars)."}), 400

    methodology = analyzer.normalize_methodologies(methodology)

    title = title or "Threat Model"
    job_id = str(uuid.uuid4())

    with _jobs_lock:
        _jobs[job_id] = {
            "events": [], "done": False, "report": None, "error": None,
            "created_at": time.monotonic(),
        }

    def _run():
        events = []

        def _cb(event: str, data: dict):
            payload = json.dumps({"event": event, **data})
            with _jobs_lock:
                _jobs[job_id]["events"].append(payload)

        try:
            report = analyzer.analyze(
                api_key, arch, title=title,
                methodology=methodology, generate_diagrams=gen_diags,
                progress_cb=_cb,
            )
            _attach_codemodel_diagram(report, github_diagram)
            report_id = _save_report(report, title, arch)
            with _jobs_lock:
                _jobs[job_id]["report"] = report
                _jobs[job_id]["done"] = True
        except Exception as exc:
            log.error("Stream job %s failed: %s", job_id, exc)
            with _jobs_lock:
                _jobs[job_id]["error"] = str(exc)
                _jobs[job_id]["done"] = True

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"success": True, "job_id": job_id})


@app.route("/api/analyze/stream", methods=["POST"])
@limiter.limit("10 per minute")
def analyze_stream():
    return _analyze_stream_impl()


def _analyze_stream_events_impl(job_id: str):
    """SSE endpoint. Client connects here after receiving job_id."""
    if not re.fullmatch(r'[0-9a-f\-]{36}', job_id):
        return jsonify({"error": "Invalid job id"}), 400

    def _generate():
        sent = 0
        while True:
            with _jobs_lock:
                job = _jobs.get(job_id)
            if job is None:
                yield "data: {\"event\":\"error\",\"message\":\"Job not found\"}\n\n"
                return

            events = job["events"]
            while sent < len(events):
                yield f"data: {events[sent]}\n\n"
                sent += 1

            if job["done"]:
                if job["error"]:
                    yield f"data: {json.dumps({'event': 'error', 'message': job['error']})}\n\n"
                else:
                    yield f"data: {json.dumps({'event': 'result', 'report': job['report'], 'id': job['report']['id']})}\n\n"
                with _jobs_lock:
                    _jobs.pop(job_id, None)
                return

            time.sleep(0.25)

    return Response(
        stream_with_context(_generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.route("/api/analyze/stream/<job_id>")
def analyze_stream_events(job_id: str):
    return _analyze_stream_events_impl(job_id)


# ── Reports ───────────────────────────────────────────────────────────────────

def _list_reports_impl():
    rows = report_db.list_reports(limit=50, include_sast=False)
    reports = [{
        "id": r["id"], "title": r["title"], "overall_risk": r["overall_risk"],
        "analyzed_at": r["analyzed_at"], "methodology": r["methodology"],
    } for r in rows]
    return jsonify({"reports": reports})


@app.route("/api/reports")
def list_reports():
    return _list_reports_impl()


def _get_report_impl(report_id: str):
    if not _validate_report_id(report_id):
        return jsonify({"success": False, "error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"success": False, "error": "Report not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"success": False, "error": "Report not found"}), 404
    return jsonify({"success": True, "report": report})


@app.route("/api/reports/<report_id>")
def get_report(report_id: str):
    return _get_report_impl(report_id)


def _delete_report_impl(report_id: str):
    if not _validate_report_id(report_id):
        return jsonify({"success": False, "error": "Invalid report id"}), 400
    existing = report_db.get_report(report_id)
    if existing is None:
        return jsonify({"success": False, "error": "Report not found"}), 404
    if _is_sast_methodology(existing.get("methodology")):
        return jsonify({"success": False, "error": "Report not found"}), 404
    report_db.delete_report(report_id)
    try:
        (REPORTS_DIR / f"{report_id}.json").unlink(missing_ok=True)
    except OSError:
        pass
    return jsonify({"success": True})


@app.route("/api/reports/<report_id>", methods=["DELETE"])
def delete_report(report_id: str):
    return _delete_report_impl(report_id)


# ── Export ────────────────────────────────────────────────────────────────────

def _export_report_impl(report_id: str):
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    html = _build_export_html(report)
    safe_title = re.sub(r"[^a-z0-9_-]+", "_", str(report.get("title") or "report").lower()).strip("_")
    filename = f"tm_{(safe_title or 'report')[:80]}.html"
    return Response(
        html, mimetype="text/html",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.route("/api/export/<report_id>")
def export_report(report_id: str):
    return _export_report_impl(report_id)


def _export_report_sarif_impl(report_id: str):
    """Export a report as SARIF 2.1.0 for GitHub/GitLab code scanning and IDEs.

    ``?verdict=`` restricts the export to categories at that correlator
    verdict (e.g. ``?verdict=confirmed_exploitable`` for a code-scanning gate
    that should only fail CI on proven, not merely modeled, findings);
    ``verdict=`` (empty) selects never-correlated categories, same convention
    as report_db.search_findings. Omitted entirely, every category exports,
    unchanged from before this filter existed.
    """
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    import sarif
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    if "verdict" in req.args:
        wanted = req.args.get("verdict") or ""
        report = dict(report)
        report["categories"] = [c for c in report.get("categories", []) or []
                                if isinstance(c, dict) and (c.get("verdict") or "") == wanted]
    doc = sarif.to_sarif(report)
    safe_title = re.sub(r"[^a-z0-9_-]+", "_", str(report.get("title") or "report").lower()).strip("_")
    filename = f"tm_{(safe_title or 'report')[:80]}.sarif"
    return Response(
        json.dumps(doc, indent=2), mimetype="application/sarif+json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.route("/api/export/<report_id>/sarif")
@app.route("/api/reports/<report_id>/export/sarif")
def export_report_sarif(report_id: str):
    return _export_report_sarif_impl(report_id)


def _canary_verdicts_from_request():
    """``?verdict=`` (repeatable) overrides which verdicts qualify; omitted
    defaults to canary.PROVEN_VERDICTS (actively_exploited/confirmed_exploitable)."""
    import canary
    vals = req.args.getlist("verdict")
    return tuple(vals) if vals else canary.PROVEN_VERDICTS


def _canary_tests_impl(report_id: str):
    """List the verdict-gated, replayable canary cases for a report as JSON
    (no script text -- see _canary_tests_sh_impl for the runnable bundle)."""
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    import canary
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    cases = canary.generate_for_report(report, verdicts=_canary_verdicts_from_request())
    return jsonify({"success": True, "count": len(cases),
                    "cases": [{k: v for k, v in c.items() if k != "script"} for c in cases]})


@app.route("/api/reports/<report_id>/canary-tests")
def canary_tests(report_id: str):
    return _canary_tests_impl(report_id)


def _canary_tests_sh_impl(report_id: str):
    """Download the runnable bash regression script for a report's
    proven-verdict, replayable findings."""
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    import canary
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    cases = canary.generate_for_report(report, verdicts=_canary_verdicts_from_request())
    script = canary.to_bash_script(report, cases)
    safe_title = re.sub(r"[^a-z0-9_-]+", "_", str(report.get("title") or "report").lower()).strip("_")
    filename = f"canary_{(safe_title or 'report')[:80]}.sh"
    return Response(script, mimetype="text/x-shellscript",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.route("/api/reports/<report_id>/canary-tests.sh")
def canary_tests_sh(report_id: str):
    return _canary_tests_sh_impl(report_id)


def _build_export_html(report: dict) -> str:
    import html as _html

    def _esc(s):
        return _html.escape(str(s))

    _SAFE_COLORS = {"Critical", "High", "Medium", "Low", "Info", "Unknown"}
    risk_colors = {
        "Critical": "#ef4444", "High": "#f97316", "Medium": "#eab308",
        "Low": "#4ade80", "Info": "#60a5fa",
    }
    methodology_labels = {k: v for k, v in analyzer.METHODOLOGY_OPTIONS.items()}

    cats = report.get("categories", [])
    cards = ""
    for c in cats:
        risk = c.get("risk", "Info") if c.get("risk") in _SAFE_COLORS else "Info"
        color = risk_colors.get(risk, "#60a5fa")
        threats_html = "".join(
            f"<div class='threat'><b>{_esc(t.get('name',''))}</b>"
            f"<p>{_esc(t.get('description',''))}</p>"
            f"<p><em>Attack vector:</em> {_esc(t.get('attack_vector',''))}</p>"
            f"<p><em>Impact:</em> {_esc(t.get('impact',''))}</p></div>"
            for t in c.get("threats", [])
        )
        mits_html = "".join(
            f"<li><b>[{_esc(m.get('priority',''))}]</b> {_esc(m.get('action',''))}</li>"
            for m in c.get("mitigations", [])
        )
        comps = ", ".join(_esc(x) for x in c.get("affected_components", []))
        cards += f"""<div class="card" style="border-left:4px solid {color}">
  <div class="card-hdr">
    <span class="badge" style="background:{color}22;color:{color};border:1px solid {color}44">{_esc(c.get('id',''))}</span>
    <span class="card-name">{_esc(c.get('name',''))}</span>
    <span class="risk-chip" style="background:{color}22;color:{color};border:1px solid {color}44">{risk} {_esc(c.get('risk_score',''))}/10</span>
  </div>
  {f'<p class="comps">Components: {comps}</p>' if comps else ''}
  {f'<div class="threats-sec"><h4>Threats</h4>{threats_html}</div>' if c.get('threats') else ''}
  {f'<div class="mits-sec"><h4>Mitigations</h4><ul>{mits_html}</ul></div>' if c.get('mitigations') else ''}
  {f'<p class="notes"><em>{_esc(c.get("notes",""))}</em></p>' if c.get("notes") else ''}
</div>"""

    recs = "".join(f"<li>{_esc(r)}</li>" for r in report.get("recommendations", []))
    overall = report.get("overall_risk", "?") if report.get("overall_risk") in _SAFE_COLORS else "Unknown"
    agg = report.get("aggregate_risk", overall)
    if agg not in _SAFE_COLORS:
        agg = overall
    oc = risk_colors.get(agg, "#94a3b8")
    method_raw = report.get("methodology", "")
    method_label = _esc(report.get("methodology_label") or methodology_labels.get(method_raw, method_raw))

    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>TM: {_esc(report.get('title',''))}</title>
<style>
body{{font-family:monospace;background:#09090b;color:#e8e3db;margin:0;padding:24px;font-size:13px}}
h1{{color:#ef4444;margin:0 0 4px}} h2{{color:#94a3b8;font-size:11px;font-weight:400;margin:0 0 16px}}
.overall{{display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:4px;
  background:{oc}22;color:{oc};border:1px solid {oc}44;font-weight:700;margin-bottom:20px}}
.summary{{background:#111;border:1px solid #222;border-radius:6px;padding:14px;margin-bottom:20px;line-height:1.6}}
.card{{background:#111;border-radius:6px;padding:14px;margin-bottom:12px;border:1px solid #1e1e1e}}
.card-hdr{{display:flex;align-items:center;gap:8px;margin-bottom:10px}}
.badge,.risk-chip{{font-size:10px;padding:2px 8px;border-radius:3px;font-weight:700}}
.card-name{{font-weight:700;flex:1}}
.comps{{color:#94a3b8;font-size:11px;margin:0 0 10px}}
.threat{{background:#0d0d10;border-radius:4px;padding:10px;margin-bottom:8px}}
.threat b{{color:#e8e3db}} .threat p{{color:#94a3b8;margin:4px 0;font-size:12px}}
h4{{color:#94a3b8;font-size:10px;text-transform:uppercase;letter-spacing:.08em;margin:10px 0 6px}}
ul{{margin:0;padding-left:18px;color:#94a3b8;font-size:12px}} li{{margin-bottom:4px}}
.notes{{color:#64748b;font-size:11px;margin:6px 0 0}}
.recs{{background:#0d1117;border:1px solid #22c55e33;border-radius:6px;padding:14px;margin-top:20px}}
.recs h3{{color:#22c55e;margin:0 0 10px;font-size:12px}}
footer{{color:#334155;font-size:10px;margin-top:24px}}
</style></head><body>
<h1>Yaksha Guard: {_esc(report.get('title','Threat Model'))}</h1>
<h2>{method_label} — Generated {_esc(report.get('analyzed_at',''))}</h2>
<div class="overall">Overall Risk: {_esc(agg)}</div>
<div class="summary">{_esc(report.get('summary',''))}</div>
<h3 style="color:#94a3b8;font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin:0 0 12px">Analysis</h3>
{cards}
<div class="recs"><h3>Top Recommendations</h3>
<ol style="margin:0;padding-left:18px;color:#94a3b8;font-size:12px">{recs}</ol></div>
<footer>Generated by Yaksha Guard — Agentic Security Architect</footer>
</body></html>"""


# ── MITRE ATT&CK enrichment ───────────────────────────────────────────────────

def _enrich_attack_impl(report_id: str):
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    categories = report.get("categories", [])
    mitre_attack.enrich_categories(categories)
    report["categories"] = categories
    report["attack_enriched"] = True
    report_db.upsert_report(report)
    try:
        report_store.atomic_write_json(REPORTS_DIR / f"{report_id}.json", report)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("JSON backup write failed for %s: %s", report_id, exc)
    return jsonify({"success": True, "attack_techniques_added": sum(len(c.get("attack_techniques", [])) for c in categories)})


@app.route("/api/reports/<report_id>/enrich/attack")
def enrich_attack(report_id: str):
    return _enrich_attack_impl(report_id)


# ── Compliance mapping ────────────────────────────────────────────────────────

def _enrich_compliance_impl(report_id: str):
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    categories = report.get("categories", [])
    compliance_mappings.enrich_categories(categories)
    report["categories"] = categories
    report["compliance_enriched"] = True
    gap_summary = compliance_mappings.compliance_summary(categories)
    weighted_summary = compliance_mappings.weighted_compliance_summary(categories)
    report["compliance_gap_summary"] = gap_summary
    report["compliance_gap_weighted"] = weighted_summary
    report_db.upsert_report(report)
    try:
        report_store.atomic_write_json(REPORTS_DIR / f"{report_id}.json", report)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("JSON backup write failed for %s: %s", report_id, exc)
    return jsonify({"success": True, "compliance_gap_summary": gap_summary,
                    "compliance_gap_weighted": weighted_summary})


@app.route("/api/reports/<report_id>/enrich/compliance")
def enrich_compliance(report_id: str):
    return _enrich_compliance_impl(report_id)


def _list_compliance_frameworks_impl():
    return jsonify({"frameworks": ["PCI DSS 4.0", "HIPAA", "GDPR", "SOC 2", "NIST 800-53", "NIST AI RMF", "EU AI Act"]})


@app.route("/api/compliance/frameworks")
def list_compliance_frameworks():
    return _list_compliance_frameworks_impl()


# ── SBOM analysis ─────────────────────────────────────────────────────────────

def _analyze_sbom_impl():
    """
    Accept a CycloneDX or SPDX SBOM file upload and return vulnerability findings.
    Supports JSON/XML for CycloneDX and JSON/text for SPDX.
    """
    file = req.files.get("file")
    if not file:
        # Try raw body
        content = req.get_data(as_text=True)
        filename = req.args.get("filename", "sbom.json")
    else:
        content = file.read().decode("utf-8", errors="replace")
        filename = file.filename or "sbom.json"

    if not content or not content.strip():
        return jsonify({"success": False, "error": "No SBOM content provided"}), 400
    if len(content) > 5_000_000:
        return jsonify({"success": False, "error": "SBOM file too large (max 5MB)"}), 400

    try:
        report = sbom_parser.parse_sbom(content, filename)
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400

    categories = sbom_parser.sbom_to_categories(report)
    result = {
        "success":           True,
        "format":            report.format,
        "tool":              report.tool,
        "component_count":   len(report.components),
        "vuln_count":        len(report.vulnerabilities),
        "unpinned_count":    len(report.unpinned_components),
        "unpinned":          report.unpinned_components[:20],
        "overall_risk":      report.overall_risk,
        "summary":           report.summary,
        "vulnerabilities":   [
            {
                "component":      v.component,
                "version":        v.version,
                "vuln_id":        v.vuln_id,
                "cve":            v.cve,
                "severity":       v.severity,
                "description":    v.description,
                "recommendation": v.recommendation,
            }
            for v in report.vulnerabilities
        ],
        "categories": categories,
    }

    report_id = f"sbom_{int(time.time())}_{secrets.token_hex(4)}"
    full_report = {
        "id":          report_id,
        "title":       f"SBOM Analysis — {filename}",
        "methodology": "SBOM",
        "analyzed_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        **result,
    }
    _scrub_secrets(full_report)
    report_db.upsert_report(full_report)
    _prune_reports_to_limit()
    try:
        report_store.atomic_write_json(REPORTS_DIR / f"{report_id}.json", full_report)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("JSON backup write failed for %s: %s", report_id, exc)
    result["id"] = report_id
    return jsonify(result)


@app.route("/api/sbom", methods=["POST"])
@limiter.limit("20 per minute")
def analyze_sbom():
    return _analyze_sbom_impl()


# ── Jira / Azure DevOps ticket creation ──────────────────────────────────────

def _create_tickets_impl(report_id: str):
    """
    Create Jira, Azure DevOps, or Linear tickets for findings in a report.

    Body JSON:
      provider:       "jira" | "azure" | "linear"
      min_severity:   "Critical" | "High" | "Medium" | "Low"  (default: "High")
      min_verdict:    "confirmed_exploitable" | "corroborated" | "design_gap" |
                       "blind_spot"  (default: none — verdict is ignored unless set;
                       only correlation reports carry a verdict per finding, so
                       plain SAST/manual reports always ticket by severity alone)
      dry_run:        true | false
      --- Jira ---
      jira_url, jira_email, jira_token, jira_project, jira_component
      --- Azure ---
      azure_org, azure_project, azure_token, azure_area_path
      --- Linear ---
      linear_api_key, linear_team_id
    """
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Report not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Report not found"}), 404

    body = req.get_json(force=True) or {}
    provider = body.get("provider", "").lower()
    if provider not in ("jira", "azure", "linear"):
        return jsonify({"error": "provider must be 'jira', 'azure', or 'linear'"}), 400

    min_sev  = body.get("min_severity", "High")
    min_verdict = body.get("min_verdict") or None
    dry_run  = bool(body.get("dry_run", False))

    if provider == "jira":
        cfg = jira_client.TicketConfig(
            provider="jira",
            jira_url=body.get("jira_url", settings_db.resolve_str(
                "jira.url", os.environ.get("JIRA_URL"), "")),
            jira_email=body.get("jira_email", settings_db.resolve_str(
                "jira.email", os.environ.get("JIRA_EMAIL"), "")),
            jira_token=body.get("jira_token", settings_db.resolve_str(
                "jira.token", os.environ.get("JIRA_TOKEN"), "")),
            jira_project_key=body.get("jira_project", settings_db.resolve_str(
                "jira.project", os.environ.get("JIRA_PROJECT"), "")),
            jira_component=body.get("jira_component", settings_db.resolve_str(
                "jira.component", os.environ.get("JIRA_COMPONENT"), "")),
        )
        if not dry_run and not all([cfg.jira_url, cfg.jira_email, cfg.jira_token, cfg.jira_project_key]):
            return jsonify({"error": "Missing Jira credentials (jira_url, jira_email, jira_token, jira_project)"}), 400
    elif provider == "azure":
        cfg = jira_client.TicketConfig(
            provider="azure",
            azure_org=body.get("azure_org", settings_db.resolve_str(
                "azure.org", os.environ.get("AZURE_ORG"), "")),
            azure_project=body.get("azure_project", settings_db.resolve_str(
                "azure.project", os.environ.get("AZURE_PROJECT"), "")),
            azure_token=body.get("azure_token", settings_db.resolve_str(
                "azure.pat", os.environ.get("AZURE_PAT"), "")),
            azure_area_path=body.get("azure_area_path", settings_db.resolve_str(
                "azure.area_path", os.environ.get("AZURE_AREA_PATH"), "")),
        )
        if not dry_run and not all([cfg.azure_org, cfg.azure_project, cfg.azure_token]):
            return jsonify({"error": "Missing Azure credentials (azure_org, azure_project, azure_token)"}), 400
    else:
        cfg = jira_client.TicketConfig(
            provider="linear",
            linear_api_key=body.get("linear_api_key", settings_db.resolve_str(
                "linear.api_key", os.environ.get("LINEAR_API_KEY"), "")),
            linear_team_id=body.get("linear_team_id", settings_db.resolve_str(
                "linear.team_id", os.environ.get("LINEAR_TEAM_ID"), "")),
        )
        if not dry_run and not all([cfg.linear_api_key, cfg.linear_team_id]):
            return jsonify({"error": "Missing Linear credentials (linear_api_key, linear_team_id)"}), 400

    tickets = jira_client.create_tickets_from_report(
        report, cfg, min_severity=min_sev, min_verdict=min_verdict, dry_run=dry_run)

    return jsonify({
        "success":      True,
        "dry_run":      dry_run,
        "provider":     provider,
        "tickets_created": len([t for t in tickets if t.status not in ("error",)]),
        "tickets_failed":  len([t for t in tickets if t.status == "error"]),
        "tickets": [
            {
                "id":       t.ticket_id,
                "url":      t.url,
                "title":    t.title,
                "severity": t.severity,
                "status":   t.status,
                "error":    t.error,
            }
            for t in tickets
        ],
    })


@app.route("/api/reports/<report_id>/tickets", methods=["POST"])
@limiter.limit("10 per minute")
def create_tickets(report_id: str):
    return _create_tickets_impl(report_id)


def _publish_confluence_page_impl(report_id: str):
    """
    Publish one Confluence page summarizing every finding in a report.

    Confluence is a wiki, not an issue tracker: unlike /tickets this is not
    severity-filtered and always produces exactly one page per call (no
    update-existing-page diffing in v1).

    Body JSON: confluence_base_url, confluence_email, confluence_api_token,
    confluence_space_key, dry_run
    """
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Report not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Report not found"}), 404

    body = req.get_json(force=True) or {}
    dry_run = bool(body.get("dry_run", False))

    cfg = jira_client.TicketConfig(
        provider="confluence",
        confluence_base_url=body.get("confluence_base_url", settings_db.resolve_str(
            "confluence.base_url", os.environ.get("CONFLUENCE_BASE_URL"), "")),
        confluence_email=body.get("confluence_email", settings_db.resolve_str(
            "confluence.email", os.environ.get("CONFLUENCE_EMAIL"), "")),
        confluence_api_token=body.get("confluence_api_token", settings_db.resolve_str(
            "confluence.api_token", os.environ.get("CONFLUENCE_API_TOKEN"), "")),
        confluence_space_key=body.get("confluence_space_key", settings_db.resolve_str(
            "confluence.space_key", os.environ.get("CONFLUENCE_SPACE_KEY"), "")),
    )
    if not dry_run and not all([cfg.confluence_base_url, cfg.confluence_email,
                                cfg.confluence_api_token, cfg.confluence_space_key]):
        return jsonify({"error": "Missing Confluence credentials (confluence_base_url, "
                                 "confluence_email, confluence_api_token, confluence_space_key)"}), 400

    if dry_run:
        return jsonify({"success": True, "dry_run": True, "provider": "confluence"})

    try:
        page = jira_client.publish_report_page(report, cfg)
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 502

    return jsonify({
        "success":  True,
        "dry_run":  False,
        "provider": "confluence",
        "page": {"id": page.ticket_id, "url": page.url, "title": page.title},
    })


@app.route("/api/reports/<report_id>/confluence-page", methods=["POST"])
@limiter.limit("10 per minute")
def publish_confluence_page(report_id: str):
    return _publish_confluence_page_impl(report_id)


# ── ATT&CK + compliance quick lookup ─────────────────────────────────────────

# ── Control Register ─────────────────────────────────────────────────────────

def _get_control_register_impl(report_id: str):
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    # Ensure enrichment before generating register
    mitre_attack.enrich_categories(report.get("categories", []))
    compliance_mappings.enrich_categories(report.get("categories", []))
    controls = control_register.generate_control_register(report)
    fmt = req.args.get("format", "json")
    if fmt == "csv":
        csv_data = control_register.to_csv(controls)
        filename = f"control_register_{report_id}.csv"
        return Response(csv_data, mimetype="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'})
    if fmt == "html":
        html = control_register.to_html(controls, report.get("title", "Threat Model"))
        return Response(html, mimetype="text/html")
    return jsonify({
        "success": True,
        "control_count": len(controls),
        "controls": controls,
        "sabsa_view": control_register.sabsa_view(controls),
    })


@app.route("/api/reports/<report_id>/control-register")
def get_control_register(report_id: str):
    return _get_control_register_impl(report_id)


def _export_control_register_impl(report_id: str):
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    mitre_attack.enrich_categories(report.get("categories", []))
    compliance_mappings.enrich_categories(report.get("categories", []))
    controls = control_register.generate_control_register(report)
    fmt = req.args.get("format", "html")
    if fmt == "csv":
        csv_data = control_register.to_csv(controls)
        return Response(csv_data, mimetype="text/csv",
            headers={"Content-Disposition": f'attachment; filename="control_register_{report_id}.csv"'})
    html = control_register.to_html(controls, report.get("title", "Threat Model"))
    return Response(html, mimetype="text/html",
        headers={"Content-Disposition": f'attachment; filename="control_register_{report_id}.html"'})


@app.route("/api/reports/<report_id>/control-register/export")
def export_control_register(report_id: str):
    return _export_control_register_impl(report_id)


# ── PQC Assessment ────────────────────────────────────────────────────────────

def _assess_pqc_impl():
    """
    Run post-quantum cryptography assessment on architecture text.
    Body: {"architecture": "...text..."} or multipart file upload.
    """
    if req.content_type and "multipart" in req.content_type:
        arch = req.form.get("architecture", "")
        files = _uploaded_files()
        if files:
            arch = _architecture_from_uploads(arch, files)
    else:
        body = req.get_json(force=True) or {}
        arch = body.get("architecture", "").strip()

    if not arch:
        return jsonify({"error": "No architecture text provided"}), 400

    result = pqc_assessment.assess_text(arch)
    return jsonify({"success": True, **result})


@app.route("/api/pqc", methods=["POST"])
@limiter.limit("30 per minute")
def assess_pqc():
    return _assess_pqc_impl()


def _report_pqc_impl(report_id: str):
    if not _validate_report_id(report_id):
        return jsonify({"error": "Invalid report id"}), 400
    report = report_db.get_report(report_id)
    if report is None:
        return jsonify({"error": "Not found"}), 404
    if _is_sast_methodology(report.get("methodology")):
        return jsonify({"error": "Not found"}), 404
    # Use the original architecture text if stored, otherwise use category names as proxy
    arch_text = report.get("architecture_text", " ".join(
        c.get("name", "") for c in report.get("categories", [])
    ))
    result = pqc_assessment.assess_text(arch_text)
    report["pqc_assessment"] = result
    report_db.upsert_report(report)
    try:
        report_store.atomic_write_json(REPORTS_DIR / f"{report_id}.json", report)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("JSON backup write failed for %s: %s", report_id, exc)
    return jsonify({"success": True, "report_id": report_id, **result})


@app.route("/api/reports/<report_id>/pqc")
def report_pqc(report_id: str):
    return _report_pqc_impl(report_id)


def _lookup_attack_impl(category: str):
    ruleset = req.args.get("ruleset", "")
    techniques = mitre_attack.get_techniques(category.upper(), ruleset)
    return jsonify({"category": category.upper(), "techniques": techniques})


@app.route("/api/lookup/attack/<category>")
def lookup_attack(category: str):
    return _lookup_attack_impl(category)


def _lookup_compliance_impl(category: str):
    ruleset = req.args.get("ruleset", "")
    controls = compliance_mappings.get_controls(category.upper(), ruleset)
    return jsonify({"category": category.upper(), "controls": controls})


@app.route("/api/lookup/compliance/<category>")
def lookup_compliance(category: str):
    return _lookup_compliance_impl(category)


from api import register_api_blueprints

register_api_blueprints(app)


if __name__ == "__main__":
    port = int(os.environ.get("TM_PORT", 5001))
    print(f"\n  Yaksha Guard — Agentic Security Architect")
    print(f"  Open: http://localhost:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=False)
