"""Ticket creation API routes."""
from __future__ import annotations

from flask import Blueprint

import app as tm_app


bp = Blueprint("tickets_api", __name__, url_prefix="/api/v1/reports")


@bp.post("/<report_id>/tickets")
@tm_app.limiter.limit("10 per minute")
def create_tickets(report_id: str):
    """Create Jira, Azure DevOps, or Linear tickets for report findings."""
    return tm_app._create_tickets_impl(report_id)


@bp.post("/<report_id>/confluence-page")
@tm_app.limiter.limit("10 per minute")
def publish_confluence_page(report_id: str):
    """Publish a Confluence page summarizing report findings."""
    return tm_app._publish_confluence_page_impl(report_id)
