"""Tests for ssvc.py — the SSVC-inspired decision-point derivation and action.

Run:  python -m unittest test_ssvc   (stdlib only, no pytest needed)
"""
from __future__ import annotations

import unittest

import ssvc


class DecisionPointTests(unittest.TestCase):
    def test_exploitation_active_from_verdict(self):
        self.assertEqual(ssvc._exploitation("actively_exploited", 0.0), "active")

    def test_exploitation_active_from_high_epss_kev(self):
        # A CISA KEV hit floors epss_kev at 0.9 (see engine._epss_kev) --
        # that alone must read as "active" even with a non-active verdict.
        self.assertEqual(ssvc._exploitation("blind_spot", 0.9), "active")

    def test_exploitation_poc_from_verdict(self):
        self.assertEqual(ssvc._exploitation("confirmed_exploitable", 0.0), "poc")

    def test_exploitation_poc_from_moderate_epss(self):
        self.assertEqual(ssvc._exploitation("blind_spot", 0.4), "poc")

    def test_exploitation_none_when_nothing_present(self):
        self.assertEqual(ssvc._exploitation("design_gap", 0.0), "none")
        self.assertEqual(ssvc._exploitation("corroborated", 0.1), "none")

    def test_exposure_open_when_reachability_high(self):
        self.assertEqual(ssvc._exposure(0.65), "open")
        self.assertEqual(ssvc._exposure(0.9), "open")

    def test_exposure_controlled_when_some_evidence(self):
        self.assertEqual(ssvc._exposure(0.35), "controlled")

    def test_exposure_defaults_controlled_not_small_when_unknown(self):
        # Absence of code-model coverage is "unknown", not "proven small" --
        # see module docstring's "unknown, not fabricated" rule.
        self.assertEqual(ssvc._exposure(0.0), "controlled")

    def test_automatable_true_at_near_max_exploitability(self):
        self.assertTrue(ssvc._automatable(0.9, ""))

    def test_automatable_false_below_threshold_and_no_ransomware(self):
        self.assertFalse(ssvc._automatable(0.5, "EPSS 10% predicted probability."))

    def test_automatable_true_from_known_ransomware_use(self):
        self.assertTrue(ssvc._automatable(
            0.0, "CVE-2021-44228; listed in CISA's Known Exploited Vulnerabilities "
                "catalog since 2021-12-10 (known ransomware use)."))

    def test_human_impact_very_high(self):
        self.assertEqual(ssvc._human_impact("Critical", 0.8), "very_high")

    def test_human_impact_high_critical_alone(self):
        self.assertEqual(ssvc._human_impact("Critical", 0.0), "high")

    def test_human_impact_high_from_high_severity_plus_impact(self):
        self.assertEqual(ssvc._human_impact("High", 0.5), "high")

    def test_human_impact_medium_from_high_severity_alone(self):
        self.assertEqual(ssvc._human_impact("High", 0.0), "medium")

    def test_human_impact_medium_from_business_impact_alone(self):
        self.assertEqual(ssvc._human_impact("Low", 0.5), "medium")

    def test_human_impact_low_default(self):
        self.assertEqual(ssvc._human_impact("Info", 0.0), "low")
        self.assertEqual(ssvc._human_impact("Low", 0.0), "low")


class ActionTableTests(unittest.TestCase):
    def test_active_high_impact_is_act(self):
        self.assertEqual(ssvc._action("active", "controlled", False, "high"), ssvc.ACT)

    def test_active_automatable_is_act_even_at_low_impact(self):
        self.assertEqual(ssvc._action("active", "controlled", True, "low"), ssvc.ACT)

    def test_active_open_exposure_is_act(self):
        self.assertEqual(ssvc._action("active", "open", False, "low"), ssvc.ACT)

    def test_active_low_impact_controlled_not_automatable_is_attend(self):
        self.assertEqual(ssvc._action("active", "controlled", False, "low"), ssvc.ATTEND)

    def test_poc_automatable_open_is_act(self):
        self.assertEqual(ssvc._action("poc", "open", True, "low"), ssvc.ACT)

    def test_poc_high_impact_is_attend(self):
        self.assertEqual(ssvc._action("poc", "controlled", False, "high"), ssvc.ATTEND)

    def test_poc_open_exposure_is_attend(self):
        self.assertEqual(ssvc._action("poc", "open", False, "low"), ssvc.ATTEND)

    def test_poc_medium_impact_is_track_star(self):
        self.assertEqual(ssvc._action("poc", "small", False, "medium"), ssvc.TRACK_STAR)

    def test_poc_controlled_low_impact_is_track_star(self):
        self.assertEqual(ssvc._action("poc", "controlled", False, "low"), ssvc.TRACK_STAR)

    def test_poc_small_low_impact_is_track(self):
        self.assertEqual(ssvc._action("poc", "small", False, "low"), ssvc.TRACK)

    def test_none_high_impact_is_track_star(self):
        self.assertEqual(ssvc._action("none", "small", False, "high"), ssvc.TRACK_STAR)

    def test_none_very_high_impact_open_is_attend(self):
        self.assertEqual(ssvc._action("none", "open", False, "very_high"), ssvc.ATTEND)

    def test_none_low_impact_is_track(self):
        self.assertEqual(ssvc._action("none", "small", False, "low"), ssvc.TRACK)

    def test_action_ordering_matches_urgency(self):
        # ACT must always rank most urgent, TRACK least, for a triage sort.
        self.assertLess(ssvc.ACTION_RANK[ssvc.ACT], ssvc.ACTION_RANK[ssvc.ATTEND])
        self.assertLess(ssvc.ACTION_RANK[ssvc.ATTEND], ssvc.ACTION_RANK[ssvc.TRACK_STAR])
        self.assertLess(ssvc.ACTION_RANK[ssvc.TRACK_STAR], ssvc.ACTION_RANK[ssvc.TRACK])


class DecideEndToEndTests(unittest.TestCase):
    def test_actively_exploited_critical_finding_is_act(self):
        result = ssvc.decide(severity="Critical", verdict="actively_exploited",
                             exploitability=0.9, business_impact=0.8,
                             epss_kev=0.0, epss_kev_reason="")
        self.assertEqual(result.action, ssvc.ACT)
        self.assertEqual(result.exploitation, "active")
        self.assertEqual(result.exposure, "open")
        self.assertEqual(result.human_impact, "very_high")
        self.assertIn("Remediate immediately", result.reason)

    def test_never_correlated_low_severity_finding_is_track(self):
        result = ssvc.decide(severity="Low", verdict="", exploitability=0.0,
                             business_impact=0.0, epss_kev=0.0, epss_kev_reason="")
        self.assertEqual(result.action, ssvc.TRACK)

    def test_kev_listed_dependency_overrides_low_verdict(self):
        # A blind-spot SBOM finding (no code/design corroboration at all) whose
        # CVE is CISA KEV-listed must still surface as urgent -- the whole
        # point of folding real-world intel into triage, not just priority.
        result = ssvc.decide(
            severity="High", verdict="blind_spot", exploitability=0.0,
            business_impact=0.0, epss_kev=0.9,
            epss_kev_reason="CVE-2021-44228; listed in CISA's Known Exploited "
                            "Vulnerabilities catalog since 2021-12-10 (known ransomware use).")
        self.assertEqual(result.exploitation, "active")
        self.assertTrue(result.automatable)
        self.assertIn(result.action, (ssvc.ACT, ssvc.ATTEND))

    def test_action_label_and_rank_consistent(self):
        result = ssvc.decide(severity="Info", verdict="", exploitability=0.0,
                             business_impact=0.0, epss_kev=0.0, epss_kev_reason="")
        self.assertEqual(result.action_label, "Track")
        self.assertEqual(ssvc.ACTION_RANK[result.action], 3)

    def test_reason_mentions_impact_and_exposure(self):
        result = ssvc.decide(severity="Medium", verdict="corroborated",
                             exploitability=0.4, business_impact=0.2,
                             epss_kev=0.0, epss_kev_reason="")
        self.assertIn("impact", result.reason.lower())
        self.assertIn("proof-of-concept", result.reason.lower())


if __name__ == "__main__":
    unittest.main()
