"""Shared explicit-insecurity-phrase list used to escalate review findings.

Single source of truth for the "risk signal" phrase list previously
duplicated (and drifting) across offline_patterns.py, engine.py, and
offline_rules.py. Each phrase is a plain-English signal that architecture
or design-review text explicitly states an insecure condition, used to
escalate a triggered rule's severity or confidence.
"""
from __future__ import annotations

RISK_SIGNALS: list[str] = [
    # Authentication
    "no authentication", "no auth", "unauthenticated",
    "authentication disabled", "authentication not required",
    # Authorization
    "no authorization", "no access control", "authorization disabled",
    # Cryptography / transport
    "plaintext", "plain text", "cleartext", "unencrypted", "no encryption",
    "in the clear", "no tls", "no ssl", "no https", "insecure connection", "http://",
    # Debug
    "debug=true", "debug = true", "debug mode", "debug enabled",
    # Credentials
    "default password", "admin:admin", "password123", "default credentials",
    "hardcoded", "hard-coded", "secret in code",
    # Logging / audit
    "no logging", "logs disabled", "logging disabled", "no audit trail",
    "no audit", "no monitoring",
    # Rate limiting
    "no rate limit", "no rate limiting", "no throttling", "no throttle",
    "rate limiting disabled", "unlimited requests",
    # MFA
    "no mfa", "mfa disabled", "mfa not required",
    # Input validation
    "no validation", "no sanitization", "unsanitized",
    # Network exposure / CORS
    "allow all origins", "cors: *", "access-control-allow-origin: *",
    "publicly accessible", "open to internet", "exposed publicly",
    "no firewall", "0.0.0.0/0",
    # AI / agentic tool and model controls
    "no tool allowlist", "no allowlist for tools", "any tool can be invoked",
    "unrestricted tool access", "no permission scoping", "no argument validation",
    "no argument schema", "no human approval", "auto-approved", "auto-approve",
    "automatically approved", "without human review", "no human review",
    "no confidence threshold",
    "no output validation", "unsandboxed", "no sandboxing", "no code sandbox",
    "no provenance tracking", "no provenance", "no session isolation",
    "no context isolation", "no tenant isolation", "shared across tenants",
    "shared across sessions", "no data minimization", "no pii redaction",
    "no redaction", "no anomaly detection", "no query monitoring",
    "no output schema", "no recursion limit", "unbounded recursion",
    "no step limit", "no approval workflow", "no rollback",
    "no token limit", "unlimited tokens", "no model access controls",
    "accepts alg none", "algorithm not pinned", "tool definition changed after approval",
    "introspection enabled in production", "graphql playground enabled in production",
    # Supply chain / build integrity
    "no signature verification", "unsigned artifacts", "no code review",
    "no branch protection", "force push to main", "no dependency scanning",
    "no vulnerability scanning", "no container scanning", "no image scanning",
    # Privilege / runtime hardening
    "runs as root", "run as root", "privileged container", "privileged mode",
    "no network policy", "no segmentation", "flat network",
    "certificate validation disabled", "accepts any certificate",
    "no certificate validation", "no revocation check", "wildcard permission",
    "cluster-admin", "no rbac", "no least privilege", "standing access",
    "wildcard permissions",
    "permanent admin", "no session timeout", "no account lockout",
    # Resilience / recovery
    "no backup", "untested backup", "no disaster recovery", "no rollback plan",
    "no patch management", "unpatched", "end of life software",
]
