"""Tests for regression.py -- persisted canary/regression cases + re-runs.

Isolates onto a temp DB, same pattern as test_verdict_tracking.py. Covers
sync-from-report (identity, history preservation on re-sync), in-process
re-run against a fake fetcher (pass/fail/skip/error), the pass->fail
regression-alert rule, bulk run-all, and the API blueprint wiring.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import canary
import regression
import report_db
from dast.engine import Resp


def _threat(url, param="", evidence="reflected payload <script>x</script>"):
    name = url + (f" [{param}]" if param else "")
    return {"name": name, "description": evidence}


def _cat(cid, title, family="xss", verdict=None, threats=None):
    cat = {"id": cid, "name": title, "title": title, "risk": "High", "family": family,
           "threats": threats or []}
    if verdict:
        cat["verdict"] = verdict
    return cat


def _report(rid, categories, title="R"):
    return {"id": rid, "title": title, "categories": categories}


class _FakeFetcher:
    """Duck-types dast.engine.Fetcher's .get(url) -> Resp, without any network I/O."""

    def __init__(self, by_url: dict[str, Resp]):
        self._by_url = by_url
        self.calls: list[str] = []

    def get(self, url, extra_headers=None):
        self.calls.append(url)
        return self._by_url[url]


class RegressionStoreTests(unittest.TestCase):
    def setUp(self):
        self._orig = regression.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        regression.DB_PATH = Path(self._td.name) / "regression.db"
        regression.init()

    def _restore(self):
        regression.DB_PATH = self._orig

    def test_sync_only_persists_proven_verdict_findings(self):
        report = _report("r1", [
            _cat("A", "Active", verdict="actively_exploited", threats=[_threat("https://x.test/a")]),
            _cat("B", "Gap", verdict="design_gap", threats=[_threat("https://x.test/b")]),
            _cat("C", "Unverdicted", threats=[_threat("https://x.test/c")]),
        ])
        synced = regression.sync_from_report(report)
        self.assertEqual(len(synced), 1)
        self.assertEqual(synced[0]["rule_id"], "A")
        self.assertEqual(len(regression.list_cases()), 1)

    def test_sast_finding_with_no_url_is_skipped(self):
        report = _report("r1", [
            _cat("SAST-1", "SQLi", verdict="confirmed_exploitable",
                threats=[{"name": "db.py:10", "description": "raw query"}]),
        ])
        self.assertEqual(regression.sync_from_report(report), [])

    def test_multiple_params_produce_distinct_cases_same_fingerprint(self):
        report = _report("r1", [
            _cat("A", "XSS", verdict="actively_exploited",
                threats=[_threat("https://x.test/a", "q1"), _threat("https://x.test/a", "q2")]),
        ])
        synced = regression.sync_from_report(report)
        self.assertEqual(len(synced), 2)
        self.assertEqual(len({c["case_id"] for c in synced}), 2)
        self.assertEqual(len({c["fingerprint"] for c in synced}), 1)

    def test_resync_preserves_created_at_and_run_history(self):
        report = _report("r1", [
            _cat("A", "Active", verdict="actively_exploited", threats=[_threat("https://x.test/a")]),
        ])
        first = regression.sync_from_report(report, now=1000.0)[0]
        case_id = first["case_id"]
        resp = Resp("https://x.test/a", 200, {}, None, "clean")
        regression.run_case(case_id, fetcher=_FakeFetcher({"https://x.test/a": resp}), now=1500.0)

        again = regression.sync_from_report(_report("r2", [
            _cat("A", "Active", verdict="actively_exploited", threats=[_threat("https://x.test/a")]),
        ]), now=2000.0)[0]
        self.assertEqual(again["case_id"], case_id)
        self.assertEqual(again["created_at"], 1000.0)
        self.assertEqual(again["last_status"], "pass")
        self.assertEqual(again["last_run_at"], 1500.0)
        self.assertEqual(again["report_id"], "r2")   # descriptive fields still refresh

    def test_never_run_case_has_default_status(self):
        report = _report("r1", [
            _cat("A", "Active", verdict="actively_exploited", threats=[_threat("https://x.test/a")]),
        ])
        case = regression.sync_from_report(report)[0]
        self.assertEqual(case["last_status"], "never_run")
        self.assertIsNone(case["last_run_at"])


class RegressionRunTests(unittest.TestCase):
    def setUp(self):
        self._orig = regression.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        regression.DB_PATH = Path(self._td.name) / "regression.db"
        regression.init()
        report = _report("r1", [
            _cat("DAST-XSS-REFLECTED", "XSS", verdict="actively_exploited",
                threats=[_threat("https://x.test/search", "q", evidence="<script>alert(1)</script>")]),
        ])
        self.case_id = regression.sync_from_report(report)[0]["case_id"]

    def _restore(self):
        regression.DB_PATH = self._orig

    def test_run_unknown_case_raises_keyerror(self):
        with self.assertRaises(KeyError):
            regression.run_case("doesnotexist")

    def test_evidence_still_present_records_fail(self):
        resp = Resp("https://x.test/search", 200, {}, None, "...<script>alert(1)</script>...")
        result = regression.run_case(
            self.case_id, fetcher=_FakeFetcher({"https://x.test/search": resp}))
        self.assertEqual(result["status"], "fail")
        self.assertFalse(result["regressed"])   # never_run -> fail is not a regression
        self.assertEqual(regression.get_case(self.case_id)["last_status"], "fail")

    def test_evidence_gone_records_pass(self):
        resp = Resp("https://x.test/search", 200, {}, None, "clean page")
        result = regression.run_case(
            self.case_id, fetcher=_FakeFetcher({"https://x.test/search": resp}))
        self.assertEqual(result["status"], "pass")

    def test_network_error_records_error_status(self):
        resp = Resp("https://x.test/search", 0, {}, None, "", error="timed out")
        result = regression.run_case(
            self.case_id, fetcher=_FakeFetcher({"https://x.test/search": resp}))
        self.assertEqual(result["status"], "error")
        self.assertIn("timed out", result["detail"])

    def test_pass_then_fail_is_a_regression(self):
        clean = Resp("https://x.test/search", 200, {}, None, "clean page")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": clean}))
        dirty = Resp("https://x.test/search", 200, {}, None, "...<script>alert(1)</script>...")
        result = regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": dirty}))
        self.assertTrue(result["regressed"])
        alerts = regression.list_alerts()
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0]["case_id"], self.case_id)

    def test_fail_then_fail_is_not_a_regression(self):
        dirty = Resp("https://x.test/search", 200, {}, None, "...<script>alert(1)</script>...")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": dirty}))
        result = regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": dirty}))
        self.assertFalse(result["regressed"])
        self.assertEqual(regression.list_alerts(), [])

    def test_run_all_replays_every_case(self):
        report2 = _report("r2", [
            _cat("DAST-HDR-HSTS", "Missing HSTS", verdict="confirmed_exploitable",
                threats=[_threat("https://x.test/", evidence="")]),
        ])
        regression.sync_from_report(report2)
        self.assertEqual(len(regression.list_cases()), 2)

        fetcher = _FakeFetcher({
            "https://x.test/search": Resp("https://x.test/search", 200, {}, None, "clean"),
            "https://x.test/": Resp("https://x.test/", 200, {"strict-transport-security": "x"}, None, ""),
        })
        results = regression.run_all(fetcher=fetcher)
        self.assertEqual(len(results), 2)
        self.assertEqual({r["status"] for r in results}, {"pass"})

    def test_alerts_can_be_acknowledged(self):
        clean = Resp("https://x.test/search", 200, {}, None, "clean page")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": clean}))
        dirty = Resp("https://x.test/search", 200, {}, None, "...<script>alert(1)</script>...")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": dirty}))
        alert_id = regression.list_alerts()[0]["id"]
        self.assertEqual(regression.unacknowledged_count(), 1)
        self.assertTrue(regression.acknowledge_alert(alert_id))
        self.assertEqual(regression.unacknowledged_count(), 0)
        self.assertFalse(regression.acknowledge_alert(999999))

    def test_summary_counts_by_status(self):
        resp = Resp("https://x.test/search", 200, {}, None, "clean page")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": resp}))
        s = regression.summary()
        self.assertEqual(s["total"], 1)
        self.assertEqual(s["by_status"]["pass"], 1)

    def test_list_cases_filters_by_status_and_query(self):
        resp = Resp("https://x.test/search", 200, {}, None, "clean page")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": resp}))
        self.assertEqual(len(regression.list_cases(status="pass")), 1)
        self.assertEqual(len(regression.list_cases(status="fail")), 0)
        self.assertEqual(len(regression.list_cases(q="XSS")), 1)
        self.assertEqual(len(regression.list_cases(q="nope")), 0)

    def test_case_history_is_most_recent_first(self):
        r1 = Resp("https://x.test/search", 200, {}, None, "clean page")
        r2 = Resp("https://x.test/search", 200, {}, None, "...<script>alert(1)</script>...")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": r1}), now=10.0)
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": r2}), now=20.0)
        history = regression.case_history(self.case_id)
        self.assertEqual([h["status"] for h in history], ["fail", "pass"])

    def test_delete_all_wipes_cases_runs_and_alerts(self):
        clean = Resp("https://x.test/search", 200, {}, None, "clean page")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": clean}))
        dirty = Resp("https://x.test/search", 200, {}, None, "...<script>alert(1)</script>...")
        regression.run_case(self.case_id, fetcher=_FakeFetcher({"https://x.test/search": dirty}))
        n = regression.delete_all()
        self.assertEqual(n, 1)
        self.assertEqual(regression.list_cases(), [])
        self.assertEqual(regression.list_alerts(), [])


class RegressionApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orig = regression.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        regression.DB_PATH = Path(self._td.name) / "regression.db"
        regression.init()

        report = _report("r1", [
            _cat("DAST-XSS-REFLECTED", "XSS", verdict="actively_exploited",
                threats=[_threat("https://x.test/search", "q", evidence="<script>alert(1)</script>")]),
        ])
        self.case_id = regression.sync_from_report(report)[0]["case_id"]
        self.csrf = self.client.get("/api/csrf-token").get_json()["token"]

    def _restore(self):
        regression.DB_PATH = self._orig

    def _post(self, path):
        return self.client.post(path, headers={"X-CSRF-Token": self.csrf})

    def test_list_cases_endpoint(self):
        resp = self.client.get("/api/v1/regression/cases")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["count"], 1)

    def test_get_case_endpoint_includes_history(self):
        resp = self.client.get(f"/api/v1/regression/cases/{self.case_id}")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["case"]["case_id"], self.case_id)
        self.assertEqual(d["case"]["history"], [])

    def test_get_unknown_case_404s(self):
        resp = self.client.get("/api/v1/regression/cases/doesnotexist")
        self.assertEqual(resp.status_code, 404)

    def test_run_unknown_case_404s(self):
        resp = self._post("/api/v1/regression/cases/doesnotexist/run")
        self.assertEqual(resp.status_code, 404)

    def test_alerts_endpoint_starts_empty(self):
        resp = self.client.get("/api/v1/regression/alerts")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["count"], 0)

    def test_ack_unknown_alert_404s(self):
        resp = self._post("/api/v1/regression/alerts/999999/ack")
        self.assertEqual(resp.status_code, 404)

    def test_summary_endpoint(self):
        resp = self.client.get("/api/v1/regression/summary")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["total"], 1)


if __name__ == "__main__":
    unittest.main()
