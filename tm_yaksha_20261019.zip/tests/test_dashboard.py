"""Security posture dashboard: aggregation service + API.

The service summarizes saved state across report_db (threat models), the broker
(SAST), and the AIBOM inventory. These tests isolate report_db onto a temp DB
and assert the aggregate math, that SAST is excluded from the cross-report
severity totals, and that a missing tool degrades gracefully instead of raising.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

import ownership
import report_db
import suppressions
import verdict_tracking
from dashboard import service
from suppressions import db as supp_db
from suppressions import store as supp_store


def _cat(name, risk, cwe="", loci=None, verdict=None):
    cat = {"id": name, "name": name, "title": name, "risk": risk, "cwe": cwe,
           "_source": "TM", "threats": [{"name": l} for l in (loci or [])],
           "affected_components": loci or []}
    if verdict:
        cat["verdict"] = verdict
    return cat


def _report(rid, methodology, cats, title="R"):
    return {"id": rid, "title": title, "methodology": methodology,
            "overall_risk": cats[0]["risk"] if cats else "Info",
            "analyzed_at": "2026-07-18T00:00:00Z", "categories": cats}


class TestDashboardService(unittest.TestCase):
    def setUp(self):
        self._op = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self._oop = ownership.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory(); self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        supp_db.init()
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"
        # No broker/aibom stores in the temp home → those sections report empty.
        report_db.upsert_report(_report("1_1_a", "codemodel",
            [_cat("SQLi", "Critical", "CWE-89", ["db.py:10"]),
             _cat("XSS", "High", "CWE-79", ["v.py:2", "v.py:3"])]))
        report_db.upsert_report(_report("1_2_b", "correlation",
            [_cat("SSRF", "Medium", "CWE-918", ["net.py:1"])]))
        report_db.upsert_report(_report("1_3_c", "sast",     # must NOT count
            [_cat("Cmd", "Critical", "CWE-78", ["x.py:1"])]))

    def _restore(self):
        report_db.DB_PATH = self._op
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp
        ownership.DB_PATH = self._oop

    def test_severity_totals_exclude_sast(self):
        tm = service._threat_model_posture()
        # 1 Critical (SQLi) + 1 Medium (SSRF); the sast Critical is excluded.
        self.assertEqual(tm["severity"]["Critical"], 1)
        self.assertEqual(tm["severity"]["High"], 2)      # XSS had 2 loci
        self.assertEqual(tm["severity"]["Medium"], 1)
        self.assertEqual(tm["reports"], 2)               # sast report excluded
        self.assertEqual(tm["critical_high"], 3)

    def test_methodology_breakdown(self):
        tm = service._threat_model_posture()
        self.assertEqual(tm["by_methodology"], {"codemodel": 1, "correlation": 1})
        self.assertNotIn("sast", tm["by_methodology"])

    def test_trend_is_chronological_with_severity(self):
        tm = service._threat_model_posture()
        self.assertEqual(len(tm["trend"]), 2)
        # each point carries a per-severity breakdown
        self.assertIn("Critical", tm["trend"][0])

    def test_families_exclude_sast(self):
        fams = {f["family"]: f for f in service._families()}
        self.assertIn("sql-injection", fams)
        self.assertNotIn("os-command-injection", fams)   # only in the sast report

    def test_suppressed_finding_drops_out_of_severity_totals(self):
        # Accept the XSS finding (rule id "XSS", both loci) -> High must drop
        # from 2 to 0, same accepted-risk decision the single-report viewer
        # already applies, now reflected in the aggregate posture too.
        suppressions.add_suppression({
            "scope": "rule", "match": "XSS", "reason": "accepted for this release",
            "author": "carol"})
        tm = service._threat_model_posture()
        self.assertEqual(tm["severity"]["High"], 0)
        self.assertEqual(tm["severity"]["Critical"], 1)   # SQLi untouched
        self.assertEqual(tm["critical_high"], 1)

    def test_suppressed_finding_drops_out_of_family_rollup(self):
        suppressions.add_suppression({
            "scope": "rule", "match": "XSS", "reason": "accepted for this release",
            "author": "carol"})
        fams = {f["family"]: f for f in service._families()}
        self.assertNotIn("xss", fams)
        self.assertIn("sql-injection", fams)              # untouched

    def test_unsuppressed_totals_unchanged_by_suppression_wiring(self):
        # No suppressions configured at all -> numbers must exactly match the
        # pre-suppression-awareness behavior (same locus-based counting unit).
        tm = service._threat_model_posture()
        self.assertEqual(tm["severity"]["Critical"], 1)
        self.assertEqual(tm["severity"]["High"], 2)
        self.assertEqual(tm["severity"]["Medium"], 1)

    def test_build_returns_all_sections(self):
        d = service.build()
        self.assertTrue(d["success"])
        for key in ("threat_model", "families", "sast", "aibom", "generated_at", "governance",
                   "fleet", "confidence_decay", "verdict_reconciliation",
                   "design_gap_agenda", "correlator_precision"):
            self.assertIn(key, d)
        # Every tool section reports an availability flag rather than raising.
        self.assertIsInstance(d["sast"].get("available"), bool)
        self.assertIsInstance(d["aibom"].get("available"), bool)

    def test_build_survives_a_broken_tool(self):
        # A store that raises must degrade to available:False, not sink build() —
        # but build() must not lie about it either: success flips to False and
        # the failure is named in errors, so the UI can distinguish "no data
        # yet" from "this section is actually broken".
        with mock.patch.object(service, "_sast", side_effect=RuntimeError("no broker")):
            d = service.build()
        self.assertFalse(d["success"])
        self.assertIn("sast", d["errors"])
        self.assertFalse(d["sast"]["available"])

    def test_section_failure_does_not_sink_dashboard(self):
        with mock.patch.object(service, "_families", side_effect=RuntimeError("boom")):
            d = service.build()
        self.assertFalse(d["success"])         # families degrades to [], but failure is surfaced
        self.assertIn("families", d["errors"])
        self.assertEqual(d["families"], [])

    def test_healthy_sections_report_success_true(self):
        # No mocked failures here — every section genuinely has no data
        # (empty temp DB minus the seeded reports) or ran cleanly, so success
        # must stay True and errors must stay empty.
        d = service.build()
        self.assertTrue(d["success"])
        self.assertEqual(d["errors"], {})


class TestDashboardVerdicts(unittest.TestCase):
    """Isolated from TestDashboardService's fixed-count fixtures since these
    tests seed their own correlation-verdict data."""

    def setUp(self):
        self._op = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self._oop = ownership.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory(); self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        supp_db.init()
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"
        report_db.upsert_report(_report("2_1_a", "correlation", [
            _cat("SQLi", "Critical", "CWE-89", ["db.py:10"], verdict="confirmed_exploitable"),
            _cat("SSRF", "Medium", "CWE-918", ["net.py:1"], verdict="corroborated"),
            _cat("XSS", "High", "CWE-79", ["v.py:2", "v.py:3"], verdict="design_gap"),
        ]))
        report_db.upsert_report(_report("2_2_b", "codemodel", [
            _cat("Cmd", "High", "CWE-78", ["x.py:1"]),   # never touched the correlator
        ]))
        report_db.upsert_report(_report("2_3_c", "sast", [                # must NOT count
            _cat("Path", "Critical", "CWE-22", ["y.py:1"], verdict="confirmed_exploitable"),
        ]))

    def _restore(self):
        report_db.DB_PATH = self._op
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp
        ownership.DB_PATH = self._oop

    def test_counts_by_verdict_exclude_sast(self):
        v = service._verdicts()
        self.assertEqual(v["counts"]["confirmed_exploitable"], 1)   # SQLi only; sast excluded
        self.assertEqual(v["counts"]["corroborated"], 1)
        self.assertEqual(v["counts"]["design_gap"], 2)              # XSS had 2 loci
        self.assertEqual(v["counts"]["blind_spot"], 0)
        self.assertEqual(v["total_correlated"], 4)

    def test_unverdicted_findings_counted_separately(self):
        v = service._verdicts()
        self.assertEqual(v["unverdicted"], 1)   # the codemodel "Cmd" finding

    def test_top_confirmed_lists_the_finding(self):
        v = service._verdicts()
        self.assertEqual(len(v["top_confirmed"]), 1)
        self.assertEqual(v["top_confirmed"][0]["id"], "SQLi")
        self.assertEqual(v["top_confirmed"][0]["report_id"], "2_1_a")

    def test_suppressed_confirmed_finding_drops_out(self):
        suppressions.add_suppression({
            "scope": "rule", "match": "SQLi", "reason": "compensating control",
            "author": "dana"})
        v = service._verdicts()
        self.assertEqual(v["counts"]["confirmed_exploitable"], 0)
        self.assertEqual(v["top_confirmed"], [])

    def test_build_includes_verdicts_section(self):
        d = service.build()
        self.assertTrue(d["success"])
        self.assertIn("verdicts", d)
        self.assertEqual(d["verdicts"]["counts"]["confirmed_exploitable"], 1)

    def test_verdict_section_failure_does_not_sink_dashboard(self):
        with mock.patch.object(service, "_verdicts", side_effect=RuntimeError("boom")):
            d = service.build()
        self.assertFalse(d["success"])
        self.assertIn("verdicts", d["errors"])
        self.assertEqual(d["verdicts"]["total_correlated"], 0)

    def test_verdict_alerts_section_reflects_escalations(self):
        self._otp = verdict_tracking.DB_PATH
        self.addCleanup(lambda: setattr(verdict_tracking, "DB_PATH", self._otp))
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdict_alerts.db"
        verdict_tracking.init()

        cat_blind = {"id": "R1", "family": "sql-injection", "name": "SQLi",
                     "verdict": "blind_spot", "affected_components": ["a.py:1"]}
        cat_confirmed = dict(cat_blind, verdict="confirmed_exploitable")
        verdict_tracking.record_transitions({"id": "v1", "categories": [cat_blind]})
        verdict_tracking.record_transitions({"id": "v2", "categories": [cat_confirmed]})

        d = service.build()
        self.assertTrue(d["success"])
        self.assertEqual(d["verdict_alerts"]["unacknowledged"], 1)
        self.assertEqual(len(d["verdict_alerts"]["recent"]), 1)
        self.assertEqual(d["verdict_alerts"]["recent"][0]["to_verdict"], "confirmed_exploitable")

    def test_verdict_alerts_section_failure_does_not_sink_dashboard(self):
        with mock.patch.object(service, "_verdict_alerts", side_effect=RuntimeError("boom")):
            d = service.build()
        self.assertFalse(d["success"])
        self.assertIn("verdict_alerts", d["errors"])
        self.assertEqual(d["verdict_alerts"]["unacknowledged"], 0)

    def test_verdict_sla_section_reflects_breaches(self):
        self._otp = verdict_tracking.DB_PATH
        self.addCleanup(lambda: setattr(verdict_tracking, "DB_PATH", self._otp))
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdict_sla.db"
        verdict_tracking.init()

        t0 = 1_000_000.0
        cat = {"id": "R1", "family": "sql-injection", "name": "SQLi",
               "verdict": "confirmed_exploitable", "affected_components": ["a.py:1"]}
        verdict_tracking.record_transitions({"id": "v1", "categories": [cat]}, now=t0)

        with mock.patch.object(verdict_tracking.time, "time", return_value=t0 + 10 * 86400.0):
            d = service.build()
        self.assertTrue(d["success"])
        self.assertEqual(d["verdict_sla"]["tracked"], 1)
        self.assertEqual(d["verdict_sla"]["counts"]["breached"], 1)
        self.assertEqual(len(d["verdict_sla"]["worst"]), 1)

    def test_verdict_sla_section_failure_does_not_sink_dashboard(self):
        with mock.patch.object(service, "_verdict_sla", side_effect=RuntimeError("boom")):
            d = service.build()
        self.assertFalse(d["success"])
        self.assertIn("verdict_sla", d["errors"])
        self.assertEqual(d["verdict_sla"]["tracked"], 0)

    def test_verdict_trend_includes_the_correlation_fixture_oldest_first(self):
        d = service.build()
        self.assertTrue(d["success"])
        point = next((p for p in d["verdict_trend"] if p["id"] == "2_1_a"), None)
        self.assertIsNotNone(point)
        self.assertEqual(point["verdict_counts"]["confirmed_exploitable"], 1)
        self.assertEqual(point["verdict_counts"]["corroborated"], 1)
        self.assertEqual(point["verdict_counts"]["design_gap"], 2)   # XSS had 2 loci

    def test_verdict_trend_section_failure_does_not_sink_dashboard(self):
        with mock.patch.object(service, "_verdict_trend", side_effect=RuntimeError("boom")):
            d = service.build()
        self.assertFalse(d["success"])
        self.assertIn("verdict_trend", d["errors"])
        self.assertEqual(d["verdict_trend"], [])

    def test_design_debt_section_reports_open_backlog_and_burndown(self):
        self._otp = verdict_tracking.DB_PATH
        self.addCleanup(lambda: setattr(verdict_tracking, "DB_PATH", self._otp))
        verdict_tracking.DB_PATH = Path(self._td.name) / "verdict_debt.db"
        verdict_tracking.init()

        cat = {"id": "R1", "family": "sql-injection", "name": "SQLi",
               "verdict": "design_gap", "affected_components": ["a.py:1"]}
        verdict_tracking.record_transitions({"id": "v1", "categories": [cat]})

        d = service.build()
        self.assertTrue(d["success"])
        self.assertEqual(d["design_debt"]["open"], 1)
        # burndown comes from report_db.verdict_trends -- the 2_1_a fixture's
        # XSS finding (design_gap, 2 loci) seeded in setUp shows up there.
        point = next((p for p in d["design_debt"]["burndown"] if p["id"] == "2_1_a"), None)
        self.assertIsNotNone(point)
        self.assertEqual(point["design_gap"], 2)

    def test_design_debt_section_failure_does_not_sink_dashboard(self):
        with mock.patch.object(service, "_design_debt", side_effect=RuntimeError("boom")):
            d = service.build()
        self.assertFalse(d["success"])
        self.assertIn("design_debt", d["errors"])
        self.assertEqual(d["design_debt"]["open"], 0)

    def test_reachable_dependencies_section_lists_the_component(self):
        report_db.upsert_report({
            "id": "2_4_d", "title": "Correlation run", "methodology": "correlation",
            "categories": [{"id": "CORR-001", "name": "Vulnerable Components",
                            "risk": "Critical", "_source": "CORRELATION",
                            "dependency_reachability": {
                                "pyyaml": {"unauthenticated": True, "tainted": True,
                                          "min_hops": 0, "agent_tool": False}}}],
        })
        d = service.build()
        self.assertTrue(d["success"])
        self.assertEqual(d["reachable_dependencies"]["count"], 1)
        self.assertEqual(d["reachable_dependencies"]["items"][0]["component"], "pyyaml")

    def test_reachable_dependencies_section_failure_does_not_sink_dashboard(self):
        with mock.patch.object(service, "_reachable_dependencies", side_effect=RuntimeError("boom")):
            d = service.build()
        self.assertFalse(d["success"])
        self.assertIn("reachable_dependencies", d["errors"])
        self.assertEqual(d["reachable_dependencies"]["count"], 0)

    def test_governance_counts_only_correlated_findings(self):
        # 3 verdict-carrying findings from the 2_1_a fixture (SQLi, SSRF, XSS);
        # the codemodel "Cmd" finding is unverdicted and the sast "Path"
        # finding is excluded -- neither counts toward total_actionable.
        gov = service._governance()
        self.assertEqual(gov["total_actionable"], 3)
        self.assertEqual(gov["owned"], 0)
        self.assertEqual(gov["unowned"], 3)
        self.assertEqual(gov["coverage_pct"], 0.0)

    def test_governance_reflects_bucket_default_and_override(self):
        from suppressions.engine import finding_fingerprint
        ownership.set_default("confirmed_exploitable", "appsec-oncall")
        sqli_fp = finding_fingerprint(_cat("SQLi", "Critical", "CWE-89", ["db.py:10"],
                                          verdict="confirmed_exploitable"))
        ownership.assign(sqli_fp, "alice")
        gov = service._governance()
        self.assertEqual(gov["owned"], 1)          # SQLi via override
        self.assertEqual(gov["unowned"], 2)         # SSRF + XSS still unassigned
        self.assertEqual(gov["coverage_pct"], round(100 / 3, 1))

    def test_governance_flags_unowned_urgent_findings(self):
        gov = service._governance()
        self.assertEqual(gov["unowned_urgent"], 1)  # SQLi (confirmed_exploitable), unowned

    def test_governance_counts_active_risk_acceptances_by_state(self):
        suppressions.add_suppression({
            "scope": "rule", "match": "SSRF", "reason": "compensating control",
            "author": "dana", "state": "wont_fix"})
        gov = service._governance()
        self.assertEqual(gov["risk_accepted"], 1)
        self.assertEqual(gov["risk_accepted_by_state"], {"wont_fix": 1})
        # A suppressed finding is excluded from the correlated set entirely.
        self.assertEqual(gov["total_actionable"], 2)

    def test_governance_section_failure_does_not_sink_dashboard(self):
        with mock.patch.object(service, "_governance", side_effect=RuntimeError("boom")):
            d = service.build()
        self.assertFalse(d["success"])
        self.assertIn("governance", d["errors"])
        self.assertEqual(d["governance"]["total_actionable"], 0)


class TestDashboardApi(unittest.TestCase):
    def test_endpoint_and_page(self):
        import app as tm_app
        c = tm_app.app.test_client()
        r = c.get("/api/v1/dashboard").get_json()
        self.assertTrue(r["success"])
        self.assertIn("severity", r["threat_model"])
        self.assertEqual(c.get("/").status_code, 200)


if __name__ == "__main__":
    unittest.main()
