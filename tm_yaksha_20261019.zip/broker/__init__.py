"""SAST broker service.

Scans internal repositories with a static analysis engine and surfaces the
findings through the existing Yaksha Guard TM report UI.

The broker decouples *scanning* from *reporting*: it reaches internal repos
(local paths or git URLs that may be unreachable from external SAST SaaS),
runs a scan engine, maps findings to the TM report shape, and saves them so
they appear in the normal report list and viewer.

Sub-modules:
  config   - state dirs, settings, repo registry + job history persistence
  scanner  - workspace prep (git clone/pull) and scan-engine invocation
  mapper   - scan-engine findings  ->  TM report dict
  service  - job queue + background worker + report persistence
  cli      - standalone entry point (scan locally, or push to a remote server)
"""
from __future__ import annotations

from .service import BrokerService, get_service

__all__ = ["BrokerService", "get_service"]
