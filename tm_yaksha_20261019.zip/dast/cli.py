"""Standalone DAST scanner entry point.

Lets the dynamic scanner run as a separate process (e.g. inside a network segment
that can reach a staging deployment) and either save the report locally or push
it to a central TM server. Mirrors broker.cli.

Usage:
  python -m dast.cli scan <url> [--name NAME] [--scope host1,host2]
         [--severity Critical|High|Medium|Low|Info] [--auth "Header: value"]
         [--server https://tm.internal --token <secret>]   # remote mode

Exit codes: 0 ok (no findings), 1 ok (findings present), 2 error.
"""
from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request

from . import config, mapper, scanner


def _push_remote(report: dict, server: str, token: str) -> str:
    base = server.rstrip("/")
    with urllib.request.urlopen(f"{base}/api/csrf-token", timeout=30) as resp:
        csrf = json.loads(resp.read()).get("token", "")
    req = urllib.request.Request(
        f"{base}/api/v1/dast/import",
        data=json.dumps(report).encode("utf-8"),
        headers={"Content-Type": "application/json", "X-CSRF-Token": csrf,
                 "X-Dast-Token": token},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read()).get("id", "")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="dast.cli", description="Dynamic app scanner.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sc = sub.add_parser("scan", help="Scan a URL and emit/push a report.")
    sc.add_argument("target", help="Target URL (http/https)")
    sc.add_argument("--name", default="", help="Display name (defaults to the URL)")
    sc.add_argument("--scope", default="", help="Extra in-scope hosts (comma sep)")
    sc.add_argument("--severity", default="Info", choices=list(config.SEVERITIES))
    sc.add_argument("--auth", default="", help="Auth header, e.g. 'Authorization: Bearer x'")
    sc.add_argument("--server", default="", help="Remote TM server base URL (remote mode)")
    sc.add_argument("--token", default=config.IMPORT_TOKEN,
                    help="Shared secret for /api/v1/dast/import (remote mode)")
    args = ap.parse_args(argv)

    target = {
        "id": config.slugify(args.name or args.target),
        "name": args.name or args.target,
        "url": args.target,
        "scope": args.scope,
        "auth_header": args.auth,
    }
    try:
        findings, meta = scanner.run_scan(
            target, args.severity, progress=lambda m: print(m, file=sys.stderr))
    except scanner.ScanError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    report = mapper.findings_to_report(findings, target, meta, args.severity)

    if args.server:
        if not args.token:
            print("ERROR: --token (or TM_DAST_TOKEN) required for remote mode", file=sys.stderr)
            return 2
        try:
            rid = _push_remote(report, args.server, args.token)
        except (urllib.error.URLError, urllib.error.HTTPError) as exc:
            print(f"ERROR: push failed: {exc}", file=sys.stderr)
            return 2
        print(f"Pushed report {rid} to {args.server} ({len(findings)} finding(s))")
    else:
        import app as tm_app
        rid = tm_app._save_report(report, report["title"])
        print(f"Saved report {rid} locally ({len(findings)} finding(s))")

    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
