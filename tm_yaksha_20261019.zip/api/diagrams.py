"""Diagram API routes."""
from __future__ import annotations

from flask import Blueprint

import app as tm_app


bp = Blueprint("diagrams_api", __name__, url_prefix="/api/v1/diagrams")


@bp.post("/architecture")
@tm_app.limiter.limit("20 per minute")
def architecture_diagram():
    """Generate an architecture Mermaid diagram."""
    return tm_app._architecture_diagram_route_impl()
