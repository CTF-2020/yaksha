"""Sign-in page, backed by a real credential store (users_db.py, SQLite).

Nothing gates on it yet: no route checks the session before serving a page,
so a valid session only makes the UI feel signed in — it is not (yet) an
authorization boundary. Route-gating is a deliberate follow-up, not an
oversight: adding it means deciding an allowlist (health checks, GitHub
webhooks, /api/csrf-token, etc.) and is out of scope here.

Routes:
  GET  /login   the sign-in form (accepts ?next=<path> to return to afterward)
  POST /login   validates email+password against users_db; wrong credentials
                re-render the form with an error (401) instead of redirecting
  GET  /logout  clears the session and returns to /login

CSRF is enforced by the app's global before_request for the POST, same as
every other form in the portal.
"""
from __future__ import annotations

from flask import Blueprint, redirect, render_template, request, session

import users_db

page_bp = Blueprint("login_page", __name__)


def _safe_next(value: str | None) -> str:
    """Only ever redirect to a same-site path — never a scheme or a
    protocol-relative URL, which would turn `next` into an open redirect."""
    if not value or not value.startswith("/") or value.startswith("//"):
        return "/"
    return value


@page_bp.get("/login")
def login_page():
    from app import _CSRF_TOKEN
    next_path = _safe_next(request.args.get("next"))
    return render_template("login.html", csrf_token=_CSRF_TOKEN, next=next_path)


@page_bp.post("/login")
def login_submit():
    from app import _CSRF_TOKEN
    next_path = _safe_next(request.form.get("next"))
    email = (request.form.get("email") or "").strip()
    password = request.form.get("password") or ""
    user = users_db.verify_user(email, password)
    if user is None:
        return render_template("login.html", csrf_token=_CSRF_TOKEN, next=next_path,
                               error="Invalid email or password"), 401
    session["user_email"] = user["email"]
    return redirect(next_path)


@page_bp.get("/logout")
def logout():
    session.pop("user_email", None)
    return redirect("/login")
