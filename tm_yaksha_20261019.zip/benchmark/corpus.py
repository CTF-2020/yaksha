"""Labelled accuracy corpus for the Yaksha Guard OFFLINE deterministic rule engine.

Each case targets one rule by id and pairs:
  * ``vuln`` — an architecture description of the INSECURE pattern the rule exists to
    catch. Ground truth: the engine must RAISE that rule (status != PASS).
  * ``safe`` — the SAME domain described SECURELY (controls in place, no risk phrases).
    Ground truth: the engine must NOT raise that rule (status == PASS) — i.e. the
    control-evidence suppression must work, so a well-architected design isn't warned.

Recall is measured from the ``vuln`` texts, false-positive resistance (specificity) from
the ``safe`` texts. Both are per-target-rule, which is the honest way to score a BROAD
reviewer: one description legitimately triggers many rules, so only the targeted rule's
status is scored for that case (other rules firing is neither credited nor penalised).

The corpus SAMPLES the rule space (53 cases spanning distinct rules across all 7
rulesets, including all 10 OWASP LLM categories); it is a discriminating benchmark,
not exhaustive coverage of all 620 rules.
"""

# expect: minimum status the vuln text must reach ("WARN" = raised at all; "FAIL" =
# must reach critical). Severity Critical/High rules with an explicit risk phrase FAIL.
CASES = [
    # ── OWASP Web Top 10 ──────────────────────────────────────────────────────
    dict(rule_id="WEB-A01-01", ruleset="web", expect="FAIL",
         vuln=("A REST API exposes GET /accounts/{account_id} backed by a Postgres "
               "database. Any authenticated user can pass any account_id and read "
               "another user's record — there is no authorization check at the row "
               "level and no access control on the object."),
         safe=("GET /accounts/{account_id} reads the database record only after "
               "object-level authorization enforced against the caller's tenant. "
               "Deny by default, with RBAC/ABAC policy tests and server-side "
               "validation on every resource access.")),
    dict(rule_id="WEB-A02-01", ruleset="web", expect="FAIL",
         vuln=("The mobile app talks to the backend API over plain HTTP. Session "
               "tokens and passwords cross the network in cleartext — traffic is "
               "unencrypted in transit and stored as plaintext in the database."),
         safe=("All API communication is over HTTPS with TLS 1.2 or TLS 1.3 enforced "
               "and HSTS enabled. Data at rest uses KMS-backed encryption and "
               "passwords use adaptive password hashing.")),
    dict(rule_id="WEB-A03-01", ruleset="web", expect="FAIL",
         vuln=("The search endpoint builds a SQL query for the MySQL database by "
               "string-concatenating the raw user input directly into the query — no "
               "parameterized queries, no input validation, unsanitized."),
         safe=("The search endpoint queries the SQL database exclusively through "
               "parameterized queries with schema validation and output encoding on "
               "results; a safe deserialization allowlist guards imports.")),
    dict(rule_id="WEB-A05-01", ruleset="web", expect="FAIL",
         vuln=("The production web app runs with debug mode enabled (debug = true); "
               "unhandled exceptions return a full stack trace and error message with "
               "internal paths to the client. Dev mode configuration shipped to prod."),
         safe=("Production runs a secure baseline enforced with debug disabled; error "
               "messages are generic, private by default, with configuration drift "
               "monitoring on the deployment.")),
    dict(rule_id="WEB-A07-01", ruleset="web", expect="FAIL",
         vuln=("The login flow uses a single password with no MFA. Default credentials "
               "(admin:admin) ship enabled and there is no rate limit on the "
               "authentication endpoint, so credential stuffing is trivial."),
         safe=("Authentication requires MFA enforced with short-lived tokens and "
               "refresh token rotation; the login endpoint has rate limiting and a "
               "secure password reset flow.")),
    dict(rule_id="WEB-A04-01", ruleset="web", expect="FAIL",
         vuln=("The password reset, login, and signup endpoints have no rate limit "
               "and no CAPTCHA; a script can attempt unlimited requests against "
               "these business flows with no abuse-case control at all."),
         safe=("Login, password reset, and signup all enforce rate limits on "
               "business flows with documented abuse cases and secure defaults as "
               "approved security requirements.")),
    dict(rule_id="WEB-A06-01", ruleset="web", expect="FAIL",
         vuln=("Backend npm and pip packages are pinned to versions from three "
               "years ago with no dependency scanning; known critical CVEs remain "
               "unpatched in production with no SCA gate enabled."),
         safe=("Every dependency and npm package goes through an SCA gate enabled "
               "with a generated SBOM; critical CVEs are blocked from release and "
               "tracked against a patch SLA.")),
    dict(rule_id="WEB-A08-01", ruleset="web", expect="FAIL",
         vuln=("The CI/CD pipeline lets any developer push directly to the deploy "
               "branch with no branch protection; build artifacts are unsigned "
               "artifacts with no code signing before release."),
         safe=("The CI/CD pipeline requires protected branches and produces signed "
               "artifacts with SLSA provenance and integrity checks on every "
               "release.")),
    dict(rule_id="WEB-A10-01", ruleset="web", expect="FAIL",
         vuln=("The webhook and URL-preview feature performs a server-side fetch "
               "of any user-supplied URL with no egress allowlist and no metadata "
               "endpoint blocked, so it can reach internal services and the cloud "
               "metadata endpoint."),
         safe=("Server-side fetches of user-supplied URLs go through an egress "
               "allowlist with metadata endpoint blocked, private IP ranges "
               "denied, and redirect validation on every request.")),
    dict(rule_id="WEB-A09-01", ruleset="web", expect="WARN",
         vuln=("The service keeps no audit trail of authentication and session events. "
               "Logging is disabled in production and there is no access log for admin "
               "actions, so a breach would be invisible."),
         safe=("Authentication, session and admin actions flow to centralized audit "
               "logging with SIEM alerting; logs are tamper-resistant and tied to "
               "incident runbooks.")),
    # ── OWASP API Top 10 ──────────────────────────────────────────────────────
    dict(rule_id="API-API1-01", ruleset="api", expect="FAIL",
         vuln=("Each REST resource is addressed by an incrementing object id in the "
               "URL. The API endpoint trusts the id from the client with no ownership "
               "check — no authorization on the object, so users read each other's "
               "records."),
         safe=("Every API endpoint applies object-level authorization with ownership "
               "checks; access is tenant scoped and gated by a per-resource policy "
               "before the resource id is used.")),
    dict(rule_id="API-API2-01", ruleset="api", expect="FAIL",
         vuln=("The API authenticates with a static bearer token / api key that never "
               "expires and is shared across clients. The JWT has no expiry and there "
               "is no authentication token rotation — a leaked credential is forever."),
         safe=("The API uses short-lived JWT credentials with issuer audience "
               "validation and refresh token rotation; every access token is revocable "
               "and bound to a single client.")),
    dict(rule_id="API-API2-05", ruleset="api", expect="FAIL",
         vuln=("The API's JWT library accepts alg none from the token header, "
               "skipping signature verification entirely; the same RSA public "
               "key used for RS256 also validates HS256 tokens since the "
               "algorithm not pinned server-side."),
         safe=("The API's JWT verification has the algorithm pinned to a single "
               "expected algorithm with an explicit algorithm allowlist; "
               "asymmetric and symmetric verification paths fully separate so "
               "a public key is never reused as an HMAC secret.")),
    dict(rule_id="API-API4-01", ruleset="api", expect="WARN",
         vuln=("List/collection endpoints accept an unbounded page size and offset and "
               "run heavy queries. There is no rate limit and no pagination cap, so a "
               "client can request the entire dataset in one call."),
         safe=("Collection endpoints enforce rate limiting with per-client quotas, "
               "payload limits and bounded pagination on every list and offset "
               "parameter.")),
    dict(rule_id="API-API3-01", ruleset="api", expect="FAIL",
         vuln=("API responses serialize and return the raw ORM model object "
               "directly to the client with no field allowlist, so internal "
               "fields, hashed passwords, and server-managed attributes leak "
               "through the response."),
         safe=("API responses apply a field allowlist with read/write DTO "
               "separation; sensitive fields filtered are never serialized, and "
               "server-managed fields immutable can't be overwritten by "
               "clients.")),
    dict(rule_id="API-API5-01", ruleset="api", expect="FAIL",
         vuln=("Admin and privileged management API functions share the same "
               "route prefix as regular endpoints with no per-route permission "
               "checks, so any authenticated user can call administrative "
               "functions directly."),
         safe=("Every admin and privileged API function requires per-route "
               "permission checks with RBAC authorization, method restrictions, "
               "and admin MFA before executing.")),
    dict(rule_id="API-API6-01", ruleset="api", expect="FAIL",
         vuln=("The checkout, registration, and booking endpoints have no bot "
               "detection and no CAPTCHA, so scripted automation can complete the "
               "business flow at unlimited requests with no risk scoring."),
         safe=("Checkout, registration, and booking flows are protected by bot "
               "detection and CAPTCHA, with risk scoring and manual review for "
               "anomalies on high-value business flows.")),
    dict(rule_id="API-API7-01", ruleset="api", expect="FAIL",
         vuln=("API requests accept an arbitrary callback URL and webhook URL for "
               "server-side fetch with no domain allowlist and no private IP "
               "blocked, exposing internal services."),
         safe=("Callback and webhook URLs go through a domain allowlist with "
               "private IP blocked, metadata endpoint blocked, and requests "
               "routed through an egress proxy.")),
    dict(rule_id="API-API8-01", ruleset="api", expect="FAIL",
         vuln=("API responses allow all origins with permissive CORS and have no "
               "strict CORS allowlist, no HSTS, and debug mode enabled in "
               "production."),
         safe=("API responses enforce a strict CORS allowlist with HSTS and "
               "secure headers; debug disabled in every production "
               "environment.")),
    dict(rule_id="API-API8-05", ruleset="api", expect="WARN",
         vuln=("The GraphQL API leaves GraphQL introspection enabled in "
               "production, and the GraphQL playground is reachable without "
               "authentication, so an introspection query returns the full "
               "schema including internal admin mutations."),
         safe=("The GraphQL API disables GraphQL introspection in production; "
               "the GraphQL playground is disabled outside development, and "
               "any introspection query is blocked at the gateway before "
               "reaching the resolver.")),
    dict(rule_id="API-API9-01", ruleset="api", expect="WARN",
         vuln=("Several deprecated API versions remain deployed with no API "
               "catalog maintained, no owner assigned, and no schema published, "
               "so shadow endpoints go untracked and undocumented."),
         safe=("Every API has an API catalog maintained, an owner assigned, and "
               "a schema published; deprecated APIs retired follow a documented "
               "version lifecycle.")),
    # ── Cloud (CSA) ───────────────────────────────────────────────────────────
    dict(rule_id="CLD-CSA01-01", ruleset="cloud", expect="FAIL",
         vuln=("Customer exports land in an S3 bucket that is public — the cloud "
               "storage blob has no access control and is world-readable. Anyone with "
               "the URL can list and download the storage objects."),
         safe=("The S3 bucket is private by default with least-privilege IAM, fronted "
               "by private endpoints, and continuously checked by CSPM monitoring and "
               "IaC security gates.")),
    dict(rule_id="CLD-CSA02-01", ruleset="cloud", expect="FAIL",
         vuln=("IAM roles attached to the Lambda and EC2 workloads use wildcard "
               "permissions with no least-privilege IAM and no short-lived "
               "credentials; static access keys never rotate."),
         safe=("IAM roles for Lambda and EC2 workloads follow least-privilege IAM "
               "with short-lived credentials issued via OIDC federation; MFA "
               "enforced on every human principal.")),
    dict(rule_id="CLD-CSA03-01", ruleset="cloud", expect="WARN",
         vuln=("Presigned URLs generated for the S3 storage bucket have no short "
               "expiry — links stay valid for seven days by default, granting "
               "long-lived download access to anyone who has the URL."),
         safe=("Presigned URLs and SAS tokens for cloud storage are generated with "
               "short expiry, valid only for minutes, never days.")),
    dict(rule_id="CLD-CSA08-01", ruleset="cloud", expect="WARN",
         vuln=("There are no alerts for unusual data volume on the storage and "
               "database exports; a bulk download or off-hours query would go "
               "completely unnoticed."),
         safe=("Alerts for unusual data volume trigger on bulk downloads and "
               "off-hours queries against cloud storage and database exports, "
               "feeding the security team in real time.")),
    # ── Mobile ────────────────────────────────────────────────────────────────
    dict(rule_id="MOB-M1-01", ruleset="mobile", expect="FAIL",
         vuln=("The Android/iOS mobile app hard-codes the API key and a default "
               "password in the apk. Secrets are embedded in plaintext in the binary "
               "and there is no certificate validation on TLS."),
         safe=("The mobile app keeps no embedded secrets — credentials live in the "
               "secure keystore, use short-lived tokens, and TLS certificate "
               "validation (pinning) is enforced.")),
    dict(rule_id="MOB-M2-01", ruleset="mobile", expect="FAIL",
         vuln=("Third-party analytics and advertising SDKs are added to the mobile "
               "app with no dependency scanning and no protected signing keys; "
               "nobody reviews SDK permissions before release."),
         safe=("Every third-party analytics and advertising SDK ships only in "
               "signed builds with dependency scanning and protected signing keys "
               "enforced on every release.")),
    dict(rule_id="MOB-M5-01", ruleset="mobile", expect="FAIL",
         vuln=("The mobile app falls back to plain HTTP when TLS negotiation fails, "
               "and certificate validation disabled for one legacy backend host, "
               "so traffic is unencrypted in transit on that path."),
         safe=("The mobile app enforces TLS 1.2+ on all network communication with "
               "no HTTP fallback; certificate validation (pinning for high-risk "
               "APIs) is required for every backend host.")),
    dict(rule_id="MOB-M9-01", ruleset="mobile", expect="FAIL",
         vuln=("The mobile app caches PII and session tokens in a local SQLite "
               "database and shared preferences with no encrypted local storage "
               "and no secure keystore protecting the local cache."),
         safe=("The mobile app uses encrypted local storage and a secure keystore "
               "for any PII or session token kept in the local SQLite cache.")),
    # ── Architecture (Zero Trust + principles) ────────────────────────────────
    dict(rule_id="ARCH-ZT-01", ruleset="architecture", expect="WARN",
         vuln=("Internal services trust anything on the corporate network / VPN. Once "
               "on the trusted internal network a caller reaches any service with no "
               "authorization — a flat, implicitly-trusted intranet."),
         safe=("The architecture assumes zero trust: continuous verification and mTLS "
               "between services, micro-segmentation, and per-resource authorization "
               "regardless of network location.")),
    dict(rule_id="ARCH-POLP-01", ruleset="architecture", expect="FAIL",
         vuln=("Developers and service accounts hold standing admin rights "
               "permanently; there is no JIT access and no quarterly access "
               "review of who still needs elevated privileges."),
         safe=("Access follows least privilege everywhere: JIT access replaces "
               "standing admin rights, service accounts use minimal service "
               "permissions, and PAM enforces quarterly access review.")),
    dict(rule_id="ARCH-FS-01", ruleset="architecture", expect="FAIL",
         vuln=("When the authorization service times out or throws an exception, "
               "the API defaults to allowing the request through — a fail-open "
               "fallback with no deny on failure and no failure audit logging."),
         safe=("Every dependency and policy check defaults to deny on failure with "
               "a circuit breaker and safe fallback; failure audit logging records "
               "every fail-closed event.")),
    dict(rule_id="ARCH-SOD-01", ruleset="architecture", expect="FAIL",
         vuln=("The same engineer can write code, approve their own pull request, "
               "and deploy straight to production with no two-person approval and "
               "no separate deployment credentials."),
         safe=("Production deploys require two-person approval on protected "
               "branches, and separate deployment credentials are used so no "
               "single engineer can write, approve, and ship a change alone.")),
    # ── DevSecOps ─────────────────────────────────────────────────────────────
    dict(rule_id="DSO-SAST-01", ruleset="devsecops", expect="WARN",
         vuln=("Code is merged to the main branch straight from a pull request with no "
               "static analysis. The git repository has no SAST, no secret scanning "
               "and no security gate in CI."),
         safe=("Every pull request to the repository runs a SAST gate with tuned rules "
               "and secret scanning; SAST/SCA gates block merges and findings have "
               "clear ownership.")),
    dict(rule_id="DSO-SCA-01", ruleset="devsecops", expect="FAIL",
         vuln=("The build pipeline installs npm and pip packages with no SCA gate "
               "blocking critical vulnerabilities; there is no dependency update "
               "automation and no generated SBOM."),
         safe=("The build pipeline runs an SCA gate that blocks critical "
               "vulnerabilities, with dependency update automation keeping "
               "packages current and an SBOM generated for every build.")),
    dict(rule_id="DSO-SECRET-01", ruleset="devsecops", expect="FAIL",
         vuln=("Developers can commit directly to the git repository with no "
               "secret scanning and no push protection; a leaked API key would "
               "sit in version control indefinitely with no automatic revocation."),
         safe=("Every commit to the repository runs through secret scanning with "
               "push protection blocking commits that contain credentials, and "
               "automatic revocation fires the moment a secret is detected.")),
    dict(rule_id="DSO-CONTAINER-01", ruleset="devsecops", expect="FAIL",
         vuln=("Container images are built from an unpinned base image and pushed "
               "straight to the registry with no image scanning; containers run "
               "as root in production with no read-only filesystem."),
         safe=("Container images are built from a pinned, signed images base and "
               "scanned by image scanning before push; workloads run non-root "
               "with a read-only filesystem enforced at runtime.")),
    # ── AI / LLM ──────────────────────────────────────────────────────────────
    dict(rule_id="AI-LLM01-01", ruleset="ai", expect="WARN",
         vuln=("A customer-facing chat LLM concatenates untrusted user input directly "
               "into the system prompt and can call tools. There is no prompt "
               "injection defense — retrieved documents and the user message share the "
               "same instruction channel."),
         safe=("The LLM chat applies prompt injection scanning and a strict "
               "instruction hierarchy; retrieval sanitization cleans documents and "
               "tools run behind a tool allowlist with prompt/content filtering.")),
    dict(rule_id="AI-LLM02-01", ruleset="ai", expect="FAIL",
         vuln=("The LLM chatbot's raw output is rendered directly as HTML in the "
               "browser frontend with no output validation and no sanitization — "
               "markdown render of the model response goes straight to innerHTML."),
         safe=("The LLM chatbot's output is HTML-escaped and DOMPurify-sanitized "
               "before rendering in the browser frontend, with CSP as a second "
               "layer of defense.")),
    dict(rule_id="AI-LLM03-01", ruleset="ai", expect="FAIL",
         vuln=("Any user can upload a document to the RAG vector store and the "
               "embedding index with no authentication and no provenance tracking, "
               "so poisoned documents enter retrieval unchecked."),
         safe=("Writes to the RAG vector database go through authenticated ingestion "
               "with provenance tracked and tenant scoped access, audited by a "
               "dedicated ingestion service.")),
    dict(rule_id="AI-LLM04-01", ruleset="ai", expect="FAIL",
         vuln=("The LLM inference API accepts unlimited tokens per request with no "
               "rate limit and no token limit, so a single client can exhaust the "
               "AI model's compute budget with one prompt."),
         safe=("Every LLM inference call enforces rate limiting and token limits "
               "per user and session, with quota and throttling on the AI model "
               "endpoint.")),
    dict(rule_id="AI-LLM05-01", ruleset="ai", expect="FAIL",
         vuln=("The service downloads model weights and checkpoints from a public "
               "Hugging Face repository and loads them into inference with no "
               "signature verification, so a compromised model registry entry runs "
               "unchecked."),
         safe=("Model weights and checkpoints are pulled only from an internal "
               "registry using signed artifacts with an AI SBOM and provider due "
               "diligence review before any checkpoint is loaded.")),
    dict(rule_id="AI-LLM06-01", ruleset="ai", expect="FAIL",
         vuln=("Fine-tuning datasets are built directly from raw customer support "
               "tickets and user data with no PII redaction and no data "
               "minimization, so personal data ends up baked into the fine-tuned "
               "model weights."),
         safe=("Training data pipelines apply PII redaction and data minimization "
               "before any fine-tuning job runs; datasets are tenant scoped and "
               "secret filtering removes credentials first.")),
    dict(rule_id="AI-LLM07-01", ruleset="ai", expect="FAIL",
         vuln=("The LLM agent's plugins have file system and database access with "
               "no permission scoping; any tool can be invoked with no allowlist, "
               "and there is no argument validation on tool calls."),
         safe=("Every LLM tool and plugin runs as allowlisted tools with least "
               "privilege scoped permissions, argument schema validation, and tool "
               "audit logging on every call.")),
    dict(rule_id="AI-LLM08-01", ruleset="ai", expect="FAIL",
         vuln=("The autonomous agent can write, delete, and deploy changes to "
               "production with no human approval and no approval workflow; write "
               "actions execute immediately with no rollback."),
         safe=("High-impact agent actions require human approval and write actions "
               "require approval before execution; the agent runs with least "
               "privilege scoped permissions and reversible actions only.")),
    dict(rule_id="AI-LLM09-01", ruleset="ai", expect="FAIL",
         vuln=("AI-generated legal and medical recommendations are shown to users "
               "and auto-applied with no human review and no confidence threshold, "
               "so a hallucinated answer reaches the customer unchecked."),
         safe=("AI-generated legal and medical recommendations require human "
               "review and are gated by a confidence threshold, with source "
               "citation and output validation before reaching the customer.")),
    dict(rule_id="AI-LLM07-05", ruleset="ai", expect="FAIL",
         vuln=("The LLM agent connects to third-party MCP servers over function "
               "calling. The tool definition changed after approval once already, "
               "and the client has no re-approval required flow — it just keeps "
               "using whatever definition the server serves this time."),
         safe=("The LLM agent connects to MCP servers whose tool manifests are "
               "content hash pinned; if a definition changes, re-approval "
               "required is enforced and manifests are diffed on every "
               "connection before the agent uses function calling.")),
    dict(rule_id="AI-LLM10-01", ruleset="ai", expect="FAIL",
         vuln=("The LLM inference endpoint is public with no rate limit and no "
               "token limit, allowing high-volume querying to extract the model's "
               "decision boundary with no anomaly detection on query patterns."),
         safe=("The inference endpoint enforces rate limits and token rate limits "
               "per client, with quotas and throttling, and query pattern "
               "monitoring to protect inference endpoints from extraction.")),

    # ── AI negation-stress cases ──────────────────────────────────────────────
    dict(rule_id="AI-LLM01-02", ruleset="ai", expect="WARN",
         vuln=("The RAG agent retrieves documents from the open web and does not "
               "sanitize retrieved content before it enters the LLM context; there "
               "is no prompt injection scanning on ingested pages."),
         safe=("Retrieved content is sanitized before entering LLM context and "
               "prompt-injection scanned; document provenance is tracked end to "
               "end for the RAG agent.")),
    dict(rule_id="AI-LLM06-04", ruleset="ai", expect="FAIL",
         vuln=("Conversation history is not redacted before model calls and does "
               "not filter for PII; secrets typed by users into the LLM chatbot "
               "pass straight through to the model provider."),
         safe=("Conversation history is redacted before model calls and filtered "
               "for PII; sensitive data redaction and secret redaction run on "
               "every LLM chatbot turn.")),

    # ── Negation-stress cases ─────────────────────────────────────────────────
    # These describe the INSECURE design by NEGATING the control ("no MFA",
    # "without parameterized queries") rather than with a risk noun. A reviewer
    # that reads a negated control mention as the control being present will miss
    # them — they guard the negation-aware suppression in _control_evidence.
    dict(rule_id="WEB-A03-01", ruleset="web", expect="FAIL",
         vuln=("The reporting endpoint runs queries against the SQL database and does "
               "not use parameterized queries; there is no input validation and no "
               "output encoding on the results returned to the user."),
         safe=("The reporting endpoint uses parameterized queries against the SQL "
               "database with schema validation and output encoding on results.")),
    dict(rule_id="WEB-A07-01", ruleset="web", expect="FAIL",
         vuln=("The admin console login has no MFA and no rate limiting; accounts are "
               "not locked after repeated failures, so credential stuffing against the "
               "authentication endpoint is unthrottled."),
         safe=("The admin console enforces MFA with short-lived tokens, rate limits the "
               "authentication endpoint and applies account lockout with a secure "
               "password reset flow.")),
    dict(rule_id="WEB-A02-01", ruleset="web", expect="FAIL",
         vuln=("Internal services talk to each other without TLS; traffic is not "
               "encrypted in transit and database backups are stored with no "
               "encryption at rest."),
         safe=("Internal services use mTLS with TLS 1.3 enforced; data in transit and "
               "database backups at rest use KMS-backed encryption.")),
]

# A fully-secure, well-architected description. A good reviewer should raise FEW rules
# on it — used to measure the "does it over-warn on secure designs" rate (label-free).
CLEAN_DESIGN = (
    "A multi-tenant SaaS. All traffic is HTTPS with TLS 1.3 enforced and HSTS enabled. "
    "Every API endpoint applies object-level authorization with ownership checks, tenant "
    "scoped and deny by default. Authentication uses MFA enforced with short-lived JWT, "
    "issuer audience validation and refresh token rotation. The SQL database is accessed "
    "only via parameterized queries with schema validation; data at rest uses KMS-backed "
    "encryption. Secrets live in a vault, never embedded. S3 buckets are private by "
    "default with least-privilege IAM and CSPM monitoring. Centralized audit logging "
    "feeds a SIEM with tamper-resistant logs. CI runs SAST/SCA gates with secret "
    "scanning. Services use mTLS with micro-segmentation and zero trust continuous "
    "verification. Debug disabled with a secure baseline enforced."
)
