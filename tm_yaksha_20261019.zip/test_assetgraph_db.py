"""Tests for assetgraph.db — the SQLite store for the asset graph.

DB_PATH is repointed to a temp file for the duration of each test, mirroring
test_lineage_db.py / test_suppressions_db.py, so this suite never touches the
real ~/.tm_assetgraph.db.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from assetgraph import db
from assetgraph.model import Asset, AssetEdge


def _asset(id_="a1", kind="repo", name="Repo A"):
    return Asset(id=id_, kind=kind, name=name, attributes={"x": 1},
                first_seen_at="2026-01-01T00:00:00Z", last_seen_at="2026-01-01T00:00:00Z",
                observation_count=1)


def _edge(id_="e1", from_id="a1", to_id="a2", relation="contains", status="active"):
    return AssetEdge(id=id_, from_id=from_id, to_id=to_id, relation=relation, status=status,
                     first_seen_at="2026-01-01T00:00:00Z", last_seen_at="2026-01-01T00:00:00Z",
                     first_seen_report_id="r1", last_seen_report_id="r1")


class TestAssetGraphDb(unittest.TestCase):
    def setUp(self):
        self._orig = db.DB_PATH
        self._td = tempfile.TemporaryDirectory()
        db.DB_PATH = Path(self._td.name) / "assetgraph.db"

    def tearDown(self):
        db.DB_PATH = self._orig
        self._td.cleanup()

    def test_upsert_and_get_asset(self):
        db.upsert_asset(_asset())
        got = db.get_asset("a1")
        self.assertEqual(got.name, "Repo A")
        self.assertEqual(got.attributes, {"x": 1})

    def test_upsert_asset_updates_name_attrs_and_count_on_conflict(self):
        db.upsert_asset(_asset())
        updated = _asset()
        updated.name = "Repo A Renamed"
        updated.attributes = {"x": 2}
        updated.observation_count = 5
        db.upsert_asset(updated)
        got = db.get_asset("a1")
        self.assertEqual(got.name, "Repo A Renamed")
        self.assertEqual(got.attributes, {"x": 2})
        self.assertEqual(got.observation_count, 5)

    def test_missing_asset_returns_none(self):
        self.assertIsNone(db.get_asset("nope"))

    def test_all_assets_filters_by_kind(self):
        db.upsert_asset(_asset(id_="a1", kind="repo"))
        db.upsert_asset(_asset(id_="a2", kind="entry_point"))
        self.assertEqual(len(db.all_assets()), 2)
        self.assertEqual(len(db.all_assets(kind="repo")), 1)

    def test_upsert_and_query_edges(self):
        db.upsert_edge(_edge())
        self.assertEqual(len(db.edges_from("a1")), 1)
        self.assertEqual(len(db.edges_to("a2")), 1)
        self.assertEqual(db.edges_from("a1")[0].status, "active")

    def test_edges_from_filters_by_status(self):
        db.upsert_edge(_edge(id_="e1", status="active"))
        db.upsert_edge(_edge(id_="e2", to_id="a3", status="stale"))
        self.assertEqual(len(db.edges_from("a1", status="active")), 1)
        self.assertEqual(len(db.edges_from("a1", status="stale")), 1)
        self.assertEqual(len(db.edges_from("a1")), 2)

    def test_set_edge_status(self):
        db.upsert_edge(_edge())
        db.set_edge_status("e1", "stale", "2026-02-01T00:00:00Z")
        e = db.edges_from("a1")[0]
        self.assertEqual(e.status, "stale")
        self.assertEqual(e.last_seen_at, "2026-02-01T00:00:00Z")

    def test_upsert_edge_is_idempotent_by_id(self):
        db.upsert_edge(_edge(status="active"))
        db.upsert_edge(_edge(status="stale"))
        self.assertEqual(len(db.edges_from("a1")), 1)
        self.assertEqual(db.edges_from("a1")[0].status, "stale")

    def test_counts(self):
        db.upsert_asset(_asset(id_="a1"))
        db.upsert_asset(_asset(id_="a2"))
        db.upsert_edge(_edge(status="active"))
        db.upsert_edge(_edge(id_="e2", to_id="a3", status="stale"))
        c = db.counts()
        self.assertEqual(c["assets"], 2)
        self.assertEqual(c["edges"], 2)
        self.assertEqual(c["active_edges"], 1)


if __name__ == "__main__":
    unittest.main()
