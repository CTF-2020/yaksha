"""Tests for the correlation (mediator) engine.

Run:  python -m unittest test_correlator   (stdlib only, no pytest needed)

They exercise the three layers independently — taxonomy normalization, the pure
correlation engine, and the report mapper — plus the verdict logic that is the
whole point of the engine (does static+runtime agreement produce a confirmed
verdict, does an unmodeled scan hit produce a blind spot, etc.).
"""
from __future__ import annotations

import os
import subprocess
import sys
import unittest

from correlator import engine, mapper, taxonomy
from correlator.model import SourceKind, Verdict


# ── Fixtures: minimal but realistic saved-report dicts ────────────────────────
def _sast_report():
    return {
        "id": "r_sast", "title": "SAST · shop-api", "methodology": "sast",
        "categories": [
            {"id": "PY-SQL-001", "name": "SQL Injection", "risk": "High",
             "_source": "SAST", "cwe": "CWE-89",
             "affected_components": ["services/search_users.py:42"],
             "remediation": "Use parameterized queries.",
             "threats": [{"name": "services/search_users.py:42",
                          "description": "cursor.execute(f\"...{q}\")"}]},
            {"id": "PY-CRYPTO-003", "name": "Weak Hash (MD5)", "risk": "Medium",
             "_source": "SAST", "cwe": "CWE-328",
             "affected_components": ["auth/tokens.py:11"],
             "remediation": "Use SHA-256 or bcrypt."},
        ],
    }


def _dast_report():
    return {
        "id": "r_dast", "title": "DAST · shop-api", "methodology": "dast",
        "categories": [
            {"id": "DAST-SQLI", "name": "SQL Injection", "risk": "High",
             "_source": "DAST", "cwe": "CWE-89",
             "affected_components": ["https://shop.test/api/users/search?q= [q]"],
             "remediation": "Parameterize the query.",
             "threats": [{"name": "https://shop.test/api/users/search?q= [q]",
                          "description": "error-based SQLi confirmed"}]},
            {"id": "DAST-HEADERS", "name": "Missing Security Headers", "risk": "Low",
             "_source": "DAST", "cwe": "CWE-16",
             "affected_components": ["https://shop.test/"]},
        ],
    }


def _codemodel_report(reachability=None, component="services/search_users.py:42",
                       risk="Critical", business_impact=None):
    cat = {
        "id": "CM-001", "name": "SQL Injection", "risk": risk,
        "_source": "CODEMODEL", "cwe": "CWE-89",
        "affected_components": [component],
        "reachability": reachability or {
            "confirmed": True, "unauthenticated": True, "tainted": True,
            "min_hops": 0, "agent_tool": False, "sink_confidence": "high",
        },
    }
    if business_impact:
        cat["business_impact"] = business_impact
    return {
        "id": "r_cm", "title": "Code Model · shop-api", "methodology": "codemodel",
        "categories": [cat],
    }


def _sbom_report(component="pyyaml@5.3.1"):
    return {
        "id": "r_sbom", "title": "SBOM Analysis — bom.json", "methodology": "SBOM",
        "categories": [
            {"id": "SBOM-HIGH", "name": "Vulnerable Components — High", "risk": "High",
             "_source": "SBOM",
             "affected_components": [component],
             "threats": [{"name": f"YAML-EXEC in {component}",
                          "description": "Code execution via unsafe yaml.load()",
                          "attack_vector": "Exploiting known vulnerability CVE-2017-18342"}]},
        ],
    }


def _codemodel_sink_report(dep_root="yaml", dep_name="yaml.load",
                           authenticated=False, tainted=True, hops=0):
    """A codemodel report whose structured scan_metadata.attack_surface names
    one reachable call into ``dep_root`` — the shape annotate_dependency_
    reachability actually reads (see codemodel/mapper.py's `deps` field)."""
    return {
        "id": "r_cm2", "title": "Code Model · shop-api", "methodology": "codemodel",
        "categories": [
            {"id": "CM-DESER", "name": "Insecure Deserialization", "risk": "High",
             "_source": "CODEMODEL", "cwe": "CWE-502",
             "affected_components": [f"POST /import → {dep_name} (app.py:88)"]},
        ],
        "scan_metadata": {"attack_surface": [{
            "method": "POST", "path": "/import", "handler": "import_view",
            "file": "app.py", "line": 80, "framework": "flask", "kind": "http",
            "authenticated": authenticated, "controls": [], "sinks": [],
            "deps": [{"root": dep_root, "name": dep_name, "file": "app.py",
                      "line": 88, "hops": hops, "tainted": tainted}],
        }]},
    }


def _threat_model_report():
    return {
        "id": "r_tm", "title": "Threat Model · shop-api", "methodology": "owasp",
        "categories": [
            {"id": "WEB-A03", "name": "Injection", "risk": "High",
             "affected_components": ["Search service", "User database"],
             "mitigations": [{"action": "Enforce parameterized queries everywhere."}],
             "notes": "OWASP: A03:2021"},
            {"id": "WEB-A09", "name": "Security Logging and Monitoring Failures",
             "risk": "Medium",
             "affected_components": ["API gateway"],
             "mitigations": [{"action": "Centralize audit logging."}]},
        ],
    }


def _incident_report(locus="services/search_users.py:42", severity="Medium"):
    """A production-incident report shaped by incidents.build_incident_report
    (methodology="incident", category tagged _source="INCIDENT") -- same
    shape a real POST /api/v1/incidents call produces."""
    return {
        "id": "r_inc", "title": "Production Incident · SQL Injection", "methodology": "incident",
        "categories": [
            {"id": "INC-001", "name": "SQL Injection", "risk": severity,
             "_source": "INCIDENT", "cwe": "CWE-89",
             "affected_components": [locus],
             "notes": "Observed in production via WAF on 2026-08-01T00:00:00Z.",
             "incident_source": "waf", "detected_at": "2026-08-01T00:00:00Z"},
        ],
    }


# ── Taxonomy ──────────────────────────────────────────────────────────────────
class TestTaxonomy(unittest.TestCase):
    def test_extract_cwes(self):
        self.assertEqual(taxonomy.extract_cwes("CWE-89"), frozenset({"CWE-89"}))
        self.assertEqual(taxonomy.extract_cwes("see cwe 79 and CWE-352"),
                         frozenset({"CWE-79", "CWE-352"}))
        self.assertEqual(taxonomy.extract_cwes(""), frozenset())

    def test_extract_owasp(self):
        self.assertEqual(taxonomy.extract_owasp("WEB-A03"), "WEB-A03")
        self.assertEqual(taxonomy.extract_owasp("API-API7"), "API-API7")
        self.assertEqual(taxonomy.extract_owasp("", "OWASP: A3:2021"), "WEB-A03")

    def test_resolve_family_cwe_wins(self):
        slug, _ = taxonomy.resolve_family("some odd title", frozenset({"CWE-89"}), "")
        self.assertEqual(slug, "sql-injection")

    def test_keyword_beats_owasp_category(self):
        # A concrete keyword is more specific than a broad OWASP category, so it
        # wins even when an (umbrella) category is also present.
        self.assertEqual(taxonomy.resolve_family("Reflected XSS in search",
                                                 frozenset(), "WEB-A03")[0], "xss")
        self.assertEqual(taxonomy.resolve_family("Reflected XSS in search",
                                                 frozenset(), "")[0], "xss")

    def test_owasp_only_is_category_bucket(self):
        # An OWASP-only finding stays an umbrella bucket rather than being forced
        # into one arbitrary child family (A03 is not "SQL Injection").
        slug, _ = taxonomy.resolve_family("Injection", frozenset(), "WEB-A03")
        self.assertEqual(slug, "owasp:WEB-A03")

    def test_multi_cwe_resolution_is_declaration_order(self):
        # A finding carrying several CWEs resolves to the first family in
        # declaration order that shares one — deterministic, not set-order luck.
        fs = frozenset({"CWE-89", "CWE-79", "CWE-352"})  # sqli / xss / csrf
        self.assertEqual(taxonomy.resolve_family("mixed", fs, "")[0], "sql-injection")

    def test_multi_cwe_deterministic_across_hash_seeds(self):
        # Regression: set iteration order used to depend on PYTHONHASHSEED, so the
        # same multi-CWE finding could resolve differently across app restarts.
        code = ("from correlator import taxonomy as t;"
                "print(t.resolve_family('m',"
                " frozenset({'CWE-89','CWE-79','CWE-352'}), '')[0])")
        cwd = os.path.dirname(os.path.abspath(__file__)) or "."
        outs = set()
        for seed in ("0", "1", "2", "3", "4"):
            env = {**os.environ, "PYTHONHASHSEED": seed}
            r = subprocess.run([sys.executable, "-c", code], capture_output=True,
                               text=True, env=env, cwd=cwd)
            outs.add(r.stdout.strip())
        self.assertEqual(outs, {"sql-injection"})

    def test_resolve_family_unknown_singleton(self):
        slug, _ = taxonomy.resolve_family("Totally novel weakness", frozenset(), "")
        self.assertTrue(slug.startswith("title:"))

    def test_locus_tokens_bridge_file_and_url(self):
        code = taxonomy.locus_tokens("services/search_users.py:42")
        url = taxonomy.locus_tokens("https://shop.test/api/users/search?q= [q]")
        self.assertIn("search", code & url)
        self.assertIn("users", code & url)

    def test_locus_related(self):
        a = taxonomy.locus_tokens("services/search_users.py:42")
        b = taxonomy.locus_tokens("/api/users/search?q=")
        self.assertTrue(taxonomy.locus_related(a, b))
        c = taxonomy.locus_tokens("billing/invoice_export.py:9")
        self.assertFalse(taxonomy.locus_related(a, c))
        # unknown locus (design finding) defers to family match
        self.assertTrue(taxonomy.locus_related(a, frozenset()))


# ── Engine ────────────────────────────────────────────────────────────────────
class TestEngine(unittest.TestCase):
    def test_source_kind_detection(self):
        obs = engine.observe_report(_sast_report())
        self.assertTrue(all(o.kind is SourceKind.CODE for o in obs))
        obs = engine.observe_report(_dast_report())
        self.assertTrue(all(o.kind is SourceKind.RUNTIME for o in obs))
        obs = engine.observe_report(_threat_model_report())
        self.assertTrue(all(o.kind is SourceKind.DESIGN for o in obs))

    def test_confirmed_exploitable(self):
        findings = engine.correlate([_sast_report(), _dast_report()])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.verdict, Verdict.CONFIRMED_EXPLOITABLE)
        self.assertEqual(sqli.source_count, 2)
        self.assertGreaterEqual(sqli.confidence, 0.79)
        self.assertEqual(sqli.severity, "High")

    def test_confirmed_escalates_severity(self):
        # Same SQLi but each tool scored it only Medium -> confirmed floors at High.
        sast = _sast_report()
        dast = _dast_report()
        sast["categories"][0]["risk"] = "Medium"
        dast["categories"][0]["risk"] = "Medium"
        findings = engine.correlate([sast, dast])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.base_severity, "Medium")
        self.assertEqual(sqli.severity, "High")

    def test_corroborated_design_plus_code(self):
        findings = engine.correlate([_sast_report(), _threat_model_report()])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.verdict, Verdict.CORROBORATED)
        self.assertEqual(sqli.kinds, {SourceKind.CODE, SourceKind.DESIGN})

    def test_incident_source_kind_detection(self):
        obs = engine.observe_report(_incident_report())
        self.assertTrue(all(o.kind is SourceKind.INCIDENT for o in obs))

    def test_incident_alone_is_actively_exploited(self):
        # No scanner ever modeled or found this -- a lone incident report is
        # still the most urgent thing in the backlog, standing on its own.
        findings = engine.correlate([_incident_report()])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.verdict, Verdict.ACTIVELY_EXPLOITED)
        self.assertEqual(sqli.kinds, {SourceKind.INCIDENT})

    def test_incident_outranks_confirmed_exploitable(self):
        # SAST+DAST alone would be confirmed_exploitable; adding a real
        # production incident on the same locus must escalate past it.
        findings = engine.correlate([_sast_report(), _dast_report(), _incident_report()])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.verdict, Verdict.ACTIVELY_EXPLOITED)
        self.assertEqual(sqli.kinds, {SourceKind.CODE, SourceKind.RUNTIME, SourceKind.INCIDENT})

    def test_incident_floors_severity_at_critical(self):
        # The incident report itself only rated this Medium -- the verdict
        # still floors severity at Critical, same convention as
        # confirmed_exploitable flooring at High.
        findings = engine.correlate([_incident_report(severity="Medium")])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.base_severity, "Medium")
        self.assertEqual(sqli.severity, "Critical")

    def test_incident_confidence_is_near_certain_regardless_of_source_count(self):
        alone = engine.correlate([_incident_report()])[0]
        multi = engine.correlate([_sast_report(), _dast_report(), _incident_report()])[0]
        self.assertEqual(alone.confidence, 0.97)
        self.assertEqual(multi.confidence, 0.97)
        self.assertIn("production incident", alone.confidence_reason.lower())

    def test_incident_outranks_confirmed_in_priority_ordering(self):
        # findings are sorted by -priority; the actively_exploited sql-injection
        # cluster (verdict bump 3.0 + near-max confidence) must sort ahead of
        # the unrelated crypto-failure blind_spot from the same SAST report.
        findings = engine.correlate([_sast_report(), _dast_report(), _incident_report()])
        self.assertEqual(findings[0].family, "sql-injection")
        self.assertEqual(findings[0].verdict, Verdict.ACTIVELY_EXPLOITED)

    def test_blind_spot_code_only(self):
        # MD5 crypto finding exists only in SAST, unmodeled -> blind spot.
        findings = engine.correlate([_sast_report(), _dast_report()])
        crypto = next(f for f in findings if f.family == "crypto-failure")
        self.assertEqual(crypto.verdict, Verdict.BLIND_SPOT)
        self.assertEqual(crypto.source_count, 1)

    def test_exploitability_absent_without_codemodel_evidence(self):
        # Two-tool agreement alone (SAST + DAST) says nothing about reachability;
        # neither carries code-model facts, so the score must stay at 0 — not
        # inferred from the CONFIRMED_EXPLOITABLE verdict.
        findings = engine.correlate([_sast_report(), _dast_report()])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.verdict, Verdict.CONFIRMED_EXPLOITABLE)
        self.assertEqual(sqli.exploitability, 0.0)
        self.assertEqual(sqli.exploitability_reason, "")

    def test_codemodel_reachability_merges_and_scores(self):
        # The code model confirms the same SQLi site the SAST pattern match found;
        # loci overlap so they cluster, and the cluster picks up the reachability
        # facts even though the SAST observation itself carries none.
        sast = _sast_report()
        sast["categories"] = [sast["categories"][0]]  # keep only the SQLi finding
        findings = engine.correlate([sast, _codemodel_report()])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.source_count, 1)  # both observations are SourceKind.CODE
        self.assertGreater(sqli.exploitability, 0.0)
        self.assertIn("unauthenticated", sqli.exploitability_reason)
        self.assertIn("attacker-controlled", sqli.exploitability_reason)

    def test_exploitability_outranks_pattern_match_at_equal_severity_and_verdict(self):
        # Same family, same severity, same (blind-spot) verdict, same 1-source
        # confidence — the only difference is code-model-confirmed reachability.
        # It alone must be what decides priority order.
        reachable_sast = _sast_report()
        reachable_sast["categories"] = [reachable_sast["categories"][0]]
        reachable_sast["categories"][0]["risk"] = "High"

        unreachable = {
            "id": "r_sast2", "title": "SAST · billing", "methodology": "sast",
            "categories": [
                {"id": "PY-SQL-002", "name": "SQL Injection", "risk": "High",
                 "_source": "SAST", "cwe": "CWE-89",
                 "affected_components": ["billing/invoice_export.py:9"]},
            ],
        }

        findings = engine.correlate(
            [reachable_sast, _codemodel_report(risk="High"), unreachable])
        confirmed = next(f for f in findings
                          if any("search_users" in o.locus_label for o in f.observations))
        pattern_only = next(f for f in findings
                             if any("invoice_export" in o.locus_label for o in f.observations))

        self.assertEqual(confirmed.severity, pattern_only.severity)
        self.assertEqual(confirmed.verdict, pattern_only.verdict)
        self.assertEqual(confirmed.confidence, pattern_only.confidence)
        self.assertEqual(pattern_only.exploitability, 0.0)
        self.assertGreater(confirmed.exploitability, pattern_only.exploitability)
        self.assertGreater(confirmed.priority, pattern_only.priority)

    def test_business_impact_absent_without_tagged_evidence(self):
        # Neither observation carries a business_impact tag (no fixture sets
        # one), so the score must stay 0 -- not inferred from locus text.
        findings = engine.correlate([_sast_report(), _dast_report()])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.business_impact, 0.0)
        self.assertEqual(sqli.business_impact_reason, "")

    def test_business_impact_merges_and_scores(self):
        # The code model tags the same SQLi site as touching payments; the
        # cluster picks up that tag even though the SAST observation itself
        # carries none.
        sast = _sast_report()
        sast["categories"] = [sast["categories"][0]]
        tag = {"tier": "critical", "score": 1.0,
               "reason": "asset/route name matches 'payment' (critical-impact keyword)"}
        findings = engine.correlate([sast, _codemodel_report(business_impact=tag)])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.business_impact, 1.0)
        self.assertIn("payment", sqli.business_impact_reason)

    def test_business_impact_outranks_untagged_at_equal_everything_else(self):
        # Same family, same severity, same verdict, same confidence, same
        # (absent) exploitability -- only the business-impact tag differs, and
        # it alone must decide priority order.
        payments_sast = _sast_report()
        payments_sast["categories"] = [payments_sast["categories"][0]]
        payments_sast["categories"][0]["risk"] = "High"
        tag = {"tier": "critical", "score": 1.0, "reason": "asset/route name matches 'payment'"}

        support_sast = {
            "id": "r_sast2", "title": "SAST · support", "methodology": "sast",
            "categories": [
                {"id": "PY-SQL-002", "name": "SQL Injection", "risk": "High",
                 "_source": "SAST", "cwe": "CWE-89",
                 "affected_components": ["billing/invoice_export.py:9"]},
            ],
        }

        findings = engine.correlate([
            payments_sast, _codemodel_report(risk="High", business_impact=tag), support_sast])
        tagged = next(f for f in findings
                       if any("search_users" in o.locus_label for o in f.observations))
        untagged = next(f for f in findings
                         if any("invoice_export" in o.locus_label for o in f.observations))

        self.assertEqual(tagged.severity, untagged.severity)
        self.assertEqual(tagged.verdict, untagged.verdict)
        self.assertEqual(tagged.confidence, untagged.confidence)
        self.assertEqual(untagged.business_impact, 0.0)
        self.assertGreater(tagged.business_impact, untagged.business_impact)
        self.assertGreater(tagged.priority, untagged.priority)

    # ── Rule-catalog confidence corroboration ───────────────────────────────
    def test_matched_rule_risk_rating_bumps_single_source_confidence(self):
        rated = _sast_report()
        rated["categories"] = [rated["categories"][0]]   # SQLi only
        rated["categories"][0]["rule_risk_rating"] = {
            "confidence": "HIGH", "likelihood": "HIGH", "impact": "MEDIUM", "matched_rules": 2}
        unrated = _sast_report()
        unrated["id"] = "r_sast2"
        unrated["categories"] = [unrated["categories"][0]]   # same finding, no rating

        rated_finding = engine.correlate([rated])[0]
        unrated_finding = engine.correlate([unrated])[0]

        self.assertEqual(unrated_finding.confidence, 0.4)   # base single-source confidence
        self.assertGreater(rated_finding.confidence, unrated_finding.confidence)
        self.assertIn("rule-catalog", rated_finding.confidence_reason.lower())

    def test_no_rule_risk_rating_leaves_confidence_and_reason_untouched(self):
        sqli = engine.correlate([_sast_report()])[0]
        self.assertEqual(sqli.confidence, 0.4)
        self.assertEqual(sqli.confidence_reason, "")

    def test_rule_catalog_bump_never_exceeds_code_plus_runtime_bonus(self):
        # A single-source finding with the maximum possible catalog bump
        # (three HIGH-rated dimensions, +0.12) must still read as LESS
        # confident than genuine two-source (code+runtime) corroboration with
        # no catalog match at all -- a catalog citation should never let a
        # single-source finding masquerade as cross-tool-proven.
        rated_single = _sast_report()
        rated_single["categories"] = [rated_single["categories"][0]]
        rated_single["categories"][0]["rule_risk_rating"] = {
            "confidence": "HIGH", "likelihood": "HIGH", "impact": "HIGH", "matched_rules": 5}
        plain_sast = _sast_report()
        plain_sast["categories"] = [plain_sast["categories"][0]]
        dast = _dast_report()
        dast["categories"] = [dast["categories"][0]]

        rated_only = engine.correlate([rated_single])[0]
        confirmed_multi_no_bump = engine.correlate([plain_sast, dast])[0]
        self.assertLess(rated_only.confidence, confirmed_multi_no_bump.confidence)

    def test_design_gap_design_only(self):
        # A09 logging is modeled but no scanner produced evidence -> design gap.
        findings = engine.correlate([_sast_report(), _dast_report(),
                                     _threat_model_report()])
        logging = next(f for f in findings if f.family == "logging-monitoring")
        self.assertEqual(logging.verdict, Verdict.DESIGN_GAP)

    def test_three_way_all_sources(self):
        findings = engine.correlate([_sast_report(), _dast_report(),
                                     _threat_model_report()])
        sqli = next(f for f in findings if f.family == "sql-injection")
        self.assertEqual(sqli.verdict, Verdict.CONFIRMED_EXPLOITABLE)
        self.assertEqual(sqli.source_count, 3)
        self.assertEqual(sqli.confidence, 1.0)

    def test_priority_ordering(self):
        findings = engine.correlate([_sast_report(), _dast_report(),
                                     _threat_model_report()])
        priorities = [f.priority for f in findings]
        self.assertEqual(priorities, sorted(priorities, reverse=True))
        # the confirmed-exploitable SQLi must sort first
        self.assertEqual(findings[0].family, "sql-injection")

    def test_distinct_loci_not_merged(self):
        # Two SAST SQLi at unrelated files should not collapse into one cluster.
        rep = {
            "id": "r", "title": "SAST", "methodology": "sast",
            "categories": [
                {"id": "A", "name": "SQL Injection", "risk": "High", "_source": "SAST",
                 "cwe": "CWE-89", "affected_components": ["a/search_users.py:1"]},
                {"id": "B", "name": "SQL Injection", "risk": "High", "_source": "SAST",
                 "cwe": "CWE-89", "affected_components": ["z/billing_invoice.py:1"]},
            ],
        }
        other = {"id": "o", "title": "TM", "methodology": "owasp",
                 "categories": [{"id": "WEB-A03", "name": "Injection", "risk": "High",
                                 "affected_components": ["misc"]}]}
        findings = engine.correlate([rep, other])
        sqli = [f for f in findings if f.family == "sql-injection"]
        self.assertEqual(len(sqli), 2)

    def test_owasp_umbrella_corroborates_multiple_children(self):
        # One modeled "A03 Injection" must corroborate BOTH a SQLi site and a
        # command-injection site — not just whichever family sorts first.
        sast = {"id": "s", "title": "SAST", "methodology": "sast", "categories": [
            {"id": "1", "name": "SQL Injection", "risk": "High", "_source": "SAST",
             "cwe": "CWE-89", "affected_components": ["x/a.py:1"]},
            {"id": "2", "name": "OS Command Injection", "risk": "High", "_source": "SAST",
             "cwe": "CWE-78", "affected_components": ["y/b.py:1"]},
        ]}
        tm = {"id": "t", "title": "TM", "methodology": "owasp", "categories": [
            {"id": "WEB-A03", "name": "Injection", "risk": "High",
             "affected_components": ["all inputs"]},
        ]}
        findings = engine.correlate([sast, tm])
        sqli = next(f for f in findings if f.family == "sql-injection")
        cmd = next(f for f in findings if f.family == "command-injection")
        self.assertEqual(sqli.verdict, Verdict.CORROBORATED)
        self.assertEqual(cmd.verdict, Verdict.CORROBORATED)
        # the umbrella bucket was consumed, not left dangling as a phantom finding
        self.assertFalse([f for f in findings if f.family.startswith("owasp:")])

    def test_empty_locus_evidence_not_over_merged(self):
        # A locus-less evidence finding must not link to every sibling in its
        # family and fabricate one over-broad cluster.
        rep = {"id": "r", "title": "SAST", "methodology": "sast", "categories": [
            {"id": "A", "name": "SQL Injection", "risk": "High", "_source": "SAST",
             "cwe": "CWE-89", "affected_components": ["a/search_users.py:1"]},
            {"id": "B", "name": "SQL Injection", "risk": "High", "_source": "SAST",
             "cwe": "CWE-89", "affected_components": []},  # no locus at all
        ]}
        findings = engine.correlate([rep])
        sqli = [f for f in findings if f.family == "sql-injection"]
        self.assertEqual(len(sqli), 2)

    # ── SBOM (vulnerable-dependency) correlation ────────────────────────────
    def test_sbom_classified_as_code_evidence(self):
        obs = engine.observe_report(_sbom_report())
        self.assertEqual(obs[0].kind, SourceKind.CODE)
        self.assertEqual(obs[0].family, "vulnerable-components")

    def test_sbom_alone_is_a_blind_spot_with_unknown_exploitability(self):
        findings = engine.correlate([_sbom_report(), _threat_model_report()])
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertEqual(dep.verdict, Verdict.BLIND_SPOT)
        self.assertEqual(dep.exploitability, 0.0)

    def test_sbom_package_reachable_via_codemodel_dep_gets_scored(self):
        # pyyaml -> imported as `yaml`; a codemodel dep-call naming `yaml.load`
        # reachable from an unauthenticated POST should attach a real
        # exploitability score to the otherwise-unproven SBOM finding.
        findings = engine.correlate(
            [_sbom_report("pyyaml@5.3.1"), _codemodel_sink_report("yaml", "yaml.load")])
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertGreater(dep.exploitability, 0.0)
        self.assertIn("unauthenticated", dep.exploitability_reason.lower())

    def test_sbom_package_reachable_via_non_sink_call_still_scored(self):
        # This is the fix for the earlier limitation: `requests` has no
        # dangerous-sink pattern of its own (no eval/sql/deserialize shape),
        # but a plain `requests.get(...)` call reachable from an entry point
        # must still score, since dep tracking runs independently of Sink.
        findings = engine.correlate(
            [_sbom_report("requests@2.25.0"),
             _codemodel_sink_report("requests", "requests.get")])
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertGreater(dep.exploitability, 0.0)

    def test_sbom_package_not_reachable_anywhere_stays_unscored(self):
        # `django` never shows up as a reachable dependency call here, so no
        # reachability should be fabricated for it.
        findings = engine.correlate(
            [_sbom_report("django@3.1.0"), _codemodel_sink_report("yaml", "yaml.load")])
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertEqual(dep.exploitability, 0.0)

    def test_annotate_dependency_reachability_does_not_mutate_input(self):
        reports = [_sbom_report("pyyaml@5.3.1"), _codemodel_sink_report("yaml", "yaml.load")]
        original_sbom_cat = reports[0]["categories"][0]
        engine.annotate_dependency_reachability(reports)
        self.assertNotIn("reachability", original_sbom_cat)

    def test_dependency_reachability_is_per_component_not_whole_bucket(self):
        # sbom_to_categories buckets every vulnerable component of a severity
        # into ONE category -- with two components here (only one reachable),
        # the per-component breakdown must name just the reachable one, not
        # both, even though the category-level `reachability` (used for
        # scoring) still merges across whichever components ARE reachable.
        multi = _sbom_report("pyyaml@5.3.1")
        multi["categories"][0]["affected_components"] = ["pyyaml@5.3.1", "django@3.1.0"]
        reports = engine.annotate_dependency_reachability(
            [multi, _codemodel_sink_report("yaml", "yaml.load")])
        cat = next(r for r in reports if r["id"] == "r_sbom")["categories"][0]
        self.assertIn("dependency_reachability", cat)
        self.assertIn("pyyaml", cat["dependency_reachability"])
        self.assertNotIn("django", cat["dependency_reachability"])
        # category-level reachability (scoring input) is unchanged behavior:
        # still a merge across whatever WAS found reachable.
        self.assertTrue(cat["reachability"])

    def test_dependency_reachability_absent_when_nothing_reachable(self):
        reports = engine.annotate_dependency_reachability(
            [_sbom_report("django@3.1.0"), _codemodel_sink_report("yaml", "yaml.load")])
        cat = next(r for r in reports if r["id"] == "r_sbom")["categories"][0]
        self.assertNotIn("dependency_reachability", cat)
        self.assertNotIn("reachability", cat)

    def test_correlated_finding_carries_dependency_reachability_through(self):
        multi = _sbom_report("pyyaml@5.3.1")
        multi["categories"][0]["affected_components"] = ["pyyaml@5.3.1", "django@3.1.0"]
        findings = engine.correlate([multi, _codemodel_sink_report("yaml", "yaml.load")])
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertIn("pyyaml", dep.dependency_reachability)
        self.assertNotIn("django", dep.dependency_reachability)

    def test_finding_with_no_dependency_reachability_has_empty_dict(self):
        findings = engine.correlate([_sbom_report(), _threat_model_report()])
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertEqual(dep.dependency_reachability, {})

    # ── EPSS / CISA KEV ──────────────────────────────────────────────────────
    def test_observation_carries_cves_extracted_from_text(self):
        obs = engine.observe_report(_sbom_report())
        self.assertEqual(obs[0].cves, frozenset({"CVE-2017-18342"}))

    def test_observation_without_cve_has_empty_frozenset(self):
        obs = engine.observe_report(_sast_report())
        self.assertEqual(obs[0].cves, frozenset())

    def test_epss_kev_absent_without_lookup_table(self):
        # No table supplied at all (the default) -- score must stay 0, not be
        # inferred from anything else, same "unknown, not fabricated" rule as
        # exploitability/business_impact.
        findings = engine.correlate([_sbom_report(), _threat_model_report()])
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertEqual(dep.epss_kev, 0.0)
        self.assertEqual(dep.epss_kev_reason, "")

    def test_epss_kev_absent_when_cve_not_in_table(self):
        findings = engine.correlate(
            [_sbom_report(), _threat_model_report()],
            epss_kev_lookup={"CVE-9999-00001": {"cve": "CVE-9999-00001", "epss": 0.9,
                                                 "epss_percentile": 0.9, "kev": False,
                                                 "kev_date_added": None, "kev_ransomware": ""}})
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertEqual(dep.epss_kev, 0.0)

    def test_epss_kev_scores_from_raw_epss_probability(self):
        findings = engine.correlate(
            [_sbom_report(), _threat_model_report()],
            epss_kev_lookup={"CVE-2017-18342": {"cve": "CVE-2017-18342", "epss": 0.0561,
                                                 "epss_percentile": 0.921, "kev": False,
                                                 "kev_date_added": None, "kev_ransomware": ""}})
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertAlmostEqual(dep.epss_kev, 0.0561, places=3)
        self.assertIn("CVE-2017-18342", dep.epss_kev_reason)
        self.assertIn("EPSS", dep.epss_kev_reason)
        self.assertNotIn("KEV", dep.epss_kev_reason)

    def test_epss_kev_floors_at_point_nine_when_kev_listed(self):
        # A raw EPSS probability of 5.6% would score far lower than this --
        # CISA-confirmed active exploitation must dominate the raw prediction.
        findings = engine.correlate(
            [_sbom_report(), _threat_model_report()],
            epss_kev_lookup={"CVE-2017-18342": {"cve": "CVE-2017-18342", "epss": 0.0561,
                                                 "epss_percentile": 0.921, "kev": True,
                                                 "kev_date_added": "2023-01-05",
                                                 "kev_ransomware": "Known"}})
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertEqual(dep.epss_kev, 0.9)
        self.assertIn("Known Exploited Vulnerabilities", dep.epss_kev_reason)
        self.assertIn("2023-01-05", dep.epss_kev_reason)
        self.assertIn("ransomware", dep.epss_kev_reason.lower())

    def test_epss_kev_contributes_additively_to_priority(self):
        no_intel = engine.correlate([_sbom_report(), _threat_model_report()])
        with_intel = engine.correlate(
            [_sbom_report(), _threat_model_report()],
            epss_kev_lookup={"CVE-2017-18342": {"cve": "CVE-2017-18342", "epss": None,
                                                 "epss_percentile": None, "kev": True,
                                                 "kev_date_added": "2023-01-05", "kev_ransomware": ""}})
        dep_plain = next(f for f in no_intel if f.family == "vulnerable-components")
        dep_kev = next(f for f in with_intel if f.family == "vulnerable-components")
        # Same severity/verdict/confidence -- the only difference is the KEV hit.
        self.assertEqual(dep_plain.severity, dep_kev.severity)
        self.assertEqual(dep_plain.verdict, dep_kev.verdict)
        self.assertGreater(dep_kev.priority, dep_plain.priority)
        self.assertAlmostEqual(dep_kev.priority - dep_plain.priority, 0.9, places=3)

    def test_epss_kev_picks_worst_across_multiple_cves_in_cluster(self):
        multi = _sbom_report("pyyaml@5.3.1")
        multi["categories"][0]["threats"].append({
            "name": "SECOND-CVE in other@1.0", "description": "unrelated flaw",
            "attack_vector": "Exploiting known vulnerability CVE-2020-00001"})
        findings = engine.correlate(
            [multi, _threat_model_report()],
            epss_kev_lookup={
                "CVE-2017-18342": {"cve": "CVE-2017-18342", "epss": 0.01, "epss_percentile": 0.1,
                                   "kev": False, "kev_date_added": None, "kev_ransomware": ""},
                "CVE-2020-00001": {"cve": "CVE-2020-00001", "epss": 0.87, "epss_percentile": 0.99,
                                   "kev": False, "kev_date_added": None, "kev_ransomware": ""},
            })
        dep = next(f for f in findings if f.family == "vulnerable-components")
        self.assertAlmostEqual(dep.epss_kev, 0.87, places=2)
        self.assertIn("CVE-2020-00001", dep.epss_kev_reason)


# ── Mapper ────────────────────────────────────────────────────────────────────
class TestMapper(unittest.TestCase):
    def _report(self):
        reports = [_sast_report(), _dast_report(), _threat_model_report()]
        findings = engine.correlate(reports)
        obs = sum(len(engine.observe_report(r)) for r in reports)
        sources = [{"id": r["id"], "title": r["title"],
                    "methodology": r["methodology"]} for r in reports]
        return mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": obs})

    def test_report_shape(self):
        rep = self._report()
        self.assertEqual(rep["methodology"], "correlation")
        self.assertTrue(rep["categories"])
        first = rep["categories"][0]
        for key in ("id", "name", "risk", "verdict", "confidence",
                    "corroboration", "threats", "mitigations", "affected_components"):
            self.assertIn(key, first)
        self.assertEqual(first["_source"], "CORRELATION")

    def test_verdict_counts_in_metadata(self):
        rep = self._report()
        meta = rep["scan_metadata"]
        self.assertGreaterEqual(meta["confirmed_exploitable"], 1)
        counts = meta["verdict_counts"]
        self.assertEqual(sum(counts.values()), meta["findings_total"])

    def test_summary_mentions_confirmed(self):
        rep = self._report()
        self.assertIn("confirmed exploitable", rep["summary"])

    def test_exploitability_surfaced_in_category(self):
        sast = _sast_report()
        sast["categories"] = [sast["categories"][0]]
        reports = [sast, _codemodel_report()]
        findings = engine.correlate(reports)
        obs = sum(len(engine.observe_report(r)) for r in reports)
        sources = [{"id": r["id"], "title": r["title"],
                    "methodology": r["methodology"]} for r in reports]
        rep = mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": obs})
        sqli = next(c for c in rep["categories"] if c["_source"] == "CORRELATION"
                    and "SQL Injection" in c["name"])
        self.assertGreater(sqli["exploitability"], 0.0)
        self.assertIn("unauthenticated", sqli["exploitability_reason"])
        self.assertIn("exploitability", sqli["notes"])

    def test_business_impact_surfaced_in_category(self):
        sast = _sast_report()
        sast["categories"] = [sast["categories"][0]]
        tag = {"tier": "critical", "score": 1.0,
               "reason": "asset/route name matches 'payment' (critical-impact keyword)"}
        reports = [sast, _codemodel_report(business_impact=tag)]
        findings = engine.correlate(reports)
        obs = sum(len(engine.observe_report(r)) for r in reports)
        sources = [{"id": r["id"], "title": r["title"],
                    "methodology": r["methodology"]} for r in reports]
        rep = mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": obs})
        sqli = next(c for c in rep["categories"] if c["_source"] == "CORRELATION"
                    and "SQL Injection" in c["name"])
        self.assertGreater(sqli["business_impact"], 0.0)
        self.assertIn("payment", sqli["business_impact_reason"])
        self.assertIn("business impact", sqli["notes"])

    def test_dependency_reachability_surfaced_in_category(self):
        multi = _sbom_report("pyyaml@5.3.1")
        multi["categories"][0]["affected_components"] = ["pyyaml@5.3.1", "django@3.1.0"]
        reports = [multi, _codemodel_sink_report("yaml", "yaml.load")]
        findings = engine.correlate(reports)
        obs = sum(len(engine.observe_report(r)) for r in reports)
        sources = [{"id": r["id"], "title": r["title"],
                    "methodology": r["methodology"]} for r in reports]
        rep = mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": obs})
        dep = next(c for c in rep["categories"] if c["_source"] == "CORRELATION"
                  and c.get("dependency_reachability"))
        self.assertIn("pyyaml", dep["dependency_reachability"])
        self.assertNotIn("django", dep["dependency_reachability"])
        self.assertIn("pyyaml", dep["description"])
        self.assertNotIn("django", dep["description"])

    def test_epss_kev_surfaced_in_category(self):
        reports = [_sbom_report(), _threat_model_report()]
        observations = []
        for r in reports:
            observations.extend(engine.observe_report(r))
        findings = engine.correlate_observations(
            observations,
            epss_kev_lookup={"CVE-2017-18342": {"cve": "CVE-2017-18342", "epss": 0.0561,
                                                 "epss_percentile": 0.921, "kev": True,
                                                 "kev_date_added": "2023-01-05", "kev_ransomware": "Known"}})
        sources = [{"id": r["id"], "title": r["title"],
                    "methodology": r["methodology"]} for r in reports]
        rep = mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": len(observations)})
        dep = next(c for c in rep["categories"] if c["_source"] == "CORRELATION"
                  and c.get("epss_kev"))
        self.assertEqual(dep["epss_kev"], 0.9)
        self.assertIn("CVE-2017-18342", dep["epss_kev_reason"])
        self.assertIn("real-world exploitation", dep["notes"])
        self.assertIn("real-world exploitation", dep["description"].lower())

    def test_ssvc_action_surfaced_in_category(self):
        # Actively-exploited + high severity should land on the most urgent
        # SSVC action; the field must be present and self-consistent.
        reports = [_incident_report(severity="Critical")]
        observations = engine.observe_report(reports[0])
        findings = engine.correlate_observations(observations)
        sources = [{"id": reports[0]["id"], "title": reports[0]["title"],
                    "methodology": reports[0]["methodology"]}]
        rep = mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": len(observations)})
        sqli = next(c for c in rep["categories"] if c["_source"] == "CORRELATION")
        self.assertIn("ssvc_action", sqli)
        self.assertIn(sqli["ssvc_action"], ("act", "attend", "track_star", "track"))
        self.assertIn("ssvc_decision_points", sqli)
        self.assertEqual(sqli["ssvc_decision_points"]["exploitation"], "active")
        self.assertIn("SSVC", sqli["notes"])
        self.assertIn(sqli["ssvc_action_label"], sqli["description"])

    def test_confidence_reason_surfaced_in_category(self):
        sast = _sast_report()
        sast["categories"] = [sast["categories"][0]]
        sast["categories"][0]["rule_risk_rating"] = {
            "confidence": "HIGH", "likelihood": "MEDIUM", "impact": "MEDIUM", "matched_rules": 2}
        findings = engine.correlate([sast])
        obs = engine.observe_report(sast)
        sources = [{"id": sast["id"], "title": sast["title"], "methodology": sast["methodology"]}]
        rep = mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": len(obs)})
        sqli = next(c for c in rep["categories"] if c["_source"] == "CORRELATION")
        self.assertTrue(sqli["confidence_reason"])
        self.assertIn("rule-catalog", sqli["confidence_reason"].lower())
        self.assertIn(sqli["confidence_reason"], sqli["notes"])

    def test_incident_verdict_and_kind_surfaced_in_category(self):
        reports = [_sast_report(), _dast_report(), _incident_report()]
        findings = engine.correlate(reports)
        obs = sum(len(engine.observe_report(r)) for r in reports)
        sources = [{"id": r["id"], "title": r["title"],
                    "methodology": r["methodology"]} for r in reports]
        rep = mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": obs})
        sqli = next(c for c in rep["categories"] if c["_source"] == "CORRELATION"
                    and "SQL Injection" in c["name"])
        self.assertEqual(sqli["verdict"], "actively_exploited")
        self.assertEqual(sqli["verdict_label"], "Actively exploited (production incident)")
        self.assertIn("Production incident", sqli["description"])
        self.assertIn("Production incident", sqli["notes"])

    def test_summary_and_recommendations_mention_actively_exploited(self):
        reports = [_incident_report(), _threat_model_report()]
        findings = engine.correlate(reports)
        obs = sum(len(engine.observe_report(r)) for r in reports)
        sources = [{"id": r["id"], "title": r["title"],
                    "methodology": r["methodology"]} for r in reports]
        rep = mapper.findings_to_report(
            findings, sources, {"report_title": "Corr", "observation_count": obs})
        self.assertIn("actively exploited", rep["summary"])
        self.assertEqual(rep["scan_metadata"]["actively_exploited"], 1)
        self.assertTrue(any("actively-exploited" in r for r in rep["recommendations"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
