"""_rules_mobile.py — OWASP Mobile Top 10 (2024) + Kubernetes Top 10 offline rules."""
MOBILE_RULES: list[dict] = [
    # ── M1 Improper Credential Usage ──────────────────────────────────────────
    {
        "id": "MOB-M1-01",
        "category": "M1",
        "question": "Are API keys, tokens, and credentials absent from the app binary and source code?",
        "rationale": "Hard-coded credentials in mobile binaries are trivially extracted with static analysis tools.",
        "severity": "Critical",
        "patterns_to_check": ["mobile", "ios", "android", "apk", "ipa", "react native", "flutter", "swift", "kotlin", "app"],
        "mitigations": [
            "Store all credentials in platform keychain (iOS) or KeyStore (Android) — never in source code or SharedPreferences",
            "Use backend-issued short-lived tokens rather than embedding long-lived API keys in the app",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m1-improper-credential-usage"],
    },
    {
        "id": "MOB-M1-02",
        "category": "M1",
        "question": "Are sensitive credentials stored in SharedPreferences/NSUserDefaults encrypted?",
        "rationale": "SharedPreferences and NSUserDefaults store data in cleartext by default — accessible on rooted/jailbroken devices.",
        "severity": "High",
        "patterns_to_check": ["shared preferences", "nsuserdefaults", "local storage", "user defaults", "android", "ios", "mobile"],
        "mitigations": [
            "Use EncryptedSharedPreferences (Android) or iOS Keychain for all sensitive data — never raw SharedPreferences/NSUserDefaults",
            "Avoid storing session tokens or credentials in any local storage not backed by platform security APIs",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m1-improper-credential-usage"],
    },
    # ── M2 Inadequate Supply Chain Security ──────────────────────────────────
    {
        "id": "MOB-M2-01",
        "category": "M2",
        "question": "Are third-party SDKs (analytics, advertising) reviewed for excessive permissions and data collection?",
        "rationale": "Ad and analytics SDKs commonly exfiltrate device data, location, and usage patterns without user awareness.",
        "severity": "High",
        "patterns_to_check": ["sdk", "third-party", "analytics", "advertising", "firebase", "mixpanel", "segment", "amplitude", "mobile"],
        "mitigations": [
            "Review permissions and data collection behaviour of all third-party SDKs before integration",
            "Pin SDK versions and monitor security advisories for embedded dependencies",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m2-inadequate-supply-chain-security"],
    },
    {
        "id": "MOB-M2-02",
        "category": "M2",
        "question": "Is app code signing enforced and are app updates integrity-verified?",
        "rationale": "Without code signing enforcement an attacker can inject malicious code into app updates.",
        "severity": "High",
        "patterns_to_check": ["code signing", "update", "ota", "over the air", "app store", "play store", "release", "distribution"],
        "mitigations": [
            "Enforce code signing on all app builds and reject apps with invalid signatures",
            "Verify OTA update packages with cryptographic signatures before applying",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m2-inadequate-supply-chain-security"],
    },
    # ── M3 Insecure Authentication / Authorization ────────────────────────────
    {
        "id": "MOB-M3-01",
        "category": "M3",
        "question": "Is certificate pinning implemented and resistant to bypass (Frida, SSLUnpinning)?",
        "rationale": "Without certificate pinning all mobile traffic is interceptable via MITM proxy on untrusted networks.",
        "severity": "High",
        "patterns_to_check": ["certificate", "ssl", "tls", "pinning", "mobile", "api", "https", "network"],
        "mitigations": [
            "Implement certificate pinning with backup pins — use a pinning library rather than manual implementation",
            "Test pinning against Frida and SSL unpinning scripts in QA; implement anti-tamper detection",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m3-insecure-authentication-authorization"],
    },
    {
        "id": "MOB-M3-02",
        "category": "M3",
        "question": "Is authentication state validated server-side on every API request — not trusted from client?",
        "rationale": "Client-side authentication state stored in the app can be trivially manipulated on rooted/jailbroken devices.",
        "severity": "Critical",
        "patterns_to_check": ["authentication", "login", "session", "token", "jwt", "mobile", "api", "auth"],
        "mitigations": [
            "Validate all authentication state server-side on every API request — never trust client-provided auth state",
            "Use short-lived access tokens with server-side session management and immediate revocation capability",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m3-insecure-authentication-authorization"],
    },
    # ── M4 Insufficient Input / Output Validation ─────────────────────────────
    {
        "id": "MOB-M4-01",
        "category": "M4",
        "question": "Are deep links and custom URL scheme parameters validated before processing?",
        "rationale": "Unvalidated deep link parameters can trigger unintended actions or expose sensitive app functionality.",
        "severity": "High",
        "patterns_to_check": ["deep link", "url scheme", "universal link", "app link", "intent", "deeplinking", "mobile"],
        "mitigations": [
            "Validate all deep link parameters against a strict allowlist before processing",
            "Require authentication before processing sensitive deep link actions — don't trust link source",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m4-insufficient-input-output-validation"],
    },
    {
        "id": "MOB-M4-02",
        "category": "M4",
        "question": "Are WebViews configured to restrict JavaScript bridge access to trusted URLs only?",
        "rationale": "WebViews with JavaScript bridge access loading untrusted URLs allow full app compromise via web content.",
        "severity": "Critical",
        "patterns_to_check": ["webview", "javascript", "web view", "hybrid", "cordova", "ionic", "capacitor", "mobile"],
        "mitigations": [
            "Disable JavaScript bridge for WebViews loading external or user-supplied URLs",
            "Allowlist permitted URLs for WebViews with JavaScript bridge access; reject any URL not on the allowlist",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m4-insufficient-input-output-validation"],
    },
    # ── M5 Insecure Communication ─────────────────────────────────────────────
    {
        "id": "MOB-M5-01",
        "category": "M5",
        "question": "Is HTTPS enforced for all network communication — no HTTP fallback or cleartext exceptions?",
        "rationale": "Mobile apps on public WiFi are trivially intercepted without TLS enforcement.",
        "severity": "Critical",
        "patterns_to_check": ["http", "network", "api", "communication", "mobile", "ios", "android", "backend"],
        "mitigations": [
            "Set NSAllowsArbitraryLoads = NO (iOS) and usesCleartextTraffic = false (Android) in app manifest",
            "Enforce HTTPS on all endpoints; reject any HTTP connection attempt at the network layer",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m5-insecure-communication"],
    },
    # ── M6 Inadequate Privacy Controls ───────────────────────────────────────
    {
        "id": "MOB-M6-01",
        "category": "M6",
        "question": "Does the app request only permissions necessary for its core functionality?",
        "rationale": "Excessive permission requests expose user data unnecessarily and undermine privacy.",
        "severity": "Medium",
        "patterns_to_check": ["permission", "location", "camera", "microphone", "contacts", "calendar", "mobile", "ios", "android"],
        "mitigations": [
            "Audit all permission requests — remove any not required for core app functionality",
            "Request permissions at the point of use with clear explanations; support operating without optional permissions",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m6-inadequate-privacy-controls"],
    },
    {
        "id": "MOB-M6-02",
        "category": "M6",
        "question": "Are sensitive screens flagged to prevent screenshots and app switcher exposure?",
        "rationale": "Without screen capture protection sensitive data (balance, PII) appears in the app switcher thumbnail.",
        "severity": "Medium",
        "patterns_to_check": ["screen", "screenshot", "banking", "payment", "sensitive", "pii", "mobile"],
        "mitigations": [
            "Set FLAG_SECURE (Android) or obscured content (iOS) on all screens displaying sensitive information",
            "Clear sensitive UI elements when the app goes to background to prevent app switcher exposure",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m6-inadequate-privacy-controls"],
    },
    # ── M7 Insufficient Binary Protections ───────────────────────────────────
    {
        "id": "MOB-M7-01",
        "category": "M7",
        "question": "Are release builds obfuscated and stripped of debug symbols?",
        "rationale": "Unobfuscated binaries allow attackers to reverse-engineer business logic and identify vulnerabilities.",
        "severity": "Medium",
        "patterns_to_check": ["binary", "obfuscation", "proguard", "r8", "release", "production", "android", "ios", "mobile"],
        "mitigations": [
            "Enable ProGuard/R8 (Android) or enable bitcode/strip debug symbols (iOS) for all release builds",
            "Remove any debug logs, test endpoints, or developer backdoors from production builds",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m7-insufficient-binary-protections"],
    },
    # ── M9 Insecure Data Storage ──────────────────────────────────────────────
    {
        "id": "MOB-M9-01",
        "category": "M9",
        "question": "Is PII and sensitive data stored locally encrypted with platform-backed keys?",
        "rationale": "Cleartext local storage (SQLite, files, SharedPreferences) is accessible on rooted/jailbroken devices.",
        "severity": "Critical",
        "patterns_to_check": ["sqlite", "local database", "local storage", "cache", "offline", "store", "mobile", "ios", "android"],
        "mitigations": [
            "Encrypt all local databases with SQLCipher; use platform keychain for encryption keys",
            "Audit all local writes for PII — prefer storing minimal data with short TTLs",
        ],
        "references": ["https://owasp.org/www-project-mobile-top-10/2024-risks/m9-insecure-data-storage"],
    },
    # ── K01 Kubernetes Insecure Workload Configurations ───────────────────────
    {
        "id": "K8S-K01-01",
        "category": "K01",
        "question": "Are Kubernetes containers configured to run as non-root with no privilege escalation?",
        "rationale": "Root containers with privilege escalation can escape to the host node on kernel vulnerability.",
        "severity": "Critical",
        "patterns_to_check": ["kubernetes", "k8s", "container", "pod", "docker", "helm", "deploy", "workload"],
        "mitigations": [
            "Set runAsNonRoot: true and allowPrivilegeEscalation: false in all pod security contexts",
            "Apply PodSecurityAdmission at Restricted level; block privileged containers via admission controller",
        ],
        "references": ["https://owasp.org/www-project-kubernetes-top-ten/2022/en/src/K01-insecure-workload-configurations"],
    },
    {
        "id": "K8S-K01-02",
        "category": "K01",
        "question": "Are CPU and memory resource limits set on all pods to prevent resource exhaustion?",
        "rationale": "Pods without resource limits can exhaust node resources causing DoS for other workloads.",
        "severity": "High",
        "patterns_to_check": ["kubernetes", "k8s", "pod", "container", "resource", "limits", "requests", "node"],
        "mitigations": [
            "Set both requests and limits for CPU and memory on all containers — use LimitRange to enforce defaults",
            "Use VPA (Vertical Pod Autoscaler) to right-size resource allocations based on actual usage",
        ],
        "references": ["https://owasp.org/www-project-kubernetes-top-ten/2022/en/src/K01-insecure-workload-configurations"],
    },
    # ── K03 Overly Permissive RBAC ────────────────────────────────────────────
    {
        "id": "K8S-K03-01",
        "category": "K03",
        "question": "Do Kubernetes service accounts use least-privilege RBAC with no wildcard permissions?",
        "rationale": "Overly permissive service accounts allow a compromised pod to escalate to cluster-admin.",
        "severity": "Critical",
        "patterns_to_check": ["kubernetes", "k8s", "rbac", "service account", "role", "clusterrole", "permission", "kubectl"],
        "mitigations": [
            "Audit all ClusterRoleBindings for wildcard verbs or resources — replace with specific grants",
            "Disable default service account token auto-mounting; only mount where explicitly needed",
        ],
        "references": ["https://owasp.org/www-project-kubernetes-top-ten/2022/en/src/K03-overly-permissive-rbac"],
    },
    # ── K07 Missing Network Segmentation ─────────────────────────────────────
    {
        "id": "K8S-K07-01",
        "category": "K07",
        "question": "Are Kubernetes NetworkPolicies in place with default-deny ingress and egress?",
        "rationale": "Without NetworkPolicies all pods can communicate freely — a compromised pod reaches all services.",
        "severity": "High",
        "patterns_to_check": ["kubernetes", "k8s", "network", "pod", "namespace", "service", "ingress", "egress"],
        "mitigations": [
            "Apply default-deny NetworkPolicy to all namespaces; explicitly allow only required pod-to-pod traffic",
            "Restrict egress from sensitive namespaces to prevent data exfiltration from compromised pods",
        ],
        "references": ["https://owasp.org/www-project-kubernetes-top-ten/2022/en/src/K07-network-segmentation-failures"],
    },
    # ── K08 Secrets Management ────────────────────────────────────────────────
    {
        "id": "K8S-K08-01",
        "category": "K08",
        "question": "Are Kubernetes Secrets encrypted at rest and not stored as plaintext in etcd?",
        "rationale": "Without etcd encryption at rest, Kubernetes Secrets are base64-encoded (not encrypted) and readable by etcd access.",
        "severity": "Critical",
        "patterns_to_check": ["kubernetes", "k8s", "secret", "etcd", "configmap", "sensitive", "credential", "api key"],
        "mitigations": [
            "Enable EncryptionConfiguration for Secrets in the Kubernetes API server — use KMS envelope encryption",
            "Use external secret stores (Vault, AWS Secrets Manager) with the Secrets Store CSI driver instead of native Secrets",
        ],
        "references": ["https://owasp.org/www-project-kubernetes-top-ten/2022/en/src/K08-secrets-management-failures"],
    },
]
