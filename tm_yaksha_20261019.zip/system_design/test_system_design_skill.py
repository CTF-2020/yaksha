import unittest
from pathlib import Path

try:
    from .system_design_skill import SystemDesignSkill
except ImportError:
    from system_design_skill import SystemDesignSkill


ROOT = Path(__file__).resolve().parent


class SystemDesignSkillTests(unittest.TestCase):
    def setUp(self):
        self.skill = SystemDesignSkill.from_directory(ROOT)

    def test_loads_skill_metadata(self):
        self.assertEqual(self.skill.metadata["name"], "system-design")
        self.assertIn("System Design", self.skill.title)

    def test_indexes_top_level_topics(self):
        topics = self.skill.list_topics()

        self.assertIn("Caching", topics)
        self.assertIn("URL Shortener", topics)
        self.assertNotIn("Write-through cache", topics)

    def test_finds_and_returns_topic_content(self):
        topic = self.skill.get_topic("Caching")

        self.assertEqual(topic.title, "Caching")
        self.assertIn("Cache Invalidation", topic.body)

    def test_search_returns_ranked_matches(self):
        matches = self.skill.search("cache invalidation", limit=3)

        self.assertGreaterEqual(len(matches), 1)
        self.assertEqual(matches[0].title, "Cache Invalidation")
        self.assertGreater(matches[0].score, 0)

    def test_generates_study_plan(self):
        plan = self.skill.study_plan(days=2, focus="interview")

        self.assertEqual(len(plan), 2)
        self.assertTrue(all(day.topics for day in plan))
        self.assertIn("Day 1", plan[0].label)

    def test_builds_topic_summary(self):
        summary = self.skill.summarize_topic("Caching", sentences=2)

        self.assertLessEqual(summary.count(". "), 2)
        self.assertIn("cache", summary.casefold())

    def test_lists_topic_outline(self):
        outline = self.skill.topic_outline("Caching")

        self.assertIn("Cache Invalidation", [item["title"] for item in outline])
        self.assertTrue(all(item["level"] > 1 for item in outline))

    def test_generates_flashcards_from_subsections(self):
        cards = self.skill.flashcards("Caching", limit=3)

        self.assertGreaterEqual(len(cards), 1)
        self.assertTrue(cards[0].term)
        self.assertIn("What should you know", cards[0].prompt)

    def test_generates_quiz_questions(self):
        questions = self.skill.quiz("Caching", count=2)

        self.assertEqual(len(questions), 2)
        self.assertTrue(questions[0].question.endswith("?"))
        self.assertTrue(questions[0].answer)


if __name__ == "__main__":
    unittest.main()
