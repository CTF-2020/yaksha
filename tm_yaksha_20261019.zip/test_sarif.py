"""Tests for the SARIF 2.1.0 exporter.

Run:  python -m unittest test_sarif

Asserts the structure GitHub/GitLab code-scanning require: a 2.1.0 envelope,
tool.driver.rules with a level and a numeric security-severity, results that
reference a valid ruleIndex, carry a level and a message, resolve file:line into
a physical location (and everything else into a logical location), and emit
stable partialFingerprints for cross-scan dedup.
"""
from __future__ import annotations

import unittest

import sarif


def _report():
    return {
        "id": "r1", "title": "SAST · demo", "methodology": "sast",
        "methodology_label": "Static Application Security Testing",
        "categories": [
            {"id": "PY-SQL-001", "name": "SQL Injection", "risk": "High",
             "_source": "SAST", "cwe": "CWE-89", "owasp": "WEB-A03",
             "stride": ["Tampering"], "remediation": "Use parameterized queries.",
             "description": "User input concatenated into SQL.",
             "affected_components": ["svc/search.py:42"],
             "threats": [{"name": "svc/search.py:42", "description": "execute(f\"...{q}\")"}]},
            {"id": "DAST-HEADERS", "name": "Missing Security Headers", "risk": "Low",
             "_source": "DAST", "cwe": "CWE-16",
             "threats": [{"name": "https://demo.test/ [server]", "description": "no HSTS"}]},
            {"id": "CORR-001", "name": "SQL Injection", "risk": "Critical",
             "_source": "CORRELATION", "verdict": "confirmed_exploitable",
             "threats": [{"name": "[Static (code)] svc/search.py:42", "description": "root cause"}]},
        ],
    }


class TestSarif(unittest.TestCase):
    def setUp(self):
        self.doc = sarif.to_sarif(_report())
        self.run = self.doc["runs"][0]

    def test_envelope(self):
        self.assertEqual(self.doc["version"], "2.1.0")
        self.assertIn("$schema", self.doc)
        self.assertEqual(self.run["tool"]["driver"]["name"], "Yaksha Guard")

    def test_rules_have_level_and_security_severity(self):
        for rule in self.run["tool"]["driver"]["rules"]:
            self.assertIn(rule["defaultConfiguration"]["level"], ("error", "warning", "note"))
            sev = float(rule["properties"]["security-severity"])
            self.assertTrue(0.0 <= sev <= 10.0)

    def test_results_reference_valid_rule_index(self):
        n_rules = len(self.run["tool"]["driver"]["rules"])
        for res in self.run["results"]:
            self.assertTrue(0 <= res["ruleIndex"] < n_rules)
            self.assertIn(res["level"], ("error", "warning", "note"))
            self.assertTrue(res["message"]["text"])

    def test_file_line_becomes_physical_location(self):
        res = next(r for r in self.run["results"] if r["ruleId"] == "PY-SQL-001")
        phys = res["locations"][0]["physicalLocation"]
        self.assertEqual(phys["artifactLocation"]["uri"], "svc/search.py")
        self.assertEqual(phys["region"]["startLine"], 42)

    def test_url_becomes_logical_location(self):
        res = next(r for r in self.run["results"] if r["ruleId"] == "DAST-HEADERS")
        self.assertIn("logicalLocations", res["locations"][0])
        self.assertNotIn("physicalLocation", res["locations"][0])

    def test_prefixed_locus_is_cleaned(self):
        # "[Static (code)] svc/search.py:42" -> physical location at line 42
        res = next(r for r in self.run["results"] if r["ruleId"] == "CORR-001")
        self.assertEqual(res["locations"][0]["physicalLocation"]["region"]["startLine"], 42)

    def test_fingerprints_are_stable_and_unique(self):
        fps = [r["partialFingerprints"]["yakshaGuard/v1"] for r in self.run["results"]]
        # deterministic across a second run
        again = sarif.to_sarif(_report())["runs"][0]["results"]
        self.assertEqual(fps, [r["partialFingerprints"]["yakshaGuard/v1"] for r in again])

    def test_severity_maps_to_error(self):
        crit = next(r for r in self.run["results"] if r["ruleId"] == "CORR-001")
        self.assertEqual(crit["level"], "error")

    def test_tags_include_owasp_and_cwe(self):
        rule = next(r for r in self.run["tool"]["driver"]["rules"] if r["id"] == "PY-SQL-001")
        tags = rule["properties"]["tags"]
        self.assertIn("WEB-A03", tags)
        self.assertIn("CWE-89", tags)

    def test_verdict_carrying_finding_gets_verdict_tag_and_property(self):
        rule = next(r for r in self.run["tool"]["driver"]["rules"] if r["id"] == "CORR-001")
        self.assertIn("verdict/confirmed_exploitable", rule["properties"]["tags"])
        result = next(r for r in self.run["results"] if r["ruleId"] == "CORR-001")
        self.assertEqual(result["properties"]["verdict"], "confirmed_exploitable")

    def test_unverdicted_finding_gets_no_verdict_tag(self):
        rule = next(r for r in self.run["tool"]["driver"]["rules"] if r["id"] == "PY-SQL-001")
        self.assertFalse(any(t.startswith("verdict/") for t in rule["properties"]["tags"]))
        result = next(r for r in self.run["results"] if r["ruleId"] == "PY-SQL-001")
        self.assertEqual(result["properties"]["verdict"], "")


def _rows():
    return [
        {"finding_id": 1, "report_id": "r1", "report_title": "R1", "rule": "PY-SQL-001",
         "title": "SQL Injection", "family": "sql-injection", "severity": "High",
         "cwe": "CWE-89", "owasp": "WEB-A03", "source": "SAST", "locus": "svc/search.py:42",
         "path": "svc/search.py", "line": 42, "verdict": "", "owner": ""},
        {"finding_id": 2, "report_id": "r2", "report_title": "R2", "rule": "DAST-HEADERS",
         "title": "Missing Security Headers", "family": "misconfig", "severity": "Low",
         "cwe": "CWE-16", "owasp": "", "source": "DAST", "locus": "https://demo.test/ [server]",
         "path": "", "line": None, "verdict": "", "owner": ""},
        {"finding_id": 3, "report_id": "r3", "report_title": "R3", "rule": "CORR-001",
         "title": "SQL Injection", "family": "sql-injection", "severity": "Critical",
         "cwe": "CWE-89", "owasp": "WEB-A03", "source": "CORRELATION",
         "locus": "[Static (code)] svc/search.py:42", "path": "", "line": None,
         "verdict": "confirmed_exploitable", "owner": "alice"},
    ]


class TestSarifRows(unittest.TestCase):
    """Same SARIF 2.1.0 contract as TestSarif, but built from flat triage rows
    (report_db.search_findings shape) spanning multiple reports -- this is
    what a verdict-filtered export.sarif download actually renders."""

    def setUp(self):
        self.doc = sarif.to_sarif_rows(_rows())
        self.run = self.doc["runs"][0]

    def test_envelope(self):
        self.assertEqual(self.doc["version"], "2.1.0")
        self.assertEqual(self.run["tool"]["driver"]["name"], "Yaksha Guard")

    def test_results_reference_valid_rule_index(self):
        n_rules = len(self.run["tool"]["driver"]["rules"])
        for res in self.run["results"]:
            self.assertTrue(0 <= res["ruleIndex"] < n_rules)
            self.assertIn(res["level"], ("error", "warning", "note"))

    def test_file_line_becomes_physical_location(self):
        res = next(r for r in self.run["results"] if r["ruleId"] == "PY-SQL-001")
        phys = res["locations"][0]["physicalLocation"]
        self.assertEqual(phys["artifactLocation"]["uri"], "svc/search.py")
        self.assertEqual(phys["region"]["startLine"], 42)

    def test_url_becomes_logical_location(self):
        res = next(r for r in self.run["results"] if r["ruleId"] == "DAST-HEADERS")
        self.assertIn("logicalLocations", res["locations"][0])

    def test_prefixed_locus_is_cleaned(self):
        res = next(r for r in self.run["results"] if r["ruleId"] == "CORR-001")
        self.assertEqual(res["locations"][0]["physicalLocation"]["region"]["startLine"], 42)

    def test_verdict_and_owner_carried_in_properties(self):
        res = next(r for r in self.run["results"] if r["ruleId"] == "CORR-001")
        self.assertEqual(res["properties"]["verdict"], "confirmed_exploitable")
        self.assertEqual(res["properties"]["owner"], "alice")
        self.assertEqual(res["properties"]["reportId"], "r3")

    def test_spans_multiple_reports_in_one_run(self):
        report_ids = {r["properties"]["reportId"] for r in self.run["results"]}
        self.assertEqual(report_ids, {"r1", "r2", "r3"})

    def test_empty_rows_produce_a_valid_empty_run(self):
        doc = sarif.to_sarif_rows([])
        self.assertEqual(doc["runs"][0]["results"], [])
        self.assertEqual(doc["runs"][0]["tool"]["driver"]["rules"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
