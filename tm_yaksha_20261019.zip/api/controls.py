"""Control register API routes."""
from __future__ import annotations

from flask import Blueprint

import app as tm_app


bp = Blueprint("controls_api", __name__, url_prefix="/api/v1/reports")


@bp.get("/<report_id>/controls")
def get_controls(report_id: str):
    """Get the control register for a report."""
    return tm_app._get_control_register_impl(report_id)


@bp.get("/<report_id>/controls/export")
def export_controls(report_id: str):
    """Export the control register for a report."""
    return tm_app._export_control_register_impl(report_id)
