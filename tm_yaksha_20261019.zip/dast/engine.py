"""Self-contained dynamic application security scanner (stdlib only).

The engine drives a *running* web application over HTTP and reports weaknesses it
can observe from the outside. It ships in-process (unlike the SAST side, which
shells out to the external Security Architecture Review scanner) so a DAST scan
works with zero external tools — no ZAP/Burp/Nuclei install required. Those
remain the recommendation for deep production scanning; this engine covers the
high-signal, low-noise checks that need no configuration.

Safety envelope (all enforced here, not by convention):
  * GET requests only — nothing that mutates server state is ever sent.
  * Redirects are inspected (for open-redirect detection) but never followed, so
    the crawler cannot be bounced onto an unauthorized host or an SSRF target.
  * The crawl is confined to an explicit host allowlist (scope).
  * A global request budget, a page cap, a wall-clock deadline, and a per-host
    delay bound total load.
  * Active checks inject only a benign, uniquely-tagged marker as a query value,
    or a benign Origin header — never a state-changing request.

Output is the same contract the broker uses: a list of finding dicts, each with
an `id` (rule, groups a card), `severity`, and location/evidence fields.
"""
from __future__ import annotations

import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from html.parser import HTMLParser
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

from . import config


# ── HTTP plumbing ─────────────────────────────────────────────────────────────
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Turn every 3xx into an HTTPError instead of following it."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


@dataclass
class Resp:
    url: str
    status: int
    headers: dict            # lower-cased single values (last wins)
    raw_headers: object      # email.message.Message (for get_all on Set-Cookie)
    body: str
    error: str = ""

    @property
    def ok(self) -> bool:
        return self.status > 0 and not self.error

    def header(self, name: str) -> str:
        return self.headers.get(name.lower(), "")

    @property
    def is_html(self) -> bool:
        return "text/html" in self.header("content-type").lower()


def _decode(raw: bytes, content_type: str) -> str:
    charset = "utf-8"
    m = re.search(r"charset=([\w-]+)", content_type or "", re.I)
    if m:
        charset = m.group(1)
    try:
        return raw.decode(charset, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")


class Fetcher:
    """A budgeted, rate-limited, redirect-inhibiting HTTP client."""

    def __init__(self, auth_header: str = "", budget: int = None,
                 timeout: int = None, delay: float = None, max_body: int = None):
        self._opener = urllib.request.build_opener(_NoRedirect)
        self._extra = _parse_header_line(auth_header)
        self.budget = config.MAX_REQUESTS if budget is None else budget
        self.timeout = config.REQUEST_TIMEOUT if timeout is None else timeout
        self.delay = config.RATE_DELAY if delay is None else delay
        self.max_body = config.MAX_BODY if max_body is None else max_body
        self.count = 0
        self._last = 0.0

    def exhausted(self) -> bool:
        return self.count >= self.budget

    def get(self, url: str, extra_headers: dict | None = None) -> Resp:
        if self.exhausted():
            return Resp(url, 0, {}, None, "", error="request budget exhausted")
        # Polite pacing: never hammer the target host.
        wait = self.delay - (time.monotonic() - self._last)
        if wait > 0:
            time.sleep(wait)
        self.count += 1
        headers = {"User-Agent": config.USER_AGENT, "Accept": "*/*"}
        headers.update(self._extra)
        if extra_headers:
            headers.update(extra_headers)
        req = urllib.request.Request(url, headers=headers, method="GET")
        try:
            resp = self._opener.open(req, timeout=self.timeout)
            raw = resp.read(self.max_body)
            out = _mk_resp(url, resp.getcode(), resp.headers, raw, self.max_body)
        except urllib.error.HTTPError as e:      # 3xx (no-follow), 4xx, 5xx
            raw = b""
            try:
                raw = e.read(self.max_body)
            except Exception:
                pass
            finally:
                e.close()
            out = _mk_resp(url, e.code, e.headers, raw, self.max_body)
        except urllib.error.URLError as e:
            out = Resp(url, 0, {}, None, "", error=str(getattr(e, "reason", e)))
        except Exception as e:                    # timeout, malformed, reset…
            out = Resp(url, 0, {}, None, "", error=str(e))
        finally:
            self._last = time.monotonic()
        return out


def _mk_resp(url, status, msg, raw, max_body) -> Resp:
    flat = {k.lower(): v for k, v in msg.items()}
    body = _decode(raw, flat.get("content-type", "")) if raw else ""
    return Resp(url, status, flat, msg, body)


def _parse_header_line(line: str) -> dict:
    """Parse an optional 'Name: value' auth header for authenticated scans."""
    if not line or ":" not in line:
        return {}
    name, _, value = line.partition(":")
    name, value = name.strip(), value.strip()
    return {name: value} if name and value else {}


# ── Link / form discovery ─────────────────────────────────────────────────────
class _LinkParser(HTMLParser):
    """Collect crawlable link targets and GET-form endpoints from an HTML page.

    `links` holds navigable targets (crawl candidates). `resources` holds
    sub-resource URLs (script/img/iframe/stylesheet) used for mixed-content
    analysis — a distinction the crawler needs but a single link list loses.
    """
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links: list[str] = []
        self.resources: list[str] = []
        self.forms: list[dict] = []
        # Sub-resources that can carry a Subresource-Integrity hash: (url, tag,
        # has_integrity). Kept separate from `resources` (mixed-content only needs
        # URLs) so the SRI check can tell an unprotected external asset apart.
        self.sri: list[dict] = []
        self._form: dict | None = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "a" and a.get("href"):
            self.links.append(a["href"])
        elif tag == "link" and a.get("href"):
            self.links.append(a["href"])
            rel = (a.get("rel") or "").lower()
            if "stylesheet" in rel:
                self.resources.append(a["href"])
                self.sri.append({"url": a["href"], "tag": "stylesheet",
                                 "integrity": bool(a.get("integrity"))})
        elif tag in ("script", "img", "iframe") and a.get("src"):
            self.links.append(a["src"])
            self.resources.append(a["src"])
            if tag == "script":
                self.sri.append({"url": a["src"], "tag": "script",
                                 "integrity": bool(a.get("integrity"))})
        elif tag == "form":
            self._form = {"action": a.get("action", ""),
                          "method": (a.get("method") or "get").lower(),
                          "inputs": []}
        elif tag in ("input", "textarea", "select") and self._form is not None:
            if a.get("name"):
                self._form["inputs"].append(a["name"])

    def handle_endtag(self, tag):
        if tag == "form" and self._form is not None:
            self.forms.append(self._form)
            self._form = None


# RCDATA elements: browsers do NOT parse tags inside these, but Python's
# HTMLParser only auto-suppresses tags inside <script>/<style>. We track a depth
# for textarea/title ourselves so a reflection inside one is correctly judged
# inert rather than a breakout.
_RCDATA_ELEMENTS = {"textarea", "title"}


class _BreakoutDetector(HTMLParser):
    """Detect whether an injected, uniquely-named tag actually parsed as markup.

    The XSS probe injects a `<token>` element. If the response reflected the
    payload *unencoded and in an active HTML context*, a real start tag named
    `token` appears here — proof of a working markup breakout. If the reflection
    landed in an inert context (HTML comment, <textarea>, <title>, <script>,
    <style>) or was entity-encoded, no such start tag is produced, so we do not
    cry XSS. This is what separates a true reflected-XSS from a harmless echo.
    """
    def __init__(self, token: str):
        super().__init__(convert_charrefs=True)
        self.token = token
        self.injected = False
        self._rcdata_depth = 0

    def handle_starttag(self, tag, attrs):
        if tag in _RCDATA_ELEMENTS:
            self._rcdata_depth += 1
            return
        if tag == self.token and self._rcdata_depth == 0:
            self.injected = True

    def handle_endtag(self, tag):
        if tag in _RCDATA_ELEMENTS and self._rcdata_depth > 0:
            self._rcdata_depth -= 1

    def handle_startendtag(self, tag, attrs):
        if tag == self.token and self._rcdata_depth == 0:
            self.injected = True


def _same_scope(url: str, scope_hosts: list[str]) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return host in scope_hosts


def _strip_fragment(url: str) -> str:
    p = urlparse(url)
    return urlunparse(p._replace(fragment=""))


def _looks_binary(url: str) -> bool:
    return bool(re.search(
        r"\.(png|jpe?g|gif|svg|ico|css|woff2?|ttf|eot|pdf|zip|mp4|webm|mp3)(\?|$)",
        url, re.I))


def _consider(raw_url: str, scope_hosts: list[str], seen: set, queue: list) -> bool:
    """Queue an in-scope, crawlable URL once; returns True if newly enqueued."""
    nxt = _strip_fragment(raw_url)
    if (nxt not in seen and _same_scope(nxt, scope_hosts)
            and not _looks_binary(nxt)
            and urlparse(nxt).scheme in ("http", "https")):
        seen.add(nxt)
        queue.append(nxt)
        return True
    return False


# ── The scan ──────────────────────────────────────────────────────────────────
@dataclass
class ScanResult:
    target: str
    findings: list = field(default_factory=list)
    pages_crawled: int = 0
    requests_made: int = 0
    truncated: bool = False


def scan(target_url: str, scope_hosts: list[str], severity_threshold: str = "Info",
         auth_header: str = "", active: bool = None, progress=None,
         max_pages: int = None, time_budget: int = None) -> ScanResult:
    """Crawl and assess a target, returning findings at/above the threshold."""
    active = config.ACTIVE_CHECKS if active is None else active
    max_pages = config.MAX_PAGES if max_pages is None else max_pages
    threshold = config.SEVERITY_ORDER.get(severity_threshold, 99)
    budget_secs = config.SCAN_TIMEOUT if time_budget is None else time_budget
    deadline = time.monotonic() + budget_secs
    authenticated = bool(_parse_header_line(auth_header))

    def emit(msg):
        if progress:
            progress(msg)

    def out_of_time():
        return time.monotonic() >= deadline

    fetcher = Fetcher(auth_header=auth_header)
    reporter = _Reporter(threshold)

    start = _strip_fragment(target_url)
    queue = [start]
    seen = {start}
    param_urls: dict[str, str] = {}   # signature -> url, deduped for active tests
    origin_urls: dict[str, str] = {}  # path signature -> url, for CORS probing
    pages = 0
    truncated = False

    # Seed from robots.txt / sitemap.xml before the link crawl so we reach pages
    # that are not linked from the landing page (a common coverage blind spot).
    _seed_from_site(start, scope_hosts, fetcher, seen, queue, emit)

    while queue and pages < max_pages and not fetcher.exhausted():
        if out_of_time():
            truncated = True
            emit("Wall-clock budget reached; stopping crawl")
            break
        url = queue.pop(0)
        emit(f"GET {url}")
        resp = fetcher.get(url)
        if not resp.ok:
            reporter.connectivity(resp)
            continue
        pages += 1

        _passive_checks(resp, reporter, authenticated)
        _check_url_secrets(url, reporter)
        origin_urls.setdefault(_path_signature(url), url)

        # Remember any param-bearing URL for later active probing.
        if urlparse(url).query:
            param_urls.setdefault(_param_signature(url), url)

        if resp.is_html:
            parser = _LinkParser()
            try:
                parser.feed(resp.body)
            except Exception:
                pass
            _check_mixed_content(url, parser.resources, reporter)
            _check_sri(url, parser.sri, scope_hosts, reporter)
            for href in parser.links:
                nxt = urljoin(url, href)
                _check_url_secrets(nxt, reporter)
                if _consider(nxt, scope_hosts, seen, queue):
                    if urlparse(nxt).query:
                        param_urls.setdefault(_param_signature(nxt), nxt)
            for form in parser.forms:
                built = _url_from_get_form(url, form)
                if built and _same_scope(built, scope_hosts):
                    param_urls.setdefault(_param_signature(built), built)

    # The crawl was cut short if pages/requests remain to visit.
    if queue and (pages >= max_pages or fetcher.exhausted()):
        truncated = True

    # ── Active phase: safe input-reflection / open-redirect / CORS probes ──────
    if active:
        for sig, url in list(param_urls.items()):
            if fetcher.exhausted() or out_of_time():
                truncated = True
                break
            emit(f"probe {url}")
            _active_checks(url, fetcher, reporter)
        # Reflected-Origin CORS: probe a bounded, path-deduped set of endpoints.
        for sig, url in list(origin_urls.items())[:config.CORS_PROBE_CAP]:
            if fetcher.exhausted() or out_of_time():
                truncated = True
                break
            _probe_reflected_origin(url, fetcher, reporter)

    if truncated:
        reporter.truncated()

    result = ScanResult(target=target_url, findings=reporter.findings,
                        pages_crawled=pages, requests_made=fetcher.count,
                        truncated=truncated)
    emit(f"Crawled {pages} page(s), {fetcher.count} request(s), "
         f"{len(reporter.findings)} finding(s)")
    return result


# ── Crawl seeding from robots.txt / sitemap.xml ───────────────────────────────
def _seed_from_site(start: str, scope_hosts: list[str], fetcher: Fetcher,
                    seen: set, queue: list, emit=lambda m: None,
                    max_seeds: int = None) -> None:
    """Discover additional in-scope URLs from robots.txt and sitemap.xml."""
    max_seeds = config.MAX_SEEDS if max_seeds is None else max_seeds
    p = urlparse(start)
    origin = f"{p.scheme}://{p.netloc}"
    added = 0
    sitemaps: list[str] = [origin + "/sitemap.xml"]

    robots = fetcher.get(origin + "/robots.txt")
    if robots.ok and robots.body and not robots.is_html:
        for line in robots.body.splitlines():
            line = line.strip()
            low = line.lower()
            if low.startswith("sitemap:"):
                sm = line.split(":", 1)[1].strip()
                if sm:
                    sitemaps.append(sm)
            elif low.startswith(("disallow:", "allow:")):
                path = line.split(":", 1)[1].strip()
                # Ignore wildcards/empties; seed only concrete path prefixes.
                if path and "*" not in path and path != "/":
                    if _consider(urljoin(origin + "/", path.lstrip("/")),
                                 scope_hosts, seen, queue):
                        added += 1
                        if added >= max_seeds:
                            emit(f"Seeded {added} URL(s) from robots.txt")
                            return

    for sm_url in sitemaps[:5]:
        if fetcher.exhausted() or added >= max_seeds:
            break
        # sm_url after the first entry comes verbatim from a `Sitemap:` line in
        # the TARGET's own robots.txt — an untrusted source. Without this gate
        # a scanned app could point it at an internal/metadata address and the
        # scanner would fetch it, bypassing the scope allowlist entirely (the
        # <loc> entries *inside* a sitemap are already scope-checked below,
        # but the sitemap URL itself wasn't).
        if (urlparse(sm_url).scheme not in ("http", "https")
                or not _same_scope(sm_url, scope_hosts)):
            continue
        sm = fetcher.get(sm_url)
        if not sm.ok or not sm.body:
            continue
        for loc in re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", sm.body, re.I):
            if _consider(loc, scope_hosts, seen, queue):
                added += 1
                if added >= max_seeds:
                    break
    if added:
        emit(f"Seeded {added} URL(s) from robots.txt/sitemap.xml")


def _param_signature(url: str) -> str:
    """Collapse a URL to path + sorted param names so ?id=1 and ?id=2 test once."""
    p = urlparse(url)
    names = ",".join(sorted(k for k, _ in parse_qsl(p.query)))
    return f"{p.scheme}://{p.netloc}{p.path}?{names}"


def _path_signature(url: str) -> str:
    """Collapse a URL to scheme://host/path (drop query) for per-endpoint dedup."""
    p = urlparse(url)
    return f"{p.scheme}://{p.netloc}{p.path}"


def _url_from_get_form(base: str, form: dict) -> str | None:
    if form["method"] != "get" or not form["inputs"]:
        return None
    action = urljoin(base, form["action"] or "")
    if urlparse(action).scheme not in ("http", "https"):
        return None
    query = urlencode({name: "1" for name in form["inputs"]})
    p = urlparse(action)
    return urlunparse(p._replace(query=query))


# ── Reporter (threshold-aware, de-duplicating sink) ───────────────────────────
class _Reporter:
    def __init__(self, threshold: int):
        self.threshold = threshold
        self.findings: list[dict] = []
        self._seen: set = set()

    def add(self, rule_id, title, severity, url, evidence, owasp, cwe,
            remediation, param="", confidence="High", request="",
            evidence_snippet=""):
        if config.SEVERITY_ORDER.get(severity, 99) > self.threshold:
            return
        key = (rule_id, url, param)
        if key in self._seen:
            return
        self._seen.add(key)
        self.findings.append({
            "id": rule_id, "title": title, "severity": severity,
            "url": url, "param": param, "method": "GET",
            "evidence": evidence, "owasp": owasp, "cwe": cwe,
            "remediation": remediation, "domain": "DAST", "confidence": confidence,
            # Reproduction evidence: the exact request that triggered the finding
            # and the response excerpt that proves it — the dynamic-scan analog of
            # a source file:line + vulnerable snippet.
            "request": request, "evidence_snippet": evidence_snippet,
        })

    def connectivity(self, resp: Resp):
        # Surface only the initial target being unreachable, once.
        if resp.error:
            self.add("DAST-CONNECT", "Target endpoint unreachable", "Info",
                     resp.url, f"Request failed: {resp.error}",
                     "A05:2021 Security Misconfiguration", "CWE-noinfo",
                     "Confirm the target URL, network path, and any auth header.",
                     confidence="Low")

    def truncated(self):
        self.add("DAST-COVERAGE-TRUNCATED", "Scan coverage was truncated", "Info",
                 "(scan)",
                 "The scan hit a request/page/time budget before exhausting the "
                 "crawl or active-probe queue; some surface was not assessed.",
                 "A05:2021 Security Misconfiguration", "CWE-noinfo",
                 "Raise TM_DAST_MAX_REQUESTS / TM_DAST_MAX_PAGES / "
                 "TM_DAST_SCAN_TIMEOUT, or narrow the scope, for full coverage.",
                 confidence="High")


# ── Passive checks (single response) ──────────────────────────────────────────
def _passive_checks(resp: Resp, rep: _Reporter, authenticated: bool = False):
    _check_transport(resp, rep)
    _check_security_headers(resp, rep)
    _check_csp_quality(resp, rep)
    _check_cookies(resp, rep)
    _check_cors(resp, rep)
    _check_cache(resp, rep, authenticated)
    _check_info_disclosure(resp, rep)


def _check_transport(resp: Resp, rep: _Reporter):
    if urlparse(resp.url).scheme == "http":
        rep.add("DAST-TLS-PLAINTEXT", "Application served over plaintext HTTP",
                "Medium", resp.url,
                "Endpoint responds over http:// — traffic and any credentials or "
                "session cookies travel unencrypted.",
                "A02:2021 Cryptographic Failures", "CWE-319",
                "Serve the application exclusively over HTTPS and redirect HTTP to "
                "HTTPS with HSTS enabled.")


def _check_security_headers(resp: Resp, rep: _Reporter):
    if not resp.is_html:
        return
    is_https = urlparse(resp.url).scheme == "https"
    if not resp.header("content-security-policy"):
        rep.add("DAST-HDR-CSP", "Missing Content-Security-Policy header", "Medium",
                resp.url, "No Content-Security-Policy response header.",
                "A05:2021 Security Misconfiguration", "CWE-693",
                "Deploy a restrictive Content-Security-Policy (at minimum "
                "default-src 'self') to contain XSS and data-injection impact.")
    if is_https and not resp.header("strict-transport-security"):
        rep.add("DAST-HDR-HSTS", "Missing Strict-Transport-Security header",
                "Medium", resp.url, "HTTPS response without an HSTS header.",
                "A05:2021 Security Misconfiguration", "CWE-523",
                "Send Strict-Transport-Security with a long max-age (>= 15552000) "
                "and includeSubDomains.")
    xcto = resp.header("x-content-type-options").lower()
    if "nosniff" not in xcto:
        rep.add("DAST-HDR-XCTO", "Missing X-Content-Type-Options: nosniff", "Low",
                resp.url, f"X-Content-Type-Options is {xcto or 'absent'!r}.",
                "A05:2021 Security Misconfiguration", "CWE-693",
                "Return X-Content-Type-Options: nosniff to stop MIME sniffing.")
    xfo = resp.header("x-frame-options")
    csp = resp.header("content-security-policy").lower()
    if not xfo and "frame-ancestors" not in csp:
        rep.add("DAST-HDR-XFO", "Clickjacking defenses absent", "Medium", resp.url,
                "Neither X-Frame-Options nor a CSP frame-ancestors directive is set.",
                "A05:2021 Security Misconfiguration", "CWE-1021",
                "Set X-Frame-Options: DENY (or SAMEORIGIN) or a CSP "
                "frame-ancestors directive to prevent framing/clickjacking.")
    if not resp.header("referrer-policy"):
        rep.add("DAST-HDR-REFERRER", "Missing Referrer-Policy header", "Info",
                resp.url, "No Referrer-Policy header; full URLs may leak on egress.",
                "A05:2021 Security Misconfiguration", "CWE-200",
                "Set Referrer-Policy (e.g. strict-origin-when-cross-origin).")


def _parse_csp(value: str) -> dict:
    """Parse a CSP header into {directive: [sources]} (lower-cased)."""
    directives: dict[str, list[str]] = {}
    for part in value.split(";"):
        tokens = part.split()
        if tokens:
            directives[tokens[0].lower()] = [t.lower() for t in tokens[1:]]
    return directives


def _check_csp_quality(resp: Resp, rep: _Reporter):
    """A present CSP can still be near-useless; flag the classic weakenings."""
    if not resp.is_html:
        return
    value = resp.header("content-security-policy")
    if not value:
        return  # absence handled by _check_security_headers
    directives = _parse_csp(value)
    script = directives.get("script-src", directives.get("default-src", []))
    issues = []
    if "'unsafe-inline'" in script:
        issues.append("script-src allows 'unsafe-inline' (inline script/XSS not contained)")
    if "'unsafe-eval'" in script:
        issues.append("script-src allows 'unsafe-eval'")
    if any(s in ("*", "http:", "https:", "data:") for s in script):
        issues.append("script-src permits a wildcard/any-host source")
    if "default-src" not in directives and "script-src" not in directives:
        issues.append("no default-src or script-src (policy governs little)")
    if "object-src" not in directives and "default-src" not in directives:
        issues.append("no object-src 'none' (plugin content uncontrolled)")
    if "base-uri" not in directives:
        issues.append("no base-uri (base-tag injection possible)")
    if issues:
        rep.add("DAST-HDR-CSP-WEAK", "Weak Content-Security-Policy", "Low",
                resp.url,
                "CSP present but weakened: " + "; ".join(issues) + ".",
                "A05:2021 Security Misconfiguration", "CWE-693",
                "Remove 'unsafe-inline'/'unsafe-eval' and wildcard sources; set "
                "default-src 'self', object-src 'none', and base-uri 'self'.",
                confidence="Medium")


def _check_cookies(resp: Resp, rep: _Reporter):
    if resp.raw_headers is None:
        return
    is_https = urlparse(resp.url).scheme == "https"
    for raw in resp.raw_headers.get_all("Set-Cookie") or []:
        name = raw.split("=", 1)[0].strip()
        low = raw.lower()
        flags = []
        if is_https and "secure" not in low:
            flags.append("Secure")
        if "httponly" not in low:
            flags.append("HttpOnly")
        if "samesite" not in low:
            flags.append("SameSite")
        if flags:
            rep.add("DAST-COOKIE-FLAGS", f"Cookie missing security flags: {name}",
                    "Medium", resp.url,
                    f"Set-Cookie '{name}' is missing: {', '.join(flags)}.",
                    "A05:2021 Security Misconfiguration", "CWE-1004",
                    "Set Secure, HttpOnly, and an explicit SameSite attribute on "
                    "session and sensitive cookies.", param=name)


def _check_cors(resp: Resp, rep: _Reporter):
    acao = resp.header("access-control-allow-origin")
    acac = resp.header("access-control-allow-credentials").lower()
    if acao == "*" and acac == "true":
        rep.add("DAST-CORS-WILDCARD",
                "Permissive CORS: wildcard origin with credentials", "High",
                resp.url,
                "Access-Control-Allow-Origin: * combined with "
                "Access-Control-Allow-Credentials: true exposes authenticated data "
                "to any origin.",
                "A05:2021 Security Misconfiguration", "CWE-942",
                "Never combine a wildcard ACAO with credentials; reflect only an "
                "explicit allowlist of trusted origins.")
    elif acao == "*":
        rep.add("DAST-CORS-WILDCARD-OPEN", "Wildcard CORS origin", "Low", resp.url,
                "Access-Control-Allow-Origin: * allows any origin to read responses.",
                "A05:2021 Security Misconfiguration", "CWE-942",
                "Restrict Access-Control-Allow-Origin to trusted origins if the "
                "endpoint returns anything non-public.")


def _check_cache(resp: Resp, rep: _Reporter, authenticated: bool):
    """Authenticated / cookie-setting HTML that is cacheable can leak via proxies."""
    if not resp.is_html:
        return
    sets_cookie = bool(resp.raw_headers is not None
                       and resp.raw_headers.get_all("Set-Cookie"))
    if not (authenticated or sets_cookie):
        return
    cc = resp.header("cache-control").lower()
    if "no-store" not in cc and "private" not in cc:
        rep.add("DAST-HDR-CACHE", "Sensitive response is cacheable", "Low",
                resp.url,
                "An authenticated or cookie-setting HTML response lacks "
                "Cache-Control: no-store/private and may be cached by a shared "
                f"proxy or the browser (Cache-Control: {cc or 'absent'!r}).",
                "A05:2021 Security Misconfiguration", "CWE-525",
                "Send Cache-Control: no-store (or private, no-cache) on responses "
                "that contain per-user or authenticated content.",
                confidence="Medium")


_BANNER_HEADERS = ("server", "x-powered-by", "x-aspnet-version",
                   "x-aspnetmvc-version", "x-generator")
_VERSION_RE = re.compile(r"\d+\.\d+")
_ERROR_SIGNATURES = (
    "Traceback (most recent call last)", "java.lang.", "org.springframework.",
    "System.NullReferenceException", "Warning: mysql", "You have an error in your "
    "SQL syntax", "ORA-0", "PG::", "Microsoft OLE DB Provider",
    "<b>Fatal error</b>", "Exception in thread",
)
# Query-parameter names that should never carry a secret in a URL (logged,
# cached, sent in Referer). Anchored to word boundaries to limit false hits.
_SECRET_PARAM_RE = re.compile(
    r"(?:^|[_\-])(?:access[_\-]?token|api[_\-]?key|apikey|auth[_\-]?token|"
    r"session(?:[_\-]?id)?|sessid|secret|password|passwd|pwd|token|jwt|"
    r"signature|sig)$", re.I)


def _check_url_secrets(url: str, rep: _Reporter):
    """Flag apparent secrets/session identifiers carried in a URL query string."""
    for name, val in parse_qsl(urlparse(url).query, keep_blank_values=True):
        if val and _SECRET_PARAM_RE.search(name):
            rep.add("DAST-INFO-SECRET-URL",
                    f"Possible secret in URL parameter: {name}", "Medium",
                    _strip_fragment(url),
                    f"Query parameter '{name}' looks like a credential/session "
                    "token; URLs are logged, cached, and leaked via Referer.",
                    "A05:2021 Security Misconfiguration", "CWE-598",
                    "Carry secrets and session tokens in headers or POST bodies, "
                    "never in the URL/query string.",
                    param=name, confidence="Low")


def _check_mixed_content(page_url: str, resources: list[str], rep: _Reporter):
    """An HTTPS page pulling http:// sub-resources downgrades its security."""
    if urlparse(page_url).scheme != "https":
        return
    bad = []
    for src in resources:
        full = urljoin(page_url, src)
        if urlparse(full).scheme == "http":
            bad.append(full)
    if bad:
        sample = ", ".join(bad[:3]) + (" …" if len(bad) > 3 else "")
        rep.add("DAST-MIXED-CONTENT", "Mixed active/passive content", "Medium",
                page_url,
                f"HTTPS page references {len(bad)} http:// sub-resource(s): {sample}",
                "A02:2021 Cryptographic Failures", "CWE-311",
                "Load all sub-resources over HTTPS; adopt "
                "Content-Security-Policy: upgrade-insecure-requests.")


def _check_sri(page_url: str, candidates: list[dict], scope_hosts: list[str],
               rep: _Reporter):
    """Cross-origin scripts/styles loaded without Subresource Integrity.

    A third-party asset with no `integrity` hash means a compromise of that CDN
    (or a MITM on it) executes attacker code in this origin — the Magecart /
    supply-chain class. Same-origin assets are exempt: they share this app's
    trust boundary and SRI adds little there.
    """
    unprotected = []
    for c in candidates:
        full = urljoin(page_url, c["url"])
        if urlparse(full).scheme not in ("http", "https"):
            continue
        if c["integrity"] or _same_scope(full, scope_hosts):
            continue
        unprotected.append(f"{c['tag']}: {full}")
    if unprotected:
        sample = "; ".join(unprotected[:3]) + (" …" if len(unprotected) > 3 else "")
        rep.add("DAST-SRI-MISSING", "Cross-origin resource without Subresource Integrity",
                "Medium", page_url,
                f"{len(unprotected)} third-party sub-resource(s) load without an "
                f"integrity hash: {sample}",
                "A08:2021 Software and Data Integrity Failures", "CWE-353",
                "Add an integrity (SRI) hash and crossorigin attribute to all "
                "third-party <script>/<link> tags, or self-host the asset.")


def _check_info_disclosure(resp: Resp, rep: _Reporter):
    for h in _BANNER_HEADERS:
        val = resp.header(h)
        if val and (_VERSION_RE.search(val) or h != "server"):
            rep.add("DAST-INFO-BANNER", f"Version/technology disclosed via {h}",
                    "Low", resp.url, f"{h}: {val}",
                    "A05:2021 Security Misconfiguration", "CWE-200",
                    "Suppress or genericize technology/version banners so an "
                    "attacker cannot fingerprint known-vulnerable components.",
                    param=h)
    body = resp.body or ""
    for sig in _ERROR_SIGNATURES:
        if sig in body:
            rep.add("DAST-INFO-ERROR", "Verbose error / stack trace exposed",
                    "Medium", resp.url,
                    f"Response body contains a server error signature: {sig!r}",
                    "A05:2021 Security Misconfiguration", "CWE-209",
                    "Return generic error pages to clients and log details "
                    "server-side; never expose stack traces or SQL errors.")
            break
    if resp.is_html and re.search(r"<title>\s*Index of /", body, re.I):
        rep.add("DAST-INFO-DIRLIST", "Directory listing enabled", "Medium",
                resp.url, "Response looks like an autogenerated directory index.",
                "A05:2021 Security Misconfiguration", "CWE-548",
                "Disable automatic directory indexing on the web server.")


# ── Active checks (safe, uniquely-tagged probes) ──────────────────────────────
_XSS_TOKEN = "qz9dast"
# Break out of an attribute/tag and inject a uniquely-named element. If this tag
# parses in the response, the payload reached an active HTML context unencoded.
_XSS_MARKER = f'{_XSS_TOKEN}"><{_XSS_TOKEN} x=1>'
_REDIRECT_PARAMS = ("redirect", "redirect_uri", "redirecturl", "url", "next",
                    "return", "returnurl", "return_to", "dest", "destination",
                    "continue", "goto", "target", "r", "u")
_CANARY_HOST = "dast-canary.example.net"
_CANARY_URL = f"https://{_CANARY_HOST}/"
_CORS_ORIGIN = f"https://{_CANARY_HOST}"


def _active_checks(url: str, fetcher: Fetcher, rep: _Reporter):
    p = urlparse(url)
    params = parse_qsl(p.query, keep_blank_values=True)
    if not params:
        return
    for idx, (name, _) in enumerate(params):
        if fetcher.exhausted():
            return
        _probe_reflected_xss(url, params, idx, name, fetcher, rep)
        if name.lower() in _REDIRECT_PARAMS and not fetcher.exhausted():
            _probe_open_redirect(url, params, idx, name, fetcher, rep)
        if config.INJECTION_CHECKS:
            for probe in (_probe_sqli, _probe_sqli_boolean, _probe_traversal,
                          _probe_ssti, _probe_cmd):
                if fetcher.exhausted():
                    return
                probe(url, params, idx, name, fetcher, rep)


def _mutate(url: str, params: list, idx: int, value: str) -> str:
    mutated = list(params)
    mutated[idx] = (mutated[idx][0], value)
    p = urlparse(url)
    return urlunparse(p._replace(query=urlencode(mutated)))


def _probe_reflected_xss(url, params, idx, name, fetcher: Fetcher, rep: _Reporter):
    probe = _mutate(url, params, idx, _XSS_MARKER)
    resp = fetcher.get(probe)
    if not resp.ok or not resp.is_html:
        return
    if _XSS_MARKER not in resp.body:
        return  # encoded, filtered, or not reflected — no finding, no noise.
    # The marker survived verbatim. Did it actually break out into markup?
    det = _BreakoutDetector(_XSS_TOKEN)
    try:
        det.feed(resp.body)
    except Exception:
        pass
    snippet = _snippet(resp.body, _XSS_MARKER)
    if det.injected:
        rep.add("DAST-XSS-REFLECTED", "Reflected Cross-Site Scripting", "High",
                url, f"Parameter '{name}' reflects an unencoded payload that parses "
                f"as live HTML markup (injected <{_XSS_TOKEN}> element).",
                "A03:2021 Injection", "CWE-79",
                "Context-encode all reflected user input (HTML-encode for body "
                "context) and deploy a Content-Security-Policy as defense in depth.",
                param=name, request=_req_line(probe), evidence_snippet=snippet)
    else:
        # Reflected unencoded but landed in an inert context (comment, textarea,
        # script, title, style). Not exploitable as-is, but brittle.
        rep.add("DAST-XSS-REFLECTED-INERT",
                "Unencoded reflection in an inert context", "Low", url,
                f"Parameter '{name}' reflects unencoded special characters that did "
                "not parse as markup (likely inside a comment/textarea/script); "
                "exploitable if the surrounding markup changes.",
                "A03:2021 Injection", "CWE-79",
                "Context-encode reflected input regardless of the current "
                "rendering context.", param=name, confidence="Low",
                request=_req_line(probe), evidence_snippet=snippet)


def _probe_open_redirect(url, params, idx, name, fetcher: Fetcher, rep: _Reporter):
    probe = _mutate(url, params, idx, _CANARY_URL)
    resp = fetcher.get(probe)
    if not resp.ok:
        return
    location = resp.header("location")
    if 300 <= resp.status < 400 and location:
        if (urlparse(location).hostname or "").lower() == _CANARY_HOST:
            rep.add("DAST-OPEN-REDIRECT", "Open redirect", "Medium", url,
                    f"Parameter '{name}' controls the Location of a "
                    f"{resp.status} redirect (sent to {_CANARY_URL}).",
                    "A01:2021 Broken Access Control", "CWE-601",
                    "Validate redirect destinations against an allowlist of "
                    "internal paths; never redirect to an untrusted absolute URL.",
                    param=name, request=_req_line(probe),
                    evidence_snippet=f"HTTP {resp.status} → Location: {location}")
            return
    # Client-side redirect sinks: a <meta http-equiv=refresh> or a JS
    # location assignment carrying our canary host is just as exploitable as a
    # 3xx Location, and a header-only check misses both.
    body = resp.body if resp.is_html else ""
    if body and (_META_REFRESH_RE.search(body) or _JS_LOCATION_RE.search(body)):
        rep.add("DAST-OPEN-REDIRECT", "Open redirect (client-side)", "Medium", url,
                f"Parameter '{name}' controls a client-side redirect "
                f"(meta-refresh or JS location) to {_CANARY_URL}.",
                "A01:2021 Broken Access Control", "CWE-601",
                "Validate redirect destinations against an allowlist; do not build "
                "a meta-refresh or location assignment from untrusted input.",
                param=name, confidence="Medium", request=_req_line(probe),
                evidence_snippet=_snippet(body, _CANARY_HOST))


# ── Injection probes (safe, non-destructive marker/differential payloads) ─────
# Each probe targets one GET query parameter with a benign payload and confirms
# the vulnerability from a signal that a non-vulnerable app cannot produce (a new
# DB error that a balanced quote removes; the literal contents of /etc/passwd; an
# arithmetic marker the server evaluated). None of them mutate server state.
_SQL_ERROR_SIGNATURES = (
    "you have an error in your sql syntax", "warning: mysqli", "warning: mysql",
    "unclosed quotation mark", "quoted string not properly terminated",
    "sqlite3.operationalerror", "sqlite_error", "pg::syntaxerror",
    "syntax error at or near", "ora-00933", "ora-01756", "ora-00921",
    "microsoft ole db provider", "odbc sql server driver",
    "sqlstate", "psql: error", "mysql_fetch", "postgresql query failed",
)
_TRAVERSAL_PAYLOADS = (
    "../../../../../../../../etc/passwd",
    "..\\..\\..\\..\\..\\..\\..\\..\\windows\\win.ini",
)
_TRAVERSAL_SIGNATURES = ("root:x:0:0:", "[extensions]", "[fonts]",
                         "for 16-bit app support")
# SSTI: the payload contains a template expression, never the literal result, so
# a response echoing the payload verbatim is not flagged — only real evaluation
# yields the sentinel-wrapped product.
_SSTI_PAYLOADS = ("qa{{7*7}}qb", "qa${7*7}qb", "qa#{7*7}qb", "qa<%= 7*7 %>qb")
_SSTI_HIT = "qa49qb"
# Command injection via shell arithmetic substitution (non-destructive): the
# server would have to *execute* the payload to produce the sentinel result.
_CMDI_PAYLOADS = ("qzc$((913+6))cq", "qzc`expr 913 + 6`cq")
_CMDI_HIT = "qzc919cq"

_CANARY_ESC = re.escape(_CANARY_HOST)
_META_REFRESH_RE = re.compile(
    r'http-equiv=["\']?refresh["\']?[^>]*url=[^"\'>]*' + _CANARY_ESC, re.I)
_JS_LOCATION_RE = re.compile(
    r'location(?:\.href)?\s*=\s*["\'][^"\']*' + _CANARY_ESC, re.I)


def _inject(url, params, idx, value, fetcher: Fetcher) -> Resp:
    return fetcher.get(_mutate(url, params, idx, value))


def _req_line(probe_url: str, method: str = "GET") -> str:
    """The exact request that triggered a finding, for reproduction."""
    return f"{method} {probe_url}"


_SNIPPET_CTX = 90
_SNIPPET_MAX = 240


def _snippet(body: str, needle: str, ctx: int = _SNIPPET_CTX) -> str:
    """Response excerpt around the first case-insensitive match of `needle`.

    This is the 'vulnerable code' a dynamic finding can show: the actual bytes
    the server returned where the payload landed (reflection, DB error, leaked
    file contents…), with surrounding context and ellipses. Whitespace is
    collapsed so a multi-line HTML body renders as one readable line.
    """
    if not body or not needle:
        return ""
    low = body.lower()
    pos = low.find(needle.lower())
    if pos < 0:
        return ""
    start = max(0, pos - ctx)
    end = min(len(body), pos + len(needle) + ctx)
    frag = re.sub(r"\s+", " ", body[start:end]).strip()
    if len(frag) > _SNIPPET_MAX:
        frag = frag[:_SNIPPET_MAX].rstrip() + "…"
    return ("…" if start > 0 else "") + frag + ("…" if end < len(body) else "")


def _has_sql_error(body: str) -> bool:
    low = body.lower()
    return any(sig in low for sig in _SQL_ERROR_SIGNATURES)


def _probe_sqli(url, params, idx, name, fetcher: Fetcher, rep: _Reporter):
    """Error-based SQLi: a lone quote raises a DB error a balanced pair removes."""
    base_val = params[idx][1]
    broken = _inject(url, params, idx, base_val + "'", fetcher)
    if not broken.ok or not _has_sql_error(broken.body):
        return
    if fetcher.exhausted():
        return
    balanced = _inject(url, params, idx, base_val + "''", fetcher)
    # Classic confirmation: the syntax error vanishes once the quote is balanced,
    # proving our input reached the SQL string. A constant error is not injectable.
    if balanced.ok and not _has_sql_error(balanced.body):
        err = next((s for s in _SQL_ERROR_SIGNATURES if s in broken.body.lower()), "")
        rep.add("DAST-SQLI", "SQL injection (error-based)", "High", url,
                f"Parameter '{name}' triggers a database syntax error with a single "
                "quote that disappears when the quote is balanced — the value is "
                "concatenated into a SQL statement.",
                "A03:2021 Injection", "CWE-89",
                "Use parameterized queries / prepared statements; never build SQL "
                "by string concatenation of user input.", param=name,
                request=_req_line(_mutate(url, params, idx, base_val + "'")),
                evidence_snippet=_snippet(broken.body, err) if err else "")


# TRUE/FALSE predicate pairs per SQL string context. Both keep the statement
# syntactically valid, so an error-suppressing endpoint that hides error-based
# SQLi still reveals itself through the differing result sets.
_SQLI_BOOL_PAIRS = (
    (" AND 1=1", " AND 1=2"),                 # numeric context
    ("' AND '1'='1", "' AND '1'='2"),         # single-quote string context
    ('" AND "1"="1', '" AND "1"="2'),         # double-quote string context
)


def _body_ratio(a: str, b: str) -> float:
    """Whitespace-normalized, length-capped similarity of two response bodies."""
    import difflib
    a = re.sub(r"\s+", " ", a or "")[:20000]
    b = re.sub(r"\s+", " ", b or "")[:20000]
    if not a and not b:
        return 1.0
    return difflib.SequenceMatcher(None, a, b).quick_ratio()


def _probe_sqli_boolean(url, params, idx, name, fetcher: Fetcher, rep: _Reporter):
    """Boolean-based blind SQLi: a TRUE predicate returns the baseline page while a
    FALSE predicate returns a materially different one — catches injection where
    DB errors are suppressed (so `_probe_sqli` stays silent).

    Conservative by construction to avoid false positives: a static page (FALSE
    also returns the baseline) and a randomly-dynamic page (baseline already
    differs from a TRUE echo) both fail the thresholds and report nothing.
    """
    base_val = params[idx][1]
    baseline = _inject(url, params, idx, base_val, fetcher)
    if not baseline.ok:
        return
    for true_suffix, false_suffix in _SQLI_BOOL_PAIRS:
        if fetcher.exhausted():
            return
        t = _inject(url, params, idx, base_val + true_suffix, fetcher)
        if fetcher.exhausted():
            return
        f = _inject(url, params, idx, base_val + false_suffix, fetcher)
        if not (t.ok and f.ok) or t.status != baseline.status:
            continue
        sim_bt = _body_ratio(baseline.body, t.body)   # baseline vs TRUE
        sim_tf = _body_ratio(t.body, f.body)          # TRUE vs FALSE
        sim_bf = _body_ratio(baseline.body, f.body)   # baseline vs FALSE
        if sim_bt >= 0.95 and sim_tf <= 0.90 and sim_bf < sim_bt - 0.05:
            rep.add("DAST-SQLI-BOOLEAN", "SQL injection (boolean-based blind)",
                    "High", url,
                    f"Parameter '{name}' acts as a boolean SQL condition: a true "
                    f"predicate ({true_suffix.strip()!r}) returns the baseline page "
                    f"(similarity {sim_bt:.2f}) while a false predicate "
                    f"({false_suffix.strip()!r}) returns a materially different "
                    f"response (TRUE↔FALSE similarity {sim_tf:.2f}) — the value is "
                    "evaluated inside a SQL statement.",
                    "A03:2021 Injection", "CWE-89",
                    "Use parameterized queries / prepared statements; never build "
                    "SQL by string concatenation of user input.", param=name,
                    request=(f"GET {_mutate(url, params, idx, base_val + true_suffix)}"
                             f"  vs  {_mutate(url, params, idx, base_val + false_suffix)}"),
                    evidence_snippet=(f"TRUE predicate → {baseline.status}, "
                                      f"similarity to baseline {sim_bt:.2f}; "
                                      f"FALSE predicate → TRUE↔FALSE similarity {sim_tf:.2f}"))
            return


def _probe_traversal(url, params, idx, name, fetcher: Fetcher, rep: _Reporter):
    """Path traversal: request a well-known OS file and detect its contents."""
    for payload in _TRAVERSAL_PAYLOADS:
        if fetcher.exhausted():
            return
        resp = _inject(url, params, idx, payload, fetcher)
        if not resp.ok:
            continue
        low = resp.body.lower()
        hit = next((s for s in _TRAVERSAL_SIGNATURES if s.lower() in low), None)
        if hit:
            rep.add("DAST-PATH-TRAVERSAL", "Path traversal / local file read",
                    "High", url,
                    f"Parameter '{name}' returned the contents of a system file "
                    f"(matched {hit!r}) for payload {payload!r}.",
                    "A01:2021 Broken Access Control", "CWE-22",
                    "Resolve and canonicalize paths, then confirm they stay within "
                    "an allowed base directory; reject '..' sequences.", param=name,
                    request=_req_line(_mutate(url, params, idx, payload)),
                    evidence_snippet=_snippet(resp.body, hit))
            return


def _probe_ssti(url, params, idx, name, fetcher: Fetcher, rep: _Reporter):
    """Server-side template injection: a template expression is evaluated."""
    for payload in _SSTI_PAYLOADS:
        if fetcher.exhausted():
            return
        resp = _inject(url, params, idx, payload, fetcher)
        if resp.ok and _SSTI_HIT in resp.body:
            rep.add("DAST-SSTI", "Server-side template injection", "High", url,
                    f"Parameter '{name}' evaluated a template expression "
                    f"({payload!r} produced {_SSTI_HIT!r}); attacker-controlled "
                    "input is rendered as a template.",
                    "A03:2021 Injection", "CWE-1336",
                    "Never render user input as a template; use a sandboxed engine "
                    "with logic-less templates and pass data as bound context.",
                    param=name,
                    request=_req_line(_mutate(url, params, idx, payload)),
                    evidence_snippet=_snippet(resp.body, _SSTI_HIT))
            return


def _probe_cmd(url, params, idx, name, fetcher: Fetcher, rep: _Reporter):
    """OS command injection via non-destructive arithmetic substitution."""
    for payload in _CMDI_PAYLOADS:
        if fetcher.exhausted():
            return
        resp = _inject(url, params, idx, payload, fetcher)
        if resp.ok and _CMDI_HIT in resp.body:
            rep.add("DAST-CMD-INJECTION", "OS command injection", "High", url,
                    f"Parameter '{name}' executed a shell substitution "
                    f"({payload!r} produced {_CMDI_HIT!r}) — input reaches a "
                    "command interpreter.",
                    "A03:2021 Injection", "CWE-78",
                    "Never pass user input to a shell; use argument arrays / native "
                    "APIs and strict allowlists for any external command.",
                    param=name,
                    request=_req_line(_mutate(url, params, idx, payload)),
                    evidence_snippet=_snippet(resp.body, _CMDI_HIT))
            return


def _probe_reflected_origin(url: str, fetcher: Fetcher, rep: _Reporter):
    """Send a benign cross-origin Origin header and see if CORS reflects it.

    The dangerous, common CORS misconfiguration is not a literal `*` (that check
    lives in the passive path) but a server that echoes *any* request Origin into
    Access-Control-Allow-Origin. Combined with Allow-Credentials: true, that lets
    an attacker page read authenticated responses. This probe is read-only (GET)
    and only adds one header, so it stays inside the safety envelope.
    """
    resp = fetcher.get(url, extra_headers={"Origin": _CORS_ORIGIN})
    if not resp.ok:
        return
    acao = resp.header("access-control-allow-origin")
    if acao != _CORS_ORIGIN:
        return  # not reflecting our arbitrary origin
    acac = resp.header("access-control-allow-credentials").lower()
    if acac == "true":
        rep.add("DAST-CORS-REFLECT-CREDS",
                "CORS reflects arbitrary origin with credentials", "High", url,
                f"The server reflected the request Origin ({_CORS_ORIGIN}) into "
                "Access-Control-Allow-Origin together with "
                "Access-Control-Allow-Credentials: true, so any origin can read "
                "authenticated responses.",
                "A05:2021 Security Misconfiguration", "CWE-942",
                "Reflect an Origin only after checking it against a strict "
                "allowlist; never combine origin reflection with credentials.",
                request=f"GET {url}  (Origin: {_CORS_ORIGIN})",
                evidence_snippet=(f"Access-Control-Allow-Origin: {acao}  ·  "
                                  f"Access-Control-Allow-Credentials: {acac}"))
    else:
        rep.add("DAST-CORS-REFLECT", "CORS reflects arbitrary origin", "Low", url,
                f"The server reflected the request Origin ({_CORS_ORIGIN}) into "
                "Access-Control-Allow-Origin, allowing any site to read responses "
                "from this endpoint.",
                "A05:2021 Security Misconfiguration", "CWE-942",
                "Reflect an Origin only after validating it against an allowlist "
                "of trusted origins if the endpoint returns anything non-public.",
                confidence="Medium",
                request=f"GET {url}  (Origin: {_CORS_ORIGIN})",
                evidence_snippet=f"Access-Control-Allow-Origin: {acao}")
