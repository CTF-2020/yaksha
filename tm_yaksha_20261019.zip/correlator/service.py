"""Orchestration: load saved reports, correlate them, save the result.

Reports live in the ``report_db`` SQLite store the rest of Yaksha Guard reads
and writes through — a leaf module with no dependency on ``app.py``, so this
package stays self-contained. This is the only part of the package that
touches the report store; it runs the pure engine and hands a finished report
dict back to the caller (the API layer) to persist through the app's own
``_save_report`` so indexing/scrubbing stay consistent with every other
report type.
"""
from __future__ import annotations

import re

import epss_kev
import report_db
import suppressions
from . import engine, mapper

# Mirrors app.py's _REPORT_ID_RE — every other report loader in the app validates
# against this before a lookup; report_ids arrive here straight from the API
# layer's request body, so this package must not be the one exception. Redundant
# with report_db.get_report's parameterized query (no path-traversal surface
# either way), but rejecting a malformed id early keeps error messages honest.
_REPORT_ID_RE = re.compile(r'^[A-Za-z0-9_-]{8,80}$')


def _load_report(report_id: str) -> dict | None:
    if not _REPORT_ID_RE.match(report_id):
        return None
    return report_db.get_report(report_id)


def load_report(report_id: str) -> dict | None:
    """Public loader for a saved report (used by the attack-path endpoint)."""
    return _load_report(report_id)


def _drop_suppressed(reports: list[dict], supps=None) -> list[dict]:
    """Strip suppressed categories before they ever reach the engine.

    An accepted-risk or false-positive decision (see suppressions/) already
    keeps a finding out of a single report's active severity pill at view
    time; without this it would still silently inflate a correlated
    cluster's severity/priority, or corroborate a design gap it shouldn't —
    the same decision, just not applied to this second read path. Returns a
    new list; input reports are not mutated.
    """
    if supps is None:
        supps = suppressions.load_suppressions()
    if not supps:
        return reports
    out = []
    for r in reports:
        annotated = suppressions.annotate_report(r, supps)
        cats = [c for c in annotated.get("categories") or []
                if not (isinstance(c, dict) and c.get("suppressed"))]
        r2 = dict(r)
        r2["categories"] = cats
        out.append(r2)
    return out


def list_correlatable() -> list[dict]:
    """Summaries of saved reports that can feed a correlation run.

    A report is correlatable if it exposes weakness categories — we accept any
    report whose methodology is not a pure inventory type and that has at least
    one category, rather than hard-coding a whitelist, so custom methodologies
    still show up. Suppressed categories are dropped first, so a report that is
    fully accepted/false-positived doesn't show up as a pickable source.
    """
    out = []
    for d in _drop_suppressed(report_db.all_reports()):
        method = str(d.get("methodology", "")).lower()
        cats = d.get("categories") or []
        if method in ("aibom", "correlation"):
            continue
        if not cats:
            continue
        code = any(str(c.get("_source", "")).upper() in ("SAST", "CODEMODEL", "SBOM")
                   for c in cats) or method in ("sast", "codemodel", "sbom")
        runtime = any(str(c.get("_source", "")).upper() == "DAST" for c in cats) or method == "dast"
        incident = any(str(c.get("_source", "")).upper() == "INCIDENT"
                      for c in cats) or method == "incident"
        kind = "code" if code else "runtime" if runtime else "incident" if incident else "design"
        out.append({
            "id": d.get("id", ""),
            "title": d.get("title", "Untitled"),
            "methodology": method,
            "kind": kind,
            "overall_risk": d.get("aggregate_risk") or d.get("overall_risk", "?"),
            "analyzed_at": d.get("analyzed_at", ""),
            "categories": len(cats),
        })
    return out


def list_reachable_dependencies(limit: int = 12) -> dict:
    """Vulnerable-dependency (SBOM) findings with a code-model-proven reachable
    call path, drawn from saved correlation reports' per-component
    ``dependency_reachability`` breakdown (see
    ``engine.annotate_dependency_reachability``). Names the exact package, not
    just "a" finding in a severity bucket -- a bucket-level fact alone can't
    say which of several CVE'd components it actually covers.

    Suppressed categories are excluded, same accepted-risk/false-positive
    rule every other cross-report rollup in this app already applies.
    """
    supps = suppressions.load_suppressions()
    items = []
    for r in report_db.all_reports(limit=2000):
        if str(r.get("methodology", "")).lower() != "correlation":
            continue
        annotated = suppressions.annotate_report(r, supps)
        for cat in annotated.get("categories") or []:
            if not isinstance(cat, dict) or cat.get("suppressed"):
                continue
            dep_reach = cat.get("dependency_reachability")
            if not isinstance(dep_reach, dict) or not dep_reach:
                continue
            for name, fact in dep_reach.items():
                fact = fact if isinstance(fact, dict) else {}
                items.append({
                    "component": name,
                    "title": cat.get("name") or cat.get("title") or "Finding",
                    "risk": str(cat.get("risk") or cat.get("severity") or "Info").capitalize(),
                    "unauthenticated": bool(fact.get("unauthenticated")),
                    "tainted": bool(fact.get("tainted")),
                    "min_hops": fact.get("min_hops", 0),
                    "report_id": r.get("id"), "report_title": r.get("title") or r.get("id"),
                })
    items.sort(key=lambda i: (not i["unauthenticated"], not i["tainted"], i["min_hops"]))
    return {"count": len(items), "items": items[:max(1, min(limit, 200))]}


def run(report_ids: list[str] | None = None, title: str = "") -> dict:
    """Correlate the given reports (or every correlatable report) and return a
    finished TM report dict.

    Raises ``ValueError`` if fewer than two source reports resolve — correlation
    across a single report is just that report.
    """
    if report_ids:
        loaded = [(rid, _load_report(rid)) for rid in report_ids]
        missing = [rid for rid, r in loaded if r is None]
        if missing:
            raise ValueError(f"report(s) not found: {', '.join(missing)}")
        reports = [r for _, r in loaded]
    else:
        summaries = list_correlatable()
        reports = [_load_report(s["id"]) for s in summaries]
        reports = [r for r in reports if r]

    reports = _drop_suppressed(reports)
    reports = [r for r in reports if (r.get("categories") or [])]
    if len(reports) < 2:
        raise ValueError(
            "need at least two reports with findings to correlate "
            f"(resolved {len(reports)})")

    reports = engine.annotate_dependency_reachability(reports)
    observations = []
    for r in reports:
        observations.extend(engine.observe_report(r))
    # Build the EPSS/KEV lookup table from only the CVEs actually named by
    # this run's observations -- a filesystem-only cache read (see
    # epss_kev.combined_lookup), never a live fetch, so a correlation run
    # never blocks on or fails because of network access.
    cves = {c for o in observations for c in o.cves}
    epss_kev_lookup = epss_kev.combined_lookup(cves) if cves else None
    findings = engine.correlate_observations(observations, epss_kev_lookup=epss_kev_lookup)
    observation_count = len(observations)

    sources = [{"id": r.get("id"), "title": r.get("title"),
                "methodology": r.get("methodology")} for r in reports]

    default_title = "Correlation · " + " + ".join(
        s["methodology"] or "?" for s in sources)[:80]
    meta = {
        "report_title": title.strip() or default_title,
        "observation_count": observation_count,
        "source_count": len(reports),
    }
    return mapper.findings_to_report(findings, sources, meta)
