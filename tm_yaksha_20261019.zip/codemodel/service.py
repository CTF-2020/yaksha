"""Orchestration: analyze a registered repo's working tree into a report.

Reuses the SAST broker's repo registry and workspace preparation, so the
code-model engine inherits the exact same authorization boundary: it can only
ever read a repo an operator has explicitly registered (local path or git URL),
never an arbitrary filesystem location. The finished report is returned to the
API layer to persist through the host app's ``_save_report``.
"""
from __future__ import annotations

from . import extractor, mapper, threats


def analyze_repo(repo: dict, ref: str | None = None) -> dict:
    """Prepare the repo's working tree, build a model, derive threats, return a report."""
    from broker import scanner   # lazy: keeps the package importable without broker

    scan_root, source_meta = scanner.prepare_workspace(repo, ref=ref)
    return analyze_path(str(scan_root), repo, source_meta)


def analyze_path(path: str, repo: dict, source_meta: dict | None = None) -> dict:
    """Build a model + report from an already-available directory (used by tests)."""
    model = extractor.build_model(path)
    threat_categories = threats.derive(model)
    meta = {"source": source_meta or {}}
    return mapper.build_report(model, threat_categories, repo, meta)
