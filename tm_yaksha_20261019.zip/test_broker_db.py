"""Tests for the SQLite broker store (broker/db.py).

Isolates onto a temp DB, styled like test_report_db.py's TestReportDbModule.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from broker import db


class TestBrokerDb(unittest.TestCase):
    def setUp(self):
        self._orig_path = db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        db.DB_PATH = Path(self._td.name) / "broker.db"
        db.init()

    def _restore(self):
        db.DB_PATH = self._orig_path

    def test_upsert_and_load_repos(self):
        db.upsert_repo({"id": "r1", "url": "https://x", "name": "r1"})
        db.upsert_repo({"id": "r2", "url": "https://y", "name": "r2"})
        repos = db.load_repos()
        self.assertEqual({r["id"] for r in repos}, {"r1", "r2"})

    def test_upsert_replaces_by_id(self):
        db.upsert_repo({"id": "r1", "name": "old"})
        db.upsert_repo({"id": "r1", "name": "new"})
        repos = db.load_repos()
        self.assertEqual(len(repos), 1)
        self.assertEqual(repos[0]["name"], "new")

    def test_remove_repo(self):
        db.upsert_repo({"id": "r1"})
        self.assertTrue(db.remove_repo("r1"))
        self.assertFalse(db.remove_repo("r1"))
        self.assertEqual(db.load_repos(), [])

    def test_save_jobs_replaces_full_list(self):
        db.save_jobs([{"id": "j1", "repo_id": "r1", "started_at": "2026-01-01T00:00:00Z"}])
        db.save_jobs([{"id": "j2", "repo_id": "r1", "started_at": "2026-01-02T00:00:00Z"}])
        jobs = db.load_jobs()
        self.assertEqual([j["id"] for j in jobs], ["j2"])

    def test_baseline_roundtrip_and_replace(self):
        db.save_baseline("r1", "main", {"fp1", "fp2"})
        self.assertEqual(db.load_baseline("r1", "main"), {"fp1", "fp2"})
        db.save_baseline("r1", "main", {"fp3"})
        self.assertEqual(db.load_baseline("r1", "main"), {"fp3"})
        self.assertEqual(db.load_baseline("r1", "other-branch"), set())

    def test_sha_cache_get_put(self):
        self.assertIsNone(db.sha_cache_get("r1", "sha1"))
        db.sha_cache_put("r1", "sha1", "rep1")
        self.assertEqual(db.sha_cache_get("r1", "sha1"), "rep1")

    def test_sha_cache_bounded(self):
        for i in range(db._SHA_CACHE_MAX + 50):
            db.sha_cache_put("r1", f"sha{i}", f"rep{i}")
        import sqlite3
        from contextlib import closing
        with closing(db._connect()) as conn:
            n = conn.execute("SELECT COUNT(*) FROM sha_cache").fetchone()[0]
        self.assertLessEqual(n, db._SHA_CACHE_MAX)
        # the most recently inserted entry must survive the eviction
        self.assertEqual(db.sha_cache_get("r1", f"sha{db._SHA_CACHE_MAX + 49}"),
                         f"rep{db._SHA_CACHE_MAX + 49}")

    def test_clear_history_wipes_jobs_baselines_sha_cache_but_not_repos(self):
        db.upsert_repo({"id": "r1"})
        db.save_jobs([{"id": "j1", "repo_id": "r1", "started_at": "2026-01-01T00:00:00Z"}])
        db.save_baseline("r1", "main", {"fp1"})
        db.sha_cache_put("r1", "sha1", "rep1")
        self.assertEqual(db.clear_history(), 1)
        self.assertEqual(db.load_jobs(), [])
        self.assertEqual(db.load_baseline("r1", "main"), set())
        self.assertIsNone(db.sha_cache_get("r1", "sha1"))
        self.assertEqual(db.repo_count(), 1)  # repo registry untouched

    def test_backfill(self):
        n = db.backfill(
            repos=[{"id": "r1"}],
            jobs=[{"id": "j1", "repo_id": "r1", "started_at": "2026-01-01T00:00:00Z"}],
            baselines=[("r1", "main", {"fp1"})],
            sha_cache={"r1:sha1": "rep1"})
        self.assertGreaterEqual(n, 3)
        self.assertEqual(db.repo_count(), 1)
        self.assertEqual(len(db.load_jobs()), 1)
        self.assertEqual(db.load_baseline("r1", "main"), {"fp1"})
        self.assertEqual(db.sha_cache_get("r1", "sha1"), "rep1")


if __name__ == "__main__":
    unittest.main()
