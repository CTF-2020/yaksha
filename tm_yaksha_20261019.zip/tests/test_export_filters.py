"""Verdict-filtered SARIF export (app.py::_export_report_sarif_impl) and the
triage CSV export (api/triage.py, triage.py::export_rows/to_csv).

Both reuse existing machinery -- report_db.search_findings's verdict filter
for CSV, and a plain category filter ahead of sarif.to_sarif() for SARIF --
so these tests focus on the filter boundary itself: omitted means everything
(unchanged from before either filter existed), an explicit verdict narrows to
just that verdict, and "" selects never-correlated findings.
"""
from __future__ import annotations

import csv
import io
import json
import tempfile
import unittest
from pathlib import Path

import report_db
import triage
from suppressions import db as supp_db
from suppressions import store as supp_store


def _cat(cid, name, risk, verdict=None, loci=None):
    cat = {"id": cid, "name": name, "title": name, "risk": risk,
           "threats": [{"name": l} for l in (loci or [f"{cid}.py:1"])],
           "affected_components": loci or [f"{cid}.py:1"]}
    if verdict:
        cat["verdict"] = verdict
    return cat


class _IsolatedStoresMixin:
    def setUp(self):
        self._op = report_db.DB_PATH
        self._osp = supp_db.DB_PATH
        self._obp = supp_store._BACKUP_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        supp_db.DB_PATH = Path(self._td.name) / "suppressions.db"
        supp_store._BACKUP_PATH = Path(self._td.name) / "supp.json"
        supp_db.init()

    def _restore(self):
        report_db.DB_PATH = self._op
        supp_db.DB_PATH = self._osp
        supp_store._BACKUP_PATH = self._obp


class SarifVerdictFilterTests(_IsolatedStoresMixin, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        super().setUp()
        report_db.upsert_report({
            "id": "100_1_sariftest", "title": "SARIF filter test", "methodology": "correlation",
            "overall_risk": "Critical",
            "categories": [
                _cat("R1", "SQLi", "Critical", verdict="actively_exploited"),
                _cat("R2", "XSS", "High", verdict="design_gap"),
                _cat("R3", "Weak Hash", "Low"),   # never correlated -> verdict ""
            ],
        })

    def _rule_ids(self, resp):
        doc = json.loads(resp.data)
        return {r["ruleId"] for r in doc["runs"][0]["results"]}

    def test_no_verdict_param_exports_everything(self):
        resp = self.client.get("/api/reports/100_1_sariftest/export/sarif")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(self._rule_ids(resp), {"R1", "R2", "R3"})

    def test_verdict_param_narrows_to_that_verdict(self):
        resp = self.client.get("/api/reports/100_1_sariftest/export/sarif?verdict=actively_exploited")
        self.assertEqual(self._rule_ids(resp), {"R1"})

    def test_empty_verdict_param_selects_uncorrelated(self):
        resp = self.client.get("/api/reports/100_1_sariftest/export/sarif?verdict=")
        self.assertEqual(self._rule_ids(resp), {"R3"})

    def test_verdict_with_no_matches_returns_empty_results(self):
        resp = self.client.get("/api/reports/100_1_sariftest/export/sarif?verdict=confirmed_exploitable")
        self.assertEqual(self._rule_ids(resp), set())


class TriageExportRowsTests(_IsolatedStoresMixin, unittest.TestCase):
    def setUp(self):
        super().setUp()
        report_db.upsert_report({
            "id": "200_1_csvtest", "title": "CSV export test", "methodology": "sast",
            "overall_risk": "Critical",
            "categories": [
                _cat("R1", "SQLi", "Critical", verdict="actively_exploited"),
                _cat("R2", "XSS", "High", verdict="design_gap"),
                _cat("R3", "Weak Hash", "Low"),
            ],
        })

    def test_export_rows_matches_queue_filter_unpaginated(self):
        # queue() with a large per_page and export_rows() must agree on the
        # same filtered set -- export_rows is just the unpaginated version.
        paged = triage.queue(per_page=200)["findings"]
        exported = triage.export_rows()
        self.assertEqual({r["finding_id"] for r in paged}, {r["finding_id"] for r in exported})

    def test_export_rows_respects_verdict_filter(self):
        rows = triage.export_rows(verdict="actively_exploited")
        self.assertEqual({r["title"] for r in rows}, {"SQLi"})

    def test_to_csv_has_header_and_expected_rows(self):
        rows = triage.export_rows()
        csv_text = triage.to_csv(rows)
        reader = csv.DictReader(io.StringIO(csv_text))
        self.assertEqual(reader.fieldnames, triage._CSV_COLUMNS)
        titles = {row["title"] for row in reader}
        self.assertEqual(titles, {"SQLi", "XSS", "Weak Hash"})

    def test_to_csv_empty_rows_still_has_header(self):
        csv_text = triage.to_csv([])
        reader = csv.DictReader(io.StringIO(csv_text))
        self.assertEqual(reader.fieldnames, triage._CSV_COLUMNS)
        self.assertEqual(list(reader), [])


class TriageCsvEndpointTests(_IsolatedStoresMixin, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        super().setUp()
        report_db.upsert_report({
            "id": "300_1_csvep", "title": "CSV endpoint test", "methodology": "sast",
            "overall_risk": "Critical",
            "categories": [
                _cat("R1", "SQLi", "Critical", verdict="actively_exploited"),
                _cat("R2", "XSS", "High", verdict="design_gap"),
            ],
        })

    def test_csv_endpoint_returns_downloadable_csv(self):
        resp = self.client.get("/api/v1/triage/export.csv")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("text/csv", resp.content_type)
        self.assertIn("attachment", resp.headers.get("Content-Disposition", ""))
        reader = csv.DictReader(io.StringIO(resp.get_data(as_text=True)))
        titles = {row["title"] for row in reader}
        self.assertEqual(titles, {"SQLi", "XSS"})

    def test_csv_endpoint_applies_verdict_filter(self):
        resp = self.client.get("/api/v1/triage/export.csv?verdict=actively_exploited")
        reader = csv.DictReader(io.StringIO(resp.get_data(as_text=True)))
        titles = {row["title"] for row in reader}
        self.assertEqual(titles, {"SQLi"})

    def test_csv_endpoint_rejects_bad_sort(self):
        resp = self.client.get("/api/v1/triage/export.csv?sort=not-a-column")
        self.assertEqual(resp.status_code, 400)


if __name__ == "__main__":
    unittest.main()
