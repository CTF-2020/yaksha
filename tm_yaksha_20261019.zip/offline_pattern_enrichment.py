"""Industrial-grade offline pattern enrichment.

The rule files intentionally stay compact enough to audit by hand. This module
expands every rule into the richer analyst context needed by the UI, API, and
offline reports without requiring Claude or any network calls.
"""
from __future__ import annotations

import re
from typing import Iterable


_RULESET_PROFILES: dict[str, dict[str, object]] = {
    "web": {
        "family": "OWASP Web Top 10",
        "domain": "Web application security",
        "entry_points": ["browser requests", "sessions", "forms", "uploads", "API calls"],
        "evidence": ["route map", "authentication flow", "authorization checks", "data-flow diagram", "deployment configuration"],
        "tests": ["abuse-case test", "negative authorization test", "secure configuration review"],
        "positive_controls": ["deny by default", "server-side validation", "centralized audit logging"],
    },
    "api": {
        "family": "OWASP API Security Top 10",
        "domain": "API and service interface security",
        "entry_points": ["REST endpoints", "GraphQL operations", "webhooks", "mobile/API clients", "partner integrations"],
        "evidence": ["OpenAPI schema", "gateway policy", "authorization middleware", "token validation logic", "rate-limit policy"],
        "tests": ["BOLA/BFLA test", "schema fuzzing", "token misuse test", "quota bypass test"],
        "positive_controls": ["object-level authorization", "issuer audience validation", "per-client quotas"],
    },
    "ai": {
        "family": "OWASP LLM Top 10",
        "domain": "AI, agent, RAG, and model security",
        "entry_points": ["user prompts", "retrieved documents", "tool outputs", "agent actions", "model responses"],
        "evidence": ["prompt template", "tool manifest", "retrieval pipeline", "output rendering path", "model access logs"],
        "tests": ["direct prompt injection test", "indirect prompt injection test", "tool permission abuse test", "output handling test"],
        "positive_controls": ["prompt/content filtering", "tool allowlist", "human approval for writes", "provenance tracking"],
    },
    "mobile": {
        "family": "OWASP Mobile and Kubernetes",
        "domain": "Mobile client and runtime platform security",
        "entry_points": ["mobile app", "device storage", "mobile API calls", "WebView", "Kubernetes workload"],
        "evidence": ["mobile threat model", "MASVS checklist", "manifest/entitlements", "network security config", "cluster policies"],
        "tests": ["static mobile review", "device storage inspection", "TLS interception test", "Kubernetes policy test"],
        "positive_controls": ["secure keystore use", "TLS certificate validation", "runtime hardening", "pod security controls"],
    },
    "cloud": {
        "family": "CSA Cloud Top Threats",
        "domain": "Cloud control plane, workload, and data security",
        "entry_points": ["cloud identities", "public services", "storage buckets", "serverless functions", "management APIs"],
        "evidence": ["IAM policy", "network diagram", "cloud audit logs", "storage policy", "IaC templates"],
        "tests": ["public exposure review", "IAM privilege review", "cloud logging review", "storage encryption review"],
        "positive_controls": ["least-privilege IAM", "private endpoints", "KMS encryption", "centralized cloud audit logging"],
    },
    "cloud_native": {
        "family": "OWASP Cloud-Native Top 10",
        "domain": "Cloud-native workload security",
        "entry_points": ["containers", "orchestrators", "serverless functions", "metadata endpoints", "service mesh"],
        "evidence": ["cluster inventory", "container image provenance", "runtime policy", "egress policy", "cloud workload identity"],
        "tests": ["container escape review", "metadata SSRF test", "runtime privilege test", "supply-chain provenance check"],
        "positive_controls": ["non-root containers", "metadata hardening", "signed images", "network policies"],
    },
    "architecture": {
        "family": "Secure System Design Principles",
        "domain": "Security architecture and governance",
        "entry_points": ["trust boundaries", "identity plane", "network zones", "admin workflows", "shared platforms"],
        "evidence": ["architecture decision record", "DFD", "trust-boundary map", "risk register", "control ownership matrix"],
        "tests": ["architecture review", "failure-mode review", "privilege review", "abuse-case workshop"],
        "positive_controls": ["zero trust", "least privilege", "fail secure", "segmentation", "formal design review"],
    },
    "devsecops": {
        "family": "DevSecOps and SDLC Controls",
        "domain": "Build, release, and operational assurance",
        "entry_points": ["source repository", "CI/CD pipeline", "artifact registry", "deployment workflow", "runtime telemetry"],
        "evidence": ["pipeline definition", "branch protection", "scanner results", "SBOM", "release approval trail"],
        "tests": ["pipeline policy review", "dependency risk review", "artifact signature verification", "secrets scan validation"],
        "positive_controls": ["SAST/SCA gates", "secret scanning", "signed artifacts", "two-person review", "SIEM alerting"],
    },
}


_CATEGORY_PROFILES: dict[str, dict[str, object]] = {
    # OWASP Web Top 10
    "A01": {
        "name": "Broken Access Control",
        "description": "Access-control decisions must be enforced on the server for every object, function, and tenant boundary.",
        "attack": "An attacker changes object identifiers, calls privileged routes, or abuses CORS/file access to reach data or actions outside their entitlement.",
        "impact": "Unauthorized data access, account takeover, tenant isolation failure, or administrative action by a non-privileged user.",
        "objective": "Prove each protected action has an explicit deny-by-default authorization decision tied to the authenticated subject and target resource.",
        "context": ["resource owner", "tenant", "role", "permission", "admin function", "protected object"],
        "tests": ["Attempt horizontal object access with another user's identifier", "Attempt direct navigation to privileged functions", "Review CORS and file-access policies for authenticated data"],
        "evidence": ["authorization middleware", "resource ownership checks", "role permission matrix", "audit logs for denied access"],
        "positive_controls": ["object-level authorization enforced", "tenant-scoped authorization", "deny by default", "RBAC/ABAC policy tests"],
    },
    "A02": {
        "name": "Cryptographic Failures",
        "description": "Sensitive data must be protected with modern cryptography in transit, at rest, and during key lifecycle operations.",
        "attack": "An attacker intercepts plaintext traffic, steals unencrypted storage, cracks weak password hashes, or reuses long-lived keys.",
        "impact": "Credential disclosure, regulated-data breach, loss of confidentiality, and inability to contain leaked secrets.",
        "objective": "Show that sensitive data and secrets are encrypted, keys are managed separately, and weak algorithms or plaintext paths are absent.",
        "context": ["PII", "payment data", "credential", "secret", "TLS", "KMS", "certificate"],
        "tests": ["Inspect TLS versions and headers", "Verify storage encryption and key ownership", "Review password hashing and secret rotation"],
        "evidence": ["TLS policy", "KMS configuration", "database encryption settings", "secret rotation record"],
        "positive_controls": ["TLS 1.2 or TLS 1.3 enforced", "HSTS enabled", "KMS-backed encryption", "adaptive password hashing"],
    },
    "A03": {
        "name": "Injection",
        "description": "Untrusted input must never be interpreted as commands, queries, templates, or executable control data.",
        "attack": "An attacker injects SQL, NoSQL, LDAP, OS command, template, or deserialization payloads through input accepted by the application.",
        "impact": "Data theft, data tampering, authentication bypass, remote code execution, or host compromise.",
        "objective": "Prove all interpreter boundaries use parameterization, schema validation, output encoding, and safe parser configuration.",
        "context": ["query", "search", "filter", "command", "template", "deserialization", "user input"],
        "tests": ["Run SQL/NoSQL injection probes", "Fuzz structured inputs against schema limits", "Review raw query and command execution paths"],
        "evidence": ["prepared statement usage", "input schemas", "template escaping", "deserialization allowlist"],
        "positive_controls": ["parameterized queries", "schema validation", "safe deserialization allowlist", "output encoding"],
    },
    "A04": {
        "name": "Insecure Design",
        "description": "Security requirements, abuse cases, and defensive design decisions must be built into the architecture before implementation.",
        "attack": "An attacker exploits missing business-rule controls, unsafe workflows, weak trust boundaries, or controls added too late to be effective.",
        "impact": "Systemic design weakness that cannot be reliably fixed with a narrow patch after release.",
        "objective": "Show that the design has documented abuse cases, control objectives, trust boundaries, and secure defaults.",
        "context": ["business flow", "workflow", "design", "trust boundary", "abuse case", "rate limit"],
        "tests": ["Run abuse-case review", "Validate business-rule invariants", "Check whether controls are explicit design requirements"],
        "evidence": ["threat model", "architecture decision records", "abuse-case backlog", "security requirements"],
        "positive_controls": ["abuse cases documented", "security requirements approved", "secure defaults", "rate limits on business flows"],
    },
    "A05": {
        "name": "Security Misconfiguration",
        "description": "Platforms, frameworks, cloud resources, and middleware must be hardened from secure baselines and continuously checked for drift.",
        "attack": "An attacker abuses default settings, debug features, open storage, excessive headers, or exposed management interfaces.",
        "impact": "Unauthorized access, information leakage, service compromise, or broad cloud/platform exposure.",
        "objective": "Prove every environment is hardened, least exposed, and continuously compared against an approved baseline.",
        "context": ["configuration", "debug", "header", "bucket", "admin console", "default"],
        "tests": ["Run secure configuration scan", "Review public exposure and headers", "Verify debug and default accounts are disabled"],
        "evidence": ["baseline policy", "IaC scan", "runtime config export", "hardening checklist"],
        "positive_controls": ["secure baseline enforced", "debug disabled", "private by default", "configuration drift monitoring"],
    },
    "A06": {
        "name": "Vulnerable and Outdated Components",
        "description": "All dependencies, runtimes, images, and platform components need inventory, vulnerability tracking, and update ownership.",
        "attack": "An attacker targets a known CVE in an outdated library, container image, runtime, plugin, or third-party package.",
        "impact": "Remote code execution, privilege escalation, supply-chain compromise, or exposure through unsupported software.",
        "objective": "Prove components are inventoried, patched to policy, and blocked from release when risk exceeds tolerance.",
        "context": ["dependency", "library", "package", "container image", "runtime", "CVE"],
        "tests": ["Run SCA and image scans", "Check unsupported versions", "Verify exception and patch SLA records"],
        "evidence": ["SBOM", "SCA report", "image scan results", "dependency update policy"],
        "positive_controls": ["SBOM generated", "SCA gate enabled", "critical CVEs blocked", "patch SLA tracked"],
    },
    "A07": {
        "name": "Identification and Authentication Failures",
        "description": "Identity proofing, session handling, token validation, and recovery flows must resist credential and session abuse.",
        "attack": "An attacker brute-forces credentials, replays tokens, bypasses MFA, abuses reset flows, or steals sessions.",
        "impact": "Account takeover, unauthorized transactions, user impersonation, or persistent session compromise.",
        "objective": "Prove authentication is phishing resistant where needed, tokens are short-lived and revocable, and recovery flows are hardened.",
        "context": ["login", "session", "JWT", "MFA", "password reset", "OIDC", "token"],
        "tests": ["Test brute-force and lockout behavior", "Verify JWT issuer/audience/expiry validation", "Review reset and MFA bypass paths"],
        "evidence": ["identity provider policy", "session configuration", "token validation code", "account recovery design"],
        "positive_controls": ["MFA enforced", "short-lived tokens", "refresh token rotation", "secure password reset"],
    },
    "A08": {
        "name": "Software and Data Integrity Failures",
        "description": "Code, artifacts, updates, data imports, and CI/CD flows must be protected against unauthorized modification.",
        "attack": "An attacker tampers with build artifacts, dependencies, update channels, serialized data, or pipeline steps.",
        "impact": "Supply-chain compromise, malicious code deployment, data corruption, or unauthorized production changes.",
        "objective": "Prove build and data integrity with signatures, provenance, protected branches, and verified update/import paths.",
        "context": ["CI/CD", "artifact", "dependency", "update", "signature", "deserialization", "integrity"],
        "tests": ["Verify artifact signatures", "Review branch protection and build provenance", "Test tampered import/update rejection"],
        "evidence": ["SLSA provenance", "artifact signature", "pipeline policy", "dependency lockfile"],
        "positive_controls": ["signed artifacts", "protected branches", "SLSA provenance", "integrity checks"],
    },
    "A09": {
        "name": "Security Logging and Monitoring Failures",
        "description": "Security-relevant actions must be logged, protected, correlated, alerted, and used during incident response.",
        "attack": "An attacker performs credential attacks, privilege changes, data exports, or destructive actions without timely detection.",
        "impact": "Delayed breach detection, weak forensics, poor containment, and inability to prove what happened.",
        "objective": "Prove high-value events are logged with identity, source, timestamp, decision, outcome, and alert routing.",
        "context": ["logging", "audit", "alert", "SIEM", "monitoring", "incident", "forensic"],
        "tests": ["Trigger security events and verify SIEM ingestion", "Review alert thresholds", "Run incident-response log retrieval drill"],
        "evidence": ["audit event catalog", "SIEM dashboards", "alert rules", "retention policy"],
        "positive_controls": ["centralized audit logging", "SIEM alerting", "tamper-resistant logs", "incident runbooks"],
    },
    "A10": {
        "name": "Server-Side Request Forgery",
        "description": "Server-side fetch, webhook, and integration features must prevent access to internal resources and metadata endpoints.",
        "attack": "An attacker submits a URL that makes the server call cloud metadata, internal services, admin panels, or blocked networks.",
        "impact": "Credential theft, internal service discovery, firewall bypass, or compromise of cloud workload identity.",
        "objective": "Prove outbound requests are allowlisted, metadata access is blocked, redirects are constrained, and responses are safely handled.",
        "context": ["URL fetch", "webhook", "metadata", "callback", "proxy", "SSRF", "internal service"],
        "tests": ["Attempt metadata endpoint access", "Test private IP and redirect bypasses", "Review egress allowlist enforcement"],
        "evidence": ["egress policy", "URL allowlist", "SSRF filter tests", "metadata hardening"],
        "positive_controls": ["egress allowlist", "metadata endpoint blocked", "private IP ranges denied", "redirect validation"],
    },
    # OWASP API Security Top 10
    "API1": {
        "name": "Broken Object Level Authorization",
        "description": "Every API object reference requires an authorization decision for the current subject and object.",
        "attack": "An attacker changes IDs, cursors, slugs, or tenant identifiers to read or modify another user's object.",
        "impact": "Cross-tenant data exposure, unauthorized changes, account compromise, and regulatory breach.",
        "objective": "Prove object ownership and tenant scope are checked after authentication and before every object read/write.",
        "context": ["object id", "tenant", "resource", "account_id", "user_id", "record"],
        "tests": ["Replay request with another user's object ID", "Enumerate object identifiers", "Attempt bulk/export object access"],
        "evidence": ["object authorization middleware", "tenant scoping tests", "API access logs"],
        "positive_controls": ["object-level authorization", "tenant scoped", "ownership checks", "per-resource policy"],
    },
    "API2": {
        "name": "Broken Authentication",
        "description": "API authentication must validate token issuer, audience, signature, expiry, revocation, and client context.",
        "attack": "An attacker reuses stale tokens, weak JWTs, leaked API keys, or bypasses identity provider assumptions.",
        "impact": "API account takeover, unauthorized service access, and long-lived credential abuse.",
        "objective": "Prove each API request is authenticated with strong token validation and revocable credentials.",
        "context": ["JWT", "OAuth", "API key", "token", "OIDC", "session"],
        "tests": ["Mutate JWT claims and algorithms", "Use expired/revoked tokens", "Test API key leakage and scope boundaries"],
        "evidence": ["token validation code", "IdP configuration", "key rotation policy", "revocation design"],
        "positive_controls": ["issuer audience validation", "short-lived JWT", "refresh token rotation", "revocable credentials"],
    },
    "API3": {
        "name": "Broken Object Property Level Authorization",
        "description": "APIs must restrict readable and writable object fields based on role, ownership, and workflow state.",
        "attack": "An attacker overposts hidden fields, requests sensitive properties, or updates server-managed attributes.",
        "impact": "Privilege escalation, sensitive property exposure, business-rule bypass, or unauthorized state changes.",
        "objective": "Prove response filtering and request DTOs enforce field-level authorization.",
        "context": ["field", "property", "mass assignment", "DTO", "serializer", "sensitive field"],
        "tests": ["Attempt mass assignment of privileged fields", "Request hidden fields", "Compare field exposure across roles"],
        "evidence": ["DTO/schema definitions", "field authorization tests", "serializer configuration"],
        "positive_controls": ["field allowlist", "read/write DTO separation", "sensitive fields filtered", "server-managed fields immutable"],
    },
    "API4": {
        "name": "Unrestricted Resource Consumption",
        "description": "APIs must enforce quotas, rate limits, pagination, payload limits, and expensive-operation guards.",
        "attack": "An attacker floods high-cost operations, large payloads, search endpoints, or token/model-consuming paths.",
        "impact": "Service outage, runaway cloud or model costs, queue starvation, and degraded tenant availability.",
        "objective": "Prove every public or tenant-facing operation has bounded cost and abuse throttling.",
        "context": ["rate limit", "quota", "pagination", "payload", "expensive query", "inference"],
        "tests": ["Run burst and sustained-rate tests", "Submit maximum payloads", "Exercise unbounded search/filter paths"],
        "evidence": ["gateway throttling policy", "quota design", "load test results", "cost guardrails"],
        "positive_controls": ["rate limiting", "per-client quotas", "payload limits", "bounded pagination"],
    },
    "API5": {
        "name": "Broken Function Level Authorization",
        "description": "Every API operation, method, and route group needs an explicit permission check for the requested function.",
        "attack": "An attacker calls admin, batch, debug, or write endpoints directly despite not having the required role.",
        "impact": "Privilege escalation, unauthorized administrative changes, or destructive business operations.",
        "objective": "Prove each function maps to a required permission and cannot be reached by URL, method, or route guessing.",
        "context": ["admin", "function", "role", "permission", "delete", "PATCH", "management"],
        "tests": ["Call privileged endpoints as low-privilege users", "Try alternate HTTP methods", "Review route permission maps"],
        "evidence": ["route authorization matrix", "RBAC policy", "negative authorization tests"],
        "positive_controls": ["per-route permission checks", "RBAC authorization", "method restrictions", "admin MFA"],
    },
    "API6": {
        "name": "Unrestricted Access to Sensitive Business Flows",
        "description": "Business-critical flows need abuse controls even when each single request appears valid.",
        "attack": "An attacker automates signup, purchase, coupon, scraping, booking, password reset, or workflow abuse at scale.",
        "impact": "Fraud, inventory abuse, business disruption, account lockouts, or economic denial of service.",
        "objective": "Prove sensitive flows have abuse detection, bot controls, velocity limits, and manual escalation paths.",
        "context": ["business flow", "purchase", "signup", "coupon", "booking", "scraping", "automation"],
        "tests": ["Automate sensitive flows", "Test velocity and replay limits", "Review fraud/abuse telemetry"],
        "evidence": ["abuse-case model", "velocity rules", "bot detection policy", "fraud monitoring"],
        "positive_controls": ["flow-level rate limits", "bot detection", "risk scoring", "manual review for anomalies"],
    },
    "API7": {
        "name": "Server Side Request Forgery",
        "description": "API features that fetch external resources must restrict destination, protocol, redirects, and response handling.",
        "attack": "An attacker uses import, webhook, callback, or URL preview APIs to reach internal networks or metadata services.",
        "impact": "Cloud credential theft, internal network discovery, and access to services not exposed to the attacker.",
        "objective": "Prove server-side outbound calls are allowlisted and blocked from private, loopback, and metadata ranges.",
        "context": ["webhook", "callback", "URL", "fetch", "metadata", "SSRF", "external API"],
        "tests": ["Use private IP, DNS rebinding, and redirect payloads", "Attempt cloud metadata calls", "Review outbound egress policy"],
        "evidence": ["URL validation code", "egress firewall rules", "metadata protection", "SSRF test cases"],
        "positive_controls": ["domain allowlist", "private IP blocked", "metadata endpoint blocked", "egress proxy"],
    },
    "API8": {
        "name": "Security Misconfiguration",
        "description": "API gateways, CORS, headers, TLS, errors, and environments must be securely configured and monitored for drift.",
        "attack": "An attacker exploits permissive CORS, verbose errors, weak TLS, default accounts, or exposed admin surfaces.",
        "impact": "Data leakage, browser-assisted abuse, endpoint discovery, or administrative compromise.",
        "objective": "Prove API runtime configuration follows a secure baseline and cannot drift silently.",
        "context": ["CORS", "TLS", "headers", "debug", "error", "gateway", "environment"],
        "tests": ["Check CORS and headers", "Review TLS policy", "Inspect error responses and debug flags"],
        "evidence": ["gateway config", "security header scan", "TLS scan", "configuration baseline"],
        "positive_controls": ["strict CORS allowlist", "HSTS", "secure headers", "debug disabled"],
    },
    "API9": {
        "name": "Improper Inventory Management",
        "description": "All API versions, environments, schemas, and owners must be inventoried, documented, and retired safely.",
        "attack": "An attacker discovers shadow, deprecated, test, or undocumented APIs that lack current controls.",
        "impact": "Bypass of hardened production paths, exposure of stale data, and unowned attack surface.",
        "objective": "Prove every API has an owner, schema, environment classification, version lifecycle, and decommission plan.",
        "context": ["version", "deprecated", "shadow API", "documentation", "inventory", "staging"],
        "tests": ["Compare gateway inventory with OpenAPI docs", "Scan for deprecated versions", "Review environment exposure"],
        "evidence": ["API catalog", "OpenAPI specs", "version lifecycle policy", "gateway route inventory"],
        "positive_controls": ["API catalog maintained", "deprecated APIs retired", "schema published", "owner assigned"],
    },
    "API10": {
        "name": "Unsafe Consumption of APIs",
        "description": "Inbound data from partner, third-party, and internal APIs must be authenticated, validated, constrained, and monitored.",
        "attack": "An attacker compromises or spoofs an upstream API and sends malicious data, excessive payloads, or unsafe callbacks.",
        "impact": "Data poisoning, SSRF chains, integrity failures, service outage, or downstream compromise.",
        "objective": "Prove consumed APIs have explicit trust contracts, schema validation, timeouts, retries, and failure isolation.",
        "context": ["third-party", "partner API", "webhook", "callback", "external service", "integration"],
        "tests": ["Send malformed upstream responses", "Test timeout/retry behavior", "Validate webhook authentication"],
        "evidence": ["integration contract", "schema validation", "mTLS/webhook signature config", "circuit breaker policy"],
        "positive_controls": ["webhook signatures", "schema validation", "timeouts and circuit breakers", "mTLS to partners"],
    },
    # OWASP LLM Top 10
    "LLM01": {
        "name": "Prompt Injection",
        "description": "Prompts, retrieved content, tool outputs, and agent messages must be treated as untrusted control data.",
        "attack": "An attacker embeds instructions that override system intent, manipulate tools, exfiltrate context, or poison downstream agents.",
        "impact": "Policy bypass, data leakage, unauthorized tool use, or corrupted model behavior.",
        "objective": "Prove untrusted text cannot alter system instructions, tool policy, or authorization decisions.",
        "context": ["prompt", "RAG", "retrieval", "tool output", "system message", "agent"],
        "tests": ["Direct prompt injection suite", "Indirect injection through retrieved documents", "Tool-output instruction injection test"],
        "evidence": ["prompt boundary design", "retrieval sanitization", "tool policy", "injection test results"],
        "positive_controls": ["prompt injection scanning", "instruction hierarchy", "retrieval sanitization", "tool allowlist"],
    },
    "LLM02": {
        "name": "Insecure Output Handling",
        "description": "Model output must be validated, encoded, sandboxed, and authorized before rendering or execution.",
        "attack": "An attacker causes the model to emit HTML, JavaScript, SQL, shell commands, URLs, or file paths consumed by downstream systems.",
        "impact": "XSS, command execution, SQL injection, SSRF, file overwrite, or unsafe automated action.",
        "objective": "Prove LLM output never directly reaches an interpreter, browser, command runner, or privileged action without validation.",
        "context": ["render", "HTML", "markdown", "execute", "SQL", "file path", "command"],
        "tests": ["XSS payload rendering test", "Generated command execution test", "Schema validation failure test"],
        "evidence": ["output schema", "sanitizer configuration", "sandbox policy", "CSP headers"],
        "positive_controls": ["DOMPurify", "HTML escaped", "structured output schema", "sandboxed execution"],
    },
    "LLM03": {
        "name": "Training Data and Model Poisoning",
        "description": "Training, fine-tuning, and retrieval corpora need provenance, integrity, tenancy, and ingestion controls.",
        "attack": "An attacker injects malicious documents, labels, examples, or embeddings that bias model responses or retrieval context.",
        "impact": "Persistent model manipulation, data leakage, unsafe recommendations, or tenant cross-contamination.",
        "objective": "Prove data entering model context or training pipelines is authenticated, authorized, scanned, and traceable.",
        "context": ["training data", "fine-tune", "RAG", "embedding", "vector", "document ingestion"],
        "tests": ["Poisoned document ingestion test", "Tenant isolation retrieval test", "Provenance traceability review"],
        "evidence": ["ingestion access control", "corpus provenance", "embedding metadata", "data quality checks"],
        "positive_controls": ["authenticated ingestion", "provenance tracked", "tenant scoped", "approved origins"],
    },
    "LLM04": {
        "name": "Model Denial of Service",
        "description": "Model and agent workloads require token, cost, concurrency, recursion, and tool-use limits.",
        "attack": "An attacker submits expensive prompts, recursive tasks, large contexts, or tool loops to exhaust budget or capacity.",
        "impact": "Service outage, runaway inference cost, queue starvation, or degraded availability for legitimate users.",
        "objective": "Prove model operations have bounded resource consumption and abuse throttling per user, tenant, and workflow.",
        "context": ["token", "inference", "agent loop", "recursive", "rate limit", "cost"],
        "tests": ["Long-context abuse test", "Concurrent inference stress test", "Recursive agent loop test"],
        "evidence": ["token limits", "quota policy", "cost alerting", "agent loop safeguards"],
        "positive_controls": ["token limits", "rate limiting", "quotas", "agent step limits"],
    },
    "LLM05": {
        "name": "Supply Chain Vulnerabilities",
        "description": "Models, plugins, datasets, prompts, packages, and agent tools require provenance and vulnerability management.",
        "attack": "An attacker compromises a model package, plugin, dependency, prompt template, dataset, or third-party model provider.",
        "impact": "Malicious model behavior, credential theft, unauthorized tool access, or compromised deployment pipeline.",
        "objective": "Prove AI components are inventoried, versioned, signed where possible, reviewed, and monitored for compromise.",
        "context": ["model provider", "plugin", "dependency", "dataset", "prompt template", "agent framework"],
        "tests": ["AI SBOM review", "Plugin permission review", "Model/provider provenance check"],
        "evidence": ["AI component inventory", "provider risk review", "dependency scan", "plugin manifest"],
        "positive_controls": ["AI SBOM", "signed artifacts", "provider due diligence", "dependency scanning"],
    },
    "LLM06": {
        "name": "Sensitive Information Disclosure",
        "description": "Sensitive prompts, context, memory, retrieval results, and outputs must be minimized, redacted, and isolated.",
        "attack": "An attacker elicits secrets, PII, system prompts, tenant data, memory, or logs through prompt manipulation or context leakage.",
        "impact": "Privacy breach, secret disclosure, tenant data exposure, and regulatory reporting obligations.",
        "objective": "Prove sensitive data is minimized before model calls and blocked from unauthorized output or cross-session memory.",
        "context": ["PII", "secret", "memory", "conversation history", "tenant", "system prompt"],
        "tests": ["Secret/PII prompt extraction test", "Cross-tenant memory test", "Output redaction validation"],
        "evidence": ["data minimization design", "redaction pipeline", "memory isolation policy", "model logging policy"],
        "positive_controls": ["PII redaction", "context isolation", "tenant scoped", "secret filtering"],
    },
    "LLM07": {
        "name": "Insecure Plugin and Tool Design",
        "description": "Tools and plugins used by agents must have least privilege, strong schemas, scoped credentials, and audited execution.",
        "attack": "An attacker manipulates the model into invoking powerful tools with attacker-controlled arguments or excessive permissions.",
        "impact": "Unauthorized data access, destructive actions, transaction abuse, or compromise through connected systems.",
        "objective": "Prove every tool has explicit permission boundaries, argument validation, and auditable execution controls.",
        "context": ["tool", "plugin", "function call", "MCP", "connector", "agent action"],
        "tests": ["Tool argument injection test", "Permission scope review", "Unauthorized tool invocation test"],
        "evidence": ["tool manifest", "permission scopes", "argument schema", "tool audit logs"],
        "positive_controls": ["allowlisted tools", "least privilege scoped", "argument schema validation", "tool audit logging"],
    },
    "LLM08": {
        "name": "Excessive Agency",
        "description": "Agent autonomy must be constrained by permissions, approvals, workflow state, and reversible actions.",
        "attack": "An attacker causes an agent to execute write, delete, purchase, deploy, or external communication actions beyond intended scope.",
        "impact": "Data loss, unauthorized transactions, production changes, legal exposure, or irreversible side effects.",
        "objective": "Prove agent actions are bounded, approved for high-impact operations, and fail safely when uncertain.",
        "context": ["agent", "autonomous", "write action", "delete", "execute", "approval"],
        "tests": ["Unauthorized write-action test", "Human approval bypass test", "Out-of-scope task test"],
        "evidence": ["agent permission matrix", "approval workflow", "action audit log", "rollback design"],
        "positive_controls": ["human approval", "read-only by default", "scoped permissions", "reversible actions"],
    },
    "LLM09": {
        "name": "Overreliance",
        "description": "AI outputs must be validated, confidence-scored, and reviewed before high-risk decisions or user-visible claims.",
        "attack": "An attacker or normal model error causes plausible but false, unsafe, or non-compliant output to be trusted automatically.",
        "impact": "Bad decisions, unsafe recommendations, compliance failure, user harm, or operational mistakes.",
        "objective": "Prove AI output has validation, uncertainty handling, human review, and fallback for high-impact decisions.",
        "context": ["decision", "recommendation", "confidence", "human review", "hallucination", "approval"],
        "tests": ["Hallucination handling test", "Low-confidence fallback test", "Human review workflow test"],
        "evidence": ["validation rules", "human review criteria", "confidence thresholds", "user disclosure design"],
        "positive_controls": ["human review", "confidence threshold", "source citation", "output validation"],
    },
    "LLM10": {
        "name": "Model Theft",
        "description": "Models, prompts, embeddings, proprietary data, and inference endpoints need access control, abuse monitoring, and extraction resistance.",
        "attack": "An attacker abuses query volume, side channels, prompt extraction, or endpoint access to steal model behavior or proprietary assets.",
        "impact": "Loss of intellectual property, competitive exposure, privacy leakage, and cost abuse.",
        "objective": "Prove model access is authorized, monitored for extraction patterns, rate-limited, and isolated from proprietary internals.",
        "context": ["model", "inference endpoint", "query volume", "embedding", "fine-tuned", "prompt extraction"],
        "tests": ["High-volume extraction simulation", "Prompt extraction test", "Inference anomaly detection review"],
        "evidence": ["model access logs", "rate-limit policy", "anomaly detection rules", "asset classification"],
        "positive_controls": ["model query monitoring", "token rate limits", "anomaly detection", "access control"],
    },
}


_CATEGORY_PROFILES.update({
    # Mobile and Kubernetes
    "M1": {"name": "Improper Credential Usage", "description": "Mobile credentials must be scoped, protected, and never embedded as reusable secrets.", "attack": "An attacker extracts API keys, tokens, or client secrets from app packages, logs, or local storage.", "impact": "API abuse, account compromise, and unauthorized backend access.", "objective": "Prove mobile clients use backend-mediated authentication and platform secure storage.", "context": ["mobile credential", "API key", "token", "keystore"], "tests": ["Reverse engineer package for secrets", "Inspect device storage", "Test token revocation"], "evidence": ["mobile storage design", "token policy", "secret scan"], "positive_controls": ["secure keystore", "short-lived tokens", "no embedded secrets"]},
    "M2": {"name": "Inadequate Supply Chain Security", "description": "Mobile dependencies, SDKs, build systems, and signing keys require provenance and tamper controls.", "attack": "An attacker compromises SDKs, build scripts, app signing, or update distribution.", "impact": "Malicious app release, data theft, or supply-chain compromise.", "objective": "Prove mobile builds are reproducible, signed, dependency-scanned, and protected by release approvals.", "context": ["SDK", "dependency", "signing", "mobile build"], "tests": ["Review dependency provenance", "Verify signing key controls", "Scan third-party SDKs"], "evidence": ["SBOM", "signing process", "release approvals"], "positive_controls": ["signed builds", "dependency scanning", "protected signing keys"]},
    "M3": {"name": "Insecure Authentication and Authorization", "description": "Mobile identity flows must resist token replay, weak biometrics, and backend authorization bypass.", "attack": "An attacker replays tokens, bypasses local checks, or calls APIs directly without server-side authorization.", "impact": "Account takeover and unauthorized API access.", "objective": "Prove backend APIs enforce authz independent of mobile UI state.", "context": ["mobile auth", "biometric", "token", "authorization"], "tests": ["Bypass local checks", "Replay tokens", "Call backend directly"], "evidence": ["auth flow", "backend authorization tests", "token validation"], "positive_controls": ["server-side authorization", "token binding", "MFA where needed"]},
    "M4": {"name": "Insufficient Input and Output Validation", "description": "Mobile apps and their APIs must validate untrusted input, deep links, IPC, WebView content, and server responses.", "attack": "An attacker abuses deep links, malformed responses, or WebView content to manipulate app behavior.", "impact": "Account abuse, data leakage, XSS in WebView, or unintended actions.", "objective": "Prove mobile input/output boundaries are schema validated and safely rendered.", "context": ["deep link", "WebView", "IPC", "server response"], "tests": ["Fuzz deep links", "Inject WebView payloads", "Tamper API responses"], "evidence": ["deep-link allowlist", "WebView settings", "schema validation"], "positive_controls": ["validated deep links", "WebView hardening", "response schema validation"]},
    "M5": {"name": "Insecure Communication", "description": "Mobile traffic must use modern TLS, certificate validation, and carefully justified pinning decisions.", "attack": "An attacker intercepts traffic through rogue Wi-Fi, proxying, weak TLS, or certificate validation bypass.", "impact": "Credential theft, session hijack, or data disclosure.", "objective": "Prove mobile network traffic cannot downgrade or accept untrusted certificates.", "context": ["TLS", "certificate", "pinning", "network security"], "tests": ["TLS interception test", "Certificate validation bypass test", "Downgrade test"], "evidence": ["network security config", "TLS scan", "pinning decision"], "positive_controls": ["TLS 1.2+", "certificate validation", "pinning for high-risk APIs"]},
    "M6": {"name": "Inadequate Privacy Controls", "description": "Mobile apps must minimize, protect, and disclose collection and transmission of personal data.", "attack": "An attacker or unauthorized SDK accesses PII, location, contacts, identifiers, or telemetry beyond consent.", "impact": "Privacy breach, regulatory exposure, and user harm.", "objective": "Prove personal data collection is minimized, consented, protected, and revocable.", "context": ["PII", "location", "privacy", "tracking", "permission"], "tests": ["Inspect SDK telemetry", "Review permission use", "Verify data minimization"], "evidence": ["data inventory", "privacy review", "permission rationale"], "positive_controls": ["data minimization", "runtime permission gating", "privacy-preserving analytics"]},
    "M7": {"name": "Insufficient Binary Protections", "description": "Mobile binaries should resist reverse engineering, tampering, and runtime manipulation appropriate to risk.", "attack": "An attacker modifies the app, hooks runtime methods, or bypasses local controls after reverse engineering.", "impact": "Fraud, API abuse, and bypass of client-side safety checks.", "objective": "Prove critical protections are server-side and the client has tamper detection where risk justifies it.", "context": ["binary", "reverse engineering", "tamper", "root", "jailbreak"], "tests": ["Tamper app package", "Runtime hook test", "Root/jailbreak behavior review"], "evidence": ["binary protection config", "server-side enforcement", "tamper telemetry"], "positive_controls": ["server-side control enforcement", "tamper detection", "obfuscation for sensitive paths"]},
    "M9": {"name": "Insecure Data Storage", "description": "Sensitive mobile data must be minimized and stored only in platform-protected storage.", "attack": "An attacker extracts files, logs, caches, screenshots, or backups from the device.", "impact": "PII, token, or business data disclosure from lost or compromised devices.", "objective": "Prove sensitive local data is encrypted, minimized, and excluded from insecure backups/logs.", "context": ["local storage", "cache", "backup", "logs", "keystore"], "tests": ["Inspect local filesystem", "Review logs/screenshots/backups", "Test lost-device data exposure"], "evidence": ["storage inventory", "keystore usage", "backup exclusion config"], "positive_controls": ["encrypted local storage", "secure keystore", "no sensitive logs"]},
    "K01": {"name": "Kubernetes Insecure Workload Configuration", "description": "Kubernetes workloads must run with restricted privileges, safe admission controls, and least-privilege identities.", "attack": "An attacker abuses privileged pods, host mounts, broad service accounts, or missing admission controls.", "impact": "Container escape, cluster compromise, and lateral movement.", "objective": "Prove workloads follow restricted pod security and least-privilege runtime policy.", "context": ["pod", "container", "cluster", "privileged", "service account"], "tests": ["Review Pod Security Standards", "Check service account permissions", "Attempt privileged workload deployment"], "evidence": ["admission policy", "RBAC bindings", "pod specs"], "positive_controls": ["restricted pods", "non-root containers", "read-only filesystem", "least-privilege service accounts"]},
    "K03": {"name": "Kubernetes Overly Permissive RBAC", "description": "Cluster roles and bindings must avoid wildcard, cluster-admin, and broad namespace permissions.", "attack": "An attacker compromises a pod or user and uses broad RBAC to control the cluster.", "impact": "Privilege escalation, secret theft, workload takeover, or cluster-wide compromise.", "objective": "Prove Kubernetes identities have only the verbs and resources required.", "context": ["RBAC", "cluster-admin", "rolebinding", "service account"], "tests": ["Audit wildcard roles", "Review service account tokens", "Test namespace boundary access"], "evidence": ["RBAC inventory", "least-privilege review", "audit logs"], "positive_controls": ["minimal RBAC", "no wildcard roles", "short-lived service account tokens"]},
    "K07": {"name": "Kubernetes Network Segmentation", "description": "Namespaces and workloads require explicit ingress and egress policy to reduce lateral movement.", "attack": "An attacker moves from a compromised pod to internal services because east-west traffic is unrestricted.", "impact": "Lateral movement, data-store access, and service compromise.", "objective": "Prove default-deny network policy and explicit service communication paths.", "context": ["network policy", "namespace", "east-west", "service mesh"], "tests": ["Attempt cross-namespace connection", "Review default-deny policy", "Validate egress restrictions"], "evidence": ["NetworkPolicy manifests", "service mesh policy", "flow logs"], "positive_controls": ["default deny network policy", "egress allowlist", "mTLS service mesh"]},
    "K08": {"name": "Kubernetes Secrets Management", "description": "Cluster secrets must be encrypted, scoped, rotated, and kept out of images, env dumps, and logs.", "attack": "An attacker reads Kubernetes secrets through etcd, broad RBAC, pod environment variables, or leaked manifests.", "impact": "Credential disclosure and compromise of connected services.", "objective": "Prove secrets are encrypted at rest, mounted with least privilege, and rotated after exposure.", "context": ["secret", "etcd", "configmap", "vault", "environment variable"], "tests": ["Review secret access RBAC", "Check etcd encryption", "Search images/manifests for secrets"], "evidence": ["secret inventory", "etcd encryption config", "rotation records"], "positive_controls": ["etcd encryption", "external secrets manager", "secret rotation", "least-privilege mounts"]},
})


_CATEGORY_PROFILES.update({
    # CSA and cloud-native categories
    "CSA01": {"name": "Misconfiguration and Inadequate Change Control", "description": "Cloud resources must be deployed from hardened IaC and monitored for drift.", "attack": "An attacker finds public, default, or drifted cloud resources and exploits the exposed path.", "impact": "Cloud data exposure, unauthorized access, and service compromise.", "objective": "Prove cloud changes are reviewed, scanned, and continuously checked against baseline.", "context": ["misconfiguration", "IaC", "public", "security group"], "tests": ["Run IaC scan", "Review public exposure", "Check config drift"], "evidence": ["IaC templates", "CSPM findings", "change approvals"], "positive_controls": ["CSPM monitoring", "IaC security gates", "private by default"]},
    "CSA02": {"name": "Identity and Access Management Weakness", "description": "Cloud identities must use least privilege, MFA, short-lived credentials, and strong federation.", "attack": "An attacker abuses overprivileged roles, static keys, missing MFA, or weak trust policies.", "impact": "Cloud account takeover, privilege escalation, and data-plane compromise.", "objective": "Prove cloud IAM is least privilege, federated, monitored, and free of stale static keys.", "context": ["IAM", "role", "MFA", "access key", "policy"], "tests": ["Audit admin permissions", "Find stale keys", "Review role trust policies"], "evidence": ["IAM inventory", "access analyzer", "MFA report"], "positive_controls": ["least-privilege IAM", "MFA enforced", "OIDC federation", "short-lived credentials"]},
    "CSA03": {"name": "Insecure Interfaces and APIs", "description": "Cloud management and service APIs require strong auth, validation, throttling, and exposure control.", "attack": "An attacker abuses exposed management APIs, weak tokens, or unbounded cloud service endpoints.", "impact": "Resource manipulation, data exposure, and control-plane compromise.", "objective": "Prove cloud APIs have strong identity, least exposure, and monitoring.", "context": ["cloud API", "management API", "gateway", "token"], "tests": ["Review API exposure", "Validate token controls", "Check throttling"], "evidence": ["API gateway policy", "cloud audit logs", "auth configuration"], "positive_controls": ["private endpoints", "API throttling", "strong auth", "audit logging"]},
    "CSA06": {"name": "Insecure Software Development", "description": "Cloud software delivery must include secure SDLC, IaC review, artifact integrity, and vulnerability gates.", "attack": "An attacker compromises build pipelines, images, functions, or IaC to deploy vulnerable or malicious workloads.", "impact": "Supply-chain compromise and cloud workload takeover.", "objective": "Prove cloud workloads are built, scanned, signed, and deployed through governed pipelines.", "context": ["CI/CD", "image", "IaC", "artifact", "serverless"], "tests": ["Verify scanner gates", "Check image provenance", "Review deployment approvals"], "evidence": ["pipeline logs", "SCA/SAST results", "artifact signatures"], "positive_controls": ["signed images", "SAST/SCA gates", "IaC scanning", "protected deployments"]},
    "CSA07": {"name": "Accidental Cloud Data Disclosure", "description": "Cloud storage, logs, snapshots, and analytics data require classification, access control, and encryption.", "attack": "An attacker discovers public buckets, exposed snapshots, verbose logs, or shared analytics exports.", "impact": "Sensitive-data disclosure and regulatory breach.", "objective": "Prove data stores are private, encrypted, classified, and protected from accidental sharing.", "context": ["bucket", "snapshot", "storage", "PII", "logs"], "tests": ["Scan public storage", "Review snapshots and logs", "Verify data classification"], "evidence": ["storage policy", "DLP scan", "encryption config"], "positive_controls": ["block public access", "KMS encryption", "data classification", "DLP monitoring"]},
    "CSA08": {"name": "System Vulnerabilities", "description": "Cloud workloads need continuous vulnerability detection, patching, and exposure-based prioritization.", "attack": "An attacker targets known CVEs in internet-facing or privileged cloud workloads.", "impact": "Workload compromise, lateral movement, and data theft.", "objective": "Prove cloud vulnerabilities are found, prioritized by exposure, and remediated within SLA.", "context": ["CVE", "patch", "image", "VM", "container"], "tests": ["Run vulnerability scan", "Check patch SLA", "Review exposed workload CVEs"], "evidence": ["scanner reports", "patch records", "asset inventory"], "positive_controls": ["continuous scanning", "patch SLA", "golden images", "exposure-based prioritization"]},
    "CSA11": {"name": "Cloud Incident Response and Resilience Gaps", "description": "Cloud environments need tested detection, containment, backup, restore, and forensic readiness.", "attack": "An attacker persists or destroys resources while teams lack logs, isolation paths, or recovery plans.", "impact": "Long dwell time, data loss, prolonged outage, and weak forensic reconstruction.", "objective": "Prove incident response, backup, and recovery are cloud-specific and tested.", "context": ["incident", "backup", "restore", "forensic", "CloudTrail"], "tests": ["Run tabletop exercise", "Test restore", "Validate log retention and isolation"], "evidence": ["IR runbook", "backup restore report", "audit log retention"], "positive_controls": ["tested backups", "cloud IR runbook", "central audit logging", "containment automation"]},
    "C01": {"name": "Insecure Cloud Configuration", "description": "Cloud-native platforms must avoid public, privileged, or default configurations.", "attack": "An attacker exploits exposed containers, buckets, network policies, or orchestrator defaults.", "impact": "Cloud workload compromise and data exposure.", "objective": "Prove cloud-native defaults are hardened and continuously monitored.", "context": ["container", "bucket", "orchestrator", "public"], "tests": ["CSPM scan", "runtime exposure review", "IaC baseline check"], "evidence": ["CSPM report", "IaC policy", "runtime config"], "positive_controls": ["hardened baseline", "private by default", "policy as code"]},
    "C02": {"name": "Injection and SSRF in Cloud Workloads", "description": "Cloud workloads must protect metadata, serverless, and internal service access from injection and SSRF.", "attack": "An attacker reaches cloud metadata or internal APIs through injection or server-side fetch behavior.", "impact": "Credential theft and workload identity compromise.", "objective": "Prove metadata access is hardened and outbound calls are controlled.", "context": ["SSRF", "metadata", "lambda", "container"], "tests": ["Metadata SSRF test", "Outbound allowlist test", "Function injection test"], "evidence": ["IMDSv2 config", "egress policy", "function validation"], "positive_controls": ["IMDSv2", "metadata blocked", "egress allowlist"]},
    "C03": {"name": "Weak Cloud Identity", "description": "Cloud-native identities require least privilege and short-lived workload credentials.", "attack": "An attacker steals or abuses broad workload identities.", "impact": "Control-plane and data-plane compromise.", "objective": "Prove workload identities are scoped, rotated, and audited.", "context": ["workload identity", "IAM", "service account"], "tests": ["Privilege review", "Token theft simulation", "Audit role assumptions"], "evidence": ["IAM policy", "workload identity config", "audit logs"], "positive_controls": ["least privilege", "short-lived credentials", "federated identity"]},
    "C04": {"name": "Cloud-Native Supply Chain", "description": "Images, functions, charts, and IaC require provenance, scanning, and release controls.", "attack": "An attacker injects vulnerable or malicious artifacts into deployment paths.", "impact": "Compromised workloads and persistent supply-chain exposure.", "objective": "Prove artifact provenance and release gates before runtime.", "context": ["image", "chart", "function", "IaC"], "tests": ["Signature verification", "Image scanning", "Provenance review"], "evidence": ["artifact registry", "signature records", "scanner output"], "positive_controls": ["signed images", "SBOM", "release gates"]},
    "C05": {"name": "Secrets Exposure", "description": "Cloud-native secrets must be externalized, encrypted, scoped, and rotated.", "attack": "An attacker extracts secrets from env vars, config maps, images, logs, or overly broad roles.", "impact": "Credential compromise and lateral movement.", "objective": "Prove secrets are not embedded and are accessible only to authorized workloads.", "context": ["secret", "configmap", "env var", "vault"], "tests": ["Secret scan", "Runtime env inspection", "RBAC review"], "evidence": ["secret inventory", "vault policy", "rotation logs"], "positive_controls": ["external secrets manager", "secret rotation", "encryption at rest"]},
    "C06": {"name": "Overprivileged Workloads", "description": "Cloud-native workloads must avoid root, privileged mode, host mounts, and broad permissions.", "attack": "An attacker escapes or escalates through excessive runtime privileges.", "impact": "Host compromise and cluster takeover.", "objective": "Prove workloads run with minimum runtime and cloud permissions.", "context": ["privileged", "root", "hostPath", "wildcard"], "tests": ["Runtime privilege review", "Admission policy test", "IAM permission review"], "evidence": ["pod specs", "admission policy", "IAM policy"], "positive_controls": ["non-root", "restricted pod security", "least privilege"]},
    "C07": {"name": "Resource Exhaustion", "description": "Cloud-native workloads need quotas, limits, autoscaling guardrails, and cost monitoring.", "attack": "An attacker or bug consumes compute, memory, concurrency, or cloud budget.", "impact": "Outage, noisy-neighbor impact, and runaway costs.", "objective": "Prove resource use is bounded per workload and tenant.", "context": ["quota", "limit", "autoscaling", "concurrency"], "tests": ["Load test limits", "Quota bypass test", "Cost alert drill"], "evidence": ["resource limits", "quota policy", "billing alerts"], "positive_controls": ["resource limits", "autoscaling caps", "cost alerts"]},
    "C08": {"name": "Cloud Data Protection", "description": "Cloud-native data stores, logs, snapshots, and queues require encryption, access control, and lifecycle policy.", "attack": "An attacker reads sensitive data from weakly protected cloud storage or logs.", "impact": "Data breach and compliance exposure.", "objective": "Prove sensitive data stores are classified, encrypted, and access-controlled.", "context": ["storage", "snapshot", "logs", "queue", "PII"], "tests": ["Encryption check", "Access policy review", "Snapshot exposure review"], "evidence": ["KMS config", "storage policy", "data classification"], "positive_controls": ["KMS encryption", "private storage", "lifecycle policy"]},
    "C09": {"name": "Insufficient Cloud Detection", "description": "Cloud-native platforms require control-plane, data-plane, and workload telemetry with alerting.", "attack": "An attacker performs suspicious actions without producing actionable alerts.", "impact": "Delayed detection and weak containment.", "objective": "Prove critical cloud and workload events reach monitored alert channels.", "context": ["CloudTrail", "audit", "flow logs", "alert"], "tests": ["Trigger alert events", "Review log coverage", "Run detection tabletop"], "evidence": ["audit logs", "SIEM rules", "alert history"], "positive_controls": ["central logging", "flow logs", "SIEM alerting"]},
    "C10": {"name": "Weak Cloud Recovery", "description": "Cloud-native systems require tested backup, restore, disaster recovery, and containment automation.", "attack": "An attacker deletes or encrypts resources while recovery paths are untested.", "impact": "Data loss and prolonged outage.", "objective": "Prove recovery objectives are documented and tested.", "context": ["backup", "restore", "DR", "RTO", "RPO"], "tests": ["Restore test", "Failover test", "Containment runbook test"], "evidence": ["backup policy", "restore report", "DR plan"], "positive_controls": ["tested backups", "defined RTO/RPO", "immutable backup"]},
})


_CATEGORY_PROFILES.update({
    # Architecture principles and DevSecOps
    "ZERO_TRUST": {"name": "Zero Trust Architecture", "description": "Trust must be continuously verified and never inferred from network location.", "attack": "An attacker who reaches an internal network or VPN pivots laterally because services assume internal equals trusted.", "impact": "Lateral movement, broad service compromise, and privilege escalation.", "objective": "Prove every request is authenticated, authorized, and evaluated with identity, device, context, and resource policy.", "context": ["internal network", "VPN", "service-to-service", "trust boundary"], "tests": ["Internal service access test", "Service identity review", "Trust-boundary walk-through"], "evidence": ["ZTA design", "service auth policy", "network segmentation"], "positive_controls": ["continuous verification", "mTLS", "micro-segmentation", "per-resource authorization"]},
    "DEFENCE_IN_DEPTH": {"name": "Defense in Depth", "description": "Controls should overlap across identity, network, host, application, data, and monitoring layers.", "attack": "An attacker bypasses one control and progresses because no independent layer stops or detects the activity.", "impact": "Single-control failure becomes full compromise.", "objective": "Prove each critical path has preventive, detective, and recovery controls at more than one layer.", "context": ["firewall", "WAF", "host", "application", "data", "monitoring"], "tests": ["Control-layer mapping", "Bypass scenario review", "Detection point validation"], "evidence": ["control map", "network zones", "EDR/WAF/SIEM configuration"], "positive_controls": ["layered controls", "independent detection", "segmented data tier"]},
    "LEAST_PRIVILEGE": {"name": "Least Privilege", "description": "Human, service, workload, and pipeline identities should have only the permissions they need for the shortest useful time.", "attack": "An attacker steals a broad or standing credential and immediately gains privileged access.", "impact": "Privilege escalation, data breach, and destructive administrative actions.", "objective": "Prove permissions are minimal, time-bound where possible, reviewed, and tied to business need.", "context": ["admin", "root", "service account", "RBAC", "permission"], "tests": ["Permission entitlement review", "Standing admin discovery", "Service-account blast-radius test"], "evidence": ["RBAC matrix", "PAM/JIT records", "access review"], "positive_controls": ["JIT access", "PAM", "quarterly access review", "minimal service permissions"]},
    "FAIL_SECURE": {"name": "Fail Secure", "description": "Security controls must default to deny and preserve safety when dependencies fail or time out.", "attack": "An attacker causes an error, timeout, or dependency failure that makes the system fail open.", "impact": "Authentication bypass, authorization bypass, or unsafe access during degraded mode.", "objective": "Prove all failure paths for auth, policy, encryption, and validation deny by default and log the event.", "context": ["timeout", "exception", "fallback", "default allow", "dependency failure"], "tests": ["Disconnect auth/policy services", "Force timeout and exception paths", "Review fallback logic"], "evidence": ["failure-mode tests", "exception handling code", "degraded-mode design"], "positive_controls": ["deny on failure", "circuit breaker", "safe fallback", "failure audit logging"]},
    "SEPARATION_OF_DUTIES": {"name": "Separation of Duties", "description": "No single actor should be able to create, approve, and deploy high-impact changes without independent control.", "attack": "A malicious or compromised insider pushes unreviewed code, configuration, or production changes.", "impact": "Undetected malicious release, fraud, or production compromise.", "objective": "Prove high-risk actions require independent approval and separate credentials.", "context": ["deploy", "release", "approval", "production", "merge"], "tests": ["Branch protection review", "Deployment permission test", "Emergency change review"], "evidence": ["approval trail", "branch protection", "deployment roles"], "positive_controls": ["two-person approval", "protected branches", "separate deployment credentials"]},
    "SECURITY_BY_DESIGN": {"name": "Security by Design", "description": "Security requirements and threat-model decisions must be explicit design inputs, not post-build patches.", "attack": "An attacker exploits workflows where no control objective, abuse case, or trust boundary was defined.", "impact": "Structural vulnerabilities that are expensive to retrofit.", "objective": "Prove security requirements, abuse cases, and acceptance criteria exist before implementation.", "context": ["design", "requirements", "threat model", "abuse case"], "tests": ["Design review", "Security requirement traceability", "Abuse-case workshop"], "evidence": ["threat model", "security requirements", "ADR", "acceptance criteria"], "positive_controls": ["security requirements", "formal threat model", "secure design review"]},
    "RISK_MANAGEMENT": {"name": "Risk Management", "description": "Risks must be identified, owned, prioritized, treated, and revalidated throughout the system lifecycle.", "attack": "Known risks remain unmanaged or unowned until they become incidents.", "impact": "Unaccepted exposure, audit failure, and poor prioritization.", "objective": "Prove each material risk has an owner, treatment plan, due date, and residual-risk decision.", "context": ["risk", "owner", "treatment", "acceptance", "register"], "tests": ["Risk register review", "Residual-risk signoff check", "Control effectiveness review"], "evidence": ["risk register", "control owner matrix", "acceptance records"], "positive_controls": ["risk owner assigned", "treatment plan", "residual risk accepted"]},
    "BCP_DR": {"name": "Business Continuity and Disaster Recovery", "description": "Critical services require tested recovery objectives, backups, failover, and dependency continuity plans.", "attack": "An attacker or outage destroys availability while recovery assumptions are untested.", "impact": "Prolonged outage, data loss, and business interruption.", "objective": "Prove backup and recovery meet documented RTO/RPO under realistic failure conditions.", "context": ["backup", "restore", "DR", "failover", "RTO", "RPO"], "tests": ["Restore drill", "Failover test", "Dependency outage exercise"], "evidence": ["DR plan", "restore test results", "backup inventory"], "positive_controls": ["tested restore", "defined RTO/RPO", "immutable backups"]},
    "ASSET_CLASSIFICATION": {"name": "Asset Classification", "description": "Assets and data must be classified so controls match sensitivity and business criticality.", "attack": "An attacker benefits when sensitive assets are treated like low-risk assets with weak controls.", "impact": "Underprotected sensitive data, poor monitoring, and weak recovery planning.", "objective": "Prove critical assets are inventoried, classified, owned, and mapped to required controls.", "context": ["asset", "classification", "data", "criticality", "owner"], "tests": ["Asset inventory review", "Data classification sample", "Control mapping check"], "evidence": ["asset inventory", "data classification", "owner register"], "positive_controls": ["classified assets", "data owner assigned", "control tiering"]},
    "CONTINUOUS_MONITORING": {"name": "Continuous Monitoring", "description": "Systems need ongoing telemetry, alerting, and control-health monitoring across security-critical paths.", "attack": "An attacker operates undetected because control failure or suspicious behavior is not monitored.", "impact": "Long dwell time, weak forensics, and delayed containment.", "objective": "Prove security events and control failures are logged, correlated, alerted, and reviewed.", "context": ["monitoring", "alert", "SIEM", "telemetry", "audit"], "tests": ["Trigger detection events", "Review alert routing", "Validate log retention"], "evidence": ["SIEM rules", "dashboards", "alert history"], "positive_controls": ["SIEM alerting", "centralized telemetry", "control health checks"]},
    "PATCH_MANAGEMENT": {"name": "Patch Management", "description": "Vulnerabilities must be detected and remediated according to criticality, exposure, and compensating controls.", "attack": "An attacker exploits known unpatched vulnerabilities in exposed or privileged components.", "impact": "Remote code execution, privilege escalation, and lateral movement.", "objective": "Prove assets are scanned and patched within SLA, with exceptions tracked and compensated.", "context": ["patch", "CVE", "vulnerability", "version", "scanner"], "tests": ["Patch SLA review", "Exposure-based vulnerability sampling", "Exception review"], "evidence": ["vulnerability scan", "patch records", "exception register"], "positive_controls": ["patch SLA", "continuous scanning", "compensating controls"]},
    "SECURITY_ARCHITECTURE_REVIEW": {"name": "Security Architecture Review", "description": "Material design changes should receive formal security architecture review before production release.", "attack": "A risky design enters production without threat modeling, control mapping, or security signoff.", "impact": "Preventable design flaws, audit gaps, and launch delays.", "objective": "Prove high-impact changes are reviewed, documented, and signed off with open risks tracked.", "context": ["architecture review", "design review", "signoff", "production"], "tests": ["Review change intake criteria", "Sample recent designs", "Check signoff artifacts"], "evidence": ["review record", "ADR", "threat model", "risk acceptance"], "positive_controls": ["formal review", "security signoff", "open-risk tracking"]},
    "SECURITY_FRAMEWORKS": {"name": "Security Framework Alignment", "description": "Security design should map to accepted frameworks so control coverage is complete and auditable.", "attack": "Controls become inconsistent or incomplete because no baseline framework defines expected coverage.", "impact": "Control gaps, audit findings, and uneven security posture.", "objective": "Prove the architecture maps to a chosen framework and exceptions are explicit.", "context": ["framework", "NIST", "ISO", "CIS", "control"], "tests": ["Framework mapping review", "Exception review", "Audit evidence sample"], "evidence": ["control mapping", "policy baseline", "exception register"], "positive_controls": ["NIST/ISO/CIS mapping", "control owner", "evidence collection"]},
    "MFA": {"name": "Multi-Factor Authentication", "description": "Privileged and sensitive access requires phishing-resistant or strong MFA with recovery safeguards.", "attack": "An attacker uses stolen credentials or weak recovery flows to access privileged functions.", "impact": "Account takeover and administrative compromise.", "objective": "Prove MFA covers privileged and high-risk access and cannot be bypassed through recovery or legacy paths.", "context": ["MFA", "2FA", "admin", "login", "recovery"], "tests": ["MFA bypass test", "Legacy auth review", "Recovery flow review"], "evidence": ["IdP policy", "MFA enrollment report", "exception list"], "positive_controls": ["MFA enforced", "phishing-resistant MFA", "recovery flow hardening"]},
    "SAST": {"name": "Static Application Security Testing", "description": "Source code should be scanned early with tuned rules and release gates for exploitable findings.", "attack": "A vulnerability ships because source-level patterns were never detected or triaged.", "impact": "Known code weakness reaches production.", "objective": "Prove SAST runs on every change, is tuned to the stack, and blocks unacceptable risk.", "context": ["SAST", "code scan", "static analysis", "repository"], "tests": ["Pipeline SAST gate review", "False-positive tuning review", "Sample finding remediation"], "evidence": ["SAST reports", "pipeline config", "triage history"], "positive_controls": ["SAST gate", "tuned rules", "finding ownership"]},
    "DAST": {"name": "Dynamic Application Security Testing", "description": "Running applications should be tested for exploitable behavior at HTTP/API boundaries.", "attack": "A runtime-only issue ships because code or dependency scanning did not exercise behavior.", "impact": "Exploitable web/API weakness in production.", "objective": "Prove DAST runs against representative environments with authentication and useful coverage.", "context": ["DAST", "dynamic scan", "runtime", "staging"], "tests": ["Authenticated DAST review", "Coverage check", "Remediation sampling"], "evidence": ["DAST report", "test credentials", "coverage metrics"], "positive_controls": ["authenticated DAST", "runtime scanning", "release gate"]},
    "SCA": {"name": "Software Composition Analysis", "description": "Dependencies require inventory, vulnerability monitoring, license review, and release blocking for severe issues.", "attack": "An attacker exploits a vulnerable dependency or transitive package.", "impact": "Remote compromise or supply-chain exposure.", "objective": "Prove dependency risk is continuously detected and remediated.", "context": ["SCA", "dependency", "package", "SBOM"], "tests": ["Dependency scan review", "Critical CVE gate test", "SBOM completeness check"], "evidence": ["SCA report", "SBOM", "dependency policy"], "positive_controls": ["SCA gate", "SBOM", "dependency update automation"]},
    "SECRETS_SCANNING": {"name": "Secrets Scanning", "description": "Secrets must be prevented from entering source, artifacts, logs, and tickets, with rapid revocation when found.", "attack": "An attacker finds leaked credentials in repositories, build logs, containers, or support artifacts.", "impact": "Credential compromise and unauthorized access.", "objective": "Prove secrets are scanned, blocked, revoked, and rotated across the delivery chain.", "context": ["secret", "API key", "password", "token", "repository"], "tests": ["Seed test secret in safe branch", "Review revocation workflow", "Scan artifacts/logs"], "evidence": ["secret scan results", "revocation records", "pre-commit hooks"], "positive_controls": ["secret scanning", "push protection", "automatic revocation"]},
    "IAC_SECURITY": {"name": "Infrastructure as Code Security", "description": "Infrastructure definitions need policy-as-code checks before deployment.", "attack": "An insecure cloud resource is repeatedly deployed from vulnerable IaC.", "impact": "Persistent misconfiguration and cloud exposure.", "objective": "Prove IaC is scanned and blocked for high-risk misconfigurations.", "context": ["Terraform", "CloudFormation", "IaC", "policy"], "tests": ["IaC scanner gate test", "Public exposure policy test", "Exception review"], "evidence": ["IaC scan", "policy-as-code config", "deployment logs"], "positive_controls": ["Checkov/tfsec gate", "policy as code", "approved exceptions"]},
    "CONTAINER_SECURITY": {"name": "Container Security", "description": "Container images and runtime configuration require hardening, scanning, signing, and least privilege.", "attack": "An attacker exploits vulnerable images or excessive runtime privileges.", "impact": "Workload compromise and lateral movement.", "objective": "Prove images are trusted and containers run with minimal privileges.", "context": ["container", "image", "Docker", "registry"], "tests": ["Image scan", "Signature verification", "Runtime privilege review"], "evidence": ["image scan report", "Dockerfile", "runtime policy"], "positive_controls": ["signed images", "non-root", "read-only filesystem", "image scanning"]},
    "PENETRATION_TESTING": {"name": "Penetration Testing", "description": "High-risk systems need adversarial validation of controls, chained attack paths, and remediation closure.", "attack": "Realistic attack paths remain unknown because controls were only reviewed individually.", "impact": "Launch with exploitable chained vulnerabilities.", "objective": "Prove material attack paths have been tested and remediation verified.", "context": ["pentest", "red team", "attack path", "validation"], "tests": ["Scope pentest", "Track remediation", "Retest closed findings"], "evidence": ["pentest report", "remediation plan", "retest evidence"], "positive_controls": ["annual pentest", "retest completed", "attack path validation"]},
    "ASVS": {"name": "Application Security Verification Standard", "description": "Application controls should map to verification requirements appropriate to system risk.", "attack": "Controls are inconsistent because no verification standard defines required depth.", "impact": "Coverage gaps and audit ambiguity.", "objective": "Prove application controls meet a selected ASVS level and evidence exists.", "context": ["ASVS", "verification", "control", "standard"], "tests": ["ASVS level selection", "Requirement mapping", "Evidence sampling"], "evidence": ["ASVS checklist", "test evidence", "control map"], "positive_controls": ["ASVS mapping", "verification evidence", "risk-based level"]},
    "ARTIFACT_SIGNING": {"name": "Artifact Signing and Provenance", "description": "Build artifacts require cryptographic signing, provenance, and verification before deployment.", "attack": "An attacker replaces or tampers with artifacts between build and production.", "impact": "Malicious code deployment and supply-chain compromise.", "objective": "Prove deployment accepts only verified artifacts from trusted pipelines.", "context": ["artifact", "signature", "provenance", "SLSA"], "tests": ["Tampered artifact deploy test", "Signature verification review", "Provenance check"], "evidence": ["signing logs", "provenance metadata", "deployment policy"], "positive_controls": ["signed artifacts", "SLSA provenance", "verify before deploy"]},
    "SECURITY_TRAINING": {"name": "Security Training", "description": "Engineering teams need role-specific security training tied to recurring defect patterns.", "attack": "Repeat vulnerabilities occur because teams do not understand secure design and coding expectations.", "impact": "High defect rate and weak control ownership.", "objective": "Prove training is targeted, current, and linked to measured defect reduction.", "context": ["training", "developer", "secure coding", "awareness"], "tests": ["Training coverage review", "Defect trend analysis", "Role-specific content review"], "evidence": ["training records", "defect metrics", "curriculum"], "positive_controls": ["role-based training", "secure coding labs", "defect feedback loop"]},
    "SIEM_SOAR": {"name": "SIEM and SOAR", "description": "Operational detection and response need centralized telemetry, correlation, playbooks, and tested automation.", "attack": "An attacker avoids response because alerts are missing, noisy, or not actionable.", "impact": "Delayed containment and poor forensic readiness.", "objective": "Prove detections are mapped to material threats and response playbooks work.", "context": ["SIEM", "SOAR", "alert", "playbook", "logging"], "tests": ["Detection simulation", "Playbook tabletop", "Alert quality review"], "evidence": ["SIEM rules", "SOAR playbooks", "alert history"], "positive_controls": ["SIEM correlation", "SOAR playbooks", "tested detections"]},
    "POST_QUANTUM_CRYPTO": {"name": "Post-Quantum Cryptography Readiness", "description": "Long-lived secrets and crypto dependencies need inventory and migration planning for quantum risk.", "attack": "An attacker stores encrypted traffic or signatures now and decrypts or forges later when algorithms weaken.", "impact": "Future confidentiality loss and trust-chain failure.", "objective": "Prove cryptographic assets are inventoried and migration paths exist for quantum-vulnerable algorithms.", "context": ["RSA", "ECC", "TLS", "certificate", "long-lived data"], "tests": ["Crypto inventory review", "Long-lived data analysis", "Migration roadmap check"], "evidence": ["crypto inventory", "certificate inventory", "PQC migration plan"], "positive_controls": ["crypto inventory", "hybrid/PQC plan", "algorithm agility"]},
    "AI_SECURITY": {"name": "AI Security SDLC", "description": "AI features need model, prompt, tool, data, and evaluation controls in the delivery pipeline.", "attack": "AI risks ship because standard SDLC gates do not test prompt, retrieval, or tool behavior.", "impact": "Prompt injection, data leakage, unsafe agent actions, and weak monitoring.", "objective": "Prove AI security tests and controls are part of build and release gates.", "context": ["AI", "LLM", "RAG", "agent", "evaluation"], "tests": ["Prompt injection regression", "Tool abuse test", "RAG poisoning test"], "evidence": ["AI test suite", "model evals", "prompt/tool change review"], "positive_controls": ["AI security evals", "prompt injection tests", "tool permission review"]},
})


def _dedupe(items: Iterable[str], limit: int | None = None) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        text = str(item).strip()
        if not text:
            continue
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(text)
        if limit is not None and len(result) >= limit:
            break
    return result


def _titleize(value: str) -> str:
    words = re.sub(r"[_-]+", " ", value or "").strip()
    return words.title() if words else "Security Pattern"


def infer_ruleset(rule: dict) -> str:
    rule_id = str(rule.get("id", ""))
    category = str(rule.get("category", ""))
    if rule_id.startswith("WEB-"):
        return "web"
    if rule_id.startswith("API-"):
        return "api"
    if rule_id.startswith("AI-"):
        return "ai"
    if rule_id.startswith("MOB-"):
        return "mobile"
    if rule_id.startswith("CLD-"):
        return "cloud"
    if rule_id.startswith("ARCH-"):
        return "architecture"
    if rule_id.startswith("DSO-"):
        return "devsecops"
    if category.startswith("C") and category[1:].isdigit():
        return "cloud_native"
    return "architecture"


def _profile_for(category: str) -> dict[str, object]:
    if category in _CATEGORY_PROFILES:
        return _CATEGORY_PROFILES[category]
    if category.startswith("A") and len(category) >= 3:
        return _CATEGORY_PROFILES.get(category[:3], {})
    if category.startswith("API"):
        return _CATEGORY_PROFILES.get(category, {})
    if category.startswith("LLM"):
        return _CATEGORY_PROFILES.get(category, {})
    return {}


def _component_phrase(triggered_patterns: Iterable[str]) -> str:
    patterns = _dedupe(triggered_patterns, 6)
    if not patterns:
        return "the supplied architecture contains insufficient concrete evidence, so the reviewer should validate applicability with component owners"
    return "the architecture references " + ", ".join(patterns)


def _false_positive_guidance(rule: dict, profile: dict[str, object], control_evidence: Iterable[str], context_evidence: Iterable[str]) -> str:
    controls = _dedupe(control_evidence, 4)
    if controls:
        return "Treat as satisfied when the cited controls are implemented, tested, and enforced on the exact affected path: " + ", ".join(controls) + "."
    context = _dedupe(context_evidence, 4) or _dedupe(profile.get("context", []), 4)
    if context:
        return "Do not raise as an active issue unless the architecture actually includes this context and lacks the named control evidence: " + ", ".join(context) + "."
    return "Do not raise as an active issue without concrete architecture evidence and absence of compensating controls."


def enrich_rule(
    rule: dict,
    *,
    ruleset: str | None = None,
    triggered_patterns: Iterable[str] | None = None,
    control_evidence: Iterable[str] | None = None,
    context_evidence: Iterable[str] | None = None,
    match_confidence: str | None = None,
) -> dict:
    """Return detailed offline-only analyst context for a rule."""
    resolved_ruleset = ruleset or infer_ruleset(rule)
    ruleset_profile = _RULESET_PROFILES.get(resolved_ruleset, _RULESET_PROFILES["architecture"])
    category = str(rule.get("category", ""))
    profile = _profile_for(category)
    specific_attack = str(rule.get("attack_vector", "")).strip()
    pattern_name = str(rule.get("pattern_name") or specific_attack or profile.get("name") or _titleize(category))
    family = str(rule.get("pattern_family") or ruleset_profile.get("family", "Offline Security Pattern"))
    domain = str(ruleset_profile.get("domain", "Security architecture"))
    question = str(rule.get("question", "")).strip()
    rationale = str(rule.get("rationale", "")).strip()
    triggered = _dedupe(triggered_patterns or [], 8)
    context = _dedupe([*profile.get("context", []), *(context_evidence or [])], 8)
    positive_controls = _dedupe([*profile.get("positive_controls", []), *ruleset_profile.get("positive_controls", []), *(control_evidence or [])], 10)
    evidence_to_collect = _dedupe([*profile.get("evidence", []), *ruleset_profile.get("evidence", [])], 10)
    tests = _dedupe([*profile.get("tests", []), *ruleset_profile.get("tests", [])], 10)
    mitigations = _dedupe(rule.get("mitigations", []), 8)

    description = (
        f"{pattern_name}: {question} "
        f"{profile.get('description', rationale) or rationale} "
        f"This offline pattern belongs to {family} and is evaluated for {domain}."
    ).strip()
    if specific_attack:
        attack_vector = f"{specific_attack}: {question} In this review, {_component_phrase(triggered)}."
    else:
        attack_vector = (
            f"{profile.get('attack', 'An attacker exploits a missing or weak control on the affected architecture path.')} "
            f"In this review, {_component_phrase(triggered)}."
        ).strip()
    impact = (
        f"{profile.get('impact', rationale or 'Business, data, and service impact depends on the exposed component and missing control.')} "
        f"Rated {rule.get('severity', 'Medium')} before compensating-control review."
    ).strip()
    control_objective = str(rule.get("control_objective") or profile.get("objective") or f"Prove the control behind this question is implemented, enforced, monitored, and tested: {question}").strip()

    validation_steps = _dedupe([
        f"Confirm applicability by mapping the rule to concrete components and trust boundaries: {', '.join(context[:5]) or domain}.",
        f"Collect implementation evidence: {', '.join(evidence_to_collect[:5])}.",
        "Verify negative and abuse-case behavior, not only successful happy-path behavior.",
        "Check whether compensating controls are preventive, detective, and owned by an accountable team.",
        "Record residual risk, control owner, due date, and retest evidence for any open gap.",
        *tests,
    ], 12)
    recommended_tests = _dedupe([
        *tests,
        "Create at least one regression test or review checklist item for this control.",
        "Retest after remediation and attach evidence to the risk record.",
    ], 10)
    implementation_guidance = _dedupe([
        *mitigations,
        f"Define an owner and acceptance criteria for the {pattern_name} control.",
        f"Add monitoring that proves the {pattern_name} control is working in production.",
        "Document residual risk and compensating controls when full remediation is deferred.",
    ], 10)
    tags = _dedupe([
        resolved_ruleset,
        family,
        category,
        pattern_name,
        str(rule.get("severity", "")),
        *(str(p) for p in rule.get("patterns_to_check", [])[:8]),
    ], 16)

    quality_gates = {
        "has_attack_vector": bool(attack_vector),
        "has_impact": bool(impact),
        "has_control_objective": bool(control_objective),
        "has_validation_steps": len(validation_steps) >= 3,
        "has_false_positive_guidance": True,
        "offline_ready": True,
    }

    return {
        "pattern_name": pattern_name,
        "pattern_family": family,
        "pattern_domain": domain,
        "pattern_stage": str(profile.get("stage", "Design review")),
        "description": description,
        "attack_vector": attack_vector,
        "impact": impact,
        "control_objective": control_objective,
        "evidence_to_collect": evidence_to_collect,
        "validation_steps": validation_steps,
        "recommended_tests": recommended_tests,
        "false_positive_guidance": _false_positive_guidance(rule, profile, control_evidence or [], context_evidence or []),
        "positive_control_examples": positive_controls,
        "implementation_guidance": implementation_guidance,
        "applicability_context": context,
        "entry_points": _dedupe(ruleset_profile.get("entry_points", []), 8),
        "tags": tags,
        "pattern_quality": {
            "level": "industrial_offline",
            "match_confidence": match_confidence or "not_evaluated",
            "gates": quality_gates,
        },
    }


def list_enriched_patterns(rules_by_ruleset: dict[str, list[dict]], ruleset: str | None = None) -> list[dict]:
    """Return enriched rule metadata suitable for pattern catalog APIs."""
    selected = {ruleset: rules_by_ruleset.get(ruleset, [])} if ruleset else rules_by_ruleset
    patterns: list[dict] = []
    for name, rules in selected.items():
        for rule in rules:
            enriched = enrich_rule(rule, ruleset=name)
            patterns.append({
                "id": rule.get("id"),
                "category": rule.get("category", ""),
                "ruleset": name,
                "severity": rule.get("severity", "Medium"),
                "question": rule.get("question", ""),
                "rationale": rule.get("rationale", ""),
                "patterns_to_check": rule.get("patterns_to_check", []),
                "mitigations": rule.get("mitigations", []),
                "references": rule.get("references", []),
                **enriched,
            })
    return patterns
