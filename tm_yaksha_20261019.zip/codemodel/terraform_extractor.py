"""Regex + brace-depth extraction of security facts from Terraform (HCL) files.

Terraform is declarative — no functions, no call graph, no control flow — so
this shares nothing with :mod:`codemodel.polyglot_extractor` (built entirely
around imperative code: taint, reachability, a name-based call graph). It
follows :mod:`codemodel.config_extractor`'s convention instead: a hand-rolled,
stdlib-only (``re`` only, no HCL parser) scanner that mutates a
:class:`~codemodel.model.SystemModel` directly, one file at a time.

v1 is a bounded set of 6 checks against common AWS resource types, not a
general HCL parser or a clone of tfsec/Checkov:
  1. ``aws_s3_bucket`` with a public ACL
  2. ``aws_s3_bucket`` with no server-side-encryption resource declared
     *in the same file* (this is a per-file scanner like config_extractor —
     it does not join facts across files, so a bucket and its encryption
     config declared in separate .tf files will not be correlated; this is
     an accepted v1 limitation, not a bug)
  3. ``aws_security_group``/``aws_security_group_rule`` ingress open to 0.0.0.0/0
  4. ``aws_iam_policy``/``aws_iam_role_policy``/``aws_iam_user_policy`` with a
     wildcard Action or Resource
  5. hardcoded AWS credentials in a ``provider "aws"`` block
  6. ``aws_db_instance``/``aws_rds_cluster``/``aws_rds_cluster_instance`` with
     ``publicly_accessible = true``

Misconfiguration facts are surfaced as ``Control(kind="cloud-misconfig", ...)``
— a new kind value, not a new dataclass field, so this needs no changes to
``model.py``. ``codemodel/threats.py`` derives one "Cloud infrastructure
misconfiguration" finding per file from these Controls, folded into the
existing ``security-misconfig`` family. Hardcoded credentials reuse the
existing ``Secret`` fact, which the existing "Hardcoded secrets" threat
section already picks up with no changes needed there.
"""
from __future__ import annotations

import re

from .model import Control, DataStore, Secret

_RESOURCE_RE = re.compile(r'\bresource\s+"([A-Za-z0-9_]+)"\s+"([A-Za-z0-9_-]+)"\s*\{')
_PROVIDER_RE = re.compile(r'\bprovider\s+"([A-Za-z0-9_]+)"\s*\{')

_S3_BUCKET_TYPES = {"aws_s3_bucket"}
_S3_ENCRYPTION_TYPES = {"aws_s3_bucket_server_side_encryption_configuration"}
_SECURITY_GROUP_TYPES = {"aws_security_group", "aws_security_group_rule"}
_IAM_TYPES = {"aws_iam_policy", "aws_iam_role_policy", "aws_iam_user_policy"}
_PUBLIC_DB_TYPES = {"aws_db_instance", "aws_rds_cluster", "aws_rds_cluster_instance"}

_OPEN_CIDR = "0.0.0.0/0"


def _find_blocks(source: str, header_re: re.Pattern):
    """Yield (label groups, block_text, start_line) for each block matched by
    ``header_re``, using brace-depth counting from the opening ``{`` so
    nested blocks (``ingress {}``, ``tags {}``) don't truncate the match.
    Braces inside quoted strings never perturb the depth count.
    """
    for m in header_re.finditer(source):
        start = m.end() - 1  # index of the opening '{'
        depth = 0
        in_string = False
        i = start
        n = len(source)
        while i < n:
            c = source[i]
            if in_string:
                if c == "\\":
                    i += 2
                    continue
                if c == '"':
                    in_string = False
            elif c == '"':
                in_string = True
            elif c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        block_text = source[start:i + 1]
        line = source.count("\n", 0, m.start()) + 1
        yield m.groups(), block_text, line


def _literal_str(block: str, key: str) -> str | None:
    """A quoted string literal for ``key = "..."``, or None if absent or if
    the value is an interpolation/reference rather than a plain literal.
    """
    m = re.search(rf'\b{re.escape(key)}\s*=\s*"([^"]*)"', block)
    if not m:
        return None
    value = m.group(1)
    return None if "${" in value else value


def _literal_true(block: str, key: str) -> bool:
    return bool(re.search(rf'\b{re.escape(key)}\s*=\s*true\b', block))


def extract(source: str, rel: str, model) -> None:
    if not _RESOURCE_RE.search(source) and not _PROVIDER_RE.search(source):
        return  # not a resource/provider-bearing .tf file (vars.tf, outputs.tf, …)

    s3_bucket_names: set[str] = set()
    s3_encrypted_refs: set[str] = set()

    for (rtype, rname), block, line in _find_blocks(source, _RESOURCE_RE):
        if rtype in _S3_BUCKET_TYPES:
            s3_bucket_names.add(rname)
            model.data_stores.append(DataStore("object-storage", "s3", rel, line))
            acl = _literal_str(block, "acl")
            if acl and "public" in acl:
                model.controls.append(Control(
                    "cloud-misconfig",
                    f"S3 bucket '{rname}' has public ACL ('{acl}')", "resource", rel, line))

        elif rtype in _S3_ENCRYPTION_TYPES:
            ref = re.search(r'\baws_s3_bucket\.([A-Za-z0-9_-]+)\.', block)
            if ref:
                s3_encrypted_refs.add(ref.group(1))

        elif rtype in _SECURITY_GROUP_TYPES:
            is_ingress = rtype == "aws_security_group" or _literal_str(block, "type") == "ingress"
            if is_ingress and _OPEN_CIDR in block:
                model.controls.append(Control(
                    "cloud-misconfig",
                    f"Security group '{rname}' allows ingress from {_OPEN_CIDR}",
                    "resource", rel, line))

        elif rtype in _IAM_TYPES:
            # Matches both raw/heredoc JSON policy text (`"Action": "*"`) and
            # jsonencode({...}) HCL-object policy text (`Action = "*"`).
            if re.search(r'"?Action"?\s*[:=]\s*"\*"', block) or \
                    re.search(r'"?Resource"?\s*[:=]\s*"\*"', block):
                model.controls.append(Control(
                    "cloud-misconfig",
                    f"IAM policy '{rname}' grants a wildcard action or resource",
                    "resource", rel, line))

        elif rtype in _PUBLIC_DB_TYPES:
            model.data_stores.append(DataStore("sql", "rds", rel, line))
            if _literal_true(block, "publicly_accessible"):
                model.controls.append(Control(
                    "cloud-misconfig",
                    f"Database '{rname}' is publicly accessible", "resource", rel, line))

    for (ptype,), block, line in _find_blocks(source, _PROVIDER_RE):
        if ptype != "aws":
            continue
        for key in ("access_key", "secret_key"):
            if _literal_str(block, key):
                model.secrets.append(Secret(f"aws provider {key}", rel, line, managed=False))

    for name in sorted(s3_bucket_names - s3_encrypted_refs):
        model.controls.append(Control(
            "cloud-misconfig",
            f"S3 bucket '{name}' has no server-side encryption configuration in this file",
            "resource", rel, 0))
