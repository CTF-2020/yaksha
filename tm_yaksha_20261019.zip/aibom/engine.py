"""AI-BOM scan engine: static AI-usage inventory + AI-specific risk findings.

Walks a working tree (read-only, stdlib-only) and produces:
  components  — the AI bill of materials: provider SDKs, frameworks, vector DBs,
                local-inference stacks, model ids, provider endpoints, credential
                references, MCP integrations, and committed model artifacts.
  findings    — AI-specific risks (hardcoded keys, prompt-injection exposure,
                LLM-output-to-exec sinks, over-privileged agent tools, unpinned
                supply chain), mapped to OWASP LLM Top 10 2025 + CWE.
  stats       — file counts, provider/model rollups, and capability flags
                (rag / agents / mcp / local_models / provider_apis).

Detection is layered: dependency manifests give high-confidence components,
Python AST imports give high-confidence usage, and content regexes (quoted model
ids, endpoints, env keys) fill in the rest at medium confidence. Context gating
keeps noise down — behavioral findings only fire in files that also show an LLM
call or tool definition, and artifact findings only fire in repos that have at
least one other AI signal.
"""
from __future__ import annotations

import ast
import json
import re
import time
from pathlib import Path

from . import config, signatures as sig

SKIP_DIRS = {
    ".git", "node_modules", "venv", ".venv", "env", ".tox", "__pycache__",
    "dist", "build", ".next", ".nuxt", "target", "vendor", "site-packages",
    ".mypy_cache", ".pytest_cache", ".idea", ".vscode", "coverage", ".ruff_cache",
}
LOCK_FILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "poetry.lock",
              "uv.lock", "cargo.lock", "composer.lock"}
CODE_EXTS = {".py", ".js", ".ts", ".tsx", ".jsx", ".mjs", ".cjs", ".java", ".go",
             ".rb", ".cs", ".php", ".kt", ".rs", ".scala", ".swift", ".ipynb",
             ".yaml", ".yml", ".toml", ".cfg", ".ini", ".json", ".sh", ".ps1"}
MAX_LINES_PER_FILE = 20000
_MAX_EVIDENCE = 20
_SNIPPET_LEN = 160

_REQ_NAME_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)")
_REQ_PIN_RE = re.compile(r"(?:==|~=|>=|<=|>|<|!=|@)")
_JS_IMPORT_RE = re.compile(
    r"""(?:from\s+|require\s*\(\s*|import\s*\(\s*|import\s+)["']([^"']+)["']""")
_ENVREF_RE = re.compile(
    r"(?:os\.environ(?:\.get)?\s*[\[(]\s*[\"']([A-Z0-9_]+)[\"']"
    r"|os\.getenv\s*\(\s*[\"']([A-Z0-9_]+)[\"']"
    r"|process\.env\.([A-Z0-9_]+)"
    r"|process\.env\[[\"']([A-Z0-9_]+)[\"']\])")


class _Inventory:
    """Accumulates components/findings while the tree is walked."""

    def __init__(self, root: Path):
        self.root = root
        self.components: dict[tuple, dict] = {}
        self.findings: list[dict] = []
        self.files_scanned = 0
        self.files_with_ai = 0
        self.llm_call_seen = False
        self.flag_evidence: dict[str, dict] = {}   # mcp/rag/agents -> first evidence
        self.deferred_artifacts: list[dict] = []   # pickle findings, gated on context

    # ── components ────────────────────────────────────────────────────────────
    def add_component(self, ctype: str, name: str, provider: str, category: str,
                      source: str, file: str, line: int, snippet: str,
                      version: str | None = None, confidence: str = "high") -> None:
        key = (ctype, name.lower())
        comp = self.components.get(key)
        if comp is None:
            comp = {"type": ctype, "name": name, "provider": provider,
                    "category": category, "version": version,
                    "sources": [], "evidence": [], "confidence": confidence}
            self.components[key] = comp
        if version and not comp.get("version"):
            comp["version"] = version
        if source not in comp["sources"]:
            comp["sources"].append(source)
        # Manifest evidence beats regex evidence for confidence.
        if confidence == "high":
            comp["confidence"] = "high"
        if len(comp["evidence"]) < _MAX_EVIDENCE:
            comp["evidence"].append({"file": file, "line": line,
                                     "snippet": snippet[:_SNIPPET_LEN]})

    # ── findings ──────────────────────────────────────────────────────────────
    def add_finding(self, rule_id: str, file: str, line: int, snippet: str,
                    confidence: str = "high", detail: str = "") -> None:
        meta = sig.RULES[rule_id]
        self.findings.append({
            "id": rule_id,
            "title": meta["title"] + (f" — {detail}" if detail else ""),
            "severity": meta["severity"],
            "file": file, "line": line,
            "snippet": snippet[:_SNIPPET_LEN],
            "owasp": meta["owasp"], "cwe": meta["cwe"],
            "remediation": meta["remediation"],
            "domain": "AI-BOM", "confidence": confidence,
        })

    def note_flag(self, flag: str, file: str, line: int, snippet: str) -> None:
        self.flag_evidence.setdefault(
            flag, {"file": file, "line": line, "snippet": snippet[:_SNIPPET_LEN]})


def _rel(root: Path, path: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.as_posix()


def _read_text(path: Path) -> str | None:
    try:
        if path.stat().st_size > config.MAX_FILE_BYTES:
            return None
        # utf-8-sig strips a leading BOM so ast.parse of Python sources does not
        # choke on it (a bare utf-8 read would drop BOM-prefixed files silently).
        return path.read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return None


def _find_line(raw: str, needle: str) -> int:
    for i, line in enumerate(raw.splitlines(), 1):
        if needle in line:
            return i
    return 1


def _redact_secret(match: re.Match, line: str) -> str:
    """Snippet with the secret value truncated — the full key must never be
    persisted into a report or BOM document."""
    secret = match.group(0)
    return line.replace(secret, secret[:10] + "…REDACTED")


# ── Manifest parsing ──────────────────────────────────────────────────────────
def _scan_requirements(inv: _Inventory, path: Path, raw: str) -> None:
    rel = _rel(inv.root, path)
    for lineno, line in enumerate(raw.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", "-")):
            continue
        m = _REQ_NAME_RE.match(stripped)
        if not m:
            continue
        name = m.group(1).lower()
        hit = sig.PY_PACKAGES.get(name)
        if not hit:
            continue
        pinned = bool(_REQ_PIN_RE.search(stripped))
        vm = re.search(r"==\s*([\w.]+)", stripped)
        inv.add_component("library", name, hit[0], hit[1],
                          f"manifest:{path.name}", rel, lineno, stripped,
                          version=vm.group(1) if vm else None)
        if not pinned:
            inv.add_finding("AIBOM-SUP-002", rel, lineno, stripped,
                            detail=name)


def _scan_pyproject(inv: _Inventory, path: Path, raw: str) -> None:
    rel = _rel(inv.root, path)
    deps: list[str] = []
    try:
        import tomllib
        data = tomllib.loads(raw)
        deps += data.get("project", {}).get("dependencies", []) or []
        for extra in (data.get("project", {}).get("optional-dependencies", {}) or {}).values():
            deps += extra or []
        poetry = data.get("tool", {}).get("poetry", {}).get("dependencies", {}) or {}
        deps += [f"{k}=={v}" if isinstance(v, str) else k for k, v in poetry.items()]
        for table in ("packages", "dev-packages"):     # Pipfile
            deps += list((data.get(table) or {}).keys())
    except Exception:
        # Very old Python or malformed TOML: fall back to bare name matching.
        deps = re.findall(r"[\"']([A-Za-z0-9._-]+)[^\"']*[\"']", raw)
    for dep in deps:
        m = _REQ_NAME_RE.match(str(dep).strip())
        if not m:
            continue
        name = m.group(1).lower()
        hit = sig.PY_PACKAGES.get(name)
        if hit:
            inv.add_component("library", name, hit[0], hit[1],
                              f"manifest:{path.name}", rel,
                              _find_line(raw, name), str(dep).strip())


def _scan_package_json(inv: _Inventory, path: Path, raw: str) -> None:
    rel = _rel(inv.root, path)
    try:
        data = json.loads(raw)
    except ValueError:
        return
    deps: dict[str, str] = {}
    for section in ("dependencies", "devDependencies", "peerDependencies"):
        block = data.get(section)
        if isinstance(block, dict):
            deps.update({str(k): str(v) for k, v in block.items()})
    for name, version in deps.items():
        hit = sig.NPM_PACKAGES.get(name)
        if not hit:
            hit = next((v for prefix, v in sig.NPM_PREFIXES.items()
                        if name.startswith(prefix)), None)
        if hit:
            inv.add_component("library", name, hit[0], hit[1],
                              f"manifest:{path.name}", rel,
                              _find_line(raw, f'"{name}"'),
                              f'"{name}": "{version}"',
                              version=version.lstrip("^~=v") or None)


def _scan_go_mod(inv: _Inventory, path: Path, raw: str) -> None:
    rel = _rel(inv.root, path)
    for lineno, line in enumerate(raw.splitlines(), 1):
        stripped = line.strip()
        for module, hit in sig.GO_MODULES.items():
            if stripped.startswith(module):
                parts = stripped.split()
                inv.add_component("library", module, hit[0], hit[1],
                                  "manifest:go.mod", rel, lineno, stripped,
                                  version=parts[1].lstrip("v") if len(parts) > 1 else None)


# ── Python AST import pass ────────────────────────────────────────────────────
def _py_imports(source: str) -> list[tuple[str, int]]:
    """(dotted module, line) for every import in a Python file; [] on syntax error."""
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError):
        return []
    found = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found += [(alias.name, node.lineno) for alias in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            found.append((node.module, node.lineno))
    return found


def _match_py_import(module: str) -> tuple[str, tuple[str, str]] | None:
    """Resolve a dotted import to a catalog package, longest alias first."""
    dotted = module.lower()
    for alias, pkg in sig.PY_IMPORT_ALIASES.items():
        if dotted == alias or dotted.startswith(alias + "."):
            return pkg, sig.PY_PACKAGES[pkg]
    top = dotted.split(".")[0].replace("_", "-")
    hit = sig.PY_PACKAGES.get(top)
    return (top, hit) if hit else None


# ── Code content pass ─────────────────────────────────────────────────────────
def _scan_code_file(inv: _Inventory, path: Path, raw: str, is_dotenv: bool) -> None:
    rel = _rel(inv.root, path)
    lines = raw.splitlines()[:MAX_LINES_PER_FILE]
    had_signal = False
    llm_call_lines: list[int] = []
    tool_def: tuple[int, str] | None = None
    exec_sinks: list[tuple[int, str]] = []

    if path.suffix == ".py":
        for module, lineno in _py_imports(raw):
            hit = _match_py_import(module)
            if hit:
                name, (provider, category) = hit
                snippet = lines[lineno - 1].strip() if lineno <= len(lines) else module
                inv.add_component("library", name, provider, category,
                                  "import", rel, lineno, snippet)
                had_signal = True

    if path.suffix in {".js", ".ts", ".tsx", ".jsx", ".mjs", ".cjs"}:
        for lineno, line in enumerate(lines, 1):
            for m in _JS_IMPORT_RE.finditer(line):
                name = m.group(1)
                hit = sig.NPM_PACKAGES.get(name) or next(
                    (v for prefix, v in sig.NPM_PREFIXES.items()
                     if name.startswith(prefix)), None)
                if hit:
                    inv.add_component("library", name, hit[0], hit[1],
                                      "import", rel, lineno, line.strip())
                    had_signal = True

    for lineno, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or len(stripped) > 2000:
            continue

        # Hardcoded provider keys — always a finding, snippet redacted.
        for provider, pattern in sig.KEY_PATTERNS:
            m = pattern.search(line)
            if m:
                rule = "AIBOM-KEY-002" if is_dotenv else "AIBOM-KEY-001"
                inv.add_finding(rule, rel, lineno, _redact_secret(m, stripped),
                                detail=provider)
                had_signal = True
                break

        # Model identifiers (quoted literals only).
        for m in sig.MODEL_RE.finditer(line):
            model = m.group("model")
            lower = model.lower()
            provider = next((p for prefix, p in sig.MODEL_PROVIDER_PREFIXES
                             if lower.startswith(prefix)), "Unknown")
            inv.add_component("model", model, provider, "model",
                              "code", rel, lineno, stripped, confidence="medium")
            had_signal = True

        # Provider endpoints.
        em = sig.ENDPOINT_RE.search(line)
        if em:
            host = em.group(0).lower()
            provider = next((p for frag, p in sig.ENDPOINTS.items()
                             if frag.lower() == host), "Unknown")
            inv.add_component("endpoint", host, provider, "endpoint",
                              "code", rel, lineno, stripped, confidence="medium")
            had_signal = True

        # Credential env-var references (good practice — inventory only).
        for m in _ENVREF_RE.finditer(line):
            key = next(g for g in m.groups() if g)
            if key in sig.ENV_KEYS:
                inv.add_component("credential-ref", key, sig.ENV_KEYS[key],
                                  "credential", "code", rel, lineno, stripped)
                had_signal = True
        if is_dotenv:
            km = sig.ENV_KEY_RE.search(stripped.split("=")[0])
            if km:
                inv.add_component("credential-ref", km.group(1),
                                  sig.ENV_KEYS[km.group(1)], "credential",
                                  "dotenv", rel, lineno, stripped.split("=")[0] + "=…")
                had_signal = True

        # Behavioral signals.
        if sig.LLM_CALL_RE.search(line):
            llm_call_lines.append(lineno)
            inv.llm_call_seen = True
            had_signal = True
        if sig.TOOL_DEF_RE.search(line) and tool_def is None:
            tool_def = (lineno, stripped)
        if sig.EXEC_SINK_RE.search(line):
            exec_sinks.append((lineno, stripped))
        if sig.MCP_RE.search(line):
            inv.note_flag("mcp", rel, lineno, stripped)
            had_signal = True
        if sig.RAG_RE.search(line):
            inv.note_flag("rag", rel, lineno, stripped)
        for taint_re in sig.PROMPT_TAINT_RES:
            if taint_re.search(line):
                inv.add_finding("AIBOM-INJ-001", rel, lineno, stripped,
                                confidence="medium")
                had_signal = True
                break
        if sig.FROM_PRETRAINED_RE.search(line) and "revision=" not in line:
            inv.add_finding("AIBOM-SUP-003", rel, lineno, stripped,
                            confidence="medium")
            had_signal = True
        if sig.LATEST_MODEL_RE.search(line):
            inv.add_finding("AIBOM-MOD-001", rel, lineno, stripped,
                            confidence="medium")
            had_signal = True

    # Cross-line, same-file heuristics: only meaningful where the file itself
    # shows LLM/agent activity, which keeps ordinary subprocess use quiet.
    if exec_sinks and (tool_def or llm_call_lines):
        rule = "AIBOM-AGY-001" if tool_def else "AIBOM-OUT-001"
        for lineno, snippet in exec_sinks[:5]:
            inv.add_finding(rule, rel, lineno, snippet, confidence="medium")
    if tool_def:
        inv.note_flag("agents", rel, tool_def[0], tool_def[1])

    if had_signal:
        inv.files_with_ai += 1


# ── Artifacts ─────────────────────────────────────────────────────────────────
_MODELISH_RE = re.compile(r"(?i)(?:model|weight|checkpoint|ckpt|classif|embed|lora|finetun)")


def _scan_artifact(inv: _Inventory, path: Path) -> None:
    rel = _rel(inv.root, path)
    ext = path.suffix.lower()
    if ext in sig.ARTIFACT_EXTS:
        inv.add_component("model-artifact", path.name, "(local artifact)",
                          "model-artifact", f"file:{sig.ARTIFACT_EXTS[ext]}",
                          rel, 1, f"{sig.ARTIFACT_EXTS[ext]} artifact, "
                          f"{path.stat().st_size:,} bytes")
        if ext in (".pt", ".pth") and _MODELISH_RE.search(path.name):
            # torch.load uses pickle under the hood — same CWE-502 exposure.
            inv.deferred_artifacts.append(
                {"rule": "AIBOM-SUP-001", "file": rel,
                 "snippet": f"PyTorch checkpoint {path.name} (pickle-based format)"})
    elif ext in sig.PICKLE_EXTS and (_MODELISH_RE.search(path.name)
                                     or _MODELISH_RE.search(path.parent.name)):
        inv.add_component("model-artifact", path.name, "(local artifact)",
                          "model-artifact", "file:Pickle", rel, 1,
                          f"pickle artifact, {path.stat().st_size:,} bytes")
        inv.deferred_artifacts.append(
            {"rule": "AIBOM-SUP-001", "file": rel,
             "snippet": f"Pickle-serialized artifact {path.name}"})


# ── Top level ─────────────────────────────────────────────────────────────────
_MANIFEST_HANDLERS = {
    "pyproject.toml": _scan_pyproject,
    "package.json": _scan_package_json,
    "go.mod": _scan_go_mod,
    "pipfile": _scan_pyproject,      # TOML with a [packages] table; fallback path
}


def scan(root: Path, progress=None) -> dict:
    """Scan a working tree; returns {"components", "findings", "stats"}."""
    root = Path(root)
    inv = _Inventory(root)
    deadline = time.time() + config.SCAN_TIMEOUT

    def walk(directory: Path):
        try:
            entries = sorted(directory.iterdir(), key=lambda p: p.name.lower())
        except OSError:
            return
        for entry in entries:
            if time.time() > deadline or inv.files_scanned >= config.MAX_FILES:
                return
            if entry.is_dir():
                if entry.name.lower() not in SKIP_DIRS and not entry.is_symlink():
                    walk(entry)
                continue
            if not entry.is_file():
                continue
            name = entry.name.lower()
            ext = entry.suffix.lower()
            if ext in sig.ARTIFACT_EXTS or ext in sig.PICKLE_EXTS:
                inv.files_scanned += 1
                _scan_artifact(inv, entry)
                continue
            is_manifest = (name in _MANIFEST_HANDLERS
                           or name.startswith("requirements"))
            is_dotenv = name.startswith(".env") and not name.endswith(".example")
            if not (is_manifest or is_dotenv or ext in CODE_EXTS):
                continue
            if name in LOCK_FILES:
                continue
            raw = _read_text(entry)
            if raw is None:
                continue
            inv.files_scanned += 1
            if progress and inv.files_scanned % 500 == 0:
                progress(f"Scanned {inv.files_scanned} files…")
            if name.startswith("requirements") and ext in ("", ".txt", ".in"):
                _scan_requirements(inv, entry, raw)
            elif name in _MANIFEST_HANDLERS:
                _MANIFEST_HANDLERS[name](inv, entry, raw)
            if ext in CODE_EXTS or is_dotenv:
                _scan_code_file(inv, entry, raw, is_dotenv)

    walk(root)
    return _finalize(inv)


def _finalize(inv: _Inventory) -> dict:
    components = list(inv.components.values())
    # A lone pickle file must not establish AI context (that would make the
    # pickle-finding gate circular); every other component type counts.
    strong = [c for c in components
              if not (c["category"] == "model-artifact"
                      and c["sources"] == ["file:Pickle"])]
    ai_context = bool(strong) or inv.llm_call_seen

    # Artifact (pickle) findings only matter as AI supply chain inside an AI repo.
    if ai_context:
        for item in inv.deferred_artifacts:
            inv.add_finding(item["rule"], item["file"], 1, item["snippet"],
                            confidence="medium")

    # Capability flags -> one informational inventory finding each.
    categories = {c["category"] for c in components}
    flags = {
        "provider_apis": bool({"provider-sdk", "endpoint"} & categories),
        "local_models": bool({"local-inference", "model-artifact"} & categories),
        "rag": "rag" in inv.flag_evidence or "vector-db" in categories,
        "agents": "agents" in inv.flag_evidence or "agent-framework" in categories,
        "mcp": "mcp" in inv.flag_evidence or "mcp" in categories,
    }
    _flag_rules = {"mcp": "AIBOM-MCP-001", "rag": "AIBOM-RAG-001",
                   "agents": "AIBOM-AGN-001"}
    for flag, rule in _flag_rules.items():
        if not flags[flag]:
            continue
        ev = inv.flag_evidence.get(flag)
        if ev is None:
            comp = next((c for c in components if c["category"] in
                         {"mcp": ("mcp",), "rag": ("vector-db",),
                          "agents": ("agent-framework",)}[flag]), None)
            ev = comp["evidence"][0] if comp and comp["evidence"] else \
                {"file": "(repo)", "line": 1, "snippet": ""}
        inv.add_finding(rule, ev["file"], ev["line"], ev["snippet"],
                        confidence="high")

    sev_order = {s: i for i, s in enumerate(sig.SEVERITIES)}
    inv.findings.sort(key=lambda f: (sev_order.get(f["severity"], 99),
                                     f["file"], f["line"]))

    models = sorted({c["name"] for c in components if c["type"] == "model"})
    providers = sorted({c["provider"] for c in components
                        if c["provider"] not in ("Unknown", "(local artifact)")})
    by_category: dict[str, int] = {}
    for c in components:
        by_category[c["category"]] = by_category.get(c["category"], 0) + 1

    return {
        "components": components,
        "findings": inv.findings,
        "stats": {
            "files_scanned": inv.files_scanned,
            "files_with_ai": inv.files_with_ai,
            "components_total": len(components),
            "models": models,
            "providers": providers,
            "by_category": by_category,
            "flags": flags,
            "ai_detected": ai_context,
        },
    }
