# TM / Yaksha Guard — Threat Modeling Platform

Flask security-review platform: OWASP/MITRE/STRIDE threat analysis, SAST broker
(scans registered repos with GitHub PR gating), code-derived
threat models, cross-tool correlation, AIBOM, SBOM, PQC assessment, SARIF
export, and a 2,477-rule catalog.

## Run

```bash
# Windows (waitress)
python wsgi.py

# Linux/Mac (gunicorn) — TM_SECRET_KEY not required: a key is persisted at
# ~/.tm_secret_key so all workers share one CSRF signing key
gunicorn --bind 0.0.0.0:5001 --workers 4 --timeout 120 wsgi:application

# Docker
docker compose up --build
```

The server binds **127.0.0.1** by default. Set `TM_HOST=0.0.0.0` to expose it —
and set `TM_API_KEY` when you do: the app holds GitHub tokens (broker) and runs
scans on demand, so unauthenticated network exposure is a bad idea.

## Test

```bash
python -m pytest        # canonical — runs BOTH test trees (root + tests/)
```

Do **not** rely on `python -m unittest discover` alone: the `tests/` directory
contains pytest-style function tests that unittest cannot collect (it reports
success while silently skipping them).

Measured accuracy of the offline analysis engine:

```bash
python -m benchmark.harness   # recall / specificity / precision / F1 vs the labelled corpus
```

`test_benchmark.py` turns those metrics into CI floors, so a rule or prompt
change that drops accuracy fails the suite.

## Configuration (env vars)

| Variable | Default | Purpose |
| --- | --- | --- |
| `TM_PORT` | `5001` | Listen port. |
| `TM_HOST` | `127.0.0.1` | Bind address (`0.0.0.0` to expose; see warning above). |
| `TM_API_KEY` | unset | When set, all `/api/` routes require it (Bearer or `X-API-Key`). |
| `TM_SECRET_KEY` | auto | CSRF signing key. Unset → persisted at `~/.tm_secret_key`. |
| `TM_DISABLE_CSP` | off | `1` disables the Content-Security-Policy header (on by default). |
| `TM_FRAME_OPTIONS` | `DENY` | `X-Frame-Options` value; `off` suppresses the header. |
| `ANTHROPIC_API_KEY` | unset | Enables LLM-backed analysis (offline rules work without it). |
| `TM_GITHUB_TOKEN` | unset | Fallback token for broker clones / PR statuses (per-repo token wins). |
| `TM_GITHUB_WEBHOOK_SECRET` | unset | Fallback webhook HMAC secret (per-repo secret wins). |

Broker scan tuning (`TM_BROKER_*`) is documented in `broker/config.py`.

## Docs

- `API_V1.md` — versioned API surface (legacy unversioned routes are frozen).
- `PRD.md` — product requirements and module map.
