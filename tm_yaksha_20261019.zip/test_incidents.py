"""Tests for incidents.py (pure report-building logic) and the
api/incidents.py Flask blueprint."""
from __future__ import annotations

import unittest

import incidents


class TestBuildIncidentReport(unittest.TestCase):
    def test_minimal_entry_builds_a_report(self):
        rep = incidents.build_incident_report(
            [{"weakness": "SQL Injection", "locus": "services/search.py:42"}])
        self.assertEqual(rep["methodology"], "incident")
        self.assertEqual(len(rep["categories"]), 1)
        cat = rep["categories"][0]
        self.assertEqual(cat["_source"], "INCIDENT")
        self.assertEqual(cat["name"], "SQL Injection")
        self.assertEqual(cat["affected_components"], ["services/search.py:42"])

    def test_defaults_source_severity_and_detected_at(self):
        rep = incidents.build_incident_report(
            [{"weakness": "SQL Injection", "locus": "a.py:1"}])
        cat = rep["categories"][0]
        self.assertEqual(cat["incident_source"], "manual")
        self.assertEqual(cat["risk"], "High")
        self.assertTrue(cat["detected_at"])

    def test_rejects_empty_entries(self):
        with self.assertRaises(ValueError):
            incidents.build_incident_report([])
        with self.assertRaises(ValueError):
            incidents.build_incident_report("not a list")

    def test_rejects_missing_weakness(self):
        with self.assertRaises(ValueError) as ctx:
            incidents.build_incident_report([{"locus": "a.py:1"}])
        self.assertIn("weakness", str(ctx.exception))

    def test_rejects_missing_locus(self):
        with self.assertRaises(ValueError) as ctx:
            incidents.build_incident_report([{"weakness": "SQLi"}])
        self.assertIn("locus", str(ctx.exception))

    def test_rejects_unknown_source(self):
        with self.assertRaises(ValueError) as ctx:
            incidents.build_incident_report(
                [{"weakness": "SQLi", "locus": "a.py:1", "source": "carrier-pigeon"}])
        self.assertIn("source", str(ctx.exception))

    def test_accepts_every_known_source(self):
        for src in incidents.SOURCES:
            rep = incidents.build_incident_report(
                [{"weakness": "SQLi", "locus": "a.py:1", "source": src}])
            self.assertEqual(rep["categories"][0]["incident_source"], src)

    def test_multiple_entries_worst_severity_is_overall(self):
        rep = incidents.build_incident_report([
            {"weakness": "SQLi", "locus": "a.py:1", "severity": "Medium"},
            {"weakness": "SSRF", "locus": "b.py:1", "severity": "Critical"},
        ])
        self.assertEqual(rep["overall_risk"], "Critical")
        self.assertEqual(len(rep["categories"]), 2)

    def test_invalid_severity_falls_back_to_high(self):
        rep = incidents.build_incident_report(
            [{"weakness": "SQLi", "locus": "a.py:1", "severity": "Apocalyptic"}])
        self.assertEqual(rep["categories"][0]["risk"], "High")

    def test_second_bad_entry_still_rejects_whole_batch(self):
        # all-or-nothing: one bad entry among good ones must still raise,
        # not silently drop the bad one.
        with self.assertRaises(ValueError) as ctx:
            incidents.build_incident_report([
                {"weakness": "SQLi", "locus": "a.py:1"},
                {"weakness": "", "locus": "b.py:1"},
            ])
        self.assertIn("entry 1", str(ctx.exception))

    def test_title_defaults_from_first_weakness(self):
        rep = incidents.build_incident_report(
            [{"weakness": "SQL Injection", "locus": "a.py:1"}])
        self.assertIn("SQL Injection", rep["title"])

    def test_explicit_title_used(self):
        rep = incidents.build_incident_report(
            [{"weakness": "SQLi", "locus": "a.py:1"}], title="Black Friday Incident")
        self.assertEqual(rep["title"], "Black Friday Incident")


class TestIncidentsApi(unittest.TestCase):
    """Live against the real app/report_db — cleans up every report it
    creates via the reports API, same pattern as TestAttackPathApi."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        cls._saved = []

    @classmethod
    def tearDownClass(cls):
        for rid in cls._saved:
            cls.client.delete(f"/api/v1/reports/{rid}",
                              headers={"X-CSRF-Token": cls.csrf})

    def _post(self, body):
        return self.client.post("/api/v1/incidents", json=body,
                                headers={"X-CSRF-Token": self.csrf})

    def test_create_returns_report_id_and_can_be_fetched(self):
        r = self._post({"entries": [{"weakness": "SQL Injection",
                                     "locus": "services/search.py:42",
                                     "source": "waf", "severity": "High"}]})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        j = r.get_json()
        self.assertTrue(j["success"])
        self.assertEqual(j["incident_count"], 1)
        rid = j["report_id"]
        self._saved.append(rid)

        got = self.client.get(f"/api/v1/reports/{rid}")
        self.assertEqual(got.status_code, 200)
        saved = got.get_json()["report"]
        self.assertEqual(saved["methodology"], "incident")
        self.assertEqual(saved["categories"][0]["_source"], "INCIDENT")

    def test_create_rejects_invalid_body(self):
        r = self._post({"entries": [{"weakness": "SQLi"}]})   # missing locus
        self.assertEqual(r.status_code, 400)
        self.assertIn("locus", r.get_json()["error"])

    def test_create_rejects_missing_entries(self):
        r = self._post({})
        self.assertEqual(r.status_code, 400)

    def test_list_includes_created_incident(self):
        r = self._post({"entries": [{"weakness": "Command Injection",
                                     "locus": "app.py:9"}]})
        rid = r.get_json()["report_id"]
        self._saved.append(rid)

        listed = self.client.get("/api/v1/incidents").get_json()
        self.assertTrue(listed["success"])
        self.assertIn(rid, [i["id"] for i in listed["incidents"]])
        self.assertTrue(all(i["methodology"] == "incident" for i in listed["incidents"]))

    def test_saved_incident_correlates_to_actively_exploited(self):
        # End-to-end: an incident report saved through the real API, then run
        # through the real correlator, must reach Verdict.ACTIVELY_EXPLOITED.
        sast = {
            "id": "", "title": "SAST fixture for incident correlation",
            "methodology": "sast",
            "categories": [{"id": "PY-SQL", "name": "SQL Injection", "risk": "High",
                           "_source": "SAST", "cwe": "CWE-89",
                           "affected_components": ["services/checkout.py:7"]}],
        }
        import app as tm_app
        sast_id = tm_app._save_report(sast, "SAST fixture for incident correlation")
        self._saved.append(sast_id)

        inc_r = self._post({"entries": [{"weakness": "SQL Injection",
                                         "locus": "services/checkout.py:7",
                                         "source": "siem"}]})
        inc_id = inc_r.get_json()["report_id"]
        self._saved.append(inc_id)

        run = self.client.post("/api/v1/correlate/run",
                               json={"report_ids": [sast_id, inc_id]},
                               headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(run.status_code, 201, run.get_data(as_text=True))
        j = run.get_json()
        self.assertEqual(j["actively_exploited"], 1)
        self._saved.append(j["report_id"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
