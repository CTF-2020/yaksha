"""GitHub integration for the SAST broker.

This module is the bridge between GitHub and the broker's scan/report pipeline:

  * webhook signature verification  (verify_signature)  — HMAC-SHA256, the only
    auth on the public /webhook endpoint, so it must be constant-time.
  * webhook payload normalisation   (parse_webhook)      — turns a raw push /
    pull_request event into the small, validated dict the service needs.
  * PR response                      (GitHubClient + report_to_pr) — after a scan
    finishes we set a commit status on the scanned SHA and upsert a single
    findings comment on the PR (updated in place on re-scan, never duplicated).

It is deliberately dependency-free (urllib, not requests) to match the rest of
the broker and the host app's minimal venv. The GitHub token never appears in a
job log, a saved report, or an API response: clone URLs are sanitised before any
progress message, and the registry is redacted on the way out (see config).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import urllib.error
import urllib.request
from urllib.parse import quote, urlparse, urlunparse

from . import config

# Marker hidden in the PR comment so we can find-and-update our own comment on a
# re-scan instead of posting a new one every push.
_COMMENT_MARKER = "<!-- yaksha-guard-sast -->"
_TM_COMMENT_MARKER = "<!-- yaksha-guard-threat-model -->"
_COMMIT_CONTEXT = "yaksha-guard/sast"
_CHECK_NAME = "Yaksha Guard SAST"
_PR_ACTIONS = {"opened", "synchronize", "reopened", "ready_for_review"}
_HTTP_TIMEOUT = 30
_REF_RE = re.compile(r"^[A-Za-z0-9._][A-Za-z0-9._/-]{0,200}$")
# GitHub accepts at most 50 annotations per check-run API call; we send the rest
# in follow-up PATCHes (GitHub appends them).
_ANNOTATIONS_PER_CALL = 50


# ── Webhook authentication ────────────────────────────────────────────────────
def verify_signature(secret: str, body: bytes, signature_header: str) -> bool:
    """Validate a GitHub `X-Hub-Signature-256: sha256=<hex>` header.

    Returns False (never raises) on any malformed input so the caller can answer
    a flat 401. Uses compare_digest so a wrong secret can't be timed out.
    """
    if not secret or not signature_header:
        return False
    if not signature_header.startswith("sha256="):
        return False
    sent = signature_header.split("=", 1)[1].strip()
    mac = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(mac, sent)


def is_valid_ref(ref: str) -> bool:
    """A git ref/refspec safe to hand to `git fetch` (no leading dash, no spaces)."""
    return bool(ref) and not ref.startswith("-") and bool(_REF_RE.match(ref))


# ── Webhook parsing ───────────────────────────────────────────────────────────
def parse_webhook(event: str, payload: dict) -> dict:
    """Normalise a raw webhook into {kind, full_name, ref, branch, sha, number}.

    kind is one of: ping | push | pull_request | ignored. Only events that should
    actually trigger a scan return a ref + sha; everything else is "ignored" with
    a human-readable reason so the endpoint can 200 without doing work.
    """
    payload = payload or {}
    repo = payload.get("repository") or {}
    full_name = (repo.get("full_name") or "").strip()

    if event == "ping":
        return {"kind": "ping", "full_name": full_name,
                "reason": "pong", "ref": None, "sha": None, "number": None}

    if event == "push":
        ref = payload.get("ref") or ""              # e.g. refs/heads/main
        sha = payload.get("after") or ""
        if payload.get("deleted") or set(sha) <= {"0"}:
            return _ignored(full_name, "branch deletion / no commit")
        if not ref.startswith("refs/heads/"):
            return _ignored(full_name, f"non-branch ref {ref!r}")
        branch = ref.split("/", 2)[-1]
        return {"kind": "push", "full_name": full_name, "ref": ref,
                "branch": branch, "sha": sha, "number": None}

    if event == "pull_request":
        action = payload.get("action", "")
        if action not in _PR_ACTIONS:
            return _ignored(full_name, f"pull_request action {action!r}")
        pr = payload.get("pull_request") or {}
        head = pr.get("head") or {}
        base = pr.get("base") or {}
        number = _as_pr_number(payload.get("number") or pr.get("number"))
        sha = head.get("sha") or ""
        if not number or not sha:
            return _ignored(full_name, "pull_request missing/invalid number or head sha")
        # Scan the base repo's pull ref so a fork PR is fetched from the repo we
        # already trust — the head fork URL is never cloned. `base_branch` is the
        # PR's target branch, so delta gating can diff against the right baseline.
        return {"kind": "pull_request", "full_name": full_name,
                "ref": f"refs/pull/{number}/head", "branch": f"pr-{number}",
                "base_branch": str(base.get("ref") or ""),
                "sha": sha, "number": number, "action": action}

    return _ignored(full_name, f"unhandled event {event!r}")


def _as_pr_number(value) -> int | None:
    """Coerce a webhook PR number to a positive int, or None if it isn't one.

    This route parses the payload *before* the signature is verified, so a
    non-numeric ``number`` must degrade to "ignored" rather than raise — an
    unauthenticated caller must never be able to trip an unhandled exception.
    """
    try:
        n = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return n if n > 0 else None


def _ignored(full_name: str, reason: str) -> dict:
    return {"kind": "ignored", "full_name": full_name, "reason": reason,
            "ref": None, "sha": None, "number": None}


# ── Clone authentication ──────────────────────────────────────────────────────
def authed_clone_url(url: str, token: str) -> str:
    """Embed a token into an https GitHub URL for cloning a private repo.

    Only rewrites https URLs (ssh uses keys, local paths need nothing). The
    returned URL is used solely as a git argument — callers must log the original
    `url`, never this one.
    """
    if not token:
        return url
    parsed = urlparse(url)
    if parsed.scheme not in ("https", "http"):
        return url
    netloc = parsed.netloc.rsplit("@", 1)[-1]   # drop any existing creds
    netloc = f"x-access-token:{quote(token, safe='')}@{netloc}"
    return urlunparse(parsed._replace(netloc=netloc))


# ── GitHub REST client (minimal, urllib) ──────────────────────────────────────
class GitHubError(RuntimeError):
    pass


class GitHubClient:
    def __init__(self, token: str, api_base: str | None = None):
        self.token = token
        self.api_base = (api_base or config.GITHUB_API_BASE).rstrip("/")

    def _request(self, method: str, path: str, body: dict | None = None) -> dict:
        url = path if path.startswith("http") else f"{self.api_base}{path}"
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Accept", "application/vnd.github+json")
        req.add_header("X-GitHub-Api-Version", "2022-11-28")
        req.add_header("User-Agent", "yaksha-guard-sast-broker")
        if self.token:
            req.add_header("Authorization", f"Bearer {self.token}")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT) as resp:
                raw = resp.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            detail = (exc.read() or b"").decode("utf-8", "replace")[:300]
            raise GitHubError(f"{method} {path} -> {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise GitHubError(f"{method} {path} failed: {exc.reason}") from exc

    # The three calls the PR response needs.
    def set_commit_status(self, full_name: str, sha: str, state: str,
                          description: str, target_url: str = "") -> dict:
        body = {"state": state, "context": _COMMIT_CONTEXT,
                "description": description[:140]}
        if target_url:
            body["target_url"] = target_url
        return self._request("POST", f"/repos/{full_name}/statuses/{sha}", body)

    def _find_marker_comment(self, full_name: str, number: int,
                             marker: str = _COMMENT_MARKER) -> int | None:
        comments = self._request(
            "GET", f"/repos/{full_name}/issues/{number}/comments?per_page=100")
        if isinstance(comments, list):
            for c in comments:
                if marker in (c.get("body") or ""):
                    return c.get("id")
        return None

    def upsert_pr_comment(self, full_name: str, number: int, body_md: str,
                          marker: str = _COMMENT_MARKER) -> dict:
        # `marker` lets independent Yaksha Guard comments (SAST vs the PR threat
        # model) each upsert their own comment instead of clobbering each other.
        existing = self._find_marker_comment(full_name, number, marker)
        if existing:
            return self._request(
                "PATCH", f"/repos/{full_name}/issues/comments/{existing}",
                {"body": body_md})
        return self._request(
            "POST", f"/repos/{full_name}/issues/{number}/comments", {"body": body_md})

    # Check Runs — richer than a commit status: they carry inline file/line
    # annotations and show on the PR's Checks tab. Creating a check run requires
    # a GitHub App installation token; a classic PAT gets 403 here (the caller
    # falls back to set_commit_status in that case).
    def create_check_run(self, full_name: str, head_sha: str, *,
                         status: str = "completed", conclusion: str | None = None,
                         output: dict | None = None, details_url: str = "",
                         started_at: str | None = None,
                         completed_at: str | None = None) -> dict:
        body: dict = {"name": _CHECK_NAME, "head_sha": head_sha, "status": status}
        if conclusion:
            body["conclusion"] = conclusion
        if output:
            body["output"] = output
        if details_url:
            body["details_url"] = details_url
        if started_at:
            body["started_at"] = started_at
        if completed_at:
            body["completed_at"] = completed_at
        return self._request("POST", f"/repos/{full_name}/check-runs", body)

    def update_check_run(self, full_name: str, check_run_id: int, **fields) -> dict:
        body = {k: v for k, v in fields.items() if v is not None}
        return self._request(
            "PATCH", f"/repos/{full_name}/check-runs/{check_run_id}", body)

    # The one *code-mutating-adjacent* write this client makes: opening a PR
    # for a branch broker/remediation.py already pushed. Still metadata in
    # the API sense (this call itself doesn't touch file content — the push
    # that put commits on `head` already happened over plain git), but it's
    # the first GitHubClient method with a write consequence a human notices
    # immediately (a new open PR), so it exists only for the human-gated
    # remediation flow, never called from any automatic scan-complete path.
    def create_pull_request(self, full_name: str, title: str, head: str, base: str,
                            body_md: str = "") -> dict:
        return self._request("POST", f"/repos/{full_name}/pulls",
                             {"title": title, "head": head, "base": base, "body": body_md})

    def upload_sarif(self, full_name: str, commit_sha: str, ref: str,
                     sarif_obj: dict) -> dict:
        """Upload a SARIF run to GitHub code scanning (gzip + base64 encoded).

        GitHub tracks fixed/reopened/dismissed state across uploads natively, so
        this is the durable home for findings, complementary to the ephemeral
        check-run annotations. Needs a token with the security_events scope.
        """
        import base64
        import gzip
        raw = json.dumps(sarif_obj).encode("utf-8")
        payload = base64.b64encode(gzip.compress(raw)).decode("ascii")
        return self._request("POST", f"/repos/{full_name}/code-scanning/sarifs",
                             {"commit_sha": commit_sha, "ref": ref, "sarif": payload})


# ── Gate + comment rendering ──────────────────────────────────────────────────
def gate_passes(report: dict, fail_on: str) -> bool:
    """True when nothing in the report is at or worse than the fail_on severity."""
    threshold = config.SEVERITY_ORDER.get(fail_on, config.SEVERITY_ORDER["High"])
    counts = (report.get("scan_metadata") or {}).get("severity_counts", {})
    for sev, n in counts.items():
        if n and config.SEVERITY_ORDER.get(sev, 99) <= threshold:
            return False
    return True


def gate_passes_findings(findings, fail_on: str) -> bool:
    """True when no finding in the list is at or worse than the fail_on severity.

    Used by delta gating, where the gate acts on the *new* findings only rather
    than on the whole report.
    """
    threshold = config.SEVERITY_ORDER.get(fail_on, config.SEVERITY_ORDER["High"])
    for f in findings or []:
        if config.SEVERITY_ORDER.get(f.get("severity", "Info"), 99) <= threshold:
            return False
    return True


def _status_line(report: dict) -> str:
    counts = (report.get("scan_metadata") or {}).get("severity_counts", {})
    parts = [f"{counts[s]} {s}" for s in config.SEVERITIES if counts.get(s)]
    total = (report.get("scan_metadata") or {}).get("findings_total", 0)
    return f"{total} finding(s): " + (", ".join(parts) if parts else "none")


def build_comment(report: dict, report_url: str, passed: bool,
                  fail_on: str, scanned_sha: str = "", delta: dict | None = None) -> str:
    """Render the PR comment markdown (carries the upsert marker)."""
    meta = report.get("scan_metadata") or {}
    counts = meta.get("severity_counts", {})
    if delta is not None:
        verdict = ("✅ **Passed** — no *new* findings at or above "
                   f"`{fail_on}` versus `{_md(delta.get('base', 'base'))}`." if passed else
                   f"❌ **Failed** — *new* findings at or above `{fail_on}` in this PR.")
        delta_line = (f"\n🆕 **{delta.get('new', 0)} new** · "
                      f"{delta.get('known', 0)} pre-existing (not gated).")
    else:
        verdict = ("✅ **Passed** — no findings at or above "
                   f"`{fail_on}`." if passed else
                   f"❌ **Failed** — findings at or above `{fail_on}` present.")
        delta_line = ""
    rows = "\n".join(
        f"| {s} | {counts.get(s, 0)} |"
        for s in config.SEVERITIES if counts.get(s)) or "| _none_ | 0 |"

    top = sorted(
        report.get("categories", []),
        key=lambda c: config.SEVERITY_ORDER.get(c.get("risk", "Info"), 99))[:8]
    findings_md = "\n".join(
        f"- **{_md(c.get('risk', '?'))}** · {_md(c.get('title', c.get('id', '?')))}"
        f" ({len(c.get('threats', []))} location(s))"
        for c in top) or "_No findings at the selected threshold._"
    more = ""
    if len(report.get("categories", [])) > len(top):
        more = f"\n\n…and {len(report['categories']) - len(top)} more rule(s)."

    link = f"\n\n[View the full report →]({report_url})" if report_url else ""
    sha_line = f"\nScanned commit: `{scanned_sha[:10]}`" if scanned_sha else ""
    return (
        f"{_COMMENT_MARKER}\n"
        f"## 🛡️ Yaksha Guard — SAST\n\n"
        f"{verdict}{delta_line}\n"
        f"{_md(_status_line(report))}{sha_line}\n\n"
        f"| Severity | Count |\n|---|---|\n{rows}\n\n"
        f"**Top findings**\n{findings_md}{more}{link}\n\n"
        f"<sub>Static analysis by Yaksha Guard SAST broker · threshold `{_md(fail_on)}`.</sub>"
    )


def _md(text) -> str:
    """Neutralise markdown/HTML control chars in untrusted strings."""
    return re.sub(r"[`<>|*_\[\]\r\n]", " ", str(text))


# ── Check-run annotations (inline file/line findings on the PR diff) ───────────
def _annotation_path(file: str, scan_root=None) -> str:
    """Repo-root-relative, forward-slash path for a GitHub annotation.

    The engine already emits `os.path.relpath(file, scan_root)`, but it uses the
    host OS separator and may carry a leading `./`; GitHub wants a clean POSIX
    path relative to the repo root. If an absolute path inside scan_root ever
    leaks through, strip the prefix defensively.
    """
    path = str(file or "").replace("\\", "/")
    if scan_root:
        root = str(scan_root).replace("\\", "/").rstrip("/")
        if root and path.startswith(root + "/"):
            path = path[len(root) + 1:]
    while path.startswith("./"):
        path = path[2:]
    return path.lstrip("/")


def build_annotations(findings, scan_root=None, limit: int | None = None) -> list[dict]:
    """Turn raw engine findings into GitHub check-run annotation dicts.

    Each annotation pins a finding to `path:start_line` with a severity-mapped
    level so it renders inline on the PR diff. Untrusted text is length-capped to
    GitHub's limits; the list is capped at `limit` (default GITHUB_MAX_ANNOTATIONS)
    so a noisy scan can't fan out into endless API calls.
    """
    cap = config.GITHUB_MAX_ANNOTATIONS if limit is None else limit
    out: list[dict] = []
    for f in findings or []:
        path = _annotation_path(f.get("file", ""), scan_root)
        if not path:
            continue
        try:
            line = int(f.get("line") or 1)
        except (TypeError, ValueError):
            line = 1
        line = max(1, line)                       # GitHub requires start_line >= 1
        sev = f.get("severity", "Info")
        title = f"{sev}: {f.get('title') or f.get('id') or 'Static analysis finding'}"
        meta = " · ".join(str(b) for b in (f.get("id"), f.get("owasp"), f.get("cwe")) if b)
        parts = []
        if f.get("snippet"):
            parts.append(str(f["snippet"]).strip())
        if meta:
            parts.append(meta)
        if f.get("remediation"):
            parts.append("Fix: " + str(f["remediation"]))
        out.append({
            "path": path,
            "start_line": line,
            "end_line": line,
            "annotation_level": config.ANNOTATION_LEVEL.get(sev, "notice"),
            "title": title[:255],                 # GitHub caps title at 255 chars
            "message": ("\n".join(parts) or "Static analysis finding.")[:640],
        })
        if len(out) >= cap:
            break
    return out


def _check_conclusion(report: dict | None, error: str | None, passed: bool) -> str:
    """GitHub check-run conclusion: failure on scan error or gate breach."""
    if error or report is None:
        return "failure"
    return "success" if passed else "failure"


def _check_summary(report: dict | None, error: str | None, passed: bool,
                   fail_on: str, scanned_sha: str, report_url: str,
                   shown: int, total: int) -> dict:
    """Build the check-run `output` block (title + markdown summary)."""
    if error or report is None:
        return {"title": "Scan failed",
                "summary": f"The SAST scan could not complete: {_md(error or 'unknown error')}"}
    verdict = ("✅ Passed" if passed else f"❌ Failed") + f" — gate `{_md(fail_on)}`"
    link = f"\n\n[View the full report →]({report_url})" if report_url else ""
    capped = (f"\n\n_Showing {shown} of {total} location(s); "
              f"see the full report for the rest._" if total > shown else "")
    sha_line = f"\nScanned commit `{scanned_sha[:10]}`." if scanned_sha else ""
    return {
        "title": f"{verdict}",
        "summary": f"{_md(_status_line(report))}{sha_line}{link}{capped}",
    }


# ── Orchestration: post a finished scan back to the PR/commit ──────────────────
def report_to_pr(repo: dict, gh_ctx: dict, report: dict | None,
                 report_id: str | None, error: str | None,
                 findings=None, scan_root=None,
                 gate_findings=None, delta=None,
                 log=lambda m: None) -> None:
    """Post a finished scan back to GitHub: a commit-level signal, the PR comment,
    and (optionally) a SARIF upload to code scanning.

    The commit-level signal is a rich Check Run with inline file/line annotations
    when the token can write checks (a GitHub App installation token); otherwise
    it transparently falls back to a commit Status (a classic PAT). The mode is
    controlled by TM_GITHUB_USE_CHECKS (auto | force | off).

    ``gate_findings`` is what the pass/fail gate and inline annotations act on —
    the *new* findings when PR delta gating is on, else all findings. ``delta``
    carries {new, known, base} for the comment. Best-effort throughout: any
    GitHub/API failure is logged and swallowed so a reporting hiccup never marks
    the scan job itself as failed.
    """
    token = repo.get("github_token") or config.GITHUB_TOKEN
    if not token:
        log("GitHub reporting skipped: no token configured")
        return

    full_name = gh_ctx.get("full_name") or config.github_full_name_from_url(repo.get("url", ""))
    sha = gh_ctx.get("sha")
    if not full_name or not sha:
        log("GitHub reporting skipped: missing repo/sha context")
        return

    if gate_findings is None:
        gate_findings = findings
    client = GitHubClient(token)
    public = (gh_ctx.get("public_url") or config.PUBLIC_URL or "").rstrip("/")
    report_url = f"{public}/#report={report_id}" if (public and report_id) else ""
    fail_on = repo.get("fail_on") or config.GITHUB_FAIL_ON
    # Gate on the new findings when a delta was computed, else on the whole set.
    passed = bool(report is not None and not error
                  and gate_passes_findings(gate_findings, fail_on))

    # ── Commit-level signal: Check Run (preferred) or commit Status (fallback) ──
    mode = config.checks_mode()
    signalled = False
    if mode != "off":
        try:
            _post_check_run(client, full_name, sha, report, error, passed,
                            fail_on, report_url, gate_findings, scan_root, log)
            signalled = True
        except GitHubError as exc:
            if mode == "force":
                log(f"GitHub check run failed (forced, no fallback): {exc}")
                signalled = True            # honour "force": do not post a status
            else:
                log(f"Check run unavailable, using commit status: {_short(exc)}")
    if not signalled:
        try:
            _post_commit_status(client, full_name, sha, report, error, passed,
                                report_url, log)
        except GitHubError as exc:
            log(f"GitHub commit status error: {exc}")

    # ── SARIF upload to code scanning (optional; native fixed/reopened tracking)─
    if config.GITHUB_UPLOAD_SARIF and report is not None and not error:
        try:
            import sarif as sarif_mod
            client.upload_sarif(full_name, sha, gh_ctx.get("ref") or f"refs/heads/{sha}",
                                sarif_mod.to_sarif(report))
            log("SARIF uploaded to code scanning")
        except (GitHubError, Exception) as exc:  # never fail the job on SARIF
            log(f"SARIF upload skipped: {_short(exc)}")

    # ── PR comment: a human-readable conversation summary (independent path) ────
    if report is not None and not error and gh_ctx.get("number"):
        try:
            client.upsert_pr_comment(
                full_name, int(gh_ctx["number"]),
                build_comment(report, report_url, passed, fail_on, sha, delta=delta))
            log(f"GitHub PR #{gh_ctx['number']} comment updated")
        except GitHubError as exc:
            log(f"GitHub PR comment error: {_short(exc)}")


def build_tm_comment(report: dict, report_url: str, changed_files: int = 0) -> str:
    """Render the PR *threat-model* comment markdown (own upsert marker).

    This is the design-level companion to the SAST comment: it summarises the
    threats the code-model derived from just the files the PR changed, so a
    reviewer sees new design risk inline without opening the tool.
    """
    cats = report.get("categories", [])
    counts: dict = {}
    for c in cats:
        r = c.get("risk", "Info")
        counts[r] = counts.get(r, 0) + 1
    rows = "\n".join(
        f"| {s} | {counts.get(s, 0)} |"
        for s in config.SEVERITIES if counts.get(s)) or "| _none_ | 0 |"
    top = sorted(cats, key=lambda c: config.SEVERITY_ORDER.get(c.get("risk", "Info"), 99))[:8]
    threats_md = "\n".join(
        f"- **{_md(c.get('risk', '?'))}** · {_md(c.get('title', c.get('name', '?')))}"
        f" ({len(c.get('threats', []))} location(s))"
        for c in top) or "_No design-level threats found in the changed files._"
    more = ""
    if len(cats) > len(top):
        more = f"\n\n…and {len(cats) - len(top)} more."
    scope = (f"Modeled **{changed_files}** changed file(s)."
             if changed_files else "Modeled the changed files.")
    link = f"\n\n[View the full threat model →]({report_url})" if report_url else ""
    headline = ("No design-level threats surfaced in this PR's changes."
                if not cats else
                f"**{len(cats)}** design-level threat(s) in this PR's changed files.")
    return (
        f"{_TM_COMMENT_MARKER}\n"
        f"## 🧵 Yaksha Guard — PR Threat Model\n\n"
        f"{headline}\n{scope}\n\n"
        f"| Severity | Count |\n|---|---|\n{rows}\n\n"
        f"**Threats**\n{threats_md}{more}{link}\n\n"
        f"<sub>Design-level model of the changed files only — complements the SAST comment.</sub>"
    )


def report_tm_to_pr(repo: dict, gh_ctx: dict, report: dict, report_id: str | None,
                    changed_files: int = 0, log=lambda m: None) -> None:
    """Post the PR-scoped threat model back to the pull request as its own comment.

    Independent and best-effort: mirrors report_to_pr's auth/skip rules, uses a
    distinct marker so it never clobbers the SAST comment, and swallows any API
    error so a reporting hiccup can't fail the scan job.
    """
    if gh_ctx.get("kind") != "pull_request" or not gh_ctx.get("number"):
        return
    token = repo.get("github_token") or config.GITHUB_TOKEN
    if not token:
        log("PR threat-model comment skipped: no token configured")
        return
    full_name = gh_ctx.get("full_name") or config.github_full_name_from_url(repo.get("url", ""))
    if not full_name:
        log("PR threat-model comment skipped: missing repo context")
        return
    public = (gh_ctx.get("public_url") or config.PUBLIC_URL or "").rstrip("/")
    report_url = f"{public}/#report={report_id}" if (public and report_id) else ""
    try:
        GitHubClient(token).upsert_pr_comment(
            full_name, int(gh_ctx["number"]),
            build_tm_comment(report, report_url, changed_files),
            marker=_TM_COMMENT_MARKER)
        log(f"GitHub PR #{gh_ctx['number']} threat-model comment updated")
    except GitHubError as exc:
        log(f"GitHub PR threat-model comment error: {_short(exc)}")


def _post_check_run(client: "GitHubClient", full_name: str, sha: str,
                    report: dict | None, error: str | None, passed: bool,
                    fail_on: str, report_url: str, findings, scan_root,
                    log) -> None:
    """Create a completed check run with inline annotations (batched ≤50/call).

    Raises GitHubError if the API rejects the call (e.g. a PAT without
    checks:write), letting the caller fall back to a commit status.
    """
    annotations = build_annotations(findings, scan_root) if not error else []
    total = len(annotations)
    first, rest = annotations[:_ANNOTATIONS_PER_CALL], annotations[_ANNOTATIONS_PER_CALL:]
    output = _check_summary(report, error, passed, fail_on, sha, report_url,
                            shown=total, total=total)
    output["annotations"] = first
    created = client.create_check_run(
        full_name, sha, status="completed",
        conclusion=_check_conclusion(report, error, passed),
        output=output, details_url=report_url,
        completed_at=config.now_iso())
    log(f"GitHub check run created: {_check_conclusion(report, error, passed)}"
        + (f" ({total} annotation(s))" if total else ""))

    check_id = created.get("id")
    for i in range(0, len(rest), _ANNOTATIONS_PER_CALL):
        if not check_id:
            break
        batch = rest[i:i + _ANNOTATIONS_PER_CALL]
        client.update_check_run(
            full_name, int(check_id),
            output={**{k: output[k] for k in ("title", "summary")},
                    "annotations": batch})


def _post_commit_status(client: "GitHubClient", full_name: str, sha: str,
                        report: dict | None, error: str | None, passed: bool,
                        report_url: str, log) -> None:
    if error or report is None:
        client.set_commit_status(full_name, sha, "error",
                                 f"Scan failed: {error or 'unknown error'}", report_url)
        log("GitHub commit status set: error")
        return
    client.set_commit_status(full_name, sha, "success" if passed else "failure",
                             _status_line(report), report_url)
    log(f"GitHub commit status set: {'success' if passed else 'failure'}")


def _short(exc) -> str:
    return str(exc).splitlines()[0][:160] if str(exc) else exc.__class__.__name__
