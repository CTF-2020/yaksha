"""Tests for codemodel.polyglot_extractor — JS/TS/Go/Java design-fact extraction.

Each language gets a realistic sample exercising routes, sinks, taint, controls,
stores and secrets, plus masking edge cases (strings/comments must never emit
facts) and the end-to-end build_model join (cross-file handler resolution)."""
import os
import tempfile
import unittest

from codemodel import extractor
from codemodel.polyglot_extractor import Masked, analyze_source

EXPRESS_SRC = """\
const express = require('express');
const { exec } = require('child_process');
const { Pool } = require('pg');
const helmet = require('helmet');
const app = express();
app.use(helmet());
app.use(requireAuth);

// app.get('/comment-route', fake) — must not register
const banner = "app.post('/string-route', fake)";
const evil = "eval(payload)";

app.get('/users/:id', (req, res) => {
  pool.query(`SELECT * FROM users WHERE id = ${req.params.id}`);
  res.send('ok');
});

app.post('/admin/run', requireAdmin, runJob);

function runJob(req, res) {
  exec('ls ' + req.body.cmd);
}

const apiKey = "sk-live-abcdef123456";
const dbPassword = process.env.DB_PASSWORD;
"""

GO_SRC = """\
package main

import (
    "database/sql"
    "fmt"
    "net/http"
    "os/exec"

    "github.com/gin-gonic/gin"
    _ "github.com/lib/pq"
)

func main() {
    r := gin.Default()
    r.Use(AuthMiddleware())
    r.GET("/items/:id", getItem)
    r.POST("/run", func(c *gin.Context) {
        exec.Command("sh", "-c", c.PostForm("cmd"))
    })
    http.HandleFunc("/health", health)
}

func getItem(c *gin.Context) {
    id := c.Query("id")
    db.Query("SELECT * FROM items WHERE id = " + id)
}

func health(w http.ResponseWriter, r *http.Request) {
    // exec.Command("in-a-comment")
    fmt.Fprintln(w, `raw string with exec.Command("x")`)
}
"""

JAVA_SRC = """\
package com.example.demo;

import java.sql.Statement;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private String dbPassword = "hunter2secret";

    @GetMapping("/{id}")
    public String getOrder(@PathVariable String id) throws Exception {
        Statement st = conn.createStatement();
        return st.executeQuery("SELECT * FROM orders WHERE id = " + id).toString();
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/run")
    public String run(@RequestParam String cmd) throws Exception {
        Runtime.getRuntime().exec(cmd);
        return "ok";
    }

    public String helper(String x) {
        return x.trim();
    }
}
"""

NEST_SRC = """\
import { Controller, Get, Post, UseGuards } from '@nestjs/common';

@Controller('cats')
export class CatsController {
  @UseGuards(AuthGuard)
  @Get(':id')
  findOne(id: string): string {
    return this.catsService.findOne(id);
  }

  @Post()
  create(body: any): string {
    return 'created';
  }
}
"""


def _eps(facts_or_model):
    return {(e.method, e.path): e for e in facts_or_model.entry_points}


class TestMasking(unittest.TestCase):
    def test_strings_and_comments_are_blanked_but_recorded(self):
        m = Masked('x = "hello"; // eval(a)\n/* exec(b) */ y = 1;', "javascript")
        self.assertNotIn("hello", m.text)
        self.assertNotIn("eval", m.text)
        self.assertNotIn("exec", m.text)
        self.assertIn("hello", [v for _s, _e, v in m.strings])

    def test_js_template_interpolation_stays_code(self):
        m = Masked("q = `SELECT ${req.params.id} FROM t`;", "javascript")
        self.assertNotIn("SELECT", m.text)
        self.assertIn("req.params.id", m.text)   # taint token must stay visible

    def test_go_raw_string_masked(self):
        m = Masked('s := `exec.Command("x")`', "go")
        self.assertNotIn("exec.Command", m.text)

    def test_line_numbers_survive_masking(self):
        src = 'a = "x"\nb = 2\nc = 3\n'
        m = Masked(src, "javascript")
        self.assertEqual(m.text.count("\n"), src.count("\n"))
        self.assertEqual(m.line_of(src.index("c = 3")), 3)


class TestExpress(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.facts = analyze_source(EXPRESS_SRC, "server.js", "javascript")

    def test_framework_and_store(self):
        self.assertIn("express", self.facts.frameworks)
        self.assertEqual([(d.kind, d.engine) for d in self.facts.data_stores],
                         [("sql", "postgres")])

    def test_routes_found_and_strings_comments_ignored(self):
        routes = {(f.route_method, f.route_path)
                  for f in self.facts.functions.values() if f.is_route}
        self.assertEqual(routes, {("GET", "/users/:id"), ("POST", "/admin/run")})

    def test_inline_handler_owns_tainted_sql_sink(self):
        inline = [f for f in self.facts.functions.values()
                  if f.is_route and f.route_path == "/users/:id"][0]
        self.assertEqual([s.family for s in inline.sinks], ["sql-injection"])
        self.assertTrue(inline.sinks[0].tainted)

    def test_named_handler_owns_tainted_command_sink(self):
        run_job = self.facts.functions["runJob"]
        self.assertTrue(run_job.is_route)
        fams = [s.family for s in run_job.sinks]
        self.assertIn("command-injection", fams)
        self.assertTrue(all(s.tainted for s in run_job.sinks
                            if s.family == "command-injection"))

    def test_route_middleware_auth_control(self):
        run_job = self.facts.functions["runJob"]
        self.assertTrue(any(c.kind == "auth" for c in run_job.controls))

    def test_global_controls_from_use(self):
        kinds = {c.kind for c in self.facts.global_controls}
        self.assertIn("headers", kinds)   # helmet
        self.assertIn("auth", kinds)      # requireAuth middleware

    def test_secrets_hardcoded_vs_managed(self):
        by_name = {s.name: s for s in self.facts.secrets}
        self.assertFalse(by_name["apiKey"].managed)
        self.assertTrue(by_name["dbPassword"].managed)


ROUTE_WITH_LEADING_OBJECT_ARG_SRC = """\
const app = require('express')();
const fs = require('fs');

app.get('/upload', { schema: { body: {} } }, (req, res) => {
  fs.writeFile(req.query.path, req.body.data, () => {});
});
"""


class TestExpressRouteWithLeadingObjectArg(unittest.TestCase):
    """A route handler preceded by a non-function argument (a schema/options object,
    common with fastify-style validators and body-parser/CORS config) must not have
    its body span truncated to that object's own braces."""

    @classmethod
    def setUpClass(cls):
        cls.facts = analyze_source(ROUTE_WITH_LEADING_OBJECT_ARG_SRC, "server.js", "javascript")

    def test_handler_owns_the_tainted_path_sink(self):
        route = [f for f in self.facts.functions.values() if f.is_route][0]
        fams = [s.family for s in route.sinks]
        self.assertIn("path-traversal", fams)
        self.assertTrue(any(s.tainted for s in route.sinks if s.family == "path-traversal"))


MCP_TOOL_SRC = """\
const { McpServer } = require('@modelcontextprotocol/sdk/server/mcp.js');
const { exec } = require('child_process');

const server = new McpServer({ name: 'demo', version: '1.0.0' });

server.tool("run_cmd", "Runs a shell command", { cmd: z.string() },
  async ({ cmd }) => {
    exec('sh ' + cmd);
    return { content: [] };
  });
"""


class TestMcpAgentTool(unittest.TestCase):
    """MCP TypeScript SDK `server.tool(name, desc, schema, handler)` registration
    must be recognised as an LLM-invokable tool, same shape as the leading-object
    -arg route case above (schema object before the handler arrow)."""

    @classmethod
    def setUpClass(cls):
        cls.facts = analyze_source(MCP_TOOL_SRC, "server.js", "javascript")

    def test_mcp_framework_detected(self):
        self.assertIn("mcp", self.facts.frameworks)

    def test_tool_function_flagged(self):
        tools = [f for f in self.facts.functions.values() if f.is_agent_tool]
        self.assertEqual(len(tools), 1)
        self.assertEqual(tools[0].tool_name, "run_cmd")

    def test_tool_handler_owns_the_command_sink(self):
        tool = next(f for f in self.facts.functions.values() if f.is_agent_tool)
        self.assertEqual([s.family for s in tool.sinks], ["command-injection"])

    def test_build_model_emits_agent_tool_entry_point(self):
        d = tempfile.mkdtemp(prefix="cm_mcp_")
        with open(os.path.join(d, "server.js"), "w", encoding="utf-8") as fh:
            fh.write(MCP_TOOL_SRC)
        m = extractor.build_model(d)
        tool_eps = [e for e in m.entry_points if e.kind == "agent-tool"]
        self.assertEqual(len(tool_eps), 1)
        self.assertEqual(tool_eps[0].path, "run_cmd")
        self.assertTrue(tool_eps[0].reachable_sinks)


class TestGo(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.facts = analyze_source(GO_SRC, "main.go", "go")

    def test_frameworks_and_stores(self):
        self.assertIn("gin", self.facts.frameworks)
        engines = {d.engine for d in self.facts.data_stores}
        self.assertIn("postgres", engines)

    def test_three_routes(self):
        routes = {(f.route_method, f.route_path)
                  for f in self.facts.functions.values() if f.is_route}
        self.assertEqual(routes, {("GET", "/items/:id"), ("POST", "/run"),
                                  ("*", "/health")})

    def test_named_handler_sql_sink(self):
        get_item = self.facts.functions["getItem"]
        self.assertEqual([s.family for s in get_item.sinks], ["sql-injection"])

    def test_inline_closure_tainted_command_sink(self):
        inline = [f for f in self.facts.functions.values()
                  if f.is_route and f.route_path == "/run"][0]
        self.assertEqual([s.family for s in inline.sinks], ["command-injection"])
        self.assertTrue(inline.sinks[0].tainted)   # c.PostForm

    def test_comment_and_raw_string_sinks_ignored(self):
        health = self.facts.functions["health"]
        self.assertEqual(health.sinks, [])

    def test_router_use_auth_middleware_is_global(self):
        self.assertTrue(any(c.kind == "auth" for c in self.facts.global_controls))


class TestJavaSpring(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.facts = analyze_source(JAVA_SRC, "OrderController.java", "java")

    def test_class_prefix_joined_to_method_paths(self):
        routes = {(f.route_method, f.route_path)
                  for f in self.facts.functions.values() if f.is_route}
        self.assertEqual(routes, {("GET", "/api/orders/{id}"),
                                  ("POST", "/api/orders/run")})

    def test_helper_method_is_not_a_route(self):
        self.assertFalse(self.facts.functions["helper"].is_route)

    def test_tainted_sql_via_bound_param(self):
        get_order = self.facts.functions["getOrder"]
        sql = [s for s in get_order.sinks if s.family == "sql-injection"]
        self.assertTrue(sql and sql[0].tainted)

    def test_preauthorize_marks_auth(self):
        run = self.facts.functions["run"]
        self.assertTrue(any(c.kind == "auth" for c in run.controls))
        self.assertTrue(any(s.family == "command-injection" and s.tainted
                            for s in run.sinks))

    def test_hardcoded_secret_field(self):
        self.assertTrue(any(not s.managed for s in self.facts.secrets))

    def test_store_from_import(self):
        self.assertTrue(any(d.kind == "sql" for d in self.facts.data_stores))


class TestNest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.facts = analyze_source(NEST_SRC, "cats.controller.ts", "typescript")

    def test_controller_prefix_and_methods(self):
        routes = {(f.route_method, f.route_path)
                  for f in self.facts.functions.values() if f.is_route}
        self.assertEqual(routes, {("GET", "/cats/:id"), ("POST", "/cats")})

    def test_useguards_is_auth(self):
        find_one = self.facts.functions["findOne"]
        self.assertTrue(any(c.kind == "auth" for c in find_one.controls))

    def test_unguarded_sibling_not_auth(self):
        create = self.facts.functions["create"]
        self.assertFalse(any(c.kind == "auth" for c in create.controls))


class TestBuildModelJoin(unittest.TestCase):
    """End-to-end: build_model over a polyglot repo joins facts per language."""

    def _repo(self, files: dict) -> str:
        root = tempfile.mkdtemp(prefix="polyrepo_")
        for rel, src in files.items():
            path = os.path.join(root, rel)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(src)
        return root

    def test_cross_file_handler_resolved_through_stub(self):
        root = self._repo({
            "routes.js": "const express = require('express');\n"
                         "const app = express();\n"
                         "app.post('/jobs', createJob);\n",
            "handlers.js": "const { execSync } = require('child_process');\n"
                           "function createJob(req, res) {\n"
                           "  execSync('run ' + req.body.name);\n"
                           "}\n",
        })
        model = extractor.build_model(root)
        eps = _eps(model)
        self.assertIn(("POST", "/jobs"), eps)
        fams = {s.family for s in eps[("POST", "/jobs")].reachable_sinks}
        self.assertIn("command-injection", fams)

    def test_languages_and_entry_points_recorded(self):
        root = self._repo({
            "main.go": GO_SRC,
            "src/OrderController.java": JAVA_SRC,
            "server.js": EXPRESS_SRC,
        })
        model = extractor.build_model(root)
        self.assertEqual(model.languages, {"go", "java", "javascript"})
        self.assertEqual(len(model.entry_points), 7)
        # trust boundaries derive from polyglot facts too
        self.assertTrue(any(b.kind == "privilege" for b in model.trust_boundaries))

    def test_language_scoped_global_auth(self):
        # Go auth middleware must not authenticate the Express route
        root = self._repo({
            "main.go": 'package main\nimport "github.com/gin-gonic/gin"\n'
                       "func main() {\n"
                       "    r := gin.Default()\n"
                       "    r.Use(AuthMiddleware())\n"
                       '    r.GET("/go", handler)\n'
                       "}\n",
            "app.js": "const express = require('express');\n"
                      "const app = express();\n"
                      "app.get('/js', (req, res) => { res.send('x'); });\n",
        })
        model = extractor.build_model(root)
        eps = _eps(model)
        self.assertTrue(eps[("GET", "/go")].authenticated)
        self.assertFalse(eps[("GET", "/js")].authenticated)

    def test_generated_and_test_files_skipped(self):
        root = self._repo({
            "bundle.min.js": "app.get('/min', h);",
            "types.d.ts": "app.get('/dts', h);",
            "main_test.go": 'package main\nimport "github.com/gin-gonic/gin"\n'
                            'func TestX() { r.GET("/t", h) }\n',
        })
        model = extractor.build_model(root)
        self.assertEqual(model.entry_points, [])

    def test_pure_python_repo_unchanged(self):
        root = self._repo({
            "app.py": "from flask import Flask\napp = Flask(__name__)\n"
                      "@app.route('/py')\ndef py():\n    return 'x'\n",
        })
        model = extractor.build_model(root)
        self.assertEqual(list(_eps(model)), [("GET", "/py")])


if __name__ == "__main__":
    unittest.main()
