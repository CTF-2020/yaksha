"""End-to-end tests for tm_guard.py against a real temporary git repository.

Drives the actual CLI functions (not the git subprocess itself, to keep the
suite fast) against a repo built with real git commits, so --staged and
--against exercise the real `git diff` output tm_guard.py parses.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

import tm_guard

SAFE_APP = '''
from flask import Flask
app = Flask(__name__)

@app.route("/ping")
def ping():
    return "pong"
'''

VULN_ADDITION = '''
import os
from flask import request

@app.route("/hook", methods=["POST"])
def hook():
    os.system("sh " + request.form["c"])
    return "ok"
'''


def _git(repo: str, *args: str) -> None:
    subprocess.run(["git", "-C", repo, "-c", "user.email=t@t", "-c", "user.name=t",
                    *args], check=True, capture_output=True, text=True)


def _ns(**kwargs) -> argparse.Namespace:
    base = {"staged": False, "against": None, "repo": ".", "fail_on": "High",
            "format": "text", "out": None}
    base.update(kwargs)
    return argparse.Namespace(**base)


class TestTmGuardCli(unittest.TestCase):
    def setUp(self):
        self.repo = tempfile.mkdtemp(prefix="tm_guard_test_")
        subprocess.run(["git", "init", "-q", "-b", "main", self.repo], check=True)
        (Path(self.repo) / "app.py").write_text(SAFE_APP, encoding="utf-8")
        _git(self.repo, "add", "-A")
        _git(self.repo, "commit", "-q", "-m", "init")

    def tearDown(self):
        shutil.rmtree(self.repo, ignore_errors=True)

    def test_staged_pass_on_benign_change(self):
        (Path(self.repo) / "app.py").write_text(SAFE_APP + "\n# a comment\n",
                                                  encoding="utf-8")
        _git(self.repo, "add", "-A")
        report, code = tm_guard._run(_ns(staged=True, repo=self.repo))
        self.assertEqual(code, 0)
        self.assertEqual(report["gate_result"], "PASS")

    def test_staged_fails_on_new_command_injection(self):
        (Path(self.repo) / "app.py").write_text(SAFE_APP + VULN_ADDITION, encoding="utf-8")
        _git(self.repo, "add", "-A")
        report, code = tm_guard._run(_ns(staged=True, repo=self.repo))
        self.assertEqual(code, 1)
        self.assertEqual(report["gate_result"], "FAIL")
        self.assertTrue(any(f["family"] == "command-injection" for f in report["findings"]))
        self.assertTrue(any(f["blocking"] for f in report["findings"]))

    def test_fail_on_critical_only_lets_a_high_pass(self):
        # SQLi from unauth GET params is "High" per guard.scan's severity table,
        # not "Critical" — raising the bar should let it through.
        sqli_route = '''
import sqlite3
from flask import request

@app.route("/search")
def search():
    q = request.args.get("q")
    sqlite3.connect("a.db").execute("SELECT * FROM u WHERE n='%s'" % q)
    return "ok"
'''
        (Path(self.repo) / "app.py").write_text(SAFE_APP + sqli_route, encoding="utf-8")
        _git(self.repo, "add", "-A")
        report, code = tm_guard._run(_ns(staged=True, repo=self.repo, fail_on="Critical"))
        self.assertEqual(code, 0)
        self.assertEqual(report["gate_result"], "PASS")
        self.assertTrue(any(f["family"] == "sql-injection" for f in report["findings"]))

    def test_preexisting_vuln_in_untouched_file_does_not_block(self):
        # Commit a second, already-vulnerable file to main.
        (Path(self.repo) / "legacy.py").write_text(
            'import os\nos.system("legacy debt " + input())\n', encoding="utf-8")
        _git(self.repo, "add", "-A")
        _git(self.repo, "commit", "-q", "-m", "legacy debt, pre-existing")

        # Now stage an unrelated, benign change to app.py only.
        (Path(self.repo) / "app.py").write_text(SAFE_APP + "\n# unrelated tweak\n",
                                                  encoding="utf-8")
        _git(self.repo, "add", "-A")
        report, code = tm_guard._run(_ns(staged=True, repo=self.repo))
        self.assertEqual(code, 0)
        self.assertEqual(report["gate_result"], "PASS")

    def test_against_ref_gates_a_branch_vs_its_base(self):
        _git(self.repo, "checkout", "-q", "-b", "feature")
        (Path(self.repo) / "app.py").write_text(SAFE_APP + VULN_ADDITION, encoding="utf-8")
        _git(self.repo, "add", "-A")
        _git(self.repo, "commit", "-q", "-m", "add hook route")

        report, code = tm_guard._run(_ns(against="main", repo=self.repo))
        self.assertEqual(code, 1)
        self.assertEqual(report["gate_result"], "FAIL")

    def test_against_ref_ignores_debt_already_on_the_base_branch(self):
        # Vulnerable code already on main before the branch existed must not
        # block a feature branch that never touches it.
        (Path(self.repo) / "legacy.py").write_text(
            'import os\nos.system("legacy debt " + input())\n', encoding="utf-8")
        _git(self.repo, "add", "-A")
        _git(self.repo, "commit", "-q", "-m", "legacy debt on main")

        _git(self.repo, "checkout", "-q", "-b", "feature2")
        (Path(self.repo) / "app.py").write_text(SAFE_APP + "\n# harmless\n",
                                                  encoding="utf-8")
        _git(self.repo, "add", "-A")
        _git(self.repo, "commit", "-q", "-m", "harmless tweak")

        report, code = tm_guard._run(_ns(against="main", repo=self.repo))
        self.assertEqual(code, 0)
        self.assertEqual(report["gate_result"], "PASS")

    def test_empty_diff_passes_with_a_note(self):
        report, code = tm_guard._run(_ns(staged=True, repo=self.repo))
        self.assertEqual(code, 0)
        self.assertIn("No added lines", report["note"])

    def test_format_text_and_github_render_without_error(self):
        (Path(self.repo) / "app.py").write_text(SAFE_APP + VULN_ADDITION, encoding="utf-8")
        _git(self.repo, "add", "-A")
        report, _ = tm_guard._run(_ns(staged=True, repo=self.repo))
        text = tm_guard._format_text(report)
        gh = tm_guard._format_github(report)
        self.assertIn("FAIL", text)
        self.assertIn("::error", gh)


if __name__ == "__main__":
    unittest.main()
