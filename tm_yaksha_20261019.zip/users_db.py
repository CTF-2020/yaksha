"""SQLite store for user accounts — the credential store backing sign-in.

Yaksha Guard has no self-service signup (an operator provisions accounts, see
the "ask your workspace admin" copy on the sign-in page). Passwords are never
stored in cleartext: hashing goes through ``werkzeug.security`` (PBKDF2-SHA256
by default), already a transitive Flask dependency — no new package.

Stdlib ``sqlite3`` only otherwise, mirroring :mod:`report_db`'s pattern:
connection-per-call with WAL + a busy timeout, and an idempotent :func:`init`
so ``DB_PATH`` can be repointed by tests without any "already initialized"
staleness.

Run as a script for admin provisioning without touching env vars:
    python users_db.py add <email> <password> [role]   # role: user (default) | admin
    python users_db.py list
    python users_db.py remove <email>
    python users_db.py promote <email>                 # set role=admin
    python users_db.py demote <email>                   # set role=user (refuses the last admin)
    python users_db.py passwd <email> <new-password>
"""
from __future__ import annotations

import os
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

from werkzeug.security import check_password_hash, generate_password_hash

STATE_DIR = Path(os.environ.get("TM_AUTH_DIR", str(Path.home() / ".tm_auth")))
DB_PATH = STATE_DIR / "auth.db"

_init_lock = threading.Lock()
_MIN_PASSWORD_LEN = 8
_ROLES = ("user", "admin")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    created_at    REAL,
    last_login_at REAL,
    role          TEXT NOT NULL DEFAULT 'user'
);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    # First-ever connection from multiple processes (e.g. every gunicorn
    # worker booting at once) races to create the WAL/SHM files; SQLite's
    # busy_timeout doesn't reliably cover that initial "enable WAL" step,
    # so retry the pragma itself rather than trusting the connect-level
    # timeout alone.
    for attempt in range(5):
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            break
        except sqlite3.OperationalError:
            if attempt == 4:
                raise
            time.sleep(0.1 * (attempt + 1))
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)
            # role predates this schema on any install that already ran
            # CREATE TABLE IF NOT EXISTS with the old column set — add it
            # once, idempotently, rather than bumping a migration version.
            cols = {r["name"] for r in conn.execute("PRAGMA table_info(users)")}
            if "role" not in cols:
                try:
                    conn.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'")
                except sqlite3.OperationalError as e:
                    # Another process's init() won this same race and already
                    # added it between our check and this statement.
                    if "duplicate column" not in str(e):
                        raise


def _normalize_email(email: str) -> str:
    return (email or "").strip().lower()


def create_user(email: str, password: str, role: str = "user") -> dict:
    """Create a user; raises ValueError on bad input, an invalid role, or a
    duplicate email."""
    email = _normalize_email(email)
    if not email or "@" not in email:
        raise ValueError("a valid email is required")
    if not password or len(password) < _MIN_PASSWORD_LEN:
        raise ValueError(f"password must be at least {_MIN_PASSWORD_LEN} characters")
    if role not in _ROLES:
        raise ValueError(f"role must be one of {_ROLES}")
    init()
    now = time.time()
    with closing(_connect()) as conn, conn:
        try:
            conn.execute(
                "INSERT INTO users(email,password_hash,created_at,role) VALUES (?,?,?,?)",
                (email, generate_password_hash(password), now, role))
        except sqlite3.IntegrityError:
            raise ValueError(f"a user with email {email!r} already exists")
    return {"email": email, "created_at": now, "role": role}


def verify_user(email: str, password: str) -> dict | None:
    """Check credentials; returns the public user record on success (and
    bumps last_login_at), or None on any mismatch — never distinguishes
    "no such user" from "wrong password" to the caller."""
    email = _normalize_email(email)
    if not email or not password:
        return None
    init()
    with closing(_connect()) as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if row is None or not check_password_hash(row["password_hash"], password):
        return None
    now = time.time()
    with closing(_connect()) as conn, conn:
        conn.execute("UPDATE users SET last_login_at = ? WHERE id = ?", (now, row["id"]))
    return {"email": row["email"], "created_at": row["created_at"], "last_login_at": now,
            "role": row["role"]}


def get_user(email: str) -> dict | None:
    init()
    with closing(_connect()) as conn:
        row = conn.execute(
            "SELECT id,email,created_at,last_login_at,role FROM users WHERE email = ?",
            (_normalize_email(email),)).fetchone()
    return dict(row) if row else None


def list_users() -> list[dict]:
    """Public view of every account — never includes password_hash."""
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT id,email,created_at,last_login_at,role FROM users ORDER BY created_at").fetchall()
    return [dict(r) for r in rows]


def delete_user(email: str) -> bool:
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute("DELETE FROM users WHERE email = ?", (_normalize_email(email),))
        return cur.rowcount > 0


def user_count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]


def admin_count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'").fetchone()[0]


def is_admin(email: str) -> bool:
    user = get_user(email)
    return bool(user and user["role"] == "admin")


def set_password(email: str, password: str) -> bool:
    """Change a user's password in place; raises ValueError on a too-short
    password. Returns False if no such user exists."""
    if not password or len(password) < _MIN_PASSWORD_LEN:
        raise ValueError(f"password must be at least {_MIN_PASSWORD_LEN} characters")
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute(
            "UPDATE users SET password_hash = ? WHERE email = ?",
            (generate_password_hash(password), _normalize_email(email)))
        return cur.rowcount > 0


def set_role(email: str, role: str) -> bool:
    """Change a user's role; raises ValueError for an unknown role. Returns
    False if no such user exists. Callers must independently guard against
    demoting the last remaining admin (see admin_count) — this function has
    no opinion on that, it just writes the column."""
    if role not in _ROLES:
        raise ValueError(f"role must be one of {_ROLES}")
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute(
            "UPDATE users SET role = ? WHERE email = ?", (role, _normalize_email(email)))
        return cur.rowcount > 0


if __name__ == "__main__":
    import sys

    def _main(argv: list[str]) -> int:
        if not argv:
            print(__doc__)
            return 1
        cmd = argv[0]
        if cmd == "add" and len(argv) in (3, 4):
            role = argv[3] if len(argv) == 4 else "user"
            try:
                user = create_user(argv[1], argv[2], role=role)
            except ValueError as exc:
                print(f"error: {exc}")
                return 1
            print(f"created {user['email']} (role={user['role']})")
            return 0
        if cmd == "list":
            for u in list_users():
                print(u["email"], "role =", u["role"], "last_login_at =", u["last_login_at"])
            return 0
        if cmd == "remove" and len(argv) == 2:
            ok = delete_user(argv[1])
            print("removed" if ok else "no such user")
            return 0 if ok else 1
        if cmd == "promote" and len(argv) == 2:
            ok = set_role(argv[1], "admin")
            print("promoted to admin" if ok else "no such user")
            return 0 if ok else 1
        if cmd == "demote" and len(argv) == 2:
            if admin_count() <= 1 and is_admin(argv[1]):
                print("error: refusing to demote the last remaining admin")
                return 1
            ok = set_role(argv[1], "user")
            print("demoted to user" if ok else "no such user")
            return 0 if ok else 1
        if cmd == "passwd" and len(argv) == 3:
            try:
                ok = set_password(argv[1], argv[2])
            except ValueError as exc:
                print(f"error: {exc}")
                return 1
            print("password updated" if ok else "no such user")
            return 0 if ok else 1
        print(__doc__)
        return 1

    raise SystemExit(_main(sys.argv[1:]))
