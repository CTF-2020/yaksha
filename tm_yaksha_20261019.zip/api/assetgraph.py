"""Persistent asset graph API.

Routes (CSRF + optional TM_API_KEY apply via the app's global before_request):
  GET  /api/v1/assetgraph                    engine status + counts by kind
  GET  /api/v1/assetgraph/assets              list assets {kind?}
  GET  /api/v1/assetgraph/assets/<id>         one asset + its edges
  GET  /api/v1/assetgraph/assets/<id>/repos   repos with an active edge into this asset
  POST /api/v1/assetgraph/sync                sync a codemodel report {report_id}
                                               -> reconciles the graph, returns a summary

Only reads/writes through report_db (a saved report) and its own
assetgraph.db store — same authorization posture as the correlator and
lineage APIs.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

from assetgraph import service

bp = Blueprint("assetgraph_api", __name__, url_prefix="/api/v1/assetgraph")

_KINDS = ("repo", "entry_point", "data_store", "external_service", "trust_boundary")


@bp.get("")
def status():
    return jsonify({"success": True, **service.status()})


@bp.get("/assets")
def list_assets():
    kind = request.args.get("kind") or None
    if kind and kind not in _KINDS:
        return jsonify({"success": False, "error": "invalid kind filter"}), 400
    return jsonify({"success": True, "assets": service.list_assets(kind=kind)})


@bp.get("/assets/<asset_id>")
def get_asset(asset_id: str):
    asset = service.get_asset(asset_id)
    if asset is None:
        return jsonify({"success": False, "error": f"asset not found: {asset_id}"}), 404
    return jsonify({"success": True, "asset": asset})


@bp.get("/assets/<asset_id>/repos")
def asset_repos(asset_id: str):
    if service.get_asset(asset_id) is None:
        return jsonify({"success": False, "error": f"asset not found: {asset_id}"}), 404
    return jsonify({"success": True, "repos": service.connected_repos(asset_id)})


@bp.post("/sync")
def sync():
    body = request.get_json(silent=True) or {}
    report_id = str(body.get("report_id", "")).strip()
    if not report_id:
        return jsonify({"success": False, "error": "report_id is required"}), 400
    try:
        summary = service.sync(report_id)
    except ValueError as exc:
        msg = str(exc)
        code = 404 if "not found" in msg else 400
        return jsonify({"success": False, "error": msg}), code
    return jsonify({"success": True, **summary}), 200
