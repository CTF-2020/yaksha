"""Claude API token-usage/cost ledger -- read-only.

Routes:
  GET /api/v1/llm-usage              aggregate spend/tokens, by caller + by
                                      model; optional ?since=<unix timestamp>
  GET /api/v1/llm-usage/recent       most recent calls, newest first;
                                      optional ?limit= (default 50, max 500)
  GET /api/v1/llm-usage/export.csv   the recent-calls list as a CSV download

This is TM's own spend running its own features (threat-model analysis,
diagrams, codemodel chain reasoning) -- not a report about a scanned repo --
so, unlike most of the API surface, it has no report_id/repo scoping.
Read-only: nothing here can be muted, assigned, or deleted, so it carries no
CSRF requirement (matches the rest of the app's GET-is-ungated convention).
"""
from __future__ import annotations

from flask import Blueprint, Response, jsonify, request

import llm_usage_db

bp = Blueprint("llm_usage_api", __name__, url_prefix="/api/v1/llm-usage")

_MAX_RECENT = 500
_DEFAULT_RECENT = 50


def _since_param():
    raw = request.args.get("since", "").strip()
    if not raw:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


@bp.get("")
def usage_summary():
    return jsonify({"success": True, **llm_usage_db.summary(since=_since_param())})


@bp.get("/recent")
def usage_recent():
    try:
        limit = int(request.args.get("limit", _DEFAULT_RECENT))
    except ValueError:
        limit = _DEFAULT_RECENT
    limit = max(1, min(limit, _MAX_RECENT))
    return jsonify({"success": True, "calls": llm_usage_db.recent(limit=limit)})


@bp.get("/export.csv")
def export_csv():
    try:
        limit = int(request.args.get("limit", _MAX_RECENT))
    except ValueError:
        limit = _MAX_RECENT
    limit = max(1, min(limit, _MAX_RECENT))
    csv_data = llm_usage_db.to_csv(llm_usage_db.recent(limit=limit))
    return Response(csv_data, mimetype="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="llm_usage.csv"'})
