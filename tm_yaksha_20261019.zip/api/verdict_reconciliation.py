"""Cross-report verdict reconciliation API — see verdict_reconciliation.py
for what distinguishes this from verdict_tracking.py's cross-SCAN
escalation tracking.

Routes:
  GET /api/v1/reconciliation/summary     conflict counts + worst conflicts
  GET /api/v1/reconciliation/conflicts   the full conflict list (?limit=)
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

import verdict_reconciliation

bp = Blueprint("verdict_reconciliation_api", __name__, url_prefix="/api/v1/reconciliation")


@bp.get("/summary")
def summary():
    return jsonify({"success": True, **verdict_reconciliation.summary()})


@bp.get("/conflicts")
def conflicts():
    try:
        limit = int(request.args.get("limit", 100))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "limit must be an integer"}), 400
    items = verdict_reconciliation.conflicts(limit=limit)
    return jsonify({"success": True, "count": len(items), "conflicts": items})
