"""Measured-accuracy harness for the DAST engine.

Unlike test_dast.py (which asserts a few behaviours on one app), this stands up a
labeled corpus of intentionally-vulnerable *and* deliberately-hardened endpoints,
scans each in isolation, and computes precision / recall / false-positive rate
per rule and overall. It exists so a change to the engine can be judged by a
number, not a vibe — the same way the SAR and Vajra projects are measured.

Design:
  * One loopback HTTP server dispatches by the first path segment to a scenario.
  * Each scenario is self-contained under /<name>/ and links only within itself,
    so a scan started at /<name>/ crawls exactly that scenario.
  * Ground truth per scenario is `expect` (rule ids that MUST fire) and `forbid`
    (rule ids that must NOT fire). Rules outside those sets are ignored for that
    scenario, so incidental findings (e.g. plaintext-HTTP over loopback) do not
    pollute the score.

Scoring (over the union of expect/forbid across all cases):
  * TP  = expected rule fired
  * FN  = expected rule did not fire            -> hurts recall
  * FP  = forbidden rule fired                  -> hurts precision
  * recall    = TP / (TP + FN)
  * precision = TP / (TP + FP)

The `forbid` sets deliberately encode the false-positive traps the context-aware
XSS check is meant to survive: reflections into an HTML comment, a <textarea>,
and a properly HTML-encoded sink must NOT raise a High reflected-XSS finding.
"""
from __future__ import annotations

import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from dast import config, engine


# ── Scenario app ──────────────────────────────────────────────────────────────
def _page(body: str) -> str:
    return f"<html><head><title>bench</title></head><body>{body}</body></html>"


def _enc(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


# Each scenario: (handler(h, sub, qs, origin)) -> None, writing a response.
def _sc_xss_body(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        h.html(_page(f"you searched for {q}"))
    else:
        h.html(_page("<a href='r?q=1'>go</a>"))


def _sc_xss_attr(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        h.html(_page(f"<input type=text value=\"{q}\">"))
    else:
        h.html(_page("<a href='r?q=1'>go</a>"))


def _sc_xss_comment(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        h.html(_page(f"<!-- last query: {q} -->ok"))
    else:
        h.html(_page("<a href='r?q=1'>go</a>"))


def _sc_xss_textarea(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        h.html(_page(f"<textarea>{q}</textarea>"))
    else:
        h.html(_page("<a href='r?q=1'>go</a>"))


def _sc_xss_encoded(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        safe = (q.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace('"', "&quot;"))
        h.html(_page(f"you searched for {safe}"))
    else:
        h.html(_page("<a href='r?q=1'>go</a>"))


def _sc_redirect(h, sub, qs, origin):
    if sub == "go" and "url" in qs:
        h.raw(302, "", headers={"Location": qs["url"][0]})
    else:
        h.html(_page("<a href='go?url=1'>next</a>"))


def _sc_cors_reflect_creds(h, sub, qs, origin):
    hdrs = {}
    if origin:
        hdrs["Access-Control-Allow-Origin"] = origin
        hdrs["Access-Control-Allow-Credentials"] = "true"
    h.html(_page("api landing"), headers=hdrs)


def _sc_cors_reflect(h, sub, qs, origin):
    hdrs = {}
    if origin:
        hdrs["Access-Control-Allow-Origin"] = origin
    h.html(_page("api landing"), headers=hdrs)


def _sc_cors_wildcard_creds(h, sub, qs, origin):
    h.html(_page("api landing"),
           headers={"Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Credentials": "true"})


def _sc_csp_weak(h, sub, qs, origin):
    h.html(_page("app"),
           headers={"Content-Security-Policy":
                    "default-src 'self'; script-src 'self' 'unsafe-inline' *"})


def _sc_secret_url(h, sub, qs, origin):
    if sub == "cb":
        h.html(_page("callback"))
    else:
        h.html(_page("<a href='cb?api_key=AKIAABC123&state=x'>link</a>"))


def _sc_error(h, sub, qs, origin):
    h.html(_page("Traceback (most recent call last):\n  File x, line 1"))


def _sc_banner(h, sub, qs, origin):
    h.html(_page("home"), headers={"X-Powered-By": "PHP/8.1.0"})


def _sc_cookie(h, sub, qs, origin):
    h.html(_page("home"), headers={"Set-Cookie": "sid=abc123"})


def _sc_dirlist(h, sub, qs, origin):
    h.raw(200, "<html><head><title>Index of /files</title></head>"
               "<body><pre>../</pre></body></html>",
          headers={"Content-Type": "text/html; charset=utf-8"})


def _sc_sqli(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        if q.count("'") % 2 == 1:                # unbalanced quote -> syntax error
            h.html(_page("Database error: You have an error in your SQL syntax; "
                         "check the manual near ''"))
        else:
            h.html(_page("results for " + _enc(q)))
    else:
        h.html(_page("<a href='r?q=abc'>go</a>"))


def _sc_traversal(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        if "etc/passwd" in q:
            h.raw(200, "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:\n",
                  headers={"Content-Type": "text/plain"})
        else:
            h.html(_page("file: " + _enc(q)))
    else:
        h.html(_page("<a href='r?q=readme.txt'>go</a>"))


def _sc_ssti(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        rendered = (_enc(q).replace("{{7*7}}", "49").replace("${7*7}", "49")
                    .replace("#{7*7}", "49").replace("<%= 7*7 %>", "49"))
        h.html(_page("hello " + rendered))
    else:
        h.html(_page("<a href='r?q=x'>go</a>"))


def _sc_cmdi(h, sub, qs, origin):
    if sub == "r":
        q = qs.get("q", [""])[0]
        # Simulate a shell that evaluates arithmetic substitution.
        out = _enc(q).replace("$((913+6))", "919").replace("`expr 913 + 6`", "919")
        h.html(_page("ping " + out))
    else:
        h.html(_page("<a href='r?q=host'>go</a>"))


def _sc_redirect_meta(h, sub, qs, origin):
    if sub == "go":
        url = qs.get("url", [""])[0]
        h.raw(200, '<html><head><meta http-equiv="refresh" content="0;url=%s">'
                   "</head><body>redirecting</body></html>" % _enc(url),
              headers={"Content-Type": "text/html; charset=utf-8"})
    else:
        h.html(_page("<a href='go?url=1'>next</a>"))


def _sc_inj_safe(h, sub, qs, origin):
    # Reflects every payload but HTML-encoded, never errors, never evaluates.
    if sub == "r":
        q = qs.get("q", [""])[0]
        h.html(_page("echo: " + _enc(q)))
    else:
        h.html(_page("<a href='r?q=x'>go</a>"))


def _sc_safe(h, sub, qs, origin):
    # A hardened endpoint: strong headers, safe cookie, no reflection, no banner.
    if sub == "r":
        q = qs.get("q", [""])[0]
        safe = (q.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace('"', "&quot;"))
        body = _page(f"searched: {safe}")
    else:
        body = _page("<a href='r?q=1'>go</a>")
    h.html(body, headers={
        "Content-Security-Policy":
            "default-src 'self'; object-src 'none'; base-uri 'self'; "
            "frame-ancestors 'none'",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Cache-Control": "no-store",
        "Set-Cookie": "sid=abc123; HttpOnly; SameSite=Strict",
    })


SCENARIOS = {
    "xss_body": _sc_xss_body,
    "xss_attr": _sc_xss_attr,
    "xss_comment": _sc_xss_comment,
    "xss_textarea": _sc_xss_textarea,
    "xss_encoded": _sc_xss_encoded,
    "redirect": _sc_redirect,
    "cors_reflect_creds": _sc_cors_reflect_creds,
    "cors_reflect": _sc_cors_reflect,
    "cors_wildcard_creds": _sc_cors_wildcard_creds,
    "csp_weak": _sc_csp_weak,
    "secret_url": _sc_secret_url,
    "error": _sc_error,
    "banner": _sc_banner,
    "cookie": _sc_cookie,
    "dirlist": _sc_dirlist,
    "sqli": _sc_sqli,
    "traversal": _sc_traversal,
    "ssti": _sc_ssti,
    "cmdi": _sc_cmdi,
    "redirect_meta": _sc_redirect_meta,
    "inj_safe": _sc_inj_safe,
    "safe": _sc_safe,
}


# Ground truth: {scenario: {"expect": {...}, "forbid": {...}}}
CORPUS = {
    "xss_body":            {"expect": {"DAST-XSS-REFLECTED"}, "forbid": set()},
    "xss_attr":            {"expect": {"DAST-XSS-REFLECTED"}, "forbid": set()},
    "xss_comment":         {"expect": {"DAST-XSS-REFLECTED-INERT"},
                            "forbid": {"DAST-XSS-REFLECTED"}},
    "xss_textarea":        {"expect": {"DAST-XSS-REFLECTED-INERT"},
                            "forbid": {"DAST-XSS-REFLECTED"}},
    "xss_encoded":         {"expect": set(),
                            "forbid": {"DAST-XSS-REFLECTED",
                                       "DAST-XSS-REFLECTED-INERT"}},
    "redirect":            {"expect": {"DAST-OPEN-REDIRECT"}, "forbid": set()},
    "cors_reflect_creds":  {"expect": {"DAST-CORS-REFLECT-CREDS"}, "forbid": set()},
    "cors_reflect":        {"expect": {"DAST-CORS-REFLECT"},
                            "forbid": {"DAST-CORS-REFLECT-CREDS"}},
    "cors_wildcard_creds": {"expect": {"DAST-CORS-WILDCARD"}, "forbid": set()},
    "csp_weak":            {"expect": {"DAST-HDR-CSP-WEAK"}, "forbid": set()},
    "secret_url":          {"expect": {"DAST-INFO-SECRET-URL"}, "forbid": set()},
    "error":               {"expect": {"DAST-INFO-ERROR"}, "forbid": set()},
    "banner":              {"expect": {"DAST-INFO-BANNER"}, "forbid": set()},
    "cookie":              {"expect": {"DAST-COOKIE-FLAGS", "DAST-HDR-CACHE"},
                            "forbid": set()},
    "dirlist":             {"expect": {"DAST-INFO-DIRLIST"}, "forbid": set()},
    "sqli":                {"expect": {"DAST-SQLI"}, "forbid": set()},
    "traversal":           {"expect": {"DAST-PATH-TRAVERSAL"}, "forbid": set()},
    "ssti":                {"expect": {"DAST-SSTI"}, "forbid": set()},
    "cmdi":                {"expect": {"DAST-CMD-INJECTION"}, "forbid": set()},
    "redirect_meta":       {"expect": {"DAST-OPEN-REDIRECT"}, "forbid": set()},
    "inj_safe":            {"expect": set(),
                            "forbid": {"DAST-SQLI", "DAST-PATH-TRAVERSAL",
                                       "DAST-SSTI", "DAST-CMD-INJECTION",
                                       "DAST-XSS-REFLECTED"}},
    "safe":                {"expect": set(),
                            "forbid": {"DAST-XSS-REFLECTED",
                                       "DAST-XSS-REFLECTED-INERT",
                                       "DAST-CORS-REFLECT",
                                       "DAST-CORS-REFLECT-CREDS",
                                       "DAST-HDR-CSP", "DAST-HDR-CSP-WEAK",
                                       "DAST-HDR-XCTO", "DAST-HDR-XFO",
                                       "DAST-COOKIE-FLAGS", "DAST-HDR-CACHE",
                                       "DAST-INFO-BANNER"}},
}


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def version_string(self):
        # A hardened server would not leak its runtime version in Server:;
        # stdlib's default ("BaseHTTP/x Python/y") otherwise trips the banner
        # rule on every scenario, including the deliberately-safe one.
        return "bench"

    def do_GET(self):                          # noqa: N802
        parsed = urlparse(self.path)
        segments = [s for s in parsed.path.split("/") if s]
        name = segments[0] if segments else ""
        sub = "/".join(segments[1:])
        qs = parse_qs(parsed.query, keep_blank_values=True)
        origin = self.headers.get("Origin", "")
        fn = SCENARIOS.get(name)
        if fn is None:
            self.raw(404, "not found")
            return
        fn(self, sub, qs, origin)

    # response helpers used by scenarios
    def html(self, body: str, headers: dict | None = None):
        h = {"Content-Type": "text/html; charset=utf-8"}
        h.update(headers or {})
        self.raw(200, body, headers=h)

    def raw(self, status: int, body: str, headers: dict | None = None):
        raw = body.encode("utf-8")
        self.send_response(status)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        if body:
            self.wfile.write(raw)


class _Server:
    def __enter__(self):
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.port}/"
        return self

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.httpd.server_close()


# ── Runner / scoring ──────────────────────────────────────────────────────────
def run() -> dict:
    tp = fn = fp = 0
    per_rule: dict[str, dict] = {}
    case_rows = []

    def bump(rule, kind):
        r = per_rule.setdefault(rule, {"tp": 0, "fn": 0, "fp": 0})
        r[kind] += 1

    with _Server() as srv:
        host = "127.0.0.1"
        scope = [host]
        for name, truth in CORPUS.items():
            start = f"{srv.base}{name}/"
            result = engine.scan(start, scope, severity_threshold="Info")
            fired = {f["id"] for f in result.findings}
            case_tp = truth["expect"] & fired
            case_fn = truth["expect"] - fired
            case_fp = truth["forbid"] & fired
            tp += len(case_tp)
            fn += len(case_fn)
            fp += len(case_fp)
            for r in case_tp:
                bump(r, "tp")
            for r in case_fn:
                bump(r, "fn")
            for r in case_fp:
                bump(r, "fp")
            status = "ok" if not case_fn and not case_fp else "MISS"
            case_rows.append((name, status, sorted(case_fn), sorted(case_fp)))

    recall = tp / (tp + fn) if (tp + fn) else 1.0
    precision = tp / (tp + fp) if (tp + fp) else 1.0
    f1 = (2 * precision * recall / (precision + recall)
          if (precision + recall) else 0.0)
    return {
        "tp": tp, "fn": fn, "fp": fp,
        "recall": recall, "precision": precision, "f1": f1,
        "per_rule": per_rule, "cases": case_rows,
        "n_cases": len(CORPUS),
    }


def main(argv=None) -> int:
    r = run()
    print("DAST engine — measured accuracy")
    print("=" * 60)
    for name, status, miss_fn, miss_fp in r["cases"]:
        flag = " " if status == "ok" else "!"
        detail = ""
        if miss_fn:
            detail += f"  missed={miss_fn}"
        if miss_fp:
            detail += f"  false+={miss_fp}"
        print(f" [{flag}] {name:<22} {status}{detail}")
    print("-" * 60)
    print(f" cases      : {r['n_cases']}")
    print(f" TP/FN/FP   : {r['tp']} / {r['fn']} / {r['fp']}")
    print(f" recall     : {r['recall']*100:5.1f}%  (expected findings caught)")
    print(f" precision  : {r['precision']*100:5.1f}%  (no forbidden findings fired)")
    print(f" F1         : {r['f1']*100:5.1f}%")
    print("-" * 60)
    print(" per-rule (tp/fn/fp):")
    for rule in sorted(r["per_rule"]):
        c = r["per_rule"][rule]
        print(f"   {rule:<28} {c['tp']}/{c['fn']}/{c['fp']}")
    ok = r["fn"] == 0 and r["fp"] == 0
    print("=" * 60)
    print(" RESULT:", "PASS (100% recall, 0 false positives)" if ok
          else f"REGRESSION ({r['fn']} missed, {r['fp']} false positive(s))")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
