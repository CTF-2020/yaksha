"""Tests for LLM multi-step attack-chain reasoning (codemodel.chain_reasoning)
+ the /correlate/chain-reasoning API.

Unit tests mock the LLM call so behavior around parsing, grounding
verification, and graceful degradation is verified without a network call;
an integration class runs the real codemodel extractor on a fixture repo, and
an API class drives the Flask route end to end (LLM call still mocked).
"""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from unittest.mock import patch

from codemodel import chain_reasoning, extractor, mapper, threats


def _cm_report(entry_over=None):
    entry = {"method": "POST", "path": "/upload", "handler": "upload",
              "file": "h.py", "line": 3, "authenticated": False, "controls": [],
              "sinks": [{"kind": "path", "family": "path-traversal", "cwe": "CWE-22",
                         "name": "open", "file": "h.py", "line": 5, "hops": 0,
                         "tainted": True, "confidence": "high"}]}
    if entry_over:
        entry.update(entry_over)
    return {
        "id": "cm", "title": "fixture", "methodology": "codemodel",
        "categories": [{
            "_source": "CODEMODEL", "id": "CM-001",
            "affected_components": ["POST /upload -> open (h.py:5)"],
        }],
        "scan_metadata": {
            "attack_surface": [entry],
            "data_stores": [{"kind": "filesystem", "engine": "local",
                              "file": "store.py", "line": 9}],
            "external_calls": [{"kind": "http", "target": "internal-admin.local",
                                 "file": "admin.py", "line": 20, "encrypted": True}],
            "code_controls": [{"kind": "auth", "mechanism": "@login_required",
                                "scope": "entrypoint"}],
            "trust_boundaries": [{"name": "filesystem", "kind": "persistence",
                                   "description": "local disk writes"}],
        },
    }


# Both steps cite loci that are actually present in _cm_report()'s facts
# (the sink at h.py:5, the external call at admin.py:20) -> fully grounded.
_VALID_RESPONSE = json.dumps({
    "summary": "One chain crosses the upload endpoint into the admin import job.",
    "chains": [{
        "title": "Unauth upload poisons admin import",
        "narrative": "Attacker uploads a crafted file via /upload, which is later "
                      "read by the admin import job with no revalidation.",
        "severity": "High",
        "confidence": 0.8,
        "families": ["path-traversal"],
        "cwes": ["CWE-22"],
        "preconditions": "Attacker can reach /upload unauthenticated.",
        "business_impact": "Admin-scope file write.",
        "steps": [
            {"locus": "h.py:5", "description": "Attacker-controlled file lands on disk."},
            {"locus": "admin.py:20", "description": "Admin job later reads it unchecked."},
        ],
        "source_loci": ["h.py:5", "admin.py:20"],
    }],
})

# Same shape, but neither step locus appears anywhere in the supplied facts.
_FABRICATED_RESPONSE = json.dumps({
    "chains": [{
        "title": "Invented chain",
        "narrative": "made up",
        "severity": "Critical",
        "confidence": 0.99,
        "steps": [
            {"locus": "nonexistent/ghost.py:9999", "description": "does not exist"},
            {"locus": "made_up_handler", "description": "also does not exist"},
        ],
    }],
})

# One grounded step (h.py:5), one fabricated -> partial grounding.
_PARTIAL_RESPONSE = json.dumps({
    "chains": [{
        "title": "Half-grounded chain",
        "narrative": "half real",
        "severity": "High",
        "confidence": 0.9,
        "steps": [
            {"locus": "h.py:5", "description": "real fact"},
            {"locus": "totally/invented.py:1", "description": "invented"},
        ],
    }],
})


def _bounded(report=None):
    return chain_reasoning._extract_bounded(report or _cm_report())


class TestFactsText(unittest.TestCase):
    def test_facts_include_entry_points_stores_calls_boundaries(self):
        text = chain_reasoning._facts_text(_bounded())
        self.assertIn("/upload", text)
        self.assertIn("path-traversal", text)
        self.assertIn("filesystem/local", text)
        self.assertIn("internal-admin.local", text)
        self.assertIn("@login_required", text)
        self.assertIn("filesystem", text)

    def test_facts_list_known_findings_so_model_does_not_restate_them(self):
        text = chain_reasoning._facts_text(_bounded())
        self.assertIn("ALREADY REPORTED AS A SINGLE-HOP FINDING", text)
        self.assertIn("POST /upload -> open (h.py:5)", text)

    def test_entry_point_selection_prioritizes_unauth_and_sinks(self):
        surface = [
            {"authenticated": True, "kind": "http", "sinks": []},
            {"authenticated": False, "kind": "agent-tool", "sinks": [{}, {}]},
        ]
        ranked = chain_reasoning._select_entry_points(surface)
        self.assertFalse(ranked[0]["authenticated"])


class TestGrounding(unittest.TestCase):
    def test_exact_file_line_is_grounded(self):
        index = chain_reasoning._fact_locus_index(_bounded())
        self.assertTrue(chain_reasoning._locus_grounded("h.py:5", index))

    def test_handler_and_target_names_are_grounded(self):
        index = chain_reasoning._fact_locus_index(_bounded())
        self.assertTrue(chain_reasoning._locus_grounded("upload", index))
        self.assertTrue(chain_reasoning._locus_grounded("internal-admin.local", index))

    def test_invented_locus_is_not_grounded(self):
        index = chain_reasoning._fact_locus_index(_bounded())
        self.assertFalse(chain_reasoning._locus_grounded("nonexistent/ghost.py:9999", index))

    def test_empty_locus_is_not_grounded(self):
        index = chain_reasoning._fact_locus_index(_bounded())
        self.assertFalse(chain_reasoning._locus_grounded("", index))

    def test_index_covers_sinks_stores_calls_and_controls(self):
        index = chain_reasoning._fact_locus_index(_bounded())
        self.assertIn("h.py:5", index)             # sink
        self.assertIn("store.py:9", index)          # data store
        self.assertIn("admin.py:20", index)          # external call
        self.assertIn("@login_required", index)      # control mechanism


class TestReasonUnit(unittest.TestCase):
    def test_no_api_key_returns_empty_without_calling_llm(self):
        with patch("codemodel.chain_reasoning.call_claude_cached") as mock_call:
            chains = chain_reasoning.reason(_cm_report(), "")
        self.assertEqual(chains, [])
        mock_call.assert_not_called()

    def test_no_attack_surface_returns_empty_without_calling_llm(self):
        report = _cm_report()
        report["scan_metadata"]["attack_surface"] = []
        with patch("codemodel.chain_reasoning.call_claude_cached") as mock_call:
            chains = chain_reasoning.reason(report, "sk-fake")
        self.assertEqual(chains, [])
        mock_call.assert_not_called()

    def test_valid_grounded_response_parses_into_chain(self):
        with patch("codemodel.chain_reasoning.call_claude_cached", return_value=_VALID_RESPONSE):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        self.assertEqual(len(chains), 1)
        c = chains[0]
        self.assertEqual(c.severity, "High")
        self.assertEqual(c.confidence, 0.8)
        self.assertEqual(c.grounding, 1.0)
        self.assertEqual(len(c.steps), 2)
        self.assertEqual(c.steps[0].locus, "h.py:5")

    def test_fully_fabricated_chain_is_dropped(self):
        with patch("codemodel.chain_reasoning.call_claude_cached",
                   return_value=_FABRICATED_RESPONSE):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        self.assertEqual(chains, [])

    def test_partially_grounded_chain_is_kept_with_capped_confidence(self):
        with patch("codemodel.chain_reasoning.call_claude_cached", return_value=_PARTIAL_RESPONSE):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        self.assertEqual(len(chains), 1)
        c = chains[0]
        self.assertEqual(c.grounding, 0.5)
        # model claimed 0.9 confidence but only half the chain is verifiable
        self.assertLessEqual(c.confidence, 0.5)

    def test_single_step_chain_is_dropped(self):
        raw = json.dumps({"chains": [{"title": "not really a chain", "severity": "High",
                                       "steps": [{"locus": "h.py:5", "description": "x"}]}]})
        with patch("codemodel.chain_reasoning.call_claude_cached", return_value=raw):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        self.assertEqual(chains, [])

    def test_empty_chains_array_is_a_valid_honest_result(self):
        raw = json.dumps({"summary": "nothing found", "chains": []})
        with patch("codemodel.chain_reasoning.call_claude_cached", return_value=raw):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        self.assertEqual(chains, [])

    def test_hostile_non_json_response_degrades_to_empty_list(self):
        with patch("codemodel.chain_reasoning.call_claude_cached",
                   return_value="I will not comply with JSON formatting."):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        self.assertEqual(chains, [])

    def test_severity_and_confidence_are_coerced(self):
        raw = json.dumps({"chains": [{
            "title": "t", "severity": "super critical!!", "confidence": "9.9",
            "steps": [{"locus": "h.py:5", "description": "1"},
                      {"locus": "admin.py:20", "description": "2"}],
        }]})
        with patch("codemodel.chain_reasoning.call_claude_cached", return_value=raw):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        self.assertEqual(chains[0].severity, "Medium")   # invalid value -> safe default
        self.assertEqual(chains[0].confidence, 1.0)       # clamped to [0, 1], fully grounded


class TestToReport(unittest.TestCase):
    def test_report_shape_with_chains(self):
        with patch("codemodel.chain_reasoning.call_claude_cached", return_value=_VALID_RESPONSE):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        report = chain_reasoning.to_report(
            chains, [{"id": "cm", "title": "fixture", "role": "codemodel"}], {})
        self.assertEqual(report["methodology"], "chainreasoning")
        self.assertEqual(report["overall_risk"], "High")
        self.assertEqual(len(report["categories"]), 1)
        cat = report["categories"][0]
        self.assertEqual(cat["_source"], "LLM-CHAIN")
        self.assertEqual(cat["risk"], "High")
        self.assertEqual(cat["grounding"], 1.0)
        self.assertEqual(len(cat["threats"]), 2)
        self.assertEqual(report["scan_metadata"]["chains_total"], 1)
        self.assertEqual(report["scan_metadata"]["avg_grounding"], 1.0)
        self.assertEqual(report["scan_metadata"]["fully_grounded"], 1)

    def test_report_shape_without_chains(self):
        report = chain_reasoning.to_report([], [], {})
        self.assertEqual(report["overall_risk"], "Info")
        self.assertEqual(report["categories"], [])
        self.assertEqual(report["recommendations"], [])
        self.assertIsNone(report["scan_metadata"]["avg_grounding"])

    def test_partial_grounding_surfaces_a_warning_in_notes(self):
        with patch("codemodel.chain_reasoning.call_claude_cached", return_value=_PARTIAL_RESPONSE):
            chains = chain_reasoning.reason(_cm_report(), "sk-fake")
        report = chain_reasoning.to_report(chains, [], {})
        self.assertIn("unverified", report["categories"][0]["notes"])


class TestIntegrationRealExtractor(unittest.TestCase):
    """Facts sheet built from the real codemodel extractor, not a synthetic dict."""

    FLASK_APP = '''
import os
from flask import Flask, request
app = Flask(__name__)

@app.route("/upload", methods=["POST"])
def upload():
    f = request.files["f"]
    f.save("/data/" + f.filename)
    return "ok"

@app.route("/admin/import", methods=["POST"])
def admin_import():
    os.system("import-tool /data/" + request.form["name"])
    return "ok"
'''

    def _cm_report_from_source(self):
        d = tempfile.mkdtemp(prefix="cr_test_")
        with open(os.path.join(d, "app.py"), "w", encoding="utf-8") as fh:
            fh.write(self.FLASK_APP)
        model = extractor.build_model(d)
        return mapper.build_report(model, threats.derive(model),
                                   {"id": "r", "name": "fixture"}, {})

    def test_facts_text_reflects_real_extracted_surface(self):
        report = self._cm_report_from_source()
        text = chain_reasoning._facts_text(chain_reasoning._extract_bounded(report))
        self.assertIn("/upload", text)
        self.assertIn("/admin/import", text)

    def test_reason_calls_llm_with_real_facts_and_parses_response(self):
        report = self._cm_report_from_source()
        # Ground the mocked response in a real extracted sink location so the
        # grounding check (which now runs against real extractor output) passes.
        eps_with_sinks = [ep for ep in report["scan_metadata"]["attack_surface"] if ep["sinks"]]
        self.assertTrue(eps_with_sinks, "fixture should yield at least one reachable sink")
        sink = eps_with_sinks[0]["sinks"][0]
        real_response = json.dumps({"chains": [{
            "title": "Upload feeds unchecked command", "severity": "Critical", "confidence": 0.9,
            "steps": [
                {"locus": f"{sink['file']}:{sink['line']}", "description": "attacker writes file"},
                {"locus": "admin_import", "description": "later executed unchecked"},
            ],
        }]})
        with patch("codemodel.chain_reasoning.call_claude_cached",
                   return_value=real_response) as mock_call:
            chains = chain_reasoning.reason(report, "sk-fake")
        self.assertEqual(len(chains), 1)
        self.assertEqual(chains[0].grounding, 1.0)
        # dynamic (facts) text was passed as the last positional arg
        called_args = mock_call.call_args[0]
        self.assertIn("/upload", called_args[-1])


class TestChainReasoningApi(unittest.TestCase):
    """Drives the real Flask route; the LLM call itself stays mocked."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN
        cls._saved = []
        cls.cm_id = tm_app._save_report(_cm_report(), "CR CM fixture")
        cls._saved.append(cls.cm_id)
        cls.dast_id = tm_app._save_report(
            {"id": "dyn", "methodology": "dast", "categories": []}, "CR DAST fixture")
        cls._saved.append(cls.dast_id)

    @classmethod
    def tearDownClass(cls):
        for rid in cls._saved:
            cls.client.delete(f"/api/v1/reports/{rid}",
                              headers={"X-CSRF-Token": cls.csrf})

    def _post(self, body):
        return self.client.post("/api/v1/correlate/chain-reasoning", json=body,
                                headers={"X-CSRF-Token": self.csrf})

    def test_missing_codemodel_id_rejected(self):
        self.assertEqual(self._post({}).status_code, 400)

    def test_wrong_methodology_rejected(self):
        r = self._post({"codemodel_report_id": self.dast_id})
        self.assertEqual(r.status_code, 400)
        self.assertIn("not a code-derived model", r.get_json()["error"])

    def test_unknown_codemodel_id_404(self):
        r = self._post({"codemodel_report_id": "nonexistent_1_00"})
        self.assertEqual(r.status_code, 404)

    def test_missing_api_key_rejected_with_no_offline_mode(self):
        r = self._post({"codemodel_report_id": self.cm_id, "api_key": ""})
        self.assertEqual(r.status_code, 400)
        self.assertIn("Anthropic API key", r.get_json()["error"])

    def test_run_with_api_key_saves_and_returns_report(self):
        with patch("codemodel.chain_reasoning.call_claude_cached", return_value=_VALID_RESPONSE):
            r = self._post({"codemodel_report_id": self.cm_id, "api_key": "sk-fake"})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        j = r.get_json()
        self.assertEqual(j["chains_total"], 1)
        self.assertEqual(j["overall_risk"], "High")
        self._saved.append(j["report_id"])


if __name__ == "__main__":
    unittest.main()
