"""One-time admin provisioning for a fresh deploy.

Run before the app server starts (see the Render start command). Creates the
admin account from TM_ADMIN_EMAIL / TM_ADMIN_PASSWORD if it doesn't already
exist; a no-op on every subsequent boot once the account is there. Both env
vars are optional so this is safe to leave wired into the start command
permanently — without them it just initializes the (empty) users table.
"""
from __future__ import annotations

import os

import users_db

users_db.init()

email = os.environ.get("TM_ADMIN_EMAIL", "").strip()
password = os.environ.get("TM_ADMIN_PASSWORD", "")

if email and password and users_db.get_user(email) is None:
    try:
        users_db.create_user(email, password, role="admin")
        print(f"bootstrap_admin: created admin account {email}")
    except ValueError:
        # Another worker process created it between our get_user check and
        # this insert (gunicorn imports wsgi.py once per worker) — fine.
        pass
