"""Tests for lineage.db — the SQLite store for threat lineage.

DB_PATH is repointed to a temp file for the duration of each test, mirroring
test_suppressions_db.py, so this suite never touches the real
~/.tm_lineage.db.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from lineage import db
from lineage.model import LineageEvent, ThreatLineage


def _threat(id_="t1", family="sql-injection", status="predicted"):
    return ThreatLineage(
        id=id_, family=family, family_title="SQL Injection", status=status,
        founding_locus=["user", "search", "handler"], kinds_seen=["design"],
        first_seen_at="2026-01-01T00:00:00Z", first_seen_report_id="r1",
        first_seen_report_title="Design Review", first_seen_kind="design",
        updated_at="2026-01-01T00:00:00Z",
    )


def _event(report_id="r1", kind="design"):
    return LineageEvent(
        at="2026-01-01T00:00:00Z", report_id=report_id, report_title="Report",
        kind=kind, methodology="owasp", severity="High",
        title="SQL Injection", locus_label="user search handler",
    )


class TestLineageDb(unittest.TestCase):
    def setUp(self):
        self._orig_path = db.DB_PATH
        self._td = tempfile.TemporaryDirectory()
        db.DB_PATH = Path(self._td.name) / "lineage.db"

    def tearDown(self):
        db.DB_PATH = self._orig_path
        self._td.cleanup()

    def test_upsert_and_get(self):
        db.upsert_threat(_threat())
        got = db.get("t1")
        self.assertIsNotNone(got)
        self.assertEqual(got.family, "sql-injection")
        self.assertEqual(got.status, "predicted")
        self.assertEqual(got.founding_locus, ["user", "search", "handler"])

    def test_upsert_is_idempotent_by_id(self):
        db.upsert_threat(_threat(status="predicted"))
        db.upsert_threat(_threat(status="realized"))
        self.assertEqual(db.count(), 1)
        self.assertEqual(db.get("t1").status, "realized")

    def test_founding_locus_does_not_change_on_conflict_update(self):
        # ON CONFLICT only updates status/kinds_seen/updated_at — founding_locus
        # must stay whatever it was set to at INSERT (frozen identity).
        t = _threat()
        db.upsert_threat(t)
        t2 = _threat(status="confirmed")
        t2.founding_locus = ["something", "totally", "different"]
        db.upsert_threat(t2)
        self.assertEqual(db.get("t1").founding_locus, ["user", "search", "handler"])
        self.assertEqual(db.get("t1").status, "confirmed")

    def test_missing_threat_returns_none(self):
        self.assertIsNone(db.get("nonexistent"))

    def test_all_threats_filters_by_status_and_family(self):
        db.upsert_threat(_threat(id_="a", family="sql-injection", status="predicted"))
        db.upsert_threat(_threat(id_="b", family="command-injection", status="realized"))
        db.upsert_threat(_threat(id_="c", family="sql-injection", status="realized"))

        self.assertEqual(len(db.all_threats()), 3)
        self.assertEqual({t.id for t in db.all_threats(status="realized")}, {"b", "c"})
        self.assertEqual({t.id for t in db.all_threats(family="sql-injection")}, {"a", "c"})
        self.assertEqual({t.id for t in db.all_threats(status="realized", family="sql-injection")}, {"c"})

    def test_add_event_and_events_for(self):
        db.upsert_threat(_threat())
        db.add_event("t1", _event(kind="design"))
        db.add_event("t1", _event(report_id="r2", kind="code"))
        events = db.events_for("t1")
        self.assertEqual(len(events), 2)
        self.assertEqual([e.kind for e in events], ["design", "code"])

    def test_event_count(self):
        db.upsert_threat(_threat())
        self.assertEqual(db.event_count("t1"), 0)
        db.add_event("t1", _event())
        db.add_event("t1", _event())
        self.assertEqual(db.event_count("t1"), 2)

    def test_db_path_survives_repointing(self):
        other = Path(self._td.name) / "sub" / "other.db"
        db.DB_PATH = other
        db.upsert_threat(_threat())
        self.assertTrue(other.exists())
        self.assertEqual(db.count(), 1)


if __name__ == "__main__":
    unittest.main()
