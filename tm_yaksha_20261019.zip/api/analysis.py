"""Analysis API routes."""
from __future__ import annotations

from flask import Blueprint

import app as tm_app


bp = Blueprint("analysis_api", __name__, url_prefix="/api/v1/analysis")


@bp.post("/reviews")
@tm_app.limiter.limit("10 per minute")
def create_review():
    """Run a review and return the finished report."""
    return tm_app._analyze_route_impl()


@bp.post("/jobs")
@tm_app.limiter.limit("10 per minute")
def create_review_job():
    """Start a streaming review job."""
    return tm_app._analyze_stream_impl()


@bp.get("/jobs/<job_id>/events")
def review_job_events(job_id: str):
    """Stream review progress events."""
    return tm_app._analyze_stream_events_impl(job_id)
