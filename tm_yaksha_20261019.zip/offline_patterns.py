"""Full offline threat-modeling engines for named analysis methodologies.

These engines deliberately return the same report shapes as the LLM-backed
analyzers. They use local framework knowledge bases plus deterministic rule
evaluation so every UI analysis pattern remains usable with no Claude/API key.
"""
from __future__ import annotations

import re
import time
from collections import defaultdict
from typing import Iterable

import offline_rules
from _rules_ai import AI_RULES
from _rules_api import API_RULES
from _rules_web import WEB_RULES
from agentic_threats import (
    detect_ai_architecture,
    detect_api_architecture,
    get_agentic_attack_surface,
    is_ai_analysis_applicable,
)
from cis_cloud import CIS_CLOUD_DOMAINS
from owasp import OWASP_TOP10
from owasp_api import OWASP_API_TOP10
from owasp_cloud import OWASP_CLOUD_TOP10
from owasp_llm import OWASP_LLM_TOP10
from risk_signals import RISK_SIGNALS as _RISK_SIGNALS
from stride_pasta import PASTA_STAGES, STRIDE


_SEV_RANK = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
_SEV_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}
_RISK_ORDER = ["Critical", "High", "Medium", "Low", "Info"]

_CATEGORY_DISPLAY_NAMES = {
    "AI-LLM01": "Prompt Injection",
    "AI-LLM02": "Insecure Output Handling",
    "AI-LLM03": "Training Data and Model Poisoning",
    "AI-LLM04": "Model Denial of Service",
    "AI-LLM05": "Supply Chain Vulnerabilities",
    "AI-LLM06": "Sensitive Information Disclosure",
    "AI-LLM07": "Insecure Plugin and Tool Design",
    "AI-LLM08": "Excessive Agency",
    "AI-LLM09": "Overreliance",
    "AI-LLM10": "Model Theft",
    "API-API1": "Broken Object Level Authorization",
    "API-API2": "Broken Authentication",
    "API-API3": "Broken Object Property Level Authorization",
    "API-API4": "Unrestricted Resource Consumption",
    "API-API5": "Broken Function Level Authorization",
    "API-API6": "Unrestricted Access to Sensitive Business Flows",
    "API-API7": "Server Side Request Forgery",
    "API-API8": "Security Misconfiguration",
    "API-API9": "Improper Inventory Management",
    "API-API10": "Unsafe Consumption of APIs",
    "WEB-A01": "Broken Access Control",
    "WEB-A02": "Cryptographic Failures",
    "WEB-A03": "Injection",
    "WEB-A04": "Insecure Design",
    "WEB-A05": "Security Misconfiguration",
    "WEB-A06": "Vulnerable and Outdated Components",
    "WEB-A07": "Identification and Authentication Failures",
    "WEB-A08": "Software and Data Integrity Failures",
    "WEB-A09": "Security Logging and Monitoring Failures",
    "WEB-A10": "Server-Side Request Forgery",
}

_COMPONENT_PATTERNS: list[tuple[str, list[str]]] = [
    ("Web frontend", ["react", "angular", "vue", "spa", "single page", "browser", "frontend", "web app"]),
    ("Mobile client", ["ios", "android", "mobile", "react native", "flutter", "apk", "ipa"]),
    ("API gateway", ["api gateway", "gateway", "nginx", "kong", "apigee", "ambassador"]),
    ("Public API", ["rest api", "graphql", "endpoint", "webhook", "public api", "/api/"]),
    ("Authentication service", ["auth service", "auth-svc", "authentication service", "identity provider", "idp", "sso", "oauth", "oidc", "login", "mfa", "cognito", "keycloak", "okta"]),
    ("Admin portal", ["admin", "administrator", "management portal", "backoffice", "console"]),
    ("Application service", ["microservice", "service", "backend", "worker", "server", "application"]),
    ("Database", ["postgres", "postgresql", "mysql", "sql server", "database", "db", "rds", "aurora", "mongodb"]),
    ("Object storage", ["s3", "bucket", "blob", "gcs", "object storage", "file storage"]),
    ("Message queue", ["queue", "sqs", "kafka", "rabbitmq", "pub/sub", "event bus", "stream"]),
    ("Cache", ["redis", "memcached", "cache", "elasticache"]),
    ("LLM service", ["llm", "gpt", "claude", "model", "ai model", "inference", "agent"]),
    ("RAG/vector store", ["rag", "retrieval", "embedding", "vector", "knowledge base", "document store"]),
    ("Tool/plugin layer", ["tool", "plugin", "function call", "mcp", "agent action", "connector"]),
    ("CI/CD pipeline", ["ci/cd", "pipeline", "github actions", "jenkins", "gitlab", "build", "deploy"]),
    ("Cloud control plane", ["aws", "azure", "gcp", "iam", "cloudtrail", "security hub", "cloud"]),
    ("Kubernetes cluster", ["kubernetes", "k8s", "eks", "aks", "gke", "pod", "container", "docker"]),
    ("CDN/load balancer", ["cloudfront", "cdn", "load balancer", "alb", "elb", "waf"]),
    ("Secrets manager", ["secret", "vault", "kms", "key management", "secrets manager", "parameter store"]),
    ("Monitoring/SIEM", ["siem", "monitoring", "logging", "audit", "cloudwatch", "splunk", "datadog"]),
    ("Third-party integration", ["third-party", "partner", "vendor", "external api", "stripe", "twilio", "sendgrid"]),
]

_AI_SCOPED_COMPONENTS = {"LLM service", "RAG/vector store", "Tool/plugin layer"}

_AI_NEGATION_RE = re.compile(
    r"\b("
    r"no|without|not using|does not use|doesn't use|do not use|don't use|not in scope|out of scope|not present|absent"
    r")\s+("
    r"ai|llm|large language model|language model|model|gpt|claude|rag|retrieval|vector|embedding|agent|agentic|tool calling|function calling"
    r")\b"
    r"|\b("
    r"ai|llm|large language model|language model|rag|vector store|agent|agentic"
    r")\s+("
    r"is not used|are not used|not used|disabled|absent|not present|out of scope"
    r")\b",
    re.IGNORECASE,
)

_CLOUD_RULE_HINTS: dict[str, list[str]] = {
    "C01": ["s3", "blob", "bucket", "kubernetes", "container", "security group", "public", "orchestration"],
    "C02": ["lambda", "function", "container", "shell", "exec", "ssrf", "metadata", "169.254", "serverless"],
    "C03": ["iam", "role", "mfa", "service account", "identity", "authorization", "access key", "console"],
    "C04": ["ci/cd", "pipeline", "github actions", "jenkins", "image", "dependency", "supply chain", "build"],
    "C05": ["secret", "api key", "password", "certificate", "configmap", "vault", "kms", "environment variable"],
    "C06": ["iam", "administrator", "admin", "cluster-admin", "wildcard", "permission", "principal", "policy"],
    "C07": ["quota", "limit", "rate", "lambda", "api gateway", "autoscaling", "cost", "billing", "concurrency"],
    "C08": ["pii", "sensitive", "database", "rds", "snapshot", "s3", "storage", "logs", "encryption"],
    "C09": ["cloudtrail", "guardduty", "security hub", "monitoring", "alert", "flow logs", "siem", "audit"],
    "C10": ["incident", "backup", "restore", "forensic", "quarantine", "runbook", "disaster recovery", "rto", "rpo"],
}

_CIS_DOMAIN_HINTS: dict[str, list[str]] = {
    "D01": ["iam", "mfa", "role", "user", "access key", "identity", "sso", "principal"],
    "D02": ["cloudtrail", "audit", "logging", "monitoring", "config", "alarm", "siem"],
    "D03": ["vpc", "subnet", "security group", "firewall", "ssh", "rdp", "flow logs", "network"],
    "D04": ["s3", "bucket", "storage", "object", "versioning", "mfa delete", "lifecycle"],
    "D05": ["rds", "aurora", "dynamodb", "database", "snapshot", "backup", "postgres", "mysql"],
    "D06": ["ec2", "vm", "instance", "ami", "ebs", "ssm", "ssh", "imds"],
    "D07": ["kms", "key", "certificate", "cmk", "acm", "cryptography", "encryption"],
    "D08": ["ecr", "eks", "container", "lambda", "serverless", "kubernetes", "image"],
}

_CONTROL_POSITIVE_HINTS: dict[str, list[str]] = {
    "mfa": ["mfa", "multi-factor", "2fa", "hardware token"],
    "rotation": ["rotated", "rotation", "rotate every", "90 days"],
    "least privilege": ["least privilege", "least-privilege", "minimum permission", "deny by default"],
    "cloudtrail": ["cloudtrail enabled", "multi-region trail", "audit logging"],
    "encrypted": ["encrypted", "encryption at rest", "sse-kms", "kms", "cmk"],
    "not publicly": ["private subnet", "not publicly accessible", "block public access", "private endpoint"],
    "flow logs": ["flow logs enabled", "vpc flow logs"],
    "imdsv2": ["imdsv2", "http tokens required"],
    "versioning": ["versioning enabled", "object lock", "mfa delete"],
    "backup": ["backup enabled", "restore tested", "deletion protection", "multi-az"],
    "scanning": ["image scanning", "sast", "sca", "secret scanning", "checkov", "tfsec"],
}

_CONTROL_NEGATIVE_HINTS: dict[str, list[str]] = {
    "mfa": ["no mfa", "mfa disabled", "without mfa"],
    "rotation": ["no rotation", "never rotated", "long-lived key", "static key"],
    "least privilege": ["administratoraccess", "wildcard", "*:*", "cluster-admin", "over privileged"],
    "cloudtrail": ["cloudtrail disabled", "no cloudtrail", "no audit logging"],
    "encrypted": ["unencrypted", "no encryption", "plaintext", "cleartext"],
    "not publicly": ["publicly accessible", "public endpoint", "0.0.0.0/0", "open to internet"],
    "flow logs": ["flow logs disabled", "no flow logs"],
    "imdsv2": ["imdsv1", "imds optional", "http tokens optional"],
    "versioning": ["versioning disabled", "no versioning"],
    "backup": ["no backup", "backup disabled", "deletion protection disabled"],
    "scanning": ["no scanning", "not scanned", "pipeline does not scan"],
}


def _now_ms(start: float) -> int:
    return int((time.monotonic() - start) * 1000)


def _contains_any(text: str, signals: Iterable[str]) -> bool:
    lowered = text.lower()
    return any(signal.lower() in lowered for signal in signals)


def _ai_surface_applicable(architecture_text: str) -> bool:
    if _AI_NEGATION_RE.search(architecture_text or ""):
        return False
    return is_ai_analysis_applicable(detect_ai_architecture(architecture_text))


def _matched(text: str, signals: Iterable[str]) -> list[str]:
    lowered = text.lower()
    return [signal for signal in signals if signal.lower() in lowered]


def _risk_score(risk: str) -> int:
    return _SEV_SCORE.get(risk, 5)


def _effective_finding_risk(finding: dict) -> str:
    if finding.get("effective_risk"):
        return finding["effective_risk"]
    status = finding.get("status", "WARN")
    severity = finding.get("severity", "Info")
    if status == "PASS":
        return "Info"
    if status == "FAIL":
        return severity
    return {
        "Critical": "High",
        "High": "Medium",
        "Medium": "Low",
        "Low": "Low",
        "Info": "Info",
    }.get(severity, "Medium")


def _worst_risk(values: Iterable[str], default: str = "Info") -> str:
    best = default
    for value in values:
        if _SEV_RANK.get(value, 99) < _SEV_RANK.get(best, 99):
            best = value
    return best


def _overall_from_categories(categories: list[dict]) -> str:
    risks = [c.get("risk", "Info") for c in categories if c.get("risk") != "Info"]
    if not risks:
        return "Low"
    critical = risks.count("Critical")
    high = risks.count("High")
    if critical >= 2:
        return "Critical"
    if critical or high >= 4:
        return "High"
    if high or risks.count("Medium") >= 4:
        return "Medium"
    return "Low"


def _normalize_mitigations(items: Iterable) -> list[dict]:
    mitigations: list[dict] = []
    for item in items:
        if isinstance(item, dict):
            action = str(item.get("action", "")).strip()
            priority = str(item.get("priority", "Short-term")).strip() or "Short-term"
        else:
            action = str(item).strip()
            priority = "Short-term"
        if action and action not in [m["action"] for m in mitigations]:
            mitigations.append({"action": action, "priority": priority})
    return mitigations


def _category_display_name(category_id: str, fallback: str) -> str:
    name = (fallback or "").strip()
    if name and name != category_id:
        return name
    mapped = _CATEGORY_DISPLAY_NAMES.get(category_id)
    if mapped:
        return mapped
    tail = re.sub(r"^[A-Z]+-", "", category_id)
    tail = re.sub(r"^[A-Z]+", "", tail) if "_" not in tail else tail
    words = tail.replace("_", " ").replace("-", " ").strip()
    return words.title() if words else category_id


def extract_components(architecture_text: str) -> list[str]:
    components: list[str] = []
    ai_applicable = _ai_surface_applicable(architecture_text)
    for label, patterns in _COMPONENT_PATTERNS:
        if label in _AI_SCOPED_COMPONENTS and not ai_applicable:
            continue
        if _contains_any(architecture_text, patterns):
            components.append(label)
    if not components:
        components.append("Application")
    return components[:14]


def extract_data_flows(architecture_text: str) -> list[str]:
    lines = [line.strip(" -\t") for line in re.split(r"[\n.;]+", architecture_text) if line.strip()]
    flow_terms = ["->", " to ", " from ", " calls ", " sends ", " publishes ", "stores", "reads", "writes", "connects"]
    flows = [line for line in lines if any(term in line.lower() for term in flow_terms)]
    return flows[:10] or lines[:5]


def extract_trust_boundaries(architecture_text: str) -> list[str]:
    text = architecture_text.lower()
    ai_applicable = _ai_surface_applicable(architecture_text)
    boundaries: list[str] = []
    checks = [
        ("Internet to edge/API boundary", ["internet", "public", "browser", "external user", "cdn", "waf"]),
        ("Frontend to backend API boundary", ["frontend", "react", "spa", "api", "gateway"]),
        ("Service to data-store boundary", ["database", "postgres", "mysql", "rds", "s3", "bucket", "storage"]),
        ("Human/admin to privileged management boundary", ["admin", "management", "console", "operator"]),
        ("Cloud account/control-plane boundary", ["aws", "azure", "gcp", "iam", "cloudtrail", "kubernetes"]),
        ("Third-party integration boundary", ["third-party", "partner", "vendor", "external api", "webhook"]),
    ]
    if ai_applicable:
        checks.append(("AI context/tool boundary", ["llm", "rag", "agent", "tool", "plugin", "vector"]))
    for label, signals in checks:
        if any(signal in text for signal in signals):
            boundaries.append(label)
    return boundaries or ["Client to application boundary", "Application to data boundary"]


def _components_for_findings(architecture_text: str, findings: list[dict], fallback: list[str]) -> list[str]:
    matched_components = []
    evidence = " ".join(" ".join(f.get("triggered_patterns", [])) for f in findings)
    combined = f"{architecture_text} {evidence}"
    ai_applicable = _ai_surface_applicable(architecture_text)
    for label, patterns in _COMPONENT_PATTERNS:
        if label in _AI_SCOPED_COMPONENTS and not ai_applicable:
            continue
        if _contains_any(combined, patterns):
            matched_components.append(label)
    return matched_components[:8] or fallback[:4]


def _evaluate_rules(architecture_text: str, rules: list[dict], ruleset: str) -> list[dict]:
    findings: list[dict] = []
    for rule in rules:
        result = offline_rules._check_rule(architecture_text, rule, ruleset)
        result["ruleset"] = ruleset
        result["category"] = rule.get("category", "")
        findings.append(result)
    return findings


def _active_findings(findings: list[dict]) -> list[dict]:
    return [f for f in findings if f.get("status") != "PASS"]


def _risk_from_findings(findings: list[dict]) -> str:
    active = _active_findings(findings)
    if not active:
        return "Info"
    severities = [_effective_finding_risk(f) for f in active]
    worst = _worst_risk(severities)
    fail_count = sum(1 for f in active if f.get("status") == "FAIL")
    if fail_count and worst in ("Critical", "High"):
        return "Critical" if worst == "Critical" else "High"
    return worst


def _control_assessment(findings: list[dict]) -> list[dict]:
    return [
        {
            "rule_id": f.get("rule_id"),
            "status": f.get("status"),
            "severity": f.get("severity"),
            "effective_risk": _effective_finding_risk(f),
            "match_confidence": f.get("match_confidence", ""),
            "question": f.get("question"),
            "evidence": f.get("triggered_patterns", []),
            "description": f.get("description", ""),
            "attack_vector": f.get("attack_vector", ""),
            "impact": f.get("impact", ""),
            "control_objective": f.get("control_objective", ""),
            "evidence_to_collect": f.get("evidence_to_collect", []),
            "validation_steps": f.get("validation_steps", []),
            "recommended_tests": f.get("recommended_tests", []),
            "false_positive_guidance": f.get("false_positive_guidance", ""),
            "positive_control_examples": f.get("positive_control_examples", []),
            "implementation_guidance": f.get("implementation_guidance", []),
            "pattern_name": f.get("pattern_name", ""),
            "pattern_family": f.get("pattern_family", ""),
            "pattern_domain": f.get("pattern_domain", ""),
            "pattern_quality": f.get("pattern_quality", {}),
            "rationale": f.get("rationale", ""),
            "mitigations": f.get("mitigations", []),
            "references": f.get("references", []),
        }
        for f in findings
    ]


def _threats_from_findings(category_name: str, findings: list[dict]) -> list[dict]:
    threats: list[dict] = []
    for f in _active_findings(findings):
        evidence = f.get("triggered_patterns", [])
        threats.append({
            "name": f.get("pattern_name") or f.get("question", category_name),
            "description": f.get("description") or f.get("rationale", ""),
            "attack_vector": f.get("attack_vector") or (
                f"Architecture evidence: {', '.join(evidence[:6])}"
                if evidence else "Control gap requires design validation."
            ),
            "impact": f.get("impact") or _effective_finding_risk(f),
            "control_objective": f.get("control_objective", ""),
            "validation_steps": f.get("validation_steps", []),
            "recommended_tests": f.get("recommended_tests", []),
            "false_positive_guidance": f.get("false_positive_guidance", ""),
            "status": f.get("status", "WARN"),
            "rule_id": f.get("rule_id", ""),
        })
    return threats


def _recommendations_from_findings(findings: list[dict], limit: int = 10) -> list[str]:
    active = sorted(
        _active_findings(findings),
        key=lambda f: (_SEV_RANK.get(f.get("severity", "Info"), 99), f.get("rule_id", "")),
    )
    recommendations: list[str] = []
    for f in active:
        text = f"[{_effective_finding_risk(f)}] {f.get('question', '').strip()}"
        if text not in recommendations:
            recommendations.append(text)
        if len(recommendations) >= limit:
            break
    return recommendations


def _framework_summary(methodology: str, categories: list[dict], findings: list[dict]) -> str:
    active = _active_findings(findings)
    fail = sum(1 for f in active if f.get("status") == "FAIL")
    warn = sum(1 for f in active if f.get("status") == "WARN")
    high_plus = sum(1 for c in categories if c.get("risk") in ("Critical", "High"))
    return (
        f"{methodology} offline analysis evaluated the complete local framework: "
        f"{len(categories)} categories and {len(findings)} controls. "
        f"{fail} controls failed, {warn} require review, and {high_plus} categories are High or Critical risk."
    )


def _framework_report(
    *,
    title: str,
    architecture_text: str,
    methodology: str,
    entries: dict[str, dict],
    rules: list[dict],
    ruleset: str,
    extra: dict | None = None,
) -> dict:
    start = time.monotonic()
    findings = _evaluate_rules(architecture_text, rules, ruleset)
    by_category: dict[str, list[dict]] = defaultdict(list)
    for finding in findings:
        by_category[finding.get("category", "")].append(finding)

    components = extract_components(architecture_text)
    categories: list[dict] = []
    for key, entry in entries.items():
        category_findings = by_category.get(key, [])
        active = _active_findings(category_findings)
        risk = _risk_from_findings(category_findings)
        base_mitigations = []
        for finding in active:
            base_mitigations.extend(finding.get("mitigations", [])[:2])
        if not base_mitigations:
            base_mitigations.extend(entry.get("mitigations", [])[:4])

        examples = entry.get("common_examples") or entry.get("attack_scenarios") or []
        category_id = entry.get("id", key)
        categories.append({
            "id": category_id,
            "name": _category_display_name(category_id, entry.get("name", key)),
            "risk": risk,
            "risk_score": _risk_score(risk),
            "affected_components": _components_for_findings(architecture_text, active, components),
            "threats": _threats_from_findings(entry.get("name", key), category_findings),
            "mitigations": _normalize_mitigations(base_mitigations)[:8],
            "notes": (
                f"{len(category_findings)} local controls evaluated; "
                f"{len(active)} active finding(s). "
                f"Framework examples considered: {'; '.join(examples[:3])}"
            ),
            "control_assessment": _control_assessment(category_findings),
            "framework_description": entry.get("description", ""),
            "common_examples": examples,
        })

    recommendations = _recommendations_from_findings(findings)
    if not recommendations:
        for category in categories[:5]:
            for mitigation in category.get("mitigations", [])[:1]:
                recommendations.append(f"[{category['id']}] {mitigation['action']}")

    report = {
        "title": title,
        "methodology": methodology,
        "summary": _framework_summary(methodology, categories, findings),
        "overall_risk": _overall_from_categories(categories),
        "categories": categories,
        "recommendations": recommendations[:10],
        "offline_engine": {
            "mode": "full-framework",
            "ruleset": ruleset,
            "total_controls": len(findings),
            "active_findings": len(_active_findings(findings)),
            "trust_boundaries": extract_trust_boundaries(architecture_text),
            "data_flows": extract_data_flows(architecture_text),
        },
        "elapsed_ms": _now_ms(start),
    }
    if extra:
        report.update(extra)
    return report


def analyze_owasp(architecture_text: str, title: str = "Untitled") -> dict:
    return _framework_report(
        title=title,
        architecture_text=architecture_text,
        methodology="OWASP Top 10 2021",
        entries=OWASP_TOP10,
        rules=WEB_RULES,
        ruleset="web",
    )


def analyze_owasp_api(
    architecture_text: str,
    title: str = "Untitled",
    ai_detection: dict | None = None,
) -> dict:
    extra: dict = {"api_detection": detect_api_architecture(architecture_text)}
    if ai_detection and ai_detection.get("is_ai"):
        extra["agentic_api_surface"] = get_agentic_attack_surface(ai_detection, architecture_text)
    return _framework_report(
        title=title,
        architecture_text=architecture_text,
        methodology="OWASP API Security Top 10 2023",
        entries=OWASP_API_TOP10,
        rules=API_RULES,
        ruleset="api",
        extra=extra,
    )


def analyze_owasp_llm(
    architecture_text: str,
    title: str = "Untitled",
    ai_detection: dict | None = None,
) -> dict:
    detection = ai_detection or detect_ai_architecture(architecture_text)
    if not is_ai_analysis_applicable(detection):
        return _not_applicable_llm_report(title, detection)
    surface = get_agentic_attack_surface(detection, architecture_text)
    report = _framework_report(
        title=title,
        architecture_text=architecture_text,
        methodology="OWASP LLM Top 10 2025",
        entries=OWASP_LLM_TOP10,
        rules=AI_RULES,
        ruleset="ai",
        extra={
            "ai_components_detected": detection.get("matched_categories", []),
            "agentic_attack_surface": surface,
            "agentic_risks": {
                "excessive_agency": _agentic_risk_statement(architecture_text, ["agent", "tool", "delete", "write", "execute"]),
                "tool_abuse_surface": _agentic_risk_statement(architecture_text, ["tool", "plugin", "function call", "mcp", "connector"]),
                "prompt_injection_vectors": _prompt_vectors(architecture_text),
            },
        },
    )
    return report


def _not_applicable_llm_report(title: str, detection: dict) -> dict:
    return {
        "title": title,
        "methodology": "OWASP LLM Top 10 2025",
        "summary": (
            "OWASP LLM analysis was selected, but Yaksha Guard did not find concrete "
            "AI, LLM, RAG, model, embedding, or agent/tool-use evidence in the supplied architecture. "
            "No LLM findings were generated."
        ),
        "overall_risk": "Low",
        "categories": [],
        "recommendations": [
            "No LLM-specific action is required unless an AI/LLM, RAG, embedding, model inference, or agent/tool component is added to the architecture."
        ],
        "ai_components_detected": [],
        "agentic_attack_surface": {},
        "agentic_risks": {},
        "applicability": {
            "status": "not_applicable",
            "reason": "No concrete AI/LLM/RAG/agentic attack surface detected.",
            "detection": detection,
        },
        "offline_engine": {
            "mode": "llm-not-applicable-gate",
            "total_controls": 0,
            "active_findings": 0,
        },
        "elapsed_ms": 0,
    }


def _agentic_risk_statement(architecture_text: str, signals: list[str]) -> str:
    matches = _matched(architecture_text, signals)
    if matches:
        return f"Relevant because the architecture mentions: {', '.join(matches[:6])}."
    return "No explicit evidence in the architecture text; validate this during design review."


def _prompt_vectors(architecture_text: str) -> list[str]:
    vectors = []
    if _contains_any(architecture_text, ["rag", "retrieval", "vector", "document"]):
        vectors.append("Indirect prompt injection through retrieved documents or vector search results")
    if _contains_any(architecture_text, ["web", "url", "external", "third-party"]):
        vectors.append("External content injection through web, partner, or third-party inputs")
    if _contains_any(architecture_text, ["tool", "plugin", "mcp", "function call"]):
        vectors.append("Tool-output instruction injection before agent action selection")
    if _contains_any(architecture_text, ["user", "chat", "prompt", "message"]):
        vectors.append("Direct user prompt injection in conversational input")
    return vectors or ["Direct user input prompt injection"]


def _cloud_rules_from_owasp() -> list[dict]:
    rules: list[dict] = []
    for key, entry in OWASP_CLOUD_TOP10.items():
        hints = _CLOUD_RULE_HINTS.get(key, ["cloud"])
        severity = "Critical" if key in {"C01", "C03", "C05", "C06", "C08"} else "High"
        for idx, example in enumerate(entry.get("common_examples", []), start=1):
            rules.append({
                "id": f"CLD-{key}-{idx:02d}",
                "category": key,
                "question": f"{entry['name']}: {example}",
                "rationale": entry.get("description", ""),
                "severity": severity,
                "patterns_to_check": hints,
                "mitigations": entry.get("mitigations", []),
                "references": ["OWASP Cloud-Native Application Security Top 10"],
            })
    return rules


def analyze_owasp_cloud(architecture_text: str, title: str = "Untitled") -> dict:
    return _framework_report(
        title=title,
        architecture_text=architecture_text,
        methodology="OWASP Cloud-Native Top 10",
        entries=OWASP_CLOUD_TOP10,
        rules=_cloud_rules_from_owasp(),
        ruleset="cloud_native",
    )


def analyze_cis_cloud(architecture_text: str, title: str = "Untitled") -> dict:
    start = time.monotonic()
    cloud_context = _contains_any(
        architecture_text,
        ["aws", "azure", "gcp", "cloud", "s3", "rds", "iam", "kubernetes", "lambda", "vpc"],
    )
    components = extract_components(architecture_text)
    domains: list[dict] = []
    pass_count = warn_count = fail_count = 0

    for domain_key, domain in CIS_CLOUD_DOMAINS.items():
        hints = _CIS_DOMAIN_HINTS.get(domain_key, ["cloud"])
        domain_evidence = _matched(architecture_text, hints)
        applicable = cloud_context or bool(domain_evidence)
        findings = []
        for control in domain.get("key_controls", []):
            status, detail = _cis_control_status(architecture_text, control, applicable, domain_evidence)
            remediation = _cis_remediation(control)
            if status == "PASS":
                pass_count += 1
            elif status == "FAIL":
                fail_count += 1
            else:
                warn_count += 1
            findings.append({
                "control": control,
                "status": status,
                "detail": detail,
                "remediation": remediation,
            })

        active_statuses = [f["status"] for f in findings if f["status"] != "PASS"]
        risk = "Critical" if "FAIL" in active_statuses else ("Medium" if active_statuses else "Low")
        domains.append({
            "id": domain.get("id", domain_key),
            "name": domain.get("name", domain_key),
            "status": "FAIL" if any(f["status"] == "FAIL" for f in findings) else ("WARN" if active_statuses else "PASS"),
            "risk": risk,
            "risk_score": _risk_score(risk),
            "affected_components": components[:6],
            "findings": findings,
            "notes": (
                f"{domain.get('cis_level', 'CIS')} domain. "
                f"Evidence terms: {', '.join(domain_evidence[:6]) or 'none found in supplied architecture'}."
            ),
        })

    overall = "Critical" if fail_count >= 2 else ("High" if fail_count or warn_count >= 12 else ("Medium" if warn_count else "Low"))
    recommendations = [
        f"[{d['risk']}] {f['remediation']}"
        for d in domains
        for f in d["findings"]
        if f["status"] != "PASS"
    ][:10]

    return {
        "title": title,
        "methodology": "CIS Cloud Benchmark",
        "summary": (
            f"CIS Cloud Benchmark offline assessment evaluated {sum(len(d['findings']) for d in domains)} controls "
            f"across {len(domains)} domains. {fail_count} failed, {warn_count} need evidence, and {pass_count} "
            f"have explicit supporting evidence in the architecture text."
        ),
        "overall_risk": overall,
        "domains": domains,
        "pass_count": pass_count,
        "warn_count": warn_count,
        "fail_count": fail_count,
        "recommendations": recommendations,
        "offline_engine": {
            "mode": "full-cis-benchmark",
            "total_controls": sum(len(d["findings"]) for d in domains),
            "trust_boundaries": extract_trust_boundaries(architecture_text),
        },
        "elapsed_ms": _now_ms(start),
    }


def _cis_control_status(
    architecture_text: str,
    control: str,
    applicable: bool,
    domain_evidence: list[str],
) -> tuple[str, str]:
    text = architecture_text.lower()
    control_lower = control.lower()
    positive = []
    negative = []
    for key, hints in _CONTROL_POSITIVE_HINTS.items():
        if key in control_lower:
            positive.extend(_matched(architecture_text, hints))
    for key, hints in _CONTROL_NEGATIVE_HINTS.items():
        if key in control_lower:
            negative.extend(_matched(architecture_text, hints))
    if negative:
        return "FAIL", f"Contradictory or unsafe evidence found: {', '.join(negative[:5])}."
    if positive:
        return "PASS", f"Supporting evidence found: {', '.join(positive[:5])}."
    direct_terms = [word for word in re.findall(r"[a-z0-9]{4,}", control_lower) if word in text]
    if len(direct_terms) >= 2:
        return "WARN", f"Control appears relevant from terms {', '.join(direct_terms[:5])}, but compliance evidence is incomplete."
    if applicable:
        return "WARN", (
            "Architecture is in scope for this domain but does not state whether this control is implemented."
        )
    return "WARN", "No cloud-control evidence was supplied; validate this control during architecture intake."


def _cis_remediation(control: str) -> str:
    lower = control.lower()
    if "mfa" in lower:
        return "Enforce MFA for all human and root/break-glass identities."
    if "public" in lower or "0.0.0.0/0" in lower:
        return "Remove public exposure and require private networking or explicit allowlists."
    if "encrypt" in lower or "kms" in lower:
        return "Enable KMS-backed encryption and key rotation for the covered service."
    if "cloudtrail" in lower or "logs" in lower or "alarm" in lower:
        return "Enable centralized audit logging, integrity protection, and alerting."
    if "backup" in lower or "versioning" in lower:
        return "Enable recoverability controls and test restore procedures."
    if "iam" in lower or "policies" in lower or "access" in lower:
        return "Apply least privilege, remove wildcard permissions, and review external access."
    return f"Implement and document CIS control: {control}"


_STRIDE_FIELDS = {
    "S": "spoofing",
    "T": "tampering",
    "R": "repudiation",
    "I": "information_disclosure",
    "D": "denial_of_service",
    "E": "elevation_of_privilege",
}

_STRIDE_SIGNALS = {
    "S": ["auth", "sso", "jwt", "token", "login", "identity", "service account", "api", "admin"],
    "T": ["database", "queue", "storage", "webhook", "api", "pipeline", "terraform", "config"],
    "R": ["admin", "payment", "transfer", "audit", "logging", "transaction", "change"],
    "I": ["database", "s3", "storage", "pii", "secret", "logs", "vector", "rag", "private"],
    "D": ["public", "internet", "api", "upload", "llm", "queue", "rate", "traffic", "cdn"],
    "E": ["admin", "iam", "role", "permission", "kubernetes", "service account", "management"],
}

_STRIDE_OWASP = {
    "S": ["OWASP A07 Identification and Authentication Failures", "OWASP API2 Broken Authentication"],
    "T": ["OWASP A03 Injection", "OWASP A08 Software and Data Integrity Failures", "OWASP API5 Broken Function Level Authorization"],
    "R": ["OWASP A09 Security Logging and Monitoring Failures"],
    "I": ["OWASP A02 Cryptographic Failures", "OWASP API3 Broken Object Property Level Authorization"],
    "D": ["OWASP API4 Unrestricted Resource Consumption", "OWASP LLM04 Model Denial of Service"],
    "E": ["OWASP A01 Broken Access Control", "OWASP API1 Broken Object Level Authorization", "OWASP API5 Broken Function Level Authorization"],
}

_STRIDE_IMPACT = {
    "S": "Unauthorized actors can impersonate legitimate users or services, causing account takeover, service misuse, and loss of trust in identity decisions.",
    "T": "Attackers can alter requests, records, configuration, or pipeline artifacts, causing business logic abuse and corrupted system state.",
    "R": "Actors can deny sensitive actions or hide misuse because the system lacks tamper-evident proof of who did what and when.",
    "I": "Sensitive data, secrets, prompts, logs, or tenant records can be disclosed outside the intended authorization boundary.",
    "D": "Attackers can exhaust compute, storage, queue depth, database connections, API quotas, or LLM token budgets and degrade availability.",
    "E": "A low-privilege actor can gain higher privilege or broader tenant/resource access than intended by the design.",
}

_STRIDE_CONTROL_OBJECTIVES = {
    "S": "Every caller must be strongly authenticated, tokens must be validated server-side, and service identity must be cryptographically bound to the channel.",
    "T": "Every state-changing path must enforce integrity controls: input validation, signed artifacts, parameterized data access, and immutable deployment practices.",
    "R": "Every high-value action must produce centralized, append-only, tamper-evident audit evidence tied to an authenticated actor.",
    "I": "Every sensitive data flow must have explicit authorization, minimization, encryption, and production-safe error/log handling.",
    "D": "Every public or costly operation must have rate, quota, timeout, circuit-breaker, and abuse-monitoring controls.",
    "E": "Every privileged function and object access must be authorized server-side with least privilege and deny-by-default policy.",
}

_STRIDE_VALIDATION = {
    "S": [
        "Can a request with a forged, expired, wrong-audience, or algorithm-confused token reach this component?",
        "Are service-to-service calls authenticated independently of network location?",
        "Are session, refresh-token, and service-account lifetimes bounded and rotated?",
    ],
    "T": [
        "Can an attacker modify request parameters, queue messages, storage objects, or deployment configuration without detection?",
        "Are state-changing APIs protected by schema validation and authorization checks before mutation?",
        "Are build artifacts, IaC plans, and container images signed or otherwise integrity-verified?",
    ],
    "R": [
        "Is every privileged or business-critical action logged with actor, target, parameters, result, timestamp, and correlation ID?",
        "Can application administrators alter or delete audit records from the app tier?",
        "Are failed authorization attempts and security-relevant changes alertable?",
    ],
    "I": [
        "Does the component return only explicitly allowed fields for the caller and tenant?",
        "Are secrets, PII, prompts, documents, and logs excluded from error responses and telemetry leaks?",
        "Are data stores, backups, and inter-service traffic encrypted with managed key ownership?",
    ],
    "D": [
        "Can anonymous or low-cost callers trigger expensive database, queue, file, or model operations?",
        "Are per-user, per-tenant, and per-IP quotas enforced before work is allocated?",
        "Do timeouts, request-size limits, and circuit breakers protect downstream dependencies?",
    ],
    "E": [
        "Can a lower-privileged caller invoke admin functions directly or by changing object, tenant, role, or path parameters?",
        "Are object-level authorization checks performed on read, write, export, batch, and delete flows?",
        "Can service accounts or cloud roles perform actions beyond the component's documented need?",
    ],
}

_STRIDE_TESTS = {
    "S": ["Token tampering test", "Expired-token replay test", "Service identity negative test"],
    "T": ["Parameter tampering test", "Unsigned artifact/config change test", "Mutation authorization test"],
    "R": ["Audit completeness test", "Log tamper-resistance test", "Correlation-ID trace test"],
    "I": ["Excessive response field test", "Cross-tenant data access test", "Secret/log leakage test"],
    "D": ["Rate-limit bypass test", "Large payload and long query test", "Downstream timeout/circuit-breaker test"],
    "E": ["BOLA/IDOR test", "Admin endpoint direct-call test", "Privilege-bearing parameter test"],
}

_STRIDE_ATTACK_PATHS = {
    "S": [
        "Obtain, forge, replay, or confuse an identity token, session, credential, service account, or workload identity.",
        "Present that identity across the relevant trust boundary before strict issuer, audience, expiry, signature, and channel binding checks are enforced.",
        "Use the accepted identity to invoke downstream functions, read protected data, or perform actions as the impersonated principal.",
    ],
    "T": [
        "Find a mutable input, object, queue message, webhook payload, database write path, deployment artifact, or configuration item.",
        "Modify the value before the owning component validates schema, authorization, integrity, or provenance.",
        "Persist or forward the altered state so business logic, downstream systems, or audit evidence now reflect attacker-controlled data.",
    ],
    "R": [
        "Perform a privileged, financial, destructive, or security-relevant action through the component.",
        "Exploit missing, incomplete, mutable, or poorly correlated audit records to break attribution.",
        "Deny the action or remove evidence during investigation because actor, target, result, and timestamp are not tamper-evident.",
    ],
    "I": [
        "Reach a data-returning path, error path, log stream, export, backup, retrieval context, or storage object.",
        "Bypass or confuse tenant, object, field, or secret filtering before data leaves the component boundary.",
        "Exfiltrate sensitive records, credentials, system internals, prompts, or operational metadata to an unauthorized actor.",
    ],
    "D": [
        "Send high-volume, high-cardinality, large-payload, recursive, or expensive requests to a public or costly operation.",
        "Force allocation of backend, database, queue, file, cache, third-party, or model resources before quota and timeout controls reject the work.",
        "Degrade availability, exhaust provider quota, increase cost, or trigger cascading failure in dependent services.",
    ],
    "E": [
        "Start with a normal user, tenant, service, or low-privilege role.",
        "Change object IDs, tenant IDs, route paths, role claims, tool parameters, service-account context, or admin-only fields.",
        "Execute a function or access an object that should require a stronger authorization decision at the owning service.",
    ],
}

_STRIDE_EVIDENCE_TO_COLLECT = {
    "S": ["Token validation code/configuration", "Session lifetime and refresh-token policy", "Service identity and mTLS/workload identity evidence", "Failed-authentication and token-replay logs"],
    "T": ["Input schemas and mutation handlers", "Authorization checks before state changes", "Database migration and write-role policy", "Artifact/signature/provenance controls"],
    "R": ["Audit event schema", "Central log shipping configuration", "Correlation-ID propagation", "Log retention and tamper-resistance evidence"],
    "I": ["Data classification and field inventory", "Response allowlists and serializer rules", "Tenant/object authorization tests", "Secret redaction and error-handling policy"],
    "D": ["Rate-limit and quota configuration", "Payload, timeout, and concurrency limits", "Expensive query/model/file operation cost controls", "Alert thresholds and autoscaling runbooks"],
    "E": ["Role and permission matrix", "Object/function-level authorization tests", "Admin route inventory", "Service-account and cloud role permissions"],
}

_STRIDE_DETECTION = {
    "S": ["Alert on token validation failures, replay attempts, impossible travel, and service-identity mismatches.", "Correlate authentication decisions with downstream authorization denials."],
    "T": ["Alert on schema validation failures, unexpected privileged fields, webhook signature failures, migration drift, and integrity-check mismatches.", "Compare mutation volume and sensitive-field changes against normal baselines."],
    "R": ["Alert when high-value actions lack correlation IDs or when audit-log delivery, retention, or integrity checks fail.", "Monitor attempts to disable logging or delete audit records."],
    "I": ["Alert on unusual export volume, cross-tenant access attempts, sensitive fields in responses/logs, and repeated error probing.", "Sample production telemetry for accidental secret or PII leakage."],
    "D": ["Alert on quota exhaustion, high error rates, slow downstream dependencies, large payloads, high-cardinality requests, and queue-depth spikes.", "Track cost and provider quota burn by user, tenant, route, and source."],
    "E": ["Alert on denied admin calls, privilege-bearing parameter changes, role assignment changes, service-account misuse, and cross-tenant object access.", "Review all privilege changes with actor, approver, before/after state, and justification."],
}

_ACTIVE_STRIDE_RISKS = {"Critical", "High", "Medium"}

_STRIDE_RANK = {
    "Critical": 0,
    "High": 1,
    "Medium": 2,
    "Needs Validation": 3,
    "Low": 4,
    "None": 5,
    "Info": 6,
}

_COMPONENT_STRIDE_APPLICABILITY: dict[str, dict[str, str]] = {
    "Web frontend": {
        "S": "Needs Validation",
        "T": "Needs Validation",
        "R": "Low",
        "I": "Needs Validation",
        "D": "Low",
        "E": "Low",
    },
    "Mobile client": {
        "S": "Medium",
        "T": "Needs Validation",
        "R": "Low",
        "I": "Medium",
        "D": "Low",
        "E": "Needs Validation",
    },
    "API gateway": {
        "S": "Medium",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Medium",
        "E": "Medium",
    },
    "Public API": {
        "S": "Medium",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Medium",
        "E": "Medium",
    },
    "Authentication service": {
        "S": "High",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Medium",
        "E": "High",
    },
    "Admin portal": {
        "S": "High",
        "T": "Medium",
        "R": "High",
        "I": "Medium",
        "D": "Needs Validation",
        "E": "High",
    },
    "Application service": {
        "S": "Needs Validation",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Needs Validation",
        "E": "Medium",
    },
    "Database": {
        "S": "None",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Needs Validation",
        "E": "Medium",
    },
    "Object storage": {
        "S": "Needs Validation",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Needs Validation",
        "E": "Medium",
    },
    "Message queue": {
        "S": "Needs Validation",
        "T": "Medium",
        "R": "Medium",
        "I": "Needs Validation",
        "D": "Medium",
        "E": "Medium",
    },
    "Cache": {
        "S": "None",
        "T": "Needs Validation",
        "R": "Low",
        "I": "Medium",
        "D": "Medium",
        "E": "Needs Validation",
    },
    "LLM service": {
        "S": "Needs Validation",
        "T": "High",
        "R": "Medium",
        "I": "High",
        "D": "Medium",
        "E": "Medium",
    },
    "RAG/vector store": {
        "S": "Needs Validation",
        "T": "High",
        "R": "Medium",
        "I": "High",
        "D": "Medium",
        "E": "Medium",
    },
    "Tool/plugin layer": {
        "S": "Medium",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Needs Validation",
        "E": "High",
    },
    "CI/CD pipeline": {
        "S": "Medium",
        "T": "High",
        "R": "Medium",
        "I": "Medium",
        "D": "Low",
        "E": "High",
    },
    "Cloud control plane": {
        "S": "High",
        "T": "Medium",
        "R": "High",
        "I": "Medium",
        "D": "Medium",
        "E": "High",
    },
    "Kubernetes cluster": {
        "S": "Medium",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Medium",
        "E": "High",
    },
    "CDN/load balancer": {
        "S": "Low",
        "T": "Needs Validation",
        "R": "Low",
        "I": "Needs Validation",
        "D": "Medium",
        "E": "Low",
    },
    "Secrets manager": {
        "S": "High",
        "T": "Medium",
        "R": "High",
        "I": "High",
        "D": "Needs Validation",
        "E": "High",
    },
    "Monitoring/SIEM": {
        "S": "Medium",
        "T": "Medium",
        "R": "High",
        "I": "Medium",
        "D": "Low",
        "E": "Medium",
    },
    "Third-party integration": {
        "S": "Medium",
        "T": "Medium",
        "R": "Medium",
        "I": "Medium",
        "D": "Needs Validation",
        "E": "Needs Validation",
    },
}

_STRIDE_NEGATIVE_SIGNALS = {
    "S": ["no authentication", "no auth", "unauthenticated", "weak jwt", "jwt not validated", "missing token validation", "anonymous"],
    "T": ["no validation", "unsanitized", "string concatenation", "unsigned", "no integrity", "no authorization", "public write"],
    "R": ["no logging", "logs disabled", "no audit", "audit disabled", "mutable logs", "delete logs"],
    "I": ["unencrypted", "plaintext", "public bucket", "exposed secret", "sensitive logs", "verbose error", "no access control"],
    "D": ["no rate limit", "rate limiting disabled", "unlimited requests", "no quota", "no timeout", "unbounded", "expensive query"],
    "E": ["no authorization", "no access control", "admin without approval", "wildcard permission", "cluster-admin", "default admin"],
}

_STRIDE_POSITIVE_CONTROLS = {
    "S": ["mfa", "oidc", "oauth", "jwt validation", "issuer audience", "mtls", "service identity", "token rotation"],
    "T": ["parameterized", "schema validation", "signed", "integrity", "immutable", "migration approval", "constraints"],
    "R": ["audit logging", "audit logs", "centralized logging", "siem", "append-only", "correlation id", "tamper-evident"],
    "I": ["response filtering", "field-level authorization", "data minimization", "redaction", "kms", "encryption", "private bucket"],
    "D": ["rate limiting", "quota", "waf", "cdn", "timeout", "circuit breaker", "payload limit", "autoscaling"],
    "E": ["rbac", "abac", "least privilege", "object-level authorization", "deny by default", "permission checks", "policy engine"],
}

_COMPONENT_STRIDE_MITIGATIONS = {
    ("Web frontend", "S"): ["Keep authentication decisions on the server or identity provider; do not treat client-side state as proof of identity.", "Use secure, HttpOnly, SameSite cookies or hardened token storage for browser sessions."],
    ("Web frontend", "T"): ["Treat all browser input as untrusted and revalidate on the API boundary.", "Protect build artifacts with integrity checks and deploy immutable static assets through the CDN."],
    ("Web frontend", "I"): ["Avoid storing sensitive tokens in localStorage; minimize client-side PII and apply CSP plus output encoding.", "Keep detailed errors and secrets out of bundled frontend code."],
    ("Web frontend", "D"): ["Use CDN caching and WAF/bot controls for public traffic; enforce expensive-operation limits at the API, not the browser."],

    ("API gateway", "S"): ["Validate JWT issuer, audience, expiry, signature, and algorithm before routing requests.", "Use mTLS or workload identity for service-to-service calls behind the gateway."],
    ("API gateway", "T"): ["Enforce request schemas, method allowlists, and canonicalization before forwarding to internal services.", "Reject unexpected headers and privilege-bearing parameters at the edge."],
    ("API gateway", "R"): ["Log authentication, authorization, routing decision, caller, target service, and correlation ID to centralized audit storage."],
    ("API gateway", "I"): ["Apply response filtering, secure headers, and error normalization at the gateway.", "Avoid forwarding secrets, internal hostnames, or stack traces to clients."],
    ("API gateway", "D"): ["Enforce per-IP, per-user, per-tenant, and per-client quotas before work reaches backend services.", "Set payload size, connection, timeout, and route-specific cost limits."],
    ("API gateway", "E"): ["Centralize coarse-grained authorization at the gateway and require service-level object authorization downstream.", "Deny privileged routes by default unless an explicit permission policy matches."],

    ("Public API", "S"): ["Validate access tokens on every request and reject expired, wrong-audience, unsigned, or algorithm-confused tokens."],
    ("Public API", "T"): ["Use schema validation and parameterized data access on every mutation path.", "Reject overposted fields and server-managed attributes."],
    ("Public API", "R"): ["Record high-value reads, writes, deletes, exports, and failed authorization attempts with correlation IDs."],
    ("Public API", "I"): ["Use field allowlists and tenant-aware response filtering for every API response.", "Classify sensitive fields and prevent them from appearing in logs or errors."],
    ("Public API", "D"): ["Apply quota and rate limits before allocating database, queue, file, or model resources."],
    ("Public API", "E"): ["Enforce object-level and function-level authorization on every read, write, export, batch, and delete action."],

    ("Authentication service", "S"): ["Use phishing-resistant MFA for privileged users and strict OIDC/JWT validation for all tokens.", "Rotate signing keys and support immediate token revocation."],
    ("Authentication service", "E"): ["Protect role, group, and claim assignment with admin approval, audit logging, and least privilege.", "Separate authentication from authorization policy decisions."],
    ("Authentication service", "I"): ["Never log credentials, reset tokens, refresh tokens, or secrets; redact identity provider claims where not needed."],

    ("Database", "T"): ["Use parameterized queries, stored procedures where appropriate, and schema constraints for all data mutations.", "Restrict write paths with RBAC, signed/reviewed migrations, and immutable audit logs."],
    ("Database", "R"): ["Capture audit records for privileged queries, migrations, schema changes, bulk export, and delete operations."],
    ("Database", "I"): ["Use least-privilege database roles, row/tenant-level security, field-level access controls, and query-result minimization.", "Use encryption at rest as a recovery and theft control, not as the primary runtime disclosure control."],
    ("Database", "D"): ["Set connection pool limits, query timeouts, index review, and expensive-query controls."],
    ("Database", "E"): ["Separate application, migration, read-only, and admin roles; prohibit shared superuser credentials."],

    ("Object storage", "T"): ["Use signed upload policies, object versioning, malware scanning, and immutable retention for sensitive objects."],
    ("Object storage", "I"): ["Block public access by default and serve objects through authorization-checked signed URLs."],
    ("Object storage", "E"): ["Scope storage identities by bucket, prefix, and action; separate read, write, and admin roles."],

    ("LLM service", "T"): ["Separate system instructions from user, retrieved, and tool content; scan direct and indirect prompt injection before context assembly.", "Use structured tool/result schemas so untrusted text cannot become control instructions."],
    ("LLM service", "R"): ["Log model prompts, retrieval IDs, tool decisions, policy denials, and human approvals with sensitive-data redaction."],
    ("LLM service", "I"): ["Redact secrets and PII before model calls; isolate tenant context and prevent system prompt or memory disclosure.", "Filter outputs for sensitive data before returning responses or storing transcripts."],
    ("LLM service", "D"): ["Enforce token, context-size, concurrency, recursion, and cost quotas per user and tenant.", "Set agent step limits and stop conditions to prevent token exhaustion loops."],
    ("LLM service", "E"): ["Run tools with scoped credentials and require human approval for write, delete, external-send, or deployment actions."],

    ("RAG/vector store", "T"): ["Authenticate ingestion, track document provenance, scan retrieved content for prompt injection, and isolate tenant corpora.", "Use approval workflows for high-trust knowledge-base updates."],
    ("RAG/vector store", "I"): ["Enforce tenant-aware retrieval filters and prevent cross-tenant embeddings, snippets, or metadata from entering model context."],
    ("RAG/vector store", "D"): ["Limit retrieval fan-out, query complexity, and embedding/search costs per tenant."],

    ("Tool/plugin layer", "S"): ["Authenticate tool callers and bind tool execution to a model session, user, tenant, and approval state."],
    ("Tool/plugin layer", "T"): ["Validate tool arguments with strict schemas and reject free-text instructions embedded in tool results."],
    ("Tool/plugin layer", "R"): ["Audit every tool invocation, arguments, approval, result, and side effect."],
    ("Tool/plugin layer", "I"): ["Prevent tools from returning secrets or broad data unless explicitly authorized for the user and task."],
    ("Tool/plugin layer", "E"): ["Default tools to read-only; scope credentials per tool and require human approval for irreversible actions."],

    ("CI/CD pipeline", "T"): ["Require protected branches, two-person review, signed artifacts, SBOM/SCA gates, and provenance verification before deploy."],
    ("CI/CD pipeline", "E"): ["Use OIDC federation and least-privilege deployment roles instead of standing production secrets."],
    ("CI/CD pipeline", "R"): ["Keep immutable build and deployment logs tied to commit, actor, artifact digest, and environment."],

    ("Cloud control plane", "S"): ["Enforce SSO/MFA, short-lived federation, and conditional access for all human cloud administrators."],
    ("Cloud control plane", "R"): ["Enable organization-wide audit logging and alert on identity, network, storage, and policy changes."],
    ("Cloud control plane", "E"): ["Remove wildcard/admin policies, use permission boundaries, and review role trust relationships."],

    ("Third-party integration", "S"): ["Authenticate webhooks with signatures or mTLS and rotate partner credentials."],
    ("Third-party integration", "T"): ["Validate partner payload schemas and use idempotency plus replay protection."],
    ("Third-party integration", "I"): ["Minimize shared data and contractually define data classification, retention, and logging expectations."],
}

_LLM_STRIDE_SPECIAL_CASES = {
    ("LLM service", "T"): {
        "name": "Prompt Injection and Context Tampering",
        "attack": "An attacker places instructions in user prompts, retrieved documents, or tool outputs to override system intent or alter downstream agent behavior.",
        "validation": "Can direct and indirect prompt-injection payloads change tool selection, system constraints, or data-access decisions?",
    },
    ("LLM service", "I"): {
        "name": "Context Leakage and Data Exfiltration",
        "attack": "An attacker elicits secrets, tenant context, system prompts, memory, or retrieved documents through model output.",
        "validation": "Can prompts cause disclosure of system instructions, memory, retrieved tenant data, secrets, or logs?",
    },
    ("LLM service", "D"): {
        "name": "Model Denial via Token or Agent Loops",
        "attack": "An attacker submits large prompts, recursive tasks, or tool loops that exhaust token budget, queue capacity, or provider quota.",
        "validation": "Are token, recursion, context-size, concurrency, and provider-cost limits enforced before model work is allocated?",
    },
    ("LLM service", "E"): {
        "name": "Unsafe Agent Action or Tool Privilege Abuse",
        "attack": "An attacker manipulates the model into invoking tools with excessive permissions or performing write/delete/external-send actions.",
        "validation": "Can a low-privilege user cause the agent to perform privileged or irreversible tool actions without approval?",
    },
    ("RAG/vector store", "T"): {
        "name": "Indirect Prompt Injection Through Retrieval",
        "attack": "An attacker poisons documents or embeddings so retrieved content carries instructions into model context.",
        "validation": "Are ingestion sources authenticated, provenance tracked, tenant scoped, and scanned before retrieval content enters context?",
    },
    ("RAG/vector store", "I"): {
        "name": "Cross-Tenant Retrieval Leakage",
        "attack": "An attacker queries the vector store to retrieve another tenant's documents, snippets, embeddings, or metadata.",
        "validation": "Are retrieval filters enforced by tenant and authorization policy before context assembly?",
    },
    ("Tool/plugin layer", "E"): {
        "name": "Tool Abuse Through Excessive Agency",
        "attack": "An attacker uses prompts or malicious tool results to make the agent call privileged tools outside intended workflow scope.",
        "validation": "Are tools allowlisted, least-privilege scoped, argument validated, audited, and gated by human approval for high-impact actions?",
    },
}


def _dedupe_text(items: Iterable[str], limit: int | None = None) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        text = str(item).strip()
        if not text:
            continue
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(text)
        if limit is not None and len(result) >= limit:
            break
    return result


def _risk_sort_key(risk: str) -> int:
    return _STRIDE_RANK.get(risk, 99)


def _component_terms(component: str) -> list[str]:
    for label, terms in _COMPONENT_PATTERNS:
        if label == component:
            return [label.lower(), *terms]
    return [component.lower()]


def _sentences(text: str) -> list[str]:
    return [part.strip(" -\t\r\n") for part in re.split(r"(?<=[.!?])\s+|[\n;]+", text) if part.strip()]


def _component_evidence(architecture_text: str, component: str) -> list[str]:
    terms = _component_terms(component)
    snippets = [
        sentence
        for sentence in _sentences(architecture_text)
        if _contains_any(sentence, terms)
    ]
    return _dedupe_text(snippets, 4)


def _local_text(architecture_text: str, component: str) -> str:
    snippets = _component_evidence(architecture_text, component)
    if snippets:
        return " ".join(snippets).lower()
    return architecture_text.lower()


def extract_trust_boundary_map(architecture_text: str) -> list[dict]:
    """Return structured trust boundaries inferred from concrete architecture terms."""
    text = architecture_text.lower()
    ai_applicable = _ai_surface_applicable(architecture_text)
    boundaries: list[dict] = []

    def add(source: str, target: str, boundary: str, reason_terms: list[str], flows: list[str] | None = None) -> None:
        if any(term in text for term in reason_terms):
            boundaries.append({
                "source": source,
                "target": target,
                "boundary": boundary,
                "reason": ", ".join([term for term in reason_terms if term in text][:6]),
                "data_flows": flows or [],
            })

    add("Internet users", "Web frontend / CDN", "Internet to frontend edge", ["internet", "public", "browser", "frontend", "react", "spa", "cdn"])
    add("Web or mobile client", "API gateway / Public API", "Client to API trust boundary", ["frontend", "mobile", "api gateway", "rest api", "graphql", "endpoint"])
    add("API gateway", "Internal application services", "Gateway to internal service boundary", ["api gateway", "backend", "service", "microservice", "internal api"])
    add("Application services", "Database / object storage", "Service to data-store boundary", ["database", "postgres", "mysql", "rds", "s3", "bucket", "storage"])
    if ai_applicable:
        add("Application or orchestration layer", "LLM service", "Application to model boundary", ["llm", "model", "gpt", "claude", "inference", "agent"])
        add("LLM service", "RAG / vector store", "Model context to retrieval boundary", ["rag", "retrieval", "vector", "embedding", "document"])
        add("LLM service", "Tools / plugins", "Model to tool-action boundary", ["tool", "plugin", "function call", "mcp", "connector", "agent action"])
    add("Internal system", "Third-party provider", "System to external dependency boundary", ["third-party", "partner", "vendor", "external api", "webhook"])
    add("CI/CD pipeline", "Production runtime", "Build to production boundary", ["ci/cd", "pipeline", "github actions", "jenkins", "gitlab", "deploy"])

    flows = extract_data_flows(architecture_text)
    for boundary in boundaries:
        src = boundary["source"].lower().split(" / ")[0]
        target_words = [part.strip().lower() for part in re.split(r"[/ ]+", boundary["target"]) if len(part.strip()) > 3]
        boundary["data_flows"] = [
            flow for flow in flows
            if src in flow.lower() or any(word in flow.lower() for word in target_words)
        ][:3]
    return boundaries


def _boundary_for_component(component: str, boundary_map: list[dict]) -> dict | None:
    component_lower = component.lower()
    for boundary in boundary_map:
        haystack = f"{boundary.get('source', '')} {boundary.get('target', '')} {boundary.get('boundary', '')}".lower()
        if any(term in haystack for term in _component_terms(component)) or any(part in haystack for part in component_lower.split()):
            return boundary
    return None


def _matched_controls(text_lower: str, stride_key: str) -> list[str]:
    return [control for control in _STRIDE_POSITIVE_CONTROLS[stride_key] if control in text_lower]


def _matched_negative_signals(text_lower: str, stride_key: str) -> list[str]:
    return [signal for signal in _STRIDE_NEGATIVE_SIGNALS[stride_key] if signal in text_lower]


def _filter_component_negative_signals(component: str, stride_key: str, signals: list[str]) -> list[str]:
    filtered: list[str] = []
    for signal in signals:
        if signal in {"no rate limit", "rate limiting disabled", "unlimited requests", "no quota"}:
            if component not in {"API gateway", "Public API", "LLM service", "RAG/vector store", "CDN/load balancer"}:
                continue
        if signal in {"no validation", "unsanitized"}:
            if component not in {"API gateway", "Public API", "Application service", "LLM service", "RAG/vector store", "Tool/plugin layer"}:
                continue
        if signal in {"string concatenation"} and component not in {"Application service", "Public API", "Database"}:
            continue
        filtered.append(signal)
    return _dedupe_text(filtered)


def _risk_raise(risk: str) -> str:
    if risk in ("None", "Info"):
        return "Needs Validation"
    if risk == "Low":
        return "Medium"
    if risk == "Needs Validation":
        return "Medium"
    if risk == "Medium":
        return "High"
    if risk == "High":
        return "High"
    return risk


def _risk_lower(risk: str) -> str:
    if risk == "Critical":
        return "High"
    if risk == "High":
        return "Medium"
    if risk == "Medium":
        return "Needs Validation"
    if risk == "Needs Validation":
        return "Low"
    return risk


def _stride_profile(component: str, stride_key: str, architecture_text: str, boundary_map: list[dict]) -> dict:
    definition = STRIDE[stride_key]
    applicability = _COMPONENT_STRIDE_APPLICABILITY.get(component, {})
    base_risk = applicability.get(stride_key, "Needs Validation")
    local_text = _local_text(architecture_text, component)
    global_text = architecture_text.lower()
    negative = _matched_negative_signals(local_text, stride_key)
    global_negative = _matched_negative_signals(global_text, stride_key)
    if component in {"API gateway", "Public API", "LLM service", "RAG/vector store", "Tool/plugin layer"}:
        negative = _dedupe_text([*negative, *global_negative])
    negative = _filter_component_negative_signals(component, stride_key, negative)
    controls = _matched_controls(f"{local_text} {global_text}", stride_key)
    component_evidence = _component_evidence(architecture_text, component)
    boundary = _boundary_for_component(component, boundary_map)
    boundary_text = boundary.get("boundary", "") if boundary else ""
    confidence = "weak"

    risk = base_risk
    if base_risk == "None":
        risk = "None"
    elif negative:
        risk = _risk_raise(base_risk)
        if (
            stride_key in {"S", "E", "I"}
            and any(signal in negative for signal in ["no authorization", "no access control", "unauthenticated", "exposed secret"])
            and base_risk == "High"
        ):
            risk = "Critical"
        confidence = "high"
    elif component_evidence and base_risk in _ACTIVE_STRIDE_RISKS:
        confidence = "medium"
    elif component_evidence:
        confidence = "needs_validation"

    if controls and not negative and risk in _ACTIVE_STRIDE_RISKS:
        risk = _risk_lower(risk)
        confidence = "positive_control_present"

    if component == "Web frontend" and stride_key == "D":
        risk = "Low"
        confidence = "weak"
    if component in _AI_SCOPED_COMPONENTS and stride_key in {"T", "I", "E", "D"}:
        ai_terms = ["llm", "rag", "vector", "embedding", "agent", "tool", "prompt", "model", "retrieval"]
        if _ai_surface_applicable(architecture_text) and any(term in global_text for term in ai_terms) and risk not in ("Critical", "High"):
            risk = "Medium"
            confidence = "medium" if confidence == "weak" else confidence

    special = _LLM_STRIDE_SPECIAL_CASES.get((component, stride_key), {})
    name = special.get("name") or f"{definition['name']} against {component}"
    attack = special.get("attack") or _component_attack_scenario(component, stride_key)
    validation = special.get("validation") or _component_validation_question(component, stride_key)
    mitigations = _dedupe_text(
        _COMPONENT_STRIDE_MITIGATIONS.get((component, stride_key), [])
        or _component_default_mitigations(component, stride_key),
        5,
    )

    evidence = _dedupe_text([
        *(f"Architecture statement: {snippet}" for snippet in component_evidence),
        *(f"Explicit risk signal: {signal}" for signal in negative),
        *(f"Control evidence: {control}" for control in controls),
        *(["Trust boundary: " + boundary_text] if boundary_text else []),
    ], 8)

    if not evidence and risk not in ("None", "Low"):
        risk = "Needs Validation"
        confidence = "weak"

    return {
        "name": name,
        "risk": risk,
        "confidence": confidence,
        "attack": attack,
        "validation": validation,
        "mitigations": mitigations,
        "component_evidence": component_evidence,
        "evidence": evidence,
        "negative_signals": negative,
        "positive_controls": controls,
        "trust_boundary": boundary or {},
        "boundary": boundary_text,
    }


def _component_attack_scenario(component: str, stride_key: str) -> str:
    scenarios = {
        ("Database", "T"): "An attacker reaches a data mutation path through the application and tampers with records, schema, or migration state rather than breaking transport encryption.",
        ("Database", "I"): "An attacker obtains app-level or database-level access and reads sensitive rows, exports, backups, or query results that the runtime decrypts automatically.",
        ("API gateway", "S"): "An attacker presents a forged, expired, wrong-audience, or algorithm-confused token at the gateway to impersonate a user or service.",
        ("API gateway", "D"): "An attacker sends high-rate or high-cost requests through the public edge before backend services can reject the work.",
        ("Authentication service", "S"): "An attacker abuses weak token validation, recovery flows, session handling, or missing MFA on privileged users to impersonate an identity.",
        ("Application service", "E"): "An attacker changes tenant, object, role, or path parameters so a backend operation runs with privileges the caller should not have.",
        ("Third-party integration", "T"): "An attacker spoofs or tampers with a webhook or partner payload to inject false state into internal workflows.",
    }
    if (component, stride_key) in scenarios:
        return scenarios[(component, stride_key)]
    definition = STRIDE[stride_key]
    return f"An attacker targets {component} to break {definition['security_property'].lower()} through a component-specific {definition['name'].lower()} path."


def _component_validation_question(component: str, stride_key: str) -> str:
    custom = {
        ("Database", "T"): "Are database writes constrained by parameterized queries, least-privilege roles, approved migrations, integrity constraints, and immutable audit records?",
        ("Database", "I"): "Can app-level users, service roles, backups, logs, or exports disclose sensitive rows beyond their tenant and field authorization?",
        ("Web frontend", "D"): "Is there evidence of frontend-specific amplification or expensive work, or is DoS actually controlled at CDN/API layers?",
        ("API gateway", "D"): "Are rate limits, quotas, payload limits, and timeouts enforced at the gateway before requests allocate backend resources?",
        ("Authentication service", "E"): "Can a user or compromised admin path create, assign, or escalate roles/claims without independent authorization and audit?",
    }
    return custom.get((component, stride_key), _STRIDE_VALIDATION[stride_key][0])


def _component_default_mitigations(component: str, stride_key: str) -> list[str]:
    if stride_key == "S":
        if component in {"API gateway", "Public API", "Authentication service", "Cloud control plane", "Secrets manager"}:
            return ["Validate identity tokens or workload identities at this boundary and reject expired, wrong-audience, unsigned, or replayed credentials."]
        return ["Validate identity at the nearest trusted backend boundary; do not rely on client-side assertions."]
    if stride_key == "T":
        return ["Validate schemas and authorization before state changes; use integrity checks appropriate to the data or artifact being modified."]
    if stride_key == "R":
        return ["Log high-value actions centrally with actor, target, result, timestamp, and correlation ID; restrict log modification rights."]
    if stride_key == "I":
        return ["Minimize returned data, enforce authorization before disclosure, redact secrets/PII from logs, and encrypt storage as a compensating theft control."]
    if stride_key == "D":
        return ["Apply quotas, rate limits, payload limits, timeouts, and circuit breakers before expensive downstream work is allocated."]
    if stride_key == "E":
        return ["Enforce least privilege and object/function-level authorization at the service that owns the protected action."]
    return ["Define and verify a component-specific control."]


def _stride_status(risk: str) -> str:
    if risk in _ACTIVE_STRIDE_RISKS:
        return "Open finding"
    if risk == "Needs Validation":
        return "Validation required"
    if risk == "Low":
        return "Low-priority baseline check"
    return "Not applicable from supplied evidence"


def _component_entry_point(component: str, profile: dict) -> str:
    boundary = profile.get("trust_boundary") or {}
    if boundary:
        source = boundary.get("source", "source")
        target = boundary.get("target", component)
        name = boundary.get("boundary", "trust boundary")
        return f"{source} to {target} across {name}"
    return f"{component} interface or data flow inferred from the architecture text"


def _component_context_sentence(component: str, profile: dict) -> str:
    evidence = profile.get("component_evidence") or []
    if evidence:
        return f"The architecture explicitly references {component} in: {evidence[0]}"
    boundary = profile.get("boundary")
    if boundary:
        return f"{component} is tied to the {boundary} trust boundary."
    return f"{component} was inferred from architecture keywords and needs validation against the real DFD."


def _control_gap_text(component: str, stride_key: str, profile: dict) -> str:
    definition = STRIDE[stride_key]
    boundary_text = profile.get("boundary") or "the relevant component boundary"
    negative = profile.get("negative_signals") or []
    controls = profile.get("positive_controls") or []
    if negative:
        driver = "Explicit gap signal(s): " + ", ".join(negative[:5]) + "."
    elif controls:
        driver = "Control signal(s) were found: " + ", ".join(controls[:5]) + "; verify these controls are enforced on the exact flow."
    else:
        driver = "No concrete compensating control was supplied for this component/category pair."
    return (
        f"{driver} Confirm how {component} preserves {definition['security_property'].lower()} "
        f"against {definition['name'].lower()} at {boundary_text}, including enforcement point, owner, logs, and test evidence. "
        f"Confidence is {profile.get('confidence', 'weak')}."
    )


def _stride_description(stride_key: str, component: str, profile: dict) -> str:
    definition = STRIDE[stride_key]
    return (
        f"{definition['name']} review for {component}: validate whether {definition['security_property'].lower()} "
        f"can fail across {_component_entry_point(component, profile)}. "
        f"{_component_context_sentence(component, profile)} "
        f"This is not a generic STRIDE checklist row; the risk is based on component applicability, explicit gap signals, "
        f"control evidence, and the trust boundary inferred from the supplied design."
    )


def _stride_attack_scenario(stride_key: str, component: str, profile: dict) -> str:
    evidence_text = "; ".join(profile["evidence"][:5]) if profile["evidence"] else "no concrete component evidence supplied"
    path = " ".join(_STRIDE_ATTACK_PATHS[stride_key])
    return (
        f"{profile['attack']} Attack path: {path} "
        f"Entry point: {_component_entry_point(component, profile)}. "
        f"Evidence considered: {evidence_text}."
    )


def _stride_abuse_case(stride_key: str, component: str, profile: dict) -> str:
    definition = STRIDE[stride_key]
    return (
        f"Attacker goal: defeat {definition['security_property'].lower()} for {component} and turn the "
        f"{profile.get('boundary') or 'component boundary'} into a path for unauthorized access, state change, "
        "data exposure, service disruption, or privilege expansion."
    )


def _stride_false_positive_guidance(stride_key: str, component: str, profile: dict) -> str:
    controls = profile.get("positive_controls") or []
    if profile["risk"] == "Needs Validation":
        return (
            "Do not treat this as a confirmed vulnerability until the DFD, implementation, and control evidence show "
            f"that {component} actually exposes this STRIDE path."
        )
    if controls and not profile.get("negative_signals"):
        return (
            "Downgrade or close this finding if the cited controls are implemented on the exact boundary, covered by "
            "negative tests, monitored in production, and cannot be bypassed by alternate routes."
        )
    return (
        "Downgrade only with concrete evidence such as passing negative tests, code/configuration review, audit-log samples, "
        "and proof that alternate interfaces enforce the same control."
    )


def _component_evidence_to_collect(component: str, stride_key: str, profile: dict) -> list[str]:
    items = [
        f"DFD segment and trust-boundary owner for {_component_entry_point(component, profile)}",
        *_STRIDE_EVIDENCE_TO_COLLECT[stride_key],
    ]
    if profile.get("trust_boundary", {}).get("data_flows"):
        items.append("Sample requests/events for the listed data flow(s) with actor, tenant, and sensitivity labels")
    if profile.get("positive_controls"):
        items.append("Implementation proof that the detected control term is enforced, not only documented")
    if profile.get("negative_signals"):
        items.append("Remediation evidence for each explicit unsafe signal before risk is downgraded")
    return _dedupe_text(items, 7)


def _component_attack_path(stride_key: str, component: str, profile: dict) -> list[str]:
    steps = [
        f"Target: {component} via {_component_entry_point(component, profile)}.",
        *_STRIDE_ATTACK_PATHS[stride_key],
        f"Expected security break: {STRIDE[stride_key]['security_property']} fails unless the listed control objective is enforced.",
    ]
    return _dedupe_text(steps, 6)


def _component_detection_guidance(stride_key: str, component: str) -> list[str]:
    return _dedupe_text([
        f"Tag detections with component={component} and STRIDE={stride_key} so repeat findings can be trended.",
        *_STRIDE_DETECTION[stride_key],
    ], 5)


def _component_owasp_mapping(component: str, stride_key: str) -> list[str]:
    mappings = list(_STRIDE_OWASP[stride_key])
    if component not in _AI_SCOPED_COMPONENTS:
        mappings = [item for item in mappings if "LLM" not in item]
    return mappings


def analyze_stride(architecture_text: str, title: str = "Untitled") -> dict:
    start = time.monotonic()
    components = extract_components(architecture_text)
    boundary_map = extract_trust_boundary_map(architecture_text)
    matrix = []
    top_threats = []

    for component in components:
        row = {"component": component}
        for stride_key, field in _STRIDE_FIELDS.items():
            definition = STRIDE[stride_key]
            profile = _stride_profile(component, stride_key, architecture_text, boundary_map)
            risk = profile["risk"]
            detail = _stride_cell_detail(stride_key, component, architecture_text, profile)
            threats = []
            if risk in _ACTIVE_STRIDE_RISKS:
                threats = [
                    f"{profile['name']}: {detail['description']}",
                    f"Attack path: {' > '.join(detail['attack_path'][:4])}",
                    f"Evidence reviewed: {'; '.join(profile['evidence'][:4]) or 'component-specific validation required'}",
                ]
                top_threats.append({
                    "category": stride_key,
                    "threat": profile["name"],
                    "component": component,
                    "risk": risk,
                    "confidence": profile["confidence"],
                    "status": detail["status"],
                    "description": detail["description"],
                    "mitigation": detail["mitigations"][0] if detail["mitigations"] else "Define and verify a component-specific control.",
                    "mitigations": detail["mitigations"],
                    "attack_vector": detail["attack_scenario"],
                    "attack_path": detail["attack_path"],
                    "abuse_case": detail["abuse_case"],
                    "impact": detail["impact"],
                    "control_objective": detail["control_objective"],
                    "control_gap": detail["control_gap"],
                    "validation": profile["validation"],
                    "validation_questions": detail["validation_questions"],
                    "recommended_tests": detail["recommended_tests"],
                    "dread_score": detail["dread"]["score"],
                    "dread": detail["dread"],
                    "owasp_mapping": detail["owasp_mapping"],
                    "evidence": profile["evidence"],
                    "evidence_to_collect": detail["evidence_to_collect"],
                    "detection_guidance": detail["detection_guidance"],
                    "false_positive_guidance": detail["false_positive_guidance"],
                    "trust_boundary": profile["trust_boundary"],
                })
            elif risk == "Needs Validation":
                threats = [
                    f"{definition['name']} requires validation at {component}; current evidence is not strong enough to score as an active finding.",
                    f"Validation focus: {profile['validation']}",
                ]
            row[field] = {
                "risk": "None" if risk == "Info" else risk,
                "threats": threats,
                "mitigations": detail["mitigations"],
                "security_property": definition.get("security_property", ""),
                "confidence": profile["confidence"],
                "trust_boundary": profile["trust_boundary"],
                "positive_controls": profile["positive_controls"],
                "negative_signals": profile["negative_signals"],
                **detail,
            }
        matrix.append(row)

    top_threats.sort(key=lambda t: (_risk_sort_key(t["risk"]), t.get("confidence") != "high", t["component"], t["category"]))
    top_threats = top_threats[:14]
    overall = _worst_risk([t["risk"] for t in top_threats], default="Low")
    recommendations = []
    for threat in top_threats:
        rec = f"[{threat['risk']}] {threat['mitigation']}"
        if rec not in recommendations:
            recommendations.append(rec)
        if len(recommendations) >= 10:
            break

    return {
        "title": title,
        "methodology": "STRIDE",
        "summary": (
            f"Offline STRIDE analysis evaluated {len(components)} components against evidence-weighted STRIDE applicability, "
            f"producing {len(top_threats)} prioritized component or trust-boundary threats. "
            "Speculative cells are marked for validation instead of being promoted to High risk."
        ),
        "overall_risk": overall,
        "stride_matrix": matrix,
        "top_stride_threats": top_threats,
        "trust_boundaries": extract_trust_boundaries(architecture_text),
        "trust_boundary_map": boundary_map,
        "data_flows": extract_data_flows(architecture_text),
        "recommendations": recommendations,
        "offline_engine": {
            "mode": "evidence-weighted-stride",
            "components": components,
            "trust_boundaries": len(boundary_map),
            "scoring": "component applicability + explicit gaps + compensating control evidence",
        },
        "elapsed_ms": _now_ms(start),
    }


def _stride_cell_detail(
    stride_key: str,
    component: str,
    architecture_text: str,
    profile: dict,
) -> dict:
    risk = profile["risk"]
    validation_questions = _dedupe_text(
        [profile["validation"], *_STRIDE_VALIDATION[stride_key]],
        5,
    )
    attack_path = _component_attack_path(stride_key, component, profile)
    return {
        "description": _stride_description(stride_key, component, profile),
        "status": _stride_status(risk),
        "entry_point": _component_entry_point(component, profile),
        "abuse_case": _stride_abuse_case(stride_key, component, profile),
        "attack_scenario": _stride_attack_scenario(stride_key, component, profile),
        "attack_path": attack_path,
        "impact": _component_stride_impact(component, stride_key),
        "control_objective": _component_control_objective(component, stride_key),
        "validation_questions": validation_questions,
        "recommended_tests": _STRIDE_TESTS[stride_key],
        "owasp_mapping": _component_owasp_mapping(component, stride_key),
        "evidence": profile["evidence"],
        "evidence_to_collect": _component_evidence_to_collect(component, stride_key, profile),
        "detection_guidance": _component_detection_guidance(stride_key, component),
        "false_positive_guidance": _stride_false_positive_guidance(stride_key, component, profile),
        "control_gap": _control_gap_text(component, stride_key, profile),
        "assumptions": [
            f"{component} is in scope because it was inferred from concrete architecture terms.",
            "Risk level is reduced when explicit compensating controls are present and raised only when relevant gap evidence exists.",
            "Cells marked Needs Validation are checklist items, not confirmed findings.",
        ],
        "mitigations": profile["mitigations"],
        "dread": _dread_for_stride(stride_key, component, architecture_text, risk, profile),
    }


def _component_stride_impact(component: str, stride_key: str) -> str:
    custom = {
        ("Database", "T"): "Unauthorized record, schema, or migration tampering can corrupt business state, bypass integrity constraints, or hide fraudulent changes.",
        ("Database", "I"): "Runtime disclosure can expose tenant records, regulated data, backups, or query results even when storage encryption is enabled.",
        ("LLM service", "T"): "Prompt or context tampering can override policy, manipulate retrieval/tool behavior, and persist unsafe instructions across agent steps.",
        ("LLM service", "I"): "Model responses can leak secrets, PII, tenant context, system prompts, or retrieved documents.",
        ("LLM service", "D"): "Token exhaustion, recursive agent loops, or provider quota exhaustion can degrade availability and create runaway cost.",
        ("Tool/plugin layer", "E"): "Excessive tool agency can turn a prompt into unauthorized write, delete, external-send, or deployment actions.",
        ("API gateway", "D"): "Unbounded edge traffic can exhaust backend, database, queue, or model resources before downstream controls can respond.",
        ("Web frontend", "D"): "Frontend availability impact is usually mediated by CDN/API controls; score High only with evidence of amplification or missing edge controls.",
    }
    return custom.get((component, stride_key), _STRIDE_IMPACT[stride_key])


def _component_control_objective(component: str, stride_key: str) -> str:
    custom = {
        ("Database", "T"): "Preserve database integrity with parameterized access, least-privilege write roles, approved migrations, integrity constraints, and immutable audit records.",
        ("Database", "I"): "Prevent runtime data disclosure through row/tenant/field-level authorization, minimized result sets, protected exports, and redacted logs.",
        ("LLM service", "T"): "Ensure untrusted prompts, retrieved content, and tool outputs cannot override system instructions or authorization policy.",
        ("LLM service", "I"): "Ensure model inputs, memory, retrieval context, logs, and outputs are tenant-isolated, minimized, and filtered for secrets or PII.",
        ("LLM service", "D"): "Bound model work with token, context-size, recursion, concurrency, timeout, and provider-cost controls.",
        ("Tool/plugin layer", "E"): "Ensure every tool action is allowlisted, least-privilege scoped, argument-validated, audited, and approval-gated for high-impact effects.",
        ("API gateway", "D"): "Reject abusive or expensive traffic at the edge through rate limits, quotas, payload limits, timeout budgets, and route cost controls.",
    }
    return custom.get((component, stride_key), _STRIDE_CONTROL_OBJECTIVES[stride_key])


def _dread_for_stride(stride_key: str, component: str, architecture_text: str, risk: str, profile: dict) -> dict:
    base = {
        "Critical": (3, 3, 3, 3, 2),
        "High": (3, 2, 2, 2, 2),
        "Medium": (2, 2, 2, 2, 1),
        "Needs Validation": (1, 1, 1, 1, 2),
        "Low": (1, 1, 1, 1, 1),
        "Info": (1, 1, 1, 1, 1),
        "None": (0, 0, 0, 0, 0),
    }.get(risk, (2, 2, 2, 1, 1))
    damage, reproducibility, exploitability, affected_users, discoverability = base
    text = architecture_text.lower()
    component_lower = component.lower()
    if risk == "None":
        return {
            "damage": 0,
            "reproducibility": 0,
            "exploitability": 0,
            "affected_users": 0,
            "discoverability": 0,
            "score": 0,
            "rating": "None",
            "rationale": ["No active STRIDE path was inferred from the supplied architecture evidence."],
        }
    rationale = [f"Base score starts from {risk} risk for {component} / {stride_key}."]
    if profile.get("negative_signals"):
        reproducibility = min(3, reproducibility + 1)
        exploitability = min(3, exploitability + 1)
        rationale.append("Explicit unsafe signals increase reproducibility and exploitability.")
    if any(term in component_lower for term in ["public", "api", "gateway", "cdn"]) or "internet" in text:
        exploitability = min(3, exploitability + 1)
        discoverability = min(3, discoverability + 1)
        rationale.append("Public/API exposure increases exploitability and discoverability.")
    if any(term in component_lower for term in ["database", "storage", "admin", "cloud", "kubernetes", "llm", "rag", "tool"]):
        damage = min(3, damage + 1)
        affected_users = min(3, affected_users + 1)
        rationale.append("Sensitive or privileged component increases damage and affected-user scope.")
    if stride_key in {"E", "I", "S"}:
        damage = min(3, damage + 1)
        rationale.append("Identity, authorization, or confidentiality failure raises potential damage.")
    if risk == "Needs Validation":
        damage = min(damage, 2)
        reproducibility = min(reproducibility, 1)
        exploitability = min(exploitability, 2)
        affected_users = min(affected_users, 1)
        rationale.append("Needs Validation caps the score because the finding is not yet confirmed.")
    score = damage + reproducibility + exploitability + affected_users + discoverability
    return {
        "damage": damage,
        "reproducibility": reproducibility,
        "exploitability": exploitability,
        "affected_users": affected_users,
        "discoverability": discoverability,
        "score": score,
        "rating": "Critical" if score >= 13 else ("High" if score >= 10 else ("Medium" if score >= 7 else ("Low" if score else "None"))),
        "rationale": _dedupe_text(rationale, 6),
    }


def analyze_pasta(architecture_text: str, title: str = "Untitled") -> dict:
    start = time.monotonic()
    components = extract_components(architecture_text)
    boundaries = extract_trust_boundaries(architecture_text)
    flows = extract_data_flows(architecture_text)
    dependencies = _external_dependencies(architecture_text)
    entry_points = _entry_points(architecture_text)
    assets = _assets(architecture_text)
    actors = _threat_actors(architecture_text)
    ai_detection = detect_ai_architecture(architecture_text)
    api_detection = detect_api_architecture(architecture_text)
    stride = analyze_stride(architecture_text, title)
    owasp = analyze_owasp(architecture_text, title)
    relevant_categories = [
        c for c in owasp.get("categories", [])
        if c.get("risk") in ("Critical", "High", "Medium")
    ][:8]
    risk_register = _pasta_risk_register(relevant_categories, stride.get("top_stride_threats", []))

    stages = [
        {
            "stage": 1,
            "name": PASTA_STAGES[0]["name"],
            "objective": PASTA_STAGES[0]["description"],
            "findings": "Business objectives inferred from architecture-critical services and data flows.",
            "analysis": _pasta_stage_analysis(1, components, boundaries, flows, risk_register),
            "evidence": _pasta_evidence(architecture_text, ["payment", "order", "checkout", "transfer", "admin", "llm", "api", "database"]),
            "assumptions": [
                "Business impact is inferred from architecture terms because no explicit business impact statement was supplied.",
                "Availability, integrity, confidentiality, and abuse prevention are all treated as in scope until excluded by the user.",
            ],
            "business_objectives": _business_objectives(architecture_text),
            "security_requirements": _security_requirements(architecture_text),
            "abuse_cases": _abuse_cases(architecture_text),
            "outputs": PASTA_STAGES[0]["outputs"],
            "next_actions": _pasta_next_actions(1),
        },
        {
            "stage": 2,
            "name": "Technical Scope",
            "objective": PASTA_STAGES[1]["description"],
            "findings": f"Identified {len(components)} major components and {len(flows)} data-flow statements.",
            "analysis": _pasta_stage_analysis(2, components, boundaries, flows, risk_register),
            "evidence": components + flows[:4],
            "assumptions": [
                "Components are inferred from keywords and should be reconciled with diagrams, API specs, IaC, and deployment inventory.",
                "Unmentioned controls are treated as unknown, not absent, unless explicit negative evidence is present.",
            ],
            "components": components,
            "external_dependencies": dependencies,
            "data_flows": flows,
            "data_classification": _data_classification(architecture_text),
            "scope_gaps": _scope_gaps(architecture_text),
            "api_detection": api_detection,
            "ai_detection": ai_detection,
            "outputs": PASTA_STAGES[1]["outputs"],
            "next_actions": _pasta_next_actions(2),
        },
        {
            "stage": 3,
            "name": "Application Decomposition",
            "objective": PASTA_STAGES[2]["description"],
            "findings": f"Identified {len(boundaries)} trust boundaries requiring explicit controls.",
            "analysis": _pasta_stage_analysis(3, components, boundaries, flows, risk_register),
            "evidence": boundaries + entry_points,
            "assumptions": [
                "Each inferred boundary must be validated with DFD direction, protocol, authentication, data sensitivity, and ownership.",
                "Every external actor and third-party integration is treated as lower trust than internal services.",
            ],
            "trust_boundaries": boundaries,
            "entry_points": entry_points,
            "assets": assets,
            "decomposition_questions": _decomposition_questions(boundaries, entry_points),
            "outputs": PASTA_STAGES[2]["outputs"],
            "next_actions": _pasta_next_actions(3),
        },
        {
            "stage": 4,
            "name": "Threat Analysis",
            "objective": PASTA_STAGES[3]["description"],
            "findings": "Threat actors and attack patterns derived from exposure, data sensitivity, and component classes.",
            "analysis": _pasta_stage_analysis(4, components, boundaries, flows, risk_register),
            "evidence": [t["threat"] for t in stride.get("top_stride_threats", [])[:6]],
            "assumptions": [
                "Threat actors are design-stage archetypes and should be replaced with organization-specific adversary profiles when available.",
                "Attack patterns prioritize realistic abuse of exposed entry points and privileged workflows.",
            ],
            "threat_actors": actors,
            "threat_actor_capabilities": _threat_actor_capabilities(actors),
            "attack_patterns": [t["threat"] for t in stride.get("top_stride_threats", [])[:8]],
            "stride_summary": stride.get("top_stride_threats", [])[:8],
            "outputs": PASTA_STAGES[3]["outputs"],
            "next_actions": _pasta_next_actions(4),
        },
        {
            "stage": 5,
            "name": "Vulnerability Analysis",
            "objective": PASTA_STAGES[4]["description"],
            "findings": "Local OWASP rules mapped design weaknesses to affected components.",
            "analysis": _pasta_stage_analysis(5, components, boundaries, flows, risk_register),
            "evidence": [c.get("name", c.get("id", "Finding")) for c in relevant_categories],
            "assumptions": [
                "Design weaknesses are reported even if implementation may later prove a compensating control exists.",
                "Known CVE/SBOM coverage depends on whether dependency inventory or SBOM files were supplied.",
            ],
            "vulnerabilities": [c["name"] for c in relevant_categories],
            "cwe_mappings": _cwe_mappings(relevant_categories),
            "control_gaps": [r for r in owasp.get("recommendations", [])[:8]],
            "weakness_map": _weakness_map(relevant_categories),
            "outputs": PASTA_STAGES[4]["outputs"],
            "next_actions": _pasta_next_actions(5),
        },
        {
            "stage": 6,
            "name": "Attack Modeling",
            "objective": PASTA_STAGES[5]["description"],
            "findings": "Attack paths generated from external entry points through trust-boundary pivots to high-value assets.",
            "analysis": _pasta_stage_analysis(6, components, boundaries, flows, risk_register),
            "evidence": [r["risk"] for r in risk_register[:6]],
            "assumptions": [
                "Attack trees are scenario models for design review and should be validated with abuse-case testing.",
                "Paths assume the attacker can reach at least one listed entry point unless the architecture documents segmentation.",
            ],
            "attack_trees": _attack_trees(risk_register, boundaries, entry_points, assets),
            "outputs": PASTA_STAGES[5]["outputs"],
            "next_actions": _pasta_next_actions(6),
        },
        {
            "stage": 7,
            "name": "Risk Analysis",
            "objective": PASTA_STAGES[6]["description"],
            "findings": "Risk register prioritizes likely, high-impact design risks before residual control validation.",
            "analysis": _pasta_stage_analysis(7, components, boundaries, flows, risk_register),
            "evidence": [f"{r['risk']} score {r['score']}" for r in risk_register[:8]],
            "assumptions": [
                "Risk scores use local severity heuristics and should be calibrated with business owner impact ratings.",
                "Residual risk assumes recommended controls are implemented and verified, not merely planned.",
            ],
            "risk_register": risk_register,
            "risk_acceptance_questions": _risk_acceptance_questions(risk_register),
            "outputs": PASTA_STAGES[6]["outputs"],
            "next_actions": _pasta_next_actions(7),
        },
    ]

    overall = _worst_risk([_score_to_risk(r["score"]) for r in risk_register], default="Low")
    recommendations = [f"[{_score_to_risk(r['score'])}] {r['mitigation']}" for r in risk_register[:10]]
    return {
        "title": title,
        "methodology": "PASTA",
        "summary": (
            f"Offline PASTA analysis completed all 7 stages for {len(components)} components, "
            f"{len(boundaries)} trust boundaries, and {len(risk_register)} prioritized risks."
        ),
        "overall_risk": overall,
        "stages": stages,
        "recommendations": recommendations,
        "offline_engine": {"mode": "full-pasta", "components": components, "trust_boundaries": boundaries},
        "elapsed_ms": _now_ms(start),
    }


def _business_objectives(architecture_text: str) -> list[str]:
    objectives = ["Maintain confidentiality, integrity, and availability of core application workflows"]
    if _contains_any(architecture_text, ["payment", "order", "checkout", "transfer"]):
        objectives.append("Protect revenue-impacting transaction workflows from fraud and tampering")
    if _contains_any(architecture_text, ["llm", "ai", "rag", "agent"]):
        objectives.append("Deliver trustworthy AI responses without data leakage or unauthorized tool actions")
    if _contains_any(architecture_text, ["admin", "management"]):
        objectives.append("Protect privileged administration paths from takeover and misuse")
    return objectives


def _security_requirements(architecture_text: str) -> list[str]:
    requirements = [
        "Deny-by-default authorization at every trust boundary",
        "Strong authentication and session protection for human and service identities",
        "Encryption in transit and at rest for sensitive data",
        "Centralized audit logging with alerting on privileged and anomalous activity",
    ]
    if _contains_any(architecture_text, ["llm", "rag", "agent"]):
        requirements.extend([
            "Prompt-injection isolation for user, retrieval, and tool-output content",
            "Human approval or policy gates for high-impact agent actions",
        ])
    return requirements


def _abuse_cases(architecture_text: str) -> list[str]:
    cases = [
        "Attacker uses a public entry point to reach a protected resource without valid authorization.",
        "Authenticated user attempts cross-tenant or cross-object access by modifying identifiers.",
    ]
    if _contains_any(architecture_text, ["llm", "rag", "agent", "prompt"]):
        cases.append("Prompt-injection attacker attempts to override instructions, poison retrieval, or trigger unsafe tool use.")
    if _contains_any(architecture_text, ["admin", "management", "iam"]):
        cases.append("Compromised administrator or service role performs unauthorized privileged operations.")
    if _contains_any(architecture_text, ["payment", "order", "transfer"]):
        cases.append("Attacker tampers with transaction amount, recipient, order state, or approval workflow.")
    return cases


def _pasta_stage_analysis(
    stage: int,
    components: list[str],
    boundaries: list[str],
    flows: list[str],
    risks: list[dict],
) -> str:
    top_risk = risks[0]["risk"] if risks else "baseline architecture risk"
    if stage == 1:
        return (
            f"The business impact model should treat {top_risk} as the primary abuse case and validate whether "
            "confidentiality, integrity, availability, safety, or regulatory impact would be unacceptable."
        )
    if stage == 2:
        return (
            f"The technical scope contains {len(components)} inferred components and {len(flows)} data-flow statements. "
            "Each item should be reconciled with deployment inventory, ownership, exposed interfaces, and control evidence."
        )
    if stage == 3:
        return (
            f"{len(boundaries)} trust boundaries were inferred. The highest-risk modeling work is to label every crossing "
            "with caller identity, protocol, data sensitivity, authorization point, and logging control."
        )
    if stage == 4:
        return (
            "Threat actor analysis should focus on entry-point abuse, credential theft, cross-tenant access, privileged "
            "workflow misuse, and chained STRIDE threats against high-value assets."
        )
    if stage == 5:
        return (
            "Weakness analysis maps design evidence to OWASP/CWE-style gaps. Treat unknown controls as open questions "
            "until test evidence or architecture decisions prove they are implemented."
        )
    if stage == 6:
        return (
            "Attack modeling converts the highest risks into stepwise paths so reviewers can see prerequisites, pivots, "
            "control breaks, detection points, and business impact instead of isolated findings."
        )
    return (
        "Risk analysis prioritizes the attack paths by likelihood and impact, then records residual risk after proposed "
        "controls are implemented and verified."
    )


def _pasta_evidence(architecture_text: str, terms: list[str]) -> list[str]:
    matches = _matched(architecture_text, terms)
    return matches or ["No explicit business context supplied; evidence inferred from architecture components."]


def _pasta_next_actions(stage: int) -> list[str]:
    actions = {
        1: [
            "Confirm crown-jewel assets and unacceptable business outcomes with the system owner.",
            "Assign risk appetite and compliance constraints before accepting residual risk.",
        ],
        2: [
            "Attach architecture diagram, API inventory, IAM/service-account inventory, and SBOM if available.",
            "Mark each component as internet-facing, internal, third-party, or privileged.",
        ],
        3: [
            "Build or update the DFD with trust boundaries, protocols, identities, and data sensitivity per flow.",
            "Document the control that authenticates and authorizes each boundary crossing.",
        ],
        4: [
            "Validate threat actors against real exposure and organization-specific incident history.",
            "Map top threats to ATT&CK/CAPEC where evidence is sufficient.",
        ],
        5: [
            "Convert each weakness into a testable control gap with owner, due date, and verification method.",
            "Use SBOM/dependency evidence to separate design risk from known vulnerable components.",
        ],
        6: [
            "Run abuse-case tests for the highest-likelihood attack paths.",
            "Add detection and response controls at each pivot point in the attack tree.",
        ],
        7: [
            "Review top risks with business owners and record accept, mitigate, transfer, or avoid decisions.",
            "Re-score residual risk after controls are implemented and independently verified.",
        ],
    }
    return actions.get(stage, [])


def _data_classification(architecture_text: str) -> list[str]:
    classifications = []
    for label, patterns in [
        ("Identity and session data", ["auth", "jwt", "session", "oauth", "sso", "token"]),
        ("Regulated or personal data", ["pii", "personal", "customer", "patient", "gdpr", "hipaa"]),
        ("Financial transaction data", ["payment", "card", "invoice", "order", "transfer"]),
        ("Operational telemetry and audit logs", ["log", "audit", "monitor", "siem", "cloudtrail"]),
        ("AI prompts, retrieved documents, and vector embeddings", ["llm", "rag", "prompt", "document", "vector", "embedding"]),
        ("Secrets and cryptographic key material", ["secret", "key", "certificate", "kms", "vault"]),
    ]:
        if _contains_any(architecture_text, patterns):
            classifications.append(label)
    return classifications or ["Application data sensitivity not specified; classify during intake."]


def _scope_gaps(architecture_text: str) -> list[str]:
    gaps = []
    checks = [
        ("Authentication and authorization details", ["auth", "jwt", "oauth", "sso", "rbac", "iam"]),
        ("Logging and monitoring controls", ["log", "audit", "monitor", "alert", "siem"]),
        ("Network segmentation and trust boundaries", ["vpc", "subnet", "private", "public", "gateway", "trust boundary"]),
        ("Backup and recovery controls", ["backup", "restore", "rto", "rpo", "dr"]),
        ("Rate limiting and abuse protection", ["rate", "quota", "throttle", "waf", "limit"]),
    ]
    for label, terms in checks:
        if not _contains_any(architecture_text, terms):
            gaps.append(f"{label} not explicitly described")
    return gaps or ["No major scope gaps detected from architecture text."]


def _decomposition_questions(boundaries: list[str], entry_points: list[str]) -> list[str]:
    questions = [
        "Which identity is authenticated at each entry point and where is authorization enforced?",
        "What data sensitivity crosses each trust boundary and is it minimized?",
    ]
    if boundaries:
        questions.append(f"Which control validates the crossing at {boundaries[0]}?")
    if entry_points:
        questions.append(f"What rate limits, schema validation, and abuse detection protect {entry_points[0]}?")
    return questions


def _external_dependencies(architecture_text: str) -> list[str]:
    dependencies = []
    for label, patterns in [
        ("Cloud provider services", ["aws", "azure", "gcp", "cloud"]),
        ("Identity provider", ["sso", "oauth", "oidc", "identity provider"]),
        ("LLM/model provider", ["llm", "gpt", "claude", "model provider"]),
        ("Third-party APIs", ["third-party", "partner", "external api", "webhook"]),
        ("Package/container registries", ["docker hub", "registry", "npm", "pypi", "container image"]),
    ]:
        if _contains_any(architecture_text, patterns):
            dependencies.append(label)
    return dependencies or ["No external dependency explicitly described"]


def _entry_points(architecture_text: str) -> list[str]:
    entries = []
    for label, patterns in [
        ("Public web/client traffic", ["browser", "frontend", "internet", "public", "cdn"]),
        ("API requests", ["api", "endpoint", "graphql", "rest"]),
        ("Admin operations", ["admin", "management", "console"]),
        ("Document/user prompt ingestion", ["upload", "document", "prompt", "chat", "rag"]),
        ("Webhook/third-party callbacks", ["webhook", "callback", "third-party", "partner"]),
    ]:
        if _contains_any(architecture_text, patterns):
            entries.append(label)
    return entries or ["Application ingress"]


def _assets(architecture_text: str) -> list[str]:
    assets = ["Application data", "User/session identities", "Operational logs"]
    if _contains_any(architecture_text, ["database", "postgres", "rds", "mysql"]):
        assets.append("Relational database records")
    if _contains_any(architecture_text, ["s3", "bucket", "storage"]):
        assets.append("Object storage contents")
    if _contains_any(architecture_text, ["secret", "key", "token"]):
        assets.append("Secrets, tokens, and signing keys")
    if _contains_any(architecture_text, ["llm", "rag", "vector"]):
        assets.extend(["LLM prompts/responses", "Vector index and retrieved documents"])
    return assets


def _threat_actors(architecture_text: str) -> list[str]:
    actors = ["External attacker", "Malicious authenticated user", "Compromised service account"]
    if _contains_any(architecture_text, ["admin", "management"]):
        actors.append("Insider or compromised administrator")
    if _contains_any(architecture_text, ["llm", "rag", "agent"]):
        actors.append("Prompt-injection attacker")
    if _contains_any(architecture_text, ["third-party", "vendor", "partner"]):
        actors.append("Compromised third-party integration")
    return actors


def _threat_actor_capabilities(actors: list[str]) -> list[str]:
    capabilities = []
    for actor in actors:
        lower = actor.lower()
        if "external" in lower:
            capabilities.append("External attacker: internet reconnaissance, credential stuffing, request tampering, injection attempts, and volumetric abuse.")
        elif "authenticated" in lower:
            capabilities.append("Malicious authenticated user: object-ID manipulation, tenant boundary probing, workflow abuse, and excessive API usage.")
        elif "service account" in lower:
            capabilities.append("Compromised service account: lateral movement through allowed APIs, secret access, and cloud/control-plane misuse within granted scope.")
        elif "administrator" in lower:
            capabilities.append("Insider or compromised administrator: privileged configuration changes, data export, log access, and approval bypass.")
        elif "prompt" in lower:
            capabilities.append("Prompt-injection attacker: instruction override, retrieval poisoning, unsafe tool invocation, and sensitive-context extraction.")
        elif "third-party" in lower:
            capabilities.append("Compromised third-party integration: malicious callback payloads, forged webhook events, and supply-chain trust abuse.")
    return capabilities


def _cwe_mappings(categories: list[dict]) -> list[str]:
    mappings = {
        "A01": "CWE-284 Improper Access Control",
        "A02": "CWE-319 Cleartext Transmission / CWE-311 Missing Encryption",
        "A03": "CWE-89 SQL Injection / CWE-78 OS Command Injection",
        "A04": "CWE-840 Business Logic Errors",
        "A05": "CWE-16 Configuration",
        "A06": "CWE-1104 Use of Unmaintained Third Party Components",
        "A07": "CWE-287 Improper Authentication",
        "A08": "CWE-494 Download of Code Without Integrity Check",
        "A09": "CWE-778 Insufficient Logging",
        "A10": "CWE-918 Server-Side Request Forgery",
    }
    cwes = []
    for category in categories:
        key = str(category.get("id", ""))[:3]
        if key in mappings:
            cwes.append(mappings[key])
    return cwes or ["CWE mappings require detailed design evidence"]


def _weakness_map(categories: list[dict]) -> list[dict]:
    mapped = []
    for category in categories[:8]:
        threats = category.get("threats") or []
        mitigations = category.get("mitigations") or []
        first_threat = threats[0] if threats else {}
        first_mitigation = mitigations[0] if mitigations else {}
        mapped.append({
            "weakness": category.get("name", category.get("id", "Design weakness")),
            "affected_components": category.get("affected_components", []),
            "exploitation_condition": first_threat.get("attack_vector") or first_threat.get("description") or "Control evidence is incomplete or missing.",
            "control_gap": first_mitigation.get("action") if isinstance(first_mitigation, dict) else str(first_mitigation or "Define a compensating control."),
            "risk": category.get("risk", "Medium"),
        })
    return mapped


def _pasta_risk_register(categories: list[dict], stride_threats: list[dict]) -> list[dict]:
    risks = []
    for category in categories:
        risk = category.get("risk", "Medium")
        risks.append({
            "risk": category.get("name", "Design risk"),
            "likelihood": "High" if risk in ("Critical", "High") else "Medium",
            "impact": "High" if risk in ("Critical", "High") else "Medium",
            "score": _risk_score(risk),
            "mitigation": (category.get("mitigations") or [{"action": "Define and verify compensating controls"}])[0]["action"],
            "residual_risk": "Medium" if risk in ("Critical", "High") else "Low",
        })
    for threat in stride_threats[:5]:
        risk = threat.get("risk", "Medium")
        risks.append({
            "risk": threat.get("threat", "STRIDE threat"),
            "likelihood": "High" if risk == "High" else "Medium",
            "impact": "High" if risk in ("Critical", "High") else "Medium",
            "score": _risk_score(risk),
            "mitigation": threat.get("mitigation", "Apply STRIDE control"),
            "residual_risk": "Medium",
        })
    risks.sort(key=lambda r: -int(r.get("score", 0)))
    return risks[:12]


def _attack_trees(
    risks: list[dict],
    boundaries: list[str],
    entry_points: list[str] | None = None,
    assets: list[str] | None = None,
) -> list[dict]:
    trees = []
    entry = (entry_points or ["application ingress"])[0]
    boundary = boundaries[0] if boundaries else "application boundary"
    asset = (assets or ["affected asset"])[0]
    for risk in risks[:5]:
        trees.append({
            "goal": risk["risk"],
            "path": [
                f"Enter through {entry}",
                "Exploit missing or weak control evidence identified by offline analysis",
                f"Pivot across {boundary} to {asset}",
                f"Impact: {risk['impact']} business/security consequence",
            ],
            "prerequisites": [
                "Reachable entry point or compromised authenticated context",
                "Control gap remains unmitigated or unverified",
            ],
            "control_breaks": [
                "Authentication, authorization, validation, logging, or rate-limit control fails at a boundary.",
                "Detection does not alert before the attacker reaches the target asset.",
            ],
            "detection": [
                "Alert on anomalous authorization failures, object access, privilege changes, and high-volume requests.",
                "Correlate entry-point telemetry with downstream data access and administrative actions.",
            ],
            "recommended_controls": [
                risk.get("mitigation", "Define and verify compensating controls"),
                "Add abuse-case tests for the complete path.",
            ],
            "likelihood": risk["likelihood"],
        })
    return trees


def _risk_acceptance_questions(risks: list[dict]) -> list[str]:
    if not risks:
        return ["Which risks remain after baseline controls and who owns acceptance?"]
    top = risks[0]
    return [
        f"If '{top['risk']}' succeeds, what business outcome is unacceptable?",
        "Who owns mitigation verification and by what date?",
        "What monitoring evidence proves residual risk is within appetite?",
        "Which risks require formal acceptance instead of remediation?",
    ]


def _score_to_risk(score: int) -> str:
    if score >= 9:
        return "Critical"
    if score >= 7:
        return "High"
    if score >= 5:
        return "Medium"
    return "Low"
