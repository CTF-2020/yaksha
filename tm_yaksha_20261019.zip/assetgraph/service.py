"""assetgraph/service.py — orchestration: sync a report into the graph, query it.

Mirrors :mod:`lineage.service` / :mod:`correlator.service`'s shape: a leaf
module reading/writing through the same ``report_db`` store the rest of the
app uses, with the reconciliation logic (what makes the graph "living" rather
than an append-only log) living here rather than in the pure engine.

Only codemodel reports feed the graph today — it is the one report type
whose ``scan_metadata`` gives a complete, structured, single-repo snapshot to
reconcile against. SBOM/dependency and cloud-resource sources are natural
next feeds (matching Prime's design->code->cloud framing more fully) but
their saved reports don't currently retain structured component/resource
data the way codemodel's scan_metadata does, so wiring them in now would mean
scraping free text instead of reading real facts — deferred rather than faked.
"""
from __future__ import annotations

import re
import time

import report_db

from . import db, engine
from .model import Asset

_REPORT_ID_RE = re.compile(r'^[A-Za-z0-9_-]{8,80}$')


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _load_report(report_id: str) -> dict | None:
    if not _REPORT_ID_RE.match(report_id):
        return None
    return report_db.get_report(report_id)


def sync(report_id: str) -> dict:
    """Reconcile one codemodel report's asset snapshot into the persistent graph.

    Repo-scoped edges (this repo *contains* entry point X) not present in the
    new snapshot are marked stale — the report is a complete scan of that one
    repo, so its absence is real information, not missing data. Edges into
    global nodes (external_service/trust_boundary) from OTHER repos are never
    touched; staleness is scoped to exactly the repo that was just rescanned.
    """
    report = _load_report(report_id)
    if report is None:
        raise ValueError(f"report not found: {report_id}")
    if str(report.get("methodology", "")).lower() != "codemodel":
        raise ValueError("only codemodel reports feed the asset graph "
                         "(run /code-model first)")

    new_assets, new_edges = engine.extract(report)
    if not new_assets:
        raise ValueError("report has no repo_id in scan_metadata — nothing to sync")

    now = now_iso()
    repo_asset_id = new_assets[0].id  # extract() always puts the repo node first
    new_edge_ids = {e.id for e in new_edges}

    created_assets = 0
    for a in new_assets:
        prior = db.get_asset(a.id)
        if prior is None:
            a.first_seen_at = now
            a.last_seen_at = now
            a.observation_count = 1
            db.upsert_asset(a)
            created_assets += 1
        else:
            prior.name = a.name
            prior.attributes = a.attributes
            prior.last_seen_at = now
            prior.observation_count += 1
            db.upsert_asset(prior)

    # All edges extract() produces originate at the repo node, so one fetch
    # covers every lookup the reconciliation below needs.
    prior_by_id = {x.id: x for x in db.edges_from(repo_asset_id)}

    created_edges = 0
    reactivated_edges = 0
    for e in new_edges:
        prior = prior_by_id.get(e.id)
        if prior is None:
            e.status = "active"
            e.first_seen_at = now
            e.last_seen_at = now
            e.first_seen_report_id = report_id
            e.last_seen_report_id = report_id
            db.upsert_edge(e)
            created_edges += 1
        else:
            if prior.status == "stale":
                reactivated_edges += 1
            prior.status = "active"
            prior.last_seen_at = now
            prior.last_seen_report_id = report_id
            db.upsert_edge(prior)

    staled_edges = 0
    for prior in prior_by_id.values():
        if prior.status == "active" and prior.id not in new_edge_ids:
            db.set_edge_status(prior.id, "stale", now)
            staled_edges += 1

    return {
        "report_id": report_id,
        "repo_asset_id": repo_asset_id,
        "assets_created": created_assets,
        "assets_touched": len(new_assets),
        "edges_created": created_edges,
        "edges_reactivated": reactivated_edges,
        "edges_staled": staled_edges,
    }


def _edge_dict(e) -> dict:
    return {"id": e.id, "from_id": e.from_id, "to_id": e.to_id, "relation": e.relation,
            "status": e.status, "first_seen_at": e.first_seen_at, "last_seen_at": e.last_seen_at,
            "first_seen_report_id": e.first_seen_report_id,
            "last_seen_report_id": e.last_seen_report_id}


def _asset_dict(a: Asset, with_edges: bool = False) -> dict:
    out = {"id": a.id, "kind": a.kind, "name": a.name, "attributes": a.attributes,
           "first_seen_at": a.first_seen_at, "last_seen_at": a.last_seen_at,
           "observation_count": a.observation_count}
    if with_edges:
        incoming = db.edges_to(a.id)
        outgoing = db.edges_from(a.id)
        out["active"] = any(e.status == "active" for e in incoming + outgoing)
        out["incoming_edges"] = [_edge_dict(e) for e in incoming]
        out["outgoing_edges"] = [_edge_dict(e) for e in outgoing]
    return out


def list_assets(kind: str | None = None) -> list[dict]:
    return [_asset_dict(a) for a in db.all_assets(kind=kind)]


def get_asset(asset_id: str) -> dict | None:
    a = db.get_asset(asset_id)
    if a is None:
        return None
    return _asset_dict(a, with_edges=True)


def connected_repos(asset_id: str, status: str = "active") -> list[dict]:
    """Which repo nodes currently have an edge into this asset.

    The direct answer to "what does the graph know everywhere": for a shared
    external_service or trust_boundary node, this is every repo that reaches
    or crosses it, discovered purely from independently-run codemodel scans.
    """
    out = []
    for e in db.edges_to(asset_id, status=status):
        repo = db.get_asset(e.from_id)
        if repo is not None and repo.kind == "repo":
            out.append({"repo_id": repo.id, "repo_name": repo.name,
                        "relation": e.relation, "edge_status": e.status,
                        "last_seen_at": e.last_seen_at})
    return out


def status() -> dict:
    c = db.counts()
    by_kind = {k: len(db.all_assets(kind=k)) for k in
              ("repo", "entry_point", "data_store", "external_service", "trust_boundary")}
    return {"engine": "assetgraph", "assets": c["assets"], "edges": c["edges"],
            "active_edges": c["active_edges"], "assets_by_kind": by_kind}
