"""Risk-acceptance / finding-suppression workflow.

A security tool that cannot record "we looked at this and accepted the risk" (or
"this is a false positive") forces operators to either fix everything or ignore
the report wholesale. This package adds the missing middle: durable, audited,
optionally-expiring decisions that mute a finding without deleting it, so the
report keeps showing the suppressed item — annotated with who accepted it, why,
and until when — while it drops out of the *active* severity posture.

Modules:
  * :mod:`suppressions.model`  — the Suppression dataclass, scopes, states.
  * :mod:`suppressions.engine` — report-independent finding fingerprints and the
    read-time application that annotates a report.
  * :mod:`suppressions.db`     — SQLite, the system of record.
  * :mod:`suppressions.store`  — persistence API; mirrors every write to a
    legacy JSON file as a best-effort backup.
"""
from __future__ import annotations

from .engine import (
    active_suppressions,
    annotate_report,
    finding_fingerprint,
    matches,
    matches_row,
)
from .model import SCOPES, STATES, Suppression
from .store import (
    add_suppression,
    delete_suppression,
    list_suppressions,
    load_suppressions,
)

__all__ = [
    "Suppression", "SCOPES", "STATES",
    "finding_fingerprint", "matches", "matches_row", "annotate_report", "active_suppressions",
    "load_suppressions", "list_suppressions", "add_suppression",
    "delete_suppression",
]
