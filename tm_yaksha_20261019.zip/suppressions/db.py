"""SQLite store for suppressions — the system of record for risk-acceptance records.

Suppressions are governance records — losing them silently un-accepts risk —
so this is the authoritative store; :mod:`suppressions.store` also mirrors
every write to the legacy ``~/.tm_suppressions.json`` as a best-effort,
human-readable backup, but nothing reads that file back in normal operation.

Stdlib ``sqlite3`` only, mirroring :mod:`report_db`'s pattern: connection-per-
call with WAL + a busy timeout, and an idempotent :func:`init` so ``DB_PATH``
can be repointed by tests without any "already initialized" staleness.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

from .model import Suppression

DB_PATH = Path.home() / ".tm_suppressions.db"

_init_lock = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS suppressions (
    id          TEXT PRIMARY KEY,
    scope       TEXT NOT NULL,
    match       TEXT NOT NULL,
    reason      TEXT NOT NULL,
    author      TEXT NOT NULL,
    state       TEXT NOT NULL,
    report_id   TEXT NOT NULL DEFAULT '',
    created_at  REAL,
    expires_at  REAL DEFAULT 0,
    label       TEXT DEFAULT '',
    max_verdict TEXT DEFAULT '',
    verdict     TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_supp_dedupe  ON suppressions(scope, match, report_id);
CREATE INDEX IF NOT EXISTS ix_supp_expires ON suppressions(expires_at);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    """Ensure the schema exists for the CURRENT DB_PATH. Cheap and idempotent."""
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)
            # max_verdict predates this schema on any install that already ran
            # CREATE TABLE IF NOT EXISTS with the old column set — add it once,
            # idempotently, rather than bumping a migration version.
            cols = {r["name"] for r in conn.execute("PRAGMA table_info(suppressions)")}
            if "max_verdict" not in cols:
                conn.execute("ALTER TABLE suppressions ADD COLUMN max_verdict TEXT DEFAULT ''")
            # Same idempotent add-once pattern for the verdict column, added
            # when suppression expiry became verdict-aware (see model.py's
            # MAX_EXPIRY_DAYS / cap_expiry_for_verdict).
            if "verdict" not in cols:
                conn.execute("ALTER TABLE suppressions ADD COLUMN verdict TEXT DEFAULT ''")


def _row_to_suppression(row: sqlite3.Row) -> Suppression:
    return Suppression(
        scope=row["scope"], match=row["match"], reason=row["reason"],
        author=row["author"], state=row["state"], report_id=row["report_id"],
        created_at=row["created_at"], expires_at=row["expires_at"],
        id=row["id"], label=row["label"], max_verdict=row["max_verdict"] or "",
        verdict=row["verdict"] or "",
    )


def all_suppressions() -> list[Suppression]:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT * FROM suppressions ORDER BY created_at DESC").fetchall()
    return [_row_to_suppression(r) for r in rows]


def upsert(supp: Suppression) -> None:
    """Insert, de-duplicating on (scope, match, report_id) like the old JSON
    store did: an existing non-expired suppression matching that triple is
    replaced (by id) rather than duplicated."""
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "DELETE FROM suppressions WHERE scope = ? AND match = ? AND report_id = ?",
            (supp.scope, supp.match, supp.report_id))
        conn.execute(
            "INSERT INTO suppressions"
            "(id,scope,match,reason,author,state,report_id,created_at,expires_at,label,"
            "max_verdict,verdict)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (supp.id, supp.scope, supp.match, supp.reason, supp.author, supp.state,
             supp.report_id, supp.created_at, supp.expires_at, supp.label, supp.max_verdict,
             supp.verdict))


def delete(supp_id: str) -> bool:
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute("DELETE FROM suppressions WHERE id = ?", (supp_id,))
        return cur.rowcount > 0


def prune_expired(now: float | None = None) -> int:
    init()
    cutoff = now if now is not None else time.time()
    with closing(_connect()) as conn, conn:
        cur = conn.execute(
            "DELETE FROM suppressions WHERE expires_at != 0 AND expires_at <= ?",
            (cutoff,))
        return cur.rowcount


def backfill(suppressions: list[Suppression]) -> int:
    """Import a batch of Suppression records once, on first boot after
    upgrading a JSON-only install. Used by app.py; never touches the JSON file."""
    n = 0
    for s in suppressions:
        if isinstance(s, Suppression):
            upsert(s)
            n += 1
    return n


def count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute("SELECT COUNT(*) FROM suppressions").fetchone()[0]


def delete_all() -> int:
    init()
    with closing(_connect()) as conn, conn:
        n = conn.execute("SELECT COUNT(*) FROM suppressions").fetchone()[0]
        conn.execute("DELETE FROM suppressions")
    return n
