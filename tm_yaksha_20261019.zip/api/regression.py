"""Persisted verdict-based canary/regression cases + re-run API.

canary.py generates a one-shot replay script/JSON for whoever is looking at
a report right now; this is what happens after that -- cases persist across
scans (auto-synced whenever a report is saved, see app.py's _save_report)
and can be replayed in-process on demand, with a durable pass/fail history
and an alert when a previously-clean case starts reproducing its original
evidence again.

Routes:
  GET  /api/v1/regression/cases               list persisted cases
                                               (?status, ?report_id, ?q)
  GET  /api/v1/regression/cases/<case_id>      one case + its run history
  POST /api/v1/regression/cases/<case_id>/run  replay it now
  POST /api/v1/regression/run-all              replay every persisted case
  GET  /api/v1/regression/alerts               regression (pass->fail) alerts
                                               (?unacknowledged_only=1)
  POST /api/v1/regression/alerts/<id>/ack      acknowledge one alert
  GET  /api/v1/regression/summary              counts, for a dashboard card
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

import regression

bp = Blueprint("regression_api", __name__, url_prefix="/api/v1/regression")


@bp.get("/cases")
def list_cases():
    cases = regression.list_cases(
        status=request.args.get("status") or None,
        report_id=request.args.get("report_id") or None,
        q=request.args.get("q") or None,
    )
    return jsonify({"success": True, "count": len(cases), "cases": cases})


@bp.get("/cases/<case_id>")
def get_case(case_id: str):
    case = regression.get_case(case_id)
    if case is None:
        return jsonify({"success": False, "error": "no such case"}), 404
    case["history"] = regression.case_history(case_id)
    return jsonify({"success": True, "case": case})


@bp.post("/cases/<case_id>/run")
def run_case(case_id: str):
    try:
        result = regression.run_case(case_id)
    except KeyError:
        return jsonify({"success": False, "error": "no such case"}), 404
    return jsonify({"success": True, "result": result})


@bp.post("/run-all")
def run_all():
    results = regression.run_all()
    regressed = [r for r in results if r["regressed"]]
    return jsonify({"success": True, "count": len(results), "regressed": len(regressed),
                    "results": results})


@bp.get("/alerts")
def list_alerts():
    alerts = regression.list_alerts(
        unacknowledged_only=request.args.get("unacknowledged_only") == "1")
    return jsonify({"success": True, "count": len(alerts), "alerts": alerts})


@bp.post("/alerts/<int:alert_id>/ack")
def ack_alert(alert_id: int):
    ok = regression.acknowledge_alert(alert_id)
    if not ok:
        return jsonify({"success": False, "error": "no such alert"}), 404
    return jsonify({"success": True})


@bp.get("/summary")
def summary():
    return jsonify({"success": True, **regression.summary()})
