"""Architecture drift detection -- declared design vs. code-derived reality.

TM's namesake gap: a threat model reasons over the architecture someone *drew*,
but attackers hit the architecture the code actually *is*. This module diffs the
two. The declared side comes from a draw.io diagram or a design/threat-model
report (nodes, flows, component labels); the actual side comes from the
code-derived model (entry points, data stores, external calls, controls, now
carried structurally in the codemodel report's ``scan_metadata``).

Drift it surfaces:
  * **Undeclared data store / external dependency** — code talks to a database
    or service the diagram never shows (the classic "the cron job queries the DB
    directly, bypassing the API tier").
  * **Undeclared entry point** — code exposes a route the design omits.
  * **Missing security component** — the diagram shows an auth gateway / WAF, but
    the code still has unauthenticated entry points (the control isn't real).
  * **Cleartext external call** — code leaves the process unencrypted.

Matching declared labels to code facts is fuzzy by nature, so it is token-based
and reuses the correlator's tokenizer (stopwords drop generic words like "api"
/ "service", leaving distinctive names like "postgres" / "stripe" / "upload").
Findings are design-review prompts, not proven vulnerabilities, so severities
are conservative. Pure: dicts in, dataclasses out.
"""
from __future__ import annotations

import hashlib
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field

from correlator import taxonomy

_SEV_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
_SEV_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}

# Node-kind inference from a declared label (first match wins, order matters).
_KIND_KEYWORDS = [
    ("datastore", ["database", "db", "postgres", "mysql", "sqlite", "mongo",
                   "redis", "cache", "s3", "bucket", "storage", "datastore",
                   "warehouse", "dynamo", "cassandra", "elastic"]),
    ("security", ["auth", "login", "oauth", "sso", "iam", "identity", "waf",
                  "firewall", "gateway", "ingress", "proxy", "keycloak", "okta"]),
    ("queue", ["queue", "kafka", "rabbit", "sqs", "sns", "pubsub", "topic", "broker"]),
    ("external", ["external", "third-party", "3rd", "vendor", "stripe", "twilio",
                  "sendgrid", "paypal", "saas", "payment"]),
    ("client", ["user", "browser", "client", "mobile", "frontend", "spa", "ui"]),
    ("service", ["service", "api", "backend", "microservice", "worker", "lambda",
                 "function", "server", "app"]),
]
# External-call targets too generic to treat as a named dependency.
_GENERIC_TARGETS = {"http", "https", "requests", "urllib", "httpx", "client",
                    "api", "session", "get", "post", "call", "url"}


def _infer_kind(label: str) -> str:
    low = label.lower()
    for kind, kws in _KIND_KEYWORDS:
        if any(kw in low for kw in kws):
            return kind
    return "component"


@dataclass
class DeclaredModel:
    nodes: list = field(default_factory=list)   # [{label, kind, tokens(frozenset)}]
    edges: list = field(default_factory=list)   # [{label}]
    all_tokens: frozenset = frozenset()
    kinds: frozenset = frozenset()

    def has_kind(self, kind: str) -> bool:
        return kind in self.kinds

    def matches(self, tokens) -> bool:
        """True if any distinctive token is present in the declared design."""
        return bool(tokens & self.all_tokens)


def _build_declared(labels: list[str], edge_labels: list[str]) -> DeclaredModel:
    nodes, all_tokens, kinds = [], set(), set()
    for label in labels:
        label = (label or "").strip()
        if not label:
            continue
        tokens = taxonomy.locus_tokens(label)
        kind = _infer_kind(label)
        nodes.append({"label": label, "kind": kind, "tokens": tokens})
        all_tokens |= tokens
        kinds.add(kind)
    edges = []
    for el in edge_labels:
        el = (el or "").strip()
        if el:
            edges.append({"label": el})
            all_tokens |= taxonomy.locus_tokens(el)
    return DeclaredModel(nodes=nodes, edges=edges,
                         all_tokens=frozenset(all_tokens), kinds=frozenset(kinds))


def declared_from_drawio(xml_content: str) -> DeclaredModel:
    """Parse a draw.io diagram into a declared model (nodes + edges + kinds)."""
    try:
        root = ET.fromstring(xml_content)
    except ET.ParseError as exc:
        raise ValueError(f"invalid draw.io XML: {exc}")
    node_labels, edge_labels = [], []
    for cell in root.iter("mxCell"):
        value = cell.get("value", "").strip()
        if not value or value in ("0", "1"):
            continue
        value = re.sub(r"<[^>]+>", " ", value)
        value = (value.replace("&lt;", "<").replace("&gt;", ">")
                 .replace("&amp;", "&"))
        value = re.sub(r"\s+", " ", value).strip()
        if not value:
            continue
        (edge_labels if cell.get("edge", "0") == "1" else node_labels).append(value)
    return _build_declared(node_labels, edge_labels)


def declared_from_report(report: dict) -> DeclaredModel:
    """Build a declared model from a design/threat-model report.

    Uses the report's architecture text plus every category's affected
    components as the set of declared nodes -- a coarse but useful fallback when
    there is no diagram.
    """
    labels: list[str] = []
    arch = str(report.get("architecture_text", ""))
    for line in arch.splitlines():
        line = line.strip(" -*#\t")
        if line and not line.startswith("//"):
            labels.append(line)
    for cat in report.get("categories", []) or []:
        if isinstance(cat, dict):
            labels.extend(str(c) for c in (cat.get("affected_components") or []) if c)
    return _build_declared(labels, [])


@dataclass
class DriftFinding:
    kind: str            # undeclared-datastore | undeclared-external | ...
    severity: str
    title: str
    detail: str
    locus: str
    recommendation: str


def _cm_meta(codemodel_report: dict) -> dict:
    return codemodel_report.get("scan_metadata") or {}


def diff(codemodel_report: dict, declared: DeclaredModel) -> list[DriftFinding]:
    """Diff a code-derived model report against a declared architecture."""
    meta = _cm_meta(codemodel_report)
    findings: list[DriftFinding] = []

    # 1. Undeclared data stores.
    for ds in meta.get("data_stores", []):
        engine = str(ds.get("engine") or ds.get("kind") or "store")
        tokens = taxonomy.locus_tokens(engine, ds.get("kind", ""))
        if not declared.matches(tokens):
            findings.append(DriftFinding(
                "undeclared-datastore", "Medium",
                f"Undeclared data store: {engine}",
                f"The code connects to a {engine} data store "
                f"({ds.get('file', '?')}:{ds.get('line', '?')}) that the design "
                f"does not represent.",
                f"{ds.get('file', '?')}:{ds.get('line', '?')}",
                "Add this store to the architecture and confirm which components "
                "are allowed to reach it (it may be a tier-bypass)."))

    # 2. Undeclared external dependencies (named targets only).
    for ec in meta.get("external_calls", []):
        target = str(ec.get("target") or "").strip()
        tok = taxonomy.locus_tokens(target)
        if not target or not tok or tok <= _GENERIC_TARGETS:
            continue
        if not declared.matches(tok):
            findings.append(DriftFinding(
                "undeclared-external", "Medium",
                f"Undeclared external dependency: {target}",
                f"The code calls out to '{target}' "
                f"({ec.get('file', '?')}:{ec.get('line', '?')}), not shown in the "
                f"design.",
                f"{ec.get('file', '?')}:{ec.get('line', '?')}",
                "Represent this dependency and its trust boundary in the model."))

    # 3. Cleartext external calls.
    for ec in meta.get("external_calls", []):
        if ec.get("encrypted") is False:
            target = str(ec.get("target") or "endpoint")
            findings.append(DriftFinding(
                "cleartext-external", "Medium",
                f"Cleartext external call: {target}",
                f"The code makes an unencrypted call to '{target}' "
                f"({ec.get('file', '?')}:{ec.get('line', '?')}).",
                f"{ec.get('file', '?')}:{ec.get('line', '?')}",
                "Use TLS for this connection, or document why cleartext is safe "
                "on this segment."))

    # 4. Undeclared entry points (capped to keep the report readable).
    undeclared_eps = []
    for ep in meta.get("attack_surface", []):
        tokens = taxonomy.locus_tokens(
            f"{ep.get('method', '')} {ep.get('path', '')}", ep.get("handler", ""))
        if tokens and not declared.matches(tokens):
            undeclared_eps.append(ep)
    for ep in undeclared_eps[:25]:
        locus = f"{ep.get('method', '*')} {ep.get('path', ep.get('handler', '?'))}".strip()
        findings.append(DriftFinding(
            "undeclared-entrypoint", "Low" if ep.get("authenticated") else "Medium",
            f"Undeclared entry point: {locus}",
            f"The code exposes {locus} "
            f"({ep.get('file', '?')}:{ep.get('line', '?')}) which the design does "
            f"not show" + ("" if ep.get("authenticated") else " (and it is "
                           "unauthenticated)") + ".",
            f"{ep.get('file', '?')}:{ep.get('line', '?')}",
            "Add the endpoint to the attack surface in the model and review its "
            "authn/authz."))

    # 5. Missing security component: design shows an auth/WAF/gateway node, but
    #    code still has unauthenticated entry points -> the control isn't real.
    if declared.has_kind("security"):
        unauth = [ep for ep in meta.get("attack_surface", [])
                  if not ep.get("authenticated")]
        if unauth:
            names = ", ".join(n["label"] for n in declared.nodes
                              if n["kind"] == "security")[:200]
            findings.append(DriftFinding(
                "missing-security-control", "High",
                "Declared security component not enforced in code",
                f"The design includes a security component ({names}) but the code "
                f"has {len(unauth)} unauthenticated entry point(s) — the modeled "
                f"control is not evident in the analyzed code.",
                unauth[0].get("path", "") or unauth[0].get("handler", ""),
                "Verify the auth/WAF/gateway actually fronts these routes; if it "
                "is external, model it as an out-of-code control explicitly."))

    findings.sort(key=lambda f: _SEV_ORDER.get(f.severity, 9))
    return findings


# ── Report rendering ──────────────────────────────────────────────────────────
def _finding_category(f: DriftFinding) -> dict:
    return {
        # Python's builtin hash() is randomized per-process (PYTHONHASHSEED),
        # so the same finding got a different id on every run — breaking
        # suppression fingerprints and cross-scan diffing. hashlib is stable
        # across processes/platforms.
        "id": f"DRIFT-{f.kind}-{hashlib.sha1((f.locus + f.title).encode('utf-8', 'replace')).hexdigest()[:8]}",
        "category": "Architecture Drift",
        "name": f.title,
        "title": f.title,
        "risk": f.severity,
        "risk_score": _SEV_SCORE.get(f.severity, 1),
        "_source": "ARCHDRIFT",
        "ruleset": "ArchDrift",
        "drift_kind": f.kind,
        "description": f.detail,
        "affected_components": [f.locus] if f.locus else [],
        "mitigation": f.recommendation,
        "remediation": f.recommendation,
        "mitigations": [{"action": f.recommendation, "priority": "Short-term"}],
        "threats": [{"name": f.locus or f.kind, "description": f.detail,
                     "attack_vector": "Design/code divergence",
                     "control_objective": f.recommendation}],
        "notes": f"drift kind: {f.kind}",
    }


def to_report(findings: list[DriftFinding], sources: list[dict], meta: dict) -> dict:
    categories = [_finding_category(f) for f in findings]
    overall = "Info"
    for f in findings:
        if _SEV_ORDER.get(f.severity, 9) < _SEV_ORDER.get(overall, 9):
            overall = f.severity
    by_kind: dict[str, int] = {}
    for f in findings:
        by_kind[f.kind] = by_kind.get(f.kind, 0) + 1

    summary = (
        f"Compared the code-derived model against the declared architecture and "
        f"found {len(findings)} drift point(s): "
        + ", ".join(f"{n} {k.replace('-', ' ')}" for k, n in by_kind.items())
        + "." if findings else
        "No architecture drift detected: the code-derived model matches the "
        "declared design on the checked dimensions.")

    return {
        "title": meta.get("report_title") or "Architecture Drift",
        "methodology": "archdrift",
        "methodology_label": "Architecture Drift (design vs. code)",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "summary": summary,
        "categories": categories,
        "recommendations": [
            "Reconcile every undeclared store/dependency/endpoint into the model.",
            "Confirm declared security controls actually front the code they claim to.",
        ],
        "scan_metadata": {
            "engine": "archdrift",
            "sources": sources,
            "drift_total": len(findings),
            "by_kind": by_kind,
        },
    }
