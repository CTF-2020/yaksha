"""Tests for owner assignment (ownership.py) -- bucket defaults, per-finding
overrides, resolution precedence, and the api/ownership.py routes.

Isolated onto a temp SQLite store -- writing through the real one would
pollute ~/.tm_ownership.db (same isolation pattern as test_triage.py /
test_report_db.py).
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import ownership


class OwnershipModuleTests(unittest.TestCase):
    def setUp(self):
        self._orig_path = ownership.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"

    def _restore(self):
        ownership.DB_PATH = self._orig_path

    # ---- bucket defaults -----------------------------------------------

    def test_defaults_start_empty_for_every_bucket(self):
        d = ownership.get_defaults()
        self.assertEqual(set(d), set(ownership.DEFAULT_BUCKETS))
        self.assertTrue(all(v == "" for v in d.values()))

    def test_set_default_persists(self):
        ownership.set_default("confirmed_exploitable", "appsec-oncall")
        self.assertEqual(ownership.get_defaults()["confirmed_exploitable"], "appsec-oncall")

    def test_set_default_overwrites(self):
        ownership.set_default("design_gap", "team-a")
        ownership.set_default("design_gap", "team-b")
        self.assertEqual(ownership.get_defaults()["design_gap"], "team-b")

    def test_set_default_empty_owner_clears(self):
        ownership.set_default("blind_spot", "team-a")
        ownership.set_default("blind_spot", "")
        self.assertEqual(ownership.get_defaults()["blind_spot"], "")

    def test_set_default_rejects_unknown_bucket(self):
        with self.assertRaises(ValueError):
            ownership.set_default("not-a-verdict", "team-a")

    def test_uncorrelated_bucket_is_settable(self):
        ownership.set_default("", "manual-review-team")
        self.assertEqual(ownership.get_defaults()[""], "manual-review-team")

    # ---- per-finding overrides -------------------------------------------

    def test_assign_persists_and_returns_record(self):
        rec = ownership.assign("fp1", "alice", assigned_by="bob", note="context")
        self.assertEqual(rec["owner"], "alice")
        self.assertEqual(rec["assigned_by"], "bob")
        self.assertEqual(rec["note"], "context")

    def test_assign_overwrites_existing(self):
        ownership.assign("fp1", "alice")
        ownership.assign("fp1", "carol")
        assignments = {a["fingerprint"]: a["owner"] for a in ownership.list_assignments()}
        self.assertEqual(assignments["fp1"], "carol")

    def test_assign_empty_owner_clears_and_returns_none(self):
        ownership.assign("fp1", "alice")
        result = ownership.assign("fp1", "")
        self.assertIsNone(result)
        self.assertEqual(ownership.list_assignments(), [])

    def test_assign_requires_fingerprint(self):
        with self.assertRaises(ValueError):
            ownership.assign("", "alice")

    def test_clear_assignment(self):
        ownership.assign("fp1", "alice")
        self.assertTrue(ownership.clear_assignment("fp1"))
        self.assertEqual(ownership.list_assignments(), [])

    def test_clear_assignment_missing_returns_false(self):
        self.assertFalse(ownership.clear_assignment("nope"))

    # ---- resolution precedence -------------------------------------------

    def test_resolve_unassigned_finding(self):
        r = ownership.resolve_owner("fp1", "blind_spot")
        self.assertEqual(r, {"owner": "", "source": "", "note": ""})

    def test_resolve_falls_back_to_bucket_default(self):
        ownership.set_default("corroborated", "team-x")
        r = ownership.resolve_owner("fp1", "corroborated")
        self.assertEqual(r["owner"], "team-x")
        self.assertEqual(r["source"], "default")

    def test_resolve_override_beats_default(self):
        ownership.set_default("corroborated", "team-x")
        ownership.assign("fp1", "alice")
        r = ownership.resolve_owner("fp1", "corroborated")
        self.assertEqual(r["owner"], "alice")
        self.assertEqual(r["source"], "override")

    def test_resolve_uncorrelated_uses_empty_bucket_default(self):
        ownership.set_default("", "manual-review-team")
        r = ownership.resolve_owner("fp1", "")
        self.assertEqual(r["owner"], "manual-review-team")
        self.assertEqual(r["source"], "default")

    # ---- bulk annotate -----------------------------------------------------

    def test_annotate_rows_bulk(self):
        ownership.set_default("confirmed_exploitable", "team-x")
        ownership.assign("fp2", "alice")
        rows = [
            {"fingerprint": "fp1", "verdict": "confirmed_exploitable"},
            {"fingerprint": "fp2", "verdict": "confirmed_exploitable"},
            {"fingerprint": "fp3", "verdict": "blind_spot"},
        ]
        ownership.annotate_rows(rows)
        self.assertEqual(rows[0]["owner"], "team-x")
        self.assertEqual(rows[0]["owner_source"], "default")
        self.assertEqual(rows[1]["owner"], "alice")
        self.assertEqual(rows[1]["owner_source"], "override")
        self.assertEqual(rows[2]["owner"], "")
        self.assertEqual(rows[2]["owner_source"], "")

    def test_annotate_rows_chunks_beyond_sqlite_param_limit(self):
        # Exercise the _CHUNK-based batching path, not just the single-row case.
        for i in range(ownership._CHUNK + 50):
            ownership.assign(f"fp{i}", f"owner{i}")
        rows = [{"fingerprint": f"fp{i}", "verdict": ""} for i in range(ownership._CHUNK + 50)]
        ownership.annotate_rows(rows)
        self.assertTrue(all(r["owner"] == f"owner{i}" for i, r in enumerate(rows)))

    # ---- admin flush parity -------------------------------------------------

    def test_delete_all_wipes_both_tables(self):
        ownership.set_default("design_gap", "team-a")
        ownership.assign("fp1", "alice")
        removed = ownership.delete_all()
        self.assertEqual(removed, 2)
        self.assertTrue(all(v == "" for v in ownership.get_defaults().values()))
        self.assertEqual(ownership.list_assignments(), [])


class OwnershipAPITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.tm_app = tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._orig_path = ownership.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        ownership.DB_PATH = Path(self._td.name) / "ownership.db"

    def _restore(self):
        ownership.DB_PATH = self._orig_path

    def _token(self):
        return self.client.get("/api/csrf-token").get_json()["token"]

    def test_get_defaults_endpoint(self):
        d = self.client.get("/api/v1/owners/defaults").get_json()
        self.assertTrue(d["success"])
        self.assertEqual(set(d["defaults"]), set(ownership.DEFAULT_BUCKETS))

    def test_set_default_endpoint(self):
        token = self._token()
        resp = self.client.post("/api/v1/owners/defaults",
                                json={"verdict": "confirmed_exploitable", "owner": "appsec-oncall"},
                                headers={"X-CSRF-Token": token})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_json()["defaults"]["confirmed_exploitable"], "appsec-oncall")

    def test_set_default_endpoint_rejects_bad_verdict(self):
        token = self._token()
        resp = self.client.post("/api/v1/owners/defaults",
                                json={"verdict": "nonsense", "owner": "team-a"},
                                headers={"X-CSRF-Token": token})
        self.assertEqual(resp.status_code, 400)

    def test_set_default_endpoint_requires_csrf(self):
        resp = self.client.post("/api/v1/owners/defaults",
                                json={"verdict": "design_gap", "owner": "team-a"})
        self.assertEqual(resp.status_code, 403)

    def test_assign_endpoint(self):
        token = self._token()
        resp = self.client.post("/api/v1/owners/assign",
                                json={"fingerprint": "fp1", "owner": "alice"},
                                headers={"X-CSRF-Token": token})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_json()["assignment"]["owner"], "alice")

    def test_assign_endpoint_requires_fingerprint(self):
        token = self._token()
        resp = self.client.post("/api/v1/owners/assign", json={"owner": "alice"},
                                headers={"X-CSRF-Token": token})
        self.assertEqual(resp.status_code, 400)

    def test_clear_assignment_endpoint(self):
        token = self._token()
        self.client.post("/api/v1/owners/assign", json={"fingerprint": "fp1", "owner": "alice"},
                         headers={"X-CSRF-Token": token})
        resp = self.client.delete("/api/v1/owners/assign/fp1", headers={"X-CSRF-Token": token})
        self.assertEqual(resp.status_code, 200)
        resp2 = self.client.delete("/api/v1/owners/assign/fp1", headers={"X-CSRF-Token": token})
        self.assertEqual(resp2.status_code, 404)

    def test_list_assignments_endpoint(self):
        token = self._token()
        self.client.post("/api/v1/owners/assign", json={"fingerprint": "fp1", "owner": "alice"},
                         headers={"X-CSRF-Token": token})
        d = self.client.get("/api/v1/owners/assignments").get_json()
        self.assertEqual(len(d["assignments"]), 1)

    def test_owners_list_combines_defaults_and_overrides(self):
        token = self._token()
        self.client.post("/api/v1/owners/defaults",
                         json={"verdict": "design_gap", "owner": "team-a"},
                         headers={"X-CSRF-Token": token})
        self.client.post("/api/v1/owners/assign", json={"fingerprint": "fp1", "owner": "alice"},
                         headers={"X-CSRF-Token": token})
        d = self.client.get("/api/v1/owners").get_json()
        self.assertEqual(set(d["owners"]), {"team-a", "alice"})


if __name__ == "__main__":
    unittest.main()
