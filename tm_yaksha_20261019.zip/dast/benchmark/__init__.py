"""Measured-accuracy benchmark for the DAST engine.

Run:  python -m dast.benchmark.harness
"""
