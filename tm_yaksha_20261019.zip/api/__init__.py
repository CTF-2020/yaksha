"""Versioned API blueprint registration."""
from __future__ import annotations


def register_api_blueprints(app):
    """Register the clearer v1 API surface while preserving legacy routes."""
    from .analysis import bp as analysis_bp
    from .controls import bp as controls_bp
    from .core import bp as core_bp
    from .diagrams import bp as diagrams_bp
    from .lookups import bp as lookups_bp
    from .patterns import bp as patterns_bp
    from .pqc import bp as pqc_bp
    from .reports import bp as reports_bp
    from .sast import bp as sast_bp, page_bp as broker_page_bp
    # DAST is soft-disabled: the dast/ package and api/dast.py stay in the repo
    # (regression.py and fleet.py still import from dast/ for replay and the
    # fleet rollup) but its blueprints are deliberately not registered here, so
    # /api/v1/dast* and /dast-scanner are unreachable and the scanner is off.
    from .aibom import bp as aibom_bp, page_bp as aibom_page_bp
    from .rules import bp as rules_bp, page_bp as rules_page_bp
    from .correlate import bp as correlate_bp, page_bp as correlate_page_bp
    from .incidents import bp as incidents_bp
    from .lineage import bp as lineage_bp
    from .assetgraph import bp as assetgraph_bp
    from .codemodel import bp as codemodel_bp, page_bp as codemodel_page_bp
    from .dashboard import bp as dashboard_bp, exec_summary_bp, page_bp as dashboard_page_bp
    from .triage import bp as triage_bp, page_bp as triage_page_bp
    from .login import page_bp as login_page_bp
    from .nav import bp as nav_bp
    from .sbom import bp as sbom_bp
    from .suppressions import bp as suppressions_bp
    from .tickets import bp as tickets_bp
    from .design_review import bp as design_review_bp
    from .admin import bp as admin_bp, page_bp as admin_page_bp
    from .ownership import bp as ownership_bp
    from .regression import bp as regression_bp
    from .fleet import bp as fleet_bp
    from .confidence import bp as confidence_bp
    from .verdict_reconciliation import bp as verdict_reconciliation_bp
    from .llm_usage import bp as llm_usage_bp
    from .ticket_fetch import jira_bp as jira_fetch_bp, confluence_bp as confluence_fetch_bp

    for blueprint in (
        core_bp,
        analysis_bp,
        diagrams_bp,
        reports_bp,
        controls_bp,
        sbom_bp,
        pqc_bp,
        patterns_bp,
        lookups_bp,
        tickets_bp,
        design_review_bp,
        suppressions_bp,
        sast_bp,
        broker_page_bp,
        aibom_bp,
        aibom_page_bp,
        rules_bp,
        rules_page_bp,
        correlate_bp,
        correlate_page_bp,
        incidents_bp,
        lineage_bp,
        assetgraph_bp,
        codemodel_bp,
        codemodel_page_bp,
        dashboard_bp,
        exec_summary_bp,
        dashboard_page_bp,
        triage_bp,
        triage_page_bp,
        ownership_bp,
        regression_bp,
        fleet_bp,
        confidence_bp,
        verdict_reconciliation_bp,
        llm_usage_bp,
        jira_fetch_bp,
        confluence_fetch_bp,
        login_page_bp,
        nav_bp,
        admin_bp,
        admin_page_bp,
    ):
        app.register_blueprint(blueprint)
