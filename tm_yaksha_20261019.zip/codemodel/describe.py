"""Render a SystemModel as a plain-text architecture description.

The threat-model analyzer reasons over prose architecture documents; this module
turns the code-derived design facts (attack surface, trust boundaries, stores,
controls, secrets handling) into that prose, so a git repo can be used directly
as threat-modeling input. Output is deliberately factual and compact — it is
analyzer *input*, not a report.
"""
from __future__ import annotations

# Hard cap so a huge monorepo cannot blow past the analyze endpoint's
# 60k-char architecture limit once user-typed text is prepended.
MAX_CHARS = 20_000
_MAX_ROWS = 60          # per section


def _fmt_entry(e) -> str:
    if e.kind == "agent-tool":
        auth = "LLM/agent-invokable (no argument constraint observed)"
    else:
        auth = "authenticated" if e.authenticated else "UNAUTHENTICATED"
    controls = ", ".join(sorted({c.kind for c in (e.controls or [])})) or "none observed"
    line = (f"- {e.method} {e.path} -> {e.handler}() [{e.kind}"
            + (f", {e.framework}" if e.framework else "")
            + f"] — {auth}; controls: {controls}")
    sinks = e.reachable_sinks or []
    if sinks:
        tops = sorted({f"{s.kind} ({s.cwe})" for s in sinks})
        line += f"; reaches sensitive sinks: {', '.join(tops)}"
    return line


def describe_model(model, source_label: str = "") -> str:
    """Return a threat-model-ready textual description of the code model."""
    stats = model.stats()
    parts = []

    header = "Code-derived architecture"
    if source_label:
        header += f" of {source_label}"
    parts.append(f"{header} (extracted by static analysis from source; "
                 f"{stats['files_scanned']} file(s) scanned).")

    langs = ", ".join(sorted(model.languages)) or "unknown"
    fw = ", ".join(sorted(model.frameworks)) or "none detected"
    parts.append(f"Languages: {langs}. Frameworks: {fw}.")

    if model.entry_points:
        rows = [_fmt_entry(e) for e in model.entry_points[:_MAX_ROWS]]
        extra = len(model.entry_points) - _MAX_ROWS
        if extra > 0:
            rows.append(f"- … and {extra} more entry point(s)")
        parts.append("Entry points (externally reachable attack surface):\n" + "\n".join(rows))
    else:
        parts.append("Entry points: none detected (library, batch job, or "
                     "unsupported framework).")

    if model.data_stores:
        rows = sorted({f"- {d.kind}: {d.engine}" for d in model.data_stores})[:_MAX_ROWS]
        parts.append("Data stores (persistence boundaries):\n" + "\n".join(rows))

    if model.external_calls:
        rows = sorted({f"- {c.kind}: {c.target}"
                       + ("" if c.encrypted else " (CLEARTEXT — unencrypted transport)")
                       for c in model.external_calls})[:_MAX_ROWS]
        parts.append("External calls (trust-boundary crossings):\n" + "\n".join(rows))

    if model.trust_boundaries:
        rows = [f"- {b.name} [{b.kind}]" + (f": {b.description}" if b.description else "")
                for b in model.trust_boundaries[:_MAX_ROWS]]
        parts.append("Trust boundaries:\n" + "\n".join(rows))

    if model.controls:
        rows = sorted({f"- {c.kind}: {c.mechanism}" for c in model.controls})[:_MAX_ROWS]
        parts.append("Global security controls observed in code:\n" + "\n".join(rows))
    else:
        parts.append("Global security controls observed in code: none detected.")

    hard = stats["hardcoded_secrets"]
    if model.secrets:
        managed = len(model.secrets) - hard
        parts.append(f"Secrets handling: {len(model.secrets)} credential reference(s) — "
                     f"{managed} from env/secret manager, {hard} HARDCODED in source.")

    text = "\n\n".join(parts)
    if len(text) > MAX_CHARS:
        text = text[:MAX_CHARS - 15].rstrip() + "\n… (truncated)"
    return text
