"""control_register.py — Auto-generate a security control register from threat model findings.

Based on:
  - Green (2025) Ch.4 Risk Management — Control Register structure (p.187)
  - Nichols (2024) Ch.5 Risk and Governance, Ch.11 Best Practices
"""
from __future__ import annotations
import csv
import io
import json
from datetime import datetime
from html import escape as html_escape

# ── Control type classification ────────────────────────────────────────────────
# Classify mitigations into Green (2025) control types
_CONTROL_TYPE_KEYWORDS: dict[str, list[str]] = {
    "Preventive":    ["enforce", "prevent", "block", "require", "restrict", "disable", "encrypt", "validate", "authenticate", "authorise", "configure", "enable mfa", "firewall", "deny"],
    "Detective":     ["monitor", "log", "alert", "detect", "audit", "review", "scan", "siem", "anomaly", "correlate", "inspect", "notify"],
    "Corrective":    ["patch", "update", "remediate", "fix", "restore", "recover", "rotate", "revoke", "reset", "quarantine", "rollback"],
    "Deterrent":     ["warn", "notice", "banner", "legal", "policy", "awareness", "training", "documentation", "cctv", "sign"],
    "Compensating":  ["compensat", "alternative", "where patching isn't", "interim", "workaround", "mitigat", "temporary"],
}

_SEVERITY_TO_PRIORITY = {
    "Critical": "P1 — Immediate (≤72hrs)",
    "High":     "P2 — Short-term (≤7 days)",
    "Medium":   "P3 — Medium-term (≤30 days)",
    "Low":      "P4 — Long-term (≤90 days)",
}

# Ordered most- to least-urgent, so a verdict can shift a control's priority
# tier by index rather than hardcoding a second lookup table.
_PRIORITY_TIERS = [
    "P1 — Immediate (≤72hrs)",
    "P2 — Short-term (≤7 days)",
    "P3 — Medium-term (≤30 days)",
    "P4 — Long-term (≤90 days)",
]

# The correlator's Verdict vocabulary (correlator/model.py), duplicated here
# rather than imported so this module stays independent of the correlator.
# "actively_exploited" (a real production incident, not just lab proof) and
# "confirmed_exploitable" (static root cause + runtime proof) move the tier:
# both are proven, not modeled, so they deserve faster action than the
# severity rating alone implies -- actively_exploited gets the larger bump
# since it outranks confirmed_exploitable, though both floor at P1 today
# given only four tiers exist. The other verdicts -- corroborated (design +
# one evidence source), design_gap (modeled, no evidence either way) and
# blind_spot (evidence, but not modeled) -- are deliberately left at the
# severity-derived baseline: none of them is a stronger signal than severity
# already carries, and a finding with no verdict at all (plain SAST/manual
# reports never touched by the correlator) is completely unaffected.
_VERDICT_PRIORITY_BUMP = {"actively_exploited": 2, "confirmed_exploitable": 1}


def _verdict_adjusted_priority(base_priority: str, verdict) -> str:
    bump = _VERDICT_PRIORITY_BUMP.get(verdict, 0)
    if not bump:
        return base_priority
    try:
        idx = _PRIORITY_TIERS.index(base_priority)
    except ValueError:
        return base_priority
    return _PRIORITY_TIERS[max(0, idx - bump)]

_SEVERITY_TO_TEST_FREQ = {
    "Critical": "Monthly",
    "High":     "Quarterly",
    "Medium":   "Semi-annual",
    "Low":      "Annual",
}

_SABSA_LAYER_MAP: dict[str, str] = {
    "Critical": "Physical / Component",
    "High":     "Physical / Component",
    "Medium":   "Logical",
    "Low":      "Contextual / Conceptual",
}


def _classify_control_type(action: str) -> str:
    text = action.lower()
    for ctype, keywords in _CONTROL_TYPE_KEYWORDS.items():
        if any(kw in text for kw in keywords):
            return ctype
    return "Preventive"


def _make_control_id(index: int, category: str) -> str:
    prefix = category.replace(":", "").replace(" ", "")[:4].upper()
    return f"CTRL-{prefix}-{index:03d}"


def _as_text(value) -> str:
    """Return a compact string from common threat-model value shapes."""
    if value is None:
        return ""
    if isinstance(value, dict):
        for key in ("name", "title", "description", "attack_vector", "id"):
            text = _as_text(value.get(key))
            if text:
                return text
        return ""
    if isinstance(value, (list, tuple, set)):
        parts = [_as_text(item) for item in value]
        return "; ".join(part for part in parts if part)
    return " ".join(str(value).split())


def _first_text(items, *keys: str) -> str:
    for item in items or []:
        if isinstance(item, dict):
            for key in keys:
                text = _as_text(item.get(key))
                if text:
                    return text
        else:
            text = _as_text(item)
            if text:
                return text
    return ""


def _join_limited(values, limit: int = 4) -> str:
    text_values = []
    for value in values or []:
        text = _as_text(value)
        if text and text not in text_values:
            text_values.append(text)
    if not text_values:
        return "Primary application flow"
    shown = text_values[:limit]
    suffix = f"; +{len(text_values) - limit} more" if len(text_values) > limit else ""
    return "; ".join(shown) + suffix


def _control_summary(action: str) -> str:
    text = _as_text(action).rstrip(".")
    if not text:
        return "Implement and validate security control"
    first_sentence = text.split(". ")[0].strip()
    if len(first_sentence) <= 110:
        return first_sentence
    return first_sentence[:107].rstrip() + "..."


def _control_domain(action: str, category: dict) -> str:
    text = f"{action} {category.get('id', '')} {category.get('name', '')}".lower()
    if any(k in text for k in ("prompt", "llm", "model", "rag", "agent", "embedding", "tool")):
        return "AI guardrails"
    if any(k in text for k in ("auth", "rbac", "mfa", "access", "permission", "tenant", "token", "session")):
        return "Identity and access"
    if any(k in text for k in ("log", "alert", "monitor", "detect", "audit", "siem", "telemetry")):
        return "Monitoring and detection"
    if any(k in text for k in ("encrypt", "key", "secret", "crypto", "tls", "certificate", "privacy", "data")):
        return "Data protection"
    if any(k in text for k in ("rate", "quota", "limit", "resilien", "backup", "restore", "recover", "availability")):
        return "Resilience"
    if any(k in text for k in ("dependency", "sbom", "package", "supply", "pipeline", "build", "scan")):
        return "SDLC and supply chain"
    if any(k in text for k in ("cloud", "aws", "azure", "gcp", "kubernetes", "container", "iam", "bucket")):
        return "Cloud platform"
    if any(k in text for k in ("input", "validate", "schema", "escape", "sanitize", "injection", "ssrf")):
        return "Input and output safety"
    return "General hardening"


def _owner_hint(control_type: str, domain: str) -> str:
    domain_l = domain.lower()
    if "identity" in domain_l:
        return "Identity / application owner"
    if "monitoring" in domain_l:
        return "Security operations / SRE owner"
    if "data" in domain_l:
        return "Application / data platform owner"
    if "sdlc" in domain_l:
        return "AppSec / engineering platform owner"
    if "ai" in domain_l:
        return "AI platform / application owner"
    if "cloud" in domain_l:
        return "Cloud platform owner"
    if control_type == "Corrective":
        return "Service owner"
    return "Application security owner"


def _control_rationale(
    category: dict,
    action: str,
    control_type: str,
    domain: str,
    threat_context: str,
) -> str:
    cat_id = category.get("id", "UNK")
    cat_name = category.get("name", "security risk")
    behavior = {
        "Preventive": "blocks the unsafe condition before the attacker can use it",
        "Detective": "creates observable evidence when exploitation attempts or control failures occur",
        "Corrective": "reduces exposure time after a weakness is found or exploited",
        "Deterrent": "sets enforceable expectations and reduces unsafe operator behavior",
        "Compensating": "adds a secondary barrier while the primary fix is planned or unavailable",
    }.get(control_type, "reduces the likelihood or impact of the finding")
    context = threat_context or f"{cat_id} {cat_name} can affect the scoped architecture when the control is missing."
    return (
        f"This {control_type.lower()} {domain.lower()} control mitigates {cat_id} - {cat_name} "
        f"because it {behavior}. Tie it to the affected flow and verify it against this threat context: {context}"
    )


def _verification_guidance(action: str, control_type: str) -> str:
    text = action.lower()
    if any(k in text for k in ("rbac", "access", "authori", "permission", "tenant", "object")):
        return "Run negative authorization tests with another user, tenant, role, and object identifier; confirm every denied path is enforced server-side and logged."
    if any(k in text for k in ("mfa", "auth", "token", "session")):
        return "Validate authentication bypass, token replay, session expiry, and privileged action step-up tests in staging and production-like configuration."
    if any(k in text for k in ("log", "alert", "monitor", "detect", "audit", "siem")):
        return "Trigger a representative event, confirm it reaches logs/SIEM with actor, asset, action, and outcome fields, and verify alert routing and response ownership."
    if any(k in text for k in ("encrypt", "key", "secret", "tls", "certificate")):
        return "Inspect configuration and runtime evidence for encryption, key rotation, secret storage, certificate validity, and blocked plaintext paths."
    if any(k in text for k in ("input", "validate", "schema", "escape", "sanitize", "prompt", "output")):
        return "Use malformed, hostile, and boundary-case payloads to prove schema validation, output encoding, prompt isolation, and unsafe sink blocking are active."
    if any(k in text for k in ("rate", "quota", "limit", "dos", "resource")):
        return "Replay burst and sustained load tests from separate actors and tenants; confirm quotas, graceful degradation, and alerting work as configured."
    if any(k in text for k in ("patch", "update", "dependency", "sbom", "scan")):
        return "Check the patched version, dependency/SBOM scan result, vulnerability exception record, and regression tests for the affected component."
    if control_type == "Detective":
        return "Generate a controlled test event and confirm detection, triage metadata, alert ownership, and runbook linkage."
    if control_type == "Corrective":
        return "Validate the remediation artifact, rollback plan, regression result, and post-fix monitoring evidence."
    return "Create a security test case that exercises both the expected allowed path and the blocked abuse path; attach evidence to the control record."


def _implementation_evidence(action: str, control_type: str) -> str:
    text = action.lower()
    if control_type == "Detective" or any(k in text for k in ("log", "alert", "monitor", "audit")):
        return "Alert rule, sample event, SIEM dashboard link, runbook, and incident-routing test result."
    if any(k in text for k in ("rbac", "access", "auth", "mfa", "permission")):
        return "Policy/config diff, role matrix, automated authorization tests, and access-review approval."
    if any(k in text for k in ("encrypt", "key", "secret", "tls")):
        return "Configuration export, key-management record, certificate scan, and plaintext-path test evidence."
    if any(k in text for k in ("patch", "dependency", "sbom", "scan")):
        return "Patch ticket, dependency/SBOM scan, version proof, and regression test result."
    return "Implementation ticket, configuration or code reference, test evidence, reviewer sign-off, and residual-risk note."


# ── Control register entry ─────────────────────────────────────────────────────

def _build_entry(index: int, category: dict, mit_action: str, mit_priority: str) -> dict:
    cat_id   = category.get("id", "UNK")
    cat_name = category.get("name", "")
    severity = category.get("risk", category.get("severity", "Medium"))
    ctrl_id  = _make_control_id(index, cat_id)

    verdict    = category.get("verdict") or ""
    ctrl_type  = _classify_control_type(mit_action)
    base_priority = _SEVERITY_TO_PRIORITY.get(severity, "P3 — Medium-term (≤30 days)")
    priority   = _verdict_adjusted_priority(base_priority, verdict)
    priority_escalated = priority != base_priority
    test_freq  = _SEVERITY_TO_TEST_FREQ.get(severity, "Quarterly")
    sabsa_layer = _SABSA_LAYER_MAP.get(severity, "Logical")
    domain = _control_domain(mit_action, category)
    summary = _control_summary(mit_action)
    threat_context = _first_text(
        category.get("threats", []),
        "attack_vector", "description", "name", "impact",
    )
    affected_components = _join_limited(
        category.get("affected_components")
        or category.get("components")
        or category.get("assets")
        or []
    )
    why_it_matters = _control_rationale(category, mit_action, ctrl_type, domain, threat_context)
    if priority_escalated:
        if verdict == "actively_exploited":
            why_it_matters += (
                " Priority was escalated above the severity-derived baseline because "
                "a real production incident confirmed this finding was actually "
                "exploited, not just theoretically reachable."
            )
        else:
            why_it_matters += (
                " Priority was escalated above the severity-derived baseline because the "
                "correlation engine marked this finding confirmed_exploitable (static root "
                "cause plus runtime proof) rather than a modeled risk alone."
            )
    verification = _verification_guidance(mit_action, ctrl_type)
    evidence = _implementation_evidence(mit_action, ctrl_type)
    owner = _owner_hint(ctrl_type, domain)

    # Derive related compliance from the category's compliance_controls
    compliance_refs = "; ".join(
        f"{c['framework']} {c['control_id']}"
        for c in category.get("compliance_controls", [])[:3]
    )

    # ATT&CK techniques this control addresses
    attack_refs = "; ".join(
        f"{t['id']} {t['name']}"
        for t in category.get("attack_techniques", [])[:2]
    )

    return {
        "control_id":           ctrl_id,
        "owasp_category":       f"{cat_id} — {cat_name}",
        "risk_severity":        severity,
        "control_summary":      summary,
        "control_description":  mit_action,
        "control_domain":       domain,
        "source_finding":       f"{cat_id} - {cat_name}",
        "threat_context":       threat_context or "No explicit attack vector was captured for this finding.",
        "affected_components":  affected_components,
        "why_it_matters":       why_it_matters,
        "verification_guidance": verification,
        "implementation_evidence": evidence,
        "control_type":         ctrl_type,
        "objective":            f"Mitigate {cat_name} risk with a {ctrl_type.lower()} {domain.lower()} control",
        "implementation_status":"Not Implemented",
        "owner":                owner,
        "priority":             priority,
        "priority_escalated":   priority_escalated,
        "verdict":              verdict,
        "testing_frequency":    test_freq,
        "sabsa_layer":          sabsa_layer,
        "related_risks":        f"{cat_id} — {cat_name}",
        "compliance_mapping":   compliance_refs,
        "attack_techniques":    attack_refs,
        "implementation_date":  "",
        "last_tested":          "",
        "notes":                "",
        "mit_original_priority": mit_priority,
    }


# ── Public API ─────────────────────────────────────────────────────────────────

def generate_control_register(report: dict) -> list[dict]:
    """
    Generate a control register from a threat model report.

    Returns a list of control register entries, one per unique mitigation.
    Each entry follows the Green (2025) control register schema.
    """
    controls: list[dict] = []
    index = 1

    categories = report.get("categories", [])
    for cat in categories:
        severity = cat.get("risk", cat.get("severity", "Medium"))
        mitigations = cat.get("mitigations", [])
        for mit in mitigations:
            if isinstance(mit, dict):
                action   = mit.get("action", "")
                priority = mit.get("priority", "")
            else:
                action   = str(mit)
                priority = _SEVERITY_TO_PRIORITY.get(severity, "")

            if not action:
                continue
            controls.append(_build_entry(index, cat, action, priority))
            index += 1

    return controls


def to_csv(controls: list[dict]) -> str:
    """Export control register to CSV string."""
    if not controls:
        return ""
    fieldnames = [
        "control_id", "owasp_category", "risk_severity", "control_summary",
        "control_description", "control_domain", "source_finding", "threat_context",
        "affected_components", "why_it_matters", "verification_guidance",
        "implementation_evidence", "control_type", "objective",
        "implementation_status", "owner", "priority", "priority_escalated", "verdict",
        "testing_frequency", "sabsa_layer", "compliance_mapping", "attack_techniques",
        "related_risks", "implementation_date", "last_tested", "notes",
    ]
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(controls)
    return buf.getvalue()


def to_html(controls: list[dict], title: str = "Security Control Register") -> str:
    """Export control register to a standalone HTML table."""
    _CTRL_COLORS = {
        "Critical": "#ef4444", "High": "#f97316", "Medium": "#eab308", "Low": "#4ade80",
    }
    _TYPE_COLORS = {
        "Preventive": "#60a5fa", "Detective": "#a78bfa", "Corrective": "#34d399",
        "Deterrent": "#f9a8d4", "Compensating": "#fbbf24",
    }

    def h(value) -> str:
        return html_escape(str(value or ""), quote=True)

    rows_html = ""
    for c in controls:
        sev   = c.get("risk_severity", "Medium")
        ctype = c.get("control_type", "")
        sc    = _CTRL_COLORS.get(sev, "#94a3b8")
        tc    = _TYPE_COLORS.get(ctype, "#94a3b8")
        summary = c.get("control_summary") or c.get("control_description", "")
        escalated_verdict = h(c.get("verdict") or "confirmed_exploitable")
        escalated_title = "Escalated by the correlator's " + escalated_verdict + " verdict"
        escalated_badge = (
            f' <span style="color:#ef4444;font-weight:700" title="{escalated_title}">▲ escalated</span>'
            if c.get('priority_escalated') else ''
        )

        rows_html += f"""<tr>
<td style="color:{sc};font-weight:700">{h(c.get('control_id'))}</td>
<td>
  <div>{h(c.get('owasp_category'))}</div>
  <div style="font-size:10px;color:#64748b;margin-top:4px">{h(c.get('affected_components'))}</div>
</td>
<td><span style="background:{sc}22;color:{sc};padding:2px 6px;border-radius:3px;font-size:11px">{h(sev)}</span></td>
<td style="font-size:12px;min-width:320px">
  <div style="font-weight:700;color:#f8fafc;margin-bottom:5px">{h(summary)}</div>
  <div style="color:#cbd5e1;line-height:1.55">{h(c.get('control_description'))}</div>
  <div style="color:#94a3b8;font-size:11px;line-height:1.5;margin-top:7px"><strong style="color:#e2e8f0">Why:</strong> {h(c.get('why_it_matters'))}</div>
  <div style="color:#94a3b8;font-size:11px;line-height:1.5;margin-top:5px"><strong style="color:#e2e8f0">Verify:</strong> {h(c.get('verification_guidance'))}</div>
</td>
<td>
  <span style="background:{tc}22;color:{tc};padding:2px 6px;border-radius:3px;font-size:11px">{h(ctype)}</span>
  <div style="font-size:10px;color:#64748b;margin-top:5px">{h(c.get('control_domain'))}</div>
</td>
<td style="font-size:11px">{h(c.get('priority'))}{escalated_badge}</td>
<td style="font-size:11px">
  <div>{h(c.get('testing_frequency'))}</div>
  <div style="color:#64748b;margin-top:4px">{h(c.get('implementation_evidence'))}</div>
</td>
<td style="font-size:11px;color:#64748b">{h(c.get('compliance_mapping'))}</td>
<td style="color:#64748b">{h(c.get('implementation_status'))}</td>
<td style="color:#64748b">{h(c.get('owner'))}</td>
</tr>"""

    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>{h(title)}</title>
<style>
body{{font-family:monospace;background:#09090b;color:#e8e3db;margin:0;padding:20px;font-size:12px}}
h1{{color:#ef4444;margin-bottom:4px}}
h2{{color:#94a3b8;font-weight:400;font-size:12px;margin:0 0 16px}}
table{{width:100%;border-collapse:collapse}}
th{{background:#111;color:#94a3b8;padding:8px;text-align:left;font-size:10px;text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid #222}}
td{{padding:8px;border-bottom:1px solid #1a1a1a;vertical-align:top}}
tr:hover{{background:#111}}
.summary{{background:#111;border:1px solid #222;border-radius:6px;padding:12px;margin-bottom:16px;display:flex;gap:24px}}
.stat{{text-align:center}} .stat-n{{font-size:24px;font-weight:700;color:#ef4444}}
.stat-l{{font-size:10px;color:#64748b;text-transform:uppercase}}
</style></head><body>
<h1>Security Control Register</h1>
<h2>{h(title)} - Generated {datetime.now().strftime('%Y-%m-%d %H:%M')} - Framework: Green (2025) + Nichols (2024)</h2>
<div class="summary">
  <div class="stat"><div class="stat-n">{len(controls)}</div><div class="stat-l">Total Controls</div></div>
  <div class="stat"><div class="stat-n">{sum(1 for c in controls if c.get("risk_severity")=="Critical")}</div><div class="stat-l">Critical</div></div>
  <div class="stat"><div class="stat-n">{sum(1 for c in controls if c.get("risk_severity")=="High")}</div><div class="stat-l">High</div></div>
  <div class="stat"><div class="stat-n">{sum(1 for c in controls if c.get("control_type")=="Preventive")}</div><div class="stat-l">Preventive</div></div>
  <div class="stat"><div class="stat-n">{sum(1 for c in controls if c.get("control_type")=="Detective")}</div><div class="stat-l">Detective</div></div>
</div>
<table>
<thead><tr>
<th>Control ID</th><th>Category</th><th>Severity</th><th>Control</th>
<th>Type</th><th>Priority</th><th>Test Freq.</th><th>Compliance</th>
<th>Status</th><th>Owner</th>
</tr></thead>
<tbody>{rows_html}</tbody>
</table>
</body></html>"""


def sabsa_view(controls: list[dict]) -> dict[str, list[dict]]:
    """Group controls by SABSA architectural layer (Green 2025, Ch.2)."""
    layers = {
        "Contextual / Conceptual": [],
        "Logical": [],
        "Physical / Component": [],
        "Operational": [],
    }
    for c in controls:
        layer = c.get("sabsa_layer", "Logical")
        layers.setdefault(layer, []).append(c)
    return {k: v for k, v in layers.items() if v}
