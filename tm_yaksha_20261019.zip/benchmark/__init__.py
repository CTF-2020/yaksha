"""Measured-accuracy benchmark for the offline analysis engine."""
