"""Code-derived threat model API + dashboard page.

Routes (CSRF + optional TM_API_KEY apply via the app's global before_request):
  GET    /api/v1/code-model             engine status
  GET    /api/v1/code-model/repos       registered repos (shared with the SAST broker)
  POST   /api/v1/code-model/analyze     analyze a repo {repo_id} -> saves report

  GET    /code-model                     dashboard UI (separate, un-prefixed bp)

The engine only ever analyzes a repo that has been *registered* with the SAST
broker (local path or git URL), reusing that registry as the authorization
boundary — a dashboard user cannot point it at an arbitrary filesystem path.
"""
from __future__ import annotations

import logging

from flask import Blueprint, jsonify, render_template, request

import app as tm_app
import arch_drift
from broker import config
from codemodel import service
from correlator import service as corr_service

log = logging.getLogger(__name__)

bp = Blueprint("codemodel_api", __name__, url_prefix="/api/v1/code-model")
page_bp = Blueprint("codemodel_page", __name__)

_MAX_DRAWIO_BYTES = 8 * 1024 * 1024


def _sync_downstream_best_effort(report_id: str) -> None:
    """Feed a codemodel scan into the two systems that accumulate across
    scans over time: the persistent threat-lineage graph (does any finding
    here realize an earlier design-time prediction, from a Jira ticket or an
    architecture review?) and the asset graph (this repo's current surface —
    entry points, data stores, shared external services). This mirrors the
    same automatic, failure-isolated wiring DAST scans use for attack-path
    validation (dast.service._validate_attack_paths) and the Jira webhook
    uses for lineage (api.design_review._sync_lineage_best_effort) — a
    codemodel scan is the third, and by far the most frequent, trigger that
    feeds both, so leaving it manual-only here would make it the one gap in
    an otherwise-automatic pipeline.
    """
    try:
        from lineage import service as lineage_service
        lineage_service.sync(report_id)
    except Exception as exc:  # noqa: BLE001 — best-effort, must never fail the scan
        log.warning("could not sync codemodel report %s into lineage: %s", report_id, exc)
    try:
        from assetgraph import service as assetgraph_service
        assetgraph_service.sync(report_id)
    except Exception as exc:  # noqa: BLE001 — best-effort, must never fail the scan
        log.warning("could not sync codemodel report %s into assetgraph: %s", report_id, exc)


@bp.get("")
def status():
    return jsonify({
        "success": True,
        "engine": "codemodel",
        "languages": ["python", "config (docker/env/yaml/tf)"],
        "frameworks": ["flask", "fastapi", "django", "drf"],
        "repos": len(config.load_repos()),
        "capabilities": ["entry-point extraction", "trust-boundary inference",
                         "control-presence detection", "call-graph sink reachability",
                         "feeds correlation engine"],
    })


@bp.get("/repos")
def list_repos():
    repos = [config.redact_repo(r) for r in config.load_repos()]
    return jsonify({"success": True, "repos": repos})


@bp.post("/analyze")
@tm_app.limiter.limit("10 per minute")
def analyze():
    body = request.get_json(silent=True) or {}
    repo_id = str(body.get("repo_id", "")).strip()
    if not config.is_valid_slug(repo_id):
        return jsonify({"success": False, "error": "invalid repo id"}), 400
    repo = config.get_repo(repo_id)
    if not repo:
        return jsonify({"success": False, "error": "repo not found — register it in the SAST broker first"}), 404

    from broker.scanner import ScanError
    try:
        report = service.analyze_repo(repo)
    except ScanError as exc:   # expected: workspace prep / clone failures -> 400 with the reason
        return jsonify({"success": False, "error": f"{type(exc).__name__}: {exc}"}), 400

    report_id = tm_app._save_report(report, report["title"])
    _sync_downstream_best_effort(report_id)

    meta = report.get("scan_metadata", {})
    return jsonify({
        "success": True,
        "report_id": report_id,
        "title": report["title"],
        "overall_risk": report.get("overall_risk"),
        "summary": report.get("summary", ""),
        "stats": meta.get("stats", {}),
        "frameworks": meta.get("frameworks", []),
        "trust_boundaries": meta.get("trust_boundaries", []),
        "findings_total": len([c for c in report.get("categories", [])
                               if c.get("id") != "CM-ARCH"]),
    }), 201


@bp.post("/drift")
@tm_app.limiter.limit("10 per minute")
def drift():
    """Detect architecture drift: code-derived model vs. a declared design.

    The actual side is a saved codemodel report (``codemodel_report_id``). The
    declared side is either a draw.io file (multipart ``file``) or a saved
    design/threat-model report (``declared_report_id``). Saves a drift report.
    """
    cm_id = str(request.form.get("codemodel_report_id")
                or (request.get_json(silent=True) or {}).get("codemodel_report_id")
                or "").strip()
    if not cm_id:
        return jsonify({"success": False,
                        "error": "codemodel_report_id is required"}), 400
    cm_report = corr_service.load_report(cm_id)
    if cm_report is None:
        return jsonify({"success": False,
                        "error": f"codemodel report not found: {cm_id}"}), 404
    if str(cm_report.get("methodology", "")).lower() != "codemodel":
        return jsonify({"success": False,
                        "error": "report is not a code-derived model"}), 400

    declared = None
    declared_label = ""
    upload = request.files.get("file")
    if upload is not None:
        raw = upload.read(_MAX_DRAWIO_BYTES + 1)
        if len(raw) > _MAX_DRAWIO_BYTES:
            return jsonify({"success": False, "error": "diagram file too large"}), 413
        try:
            declared = arch_drift.declared_from_drawio(raw.decode("utf-8", "replace"))
        except ValueError as exc:
            return jsonify({"success": False, "error": str(exc)}), 400
        declared_label = upload.filename or "diagram"
    else:
        body = request.get_json(silent=True) or {}
        declared_id = str(body.get("declared_report_id", "")).strip()
        if not declared_id:
            return jsonify({"success": False,
                            "error": "provide a draw.io file or a declared_report_id"}), 400
        declared_report = corr_service.load_report(declared_id)
        if declared_report is None:
            return jsonify({"success": False,
                            "error": f"declared report not found: {declared_id}"}), 404
        declared = arch_drift.declared_from_report(declared_report)
        declared_label = declared_report.get("title", declared_id)

    findings = arch_drift.diff(cm_report, declared)
    sources = [{"id": cm_id, "title": cm_report.get("title"), "role": "code"},
               {"id": declared_label, "role": "declared"}]
    meta = {"report_title": f"Architecture Drift · {cm_report.get('title', cm_id)}"}
    report = arch_drift.to_report(findings, sources, meta)

    report_id = tm_app._save_report(report, report["title"])
    smeta = report.get("scan_metadata", {})
    return jsonify({
        "success": True,
        "report_id": report_id,
        "title": report["title"],
        "overall_risk": report.get("overall_risk"),
        "drift_total": smeta.get("drift_total", 0),
        "by_kind": smeta.get("by_kind", {}),
        "summary": report.get("summary", ""),
    }), 201


@page_bp.get("/code-model")
def codemodel_page():
    from app import _CSRF_TOKEN
    return render_template("codemodel.html", csrf_token=_CSRF_TOKEN)
