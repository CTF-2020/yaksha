"""Tests for the operational settings store (settings_db.py).

Isolates onto a temp DB, styled like test_report_db.py's TestReportDbModule.
Covers storage roundtrips, secret masking, and the env > DB > default
resolution precedence every config module now relies on.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import settings_db


class TestSettingsDb(unittest.TestCase):
    def setUp(self):
        self._orig_path = settings_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        settings_db.DB_PATH = Path(self._td.name) / "settings.db"
        settings_db.init()

    def _restore(self):
        settings_db.DB_PATH = self._orig_path

    def test_set_get_unset_roundtrip(self):
        self.assertIsNone(settings_db.get_value("broker.scan_timeout"))
        settings_db.set_value("broker.scan_timeout", "1200")
        self.assertEqual(settings_db.get_value("broker.scan_timeout"), "1200")
        self.assertTrue(settings_db.unset("broker.scan_timeout"))
        self.assertIsNone(settings_db.get_value("broker.scan_timeout"))
        self.assertFalse(settings_db.unset("broker.scan_timeout"))

    def test_set_replaces(self):
        settings_db.set_value("broker.workers", "3")
        settings_db.set_value("broker.workers", "8")
        self.assertEqual(settings_db.get_value("broker.workers"), "8")

    def test_secret_keys_auto_flagged_and_masked(self):
        settings_db.set_value("broker.github_token", "ghp_supersecret")
        listed = {s["key"]: s for s in settings_db.list_settings()}
        self.assertTrue(listed["broker.github_token"]["is_secret"])
        self.assertIsNone(listed["broker.github_token"]["value"])

    def test_secret_revealed_on_request(self):
        settings_db.set_value("app.api_key", "topsecret")
        listed = {s["key"]: s for s in settings_db.list_settings(reveal_secrets=True)}
        self.assertEqual(listed["app.api_key"]["value"], "topsecret")

    def test_non_secret_key_never_masked(self):
        settings_db.set_value("broker.workers", "5")
        listed = {s["key"]: s for s in settings_db.list_settings()}
        self.assertFalse(listed["broker.workers"]["is_secret"])
        self.assertEqual(listed["broker.workers"]["value"], "5")

    def test_clear_all_wipes_everything_by_default(self):
        settings_db.set_value("broker.workers", "5")
        settings_db.set_value("app.require_login", "true")
        self.assertEqual(settings_db.clear_all(), 2)
        self.assertEqual(settings_db.list_settings(), [])

    def test_clear_all_preserves_given_keys(self):
        settings_db.set_value("broker.workers", "5")
        settings_db.set_value("app.require_login", "true")
        removed = settings_db.clear_all(preserve={"app.require_login"})
        self.assertEqual(removed, 1)
        self.assertIsNone(settings_db.get_value("broker.workers"))
        self.assertEqual(settings_db.get_value("app.require_login"), "true")


class TestResolvePrecedence(unittest.TestCase):
    """env value (if truthy) wins; else stored DB value; else default."""

    def setUp(self):
        self._orig_path = settings_db.DB_PATH
        self.addCleanup(self._restore)
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        settings_db.DB_PATH = Path(self._td.name) / "settings.db"
        settings_db.init()

    def _restore(self):
        settings_db.DB_PATH = self._orig_path

    def test_resolve_str_default_when_nothing_set(self):
        self.assertEqual(settings_db.resolve_str("k", None, "fallback"), "fallback")

    def test_resolve_str_db_wins_over_default(self):
        settings_db.set_value("k", "stored")
        self.assertEqual(settings_db.resolve_str("k", None, "fallback"), "stored")

    def test_resolve_str_env_wins_over_db_and_default(self):
        settings_db.set_value("k", "stored")
        self.assertEqual(settings_db.resolve_str("k", "from-env", "fallback"), "from-env")

    def test_resolve_int_casts_and_falls_back_on_garbage(self):
        settings_db.set_value("k", "not-a-number")
        self.assertEqual(settings_db.resolve_int("k", None, 42), 42)
        settings_db.set_value("k", "99")
        self.assertEqual(settings_db.resolve_int("k", None, 42), 99)
        self.assertEqual(settings_db.resolve_int("k", "7", 42), 7)

    def test_resolve_bool_parses_common_spellings(self):
        for truthy in ("1", "true", "yes", "on", "TRUE"):
            self.assertTrue(settings_db.resolve_bool("k", truthy, False))
        for falsy in ("0", "false", "no", "off", "FALSE"):
            self.assertFalse(settings_db.resolve_bool("k", falsy, True))

    def test_resolve_bool_db_wins_over_default(self):
        settings_db.set_value("k", "true")
        self.assertTrue(settings_db.resolve_bool("k", None, False))

    def test_resolve_set_parses_comma_list(self):
        self.assertEqual(
            settings_db.resolve_set("k", "GitHub.com, gitlab.com ,,internal.git"),
            {"github.com", "gitlab.com", "internal.git"})
        self.assertEqual(settings_db.resolve_set("k", None), set())

    def test_resolve_set_db_value_used_when_env_absent(self):
        settings_db.set_value("k", "a,b")
        self.assertEqual(settings_db.resolve_set("k", None), {"a", "b"})


if __name__ == "__main__":
    unittest.main()
