"""DAST orchestration: job queue, background worker, report persistence.

Mirrors broker.service: a scan runs on a daemon thread so the triggering request
returns immediately with a job id; the UI polls /jobs/<id> or streams events.
Jobs are mirrored to ~/.tm_dast/jobs.json so history survives a restart, and the
finished report is saved through the host app's own `_save_report` so it appears
in the existing report list and viewer alongside SAST and manual reports.
"""
from __future__ import annotations

import queue
import threading
import traceback

from . import config, github, mapper, scanner, validate


class DastService:
    def __init__(self) -> None:
        self._jobs: dict[str, dict] = {}
        self._lock = threading.RLock()
        # Bounded worker pool — mirrors broker.service.BrokerService: a burst
        # of scan requests across many targets must not spawn one thread per
        # request (unbounded concurrent crawls, each holding sockets open for
        # up to config.SCAN_TIMEOUT). Started lazily on first submit so merely
        # constructing the service (e.g. in a unit test) spawns no threads.
        self._queue: "queue.Queue[tuple]" = queue.Queue()
        self._workers: list[threading.Thread] = []
        self._workers_started = False
        for job in config.load_jobs():
            self._jobs[job["id"]] = job

    # ── Worker pool ───────────────────────────────────────────────────────────
    def _ensure_workers(self) -> None:
        with self._lock:
            if self._workers_started:
                return
            self._workers_started = True
            for i in range(config.DAST_WORKERS):
                t = threading.Thread(target=self._worker_loop, name=f"dast-worker-{i}",
                                     daemon=True)
                t.start()
                self._workers.append(t)

    def _worker_loop(self) -> None:
        while True:
            job_id, target, severity, gh_ctx = self._queue.get()
            try:
                self._run(job_id, target, severity, gh_ctx)
            except Exception:  # a worker must never die on a job failure
                import logging
                logging.getLogger("dast").error("worker crashed\n%s",
                                                 traceback.format_exc())
            finally:
                self._queue.task_done()

    # ── Job bookkeeping ───────────────────────────────────────────────────────
    def _new_job_id(self) -> str:
        import secrets
        import time
        return f"dast_{int(time.time())}_{secrets.token_hex(3)}"

    def _persist(self) -> None:
        with self._lock:
            ordered = sorted(self._jobs.values(),
                             key=lambda j: j.get("started_at", ""), reverse=True)
            config.save_jobs(ordered)

    def reset_job_history(self) -> int:
        """Admin flush: drop every job from memory and persistence so the
        dashboard reflects empty state immediately, without a restart."""
        with self._lock:
            n = len(self._jobs)
            self._jobs.clear()
        config.clear_job_history()
        return n

    def _update(self, job_id: str, **fields) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return
            job.update(fields)
        self._persist()

    def _log(self, job_id: str, message: str) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is not None:
                job.setdefault("log", []).append(f"{config.now_iso()}  {message}")
                job["log"] = job["log"][-50:]
                job["progress"] = message

    # ── Public API ────────────────────────────────────────────────────────────
    def list_jobs(self, limit: int = 100) -> list[dict]:
        with self._lock:
            jobs = sorted(self._jobs.values(),
                          key=lambda j: j.get("started_at", ""), reverse=True)
        return [dict(j) for j in jobs[:limit]]

    def get_job(self, job_id: str) -> dict | None:
        with self._lock:
            job = self._jobs.get(job_id)
            return dict(job) if job else None

    def _find_inflight(self, target_id: str, sha) -> str | None:
        """Return the id of an already queued/running scan for this work, if any.

        GitHub delivers webhooks at-least-once, so a redelivery (same target +
        commit sha) would otherwise launch a second concurrent scan and post a
        duplicate gate signal. Manual re-submits for a target that is already
        scanning are likewise collapsed onto the in-flight job.
        """
        with self._lock:
            for job in self._jobs.values():
                if (job.get("target_id") == target_id
                        and job.get("status") in ("queued", "running")
                        and job.get("commit") == sha):
                    return job["id"]
        return None

    def submit_scan(self, target: dict, severity: str = "Info",
                    gh_ctx: dict | None = None) -> str:
        if severity not in config.SEVERITY_ORDER:
            severity = "Info"
        existing = self._find_inflight(target.get("id"), (gh_ctx or {}).get("sha"))
        if existing:
            return existing
        job_id = self._new_job_id()
        job = {
            "id": job_id,
            "target_id": target.get("id"),
            "target_name": target.get("name"),
            "target_url": target.get("url"),
            "severity": severity,
            "status": "queued",
            "progress": "Queued",
            "started_at": config.now_iso(),
            "finished_at": None,
            "report_id": None,
            "validation_report_id": None,
            "stats": None,
            "error": None,
            "log": [],
            # Webhook context (no secrets) so the dashboard can show the trigger.
            "trigger": (gh_ctx or {}).get("kind", "manual"),
            "environment": (gh_ctx or {}).get("environment"),
            "commit": (gh_ctx or {}).get("sha"),
        }
        with self._lock:
            self._jobs[job_id] = job
        self._persist()
        self._ensure_workers()
        self._queue.put((job_id, target, severity, gh_ctx))
        return job_id

    # ── Worker ────────────────────────────────────────────────────────────────
    def _run(self, job_id: str, target: dict, severity: str,
             gh_ctx: dict | None = None) -> None:
        report = report_id = None
        try:
            self._update(job_id, status="running")
            self._log(job_id, "Starting dynamic scan")
            findings, meta = scanner.run_scan(
                target, severity, progress=lambda m: self._log(job_id, m))
            self._log(job_id, f"Scan complete: {len(findings)} finding(s)")

            report = mapper.findings_to_report(findings, target, meta, severity)
            report_id = self._save_report(report)
            self._log(job_id, f"Report saved: {report_id}")

            stats = report["scan_metadata"]
            self._update(
                job_id, status="done", finished_at=config.now_iso(),
                report_id=report_id, progress="Done",
                stats={
                    "findings_total": stats["findings_total"],
                    "rules_triggered": stats["rules_triggered"],
                    "severity_counts": stats["severity_counts"],
                    "overall_risk": report["overall_risk"],
                    "pages_crawled": meta.get("pages_crawled", 0),
                },
            )
            self._record_last_scan(target["id"], report_id, report["overall_risk"],
                                   stats["findings_total"])
            self._validate_attack_paths(job_id, target, report)
            self._report_to_github(job_id, target, gh_ctx, report, report_id, None)
        except Exception as exc:
            self._log(job_id, f"ERROR: {exc}")
            self._update(job_id, status="error", finished_at=config.now_iso(),
                         progress="Failed", error=str(exc))
            self._report_to_github(job_id, target, gh_ctx, None, None, str(exc))
            import logging
            logging.getLogger("dast").error("scan job %s failed\n%s",
                                             job_id, traceback.format_exc())

    def _report_to_github(self, job_id: str, target: dict, gh_ctx: dict | None,
                          report: dict | None, report_id: str | None,
                          error: str | None) -> None:
        """Post the deployment gate signal back to GitHub for webhook scans."""
        if not gh_ctx or gh_ctx.get("kind") not in ("deployment", "push"):
            return
        try:
            github.report_to_github(target, gh_ctx, report, report_id, error,
                                    log=lambda m: self._log(job_id, m))
            self._persist()
        except Exception as exc:  # never let reporting fail the job
            self._log(job_id, f"GitHub reporting raised: {exc}")

    def _validate_attack_paths(self, job_id: str, target: dict, report: dict) -> None:
        """Re-synthesize attack paths for this target's linked repo using the
        scan that just finished as runtime evidence — the "continuous" half of
        attack-path validation: every scan re-checks candidates against fresh
        evidence with no one having to ask. A silent no-op (not an error) when
        the target has no linked repo, or that repo has never had a
        code-derived threat model run — most targets won't yet, and that is
        expected, not a failure worth surfacing as one.
        """
        try:
            validated = validate.validate(report, target)
        except Exception as exc:  # never let validation fail the scan job
            self._log(job_id, f"Attack-path validation raised: {exc}")
            return
        if validated is None:
            return
        validation_id = self._save_report(validated)
        meta = validated.get("scan_metadata", {})
        self._log(job_id, f"Attack-path validation: {meta.get('confirmed', 0)} "
                          f"confirmed / {meta.get('paths_total', 0)} path(s) — "
                          f"report {validation_id}")
        self._update(job_id, validation_report_id=validation_id)

    @staticmethod
    def _save_report(report: dict) -> str:
        import app as tm_app  # lazy import to avoid a circular import at load
        return tm_app._save_report(report, report["title"])

    def _record_last_scan(self, target_id: str, report_id: str,
                          risk: str, findings: int) -> None:
        target = config.get_target(target_id)
        if not target:
            return
        target["last_scan"] = {
            "report_id": report_id, "risk": risk,
            "findings": findings, "at": config.now_iso(),
        }
        config.upsert_target(target)

    # ── Remote-push path (standalone scanner -> server) ───────────────────────
    def import_report(self, report: dict) -> str:
        if not isinstance(report.get("categories"), list):
            raise ValueError("report must include a categories list")
        report.setdefault("methodology", "dast")
        report.setdefault("methodology_label", "Dynamic Application Security Testing")
        report.setdefault("analyzed_at", config.now_iso())
        report["title"] = report.get("title") or "DAST · imported"
        return self._save_report(report)


_service: DastService | None = None
_service_lock = threading.Lock()


def get_service() -> DastService:
    global _service
    with _service_lock:
        if _service is None:
            _service = DastService()
    return _service
