"""canary.py — verdict-based canary/regression test auto-generation.

Turns a *proven* finding into a runnable curl replay script that re-sends the
exact request that triggered it and checks whether the same evidence still
shows up. Only the two "proven" correlator verdicts qualify by default --
actively_exploited (a real production incident) and confirmed_exploitable
(static root cause + independent runtime proof) -- the same asymmetry
control_register.py and compliance_mappings.py already apply elsewhere:
corroborated/design_gap/blind_spot findings aren't demonstrated true
positives, so there's nothing proven yet to guard against regressing.

Only DAST-sourced findings (dast/mapper.py: threat name = "<url>[ [param]]",
GET-only -- dast/engine.py's _Reporter.add hardcodes method="GET" for every
finding) have a real HTTP locus to replay. A SAST/codemodel finding is a
source file:line with nothing to curl, so those are skipped entirely rather
than emitting a script that can't actually test anything.

Two check strategies, matched to what's mechanically verifiable without
reimplementing every vulnerability class's detection logic:
  * header rules (HSTS/CSP/XFO/XCTO/Referrer-Policy) -- check the response
    header directly; precise, no heuristic involved.
  * everything else -- replay the request and check whether the ORIGINAL
    evidence text captured at scan time still appears in the fresh response.
    This is a standard regression-detection pattern (did the same signal
    that proved it the first time reappear) rather than a reimplementation
    of the scanner's own payload logic.

This module only builds cases and decides pass/fail/skip for one response
(:func:`generate_for_report`, :func:`to_bash_script`, :func:`evaluate_response`)
-- it has no memory. regression.py is the persistence + re-run layer built on
top: it stores the cases this module generates, replays them in-process on
demand (or in bulk), and keeps a durable history so a case that passed on one
run and fails on a later one can be flagged as an actual regression.
"""
from __future__ import annotations

import re
import shlex

# The correlator's two "proven" verdicts (correlator/model.py's Verdict enum,
# duplicated here rather than imported -- same independence choice
# suppressions/model.py and control_register.py already made).
PROVEN_VERDICTS = ("actively_exploited", "confirmed_exploitable")

# dast/mapper.py's _loc(): f"{url}" + (f" [{param}]" if param else "").
# A "[Static (code)] ..." style prefix (report_db._PREFIX_RE) can wrap a
# locus once correlation merges sources, so that's stripped first.
_PREFIX_RE = re.compile(r"^\[[^\]]+\]\s*(.+)$")
_LOC_RE = re.compile(r"^(?P<url>\S+)(?:\s+\[(?P<param>[^\]]+)\])?$")

# rule_id -> response header this finding is about. Mechanically checkable:
# present/absent, no evidence-text heuristic needed.
_HEADER_CHECKS = {
    "DAST-HDR-HSTS": "Strict-Transport-Security",
    "DAST-HDR-CSP": "Content-Security-Policy",
    "DAST-HDR-XFO": "X-Frame-Options",
    "DAST-HDR-XCTO": "X-Content-Type-Options",
    "DAST-HDR-REFERRER": "Referrer-Policy",
}


def _parse_locus(name: str) -> tuple[str, str] | None:
    """"<url>( [<param>])?" -> (url, param), or None if not a replayable URL."""
    s = str(name or "").strip()
    m = _PREFIX_RE.match(s)
    if m:
        s = m.group(1).strip()
    m = _LOC_RE.match(s)
    if not m:
        return None
    url = m.group("url")
    if not url.startswith(("http://", "https://")):
        return None
    return url, (m.group("param") or "")


def qualifying_threats(category: dict):
    """Yield (threat, url, param) for every threat in this category that has
    a real, replayable HTTP locus. Public: regression.py's persistence layer
    reuses this to find the same replayable cases the bash script covers."""
    for t in category.get("threats") or []:
        if not isinstance(t, dict):
            continue
        parsed = _parse_locus(t.get("name"))
        if parsed:
            yield t, parsed[0], parsed[1]


def _check_snippet(rule_id: str, evidence: str) -> str:
    """The bash snippet that decides PASS/FAIL for one replayed response,
    given $RESP_HEADERS / $RESP_BODY are already populated."""
    header = _HEADER_CHECKS.get(rule_id)
    if header:
        return (f'if printf \'%s\' "$RESP_HEADERS" | grep -qi "^{header}:"; then\n'
                f'  echo "  PASS -- {header} present"\n'
                f'else\n'
                f'  echo "  FAIL -- {header} missing (regression?)"; FAILED=1\n'
                f'fi')
    marker = " ".join((evidence or "").split())[:160]
    if not marker:
        return '  echo "  SKIP -- no evidence marker captured to compare against"'
    quoted = shlex.quote(marker)
    # $RESP_BODY is whitespace-collapsed the same way the marker was (tr -s
    # squeezes each run of whitespace to one space) before the grep -- the
    # marker is built from the original evidence's *collapsed* whitespace,
    # so comparing it against the raw, un-collapsed body would miss a still-
    # reproducing finding whenever the response's line breaks/indentation
    # around the matching text don't happen to line up byte-for-byte with
    # how it looked at scan time, producing a false PASS on a live bug.
    return (f'if printf \'%s\' "$RESP_BODY" | tr -s \'[:space:]\' \' \' | grep -qF {quoted}; then\n'
            f'  echo "  FAIL -- original evidence still present (regression?)"; FAILED=1\n'
            f'else\n'
            f'  echo "  PASS -- original evidence no longer reproduces"\n'
            f'fi')


def generate_case(category: dict, threat: dict, url: str, param: str) -> dict:
    """One curl-replay case for one (category, threat) pair."""
    rule_id = str(category.get("id") or "")
    title = str(category.get("title") or category.get("name") or rule_id)
    evidence = str(threat.get("description") or "")
    label = f"[{rule_id}] {title}" + (f" -- param: {param}" if param else "")
    check = _check_snippet(rule_id, evidence)
    script = (
        f'echo {shlex.quote(label)}\n'
        f'HDRFILE=$(mktemp); BODYFILE=$(mktemp)\n'
        f'curl -sS -D "$HDRFILE" -o "$BODYFILE" --max-time 15 {shlex.quote(url)}\n'
        f'RESP_HEADERS=$(cat "$HDRFILE"); RESP_BODY=$(cat "$BODYFILE")\n'
        f'rm -f "$HDRFILE" "$BODYFILE"\n'
        f'{check}\n'
    )
    return {"rule_id": rule_id, "title": title, "url": url, "param": param,
            "verdict": category.get("verdict") or "", "script": script,
            "evidence": evidence}


def generate_for_report(report: dict, verdicts: tuple[str, ...] = PROVEN_VERDICTS) -> list[dict]:
    """Every qualifying (verdict-gated, URL-having) finding's replay case,
    across the whole report."""
    cases: list[dict] = []
    for cat in report.get("categories") or []:
        if not isinstance(cat, dict):
            continue
        if (cat.get("verdict") or "") not in verdicts:
            continue
        for threat, url, param in qualifying_threats(cat):
            cases.append(generate_case(cat, threat, url, param))
    return cases


def to_bash_script(report: dict, cases: list[dict]) -> str:
    """Bundle every case into one downloadable, runnable bash script."""
    title = str(report.get("title") or report.get("id") or "report")
    header = (
        "#!/usr/bin/env bash\n"
        "# Verdict-based regression canary -- auto-generated by Yaksha Guard.\n"
        f"# Report: {title} ({report.get('id', '')})\n"
        "#\n"
        "# Replays the exact request that proved each finding and checks whether\n"
        "# the same evidence still shows up. Only findings at a PROVEN verdict\n"
        "# (actively_exploited / confirmed_exploitable) are included here -- these\n"
        "# are demonstrated true positives, not \"might be a problem\".\n"
        "# A FAIL means the finding still reproduces; review before shipping.\n"
        "#\n"
        "# Only run this against a system you are authorized to test.\n"
        "set -uo pipefail\n"
        "FAILED=0\n\n"
    )
    if not cases:
        return header + 'echo "No proven (actively_exploited / confirmed_exploitable) findings with a replayable HTTP locus."\n'
    footer = (
        "\nif [ \"$FAILED\" -ne 0 ]; then\n"
        "  echo\n"
        "  echo \"One or more findings still reproduce. See FAIL lines above.\"\n"
        "  exit 1\n"
        "fi\n"
        "echo\n"
        "echo \"All replayed findings no longer reproduce.\"\n"
    )
    return header + "\n".join(c["script"] for c in cases) + footer


def evaluate_response(rule_id: str, evidence: str, headers: dict, body: str) -> tuple[str, str]:
    """In-process pass/fail/skip for one replayed response -- the same
    decision :func:`_check_snippet` renders as a bash check, so a
    browser/API-triggered re-run (regression.py) and the downloadable
    canary.sh script always agree on the same case.

    Returns ``(status, detail)`` where status is one of:
      * "pass" -- the finding no longer reproduces.
      * "fail" -- it still does (a regression, if the previous run passed).
      * "skip" -- no evidence marker was ever captured to compare against,
        so this case makes no claim either way.

    ``headers`` is expected lower-cased (dast.engine.Resp's contract).
    """
    header = _HEADER_CHECKS.get(rule_id)
    if header:
        if header.lower() in (headers or {}):
            return "pass", f"{header} present"
        return "fail", f"{header} missing (regression?)"
    marker = " ".join((evidence or "").split())[:160]
    if not marker:
        return "skip", "no evidence marker captured to compare against"
    # See _check_snippet's comment: the body must get the same whitespace
    # collapsing the marker did, or a still-reproducing finding whose
    # surrounding whitespace shifted slightly reads as a false PASS.
    normalized_body = " ".join((body or "").split())
    if marker in normalized_body:
        return "fail", "original evidence still present (regression?)"
    return "pass", "original evidence no longer reproduces"
