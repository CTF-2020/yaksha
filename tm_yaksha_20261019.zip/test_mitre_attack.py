"""Regression tests for mitre_attack.py's category-id -> ruleset routing.

analyzer.analyze_offline() builds category ids as f"{ruleset.upper()}-{category}"
(e.g. "MOBILE-M1" for the offline mobile ruleset's category "M1"), so
get_techniques()/_normalize_category() must strip that prefix before looking the
bare category id up in the per-ruleset ATT&CK tables — otherwise a real,
populated table (OWASP_MOBILE_ATTACK) is silently never reached.
"""
from __future__ import annotations

import unittest

import mitre_attack


class MobilePrefixRoutingTests(unittest.TestCase):
    def test_mobile_prefixed_category_resolves_to_bare_key(self):
        cat, ruleset = mitre_attack._normalize_category("MOBILE-M1")
        self.assertEqual(cat, "M1")
        self.assertEqual(ruleset, "mobile")

    def test_mobile_prefixed_category_returns_real_techniques(self):
        techniques = mitre_attack.get_techniques("MOBILE-M1")
        self.assertTrue(techniques, "MOBILE-M1 should resolve to OWASP_MOBILE_ATTACK's M1 entry")
        ids = {t["id"] for t in techniques}
        self.assertIn("T1552", ids)

    def test_mobile_k8s_prefixed_category_returns_real_techniques(self):
        techniques = mitre_attack.get_techniques("MOBILE-K01")
        self.assertTrue(techniques, "MOBILE-K01 should resolve to OWASP_MOBILE_ATTACK's K01 entry")

    def test_enrich_categories_populates_attack_techniques_for_offline_mobile(self):
        categories = [{"id": "MOBILE-M2", "name": "Supply Chain", "threats": []}]
        mitre_attack.enrich_categories(categories)
        self.assertTrue(categories[0]["attack_techniques"])


class ColonSuffixCategoryIdTests(unittest.TestCase):
    """owasp.py / offline_patterns.py's _framework_report stamp category ids
    with a display-year suffix ("A01:2021", "API1:2023") that must be
    stripped before the bare-key ATT&CK tables are looked up.
    """

    def test_owasp_web_colon_suffix_resolves_to_bare_key(self):
        cat, ruleset = mitre_attack._normalize_category("A01:2021")
        self.assertEqual(cat, "A01")
        self.assertEqual(ruleset, "web")

    def test_owasp_web_colon_suffix_returns_real_techniques(self):
        techniques = mitre_attack.get_techniques("A01:2021")
        self.assertTrue(techniques, "A01:2021 should resolve to OWASP_WEB_ATTACK's A01 entry")
        ids = {t["id"] for t in techniques}
        self.assertIn("T1078", ids)

    def test_owasp_api_colon_suffix_returns_real_techniques(self):
        techniques = mitre_attack.get_techniques("API1:2023")
        self.assertTrue(techniques, "API1:2023 should resolve to the api ruleset's API1 entry")

    def test_enrich_categories_populates_attack_techniques_for_colon_suffixed_id(self):
        categories = [{"id": "A03:2021", "name": "Injection", "threats": []}]
        mitre_attack.enrich_categories(categories)
        self.assertTrue(categories[0]["attack_techniques"])


if __name__ == "__main__":
    unittest.main()
