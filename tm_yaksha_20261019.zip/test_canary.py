"""Tests for canary.py -- verdict-based canary/regression test generation.

Pure-module tests exercise locus parsing, verdict gating, and script
generation directly; the app-level tests below exercise the two routes
through the Flask test client against an isolated report_db.
"""
from __future__ import annotations

import shlex
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

import canary
import report_db


def _threat(url, param="", evidence="reflected payload <script>x</script>"):
    name = url + (f" [{param}]" if param else "")
    return {"name": name, "description": evidence}


def _cat(cid, title, risk="High", verdict=None, threats=None):
    cat = {"id": cid, "name": title, "title": title, "risk": risk,
           "threats": threats or []}
    if verdict:
        cat["verdict"] = verdict
    return cat


def _report(rid, categories, title="R"):
    return {"id": rid, "title": title, "categories": categories}


class ParseLocusTests(unittest.TestCase):
    def test_plain_url(self):
        self.assertEqual(canary._parse_locus("https://x.test/a"), ("https://x.test/a", ""))

    def test_url_with_param(self):
        self.assertEqual(canary._parse_locus("https://x.test/a?q=1 [q]"),
                         ("https://x.test/a?q=1", "q"))

    def test_prefixed_locus_is_stripped(self):
        self.assertEqual(canary._parse_locus("[Static (code)] https://x.test/a"),
                         ("https://x.test/a", ""))

    def test_non_url_locus_returns_none(self):
        self.assertIsNone(canary._parse_locus("db.py:10"))

    def test_non_http_scheme_returns_none(self):
        self.assertIsNone(canary._parse_locus("ftp://x.test/a"))

    def test_empty_returns_none(self):
        self.assertIsNone(canary._parse_locus(""))
        self.assertIsNone(canary._parse_locus(None))


class QualifyingThreatsTests(unittest.TestCase):
    def test_mixed_threats_only_url_ones_qualify(self):
        cat = _cat("DAST-XSS-REFLECTED", "XSS", threats=[
            _threat("https://x.test/a", "q"),
            {"name": "db.py:10", "description": "no url here"},
        ])
        out = list(canary.qualifying_threats(cat))
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0][1], "https://x.test/a")
        self.assertEqual(out[0][2], "q")


class GenerateCaseTests(unittest.TestCase):
    def test_header_rule_uses_header_check(self):
        cat = _cat("DAST-HDR-HSTS", "Missing HSTS")
        threat = _threat("https://x.test/", evidence="")
        case = canary.generate_case(cat, threat, "https://x.test/", "")
        self.assertIn("Strict-Transport-Security", case["script"])
        self.assertIn("grep -qi", case["script"])
        self.assertNotIn("grep -qF", case["script"])

    def test_evidence_rule_uses_marker_check(self):
        cat = _cat("DAST-XSS-REFLECTED", "Reflected XSS")
        threat = _threat("https://x.test/a", "q", evidence="<script>alert(1)</script>")
        case = canary.generate_case(cat, threat, "https://x.test/a", "q")
        self.assertIn("grep -qF", case["script"])
        self.assertIn("alert(1)", case["script"])
        self.assertIn("param: q", case["script"])

    def test_no_evidence_produces_skip(self):
        cat = _cat("DAST-INFO-BANNER", "Server banner leak")
        threat = _threat("https://x.test/", evidence="")
        case = canary.generate_case(cat, threat, "https://x.test/", "")
        self.assertIn("SKIP", case["script"])

    def test_case_carries_metadata(self):
        cat = _cat("DAST-SQLI", "SQL Injection", verdict="confirmed_exploitable")
        threat = _threat("https://x.test/login", "user")
        case = canary.generate_case(cat, threat, "https://x.test/login", "user")
        self.assertEqual(case["rule_id"], "DAST-SQLI")
        self.assertEqual(case["url"], "https://x.test/login")
        self.assertEqual(case["param"], "user")
        self.assertEqual(case["verdict"], "confirmed_exploitable")


class GenerateForReportTests(unittest.TestCase):
    def test_only_proven_verdicts_qualify_by_default(self):
        report = _report("r1", [
            _cat("A", "Active", threats=[_threat("https://x.test/a")], verdict="actively_exploited"),
            _cat("B", "Confirmed", threats=[_threat("https://x.test/b")], verdict="confirmed_exploitable"),
            _cat("C", "Corroborated", threats=[_threat("https://x.test/c")], verdict="corroborated"),
            _cat("D", "Blind", threats=[_threat("https://x.test/d")], verdict="blind_spot"),
            _cat("E", "Gap", threats=[_threat("https://x.test/e")], verdict="design_gap"),
            _cat("F", "Unverdicted", threats=[_threat("https://x.test/f")]),
        ])
        cases = canary.generate_for_report(report)
        self.assertEqual({c["rule_id"] for c in cases}, {"A", "B"})

    def test_custom_verdict_override(self):
        report = _report("r1", [
            _cat("C", "Corroborated", threats=[_threat("https://x.test/c")], verdict="corroborated"),
        ])
        self.assertEqual(canary.generate_for_report(report), [])
        cases = canary.generate_for_report(report, verdicts=("corroborated",))
        self.assertEqual(len(cases), 1)

    def test_sast_finding_with_no_url_is_skipped_even_if_proven(self):
        report = _report("r1", [
            _cat("SAST-1", "SQLi", verdict="confirmed_exploitable",
                threats=[{"name": "db.py:10", "description": "raw query"}]),
        ])
        self.assertEqual(canary.generate_for_report(report), [])

    def test_multiple_threats_in_one_category_all_qualify(self):
        report = _report("r1", [
            _cat("A", "XSS", verdict="actively_exploited",
                threats=[_threat("https://x.test/a", "q1"), _threat("https://x.test/a", "q2")]),
        ])
        cases = canary.generate_for_report(report)
        self.assertEqual(len(cases), 2)


class ToBashScriptTests(unittest.TestCase):
    def test_envelope_has_shebang_and_report_title(self):
        report = _report("r1", [], title="My Report")
        script = canary.to_bash_script(report, [])
        self.assertTrue(script.startswith("#!/usr/bin/env bash"))
        self.assertIn("My Report", script)
        self.assertIn("set -uo pipefail", script)

    def test_empty_cases_says_so_and_is_still_runnable_shaped(self):
        report = _report("r1", [], title="R")
        script = canary.to_bash_script(report, [])
        self.assertIn("No proven", script)
        self.assertNotIn("FAILED\" -ne 0", script)   # no footer when nothing to run

    def test_cases_are_joined_and_footer_present(self):
        report = _report("r1", [], title="R")
        cases = canary.generate_for_report(_report("r1", [
            _cat("A", "XSS", verdict="actively_exploited", threats=[_threat("https://x.test/a")]),
            _cat("B", "SQLi", verdict="confirmed_exploitable", threats=[_threat("https://x.test/b")]),
        ]))
        script = canary.to_bash_script(report, cases)
        self.assertIn("[A] XSS", script)
        self.assertIn("[B] SQLi", script)
        self.assertIn('FAILED" -ne 0', script)
        self.assertIn("All replayed findings no longer reproduce.", script)


@unittest.skipUnless(shutil.which("bash"), "bash not on PATH")
class CheckSnippetBashExecutionTests(unittest.TestCase):
    """Actually run the generated bash check (not just inspect its text),
    so a change to _check_snippet that's syntactically fine but behaviorally
    wrong (e.g. the whitespace-normalization asymmetry this guards against)
    gets caught the same way evaluate_response's equivalent Python bug would."""

    def _run(self, rule_id: str, evidence: str, resp_body: str) -> str:
        snippet = canary._check_snippet(rule_id, evidence)
        script = (
            "set -uo pipefail\nFAILED=0\n"
            f"RESP_BODY={shlex.quote(resp_body)}\n"
            f"RESP_HEADERS=''\n{snippet}\n"
        )
        proc = subprocess.run(["bash", "-c", script], capture_output=True, text=True, timeout=10)
        return proc.stdout

    def test_still_reproduces_despite_different_whitespace_fails(self):
        out = self._run("DAST-SQLI", "Error: user 'admin'\n  not found",
                        "...Error: user 'admin'\n    not found...")
        self.assertIn("FAIL", out)

    def test_evidence_gone_passes(self):
        out = self._run("DAST-SQLI", "Error: user 'admin' not found", "clean response")
        self.assertIn("PASS", out)


class EvaluateResponseTests(unittest.TestCase):
    def test_header_present_passes(self):
        status, detail = canary.evaluate_response(
            "DAST-HDR-HSTS", "", {"strict-transport-security": "max-age=1"}, "")
        self.assertEqual(status, "pass")
        self.assertIn("present", detail)

    def test_header_missing_fails(self):
        status, detail = canary.evaluate_response("DAST-HDR-CSP", "", {}, "")
        self.assertEqual(status, "fail")
        self.assertIn("missing", detail)

    def test_header_check_is_case_insensitive_key_lookup(self):
        # dast.engine.Resp headers are already lower-cased; evaluate_response
        # must not assume any particular casing of the CONSTANT it compares against.
        status, _ = canary.evaluate_response(
            "DAST-HDR-XFO", "", {"x-frame-options": "DENY"}, "")
        self.assertEqual(status, "pass")

    def test_evidence_still_present_fails(self):
        status, detail = canary.evaluate_response(
            "DAST-XSS-REFLECTED", "<script>alert(1)</script>", {},
            "...<script>alert(1)</script>...")
        self.assertEqual(status, "fail")
        self.assertIn("still present", detail)

    def test_evidence_gone_passes(self):
        status, detail = canary.evaluate_response(
            "DAST-XSS-REFLECTED", "<script>alert(1)</script>", {}, "clean response")
        self.assertEqual(status, "pass")
        self.assertIn("no longer reproduces", detail)

    def test_no_evidence_marker_skips(self):
        status, detail = canary.evaluate_response("DAST-INFO-BANNER", "", {}, "anything")
        self.assertEqual(status, "skip")

    def test_evidence_still_present_with_different_whitespace_still_fails(self):
        # The marker is built by collapsing the evidence's whitespace to
        # single spaces ("a\n  b" -> "a b"). Before the fix, the response
        # body was compared raw/un-collapsed, so a still-reproducing finding
        # whose surrounding whitespace shifted (extra indentation, a
        # different line break) read as a false PASS -- the worse failure
        # direction for a regression canary.
        status, detail = canary.evaluate_response(
            "DAST-SQLI", "Error: user 'admin'\n  not found", {},
            "...Error: user 'admin'\n    not found...")
        self.assertEqual(status, "fail")
        self.assertIn("still present", detail)

    def test_agrees_with_bash_check_snippet_choice_of_strategy(self):
        # Same rule_id must route to the same strategy (header vs marker) in
        # both the bash-script generator and the in-process evaluator.
        cat = _cat("DAST-HDR-HSTS", "Missing HSTS")
        threat = _threat("https://x.test/", evidence="")
        case = canary.generate_case(cat, threat, "https://x.test/", "")
        self.assertIn("Strict-Transport-Security", case["script"])
        status, _ = canary.evaluate_response("DAST-HDR-HSTS", case["evidence"],
                                             {"strict-transport-security": "x"}, "")
        self.assertEqual(status, "pass")


class GenerateCaseEvidenceFieldTests(unittest.TestCase):
    def test_case_carries_raw_evidence_text(self):
        cat = _cat("DAST-XSS-REFLECTED", "Reflected XSS")
        threat = _threat("https://x.test/a", "q", evidence="<script>alert(1)</script>")
        case = canary.generate_case(cat, threat, "https://x.test/a", "q")
        self.assertEqual(case["evidence"], "<script>alert(1)</script>")


class CanaryApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        self._op = report_db.DB_PATH
        self.addCleanup(lambda: setattr(report_db, "DB_PATH", self._op))
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        report_db.init()
        report_db.upsert_report({
            "id": "100_1_canarytest", "title": "Canary API test", "methodology": "dast",
            "overall_risk": "Critical",
            "categories": [
                _cat("DAST-XSS-REFLECTED", "Reflected XSS", verdict="actively_exploited",
                    threats=[_threat("https://x.test/search", "q")]),
                _cat("DAST-INFO-BANNER", "Server banner", verdict="design_gap",
                    threats=[_threat("https://x.test/")]),
            ],
        })

    def test_json_endpoint_lists_only_proven_verdicts(self):
        resp = self.client.get("/api/reports/100_1_canarytest/canary-tests")
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["count"], 1)
        self.assertEqual(d["cases"][0]["rule_id"], "DAST-XSS-REFLECTED")
        self.assertNotIn("script", d["cases"][0])

    def test_json_endpoint_respects_verdict_override(self):
        resp = self.client.get("/api/reports/100_1_canarytest/canary-tests?verdict=design_gap")
        d = resp.get_json()
        self.assertEqual(d["count"], 1)
        self.assertEqual(d["cases"][0]["rule_id"], "DAST-INFO-BANNER")

    def test_sh_endpoint_downloads_runnable_script(self):
        resp = self.client.get("/api/reports/100_1_canarytest/canary-tests.sh")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("attachment", resp.headers.get("Content-Disposition", ""))
        self.assertIn("x-shellscript", resp.content_type)
        text = resp.get_data(as_text=True)
        self.assertTrue(text.startswith("#!/usr/bin/env bash"))
        self.assertIn("DAST-XSS-REFLECTED", text)
        self.assertNotIn("DAST-INFO-BANNER", text)   # design_gap excluded by default

    def test_invalid_report_id_rejected(self):
        resp = self.client.get("/api/reports/bad!!/canary-tests")
        self.assertEqual(resp.status_code, 400)

    def test_v1_mirror_route_matches_legacy(self):
        legacy = self.client.get("/api/reports/100_1_canarytest/canary-tests").get_json()
        v1 = self.client.get("/api/v1/reports/100_1_canarytest/canary-tests").get_json()
        self.assertEqual(legacy["cases"], v1["cases"])


if __name__ == "__main__":
    unittest.main()
