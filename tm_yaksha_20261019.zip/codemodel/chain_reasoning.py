"""codemodel/chain_reasoning.py — LLM multi-step attack-chain reasoning.

``codemodel.threats`` derives *single-hop* findings: one entry point reaching
one sink. ``attack_paths.synthesize`` chains that same single hop into a
narrated path graded by evidence. Neither can see a chain that crosses
*between* distinct entry points, a shared data store, or a control gap at one
boundary combined with an unrelated data flow elsewhere in the system — the
kind of thing an attacker connects by reasoning about intent, not by tracing a
call graph one function at a time. That is the gap this module fills.

It hands the code-derived *facts* (never raw source) to an LLM and asks it to
propose exactly that: chains combining two or more facts across a trust
boundary, explicitly excluding anything already reported as a single-hop
finding. Output is tagged ``_source: "LLM-CHAIN"``. Like ``attack_paths``, it
is deliberately left out of the correlator's SAST/DAST buckets so it falls
through to ``SourceKind.DESIGN`` — a hypothesis to be corroborated or refuted
by real evidence, not a proven finding on its own.

No offline fallback exists here: finding a novel chain is a generative
reasoning act, not a rule lookup, so :func:`reason` returns an empty list
without an API key rather than fabricating a lesser substitute.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from analyzer import _extract_json, _harden_system, _wrap_input
from claude_client import call_claude_cached

_SEVERITIES = ("Critical", "High", "Medium", "Low", "Info")
_SEV_ORDER = {s: i for i, s in enumerate(_SEVERITIES)}
_SEV_SCORE = {"Critical": 9, "High": 7, "Medium": 5, "Low": 3, "Info": 1}

# Prompt-budget caps: keep the fact sheet compact and cheap even on a large repo.
_MAX_ENTRY_POINTS = 60
_MAX_ASSETS = 40
_MAX_KNOWN_FINDINGS = 60


@dataclass
class ChainStep:
    locus: str
    description: str


@dataclass
class Chain:
    title: str
    narrative: str
    severity: str
    confidence: float
    families: list = field(default_factory=list)
    cwes: list = field(default_factory=list)
    preconditions: str = ""
    business_impact: str = ""
    steps: list = field(default_factory=list)         # list[ChainStep]
    source_loci: list = field(default_factory=list)   # facts cited, for audit
    grounding: float = 1.0    # fraction of steps traceable to a fact we actually supplied

    @property
    def priority(self) -> float:
        return round(_SEV_SCORE.get(self.severity, 1) + self.confidence, 3)


def _coerce_severity(value) -> str:
    text = str(value or "").strip().title()
    return text if text in _SEVERITIES else "Medium"


def _coerce_confidence(value) -> float:
    try:
        c = float(value)
    except (TypeError, ValueError):
        return 0.5
    return round(max(0.0, min(1.0, c)), 3)


def _select_entry_points(surface: list[dict]) -> list[dict]:
    """Rank entry points so a bounded prompt still covers the ones worth chaining."""
    def score(ep):
        return ((0 if ep.get("authenticated") else 2)
                + (2 if ep.get("kind") == "agent-tool" else 0)
                + min(len(ep.get("sinks", []) or []), 3))
    return sorted(surface, key=score, reverse=True)[:_MAX_ENTRY_POINTS]


def _known_loci(categories: list[dict]) -> list[str]:
    """Loci already covered by a single-hop CodeModel finding, so the model steers past them."""
    loci: list[str] = []
    for cat in categories or []:
        if cat.get("_source") != "CODEMODEL":
            continue
        for comp in cat.get("affected_components", []) or []:
            loci.append(str(comp))
    return loci[:_MAX_KNOWN_FINDINGS]


def _extract_bounded(codemodel_report: dict) -> dict:
    """Apply the prompt-budget bounds once so the prompt text and the grounding
    index are built from the *exact same* set of facts — a chain can only be
    verified against what the model actually saw.
    """
    meta = codemodel_report.get("scan_metadata") or {}
    return {
        "surface": _select_entry_points(meta.get("attack_surface") or []),
        "stores": (meta.get("data_stores") or [])[:_MAX_ASSETS],
        "calls": (meta.get("external_calls") or [])[:_MAX_ASSETS],
        "controls": (meta.get("code_controls") or [])[:_MAX_ASSETS],
        "boundaries": meta.get("trust_boundaries") or [],
        "known_findings": _known_loci(codemodel_report.get("categories") or []),
    }


def _fact_locus_index(bounded: dict) -> set[str]:
    """Every literal locus/name string shown to the model, for grounding checks.

    Kept separate from the correlator's ``taxonomy.locus_tokens`` fuzzy matcher:
    that one deliberately discards line numbers to match a static hit against a
    runtime hit at the same *feature*. Here the model was told to copy a
    file:line or name verbatim from a list it was given, so exact-or-substring
    matching against that same list is the right test for "did it invent this".
    """
    index: set[str] = set()

    def add_loc(file, line):
        if file and line is not None:
            index.add(f"{file}:{line}")

    for ep in bounded["surface"]:
        add_loc(ep.get("file"), ep.get("line"))
        if ep.get("handler"):
            index.add(str(ep["handler"]))
        for s in ep.get("sinks") or []:
            add_loc(s.get("file"), s.get("line"))
            if s.get("name"):
                index.add(str(s["name"]))
    for d in bounded["stores"]:
        add_loc(d.get("file"), d.get("line"))
    for c in bounded["calls"]:
        add_loc(c.get("file"), c.get("line"))
        if c.get("target"):
            index.add(str(c["target"]))
    for c in bounded["controls"]:
        if c.get("mechanism"):
            index.add(str(c["mechanism"]))
    return index


_LOCUS_FILE_LINE_RE = re.compile(r"([\w./\\-]+):(\d+)")


def _locus_grounded(locus: str, index: set[str]) -> bool:
    """True when a cited locus is traceable to a fact actually supplied to the model."""
    locus = (locus or "").strip()
    if not locus:
        return False
    if locus in index:
        return True
    m = _LOCUS_FILE_LINE_RE.search(locus)
    if m:
        file_line = f"{m.group(1)}:{m.group(2)}"
        if file_line in index:
            return True
    # Tolerate the model paraphrasing ("handler upload" vs "upload") via
    # substring containment, but only against index entries specific enough
    # that containment isn't a coincidence.
    return any((locus in entry or entry in locus) for entry in index if len(entry) >= 4)


def _grounding_ratio(steps: list[ChainStep], index: set[str]) -> float:
    if not steps:
        return 0.0
    grounded = sum(1 for s in steps if _locus_grounded(s.locus, index))
    return round(grounded / len(steps), 3)


def _facts_text(bounded: dict) -> str:
    surface = bounded["surface"]
    stores = bounded["stores"]
    calls = bounded["calls"]
    controls = bounded["controls"]
    boundaries = bounded["boundaries"]
    known = bounded["known_findings"]

    lines = ["ENTRY POINTS (attack surface):"]
    for ep in surface:
        sinks = ep.get("sinks") or []
        sink_txt = "; ".join(
            f"{s.get('family')} sink '{s.get('name')}' at {s.get('file')}:{s.get('line')}"
            + (" (tainted)" if s.get("tainted") else "")
            for s in sinks) or "no dangerous sink directly reachable"
        ctrl_txt = ", ".join(c.get("mechanism", "") for c in ep.get("controls", []) or []) \
            or "none observed"
        lines.append(
            f"- [{'auth' if ep.get('authenticated') else 'UNAUTH'}] {ep.get('method')} "
            f"{ep.get('path') or ep.get('handler')} (handler {ep.get('handler')}, "
            f"{ep.get('file')}:{ep.get('line')}) · kind={ep.get('kind')} · "
            f"controls: {ctrl_txt} · reaches: {sink_txt}")

    lines.append("\nDATA STORES:")
    for d in stores:
        lines.append(f"- {d.get('kind')}/{d.get('engine')} referenced at "
                      f"{d.get('file')}:{d.get('line')}")

    lines.append("\nEXTERNAL CALLS (cross a trust boundary):")
    for c in calls:
        lines.append(f"- {c.get('kind')} -> {c.get('target')} at {c.get('file')}:{c.get('line')}"
                      + ("" if c.get("encrypted", True) else " [CLEARTEXT]"))

    lines.append("\nGLOBAL CONTROLS OBSERVED:")
    for c in controls:
        lines.append(f"- {c.get('kind')}: {c.get('mechanism')} ({c.get('scope')})")

    lines.append("\nTRUST BOUNDARIES INFERRED:")
    for b in boundaries:
        lines.append(f"- {b.get('name')} ({b.get('kind')}): {b.get('description')}")

    if known:
        lines.append(
            "\nALREADY REPORTED AS A SINGLE-HOP FINDING (do not restate one of these alone as "
            "a chain — you may only reference one as ONE step of a longer chain):")
        for loc in known:
            lines.append(f"- {loc}")

    return "\n".join(lines)


_SYSTEM = (
    "You are a senior red-team-minded security architect. You reason about how an "
    "attacker chains multiple weak facts together across trust boundaries — never "
    "about a single fact in isolation. Respond with valid JSON only — no prose, no "
    "markdown fences."
)

_INSTRUCTIONS = """You are given the code-derived facts of a system: its entry points, the \
sinks they reach, its data stores, its external calls, its observed controls, its \
inferred trust boundaries, and the single-hop findings a reachability engine \
already reported.

Find MULTI-STEP ATTACK CHAINS: sequences that combine TWO OR MORE of these \
facts. Examples of the shape to look for — an unauthenticated entry point that \
writes attacker-controlled data into a store a *different*, more privileged \
entry point later reads or acts on; a missing control at one boundary that \
removes a precondition an attacker needs at another; a sequence of external \
calls that lets an attacker pivot from one trust boundary to another. Every \
step must cite a specific fact (file:line, handler, or store name) from the \
input below — never invent a component that is not listed. A valid chain has \
at least two distinct steps crossing a trust boundary or asset; do not propose \
a chain that just restates one already-reported single-hop finding under a new \
name. If the facts do not support any genuine multi-step chain, return an \
empty chains array rather than forcing one.

Return JSON with this exact structure:
{
  "summary": "1-2 sentence summary of what chains (if any) were found and why they matter",
  "chains": [
    {
      "title": "short attacker-goal-oriented title",
      "narrative": "how an attacker actually walks this chain, step by step, in prose",
      "severity": "Critical|High|Medium|Low",
      "confidence": 0.0,
      "families": ["weakness-family-slug"],
      "cwes": ["CWE-XXX"],
      "preconditions": "what the attacker needs before starting (access, timing, another bug)",
      "business_impact": "what actually breaks if this chain is completed",
      "steps": [
        {"locus": "file:line or handler/store name from the input facts", "description": "what happens at this step"}
      ],
      "source_loci": ["every input fact this chain relies on, for audit"]
    }
  ]
}

Return ONLY the JSON. Facts:
---
"""


def _parse_chains(raw: dict, index: set[str]) -> list[Chain]:
    """Parse the model's chains and verify each against the fact index.

    A chain where *no* step traces to a fact we actually supplied is dropped —
    the whole premise of this engine is reasoning grounded in real extracted
    facts, not free-floating LLM speculation, so an ungrounded chain is worse
    than useless: it would misdirect remediation effort. A partially-grounded
    chain is kept but its confidence is capped at its grounding ratio, so an
    75%-fabricated chain can never outrank a fully-grounded one on priority.
    """
    chains: list[Chain] = []
    raw_chains = raw.get("chains")
    if not isinstance(raw_chains, list):
        return chains
    for c in raw_chains:
        if not isinstance(c, dict):
            continue
        raw_steps = c.get("steps")
        steps = [ChainStep(locus=str(s.get("locus", "")), description=str(s.get("description", "")))
                 for s in raw_steps if isinstance(s, dict)] if isinstance(raw_steps, list) else []
        if len(steps) < 2:
            continue  # not a chain — drop single-step "chains" the model proposed anyway

        grounding = _grounding_ratio(steps, index)
        if grounding == 0.0:
            continue  # no step traces to a supplied fact — treat as fabricated, drop it

        families = c.get("families")
        cwes = c.get("cwes")
        source_loci = c.get("source_loci")
        confidence = min(_coerce_confidence(c.get("confidence")), grounding)
        chains.append(Chain(
            title=str(c.get("title") or "Untitled attack chain")[:200],
            narrative=str(c.get("narrative") or ""),
            severity=_coerce_severity(c.get("severity")),
            confidence=confidence,
            families=[str(f) for f in families][:6] if isinstance(families, list) else [],
            cwes=[str(w) for w in cwes][:6] if isinstance(cwes, list) else [],
            preconditions=str(c.get("preconditions") or ""),
            business_impact=str(c.get("business_impact") or ""),
            steps=steps[:12],
            source_loci=[str(x) for x in source_loci][:20] if isinstance(source_loci, list) else [],
            grounding=grounding,
        ))
    chains.sort(key=lambda c: (-c.priority, c.title))
    return chains


def reason(codemodel_report: dict, api_key: str) -> list[Chain]:
    """Ask an LLM to find multi-step attack chains in a codemodel report's facts.

    Never raises on malformed model output — a hostile or broken JSON response
    degrades to an empty list, same as ``attack_paths`` degrading to no paths
    when there's no exploitability signal. A hypothesis engine that honestly
    finds nothing is a valid result, not a failure.
    """
    if not api_key:
        return []
    surface = (codemodel_report.get("scan_metadata") or {}).get("attack_surface")
    if not surface:
        return []

    bounded = _extract_bounded(codemodel_report)
    dynamic = _wrap_input(_facts_text(bounded))
    raw = call_claude_cached(api_key, _harden_system(_SYSTEM), _INSTRUCTIONS, dynamic,
                              max_tokens=8192, caller="codemodel.chain_reasoning")
    try:
        parsed = _extract_json(raw)
    except ValueError:
        return []
    return _parse_chains(parsed, _fact_locus_index(bounded))


# ── Report rendering ──────────────────────────────────────────────────────────

def _chain_category(idx: int, c: Chain) -> dict:
    threats = [{
        "name": f"Step {i + 1}: {s.locus}",
        "description": s.description,
        "attack_vector": s.locus,
        "control_objective": "",
    } for i, s in enumerate(c.steps)]
    return {
        "id": f"LC-{idx:03d}",
        "category": "LLM Attack-Chain Reasoning",
        "name": c.title,
        "title": c.title,
        "risk": c.severity,
        "risk_score": _SEV_SCORE.get(c.severity, 1),
        "_source": "LLM-CHAIN",
        "ruleset": "ChainReasoning",
        "cwe": c.cwes[0] if c.cwes else "",
        "confidence": c.confidence,
        "grounding": c.grounding,
        "description": c.narrative,
        "affected_components": (c.source_loci or [s.locus for s in c.steps])[:25],
        "mitigation": "Break the chain at its weakest step — usually the earliest missing "
                      "control or the shared asset that lets it cross a trust boundary.",
        "remediation": "Break the chain: harden the earliest step an attacker needs.",
        "mitigations": [{
            "action": "Harden the earliest step in the chain (see steps below).",
            "priority": "Immediate" if c.severity in ("Critical", "High") else "Short-term",
        }],
        "threats": threats,
        "notes": (f"confidence: {c.confidence} · grounding: {c.grounding:.0%} of steps traced "
                  f"to a supplied fact{' — treat remaining steps as unverified LLM inference' if c.grounding < 1.0 else ''} · "
                  f"preconditions: {c.preconditions or 'n/a'} · "
                  f"business impact: {c.business_impact or 'n/a'} · "
                  f"families: {', '.join(c.families) or 'n/a'} · "
                  "hypothesized by LLM reasoning over code-derived facts — corroborate with "
                  "SAST/DAST/runtime evidence via the correlator before treating as confirmed."),
    }


def to_report(chains: list[Chain], sources: list[dict], meta: dict) -> dict:
    categories = [_chain_category(i + 1, c) for i, c in enumerate(chains)]
    overall = "Info"
    for c in chains:
        if _SEV_ORDER.get(c.severity, 9) < _SEV_ORDER.get(overall, 9):
            overall = c.severity
    counts = {s: sum(1 for c in chains if c.severity == s) for s in _SEVERITIES}

    if chains:
        summary = (f"LLM reasoning proposed {len(chains)} multi-step attack chain(s) over the "
                    "code-derived facts: "
                    + ", ".join(f"{counts[s]} {s}" for s in _SEVERITIES if counts[s]) + ".")
    else:
        summary = ("LLM reasoning found no multi-step attack chain beyond what the "
                    "reachability engine already reports.")

    return {
        "title": meta.get("report_title") or "LLM Attack-Chain Reasoning",
        "methodology": "chainreasoning",
        "methodology_label": "LLM Attack-Chain Reasoning",
        "overall_risk": overall,
        "aggregate_risk": overall,
        "summary": summary,
        "categories": categories,
        "recommendations": [
            "Treat each chain as a hypothesis: corroborate it with SAST/DAST/runtime "
            "evidence via the correlator before prioritizing remediation on LLM "
            "confidence alone.",
            "Chains that cross a trust boundary are usually broken cheapest at the "
            "earliest step — fix the entry, not the sink.",
        ] if chains else [],
        "scan_metadata": {
            "engine": "chainreasoning",
            "sources": sources,
            "chains_total": len(chains),
            "severity_counts": counts,
            "avg_grounding": round(sum(c.grounding for c in chains) / len(chains), 3)
                            if chains else None,
            "fully_grounded": sum(1 for c in chains if c.grounding >= 1.0),
            "partially_grounded": sum(1 for c in chains if c.grounding < 1.0),
        },
    }
