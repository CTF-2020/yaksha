"""Portal navigation API.

Read-only JSON mirror of portal_nav.py — the same data the server-rendered
navbars use — so external consumers (CLIs, integrations, tests) can discover
the portal surface without scraping HTML.

Routes:
  GET /api/v1/nav   {"success": true, "items": [...], "use_cases": [...]}
"""
from __future__ import annotations

from flask import Blueprint, jsonify

import auth
import portal_nav

bp = Blueprint("nav_api", __name__, url_prefix="/api/v1/nav")


@bp.get("")
def get_nav():
    is_admin = auth.is_admin()
    items = [i for i in portal_nav.NAV_ITEMS if not i.get("admin_only") or is_admin]
    return jsonify({
        "success": True,
        "items": items,
        "use_cases": portal_nav.USE_CASES,
        "manifest": "/api/v1",
    })
