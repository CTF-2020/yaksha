"""dast/validate.py — attack-path validation from a completed DAST scan.

``codemodel`` + ``attack_paths`` already synthesize *candidate* exploit
chains from static reachability alone. A DAST scan of the same running
application is the one source that can move a candidate from "reachable" to
"confirmed" — proof an unauthenticated, tainted sink is not just wired up in
the call graph but actually exploitable from the outside, right now, in the
deployed target.

This module is the missing link, not a new correlation engine: ``attack_paths``
and the correlator already treat any category tagged ``_source: "DAST"`` as
runtime evidence (see ``attack_paths._index_evidence`` / ``correlator.engine.
_source_kind``). What's missing is resolving "which codemodel report is this
DAST scan validating" — done by matching the target's registered source repo
against the SAST broker's repo registry, the exact same GitHub owner/repo
matching :func:`broker.config.find_repo_for_github` already uses to route
webhooks — and then wiring the two together automatically after every scan
(see :func:`dast.service.DastService._run`), so "continuous" is real: every
successful deployment scan re-validates attack paths with fresh evidence
without anyone asking it to.
"""
from __future__ import annotations

import attack_paths
from broker import config as broker_config

from . import config


def repo_id_for_target(target: dict) -> str | None:
    """The SAST-broker repo id this DAST target's application was built from,
    resolved from the target's registered source-repo link. None when the
    target has no repo link, or the link doesn't match a registered repo."""
    full_name = (target.get("github_full_name") or "").strip().lower()
    if not full_name:
        full_name = config.github_full_name_from_url(target.get("repo_url", "")) or ""
    if not full_name:
        return None
    repo = broker_config.find_repo_for_github(full_name)
    return repo.get("id") if repo else None


def latest_codemodel_report(repo_id: str) -> dict | None:
    """Most recent saved codemodel report for this repo, or None if it has
    never been scanned."""
    import report_db
    for r in report_db.all_reports():
        if (str(r.get("methodology", "")).lower() == "codemodel"
                and (r.get("scan_metadata") or {}).get("repo_id") == repo_id):
            return r
    return None


def validate(dast_report: dict, target: dict) -> dict | None:
    """Synthesize attack paths for this target's repo, using ``dast_report``
    as runtime evidence. Returns the finished report, or None when there is
    nothing to validate against yet (no linked repo, or that repo has never
    had a code-derived threat model run) — a silent no-op, not an error, since
    most targets won't have a linked repo scanned yet and that is a normal,
    expected state rather than a failure.
    """
    repo_id = repo_id_for_target(target)
    if not repo_id:
        return None
    cm_report = latest_codemodel_report(repo_id)
    if cm_report is None:
        return None

    paths = attack_paths.synthesize(cm_report, [dast_report])
    sources = [
        {"id": cm_report.get("id"), "title": cm_report.get("title"), "role": "codemodel"},
        {"id": dast_report.get("id"), "title": dast_report.get("title"), "role": "evidence"},
    ]
    meta = {"report_title": f"Attack Paths (validated) · {target.get('name') or repo_id}"}
    return attack_paths.to_report(paths, sources, meta)
