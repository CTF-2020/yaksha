"""Tests for the read-side fetch functions added to jira_client.py
(get_issue, get_issue_comments, search_issues, get_confluence_page,
search_confluence_pages, confluence_html_to_text) and their API routes in
api/ticket_fetch.py.

Module-level tests mock jira_client._http (no real HTTP calls), same spirit
as test_ticketing_connectors.py. API tests use the Flask test client and
mock jira_client's fetch functions directly to isolate routing/validation
from the HTTP-mocking already covered at the module level.
"""
from __future__ import annotations

import unittest
from unittest import mock

import jira_client


def _jira_cfg():
    return jira_client.TicketConfig(
        provider="jira", jira_url="https://example.atlassian.net",
        jira_email="bot@example.com", jira_token="tok123", jira_project_key="SEC")


def _confluence_cfg():
    return jira_client.TicketConfig(
        provider="confluence", confluence_base_url="https://example.atlassian.net",
        confluence_email="bot@example.com", confluence_api_token="tok123",
        confluence_space_key="SEC")


_FAKE_ISSUE = {
    "key": "SEC-101",
    "fields": {
        "summary": "Open redirect in login flow",
        "description": {"type": "doc", "version": 1, "content": [
            {"type": "paragraph", "content": [{"type": "text", "text": "Service reads a redirect param."}]},
        ]},
        "status": {"name": "In Progress"},
        "priority": {"name": "High"},
        "issuetype": {"name": "Bug"},
        "assignee": {"displayName": "Alice"},
        "reporter": {"displayName": "Bob"},
        "labels": ["security"],
        "components": [{"name": "auth"}],
        "created": "2026-01-01T00:00:00.000+0000",
        "updated": "2026-01-02T00:00:00.000+0000",
        "resolution": None,
    },
}

_FAKE_COMMENTS = {
    "comments": [
        {"id": "1", "author": {"displayName": "Alice"}, "body": "Looking into it.",
         "created": "2026-01-01T01:00:00.000+0000", "updated": "2026-01-01T01:00:00.000+0000"},
    ]
}

_FAKE_SEARCH = {"issues": [_FAKE_ISSUE]}

_FAKE_PAGE = {
    "id": "12345",
    "title": "Payments architecture",
    "space": {"key": "SEC"},
    "version": {"number": 3, "when": "2026-01-02T00:00:00.000Z"},
    "body": {"storage": {"value": "<p>The service <b>never</b> logs card numbers.</p>"}},
    "_links": {"webui": "/spaces/SEC/pages/12345/Payments"},
}

_FAKE_PAGE_SEARCH = {
    "results": [
        {"id": "12345", "title": "Payments architecture", "type": "page",
         "_links": {"webui": "/spaces/SEC/pages/12345/Payments"}},
    ]
}


class AdfToTextTests(unittest.TestCase):
    def test_plain_string_passthrough(self):
        self.assertEqual(jira_client.adf_to_text("hi"), "hi")

    def test_none_is_empty(self):
        self.assertEqual(jira_client.adf_to_text(None), "")


class GetIssueTests(unittest.TestCase):
    def test_normalizes_fields(self):
        with mock.patch.object(jira_client, "_http", return_value=_FAKE_ISSUE) as http:
            issue = jira_client.get_issue(_jira_cfg(), "SEC-101")
        self.assertEqual(issue["key"], "SEC-101")
        self.assertEqual(issue["url"], "https://example.atlassian.net/browse/SEC-101")
        self.assertIn("redirect param", issue["description"])
        self.assertEqual(issue["status"], "In Progress")
        self.assertEqual(issue["priority"], "High")
        self.assertEqual(issue["assignee"], "Alice")
        self.assertEqual(issue["labels"], ["security"])
        self.assertEqual(issue["components"], ["auth"])
        method, url, headers = http.call_args[0]
        self.assertEqual(method, "GET")
        self.assertIn("/rest/api/3/issue/SEC-101", url)

    def test_wrong_provider_rejected(self):
        with self.assertRaises(ValueError):
            jira_client.get_issue(_confluence_cfg(), "SEC-101")


class GetIssueCommentsTests(unittest.TestCase):
    def test_normalizes_comments(self):
        with mock.patch.object(jira_client, "_http", return_value=_FAKE_COMMENTS):
            comments = jira_client.get_issue_comments(_jira_cfg(), "SEC-101")
        self.assertEqual(len(comments), 1)
        self.assertEqual(comments[0]["author"], "Alice")
        self.assertEqual(comments[0]["body"], "Looking into it.")

    def test_max_results_clamped(self):
        with mock.patch.object(jira_client, "_http", return_value=_FAKE_COMMENTS) as http:
            jira_client.get_issue_comments(_jira_cfg(), "SEC-101", max_results=10_000)
        _, url, _ = http.call_args[0]
        self.assertIn("maxResults=200", url)


class SearchIssuesTests(unittest.TestCase):
    def test_returns_normalized_issues(self):
        with mock.patch.object(jira_client, "_http", return_value=_FAKE_SEARCH) as http:
            issues = jira_client.search_issues(_jira_cfg(), "project = SEC")
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["key"], "SEC-101")
        method, url, headers = http.call_args[0]
        self.assertIn("/rest/api/3/search", url)
        self.assertIn("jql=project", url)


class ConfluenceHtmlToTextTests(unittest.TestCase):
    def test_strips_tags(self):
        text = jira_client.confluence_html_to_text("<p>The service <b>never</b> logs cards.</p>")
        self.assertEqual(text, "The service never logs cards.")

    def test_empty_input(self):
        self.assertEqual(jira_client.confluence_html_to_text(""), "")

    def test_malformed_markup_does_not_raise(self):
        # Best-effort: an unterminated tag shouldn't take the whole fetch down.
        text = jira_client.confluence_html_to_text("<p>unterminated")
        self.assertIn("unterminated", text)


class GetConfluencePageTests(unittest.TestCase):
    def test_normalizes_page(self):
        with mock.patch.object(jira_client, "_http", return_value=_FAKE_PAGE):
            page = jira_client.get_confluence_page(_confluence_cfg(), "12345")
        self.assertEqual(page["id"], "12345")
        self.assertEqual(page["title"], "Payments architecture")
        self.assertEqual(page["space_key"], "SEC")
        self.assertEqual(page["version"], 3)
        self.assertIn("never", page["body_text"])
        self.assertNotIn("<b>", page["body_text"])
        self.assertEqual(page["url"],
                         "https://example.atlassian.net/spaces/SEC/pages/12345/Payments")

    def test_wrong_provider_rejected(self):
        with self.assertRaises(ValueError):
            jira_client.get_confluence_page(_jira_cfg(), "12345")


class SearchConfluencePagesTests(unittest.TestCase):
    def test_returns_lightweight_rows(self):
        with mock.patch.object(jira_client, "_http", return_value=_FAKE_PAGE_SEARCH) as http:
            pages = jira_client.search_confluence_pages(_confluence_cfg(), 'space = "SEC"')
        self.assertEqual(len(pages), 1)
        self.assertEqual(pages[0]["id"], "12345")
        self.assertEqual(pages[0]["title"], "Payments architecture")
        method, url, headers = http.call_args[0]
        self.assertIn("/wiki/rest/api/content/search", url)


class TicketFetchApiTests(unittest.TestCase):
    """Routing/validation only -- jira_client's fetch functions are mocked
    directly here, since the HTTP-shape-level behavior is already covered
    above."""

    @classmethod
    def setUpClass(cls):
        import app as tm_app
        cls.client = tm_app.app.test_client()

    def setUp(self):
        # Make the "is it configured" checks pass without touching the real
        # settings store or environment.
        patcher = mock.patch("api.ticket_fetch._jira_cfg", return_value=_jira_cfg())
        patcher.start()
        self.addCleanup(patcher.stop)
        patcher2 = mock.patch("api.ticket_fetch._confluence_cfg", return_value=_confluence_cfg())
        patcher2.start()
        self.addCleanup(patcher2.stop)

    def test_get_issue_endpoint(self):
        with mock.patch.object(jira_client, "get_issue", return_value={"key": "SEC-101"}):
            resp = self.client.get("/api/v1/jira/issues/SEC-101")
        self.assertEqual(resp.status_code, 200)
        d = resp.get_json()
        self.assertTrue(d["success"])
        self.assertEqual(d["issue"]["key"], "SEC-101")

    def test_get_issue_rejects_bad_key(self):
        resp = self.client.get("/api/v1/jira/issues/not a key")
        self.assertEqual(resp.status_code, 400)

    def test_get_issue_404_passthrough(self):
        with mock.patch.object(jira_client, "get_issue",
                               side_effect=RuntimeError("HTTP 404 Not Found: {}")):
            resp = self.client.get("/api/v1/jira/issues/SEC-999")
        self.assertEqual(resp.status_code, 404)

    def test_get_issue_comments_endpoint(self):
        with mock.patch.object(jira_client, "get_issue_comments",
                               return_value=[{"id": "1", "body": "hi"}]):
            resp = self.client.get("/api/v1/jira/issues/SEC-101/comments")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(resp.get_json()["comments"]), 1)

    def test_search_issues_endpoint_requires_jql(self):
        resp = self.client.get("/api/v1/jira/search")
        self.assertEqual(resp.status_code, 400)

    def test_search_issues_endpoint(self):
        with mock.patch.object(jira_client, "search_issues",
                               return_value=[{"key": "SEC-101"}]):
            resp = self.client.get("/api/v1/jira/search?jql=project=SEC")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(resp.get_json()["issues"]), 1)

    def test_get_page_endpoint(self):
        with mock.patch.object(jira_client, "get_confluence_page",
                               return_value={"id": "12345", "title": "x"}):
            resp = self.client.get("/api/v1/confluence/pages/12345")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_json()["page"]["id"], "12345")

    def test_get_page_rejects_non_numeric_id(self):
        resp = self.client.get("/api/v1/confluence/pages/abc")
        self.assertEqual(resp.status_code, 400)

    def test_search_pages_endpoint_requires_cql(self):
        resp = self.client.get("/api/v1/confluence/search")
        self.assertEqual(resp.status_code, 400)

    def test_search_pages_endpoint(self):
        with mock.patch.object(jira_client, "search_confluence_pages",
                               return_value=[{"id": "12345", "title": "x"}]):
            resp = self.client.get('/api/v1/confluence/search?cql=space="SEC"')
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(resp.get_json()["pages"]), 1)

    def test_unconfigured_jira_returns_400(self):
        with mock.patch("api.ticket_fetch._jira_cfg",
                        return_value=jira_client.TicketConfig(provider="jira")):
            resp = self.client.get("/api/v1/jira/issues/SEC-101")
        self.assertEqual(resp.status_code, 400)

    def test_unconfigured_confluence_returns_400(self):
        with mock.patch("api.ticket_fetch._confluence_cfg",
                        return_value=jira_client.TicketConfig(provider="confluence")):
            resp = self.client.get("/api/v1/confluence/pages/12345")
        self.assertEqual(resp.status_code, 400)


if __name__ == "__main__":
    unittest.main()
