"""claude_client.py — Shared Anthropic SDK client with prompt caching, retry,
and token-usage/cost tracking."""
from __future__ import annotations
import logging
import time
import anthropic

MODEL = "claude-sonnet-4-6"
log = logging.getLogger(__name__)

_RETRYABLE = (anthropic.RateLimitError, anthropic.APIStatusError)
_MAX_RETRIES = 4
_BASE_DELAY = 1.0

# $ per 1M tokens. Cache write/read follow Anthropic's standard cache pricing
# (1.25x / 0.1x the base input rate) -- the Messages API usage object doesn't
# carry per-model cache rates, only token counts. An unpriced model (MODEL
# changed without updating this table) costs $0.00 rather than raising --
# cost tracking must never be the reason an analysis fails.
PRICING = {
    "claude-sonnet-4-6": {"input": 3.00, "output": 15.00, "cache_write": 3.75, "cache_read": 0.30},
}


def _cost_usd(model: str, usage) -> float:
    rates = PRICING.get(model)
    if not rates or usage is None:
        return 0.0
    return (
        getattr(usage, "input_tokens", 0) * rates["input"]
        + getattr(usage, "output_tokens", 0) * rates["output"]
        + getattr(usage, "cache_creation_input_tokens", 0) * rates["cache_write"]
        + getattr(usage, "cache_read_input_tokens", 0) * rates["cache_read"]
    ) / 1_000_000


def _record_usage(model: str, caller: str, usage) -> None:
    """Best-effort usage logging -- never let a tracking failure break the
    caller's actual (already-successful) LLM call."""
    if usage is None:
        return
    try:
        import llm_usage_db
        llm_usage_db.record_call(
            model=model,
            caller=caller,
            input_tokens=getattr(usage, "input_tokens", 0) or 0,
            output_tokens=getattr(usage, "output_tokens", 0) or 0,
            cache_creation_input_tokens=getattr(usage, "cache_creation_input_tokens", 0) or 0,
            cache_read_input_tokens=getattr(usage, "cache_read_input_tokens", 0) or 0,
            cost_usd=_cost_usd(model, usage),
        )
    except Exception:
        log.warning("llm usage logging failed", exc_info=True)


def _with_backoff(fn):
    """Call fn(), retrying on rate-limit/server errors with exponential backoff."""
    delay = _BASE_DELAY
    for attempt in range(_MAX_RETRIES):
        try:
            return fn()
        except anthropic.RateLimitError as exc:
            if attempt == _MAX_RETRIES - 1:
                raise
            log.warning("Rate limited, retrying in %.1fs (attempt %d/%d)", delay, attempt + 1, _MAX_RETRIES)
            time.sleep(delay)
            delay = min(delay * 2, 60.0)
        except anthropic.APIStatusError as exc:
            if exc.status_code < 500 or attempt == _MAX_RETRIES - 1:
                raise
            log.warning("Server error %d, retrying in %.1fs", exc.status_code, delay)
            time.sleep(delay)
            delay = min(delay * 2, 60.0)


def call_claude(
    api_key: str,
    system: str,
    user: str,
    max_tokens: int = 8192,
    caller: str = "",
) -> str:
    """Call Claude with ephemeral cache on the system prompt.

    caller is a short dotted tag identifying the feature making the call
    (e.g. "diagram.dfd") -- logged against the usage ledger (llm_usage_db)
    so spend is attributable per feature, not just in aggregate.
    """
    client = anthropic.Anthropic(api_key=api_key)

    def _call():
        message = client.messages.create(
            model=MODEL,
            max_tokens=max_tokens,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            messages=[{"role": "user", "content": user}],
        )
        _record_usage(MODEL, caller, getattr(message, "usage", None))
        return message.content[0].text

    return _with_backoff(_call)


def call_claude_cached(
    api_key: str,
    system: str,
    static_prefix: str,
    dynamic_suffix: str,
    max_tokens: int = 8192,
    caller: str = "",
) -> str:
    """Call Claude with cache on both the system prompt and the static user prefix.

    The static_prefix (knowledge base + schema) is cached; dynamic_suffix (architecture
    text) is not. This cuts ~90% of input tokens on repeated analyses.

    caller is a short dotted tag identifying the feature making the call
    (e.g. "analyzer.owasp") -- logged against the usage ledger (llm_usage_db)
    so spend is attributable per feature, not just in aggregate.
    """
    client = anthropic.Anthropic(api_key=api_key)

    def _call():
        message = client.messages.create(
            model=MODEL,
            max_tokens=max_tokens,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": static_prefix, "cache_control": {"type": "ephemeral"}},
                    {"type": "text", "text": dynamic_suffix},
                ],
            }],
        )
        _record_usage(MODEL, caller, getattr(message, "usage", None))
        return message.content[0].text

    return _with_backoff(_call)
