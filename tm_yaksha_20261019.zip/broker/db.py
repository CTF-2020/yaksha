"""SQLite store for the SAST broker — the system of record for the repo
registry, job history, PR-delta baselines, and the scanned-SHA cache.

Repos and jobs are opaque, evolving dicts (github tokens, webhook secrets,
per-job log/progress/stats...), so each is kept as a JSON blob column, same
philosophy as ``report_db.reports.data`` — only the columns actually needed
for lookups/ordering are broken out. :mod:`broker.config` remains the public
surface every caller uses; this module is purely the persistence plumbing
behind it, and also mirrors every write to the legacy JSON files as a
best-effort backup.

Stdlib ``sqlite3`` only, mirroring :mod:`report_db`'s pattern: connection-per-
call with WAL + a busy timeout, and an idempotent :func:`init` so ``DB_PATH``
can be repointed by tests without any "already initialized" staleness.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import closing
from pathlib import Path

from . import config

DB_PATH = config.STATE_DIR / "broker.db"

_init_lock = threading.Lock()
_SHA_CACHE_MAX = 2000

_SCHEMA = """
CREATE TABLE IF NOT EXISTS repos (
    id          TEXT PRIMARY KEY,
    data        TEXT NOT NULL,
    created_at  REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS jobs (
    id          TEXT PRIMARY KEY,
    repo_id     TEXT,
    started_at  TEXT,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_broker_jobs_repo ON jobs(repo_id);
CREATE TABLE IF NOT EXISTS baselines (
    repo_id     TEXT NOT NULL,
    branch      TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    PRIMARY KEY (repo_id, branch, fingerprint)
);
CREATE TABLE IF NOT EXISTS sha_cache (
    repo_id     TEXT NOT NULL,
    sha         TEXT NOT NULL,
    report_id   TEXT NOT NULL,
    inserted_at REAL DEFAULT 0,
    PRIMARY KEY (repo_id, sha)
);
CREATE INDEX IF NOT EXISTS ix_broker_sha_cache_inserted ON sha_cache(inserted_at);
"""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init() -> None:
    with _init_lock:
        with closing(_connect()) as conn, conn:
            conn.executescript(_SCHEMA)


# ── Repo registry ─────────────────────────────────────────────────────────────
def load_repos() -> list[dict]:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT data FROM repos ORDER BY created_at DESC, rowid DESC").fetchall()
    return [json.loads(r["data"]) for r in rows]


def save_repos(repos: list[dict]) -> None:
    """Replace the full registry (used by callers that hold the whole list)."""
    init()
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM repos")
        conn.executemany(
            "INSERT INTO repos(id,data,created_at) VALUES (?,?,?)",
            [(r.get("id"), json.dumps(r, ensure_ascii=False), _created_at(r))
             for r in repos if r.get("id")])


def upsert_repo(entry: dict) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM repos WHERE id = ?", (entry["id"],))
        conn.execute(
            "INSERT INTO repos(id,data,created_at) VALUES (?,?,?)",
            (entry["id"], json.dumps(entry, ensure_ascii=False), _created_at(entry)))


def remove_repo(repo_id: str) -> bool:
    init()
    with closing(_connect()) as conn, conn:
        cur = conn.execute("DELETE FROM repos WHERE id = ?", (repo_id,))
        return cur.rowcount > 0


def _created_at(repo: dict) -> float:
    import time
    val = repo.get("created_at") or repo.get("registered_at")
    try:
        return float(val) if val else time.time()
    except (TypeError, ValueError):
        return time.time()


# ── Job history ───────────────────────────────────────────────────────────────
def load_jobs() -> list[dict]:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT data FROM jobs ORDER BY started_at DESC, rowid DESC").fetchall()
    return [json.loads(r["data"]) for r in rows]


def save_jobs(jobs: list[dict]) -> None:
    """Replace the full job history (the service always passes its complete,
    already-trimmed, in-memory set)."""
    init()
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM jobs")
        conn.executemany(
            "INSERT INTO jobs(id,repo_id,started_at,data) VALUES (?,?,?,?)",
            [(j.get("id"), j.get("repo_id"), str(j.get("started_at") or ""),
              json.dumps(j, ensure_ascii=False))
             for j in jobs if j.get("id")])


# ── Baselines (per repo + branch fingerprint sets) ────────────────────────────
def load_baseline(repo_id: str, branch: str) -> set:
    init()
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT fingerprint FROM baselines WHERE repo_id = ? AND branch = ?",
            (repo_id, branch)).fetchall()
    return {r["fingerprint"] for r in rows}


def save_baseline(repo_id: str, branch: str, fingerprints: set) -> None:
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "DELETE FROM baselines WHERE repo_id = ? AND branch = ?", (repo_id, branch))
        conn.executemany(
            "INSERT INTO baselines(repo_id,branch,fingerprint) VALUES (?,?,?)",
            [(repo_id, branch, fp) for fp in fingerprints])


# ── Scanned-SHA cache (repo_id + sha -> report_id) ────────────────────────────
def sha_cache_get(repo_id: str, sha: str) -> str | None:
    init()
    with closing(_connect()) as conn:
        row = conn.execute(
            "SELECT report_id FROM sha_cache WHERE repo_id = ? AND sha = ?",
            (repo_id, sha)).fetchone()
    return row["report_id"] if row else None


def sha_cache_put(repo_id: str, sha: str, report_id: str) -> None:
    import time
    init()
    with closing(_connect()) as conn, conn:
        conn.execute(
            "INSERT OR REPLACE INTO sha_cache(repo_id,sha,report_id,inserted_at)"
            " VALUES (?,?,?,?)", (repo_id, sha, report_id, time.time()))
        # Bound the cache: keep only the most recently inserted entries.
        conn.execute(
            "DELETE FROM sha_cache WHERE rowid IN ("
            " SELECT rowid FROM sha_cache ORDER BY inserted_at DESC, rowid DESC"
            " LIMIT -1 OFFSET ?)", (_SHA_CACHE_MAX,))


# ── Backfill ──────────────────────────────────────────────────────────────────
def backfill(repos: list[dict], jobs: list[dict],
             baselines: list[tuple], sha_cache: dict) -> int:
    """Import a pre-existing JSON-only install's state once, on first boot
    after upgrading. Never touches the JSON files. Returns a rough count of
    records imported, for logging."""
    n = 0
    for r in repos:
        if isinstance(r, dict) and r.get("id"):
            upsert_repo(r)
            n += 1
    if jobs:
        save_jobs(jobs)
        n += len(jobs)
    for repo_id, branch, fingerprints in baselines:
        if fingerprints:
            save_baseline(repo_id, branch, fingerprints)
            n += len(fingerprints)
    for key, report_id in (sha_cache or {}).items():
        if ":" in key:
            repo_id, sha = key.split(":", 1)
            sha_cache_put(repo_id, sha, report_id)
            n += 1
    return n


def repo_count() -> int:
    init()
    with closing(_connect()) as conn:
        return conn.execute("SELECT COUNT(*) FROM repos").fetchone()[0]


def clear_history() -> int:
    """Wipe job history, PR-delta baselines, and the scanned-SHA cache.
    Deliberately leaves the `repos` registry alone — that's registration
    config, not scan data, so an admin flush shouldn't force re-adding every
    repo. Returns the number of jobs removed."""
    init()
    with closing(_connect()) as conn, conn:
        n = conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
        conn.execute("DELETE FROM jobs")
        conn.execute("DELETE FROM baselines")
        conn.execute("DELETE FROM sha_cache")
    return n
