"""Tests for assetgraph.service (direct) and the /api/v1/assetgraph API (Flask).

Mirrors test_lineage_service.py's isolation approach: report_db is used
through the app's real save path in the API class (matching the established
test_attack_paths.py / test_chain_reasoning.py pattern), report_db.DB_PATH is
swapped directly in the direct-service class, and assetgraph.db's own store
is always repointed to a temp file so no test touches the real
~/.tm_assetgraph.db.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from assetgraph import db, service


def _codemodel_report(rid, repo_id, target="payments-api.internal", with_upload=True):
    surface = []
    if with_upload:
        surface.append({"method": "POST", "path": "/upload", "handler": "upload",
                        "file": "h.py", "line": 3, "framework": "flask",
                        "authenticated": False, "kind": "http", "controls": [], "sinks": []})
    return {
        "id": rid, "title": f"Code Model {repo_id}", "methodology": "codemodel",
        "scan_metadata": {
            "repo_id": repo_id, "repo_name": repo_id,
            "frameworks": ["flask"], "languages": ["python"],
            "attack_surface": surface,
            "data_stores": [{"kind": "sql", "engine": "postgres", "file": "db.py", "line": 1}],
            "external_calls": [{"kind": "http", "target": target, "file": "c.py",
                                "line": 5, "encrypted": True}],
            "trust_boundaries": [{"name": "Client ↔ Application", "kind": "network",
                                  "description": "d"}],
        },
    }


class TestAssetGraphServiceDirect(unittest.TestCase):
    def setUp(self):
        self._orig_db_path = db.DB_PATH
        self._td = tempfile.TemporaryDirectory()
        db.DB_PATH = Path(self._td.name) / "assetgraph.db"

        import report_db
        self._orig_report_path = report_db.DB_PATH
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        self.report_db = report_db

    def tearDown(self):
        db.DB_PATH = self._orig_db_path
        self.report_db.DB_PATH = self._orig_report_path
        self._td.cleanup()

    def test_sync_unknown_report_raises(self):
        with self.assertRaises(ValueError):
            service.sync("nonexistent")

    def test_sync_rejects_non_codemodel_report(self):
        self.report_db.upsert_report({"id": "report_r1", "methodology": "owasp", "categories": []})
        with self.assertRaises(ValueError):
            service.sync("report_r1")

    def test_first_sync_creates_all_asset_kinds(self):
        self.report_db.upsert_report(_codemodel_report("report_r1", "repo-a"))
        summary = service.sync("report_r1")
        self.assertEqual(summary["assets_created"], 5)   # repo + ep + store + ext + boundary
        self.assertEqual(summary["edges_staled"], 0)

        kinds = {a["kind"] for a in service.list_assets()}
        self.assertEqual(kinds, {"repo", "entry_point", "data_store",
                                 "external_service", "trust_boundary"})

    def test_rescan_without_an_entry_point_stales_only_that_edge(self):
        self.report_db.upsert_report(_codemodel_report("report_r1", "repo-a", with_upload=True))
        service.sync("report_r1")

        self.report_db.upsert_report(_codemodel_report("report_r2", "repo-a", with_upload=False))
        summary = service.sync("report_r2")
        self.assertEqual(summary["edges_staled"], 1)

        entry_points = [a for a in service.list_assets(kind="entry_point")]
        self.assertEqual(len(entry_points), 1)
        detail = service.get_asset(entry_points[0]["id"])
        self.assertFalse(detail["active"])   # its only edge is now stale

        # the data store / external service / trust boundary are unaffected
        stores = [a for a in service.list_assets(kind="data_store")]
        self.assertTrue(service.get_asset(stores[0]["id"])["active"])

    def test_edge_reactivates_if_asset_reappears_in_a_later_scan(self):
        self.report_db.upsert_report(_codemodel_report("report_r1", "repo-a", with_upload=True))
        service.sync("report_r1")
        self.report_db.upsert_report(_codemodel_report("report_r2", "repo-a", with_upload=False))
        service.sync("report_r2")
        self.report_db.upsert_report(_codemodel_report("report_r3", "repo-a", with_upload=True))
        summary = service.sync("report_r3")
        self.assertEqual(summary["edges_reactivated"], 1)

        entry_points = service.list_assets(kind="entry_point")
        self.assertTrue(service.get_asset(entry_points[0]["id"])["active"])

    def test_shared_external_service_merges_across_repos(self):
        self.report_db.upsert_report(_codemodel_report("report_r1", "repo-a", target="shared.internal"))
        self.report_db.upsert_report(_codemodel_report("report_r2", "repo-b", target="shared.internal"))
        service.sync("report_r1")
        service.sync("report_r2")

        ext_services = service.list_assets(kind="external_service")
        self.assertEqual(len(ext_services), 1)   # one shared node, not two

        repos = service.connected_repos(ext_services[0]["id"])
        self.assertEqual({r["repo_name"] for r in repos}, {"repo-a", "repo-b"})

    def test_rescanning_one_repo_does_not_touch_another_repos_edges(self):
        self.report_db.upsert_report(_codemodel_report("report_r1", "repo-a", target="shared.internal"))
        self.report_db.upsert_report(_codemodel_report("report_r2", "repo-b", target="shared.internal"))
        service.sync("report_r1")
        service.sync("report_r2")

        # Rescan repo-a with the external call removed entirely.
        stripped = _codemodel_report("report_r3", "repo-a", target="shared.internal")
        stripped["scan_metadata"]["external_calls"] = []
        self.report_db.upsert_report(stripped)
        service.sync("report_r3")

        ext_services = service.list_assets(kind="external_service")
        repos = service.connected_repos(ext_services[0]["id"])
        # repo-a's edge is now stale (excluded from the active-only default);
        # repo-b's is untouched.
        self.assertEqual({r["repo_name"] for r in repos}, {"repo-b"})

    def test_status_summary(self):
        self.report_db.upsert_report(_codemodel_report("report_r1", "repo-a"))
        service.sync("report_r1")
        s = service.status()
        self.assertEqual(s["assets"], 5)
        self.assertEqual(s["assets_by_kind"]["repo"], 1)


class TestAssetGraphApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN

        cls._orig_db_path = db.DB_PATH
        cls._td = tempfile.TemporaryDirectory()
        db.DB_PATH = Path(cls._td.name) / "assetgraph_api.db"

        cls._saved = []
        cls.cm_id = tm_app._save_report(_codemodel_report("x", "repo-api-test"),
                                        "Assetgraph API fixture")
        cls._saved.append(cls.cm_id)

    @classmethod
    def tearDownClass(cls):
        for rid in cls._saved:
            cls.client.delete(f"/api/v1/reports/{rid}", headers={"X-CSRF-Token": cls.csrf})
        db.DB_PATH = cls._orig_db_path
        cls._td.cleanup()

    def _sync(self, report_id):
        return self.client.post("/api/v1/assetgraph/sync", json={"report_id": report_id},
                                headers={"X-CSRF-Token": self.csrf})

    def test_missing_report_id_rejected(self):
        r = self.client.post("/api/v1/assetgraph/sync", json={},
                             headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 400)

    def test_unknown_report_id_404(self):
        r = self._sync("nonexistent_1_00")
        self.assertEqual(r.status_code, 404)

    def test_sync_list_get_and_repos_roundtrip(self):
        r = self._sync(self.cm_id)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        self.assertEqual(r.get_json()["assets_created"], 5)

        listed = self.client.get("/api/v1/assetgraph/assets?kind=repo").get_json()
        self.assertTrue(listed["success"])
        self.assertEqual(len(listed["assets"]), 1)
        repo_id = listed["assets"][0]["id"]

        detail = self.client.get(f"/api/v1/assetgraph/assets/{repo_id}").get_json()
        self.assertTrue(detail["success"])
        self.assertIn("outgoing_edges", detail["asset"])

        ext = self.client.get("/api/v1/assetgraph/assets?kind=external_service").get_json()
        ext_id = ext["assets"][0]["id"]
        repos = self.client.get(f"/api/v1/assetgraph/assets/{ext_id}/repos").get_json()
        self.assertTrue(repos["success"])
        self.assertEqual(len(repos["repos"]), 1)

    def test_invalid_kind_filter_rejected(self):
        r = self.client.get("/api/v1/assetgraph/assets?kind=bogus")
        self.assertEqual(r.status_code, 400)

    def test_unknown_asset_404(self):
        r = self.client.get("/api/v1/assetgraph/assets/nonexistent")
        self.assertEqual(r.status_code, 404)

    def test_unknown_asset_repos_404(self):
        r = self.client.get("/api/v1/assetgraph/assets/nonexistent/repos")
        self.assertEqual(r.status_code, 404)

    def test_status_endpoint(self):
        r = self.client.get("/api/v1/assetgraph")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.get_json()["success"])


if __name__ == "__main__":
    unittest.main()
