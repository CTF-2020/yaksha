"""Tests for lineage.service (direct) and the /api/v1/lineage API (Flask).

report_db is used through the app's real save path (tm_app._save_report),
matching the established pattern in test_attack_paths.py / test_chain_reasoning.py
(save via the app, clean up via DELETE afterward) rather than swapping
report_db's own DB_PATH — lineage.db's own store IS repointed to a temp file
per test class, since it's a leaf store nothing else in the app depends on
staying at a fixed path.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from lineage import db, service

DESIGN_REPORT = {
    "id": "lin_design_1", "title": "Design Review", "methodology": "owasp",
    "categories": [{
        "id": "WEB-A03", "name": "SQL Injection", "risk": "High",
        "affected_components": ["user search handler"],
        "mitigations": [{"action": "Parameterize queries."}],
    }],
}

CODE_REPORT = {
    "id": "lin_code_1", "title": "Code Model", "methodology": "codemodel",
    "categories": [{
        "id": "CM-001", "name": "SQL Injection", "risk": "Critical", "_source": "CODEMODEL",
        "cwe": "CWE-89", "affected_components": ["handlers/user_search.py:42"],
    }],
}


class TestLineageServiceDirect(unittest.TestCase):
    def setUp(self):
        self._orig_db_path = db.DB_PATH
        self._td = tempfile.TemporaryDirectory()
        db.DB_PATH = Path(self._td.name) / "lineage.db"

        import report_db
        self._orig_report_path = report_db.DB_PATH
        report_db.DB_PATH = Path(self._td.name) / "reports.db"
        self.report_db = report_db

    def tearDown(self):
        db.DB_PATH = self._orig_db_path
        self.report_db.DB_PATH = self._orig_report_path
        self._td.cleanup()

    def test_sync_unknown_report_raises(self):
        with self.assertRaises(ValueError):
            service.sync("nonexistent_report_id")

    def test_sync_design_then_code_reports_realized(self):
        self.report_db.upsert_report(DESIGN_REPORT)
        summary1 = service.sync("lin_design_1")
        self.assertEqual(summary1["threats_created"], 1)
        self.assertEqual(summary1["realized_this_sync"], [])

        self.report_db.upsert_report(CODE_REPORT)
        summary2 = service.sync("lin_code_1")
        self.assertEqual(summary2["threats_created"], 0)
        self.assertEqual(summary2["threats_updated"], 1)
        self.assertEqual(len(summary2["realized_this_sync"]), 1)

        threats = service.list_threats()
        self.assertEqual(len(threats), 1)
        self.assertEqual(threats[0]["status"], "realized")
        self.assertEqual(threats[0]["event_count"], 2)

    def test_get_threat_includes_full_event_timeline(self):
        self.report_db.upsert_report(DESIGN_REPORT)
        service.sync("lin_design_1")
        self.report_db.upsert_report(CODE_REPORT)
        service.sync("lin_code_1")

        threat_id = service.list_threats()[0]["id"]
        full = service.get_threat(threat_id)
        self.assertIn("events", full)
        self.assertEqual(len(full["events"]), 2)
        self.assertEqual(full["events"][0]["kind"], "design")
        self.assertEqual(full["events"][1]["kind"], "code")

    def test_get_unknown_threat_returns_none(self):
        self.assertIsNone(service.get_threat("nope"))

    def test_status_summary_counts_by_status(self):
        self.report_db.upsert_report(DESIGN_REPORT)
        service.sync("lin_design_1")
        summary = service.status()
        self.assertEqual(summary["threats_tracked"], 1)
        self.assertEqual(summary["status_counts"]["predicted"], 1)

    def test_list_threats_filters_by_status(self):
        self.report_db.upsert_report(DESIGN_REPORT)
        service.sync("lin_design_1")
        self.assertEqual(len(service.list_threats(status="predicted")), 1)
        self.assertEqual(len(service.list_threats(status="realized")), 0)


class TestLineageApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as tm_app
        tm_app.app.config["TESTING"] = True
        cls.tm = tm_app
        cls.client = tm_app.app.test_client()
        cls.csrf = tm_app._CSRF_TOKEN

        cls._orig_lineage_db_path = db.DB_PATH
        cls._td = tempfile.TemporaryDirectory()
        db.DB_PATH = Path(cls._td.name) / "lineage_api.db"

        cls._saved = []
        cls.design_id = tm_app._save_report(dict(DESIGN_REPORT), "Lineage design fixture")
        cls._saved.append(cls.design_id)
        cls.code_id = tm_app._save_report(dict(CODE_REPORT), "Lineage code fixture")
        cls._saved.append(cls.code_id)

    @classmethod
    def tearDownClass(cls):
        for rid in cls._saved:
            cls.client.delete(f"/api/v1/reports/{rid}", headers={"X-CSRF-Token": cls.csrf})
        db.DB_PATH = cls._orig_lineage_db_path
        cls._td.cleanup()

    def _sync(self, report_id):
        return self.client.post("/api/v1/lineage/sync", json={"report_id": report_id},
                                headers={"X-CSRF-Token": self.csrf})

    def test_missing_report_id_rejected(self):
        r = self.client.post("/api/v1/lineage/sync", json={},
                             headers={"X-CSRF-Token": self.csrf})
        self.assertEqual(r.status_code, 400)

    def test_unknown_report_id_404(self):
        r = self._sync("nonexistent_1_00")
        self.assertEqual(r.status_code, 404)

    def test_sync_design_then_code_and_list_and_get(self):
        r1 = self._sync(self.design_id)
        self.assertEqual(r1.status_code, 200, r1.get_data(as_text=True))
        self.assertEqual(r1.get_json()["threats_created"], 1)

        r2 = self._sync(self.code_id)
        self.assertEqual(r2.status_code, 200)
        j2 = r2.get_json()
        self.assertEqual(len(j2["realized_this_sync"]), 1)

        threats = self.client.get("/api/v1/lineage/threats").get_json()["threats"]
        self.assertEqual(len(threats), 1)
        self.assertEqual(threats[0]["status"], "realized")

        detail = self.client.get(f"/api/v1/lineage/threats/{threats[0]['id']}").get_json()
        self.assertTrue(detail["success"])
        self.assertEqual(len(detail["threat"]["events"]), 2)

    def test_unknown_threat_id_404(self):
        r = self.client.get("/api/v1/lineage/threats/nonexistent")
        self.assertEqual(r.status_code, 404)

    def test_invalid_status_filter_rejected(self):
        r = self.client.get("/api/v1/lineage/threats?status=bogus")
        self.assertEqual(r.status_code, 400)

    def test_status_endpoint(self):
        r = self.client.get("/api/v1/lineage")
        self.assertEqual(r.status_code, 200)
        j = r.get_json()
        self.assertTrue(j["success"])
        self.assertIn("status_counts", j)


if __name__ == "__main__":
    unittest.main()
