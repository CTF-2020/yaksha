"""Static auditor for regular-expression denial-of-service (ReDoS).

A scanner that runs many regexes over attacker-controlled source is a DoS target:
one pattern with catastrophic backtracking meeting a crafted input can hang the
worker for minutes. Python's ``re`` cannot be interrupted mid-match portably, so
the durable defenses are (1) *find and fix* dangerous patterns before they ship
and (2) *cap input length* before matching. This module does (1) — a heuristic
detector for the three shapes that cause exponential/polynomial blowup — and
offers a bounded-length match helper for (2).

It is a heuristic, not a proof: it aims for high signal on the well-known evil
shapes (nested quantifiers, quantified overlapping alternation, adjacent
unbounded quantifiers) with few false alarms, and it can scan a source file's
own ``re.compile("…")`` literals via the AST.
"""
from __future__ import annotations

import ast
import re

_UNBOUNDED_Q = ("*", "+")


def _quant_at(pattern: str, i: int) -> bool:
    """True if position i begins an unbounded quantifier (*, +, or {n,})."""
    if i >= len(pattern):
        return False
    c = pattern[i]
    if c in _UNBOUNDED_Q:
        return True
    if c == "{":
        m = re.match(r"\{\d*,\}", pattern[i:])   # {n,} is unbounded
        return bool(m)
    return False


def _group_bodies(pattern: str):
    """Yield (body, quantified_unbounded) for each parenthesised group.

    A tiny paren matcher that respects escapes and character classes so it does
    not treat ``\\(`` or a ``[(]`` as a group. Returns each group's inner text and
    whether the group as a whole is immediately followed by an unbounded quantifier.
    """
    stack = []
    i, n = 0, len(pattern)
    in_class = False
    while i < n:
        c = pattern[i]
        if c == "\\":
            i += 2
            continue
        if in_class:
            if c == "]":
                in_class = False
            i += 1
            continue
        if c == "[":
            in_class = True
        elif c == "(":
            stack.append(i)
        elif c == ")" and stack:
            start = stack.pop()
            body = pattern[start + 1:i]
            after = i + 1
            # skip a group-close like )?: not relevant; check the char after ')'
            quantified = _quant_at(pattern, after)
            yield body, quantified
        i += 1


def _has_unbounded_inner_quant(body: str) -> bool:
    """True if a group body contains an unbounded quantifier at top level."""
    i, n = 0, len(body)
    in_class = False
    depth = 0
    while i < n:
        c = body[i]
        if c == "\\":
            i += 2
            continue
        if in_class:
            if c == "]":
                in_class = False
            i += 1
            continue
        if c == "[":
            in_class = True
        elif c == "(":
            depth += 1
        elif c == ")":
            depth = max(0, depth - 1)
        elif depth == 0 and _quant_at(body, i):
            return True
        i += 1
    return False


def _alternation_overlaps(body: str) -> bool:
    """Heuristic: a top-level '|' whose alternatives can match the same prefix."""
    # split on top-level | only
    parts, depth, cur, in_class = [], 0, [], False
    i = 0
    while i < len(body):
        c = body[i]
        if c == "\\":
            cur.append(body[i:i + 2]); i += 2; continue
        if c == "[":
            in_class = True
        elif c == "]":
            in_class = False
        elif not in_class and c == "(":
            depth += 1
        elif not in_class and c == ")":
            depth -= 1
        if c == "|" and depth == 0 and not in_class:
            parts.append("".join(cur)); cur = []
        else:
            cur.append(c)
        i += 1
    parts.append("".join(cur))
    if len(parts) < 2:
        return False
    firsts = [p[:1] for p in parts if p]
    if len(firsts) != len(set(firsts)):      # two alternatives share a first token
        return True
    for a in parts:                          # one alternative is a prefix of another
        for b in parts:
            if a and b and a != b and b.startswith(a):
                return True
    return False


def _adjacent_unbounded(pattern: str) -> bool:
    """Two consecutive unbounded-quantified atoms over overlapping classes (.*.* etc.)."""
    # normalise common atoms: '.', '\s', '\w', '\d', char-classes
    return bool(re.search(r"(?:\.|\\[swd]|\[[^\]]*\])[*+]\s*(?:\.|\\[swd]|\[[^\]]*\])[*+]",
                          pattern))


def audit_pattern(pattern: str) -> list[dict]:
    """Return a list of ReDoS findings for one pattern (empty if it looks safe)."""
    findings = []
    for body, quantified in _group_bodies(pattern):
        if quantified and _has_unbounded_inner_quant(body):
            findings.append({
                "severity": "High", "kind": "nested-quantifier",
                "detail": f"group '({body})' has an inner unbounded quantifier and is "
                          "itself quantified — exponential backtracking (e.g. (a+)+)."})
        if quantified and _alternation_overlaps(body):
            findings.append({
                "severity": "High", "kind": "quantified-overlapping-alternation",
                "detail": f"quantified alternation '({body})' has overlapping "
                          "alternatives — exponential backtracking (e.g. (a|ab)+)."})
    if _adjacent_unbounded(pattern):
        findings.append({
            "severity": "Medium", "kind": "adjacent-unbounded-quantifiers",
            "detail": "two adjacent unbounded quantifiers over overlapping classes "
                      "(e.g. .*.*) — polynomial backtracking."})
    return findings


def audit_patterns(patterns) -> list[dict]:
    out = []
    for p in patterns:
        for f in audit_pattern(p):
            out.append({"pattern": p, **f})
    return out


def audit_source_file(path: str) -> list[dict]:
    """Audit every ``re.compile("literal")`` / re.<fn>("literal") in a Python file."""
    try:
        # utf-8-sig strips a leading BOM so ast.parse does not choke on it and
        # silently skip BOM-prefixed source files.
        with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
            tree = ast.parse(fh.read())
    except (OSError, SyntaxError, ValueError):
        return []
    findings = []
    re_funcs = {"compile", "match", "search", "fullmatch", "findall", "finditer", "sub", "split"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                and node.func.attr in re_funcs and node.args \
                and isinstance(node.args[0], ast.Constant) \
                and isinstance(node.args[0].value, str):
            for f in audit_pattern(node.args[0].value):
                findings.append({"file": path, "line": node.lineno,
                                 "pattern": node.args[0].value[:120], **f})
    return findings


# ── runtime mitigation (2): cap input before matching ─────────────────────────
_DEFAULT_MAX_LEN = 100_000


def bounded_search(compiled, text: str, max_len: int = _DEFAULT_MAX_LEN):
    """Run ``compiled.search`` only on a length-capped slice of ``text``.

    Bounding the input is the portable mitigation for an undetected ReDoS: worst
    case is bounded by the input size, so a hostile file cannot cause unbounded
    CPU. Returns ``None`` for oversized input rather than risking the match.
    """
    if text is None:
        return None
    if len(text) > max_len:
        text = text[:max_len]
    return compiled.search(text)
