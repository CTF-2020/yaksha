"""Measured-accuracy harness for the OFFLINE deterministic analysis engine.

TM's SAST, DAST, taint and semantic layers elsewhere all carry a measured number;
the core reviewer did not. This scores ``offline_rules.run_offline_review`` against
the labelled :mod:`benchmark.corpus` and reports recall, specificity, precision,
F1 and a severity-accuracy figure — so every rule or phrasing change becomes a
measurable experiment instead of a vibe, and a regression drops a CI floor.

Scoring is *per targeted rule*, the honest way to score a broad reviewer: one
description legitimately trips many rules, so for each case only the rule the case
targets is graded (other rules firing is neither credited nor penalised). Each
case contributes two graded points:

  * ``vuln`` text  -> the targeted rule MUST fire (true positive if it does).
  * ``safe`` text  -> the targeted rule MUST NOT fire (false positive if it does).

From that 2x2 the harness derives:
  recall      = TP / (TP + FN)     did we catch the insecure design?
  specificity = TN / (TN + FP)     did we stay quiet on the secure one?
  precision   = TP / (TP + FP)     when we fired, were we right?
  f1          = harmonic mean of precision & recall
  severity    = of caught vulns, the fraction reaching the expected floor
                (WARN = raised at all; FAIL = reached Critical/High)

It also runs a fully-secure ``CLEAN_DESIGN`` and reports the over-warn rate: how
many of all applicable rules fire on a design that should raise almost none.

Pure and offline — no API key, deterministic, fast enough to gate on.
"""
from __future__ import annotations

import offline_rules

from . import corpus

# A "FAIL" case must reach Critical/High; a "WARN" case need only be raised.
_FAIL_STATUSES = {"FAIL"}
_RAISED_STATUSES = {"WARN", "FAIL"}


def _status_of(review: dict, rule_id: str) -> str:
    """The targeted rule's status in a review, or PASS if it did not fire/apply."""
    for f in review.get("findings", []):
        if f.get("rule_id") == rule_id:
            return f.get("status", "PASS")
    return "PASS"


def _meets_expect(status: str, expect: str) -> bool:
    if expect == "FAIL":
        return status in _FAIL_STATUSES
    return status in _RAISED_STATUSES     # "WARN" == raised at all


def evaluate() -> dict:
    """Run the full corpus and return structured metrics (no printing)."""
    tp = fp = fn = tn = 0
    severity_ok = 0            # of caught vulns, reached the expected floor
    per_ruleset: dict[str, dict] = {}
    case_rows: list[dict] = []

    for case in corpus.CASES:
        rid, rs, expect = case["rule_id"], case["ruleset"], case["expect"]
        bucket = per_ruleset.setdefault(rs, {"tp": 0, "fp": 0, "fn": 0, "tn": 0})

        vuln_status = _status_of(
            offline_rules.run_offline_review(case["vuln"], [rs]), rid)
        raised = vuln_status in _RAISED_STATUSES
        if raised:
            tp += 1; bucket["tp"] += 1
            if _meets_expect(vuln_status, expect):
                severity_ok += 1
        else:
            fn += 1; bucket["fn"] += 1

        safe_status = _status_of(
            offline_rules.run_offline_review(case["safe"], [rs]), rid)
        safe_fired = safe_status in _RAISED_STATUSES
        if safe_fired:
            fp += 1; bucket["fp"] += 1
        else:
            tn += 1; bucket["tn"] += 1

        case_rows.append({
            "rule_id": rid, "ruleset": rs, "expect": expect,
            "vuln_status": vuln_status, "safe_status": safe_status,
            "recall_hit": raised, "specificity_hit": not safe_fired,
            "severity_hit": raised and _meets_expect(vuln_status, expect),
        })

    def _ratio(a, b):
        return round(a / b, 4) if b else 0.0

    recall = _ratio(tp, tp + fn)
    specificity = _ratio(tn, tn + fp)
    precision = _ratio(tp, tp + fp)
    f1 = _ratio(2 * precision * recall, precision + recall) if (precision + recall) else 0.0
    severity_recall = _ratio(severity_ok, tp + fn)

    # Over-warn on a fully-secure design: applicable rules that fire.
    clean = offline_rules.run_offline_review(corpus.CLEAN_DESIGN)
    clean_findings = clean.get("findings", [])
    clean_fired = sum(1 for f in clean_findings if f.get("status") in _RAISED_STATUSES)
    clean_total = len(clean_findings)

    ruleset_metrics = {
        rs: {
            "recall": _ratio(b["tp"], b["tp"] + b["fn"]),
            "specificity": _ratio(b["tn"], b["tn"] + b["fp"]),
            "cases": b["tp"] + b["fn"],
        } for rs, b in sorted(per_ruleset.items())
    }

    return {
        "cases": len(corpus.CASES),
        "confusion": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
        "recall": recall,
        "specificity": specificity,
        "precision": precision,
        "f1": f1,
        "severity_recall": severity_recall,
        "clean_design": {
            "rules_evaluated": clean_total,
            "rules_fired": clean_fired,
            "overwarn_rate": _ratio(clean_fired, clean_total),
            "overall_risk": clean.get("overall_risk"),
        },
        "by_ruleset": ruleset_metrics,
        "cases_detail": case_rows,
    }


def format_report(m: dict) -> str:
    c = m["confusion"]
    lines = [
        "Offline analysis engine — measured accuracy",
        "=" * 48,
        f"corpus cases        : {m['cases']}  (each = 1 vuln + 1 safe)",
        f"confusion (rule-lvl): TP={c['tp']} FP={c['fp']} FN={c['fn']} TN={c['tn']}",
        "",
        f"recall (caught)     : {m['recall']:.1%}",
        f"specificity (quiet) : {m['specificity']:.1%}",
        f"precision           : {m['precision']:.1%}",
        f"F1                  : {m['f1']:.1%}",
        f"severity accuracy   : {m['severity_recall']:.1%}",
        "",
        f"clean design over-warn: {m['clean_design']['rules_fired']}/"
        f"{m['clean_design']['rules_evaluated']} rules "
        f"({m['clean_design']['overwarn_rate']:.1%}), "
        f"overall risk = {m['clean_design']['overall_risk']}",
        "",
        "per ruleset (recall / specificity):",
    ]
    for rs, r in m["by_ruleset"].items():
        lines.append(f"  {rs:<12} recall {r['recall']:.0%}  "
                     f"specificity {r['specificity']:.0%}  (n={r['cases']})")
    misses = [c for c in m["cases_detail"] if not c["recall_hit"]]
    fps = [c for c in m["cases_detail"] if not c["specificity_hit"]]
    if misses:
        lines += ["", "missed (vuln not raised):"]
        lines += [f"  {c['rule_id']} ({c['vuln_status']})" for c in misses]
    if fps:
        lines += ["", "false positives (safe design fired):"]
        lines += [f"  {c['rule_id']} ({c['safe_status']})" for c in fps]
    return "\n".join(lines)


def main() -> None:
    print(format_report(evaluate()))


if __name__ == "__main__":
    main()
