"""Business-impact classification for code-derived findings.

Technical exploitability (see ``codemodel/threats.py`` ``reachability`` facts,
consumed by ``correlator/engine.py`` ``_exploitability``) answers "can this be
reached and proven". It says nothing about "does it matter if it is" — a SQL
injection on ``/internal/healthcheck`` and one on ``/api/payments/charge`` can
be equally reachable and equally tainted, yet carry very different business
risk. This module supplies that missing, orthogonal signal.

Business criticality is not something static analysis of code *structure*
can derive the way reachability can — there is no call graph for "this is
where the money is". The best a code-derived engine can do without an
explicit asset registry is infer it from what the affected route, handler,
or asset is *named*, the same way a human reading a repo would. That is
deliberately weaker evidence than reachability, so it is scored and surfaced
as its own signal rather than folded into it.

Conservative by construction: no keyword match means no tier (``None``),
never a guessed default — mirrors ``reachability`` being absent (not
"safe") when the code model has no coverage, so this stays purely additive
and never fabricates a signal.
"""
from __future__ import annotations

import re

CRITICAL, HIGH, MEDIUM, LOW = "critical", "high", "medium", "low"

_SCORE = {CRITICAL: 1.0, HIGH: 0.7, MEDIUM: 0.4, LOW: 0.15}

# Keyword -> tier, checked worst-first so the highest tier hit anywhere in the
# text wins when a blob matches more than one bucket (e.g. "payment_user_export"
# is CRITICAL, not MEDIUM). Keywords are matched as whole "words" (bounded by
# non-alphanumerics: '/', '_', '-', '.', start/end) against route paths,
# handler names, and file/asset names, so "order" matches "/api/orders" or
# "order_service.py" but not "orderly".
_KEYWORDS = {
    CRITICAL: (
        "payment", "payments", "checkout", "billing", "invoice", "card",
        "cvv", "stripe", "paypal", "wallet", "ach", "wire", "refund",
        "subscription", "ledger", "payout",
    ),
    HIGH: (
        "credential", "credentials", "password", "secret", "apikey",
        "api_key", "token", "auth", "login", "account", "accounts",
        "user", "users", "profile", "pii", "ssn", "dob", "address",
        "phone", "email", "medical", "health", "patient", "admin",
        "privilege", "role", "permission",
    ),
    MEDIUM: (
        "order", "orders", "cart", "inventory", "product", "products",
        "session", "booking",
    ),
    LOW: (
        "log", "logs", "logging", "metric", "metrics", "analytic",
        "analytics", "telemetry", "healthcheck", "health-check", "ping",
        "status", "docs", "readme", "static", "asset", "assets",
    ),
}

_WORD_RE = {
    tier: re.compile(
        r"(?:^|[^a-z0-9])(" + "|".join(re.escape(k) for k in kws) + r")(?:$|[^a-z0-9])",
        re.IGNORECASE,
    )
    for tier, kws in _KEYWORDS.items()
}


def classify(*texts: str) -> dict | None:
    """Infer a business-impact tier from free text.

    Pass route paths, handler names, file paths, and component/asset names —
    anything naming what the finding actually touches. Scans for the
    highest-severity keyword match across all provided text and returns
    ``{"tier", "score", "reason"}``, or ``None`` if nothing matched.
    """
    blob = " ".join(t for t in texts if t)
    if not blob:
        return None
    for tier in (CRITICAL, HIGH, MEDIUM, LOW):
        m = _WORD_RE[tier].search(blob)
        if m:
            keyword = m.group(1).lower()
            return {
                "tier": tier,
                "score": _SCORE[tier],
                "reason": f"asset/route name matches '{keyword}' ({tier}-impact keyword)",
            }
    return None


# Worst-first rank so a CRITICAL hit always beats a HIGH hit regardless of
# hop distance, matched against how far apart hop decay can move a score
# (see _HOP_DECAY below — two tiers apart never closes at the reach depths
# the call-graph BFS uses).
_TIER_RANK = {CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1}
# Per-hop multiplier applied to an indirect hit's score: a keyword found on
# the finding's own locus (hop 0) scores at face value; the same keyword
# found N call-hops away in the reachable subgraph is real but weaker
# evidence, so it is discounted geometrically rather than trusted at face
# value.
_HOP_DECAY = 0.85


def nearest_match(candidates: list[tuple[str, int]]) -> dict | None:
    """Graph-proximity variant of :func:`classify`.

    ``candidates`` is ``[(text, hops), ...]`` gathered by walking the call
    graph out from a single entry point — the entry point's own route/name/
    file at hop 0, then every function it transitively calls at increasing
    hop distance (see ``codemodel/extractor.py:_reachable_impact``). A hop-0
    candidate reduces to exactly what :func:`classify` would find on that
    same text, so this is a strict superset of the old name-only heuristic:
    it additionally catches a generically-named route that calls a helper
    named/located near a sensitive asset a few hops away, which naming the
    route alone can never see.

    Picks the worst (highest-rank) tier hit across every candidate; ties
    within a tier are broken by the smallest hop distance. Returns
    ``{"tier", "score", "reason", "hops"}``, or ``None`` if nothing in the
    reachable subgraph matched any keyword.
    """
    best = None  # ((tier_rank, -hops), tier, keyword, hops)
    for text, hops in candidates:
        if not text:
            continue
        for tier in (CRITICAL, HIGH, MEDIUM, LOW):
            m = _WORD_RE[tier].search(text)
            if not m:
                continue
            key = (_TIER_RANK[tier], -hops)
            if best is None or key > best[0]:
                best = (key, tier, m.group(1).lower(), hops)
            break  # this candidate's own best tier found; don't downgrade it
    if best is None:
        return None
    _, tier, keyword, hops = best
    score = round(_SCORE[tier] * (_HOP_DECAY ** hops), 3)
    if hops == 0:
        reason = f"asset/route name matches '{keyword}' ({tier}-impact keyword)"
    else:
        reason = (f"call graph reaches '{keyword}' ({tier}-impact keyword) "
                  f"{hops} call hop(s) from the entry point")
    return {"tier": tier, "score": score, "reason": reason, "hops": hops}
