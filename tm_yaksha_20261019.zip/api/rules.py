"""Rule catalog API + dashboard page.

Serves the semgrep rule *reference* catalog (metadata only — see the `_notice`
block in data/semgrep_rules.json). Read-only; safe under the app's global
before_request (CSRF only guards mutating verbs, of which this blueprint has none).

Routes:
  GET  /api/v1/rules                 paginated/filtered rule list (?q, ?language,
                                     ?category, ?severity, ?cwe, ?owasp, ?page, ?per_page)
  GET  /api/v1/rules/facets          filter values + counts, plus the source notice
  GET  /api/v1/rules/stats           catalog totals
  GET  /api/v1/rules/<key>           one rule by key or id
  GET  /rules                        dashboard UI (separate, un-prefixed blueprint)
"""
from __future__ import annotations

from flask import Blueprint, jsonify, render_template, request

import rules_catalog

bp = Blueprint("rules_api", __name__, url_prefix="/api/v1/rules")
page_bp = Blueprint("rules_page", __name__)


@bp.get("")
def list_rules():
    try:
        per_page = int(request.args.get("per_page", 50))
        page = int(request.args.get("page", 1))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "page/per_page must be integers"}), 400
    result = rules_catalog.query(
        q=request.args.get("q"),
        language=request.args.get("language"),
        category=request.args.get("category"),
        severity=request.args.get("severity"),
        ruleset=request.args.get("ruleset"),
        cwe=request.args.get("cwe"),
        owasp=request.args.get("owasp"),
        page=page,
        per_page=per_page,
    )
    result["success"] = True
    return jsonify(result)


@bp.get("/facets")
def facets():
    return jsonify({"success": True, "facets": rules_catalog.facets(),
                    "notice": rules_catalog.notice()})


@bp.get("/stats")
def stats():
    return jsonify({"success": True, **rules_catalog.stats()})


@bp.get("/<path:key>")
def get_rule(key):
    rule = rules_catalog.get(key)
    if not rule:
        return jsonify({"success": False, "error": "rule not found"}), 404
    return jsonify({"success": True, "rule": rule})


@page_bp.get("/rules")
def dashboard():
    from app import _CSRF_TOKEN
    return render_template("rules.html", csrf_token=_CSRF_TOKEN)
