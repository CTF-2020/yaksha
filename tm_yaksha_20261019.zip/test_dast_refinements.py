"""Tests for the DAST engine refinements: SRI check + boolean-blind SQLi.

Run:  python -m unittest test_dast_refinements

Drives the real in-process engine against a local HTTP server crafted to be
vulnerable (or safe) for each new capability, plus direct unit tests of the
detection logic. Uses the loopback interface only, a tight request budget, and
no rate delay so it runs fast and touches nothing external.
"""
from __future__ import annotations

import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from dast import engine


# ── A tiny configurable target ────────────────────────────────────────────────
class _Handler(BaseHTTPRequestHandler):
    pages: dict = {}          # path -> html (for static/SRI pages)
    sqli_param = "id"         # param that is boolean-SQLi vulnerable

    def log_message(self, *a):
        pass

    def _send(self, body: str, ctype="text/html; charset=utf-8"):
        raw = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query, keep_blank_values=True)

        if path == "/search":
            # Boolean-blind SQLi simulation: the value is spliced into a WHERE.
            # TRUE predicate -> full result row; FALSE predicate -> empty result.
            val = (qs.get(self.sqli_param, [""])[0])
            rows = _simulate_sql(val)
            body = "<html><body><h1>Results</h1>" + rows + "</body></html>"
            return self._send(body)

        return self._send(self.pages.get(path, "<html><body>ok</body></html>"))


def _simulate_sql(value: str) -> str:
    """Model `SELECT ... WHERE id = <value>` for a table with one matching row.

    A bare/known id and any TRUE tautology return the row; a FALSE predicate
    (…1=2, …'1'='2, …\"1\"=\"2) returns no rows. A lone quote raises no error
    (error-based is suppressed) — exactly the case boolean-blind is meant to catch.
    """
    v = value.strip()
    row = "<div class='row'>id=1 name=Alice email=alice@example.com role=admin</div>"
    # FALSE predicates -> empty
    for false_marker in ("1=2", "'1'='2", '"1"="2'):
        if false_marker in v.replace(" ", ""):
            return "<p>No results.</p>"
    # TRUE predicates OR the plain baseline value -> the row
    return row


def _serve(handler_cls) -> tuple[ThreadingHTTPServer, str]:
    srv = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    host, port = srv.server_address
    return srv, f"http://127.0.0.1:{port}"


def _fast_scan(base_url):
    # No rate delay, generous budget, injection checks on — bypass config gates.
    engine.config.RATE_DELAY = 0.0
    engine.config.ACTIVE_CHECKS = True
    engine.config.INJECTION_CHECKS = True
    return engine.scan(base_url, ["127.0.0.1"], severity_threshold="Info",
                       max_pages=20, time_budget=30)


# ── Boolean-blind SQLi (end-to-end against the local server) ──────────────────
class TestBooleanSqli(unittest.TestCase):
    def test_detects_boolean_blind_sqli(self):
        class H(_Handler):
            pages = {"/": '<html><body><a href="/search?id=1">go</a></body></html>'}
        srv, base = _serve(H)
        try:
            result = _fast_scan(base)
        finally:
            srv.shutdown(); srv.server_close()
        ids = {f["id"] for f in result.findings}
        self.assertIn("DAST-SQLI-BOOLEAN", ids)

    def test_no_false_positive_on_static_page(self):
        # /search ignores the param entirely -> TRUE and FALSE return the same page.
        class H(_Handler):
            pages = {"/": '<html><body><a href="/search?id=1">go</a></body></html>'}
            def do_GET(self):
                if urlparse(self.path).path == "/search":
                    return self._send("<html><body>constant results</body></html>")
                return self._send(self.pages.get(urlparse(self.path).path, "ok"))
        srv, base = _serve(H)
        try:
            result = _fast_scan(base)
        finally:
            srv.shutdown(); srv.server_close()
        self.assertNotIn("DAST-SQLI-BOOLEAN", {f["id"] for f in result.findings})


# ── SRI (unit test of the check + parser) ─────────────────────────────────────
class TestSri(unittest.TestCase):
    def _report_for(self, html, page="https://app.example.com/"):
        parser = engine._LinkParser()
        parser.feed(html)
        rep = engine._Reporter(threshold=engine.config.SEVERITY_ORDER["Info"])
        engine._check_sri(page, parser.sri, ["app.example.com"], rep)
        return rep.findings

    def test_flags_cross_origin_script_without_integrity(self):
        html = '<script src="https://cdn.evil-thirdparty.com/a.js"></script>'
        ids = {f["id"] for f in self._report_for(html)}
        self.assertIn("DAST-SRI-MISSING", ids)

    def test_ignores_cross_origin_with_integrity(self):
        html = ('<script src="https://cdn.thirdparty.com/a.js" '
                'integrity="sha384-abc" crossorigin="anonymous"></script>')
        self.assertEqual(self._report_for(html), [])

    def test_ignores_same_origin_script(self):
        html = '<script src="/static/app.js"></script>'
        self.assertEqual(self._report_for(html), [])

    def test_flags_cross_origin_stylesheet(self):
        html = '<link rel="stylesheet" href="https://cdn.other.com/x.css">'
        ids = {f["id"] for f in self._report_for(html)}
        self.assertIn("DAST-SRI-MISSING", ids)


# ── body-similarity helper ────────────────────────────────────────────────────
class TestBodyRatio(unittest.TestCase):
    def test_identical_is_one(self):
        self.assertEqual(engine._body_ratio("<p>x</p>", "<p>x</p>"), 1.0)

    def test_whitespace_normalized(self):
        self.assertGreaterEqual(engine._body_ratio("a   b", "a b"), 0.99)

    def test_different_is_low(self):
        big_a = "<div>row</div>" * 200
        big_b = "<p>No results.</p>"
        self.assertLess(engine._body_ratio(big_a, big_b), 0.5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
