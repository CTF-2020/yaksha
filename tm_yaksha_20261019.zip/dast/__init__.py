"""Dynamic Application Security Testing (DAST) package.

A running-application scanner that parallels the SAST broker: register a target
URL, run a safe, bounded active/passive scan, and surface findings in the same
Yaksha Guard TM report viewer. The engine is stdlib-only and in-process, so a
scan needs no external tooling.
"""
from __future__ import annotations

from .service import get_service

__all__ = ["get_service"]
